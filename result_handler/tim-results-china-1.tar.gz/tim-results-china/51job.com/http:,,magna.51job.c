[0712/095928.017721:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095928.018063:INFO:switcher_clone.cc(787)] backtrace rip is 7fd0d8944891
[0712/095928.828181:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095928.828504:INFO:switcher_clone.cc(787)] backtrace rip is 7f075a529891
[1:1:0712/095928.832801:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/095928.833015:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/095928.838537:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/095930.383689:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095930.384105:INFO:switcher_clone.cc(787)] backtrace rip is 7f1a0ca8c891
[120524:120524:0712/095930.396043:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6959b785-d0b4-4b8e-a112-d15e728a6e8b
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[120557:120557:0712/095930.611169:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=120557
[120569:120569:0712/095930.611674:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=120569
[120524:120524:0712/095930.970815:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[120524:120555:0712/095930.971662:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/095930.971928:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095930.972163:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095930.972880:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095930.973081:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/095930.976570:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d4d81da, 1
[1:1:0712/095930.977050:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3e96d96d, 0
[1:1:0712/095930.977257:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x314d08cf, 3
[1:1:0712/095930.977506:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xe4f58c9, 2
[1:1:0712/095930.977746:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6dffffffd9ffffff963e ffffffdaffffff814d3d ffffffc9584f0e ffffffcf084d31 , 10104, 4
[1:1:0712/095930.978791:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[120524:120555:0712/095930.979064:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGmٖ>ځM=�XO�M1.�
[120524:120555:0712/095930.979147:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is mٖ>ځM=�XO�M1Ȗ.�
[1:1:0712/095930.979053:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07587640a0, 3
[1:1:0712/095930.979310:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07588ef080, 2
[120524:120555:0712/095930.979551:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[120524:120555:0712/095930.979621:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 120577, 4, 6dd9963e da814d3d c9584f0e cf084d31 
[1:1:0712/095930.979597:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07425b2d20, -2
[1:1:0712/095931.002236:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095931.003109:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e4f58c9
[1:1:0712/095931.004069:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e4f58c9
[1:1:0712/095931.005709:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e4f58c9
[1:1:0712/095931.007202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.007409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.007603:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.007792:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.008479:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e4f58c9
[1:1:0712/095931.008823:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f075a5297ba
[1:1:0712/095931.008957:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f075a520def, 7f075a52977a, 7f075a52b0cf
[1:1:0712/095931.014679:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e4f58c9
[1:1:0712/095931.015037:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e4f58c9
[1:1:0712/095931.015797:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e4f58c9
[1:1:0712/095931.017815:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.018009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.018197:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.018403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e4f58c9
[1:1:0712/095931.019637:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e4f58c9
[1:1:0712/095931.020003:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f075a5297ba
[1:1:0712/095931.020148:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f075a520def, 7f075a52977a, 7f075a52b0cf
[1:1:0712/095931.027875:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095931.028342:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095931.028505:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeaba7938, 0x7ffdeaba78b8)
[1:1:0712/095931.044056:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095931.049827:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[120524:120524:0712/095931.609430:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120524:120524:0712/095931.610624:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120524:120536:0712/095931.628945:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[120524:120536:0712/095931.629041:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[120524:120524:0712/095931.630739:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[120524:120524:0712/095931.630812:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[120524:120524:0712/095931.630948:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,120577, 4
[1:7:0712/095931.635417:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[120524:120548:0712/095931.686442:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/095931.759638:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2642b09ab220
[1:1:0712/095931.759917:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/095932.073472:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/095933.576097:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095933.579496:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[120524:120524:0712/095933.607159:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[120524:120524:0712/095933.607267:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095934.660809:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095934.827924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095934.828296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095934.845299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095934.845705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095934.996317:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095934.996702:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095935.477134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095935.485341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095935.485642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095935.521937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095935.532419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095935.532684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095935.544384:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/095935.547879:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2642b09a9e20
[1:1:0712/095935.548108:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[120524:120524:0712/095935.549719:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[120524:120524:0712/095935.565218:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[120524:120524:0712/095935.590958:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[120524:120524:0712/095935.591122:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095935.655545:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095936.586511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f074418d2e0 0x2642b0c3cb60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095936.587922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/095936.588195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095936.589671:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095936.637953:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2642b09aa820
[1:1:0712/095936.638223:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[120524:120524:0712/095936.644742:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[120524:120524:0712/095936.655948:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/095936.667960:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/095936.668361:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[120524:120524:0712/095936.674380:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[120524:120524:0712/095936.688014:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120524:120524:0712/095936.689032:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120524:120536:0712/095936.695071:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[120524:120536:0712/095936.695182:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[120524:120524:0712/095936.695308:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[120524:120524:0712/095936.695385:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[120524:120524:0712/095936.695520:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,120577, 4
[1:7:0712/095936.699435:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095937.266570:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/095937.894140:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f074418d2e0 0x2642b0b82be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095937.895186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/095937.895424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095937.896257:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[120524:120524:0712/095937.975261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[120524:120524:0712/095937.975377:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/095938.008917:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095938.467352:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[120524:120524:0712/095938.752049:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[120524:120555:0712/095938.752530:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/095938.752733:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095938.752995:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095938.753428:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095938.753636:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/095938.757349:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x16eea42a, 1
[1:1:0712/095938.757719:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f4e3d88, 0
[1:1:0712/095938.757905:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1b5e6914, 3
[1:1:0712/095938.758089:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x12f38979, 2
[1:1:0712/095938.758273:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff883d4e2f 2affffffa4ffffffee16 79ffffff89fffffff312 14695e1b , 10104, 5
[1:1:0712/095938.759307:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[120524:120555:0712/095938.759592:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�=N/*��y��i^�0�
[120524:120555:0712/095938.759662:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �=N/*��y��i^��0�
[1:1:0712/095938.759586:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07587640a0, 3
[120524:120555:0712/095938.759922:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 120621, 5, 883d4e2f 2aa4ee16 7989f312 14695e1b 
[1:1:0712/095938.759859:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07588ef080, 2
[1:1:0712/095938.760093:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f07425b2d20, -2
[1:1:0712/095938.782624:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095938.783022:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12f38979
[1:1:0712/095938.783377:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12f38979
[1:1:0712/095938.784049:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12f38979
[1:1:0712/095938.785555:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.785800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.786027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.786255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.786955:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12f38979
[1:1:0712/095938.787306:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f075a5297ba
[1:1:0712/095938.787483:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f075a520def, 7f075a52977a, 7f075a52b0cf
[1:1:0712/095938.793334:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12f38979
[1:1:0712/095938.793755:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12f38979
[1:1:0712/095938.794511:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12f38979
[1:1:0712/095938.796528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.796786:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.797008:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.797252:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12f38979
[1:1:0712/095938.798599:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12f38979
[1:1:0712/095938.799096:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f075a5297ba
[1:1:0712/095938.799318:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f075a520def, 7f075a52977a, 7f075a52b0cf
[1:1:0712/095938.807176:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095938.807734:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095938.807966:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeaba7938, 0x7ffdeaba78b8)
[1:1:0712/095938.819006:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095938.823401:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/095939.001007:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2642b0971220
[1:1:0712/095939.001291:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/095939.028653:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095939.028892:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095939.564853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095939.570627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d217dace5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/095939.570975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095939.579201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[120524:120524:0712/095939.665143:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120524:120524:0712/095939.671104:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120524:120524:0712/095939.714496:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://magna.51job.com/
[120524:120524:0712/095939.714588:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://magna.51job.com/, http://magna.51job.com/, 1
[120524:120524:0712/095939.714726:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://magna.51job.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:59:39 GMT Server: Apache Cache-Control: no-cache,no-store Expires: Thu, 01 Jan 1970 00:00:01 GMT Pragma: no-cache Keep-Alive: timeout=10, max=198 Connection: Keep-Alive Content-Type: text/html Content-Encoding: gzip Transfer-Encoding: chunked  ,120621, 5
[120524:120536:0712/095939.720480:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[120524:120536:0712/095939.720564:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/095939.729394:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095939.730685:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095939.731406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d217d9a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/095939.731651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095939.773942:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://magna.51job.com/
[1:1:0712/095939.911280:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[120524:120524:0712/095939.915484:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://magna.51job.com/, http://magna.51job.com/, 1
[120524:120524:0712/095939.915581:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://magna.51job.com/, http://magna.51job.com
[1:1:0712/095940.024157:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095940.044077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095940.045800:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/095940.046021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d217dace5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/095940.046310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095940.117133:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095940.117380:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://magna.51job.com/"
[1:1:0712/095940.142035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 122 0x7f0742265070 0x2642b0979560 , "http://magna.51job.com/"
[1:1:0712/095940.144623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , , 
	var _tkd = _tkd || [];
	var param = 'webId=4&accountId=&ctmId=607998&guid=&dType=1&jobId=&type=&ur
[1:1:0712/095940.144894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095940.164375:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095940.165344:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/095940.165587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d217dace5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/095940.165865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095940.493689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 153 0x7f07588ef080 0x2642b0af2ce0 1 0 0x2642b0af2cf8 , "http://magna.51job.com/"
[1:1:0712/095940.539228:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095940.549953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0712/095940.550230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095940.872387:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.104065, 350, 1
[1:1:0712/095940.872679:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/095941.293956:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095941.294247:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://magna.51job.com/"
[1:1:0712/095941.302749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194 0x7f0742265070 0x2642b0cc4a60 , "http://magna.51job.com/"
[1:1:0712/095941.321791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , , /*! Video.js v4.5.1 Copyright 2014 Brightcove, Inc. https://github.com/videojs/video.js/blob/master/
[1:1:0712/095941.322102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095941.325426:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095941.325950:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095941.329951:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095941.330453:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095941.330863:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095941.398006:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x376c05b229c8, 0x2642b07431a8
[1:1:0712/095941.398270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://magna.51job.com/", 1
[1:1:0712/095941.398640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 214
[1:1:0712/095941.398906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 214 0x7f0742265070 0x2642b0cc6260 , 5:3_http://magna.51job.com/, 1, -5:3_http://magna.51job.com/, 194 0x7f0742265070 0x2642b0cc4a60 
[1:1:0712/095941.439439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 194 0x7f0742265070 0x2642b0cc4a60 , "http://magna.51job.com/"
[1:1:0712/095941.580565:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.286291, 434, 1
[1:1:0712/095941.580906:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095942.033227:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095942.033479:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://magna.51job.com/"
[1:1:0712/095942.034231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.035094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , , 
  function clearfield(obj)
    {
    if (obj.value == "职位搜索  请输入职位名称关键词
[1:1:0712/095942.035310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095942.038385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.044741:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.114618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.126654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.132053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.159813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095942.187627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f0742265070 0x2642b09d0d60 , "http://magna.51job.com/"
[1:1:0712/095943.162623:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.12909, 8, 0
[1:1:0712/095943.162903:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095943.170364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 214, 7f0744baa881
[1:1:0712/095943.182213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33bf74c02860","ptid":"194 0x7f0742265070 0x2642b0cc4a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095943.182520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://magna.51job.com/","ptid":"194 0x7f0742265070 0x2642b0cc4a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095943.182853:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095943.185278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , u.dc, (){var a,c,d=document.getElementsByTagName("video");if(d&&0<d.length)for(var e=0,g=d.length;e<g;e++)
[1:1:0712/095943.185495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095943.307540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://magna.51job.com/", 500
[1:1:0712/095943.308043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 287
[1:1:0712/095943.308292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 287 0x7f0742265070 0x2642b0d1b460 , 5:3_http://magna.51job.com/, 1, -5:3_http://magna.51job.com/, 214 0x7f0742265070 0x2642b0cc6260 
[1:1:0712/095943.504794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x376c05b229c8, 0x2642b0743150
[1:1:0712/095943.505036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://magna.51job.com/", 0
[1:1:0712/095943.505418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 289
[1:1:0712/095943.505647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 289 0x7f0742265070 0x2642b1331f60 , 5:3_http://magna.51job.com/, 1, -5:3_http://magna.51job.com/, 214 0x7f0742265070 0x2642b0cc6260 
[1:1:0712/095943.670167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://magna.51job.com/", 250
[1:1:0712/095943.670622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 290
[1:1:0712/095943.670872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 290 0x7f0742265070 0x2642b0b16760 , 5:3_http://magna.51job.com/, 1, -5:3_http://magna.51job.com/, 214 0x7f0742265070 0x2642b0cc6260 
[1:1:0712/095944.581717:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095944.582144:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://magna.51job.com/"
[1:1:0712/095944.585733:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://magna.51job.com/"
[1:1:0712/095944.586670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , A, (){i.addEventListener?(i.removeEventListener("DOMContentLoaded",A,!1),v.ready()):i.readyState==="com
[1:1:0712/095944.586793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095947.304272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "abort", "http://magna.51job.com/"
[1:1:0712/095947.305033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e.V.e.V, (c){if(!e.disabled){c=u.ic(c);var d=e.z[c.type];if(d)for(var d=d.slice(0),k=0,r=d.length;k<r&&!c.pc(
[1:1:0712/095947.305300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095947.323663:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095947.324441:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095947.330251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "emptied", "http://magna.51job.com/"
[1:1:0712/095947.336194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "timeupdate", "http://magna.51job.com/"
[1:1:0712/095947.336726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "timeupdate", "http://magna.51job.com/"
[1:1:0712/095947.421464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 289, 7f0744baa881
[1:1:0712/095947.433009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33bf74c02860","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.433355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://magna.51job.com/","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.433732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095947.434275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095947.434517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095947.478458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 287, 7f0744baa8db
[1:1:0712/095947.493702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33bf74c02860","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.494046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://magna.51job.com/","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.494491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 356
[1:1:0712/095947.494730:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7f0742265070 0x2642b152fb60 , 5:3_http://magna.51job.com/, 0, , 287 0x7f0742265070 0x2642b0d1b460 
[1:1:0712/095947.495046:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095947.495591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095947.495831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095947.629954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 290, 7f0744baa8db
[1:1:0712/095947.646270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33bf74c02860","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.646596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://magna.51job.com/","ptid":"214 0x7f0742265070 0x2642b0cc6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095947.647029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 367
[1:1:0712/095947.647274:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7f0742265070 0x2642b0d1ebe0 , 5:3_http://magna.51job.com/, 0, , 290 0x7f0742265070 0x2642b0b16760 
[1:1:0712/095947.647584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095947.648298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095947.648522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095947.650542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x376c05b229c8, 0x2642b0743150
[1:1:0712/095947.650749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://magna.51job.com/", 2000
[1:1:0712/095947.651101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 370
[1:1:0712/095947.651340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f0742265070 0x2642b0d19560 , 5:3_http://magna.51job.com/, 1, -5:3_http://magna.51job.com/, 290 0x7f0742265070 0x2642b0b16760 
[1:1:0712/095948.094203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://magna.51job.com/"
[1:1:0712/095948.094665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://magna.51job.com/"
[1:1:0712/095948.095316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e.V.e.V, (c){if(!e.disabled){c=u.ic(c);var d=e.z[c.type];if(d)for(var d=d.slice(0),k=0,r=d.length;k<r&&!c.pc(
[1:1:0712/095948.095543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095948.102541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "suspend", "http://magna.51job.com/"
[1:1:0712/095948.257369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://magna.51job.com/"
[1:1:0712/095948.258071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , img.onload.img.onerror, () {
            win[n] = null;
        }
[1:1:0712/095948.258324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095948.422990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 367, 7f0744baa8db
[1:1:0712/095948.440141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"290 0x7f0742265070 0x2642b0b16760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095948.440475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"290 0x7f0742265070 0x2642b0b16760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095948.440942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 399
[1:1:0712/095948.441181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 399 0x7f0742265070 0x2642b152cc60 , 5:3_http://magna.51job.com/, 0, , 367 0x7f0742265070 0x2642b0d1ebe0 
[1:1:0712/095948.441517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095948.442057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095948.442271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095948.513559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 356, 7f0744baa8db
[1:1:0712/095948.529221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"287 0x7f0742265070 0x2642b0d1b460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095948.529560:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"287 0x7f0742265070 0x2642b0d1b460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095948.530014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 407
[1:1:0712/095948.530246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7f0742265070 0x2642b0d60160 , 5:3_http://magna.51job.com/, 0, , 356 0x7f0742265070 0x2642b152fb60 
[1:1:0712/095948.530542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095948.531059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095948.531272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095949.062841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 399, 7f0744baa8db
[1:1:0712/095949.074974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"367 0x7f0742265070 0x2642b0d1ebe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.075271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"367 0x7f0742265070 0x2642b0d1ebe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.075728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 436
[1:1:0712/095949.075977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f0742265070 0x2642b0b1e3e0 , 5:3_http://magna.51job.com/, 0, , 399 0x7f0742265070 0x2642b152cc60 
[1:1:0712/095949.076294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095949.076830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095949.077059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095949.205488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 407, 7f0744baa8db
[1:1:0712/095949.225061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"356 0x7f0742265070 0x2642b152fb60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.225392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"356 0x7f0742265070 0x2642b152fb60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.225876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 445
[1:1:0712/095949.226120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 445 0x7f0742265070 0x2642b14e30e0 , 5:3_http://magna.51job.com/, 0, , 407 0x7f0742265070 0x2642b0d60160 
[1:1:0712/095949.226433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095949.226981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095949.227196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095949.685828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 436, 7f0744baa8db
[1:1:0712/095949.697398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"399 0x7f0742265070 0x2642b152cc60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.697711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"399 0x7f0742265070 0x2642b152cc60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.698164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 467
[1:1:0712/095949.698396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 467 0x7f0742265070 0x2642b0d1ece0 , 5:3_http://magna.51job.com/, 0, , 436 0x7f0742265070 0x2642b0b1e3e0 
[1:1:0712/095949.698724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095949.699243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095949.699456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095949.831277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 445, 7f0744baa8db
[1:1:0712/095949.845512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"407 0x7f0742265070 0x2642b0d60160 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.845848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"407 0x7f0742265070 0x2642b0d60160 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095949.846300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 477
[1:1:0712/095949.846552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7f0742265070 0x2642b052d0e0 , 5:3_http://magna.51job.com/, 0, , 445 0x7f0742265070 0x2642b14e30e0 
[1:1:0712/095949.846885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095949.847411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095949.847664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095950.018392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://magna.51job.com/, 370, 7f0744baa881
[1:1:0712/095950.039772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33bf74c02860","ptid":"290 0x7f0742265070 0x2642b0b16760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.040128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://magna.51job.com/","ptid":"290 0x7f0742265070 0x2642b0b16760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.040549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095950.041097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095950.041311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095950.390348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 467, 7f0744baa8db
[1:1:0712/095950.410981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"436 0x7f0742265070 0x2642b0b1e3e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.411283:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"436 0x7f0742265070 0x2642b0b1e3e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.411732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 504
[1:1:0712/095950.412004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7f0742265070 0x2642b1533660 , 5:3_http://magna.51job.com/, 0, , 467 0x7f0742265070 0x2642b0d1ece0 
[1:1:0712/095950.412330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095950.412872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095950.413105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095950.794494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 477, 7f0744baa8db
[1:1:0712/095950.807004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"445 0x7f0742265070 0x2642b14e30e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.807270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"445 0x7f0742265070 0x2642b14e30e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.807703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 530
[1:1:0712/095950.807984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7f0742265070 0x2642b13bb3e0 , 5:3_http://magna.51job.com/, 0, , 477 0x7f0742265070 0x2642b052d0e0 
[1:1:0712/095950.808302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095950.808808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095950.809047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095950.880544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 504, 7f0744baa8db
[1:1:0712/095950.903298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"467 0x7f0742265070 0x2642b0d1ece0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.903604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"467 0x7f0742265070 0x2642b0d1ece0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095950.904095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 534
[1:1:0712/095950.904325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f0742265070 0x2642b0cb17e0 , 5:3_http://magna.51job.com/, 0, , 504 0x7f0742265070 0x2642b1533660 
[1:1:0712/095950.904648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095950.905216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095950.905430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095951.353053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 530, 7f0744baa8db
[1:1:0712/095951.375724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"477 0x7f0742265070 0x2642b052d0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095951.376067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"477 0x7f0742265070 0x2642b052d0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095951.376515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 557
[1:1:0712/095951.376746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f0742265070 0x2642b1517ce0 , 5:3_http://magna.51job.com/, 0, , 530 0x7f0742265070 0x2642b13bb3e0 
[1:1:0712/095951.377080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095951.377605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095951.377825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095951.454267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 534, 7f0744baa8db
[1:1:0712/095951.477318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"504 0x7f0742265070 0x2642b1533660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095951.477626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"504 0x7f0742265070 0x2642b1533660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095951.478061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 563
[1:1:0712/095951.478288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f0742265070 0x2642b0d5fde0 , 5:3_http://magna.51job.com/, 0, , 534 0x7f0742265070 0x2642b0cb17e0 
[1:1:0712/095951.478689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095951.479225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095951.479437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.021723:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 563, 7f0744baa8db
[1:1:0712/095952.045848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"534 0x7f0742265070 0x2642b0cb17e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.046126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"534 0x7f0742265070 0x2642b0cb17e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.046529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 596
[1:1:0712/095952.046720:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f0742265070 0x2642b14eeae0 , 5:3_http://magna.51job.com/, 0, , 563 0x7f0742265070 0x2642b0d5fde0 
[1:1:0712/095952.046991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.047489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.047667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.075617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 557, 7f0744baa8db
[1:1:0712/095952.100315:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"530 0x7f0742265070 0x2642b13bb3e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.100584:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"530 0x7f0742265070 0x2642b13bb3e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.100968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 602
[1:1:0712/095952.101179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f0742265070 0x2642b14f27e0 , 5:3_http://magna.51job.com/, 0, , 557 0x7f0742265070 0x2642b1517ce0 
[1:1:0712/095952.101454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.101930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.102106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.305821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 596, 7f0744baa8db
[1:1:0712/095952.312859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"563 0x7f0742265070 0x2642b0d5fde0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.313024:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"563 0x7f0742265070 0x2642b0d5fde0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.313262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 613
[1:1:0712/095952.313376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f0742265070 0x2642b1527460 , 5:3_http://magna.51job.com/, 0, , 596 0x7f0742265070 0x2642b14eeae0 
[1:1:0712/095952.313511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.313776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.313878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.352826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 602, 7f0744baa8db
[1:1:0712/095952.359738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"557 0x7f0742265070 0x2642b1517ce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.359904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"557 0x7f0742265070 0x2642b1517ce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.360098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 620
[1:1:0712/095952.360205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f0742265070 0x2642b0b02c60 , 5:3_http://magna.51job.com/, 0, , 602 0x7f0742265070 0x2642b14f27e0 
[1:1:0712/095952.360420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.360682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.360782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.513921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 613, 7f0744baa8db
[1:1:0712/095952.541236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"596 0x7f0742265070 0x2642b14eeae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.541528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"596 0x7f0742265070 0x2642b14eeae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.541949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 628
[1:1:0712/095952.542163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7f0742265070 0x2642b0b1e1e0 , 5:3_http://magna.51job.com/, 0, , 613 0x7f0742265070 0x2642b1527460 
[1:1:0712/095952.542464:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.542939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.543120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.681451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 628, 7f0744baa8db
[1:1:0712/095952.689218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"613 0x7f0742265070 0x2642b1527460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.689413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"613 0x7f0742265070 0x2642b1527460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.689629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 630
[1:1:0712/095952.689738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7f0742265070 0x2642b0afa5e0 , 5:3_http://magna.51job.com/, 0, , 628 0x7f0742265070 0x2642b0b1e1e0 
[1:1:0712/095952.689883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.690168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.690274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.836808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 620, 7f0744baa8db
[1:1:0712/095952.861662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"602 0x7f0742265070 0x2642b14f27e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.861869:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"602 0x7f0742265070 0x2642b14f27e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.862102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 633
[1:1:0712/095952.862215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f0742265070 0x2642b0b169e0 , 5:3_http://magna.51job.com/, 0, , 620 0x7f0742265070 0x2642b0b02c60 
[1:1:0712/095952.862379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.862679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.862797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095952.943671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 630, 7f0744baa8db
[1:1:0712/095952.965643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"628 0x7f0742265070 0x2642b0b1e1e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.965886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"628 0x7f0742265070 0x2642b0b1e1e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095952.966145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 639
[1:1:0712/095952.966264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f0742265070 0x2642b14f5360 , 5:3_http://magna.51job.com/, 0, , 630 0x7f0742265070 0x2642b0afa5e0 
[1:1:0712/095952.966473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095952.966775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095952.966881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.188994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 639, 7f0744baa8db
[1:1:0712/095953.210189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"630 0x7f0742265070 0x2642b0afa5e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.210403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"630 0x7f0742265070 0x2642b0afa5e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.210669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 645
[1:1:0712/095953.210780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f0742265070 0x2642b0b16b60 , 5:3_http://magna.51job.com/, 0, , 639 0x7f0742265070 0x2642b14f5360 
[1:1:0712/095953.210927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.211211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.211314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.315582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 633, 7f0744baa8db
[1:1:0712/095953.326174:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"620 0x7f0742265070 0x2642b0b02c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.326369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"620 0x7f0742265070 0x2642b0b02c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.326658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 649
[1:1:0712/095953.326808:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f0742265070 0x2642b0cc6360 , 5:3_http://magna.51job.com/, 0, , 633 0x7f0742265070 0x2642b0b169e0 
[1:1:0712/095953.326962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.327253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.327359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.449206:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 645, 7f0744baa8db
[1:1:0712/095953.476151:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"639 0x7f0742265070 0x2642b14f5360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.476434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"639 0x7f0742265070 0x2642b14f5360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.476899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 653
[1:1:0712/095953.477092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7f0742265070 0x2642b2163660 , 5:3_http://magna.51job.com/, 0, , 645 0x7f0742265070 0x2642b0b16b60 
[1:1:0712/095953.477364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.477885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.478064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.750362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 653, 7f0744baa8db
[1:1:0712/095953.783688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"645 0x7f0742265070 0x2642b0b16b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.784059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"645 0x7f0742265070 0x2642b0b16b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.784540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 662
[1:1:0712/095953.784831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f0742265070 0x2642b0cba960 , 5:3_http://magna.51job.com/, 0, , 653 0x7f0742265070 0x2642b2163660 
[1:1:0712/095953.785143:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.785757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.785978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.923612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 649, 7f0744baa8db
[1:1:0712/095953.939648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"633 0x7f0742265070 0x2642b0b169e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.939824:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"633 0x7f0742265070 0x2642b0b169e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.940035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 668
[1:1:0712/095953.940147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f0742265070 0x2642b14ee360 , 5:3_http://magna.51job.com/, 0, , 649 0x7f0742265070 0x2642b0cc6360 
[1:1:0712/095953.940315:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.940635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.940745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095953.959617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 662, 7f0744baa8db
[1:1:0712/095953.969154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"653 0x7f0742265070 0x2642b2163660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.969338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"653 0x7f0742265070 0x2642b2163660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095953.969561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 670
[1:1:0712/095953.969704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 670 0x7f0742265070 0x2642b0d1e160 , 5:3_http://magna.51job.com/, 0, , 662 0x7f0742265070 0x2642b0cba960 
[1:1:0712/095953.969859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095953.970135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095953.970240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095954.200789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 670, 7f0744baa8db
[1:1:0712/095954.234604:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"662 0x7f0742265070 0x2642b0cba960 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.234944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"662 0x7f0742265070 0x2642b0cba960 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.235406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 678
[1:1:0712/095954.235640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f0742265070 0x2642b151b0e0 , 5:3_http://magna.51job.com/, 0, , 670 0x7f0742265070 0x2642b0d1e160 
[1:1:0712/095954.235975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095954.236555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095954.236817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095954.335338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 668, 7f0744baa8db
[1:1:0712/095954.366997:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"649 0x7f0742265070 0x2642b0cc6360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.367345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"649 0x7f0742265070 0x2642b0cc6360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.367857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 684
[1:1:0712/095954.368109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f0742265070 0x2642b216eae0 , 5:3_http://magna.51job.com/, 0, , 668 0x7f0742265070 0x2642b14ee360 
[1:1:0712/095954.368421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095954.369043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095954.369267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095954.449746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 678, 7f0744baa8db
[1:1:0712/095954.457790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"670 0x7f0742265070 0x2642b0d1e160 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.457927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"670 0x7f0742265070 0x2642b0d1e160 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.458113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 689
[1:1:0712/095954.458221:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f0742265070 0x2642b217bf60 , 5:3_http://magna.51job.com/, 0, , 678 0x7f0742265070 0x2642b151b0e0 
[1:1:0712/095954.458367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095954.458622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095954.458754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095954.694130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 689, 7f0744baa8db
[1:1:0712/095954.702769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"678 0x7f0742265070 0x2642b151b0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.702956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"678 0x7f0742265070 0x2642b151b0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.703194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 701
[1:1:0712/095954.703308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f0742265070 0x2642b058af60 , 5:3_http://magna.51job.com/, 0, , 689 0x7f0742265070 0x2642b217bf60 
[1:1:0712/095954.703450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095954.703722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095954.703956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095954.837365:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 684, 7f0744baa8db
[1:1:0712/095954.863685:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"668 0x7f0742265070 0x2642b14ee360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.864053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"668 0x7f0742265070 0x2642b14ee360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095954.864530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 710
[1:1:0712/095954.864774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 710 0x7f0742265070 0x2642b14f4760 , 5:3_http://magna.51job.com/, 0, , 684 0x7f0742265070 0x2642b216eae0 
[1:1:0712/095954.865107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095954.865703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095954.865944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.014949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 701, 7f0744baa8db
[1:1:0712/095955.041303:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"689 0x7f0742265070 0x2642b217bf60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.041474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"689 0x7f0742265070 0x2642b217bf60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.041675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 718
[1:1:0712/095955.041782:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7f0742265070 0x2642b0cb19e0 , 5:3_http://magna.51job.com/, 0, , 701 0x7f0742265070 0x2642b058af60 
[1:1:0712/095955.041949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.042226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.042337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.198765:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 718, 7f0744baa8db
[1:1:0712/095955.207080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7f0742265070 0x2642b058af60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.207219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7f0742265070 0x2642b058af60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.207415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 724
[1:1:0712/095955.207518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 724 0x7f0742265070 0x2642b21969e0 , 5:3_http://magna.51job.com/, 0, , 718 0x7f0742265070 0x2642b0cb19e0 
[1:1:0712/095955.207654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.208043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.208243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.348989:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 710, 7f0744baa8db
[1:1:0712/095955.385313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"684 0x7f0742265070 0x2642b216eae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.385607:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"684 0x7f0742265070 0x2642b216eae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.386017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 730
[1:1:0712/095955.386212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f0742265070 0x2642b20e6260 , 5:3_http://magna.51job.com/, 0, , 710 0x7f0742265070 0x2642b14f4760 
[1:1:0712/095955.386466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.386964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.387142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.484555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 724, 7f0744baa8db
[1:1:0712/095955.514859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"718 0x7f0742265070 0x2642b0cb19e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.515145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"718 0x7f0742265070 0x2642b0cb19e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.515552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 735
[1:1:0712/095955.515759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f0742265070 0x2642b14ee560 , 5:3_http://magna.51job.com/, 0, , 724 0x7f0742265070 0x2642b21969e0 
[1:1:0712/095955.516066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.516550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.516761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.697423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 735, 7f0744baa8db
[1:1:0712/095955.711596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"724 0x7f0742265070 0x2642b21969e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.711815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"724 0x7f0742265070 0x2642b21969e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.712126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 740
[1:1:0712/095955.712285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7f0742265070 0x2642b216eae0 , 5:3_http://magna.51job.com/, 0, , 735 0x7f0742265070 0x2642b14ee560 
[1:1:0712/095955.712476:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.712843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.713007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.822571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 730, 7f0744baa8db
[1:1:0712/095955.853024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"710 0x7f0742265070 0x2642b14f4760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.853312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"710 0x7f0742265070 0x2642b14f4760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.853698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 744
[1:1:0712/095955.853887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7f0742265070 0x2642b09817e0 , 5:3_http://magna.51job.com/, 0, , 730 0x7f0742265070 0x2642b20e6260 
[1:1:0712/095955.854156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.854643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.854816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095955.963808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 740, 7f0744baa8db
[1:1:0712/095955.983068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"735 0x7f0742265070 0x2642b14ee560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.983323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"735 0x7f0742265070 0x2642b14ee560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095955.983627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 749
[1:1:0712/095955.983785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7f0742265070 0x2642b13bbf60 , 5:3_http://magna.51job.com/, 0, , 740 0x7f0742265070 0x2642b216eae0 
[1:1:0712/095955.984012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095955.984477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095955.984627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095956.278020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 749, 7f0744baa8db
[1:1:0712/095956.289100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"740 0x7f0742265070 0x2642b216eae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.289284:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"740 0x7f0742265070 0x2642b216eae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.289508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 757
[1:1:0712/095956.289629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f0742265070 0x2642b0b83560 , 5:3_http://magna.51job.com/, 0, , 749 0x7f0742265070 0x2642b13bbf60 
[1:1:0712/095956.289777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095956.290067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095956.290219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095956.309971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 744, 7f0744baa8db
[1:1:0712/095956.318414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"730 0x7f0742265070 0x2642b20e6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.318541:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"730 0x7f0742265070 0x2642b20e6260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.318722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 759
[1:1:0712/095956.318828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7f0742265070 0x2642b21a58e0 , 5:3_http://magna.51job.com/, 0, , 744 0x7f0742265070 0x2642b09817e0 
[1:1:0712/095956.318965:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095956.319234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095956.319338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095956.487436:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://magna.51job.com/"
[1:1:0712/095956.488080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/095956.488315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095956.488692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://magna.51job.com/"
[1:1:0712/095956.947656:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 757, 7f0744baa8db
[1:1:0712/095956.980425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"749 0x7f0742265070 0x2642b13bbf60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.980672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"749 0x7f0742265070 0x2642b13bbf60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095956.981052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 784
[1:1:0712/095956.981241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f0742265070 0x2642b14ea060 , 5:3_http://magna.51job.com/, 0, , 757 0x7f0742265070 0x2642b0b83560 
[1:1:0712/095956.981546:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095956.982022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095956.982197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.191397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 759, 7f0744baa8db
[1:1:0712/095957.231227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"744 0x7f0742265070 0x2642b09817e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.231604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"744 0x7f0742265070 0x2642b09817e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.232089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 788
[1:1:0712/095957.232402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7f0742265070 0x2642b0ca7ae0 , 5:3_http://magna.51job.com/, 0, , 759 0x7f0742265070 0x2642b21a58e0 
[1:1:0712/095957.232782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.233407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.233627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.360947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 784, 7f0744baa8db
[1:1:0712/095957.400996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"757 0x7f0742265070 0x2642b0b83560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.401314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"757 0x7f0742265070 0x2642b0b83560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.401795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 790
[1:1:0712/095957.402028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7f0742265070 0x2642b0d1d360 , 5:3_http://magna.51job.com/, 0, , 784 0x7f0742265070 0x2642b14ea060 
[1:1:0712/095957.402391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.402979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.403194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.405284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 788, 7f0744baa8db
[1:1:0712/095957.445265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"759 0x7f0742265070 0x2642b21a58e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.445568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"759 0x7f0742265070 0x2642b21a58e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.446017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 791
[1:1:0712/095957.446246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7f0742265070 0x2642b14e6760 , 5:3_http://magna.51job.com/, 0, , 788 0x7f0742265070 0x2642b0ca7ae0 
[1:1:0712/095957.446554:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.447094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.447304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.491819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 790, 7f0744baa8db
[1:1:0712/095957.532041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"784 0x7f0742265070 0x2642b14ea060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.532350:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"784 0x7f0742265070 0x2642b14ea060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.532895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 794
[1:1:0712/095957.533131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f0742265070 0x2642b14f4ae0 , 5:3_http://magna.51job.com/, 0, , 790 0x7f0742265070 0x2642b0d1d360 
[1:1:0712/095957.533487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.534067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.534288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.724937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 794, 7f0744baa8db
[1:1:0712/095957.757789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"790 0x7f0742265070 0x2642b0d1d360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.758155:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"790 0x7f0742265070 0x2642b0d1d360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.758676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 796
[1:1:0712/095957.758890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7f0742265070 0x2642b1529ee0 , 5:3_http://magna.51job.com/, 0, , 794 0x7f0742265070 0x2642b14f4ae0 
[1:1:0712/095957.759168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.759678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.759858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.849532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 791, 7f0744baa8db
[1:1:0712/095957.886975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"788 0x7f0742265070 0x2642b0ca7ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.887301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"788 0x7f0742265070 0x2642b0ca7ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.887809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 798
[1:1:0712/095957.888057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7f0742265070 0x2642b2184560 , 5:3_http://magna.51job.com/, 0, , 791 0x7f0742265070 0x2642b14e6760 
[1:1:0712/095957.888369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.889014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.889239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095957.961794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 796, 7f0744baa8db
[1:1:0712/095957.971658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"794 0x7f0742265070 0x2642b14f4ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.971828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"794 0x7f0742265070 0x2642b14f4ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095957.972030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 800
[1:1:0712/095957.972151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f0742265070 0x2642b098bae0 , 5:3_http://magna.51job.com/, 0, , 796 0x7f0742265070 0x2642b1529ee0 
[1:1:0712/095957.972301:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095957.972594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095957.972706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.202771:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 800, 7f0744baa8db
[1:1:0712/095958.223239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"796 0x7f0742265070 0x2642b1529ee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.223397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"796 0x7f0742265070 0x2642b1529ee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.223619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 802
[1:1:0712/095958.223741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f0742265070 0x2642b2163f60 , 5:3_http://magna.51job.com/, 0, , 800 0x7f0742265070 0x2642b098bae0 
[1:1:0712/095958.223885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.224172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.224284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.346181:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 798, 7f0744baa8db
[1:1:0712/095958.381848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"791 0x7f0742265070 0x2642b14e6760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.382098:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"791 0x7f0742265070 0x2642b14e6760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.382485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 804
[1:1:0712/095958.382718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f0742265070 0x2642b151b060 , 5:3_http://magna.51job.com/, 0, , 798 0x7f0742265070 0x2642b2184560 
[1:1:0712/095958.382980:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.383505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.383708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.444199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 802, 7f0744baa8db
[1:1:0712/095958.454140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"800 0x7f0742265070 0x2642b098bae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.454278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"800 0x7f0742265070 0x2642b098bae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.454471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 807
[1:1:0712/095958.454580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f0742265070 0x2642b098b060 , 5:3_http://magna.51job.com/, 0, , 802 0x7f0742265070 0x2642b2163f60 
[1:1:0712/095958.454777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.455042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.455152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.715281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 807, 7f0744baa8db
[1:1:0712/095958.749593:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"802 0x7f0742265070 0x2642b2163f60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.749856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"802 0x7f0742265070 0x2642b2163f60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.750245:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 809
[1:1:0712/095958.750442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f0742265070 0x2642b2111660 , 5:3_http://magna.51job.com/, 0, , 807 0x7f0742265070 0x2642b098b060 
[1:1:0712/095958.750714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.751219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.751406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.823234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 804, 7f0744baa8db
[1:1:0712/095958.836375:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"798 0x7f0742265070 0x2642b2184560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.836637:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"798 0x7f0742265070 0x2642b2184560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.837054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 811
[1:1:0712/095958.837277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f0742265070 0x2642b14f2fe0 , 5:3_http://magna.51job.com/, 0, , 804 0x7f0742265070 0x2642b151b060 
[1:1:0712/095958.837545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.838056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.838274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095958.957592:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 809, 7f0744baa8db
[1:1:0712/095958.990175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"807 0x7f0742265070 0x2642b098b060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.990412:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"807 0x7f0742265070 0x2642b098b060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095958.990803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 813
[1:1:0712/095958.990998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7f0742265070 0x2642b14e7a60 , 5:3_http://magna.51job.com/, 0, , 809 0x7f0742265070 0x2642b2111660 
[1:1:0712/095958.991274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095958.991804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095958.991984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.208064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 813, 7f0744baa8db
[1:1:0712/095959.242815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"809 0x7f0742265070 0x2642b2111660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.243096:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"809 0x7f0742265070 0x2642b2111660 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.243495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 815
[1:1:0712/095959.243696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f0742265070 0x2642b1528ce0 , 5:3_http://magna.51job.com/, 0, , 813 0x7f0742265070 0x2642b14e7a60 
[1:1:0712/095959.244024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.244541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.244728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.355873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 811, 7f0744baa8db
[1:1:0712/095959.386330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"804 0x7f0742265070 0x2642b151b060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.386616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"804 0x7f0742265070 0x2642b151b060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.387040:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 817
[1:1:0712/095959.387244:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7f0742265070 0x2642b0ca78e0 , 5:3_http://magna.51job.com/, 0, , 811 0x7f0742265070 0x2642b14f2fe0 
[1:1:0712/095959.387506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.388046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.388236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.459107:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 815, 7f0744baa8db
[1:1:0712/095959.491895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"813 0x7f0742265070 0x2642b14e7a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.492126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"813 0x7f0742265070 0x2642b14e7a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.492490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 819
[1:1:0712/095959.492683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 819 0x7f0742265070 0x2642b21a5e60 , 5:3_http://magna.51job.com/, 0, , 815 0x7f0742265070 0x2642b1528ce0 
[1:1:0712/095959.492977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.493445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.493618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.718171:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 819, 7f0744baa8db
[1:1:0712/095959.755749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"815 0x7f0742265070 0x2642b1528ce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.756017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"815 0x7f0742265070 0x2642b1528ce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.756406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 821
[1:1:0712/095959.756596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f0742265070 0x2642b14f20e0 , 5:3_http://magna.51job.com/, 0, , 819 0x7f0742265070 0x2642b21a5e60 
[1:1:0712/095959.756839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.757336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.757522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.826850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 817, 7f0744baa8db
[1:1:0712/095959.839967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"811 0x7f0742265070 0x2642b14f2fe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.840089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"811 0x7f0742265070 0x2642b14f2fe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.840271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 823
[1:1:0712/095959.840374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7f0742265070 0x2642b0d18860 , 5:3_http://magna.51job.com/, 0, , 817 0x7f0742265070 0x2642b0ca78e0 
[1:1:0712/095959.840506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.840766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.840868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/095959.967730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 821, 7f0744baa8db
[1:1:0712/095959.998880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"819 0x7f0742265070 0x2642b21a5e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.999055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"819 0x7f0742265070 0x2642b21a5e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/095959.999268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 825
[1:1:0712/095959.999377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7f0742265070 0x2642b151eb60 , 5:3_http://magna.51job.com/, 0, , 821 0x7f0742265070 0x2642b14f20e0 
[1:1:0712/095959.999534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/095959.999807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/095959.999912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.206211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 825, 7f0744baa8db
[1:1:0712/100000.239700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"821 0x7f0742265070 0x2642b14f20e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.239945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"821 0x7f0742265070 0x2642b14f20e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.240364:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 827
[1:1:0712/100000.240569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f0742265070 0x2642b0d18a60 , 5:3_http://magna.51job.com/, 0, , 825 0x7f0742265070 0x2642b151eb60 
[1:1:0712/100000.240817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.241321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.241498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.367276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 823, 7f0744baa8db
[1:1:0712/100000.402578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"817 0x7f0742265070 0x2642b0ca78e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.402836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"817 0x7f0742265070 0x2642b0ca78e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.403256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 829
[1:1:0712/100000.403460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f0742265070 0x2642b0a783e0 , 5:3_http://magna.51job.com/, 0, , 823 0x7f0742265070 0x2642b0d18860 
[1:1:0712/100000.403719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.404264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.404454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.459442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 827, 7f0744baa8db
[1:1:0712/100000.496578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"825 0x7f0742265070 0x2642b151eb60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.496851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"825 0x7f0742265070 0x2642b151eb60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.498513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 831
[1:1:0712/100000.498765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f0742265070 0x2642b0b152e0 , 5:3_http://magna.51job.com/, 0, , 827 0x7f0742265070 0x2642b0d18a60 
[1:1:0712/100000.499166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.499850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.500182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.690583:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 831, 7f0744baa8db
[1:1:0712/100000.723961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"827 0x7f0742265070 0x2642b0d18a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.724279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"827 0x7f0742265070 0x2642b0d18a60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.724680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 833
[1:1:0712/100000.724903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f0742265070 0x2642b226e460 , 5:3_http://magna.51job.com/, 0, , 831 0x7f0742265070 0x2642b0b152e0 
[1:1:0712/100000.725202:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.725706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.725913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.856112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 829, 7f0744baa8db
[1:1:0712/100000.887656:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"823 0x7f0742265070 0x2642b0d18860 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.887952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"823 0x7f0742265070 0x2642b0d18860 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.888440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 835
[1:1:0712/100000.888671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f0742265070 0x2642b151ed60 , 5:3_http://magna.51job.com/, 0, , 829 0x7f0742265070 0x2642b0a783e0 
[1:1:0712/100000.889030:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.889610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.889932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100000.962574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 833, 7f0744baa8db
[1:1:0712/100000.996230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"831 0x7f0742265070 0x2642b0b152e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.996498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"831 0x7f0742265070 0x2642b0b152e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100000.996904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 837
[1:1:0712/100000.997165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f0742265070 0x2642b1533b60 , 5:3_http://magna.51job.com/, 0, , 833 0x7f0742265070 0x2642b226e460 
[1:1:0712/100000.997488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100000.998042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100000.998300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.210213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 837, 7f0744baa8db
[1:1:0712/100001.247690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7f0742265070 0x2642b226e460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.248036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7f0742265070 0x2642b226e460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.249657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 839
[1:1:0712/100001.249883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 839 0x7f0742265070 0x2642b0b02de0 , 5:3_http://magna.51job.com/, 0, , 837 0x7f0742265070 0x2642b1533b60 
[1:1:0712/100001.250187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.250714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.250943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.363477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 835, 7f0744baa8db
[1:1:0712/100001.394669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"829 0x7f0742265070 0x2642b0a783e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.395100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"829 0x7f0742265070 0x2642b0a783e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.395826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 841
[1:1:0712/100001.396175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f0742265070 0x2642b14e7960 , 5:3_http://magna.51job.com/, 0, , 835 0x7f0742265070 0x2642b151ed60 
[1:1:0712/100001.396644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.397571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.397883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.460088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 839, 7f0744baa8db
[1:1:0712/100001.493932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"837 0x7f0742265070 0x2642b1533b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.494210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"837 0x7f0742265070 0x2642b1533b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.494615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 843
[1:1:0712/100001.494837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f0742265070 0x2642b14eb8e0 , 5:3_http://magna.51job.com/, 0, , 839 0x7f0742265070 0x2642b0b02de0 
[1:1:0712/100001.495144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.495654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.495885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.722698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 843, 7f0744baa8db
[1:1:0712/100001.756633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"839 0x7f0742265070 0x2642b0b02de0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.756870:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"839 0x7f0742265070 0x2642b0b02de0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.757239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 845
[1:1:0712/100001.757450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f0742265070 0x2642b0aecfe0 , 5:3_http://magna.51job.com/, 0, , 843 0x7f0742265070 0x2642b14eb8e0 
[1:1:0712/100001.757698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.758167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.758342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.824134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 841, 7f0744baa8db
[1:1:0712/100001.834096:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"835 0x7f0742265070 0x2642b151ed60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.834226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"835 0x7f0742265070 0x2642b151ed60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.834455:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 847
[1:1:0712/100001.834576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7f0742265070 0x2642b0976fe0 , 5:3_http://magna.51job.com/, 0, , 841 0x7f0742265070 0x2642b14e7960 
[1:1:0712/100001.834714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.834995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.835108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100001.942602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 845, 7f0744baa8db
[1:1:0712/100001.952620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"843 0x7f0742265070 0x2642b14eb8e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.952753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"843 0x7f0742265070 0x2642b14eb8e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100001.952942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 849
[1:1:0712/100001.953049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f0742265070 0x2642b2274c60 , 5:3_http://magna.51job.com/, 0, , 845 0x7f0742265070 0x2642b0aecfe0 
[1:1:0712/100001.953191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100001.953490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100001.953599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.229551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 849, 7f0744baa8db
[1:1:0712/100002.266039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"845 0x7f0742265070 0x2642b0aecfe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.266333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"845 0x7f0742265070 0x2642b0aecfe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.266762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 852
[1:1:0712/100002.266967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f0742265070 0x2642b152df60 , 5:3_http://magna.51job.com/, 0, , 849 0x7f0742265070 0x2642b2274c60 
[1:1:0712/100002.267229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.267752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.267938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.358935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 847, 7f0744baa8db
[1:1:0712/100002.395570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"841 0x7f0742265070 0x2642b14e7960 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.395821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"841 0x7f0742265070 0x2642b14e7960 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.396197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 854
[1:1:0712/100002.396399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 854 0x7f0742265070 0x2642b2267460 , 5:3_http://magna.51job.com/, 0, , 847 0x7f0742265070 0x2642b0976fe0 
[1:1:0712/100002.396681:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.397156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.397332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.458286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 852, 7f0744baa8db
[1:1:0712/100002.492341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"849 0x7f0742265070 0x2642b2274c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.492607:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"849 0x7f0742265070 0x2642b2274c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.492981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 856
[1:1:0712/100002.493168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 856 0x7f0742265070 0x2642b2184360 , 5:3_http://magna.51job.com/, 0, , 852 0x7f0742265070 0x2642b152df60 
[1:1:0712/100002.493439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.493918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.494093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.693799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 856, 7f0744baa8db
[1:1:0712/100002.704329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"852 0x7f0742265070 0x2642b152df60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.704459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"852 0x7f0742265070 0x2642b152df60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.704690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 858
[1:1:0712/100002.704818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f0742265070 0x2642b226e0e0 , 5:3_http://magna.51job.com/, 0, , 856 0x7f0742265070 0x2642b2184360 
[1:1:0712/100002.704961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.705241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.705351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.865602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 854, 7f0744baa8db
[1:1:0712/100002.901908:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"847 0x7f0742265070 0x2642b0976fe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.902153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"847 0x7f0742265070 0x2642b0976fe0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.902535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 860
[1:1:0712/100002.902755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f0742265070 0x2642b0a827e0 , 5:3_http://magna.51job.com/, 0, , 854 0x7f0742265070 0x2642b2267460 
[1:1:0712/100002.903011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.903493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.903701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100002.958164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 858, 7f0744baa8db
[1:1:0712/100002.994492:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"856 0x7f0742265070 0x2642b2184360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.994753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"856 0x7f0742265070 0x2642b2184360 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100002.995141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 862
[1:1:0712/100002.995337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f0742265070 0x2642b0a75e60 , 5:3_http://magna.51job.com/, 0, , 858 0x7f0742265070 0x2642b226e0e0 
[1:1:0712/100002.995621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100002.996130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100002.996315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100003.216136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 862, 7f0744baa8db
[1:1:0712/100003.256006:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"858 0x7f0742265070 0x2642b226e0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.256368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"858 0x7f0742265070 0x2642b226e0e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.256897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 864
[1:1:0712/100003.257165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f0742265070 0x2642b0d1a860 , 5:3_http://magna.51job.com/, 0, , 862 0x7f0742265070 0x2642b0a75e60 
[1:1:0712/100003.257507:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100003.258154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100003.258389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100003.336536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 860, 7f0744baa8db
[1:1:0712/100003.346937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"854 0x7f0742265070 0x2642b2267460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.347067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"854 0x7f0742265070 0x2642b2267460 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.347254:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 866
[1:1:0712/100003.347364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 866 0x7f0742265070 0x2642b221cce0 , 5:3_http://magna.51job.com/, 0, , 860 0x7f0742265070 0x2642b0a827e0 
[1:1:0712/100003.347500:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100003.347808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100003.347921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100003.472202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 864, 7f0744baa8db
[1:1:0712/100003.508913:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"862 0x7f0742265070 0x2642b0a75e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.509165:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"862 0x7f0742265070 0x2642b0a75e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.509551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 868
[1:1:0712/100003.509748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f0742265070 0x2642b0d1aee0 , 5:3_http://magna.51job.com/, 0, , 864 0x7f0742265070 0x2642b0d1a860 
[1:1:0712/100003.510058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100003.510552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100003.510734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100003.711160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 868, 7f0744baa8db
[1:1:0712/100003.748039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"864 0x7f0742265070 0x2642b0d1a860 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.748299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"864 0x7f0742265070 0x2642b0d1a860 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.748684:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 870
[1:1:0712/100003.748940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f0742265070 0x2642b20e68e0 , 5:3_http://magna.51job.com/, 0, , 868 0x7f0742265070 0x2642b0d1aee0 
[1:1:0712/100003.749248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100003.749807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100003.750031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100003.858220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 866, 7f0744baa8db
[1:1:0712/100003.895089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"860 0x7f0742265070 0x2642b0a827e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.895336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"860 0x7f0742265070 0x2642b0a827e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100003.895722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 872
[1:1:0712/100003.895958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7f0742265070 0x2642b14f6c60 , 5:3_http://magna.51job.com/, 0, , 866 0x7f0742265070 0x2642b221cce0 
[1:1:0712/100003.896217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100003.896707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100003.896912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100004.005395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/100004.005660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100004.016997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 870, 7f0744baa8db
[1:1:0712/100004.055869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"868 0x7f0742265070 0x2642b0d1aee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.056239:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"868 0x7f0742265070 0x2642b0d1aee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.056673:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 880
[1:1:0712/100004.056902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f0742265070 0x2642b14e6ee0 , 5:3_http://magna.51job.com/, 0, , 870 0x7f0742265070 0x2642b20e68e0 
[1:1:0712/100004.057334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100004.058067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100004.058332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100004.219487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 880, 7f0744baa8db
[1:1:0712/100004.229801:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"870 0x7f0742265070 0x2642b20e68e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.229975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"870 0x7f0742265070 0x2642b20e68e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.230184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 883
[1:1:0712/100004.230292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7f0742265070 0x2642b14ea2e0 , 5:3_http://magna.51job.com/, 0, , 880 0x7f0742265070 0x2642b14e6ee0 
[1:1:0712/100004.230425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100004.230689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100004.230793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100004.345534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 872, 7f0744baa8db
[1:1:0712/100004.358204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"866 0x7f0742265070 0x2642b221cce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.358446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"866 0x7f0742265070 0x2642b221cce0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.358749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 885
[1:1:0712/100004.358907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7f0742265070 0x2642b225e1e0 , 5:3_http://magna.51job.com/, 0, , 872 0x7f0742265070 0x2642b14f6c60 
[1:1:0712/100004.359154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100004.359576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100004.359727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[120524:120524:0712/100004.571851:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/100004.643009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 883, 7f0744baa8db
[1:1:0712/100004.691546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"880 0x7f0742265070 0x2642b14e6ee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.691893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"880 0x7f0742265070 0x2642b14e6ee0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100004.692466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 899
[1:1:0712/100004.692730:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 899 0x7f0742265070 0x2642b225e060 , 5:3_http://magna.51job.com/, 0, , 883 0x7f0742265070 0x2642b14ea2e0 
[1:1:0712/100004.693189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100004.693794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100004.694049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[3:3:0712/100004.767327:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/100005.685504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 885, 7f0744baa8db
[1:1:0712/100005.723413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"872 0x7f0742265070 0x2642b14f6c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100005.723761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"872 0x7f0742265070 0x2642b14f6c60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100005.724231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 935
[1:1:0712/100005.724501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7f0742265070 0x2642b2223260 , 5:3_http://magna.51job.com/, 0, , 885 0x7f0742265070 0x2642b225e1e0 
[1:1:0712/100005.724825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100005.725375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100005.725592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100006.108046:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 899, 7f0744baa8db
[1:1:0712/100006.147807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"883 0x7f0742265070 0x2642b14ea2e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100006.148117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"883 0x7f0742265070 0x2642b14ea2e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100006.148595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 958
[1:1:0712/100006.148830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7f0742265070 0x2642b21f3b60 , 5:3_http://magna.51job.com/, 0, , 899 0x7f0742265070 0x2642b225e060 
[1:1:0712/100006.149151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100006.149715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100006.149928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100007.145979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 935, 7f0744baa8db
[1:1:0712/100007.184975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"885 0x7f0742265070 0x2642b225e1e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100007.185323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"885 0x7f0742265070 0x2642b225e1e0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100007.185842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 969
[1:1:0712/100007.186124:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7f0742265070 0x2642b2651560 , 5:3_http://magna.51job.com/, 0, , 935 0x7f0742265070 0x2642b2223260 
[1:1:0712/100007.186484:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100007.187493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100007.188003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100007.665544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 958, 7f0744baa8db
[1:1:0712/100007.704932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"899 0x7f0742265070 0x2642b225e060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100007.705232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"899 0x7f0742265070 0x2642b225e060 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100007.705666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 977
[1:1:0712/100007.705933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f0742265070 0x2642b2683e60 , 5:3_http://magna.51job.com/, 0, , 958 0x7f0742265070 0x2642b21f3b60 
[1:1:0712/100007.706253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100007.706781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100007.706995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100008.131614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 969, 7f0744baa8db
[1:1:0712/100008.171552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"935 0x7f0742265070 0x2642b2223260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.171887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"935 0x7f0742265070 0x2642b2223260 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.172335:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 986
[1:1:0712/100008.172566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f0742265070 0x2642b26c1ae0 , 5:3_http://magna.51job.com/, 0, , 969 0x7f0742265070 0x2642b2651560 
[1:1:0712/100008.172898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100008.173424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100008.173636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/100008.574728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 977, 7f0744baa8db
[1:1:0712/100008.628912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"958 0x7f0742265070 0x2642b21f3b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.629330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"958 0x7f0742265070 0x2642b21f3b60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.629825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 998
[1:1:0712/100008.630073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7f0742265070 0x2642b23d9760 , 5:3_http://magna.51job.com/, 0, , 977 0x7f0742265070 0x2642b2683e60 
[1:1:0712/100008.630397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100008.630926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100008.631195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100008.691421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 986, 7f0744baa8db
[1:1:0712/100008.732669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"969 0x7f0742265070 0x2642b2651560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.733034:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"969 0x7f0742265070 0x2642b2651560 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100008.733514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1001
[1:1:0712/100008.733755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7f0742265070 0x2642b23dfc60 , 5:3_http://magna.51job.com/, 0, , 986 0x7f0742265070 0x2642b26c1ae0 
[1:1:0712/100008.734163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100008.734695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100008.734922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100009.159639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 998, 7f0744baa8db
[1:1:0712/100009.176262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"977 0x7f0742265070 0x2642b2683e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.176604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"977 0x7f0742265070 0x2642b2683e60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.177041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1011
[1:1:0712/100009.177307:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1011 0x7f0742265070 0x2642b26b9760 , 5:3_http://magna.51job.com/, 0, , 998 0x7f0742265070 0x2642b23d9760 
[1:1:0712/100009.177695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100009.178243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100009.178457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100009.223023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1001, 7f0744baa8db
[1:1:0712/100009.264798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"986 0x7f0742265070 0x2642b26c1ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.265197:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"986 0x7f0742265070 0x2642b26c1ae0 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.265652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1012
[1:1:0712/100009.265886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7f0742265070 0x2642b09f3260 , 5:3_http://magna.51job.com/, 0, , 1001 0x7f0742265070 0x2642b23dfc60 
[1:1:0712/100009.266291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100009.266835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100009.267047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100009.571622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1012, 7f0744baa8db
[1:1:0712/100009.615006:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1001 0x7f0742265070 0x2642b23dfc60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.615422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1001 0x7f0742265070 0x2642b23dfc60 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.615877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1021
[1:1:0712/100009.616176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7f0742265070 0x2642b226f560 , 5:3_http://magna.51job.com/, 0, , 1012 0x7f0742265070 0x2642b09f3260 
[1:1:0712/100009.616570:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100009.617094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100009.617331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
[1:1:0712/100009.620721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1011, 7f0744baa8db
[1:1:0712/100009.665629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"998 0x7f0742265070 0x2642b23d9760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.665996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"998 0x7f0742265070 0x2642b23d9760 ","rf":"5:3_http://magna.51job.com/"}
[1:1:0712/100009.666461:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://magna.51job.com/, 1023
[1:1:0712/100009.666709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f0742265070 0x2642b26a1360 , 5:3_http://magna.51job.com/, 0, , 1011 0x7f0742265070 0x2642b26b9760 
[1:1:0712/100009.667095:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://magna.51job.com/"
[1:1:0712/100009.667641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://magna.51job.com/, 33bf74c02860, , e, (){return c.apply(a,arguments)}
[1:1:0712/100009.667891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://magna.51job.com/", "magna.51job.com", 3, 1, , , 0
