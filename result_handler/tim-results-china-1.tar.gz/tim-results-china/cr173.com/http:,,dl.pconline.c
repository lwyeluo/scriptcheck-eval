[0712/220602.639001:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220602.639343:INFO:switcher_clone.cc(787)] backtrace rip is 7f8828349891
[0712/220603.716889:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220603.717209:INFO:switcher_clone.cc(787)] backtrace rip is 7f6e2bc38891
[1:1:0712/220603.728746:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/220603.729008:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/220603.735271:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/220605.273859:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220605.274162:INFO:switcher_clone.cc(787)] backtrace rip is 7f1e01622891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9696:9696:0712/220605.481145:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9696
[9701:9701:0712/220605.481576:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9701
[9658:9658:0712/220605.557813:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f241a7f2-5f49-415f-9b59-5a86058b6773
[9658:9658:0712/220606.200051:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9658:9694:0712/220606.201377:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/220606.201859:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220606.202151:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220606.202816:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220606.202977:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/220606.205800:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x17aad0ee, 1
[1:1:0712/220606.206107:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd6f9b8d, 0
[1:1:0712/220606.206280:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1606076f, 3
[1:1:0712/220606.206440:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x80f523f, 2
[1:1:0712/220606.206686:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8dffffff9b6f0d ffffffeeffffffd0ffffffaa17 3f520f08 6f070616 , 10104, 4
[1:1:0712/220606.207654:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9658:9694:0712/220606.207929:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��o�Ъ?RoY�6
[1:1:0712/220606.207874:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29e730a0, 3
[1:1:0712/220606.208095:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29ffe080, 2
[9658:9694:0712/220606.208099:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��o�Ъ?Ro�Y�6
[1:1:0712/220606.208252:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e13cc1d20, -2
[9658:9694:0712/220606.208557:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9658:9694:0712/220606.208776:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9711, 4, 8d9b6f0d eed0aa17 3f520f08 6f070616 
[1:1:0712/220606.228513:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220606.229405:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 80f523f
[1:1:0712/220606.230385:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 80f523f
[1:1:0712/220606.232085:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 80f523f
[1:1:0712/220606.233679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.233872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.234089:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.234277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.234965:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 80f523f
[1:1:0712/220606.235307:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220606.235444:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220606.241638:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 80f523f
[1:1:0712/220606.242086:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 80f523f
[1:1:0712/220606.242988:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 80f523f
[1:1:0712/220606.245110:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.245313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.245507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.245744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 80f523f
[1:1:0712/220606.247051:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 80f523f
[1:1:0712/220606.247423:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220606.247558:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220606.255742:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220606.256209:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220606.256363:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffedb832108, 0x7ffedb832088)
[1:1:0712/220606.272661:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220606.278643:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9658:9658:0712/220606.869963:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9658:9658:0712/220606.870405:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9658:9670:0712/220606.876190:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9658:9658:0712/220606.876225:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9658:9670:0712/220606.876283:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[9658:9658:0712/220606.876311:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9658:9658:0712/220606.876453:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9711, 4
[1:7:0712/220606.878427:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9658:9682:0712/220606.948203:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/220607.016013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2c9dab42b220
[1:1:0712/220607.016274:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/220607.347509:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9658:9658:0712/220608.854901:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9658:9658:0712/220608.855013:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220608.908264:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220608.912149:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220609.896346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220609.896645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220609.926519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220609.926841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220610.004731:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220610.353309:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220610.353521:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220610.799759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220610.807761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220610.807972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220610.841918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220610.852694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220610.852997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220610.865008:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[9658:9658:0712/220610.867959:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220610.871207:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c9dab429e20
[1:1:0712/220610.871536:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9658:9658:0712/220610.873928:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9658:9658:0712/220610.918594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9658:9658:0712/220610.918748:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220610.938982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220611.836541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f6e1589c2e0 0x2c9dab6fcfe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220611.837833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/220611.838353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220611.839802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9658:9658:0712/220611.908763:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220611.909933:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c9dab42a820
[1:1:0712/220611.910077:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9658:9658:0712/220611.912272:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/220611.916455:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220611.916564:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9658:9658:0712/220611.929337:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9658:9658:0712/220611.944949:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9658:9658:0712/220611.947750:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9658:9670:0712/220611.954140:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9658:9670:0712/220611.954244:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9658:9658:0712/220611.954439:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9658:9658:0712/220611.954517:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9658:9658:0712/220611.954652:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9711, 4
[1:7:0712/220611.963568:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220612.593084:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[9658:9658:0712/220612.740223:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9658:9694:0712/220612.740736:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/220612.740967:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220612.741156:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220612.741558:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220612.741696:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/220612.744666:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x294fca3, 1
[1:1:0712/220612.745004:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12cec415, 0
[1:1:0712/220612.745151:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1b1fdf57, 3
[1:1:0712/220612.745292:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x9589192, 2
[1:1:0712/220612.745480:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 15ffffffc4ffffffce12 ffffffa3fffffffcffffff9402 ffffff92ffffff915809 57ffffffdf1f1b , 10104, 5
[1:1:0712/220612.746463:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9658:9694:0712/220612.746681:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�������X	W�	�6
[9658:9694:0712/220612.746767:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �������X	W��o	�6
[1:1:0712/220612.746677:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29e730a0, 3
[1:1:0712/220612.746870:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29ffe080, 2
[9658:9694:0712/220612.747048:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9755, 5, 15c4ce12 a3fc9402 92915809 57df1f1b 
[1:1:0712/220612.747053:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e13cc1d20, -2
[1:1:0712/220612.767763:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220612.768062:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9589192
[1:1:0712/220612.768409:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9589192
[1:1:0712/220612.769022:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9589192
[1:1:0712/220612.770429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.770636:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.770811:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.770985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.771636:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9589192
[1:1:0712/220612.771915:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220612.772054:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220612.777715:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9589192
[1:1:0712/220612.778060:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9589192
[1:1:0712/220612.778820:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9589192
[1:1:0712/220612.780820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.781027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.781216:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.781412:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9589192
[1:1:0712/220612.782653:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9589192
[1:1:0712/220612.783009:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220612.783139:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220612.790824:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220612.791310:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220612.791485:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffedb832108, 0x7ffedb832088)
[1:1:0712/220612.804813:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220612.809185:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/220612.921488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f6e1589c2e0 0x2c9dab4a5de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220612.922525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/220612.922750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220612.923552:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220613.036274:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c9dab3f8220
[1:1:0712/220613.036525:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9658:9658:0712/220613.091698:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9658:9658:0712/220613.091826:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/220613.119809:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220613.612298:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220614.201935:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220614.202200:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9658:9658:0712/220614.404288:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9658:9658:0712/220614.448989:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[9658:9694:0712/220614.449354:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/220614.449566:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220614.449743:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220614.450094:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220614.450226:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/220614.453044:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x354bda24, 1
[1:1:0712/220614.453365:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24311515, 0
[1:1:0712/220614.453586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xaa08991, 3
[1:1:0712/220614.453767:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30dc50e9, 2
[1:1:0712/220614.453940:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 15153124 24ffffffda4b35 ffffffe950ffffffdc30 ffffff91ffffff89ffffffa00a , 10104, 6
[1:1:0712/220614.454902:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9658:9694:0712/220614.455274:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING1$$�K5�P�0���
��6
[9658:9694:0712/220614.455340:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 1$$�K5�P�0���
8���6
[1:1:0712/220614.455269:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29e730a0, 3
[1:1:0712/220614.455443:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e29ffe080, 2
[1:1:0712/220614.455615:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6e13cc1d20, -2
[9658:9694:0712/220614.455650:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9770, 6, 15153124 24da4b35 e950dc30 9189a00a 
[9658:9658:0712/220614.463076:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9658:9670:0712/220614.467384:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[9658:9670:0712/220614.467434:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[9658:9658:0712/220614.470005:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://dl.pconline.com.cn/
[9658:9658:0712/220614.470043:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://dl.pconline.com.cn/, https://dl.pconline.com.cn/, 1
[9658:9658:0712/220614.470100:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://dl.pconline.com.cn/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 05:06:14 GMT Server: Tengine Content-Type: text/html Content-Length: 85825 Expires: Sat, 13 Jul 2019 05:19:10 GMT Cache-Control: max-age=900 Content-Encoding: gzip X-Cache-Lookup: HIT from pconline-dl-ngx1-vm238-25.pconline.ctc:80 Via: 1.0 pconline-dl-ngx1-vm238-25.pconline.ctc:80 (squid/2.6.STABLE20) X-Via: 1.1 chkuan144:6 (Cdn Cache Server V2.0) Connection: keep-alive  ,0, 6
[1:1:0712/220614.470088:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220614.470284:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30dc50e9
[1:1:0712/220614.470478:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30dc50e9
[1:1:0712/220614.470710:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30dc50e9
[1:1:0712/220614.471214:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.471318:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.471410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.471498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.471723:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30dc50e9
[1:1:0712/220614.471849:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220614.471987:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220614.473422:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30dc50e9
[1:1:0712/220614.473578:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30dc50e9
[1:1:0712/220614.473843:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30dc50e9
[1:1:0712/220614.474534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.474651:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.474751:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.474843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30dc50e9
[1:1:0712/220614.476123:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30dc50e9
[1:1:0712/220614.476485:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6e2bc387ba
[1:1:0712/220614.476613:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6e2bc2fdef, 7f6e2bc3877a, 7f6e2bc3a0cf
[1:1:0712/220614.484340:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220614.484820:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220614.484995:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffedb832108, 0x7ffedb832088)
[1:1:0712/220614.498146:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220614.502134:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/220614.502801:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/220614.570814:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220614.752067:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c9dab41a220
[1:1:0712/220614.752329:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/220614.762294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220614.766715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c41ec94e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/220614.767030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220614.774671:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220614.791108:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://dl.pconline.com.cn/
[9658:9658:0712/220615.035985:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://dl.pconline.com.cn/, https://dl.pconline.com.cn/, 1
[1:1:0712/220615.035949:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9658:9658:0712/220615.036141:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://dl.pconline.com.cn/, https://dl.pconline.com.cn
[1:1:0712/220615.086103:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220615.102728:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220615.162147:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220615.162379:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220615.182313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 107 0x7f6e13974070 0x2c9dab3def60 , "https://dl.pconline.com.cn/"
[1:1:0712/220615.186157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
var deviceJump=(function(){var u=navigator.userAgent.toLowerCase();var d=window.location.href.toLow
[1:1:0712/220615.186381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220615.188620:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220615.200513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 107 0x7f6e13974070 0x2c9dab3def60 , "https://dl.pconline.com.cn/"
[1:1:0712/220615.299470:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220615.469810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220615.470566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c41ec821f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/220615.470780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220615.673841:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220616.041460:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220616.062233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6e13974070 0x2c9dab5cd060 , "https://dl.pconline.com.cn/"
[1:1:0712/220616.063129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
var ad_2016_download_v3 = 1;

[1:1:0712/220616.063392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220616.068822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6e13974070 0x2c9dab5cd060 , "https://dl.pconline.com.cn/"
[1:1:0712/220616.160688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6e13974070 0x2c9dab5cd060 , "https://dl.pconline.com.cn/"
[1:1:0712/220616.162750:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 999, 0x271d951229c8, 0x2c9dab2931a0
[1:1:0712/220616.162955:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 999
[1:1:0712/220616.163507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 206
[1:1:0712/220616.163747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 206 0x7f6e13974070 0x2c9dab582960 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 161 0x7f6e13974070 0x2c9dab5cd060 
[1:1:0712/220616.166680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6e13974070 0x2c9dab5cd060 , "https://dl.pconline.com.cn/"
[1:1:0712/220616.192010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6e13974070 0x2c9dab5cd060 , "https://dl.pconline.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/220616.320999:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.255999, 137, 1
[1:1:0712/220616.321144:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220616.566904:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220616.567353:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220616.567757:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220616.568199:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220616.568573:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220616.745982:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220617.328858:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220617.329003:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220617.329799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f6e13974070 0x2c9dab680de0 , "https://dl.pconline.com.cn/"
[1:1:0712/220617.330301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
/*登录url*/
window.ajaxLoginUrl = location.protocol+"//www1.pconline.com.cn/common/js/pconline.lo
[1:1:0712/220617.330420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220617.345781:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0167341, 339, 1
[1:1:0712/220617.345908:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220617.648529:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220617.953904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 206, 7f6e162b9881
[1:1:0712/220617.961287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"161 0x7f6e13974070 0x2c9dab5cd060 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220617.961435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"161 0x7f6e13974070 0x2c9dab5cd060 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220617.961578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220617.961890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , (){var js=document.createElement("script"); js.src="//ivy.pconline.com.cn/adpuba/show?id=pc.xz.shouy
[1:1:0712/220617.961996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220618.161704:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220618.161934:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220618.162671:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f6e13974070 0x2c9dab62e9e0 , "https://dl.pconline.com.cn/"
[1:1:0712/220618.164462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
(function(){
function isContain(a, b) {
try {
return a.contains ? a != b && a.contains(b) : !!(a.co
[1:1:0712/220618.164644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220618.458250:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.296267, 1693, 1
[1:1:0712/220618.458534:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220620.589127:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220620.589349:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220620.590135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f6e13974070 0x2c9dab8791e0 , "https://dl.pconline.com.cn/"
[1:1:0712/220620.591059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
if(!window.preloadShow4) document.write('<script src="//ivy.pconline.com.cn/show4?opt=1&id=pc.xz.sh
[1:1:0712/220620.591449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220620.659673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f6e1589c2e0 0x2c9dab878960 , "https://dl.pconline.com.cn/"
[1:1:0712/220620.685441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , (function(){var h={},mt={},c={id:"d38ac9ad074d9e00764ad1daa6023a31",dm:["dl.pconline.com.cn"],js:"to
[1:1:0712/220620.685671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220620.722183:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293190
[1:1:0712/220620.722380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220620.722748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 457
[1:1:0712/220620.722934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 457 0x7f6e13974070 0x2c9dab614460 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 386 0x7f6e1589c2e0 0x2c9dab878960 
[9658:9658:0712/220647.134400:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/220647.144497:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/220648.664375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 600000
[1:1:0712/220648.664859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 518
[1:1:0712/220648.665103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f6e13974070 0x2c9daba3d0e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 386 0x7f6e1589c2e0 0x2c9dab878960 
[1:1:0712/220648.665980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 5000
[1:1:0712/220648.666454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 519
[1:1:0712/220648.666699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7f6e13974070 0x2c9dabe43960 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 386 0x7f6e1589c2e0 0x2c9dab878960 
[1:1:0712/220648.714523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7f6e1589c2e0 0x2c9dab8683e0 , "https://dl.pconline.com.cn/"
[1:1:0712/220648.715754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , ;(function(){
    window.__ivyTest15Count__=[];window.__tid__='pc.xz.shouye.test15.';
    var srcs
[1:1:0712/220648.715985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220650.039419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.040150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , ivymap=window.ivymap||{};
ivymap["pc.xz.shouye.zu.tl1."] = function(){document_write(unescape('<scri
[1:1:0712/220650.040308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220650.042003:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.045420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.052363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.055541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.057968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.061261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453, "https://dl.pconline.com.cn/"
[1:1:0712/220650.064087:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220650.216487:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.175138, 770, 1
[1:1:0712/220650.216675:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220650.351198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/220650.351410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220651.855493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 457, 7f6e162b9881
[1:1:0712/220651.881615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"386 0x7f6e1589c2e0 0x2c9dab878960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220651.882075:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"386 0x7f6e1589c2e0 0x2c9dab878960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220651.882498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220651.883067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220651.883315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220651.884380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220651.884626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220651.885094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 649
[1:1:0712/220651.885400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f6e13974070 0x2c9dac0c6b60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 457 0x7f6e13974070 0x2c9dab614460 
[1:1:0712/220653.825688:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220653.825938:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220653.826713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f6e13974070 0x2c9dac049760 , "https://dl.pconline.com.cn/"
[1:1:0712/220653.827526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , showIvyViaJs("pc.xz.shouye.zu.tl2.")
[1:1:0712/220653.827748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220654.079502:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.253489, 1852, 1
[1:1:0712/220654.079785:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220654.177560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , document.readyState
[1:1:0712/220654.177863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220656.154195:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/220656.156126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , g.onload, (){g.onload=u;g=window[d]=u;a&&a(b)}
[1:1:0712/220656.156392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220656.348839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 649, 7f6e162b9881
[1:1:0712/220656.370386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"457 0x7f6e13974070 0x2c9dab614460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220656.370749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"457 0x7f6e13974070 0x2c9dab614460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220656.371212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220656.371825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220656.372080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220656.372818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220656.373015:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220656.373411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 850
[1:1:0712/220656.373652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f6e13974070 0x2c9dac2903e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 649 0x7f6e13974070 0x2c9dac0c6b60 
[1:1:0712/220657.065131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 519, 7f6e162b98db
[1:1:0712/220657.088169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"386 0x7f6e1589c2e0 0x2c9dab878960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220657.088515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"386 0x7f6e1589c2e0 0x2c9dab878960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220657.088979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 863
[1:1:0712/220657.089204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7f6e13974070 0x2c9dac0c1260 , 6:3_https://dl.pconline.com.cn/, 0, , 519 0x7f6e13974070 0x2c9dabe43960 
[1:1:0712/220657.089506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220657.090050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/220657.090288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220701.215258:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220701.215521:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220701.216397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 815 0x7f6e13974070 0x2c9dabe402e0 , "https://dl.pconline.com.cn/"
[1:1:0712/220701.217278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , showIvyViaJs("pc.xz.shouye.zu.tl3.")
[1:1:0712/220701.217527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220701.378214:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.162616, 1818, 1
[1:1:0712/220701.378512:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220701.420973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , document.readyState
[1:1:0712/220701.421252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220703.129074:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 850, 7f6e162b9881
[1:1:0712/220703.168960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"649 0x7f6e13974070 0x2c9dac0c6b60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220703.169327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"649 0x7f6e13974070 0x2c9dac0c6b60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220703.169714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220703.170360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220703.170577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220703.171275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220703.171466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220703.171905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 919
[1:1:0712/220703.172126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f6e13974070 0x2c9dabc176e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 850 0x7f6e13974070 0x2c9dac2903e0 
[1:1:0712/220703.718248:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 863, 7f6e162b98db
[1:1:0712/220703.761422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"519 0x7f6e13974070 0x2c9dabe43960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220703.761755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"519 0x7f6e13974070 0x2c9dabe43960 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220703.762177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 932
[1:1:0712/220703.762546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f6e13974070 0x2c9dac2903e0 , 6:3_https://dl.pconline.com.cn/, 0, , 863 0x7f6e13974070 0x2c9dac0c1260 
[1:1:0712/220703.762882:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220703.763457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/220703.763669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220705.054142:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220705.054425:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220705.059828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 905 0x7f6e13974070 0x2c9dac049660 , "https://dl.pconline.com.cn/"
[1:1:0712/220705.125206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , /* jQuery v1.6.3 http://jquery.com/ | http://jquery.org/license */
(function(a,b){function cu(a){ret
[1:1:0712/220705.125511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220705.357620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 905 0x7f6e13974070 0x2c9dac049660 , "https://dl.pconline.com.cn/"
		remove user.10_2195aeee -> 0
		remove user.11_258a15d4 -> 0
		remove user.12_1bf168b -> 0
		remove user.13_28982a3f -> 0
		remove user.14_8d6f473d -> 0
		remove user.10_8b7edf7e -> 0
[1:1:0712/220707.641555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x271d951229c8, 0x2c9dab293248
[1:1:0712/220707.641822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/220707.642190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 950
[1:1:0712/220707.642464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7f6e13974070 0x2c9dad193ee0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 905 0x7f6e13974070 0x2c9dac049660 
[1:1:0712/220707.647372:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/220707.647725:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 951
[1:1:0712/220707.647913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f6e13974070 0x2c9dac047a60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 905 0x7f6e13974070 0x2c9dac049660 
[1:1:0712/220707.763280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 3500
[1:1:0712/220707.763686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 953
[1:1:0712/220707.763880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f6e13974070 0x2c9dac9a3be0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 905 0x7f6e13974070 0x2c9dac049660 
[1:1:0712/220707.834693:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.78004, 0, 0
[1:1:0712/220707.834839:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220707.867887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , document.readyState
[1:1:0712/220707.868032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220708.072598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 919, 7f6e162b9881
[1:1:0712/220708.087573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"850 0x7f6e13974070 0x2c9dac2903e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220708.087741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"850 0x7f6e13974070 0x2c9dac2903e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220708.087935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220708.088235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220708.088337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220708.088672:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220708.088770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220708.088933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 990
[1:1:0712/220708.089039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7f6e13974070 0x2c9daba42160 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 919 0x7f6e13974070 0x2c9dabc176e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[9658:9658:0712/220709.086929:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/220709.266582:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220709.266836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220709.283496:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0165381, 85, 1
[1:1:0712/220709.283744:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220709.912994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 950, 7f6e162b9881
[1:1:0712/220709.957767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220709.958164:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220709.958542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220709.959088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , cp, (){cn=b}
[1:1:0712/220709.959298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220709.960833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 951, 7f6e162b98db
[1:1:0712/220710.006637:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220710.006977:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220710.007407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1029
[1:1:0712/220710.007632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f6e13974070 0x2c9dac0ecae0 , 6:3_https://dl.pconline.com.cn/, 0, , 951 0x7f6e13974070 0x2c9dac047a60 
[1:1:0712/220710.008028:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220710.008608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/220710.008834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220710.010340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220710.010539:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/220710.010909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1030
[1:1:0712/220710.011159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f6e13974070 0x2c9dab5af060 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 951 0x7f6e13974070 0x2c9dac047a60 
[1:1:0712/220710.468250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , document.readyState
[1:1:0712/220710.468541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220711.669878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 990, 7f6e162b9881
[1:1:0712/220711.716832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"919 0x7f6e13974070 0x2c9dabc176e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220711.717190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"919 0x7f6e13974070 0x2c9dabc176e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220711.717616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220711.718191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220711.718431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220711.719156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220711.719372:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220711.719752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1093
[1:1:0712/220711.719993:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f6e13974070 0x2c9dab93bfe0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 990 0x7f6e13974070 0x2c9daba42160 
[1:1:0712/220711.721698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 932, 7f6e162b98db
[1:1:0712/220711.768307:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"863 0x7f6e13974070 0x2c9dac0c1260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220711.768629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"863 0x7f6e13974070 0x2c9dac0c1260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220711.769073:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1095
[1:1:0712/220711.769295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7f6e13974070 0x2c9dad3c9d60 , 6:3_https://dl.pconline.com.cn/, 0, , 932 0x7f6e13974070 0x2c9dac2903e0 
[1:1:0712/220711.769669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220711.770192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/220711.770428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220713.443223:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220713.443496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/220713.444447:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.446157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , 
(function(){
var thisurl = window.location.href;
if (thisurl.match('//dl.pconline.com.cn/') || this
[1:1:0712/220713.446404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220713.455057:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.463202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.470407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.490598:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x301e6de990c0
[1:1:0712/220713.498526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.499829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x271d951229c8, 0x2c9dab2931a0
[1:1:0712/220713.500051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 250
[1:1:0712/220713.500417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1130
[1:1:0712/220713.500653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7f6e13974070 0x2c9dad33fbe0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1027 0x7f6e13974070 0x2c9dab872a60 
[1:1:0712/220713.503152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.506947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.509910:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.523167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.525827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.528513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.531634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1027 0x7f6e13974070 0x2c9dab872a60 , "https://dl.pconline.com.cn/"
[1:1:0712/220713.539550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/220713.540791:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/220713.542251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/220713.829985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1030, 7f6e162b9881
[1:1:0712/220713.867253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"951 0x7f6e13974070 0x2c9dac047a60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220713.867602:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"951 0x7f6e13974070 0x2c9dac047a60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220713.867985:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220713.868536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , cp, (){cn=b}
[1:1:0712/220713.868747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220714.242382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , document.readyState
[1:1:0712/220714.242665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220715.267723:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 953, 7f6e162b98db
[1:1:0712/220715.323070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220715.323429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"905 0x7f6e13974070 0x2c9dac049660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220715.323859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1166
[1:1:0712/220715.324084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7f6e13974070 0x2c9dad4a84e0 , 6:3_https://dl.pconline.com.cn/, 0, , 953 0x7f6e13974070 0x2c9dac9a3be0 
[1:1:0712/220715.324460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220715.325014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/220715.325221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220715.363159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220715.363420:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/220715.363796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1167
[1:1:0712/220715.364024:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f6e13974070 0x2c9dad549be0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 953 0x7f6e13974070 0x2c9dac9a3be0 
[1:1:0712/220715.366693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/220715.367063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1168
[1:1:0712/220715.367292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7f6e13974070 0x2c9dac15fae0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 953 0x7f6e13974070 0x2c9dac9a3be0 
[1:1:0712/220716.096283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1093, 7f6e162b9881
[1:1:0712/220716.122559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2511f8382860","ptid":"990 0x7f6e13974070 0x2c9daba42160 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220716.122832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"990 0x7f6e13974070 0x2c9daba42160 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/220716.123240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/220716.124061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 2511f8382860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/220716.124250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/220716.124926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x271d951229c8, 0x2c9dab293150
[1:1:0712/220716.125083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/220716.125403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1182
[1:1:0712/220716.125588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1182 0x7f6e13974070 0x2c9dab41ef60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1093 0x7f6e13974070 0x2c9dab93bfe0 
