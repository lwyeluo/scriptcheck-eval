[0711/223012.758361:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223012.758817:INFO:switcher_clone.cc(787)] backtrace rip is 7f05078c8891
[0711/223013.735690:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223013.736110:INFO:switcher_clone.cc(787)] backtrace rip is 7f82a27f4891
[1:1:0711/223013.747713:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/223013.748082:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/223013.753562:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[27421:27421:0711/223014.797470:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3fec357a-6303-43c4-bae2-cadb2ae82ac3
[27421:27421:0711/223015.256917:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[27421:27451:0711/223015.257744:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/223015.257987:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223015.258240:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223015.258815:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223015.258958:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/223015.261825:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34030b7a, 1
[1:1:0711/223015.262185:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x34f61bff, 0
[1:1:0711/223015.262390:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x360251e8, 3
[1:1:0711/223015.262581:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xce96477, 2
[1:1:0711/223015.262804:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffff1bfffffff634 7a0b0334 7764ffffffe90c ffffffe8510236 , 10104, 4
[1:1:0711/223015.263792:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27421:27451:0711/223015.264114:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��4z4wd��Q6���
[27421:27451:0711/223015.264186:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��4z4wd��Q6�����
[1:1:0711/223015.264083:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f82a0a2f0a0, 3
[1:1:0711/223015.264352:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f82a0bba080, 2
[27421:27451:0711/223015.264477:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[27421:27451:0711/223015.264542:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27466, 4, ff1bf634 7a0b0334 7764e90c e8510236 
[1:1:0711/223015.264510:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f828a87dd20, -2
[0711/223015.269844:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223015.270143:INFO:switcher_clone.cc(787)] backtrace rip is 7f3bee4b6891
[1:1:0711/223015.283271:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223015.284334:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ce96477
[1:1:0711/223015.285498:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ce96477
[1:1:0711/223015.287438:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ce96477
[1:1:0711/223015.289297:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.289528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.289749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.289970:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.290756:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ce96477
[1:1:0711/223015.291179:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f82a27f47ba
[1:1:0711/223015.291348:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f82a27ebdef, 7f82a27f477a, 7f82a27f60cf
[1:1:0711/223015.297895:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ce96477
[1:1:0711/223015.298265:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ce96477
[1:1:0711/223015.298976:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ce96477
[1:1:0711/223015.300984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.301195:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.301416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.301596:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ce96477
[1:1:0711/223015.302855:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ce96477
[1:1:0711/223015.303227:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f82a27f47ba
[1:1:0711/223015.303368:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f82a27ebdef, 7f82a27f477a, 7f82a27f60cf
[1:1:0711/223015.311094:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223015.311631:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223015.311774:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff12c551a8, 0x7fff12c55128)
[1:1:0711/223015.329818:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223015.335580:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[27453:27453:0711/223015.471021:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27453
[27480:27480:0711/223015.471465:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27480
[27421:27421:0711/223015.868187:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27421:27421:0711/223015.868656:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27421:27421:0711/223015.877453:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[27421:27421:0711/223015.877546:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[27421:27421:0711/223015.877684:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,27466, 4
[27421:27432:0711/223015.878667:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[27421:27432:0711/223015.878744:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/223015.904138:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[27421:27445:0711/223015.968529:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/223016.016443:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x37c4a8dbf220
[1:1:0711/223016.016713:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/223016.305874:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[27421:27421:0711/223018.202070:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[27421:27421:0711/223018.202194:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223018.246489:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223018.250008:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223019.400638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223019.400830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223019.409710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223019.409825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223019.478555:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223019.844146:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223019.844394:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223020.226412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223020.234474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223020.234721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223020.266701:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223020.269825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223020.269964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223020.273958:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[27421:27421:0711/223020.278753:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/223020.280446:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37c4a8dbde20
[1:1:0711/223020.280638:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[27421:27421:0711/223020.285504:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[27421:27421:0711/223020.321373:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[27421:27421:0711/223020.321531:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223020.327190:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223021.031731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f828c4582e0 0x37c4a903d0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223021.033411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/223021.033679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223021.035235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[27421:27421:0711/223021.107277:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/223021.108182:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37c4a8dbe820
[1:1:0711/223021.108370:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[27421:27421:0711/223021.117291:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/223021.128028:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/223021.128338:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[27421:27421:0711/223021.135580:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[27421:27421:0711/223021.143020:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27421:27421:0711/223021.144019:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27421:27432:0711/223021.150121:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[27421:27432:0711/223021.150210:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[27421:27421:0711/223021.150366:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[27421:27421:0711/223021.150442:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[27421:27421:0711/223021.150577:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,27466, 4
[1:7:0711/223021.153666:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223021.772570:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/223022.085882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f828c4582e0 0x37c4a918d360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223022.086901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/223022.087131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223022.087897:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223022.255116:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[27421:27421:0711/223022.255383:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[27421:27421:0711/223022.255495:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/223022.578966:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[27421:27421:0711/223022.780548:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[27421:27451:0711/223022.780980:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/223022.781180:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223022.781427:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223022.781886:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223022.782030:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/223022.785383:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa0071cf, 1
[1:1:0711/223022.785758:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1900104b, 0
[1:1:0711/223022.785907:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1906195e, 3
[1:1:0711/223022.786048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3844917c, 2
[1:1:0711/223022.786189:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4b100019 ffffffcf71000a 7cffffff914438 5e190619 , 10104, 5
[1:1:0711/223022.787165:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27421:27451:0711/223022.787412:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGK
[27421:27451:0711/223022.787509:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is K
[1:1:0711/223022.787400:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f82a0a2f0a0, 3
[1:1:0711/223022.787598:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f82a0bba080, 2
[27421:27451:0711/223022.787830:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27519, 5, 4b100019 cf71000a 7c914438 5e190619 
[1:1:0711/223022.787809:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f828a87dd20, -2
[1:1:0711/223022.798708:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223022.798913:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3844917c
[1:1:0711/223022.799107:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3844917c
[1:1:0711/223022.799364:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3844917c
[1:1:0711/223022.799817:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.799918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.800013:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.800104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.800342:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3844917c
[1:1:0711/223022.800627:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f82a27f47ba
[1:1:0711/223022.800803:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f82a27ebdef, 7f82a27f477a, 7f82a27f60cf
[1:1:0711/223022.807822:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3844917c
[1:1:0711/223022.808311:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3844917c
[1:1:0711/223022.809247:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3844917c
[1:1:0711/223022.810811:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.810935:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.811046:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.811149:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3844917c
[1:1:0711/223022.811627:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3844917c
[1:1:0711/223022.811791:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f82a27f47ba
[1:1:0711/223022.811868:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f82a27ebdef, 7f82a27f477a, 7f82a27f60cf
[1:1:0711/223022.814199:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223022.814588:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223022.814685:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff12c551a8, 0x7fff12c55128)
[1:1:0711/223022.822112:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223022.826591:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/223022.978183:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223022.978439:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223022.990110:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37c4a8d8f220
[1:1:0711/223022.990364:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/223023.447092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223023.451756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 16c4bdc109f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/223023.452060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223023.459870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[27421:27421:0711/223023.580928:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27421:27421:0711/223023.586883:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27421:27432:0711/223023.613056:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[27421:27432:0711/223023.613155:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[27421:27421:0711/223023.617792:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://game.tgbus.com/
[27421:27421:0711/223023.617890:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://game.tgbus.com/, https://game.tgbus.com/game/10760, 1
[27421:27421:0711/223023.618027:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://game.tgbus.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 05:30:23 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Server: nginx/1.15.10 X-Powered-By: Express ETag: W/"dbd0-a2xCu1rgSED4e6Xvu0dezUPSk90" Content-Encoding: gzip X-Via: 1.1 shx68:5 (Cdn Cache Server V2.0), 1.1 PSgdjywtak47:9 (Cdn Cache Server V2.0), 1.1 kuan21:4 (Cdn Cache Server V2.0) Connection: keep-alive  ,27519, 5
[1:7:0711/223023.624837:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223023.660094:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://game.tgbus.com/
[27421:27421:0711/223023.744309:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://game.tgbus.com/, https://game.tgbus.com/, 1
[27421:27421:0711/223023.744438:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://game.tgbus.com/, https://game.tgbus.com
[1:1:0711/223023.772618:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223023.825207:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223023.850975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223023.851677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 16c4bdae1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/223023.851930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223023.915935:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223023.916195:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://game.tgbus.com/game/10760"
[1:1:0711/223023.986074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7f828a530070 0x37c4a8dacf60 , "https://game.tgbus.com/game/10760"
[1:1:0711/223023.986954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , 
// 移动端访问game.tgbus.com 跳转m.tgbus.com/gamelib
var isMobile = navigator.userAgent.match
[1:1:0711/223023.987077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223023.988431:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223024.151947:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.235533, 793, 1
[1:1:0711/223024.152110:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223025.221132:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223025.221605:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223025.221960:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223025.222389:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223025.222729:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223025.268949:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223025.269190:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://game.tgbus.com/game/10760"
[1:1:0711/223029.510033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7f828a530070 0x37c4a91e28e0 , "https://game.tgbus.com/game/10760"
[1:1:0711/223029.514070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , window.__INITIAL_SILO__={"gamelibHome":{"nav":{"groups":[{"label":"平台","items":[{"icon":["fab","
[1:1:0711/223029.514330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223029.584661:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223030.230816:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 , "https://game.tgbus.com/game/10760"
[1:1:0711/223030.246306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , (window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-vendors"],{"014b":function(t,e,r){
[1:1:0711/223030.246486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223030.252358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 , "https://game.tgbus.com/game/10760"
[1:1:0711/223030.256658:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 , "https://game.tgbus.com/game/10760"
[1:1:0711/223030.850190:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3131ad8c29c8, 0x37c4a8759218
[1:1:0711/223030.850441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 0
[1:1:0711/223030.850802:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 565
[1:1:0711/223030.850990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f828a530070 0x37c4a9033660 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 
[1:1:0711/223034.219608:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x3131ad8c29c8, 0x37c4a8759218
[1:1:0711/223034.219781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 120000
[1:1:0711/223034.219975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 566
[1:1:0711/223034.220137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7f828a530070 0x37c4aa25fd60 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 
[1:1:0711/223034.316707:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.06758, 0, 0
[1:1:0711/223034.316951:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223034.481645:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223034.481852:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://game.tgbus.com/game/10760"
[1:1:0711/223034.482601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f828a530070 0x37c4aa510760 , "https://game.tgbus.com/game/10760"
[1:1:0711/223034.483444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , 
(function() {
  // 没有被嵌入到iframe中
  if (top !== self) {
    var script = document.crea
[1:1:0711/223034.483617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223034.491256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f828a530070 0x37c4aa510760 , "https://game.tgbus.com/game/10760"
[1:1:0711/223034.615868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f828a530070 0x37c4aa510760 , "https://game.tgbus.com/game/10760"
[1:1:0711/223034.790062:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37c4a8e9f220
[1:1:0711/223034.790298:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/223034.799140:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/223034.799305:INFO:render_frame_impl.cc(7019)] 	 [url] = https://game.tgbus.com
[1:1:0711/223034.802541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f828a530070 0x37c4aa510760 , "https://game.tgbus.com/game/10760"
		remove user.10_3b159bf8 -> 0
		remove user.11_bfc67ecb -> 0
		remove user.12_e1e110e4 -> 0
		remove user.13_82184278 -> 0
		remove user.14_45c78a3d -> 0
[1:1:0711/223034.806866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://game.tgbus.com/game/10760"
[27421:27421:0711/223036.269934:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://game.tgbus.com/, https://game.tgbus.com/, 1
[27421:27421:0711/223036.270043:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://game.tgbus.com/, https://game.tgbus.com
[27421:27421:0711/223036.302177:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[27421:27421:0711/223036.307705:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[27421:27421:0711/223036.318761:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://game.tgbus.com/
[1:1:0711/223036.949663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 565, 7f828ce75881
[1:1:0711/223036.959515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0faa7b3c2860","ptid":"554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223036.959741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://game.tgbus.com/","ptid":"554 0x7f82a0bba080 0x37c4a8ffe9c0 1 0 0x37c4a8ffe9d8 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223036.959923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://game.tgbus.com/game/10760"
[1:1:0711/223036.960227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , (){V.devtools&&ut&&ut.emit("init",_n)}
[1:1:0711/223036.960340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223037.157657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 588 0x7f828c4582e0 0x37c4aa5b86e0 , "https://game.tgbus.com/game/10760"
[1:1:0711/223037.158581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , (window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["v-game"],{"0390":function(e,t,n){"use st
[1:1:0711/223037.158699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[3:3:0711/223037.166255:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[27421:27421:0711/223037.291819:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27421:27421:0711/223037.299835:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27421:27432:0711/223037.333233:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[27421:27432:0711/223037.333351:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[27421:27421:0711/223037.333550:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bdtj.tagtic.cn/
[27421:27421:0711/223037.333654:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A30%3A34.639Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Fgame.tgbus.com%2Fgame%2F10760&referer=&request_method=get&page_id=cca725012a81cf9e3d0eb1b14e1550ea&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false, 4
[27421:27421:0711/223037.333864:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://bdtj.tagtic.cn/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html vary:Accept-Encoding date:Fri, 12 Jul 2019 05:30:36 GMT last-modified:Fri, 14 Jun 2019 00:46:47 GMT etag:W/"5d02ee77-200" access-control-allow-methods:GET,POST,PUT,DELETE,PATCH,OPTIONS access-control-allow-credentials:true ali-swift-global-savetime:1562909436 via:cache15.l2et2-1[23,200-0,M], cache28.l2et2-1[24,0], cache1.cn518[54,200-0,M], cache8.cn518[57,0] x-cache:MISS TCP_MISS dirn:-2:-2 x-swift-savetime:Fri, 12 Jul 2019 05:30:36 GMT x-swift-cachetime:172800 timing-allow-origin:* eagleid:7cc1e21c15629094364887794e content-encoding:gzip  ,27519, 5
[1:7:0711/223037.338461:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[27421:27421:0711/223037.341468:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223037.564742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://game.tgbus.com/game/10760"
[1:1:0711/223037.848258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/223037.848567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223039.570391:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://bdtj.tagtic.cn/
[1:1:0711/223039.704791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 690 0x7f828c4582e0 0x37c4aac003e0 , "https://game.tgbus.com/game/10760"
[1:1:0711/223039.708812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , (function(){var h={},mt={},c={id:"ad6b0fd84f08dc70750c5ee6ba650172",dm:["tgbus.com"],js:"tongji.baid
[1:1:0711/223039.709042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223039.738391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3131ad8c29c8, 0x37c4a8759190
[1:1:0711/223039.738668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 100
[1:1:0711/223039.739070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 715
[1:1:0711/223039.739345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f828a530070 0x37c4aafd53e0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 690 0x7f828c4582e0 0x37c4aac003e0 
[1:1:0711/223039.932635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://game.tgbus.com/game/10760"
[1:1:0711/223039.933365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/223039.933612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223039.935104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://game.tgbus.com/game/10760"
[1:1:0711/223039.937726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://game.tgbus.com/game/10760"
[1:1:0711/223043.776145:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223054.641067:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223054.642887:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223054.643324:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223054.643767:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[27421:27421:0711/223059.287337:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223105.777792:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x3131ad8c29c8, 0x37c4a8759210
[1:1:0711/223105.778681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 120000
[1:1:0711/223105.779181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 751
[1:1:0711/223105.779457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f828a530070 0x37c4b3b4d3e0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 693
[1:1:0711/223105.785845:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x3131ad8c29c8, 0x37c4a8759210
[1:1:0711/223105.786071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 120000
[1:1:0711/223105.786466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 752
[1:1:0711/223105.786696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7f828a530070 0x37c4b4af9be0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 693
[1:1:0711/223105.792209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x3131ad8c29c8, 0x37c4a8759210
[1:1:0711/223105.792478:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 120000
[1:1:0711/223105.792857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 756
[1:1:0711/223105.793083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f828a530070 0x37c4b4af91e0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 693
[1:1:0711/223118.117262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , document.readyState
[1:1:0711/223118.117539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[27421:27421:0711/223119.091871:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn/, 4
[27421:27421:0711/223119.091976:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn
[1:1:0711/223119.097025:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223119.677472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 715, 7f828ce75881
[1:1:0711/223119.701238:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0faa7b3c2860","ptid":"690 0x7f828c4582e0 0x37c4aac003e0 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223119.701616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://game.tgbus.com/","ptid":"690 0x7f828c4582e0 0x37c4aac003e0 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223119.702073:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://game.tgbus.com/game/10760"
[1:1:0711/223119.702676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/223119.702894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223119.703766:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3131ad8c29c8, 0x37c4a8759150
[1:1:0711/223119.703998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 100
[1:1:0711/223119.704394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 823
[1:1:0711/223119.704653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7f828a530070 0x37c4aa9c1060 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 715 0x7f828a530070 0x37c4aafd53e0 
[1:1:0711/223120.415150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , document.readyState
[1:1:0711/223120.415460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[27421:27421:0711/223122.793030:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223123.736067:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223124.097287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 823, 7f828ce75881
[1:1:0711/223124.132584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0faa7b3c2860","ptid":"715 0x7f828a530070 0x37c4aafd53e0 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223124.132916:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://game.tgbus.com/","ptid":"715 0x7f828a530070 0x37c4aafd53e0 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223124.133302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://game.tgbus.com/game/10760"
[1:1:0711/223124.133868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/223124.134045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223124.134726:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3131ad8c29c8, 0x37c4a8759150
[1:1:0711/223124.134892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 100
[1:1:0711/223124.135238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 864
[1:1:0711/223124.135427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f828a530070 0x37c4b8118be0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 823 0x7f828a530070 0x37c4aa9c1060 
[1:1:0711/223124.182143:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://game.tgbus.com/game/10760"
[1:1:0711/223124.182991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/223124.183212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223124.456140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , document.readyState
[1:1:0711/223124.456414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223125.900938:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223125.901117:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A30%3A34.639Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Fgame.tgbus.com%2Fgame%2F10760&referer=&request_method=get&page_id=cca725012a81cf9e3d0eb1b14e1550ea&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/223126.275350:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 864, 7f828ce75881
[1:1:0711/223126.312606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0faa7b3c2860","ptid":"823 0x7f828a530070 0x37c4aa9c1060 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223126.312925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://game.tgbus.com/","ptid":"823 0x7f828a530070 0x37c4aa9c1060 ","rf":"5:3_https://game.tgbus.com/"}
[1:1:0711/223126.313386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://game.tgbus.com/game/10760"
[1:1:0711/223126.313934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/223126.314150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223126.314505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3131ad8c29c8, 0x37c4a8759150
[1:1:0711/223126.314612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://game.tgbus.com/game/10760", 100
[1:1:0711/223126.314792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://game.tgbus.com/, 912
[1:1:0711/223126.314904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7f828a530070 0x37c4b8dd98e0 , 5:3_https://game.tgbus.com/, 1, -5:3_https://game.tgbus.com/, 864 0x7f828a530070 0x37c4b8118be0 
[1:1:0711/223126.386036:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 870 0x7f828c4582e0 0x37c4aa7263e0 , "https://game.tgbus.com/game/10760"
[1:1:0711/223126.392512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://game.tgbus.com/, 0faa7b3c2860, , , (window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["far"],{b702:function(c,a,n){"use strict"
[1:1:0711/223126.392727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://game.tgbus.com/game/10760", "game.tgbus.com", 3, 1, , , 0
[1:1:0711/223126.494176:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://game.tgbus.com/game/10760"
