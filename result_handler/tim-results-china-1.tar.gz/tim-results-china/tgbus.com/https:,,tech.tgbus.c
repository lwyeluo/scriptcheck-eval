[0711/222601.541607:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222601.542034:INFO:switcher_clone.cc(787)] backtrace rip is 7fb2b4370891
[0711/222602.480285:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222602.480669:INFO:switcher_clone.cc(787)] backtrace rip is 7ff0b9680891
[1:1:0711/222602.492477:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/222602.492732:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/222602.498088:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26895:26895:0711/222603.589284:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/5693bfd8-1789-4573-8465-e5448ea3eed4
[0711/222603.818252:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222603.818551:INFO:switcher_clone.cc(787)] backtrace rip is 7fed2a784891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26927:26927:0711/222604.056869:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26927
[26939:26939:0711/222604.057278:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26939
[26895:26895:0711/222604.070983:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26895:26925:0711/222604.071927:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/222604.072142:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/222604.072345:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/222604.072942:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/222604.073119:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/222604.076153:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xcde5701, 1
[1:1:0711/222604.076444:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x16a7a66a, 0
[1:1:0711/222604.076617:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a5e98ec, 3
[1:1:0711/222604.076767:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15fea9ca, 2
[1:1:0711/222604.076967:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6affffffa6ffffffa716 0157ffffffde0c ffffffcaffffffa9fffffffe15 ffffffecffffff985e2a , 10104, 4
[1:1:0711/222604.077868:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26895:26925:0711/222604.078088:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGj��W�ʩ��^*�~h
[26895:26925:0711/222604.078153:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is j��W�ʩ��^*h��~h
[1:1:0711/222604.078076:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0b78bb0a0, 3
[1:1:0711/222604.078312:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0b7a46080, 2
[26895:26925:0711/222604.078417:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/222604.078454:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0a1709d20, -2
[26895:26925:0711/222604.078484:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26941, 4, 6aa6a716 0157de0c caa9fe15 ec985e2a 
[1:1:0711/222604.098147:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/222604.099198:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15fea9ca
[1:1:0711/222604.100375:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15fea9ca
[1:1:0711/222604.101494:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15fea9ca
[1:1:0711/222604.102061:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.102162:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.102249:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.102354:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.102579:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15fea9ca
[1:1:0711/222604.102719:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff0b96807ba
[1:1:0711/222604.102798:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff0b9677def, 7ff0b968077a, 7ff0b96820cf
[1:1:0711/222604.104275:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15fea9ca
[1:1:0711/222604.104437:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15fea9ca
[1:1:0711/222604.105164:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15fea9ca
[1:1:0711/222604.107654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.107888:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.108117:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.108353:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15fea9ca
[1:1:0711/222604.108996:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15fea9ca
[1:1:0711/222604.109172:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff0b96807ba
[1:1:0711/222604.109249:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff0b9677def, 7ff0b968077a, 7ff0b96820cf
[1:1:0711/222604.111465:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/222604.111766:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/222604.111859:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdc3568c48, 0x7ffdc3568bc8)
[1:1:0711/222604.126473:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/222604.133913:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26895:26918:0711/222604.690455:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/222604.690452:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xb25d316b220
[1:1:0711/222604.690681:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[26895:26895:0711/222604.721885:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222604.723274:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222604.736343:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26895:26906:0711/222604.736444:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222604.736707:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26895:26895:0711/222604.736830:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26895:26895:0711/222604.737005:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26941, 4
[1:7:0711/222604.742362:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222605.188151:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[26895:26895:0711/222606.343166:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26895:26895:0711/222606.343283:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/222606.395340:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222606.398920:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222607.697264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/222607.697682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222607.740318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/222607.740879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222607.822798:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222608.126218:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222608.126608:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222608.446145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222608.465199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/222608.465591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222608.608294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222608.614320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/222608.614723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222608.627148:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26895:26895:0711/222608.631677:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/222608.636676:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb25d3169e20
[1:1:0711/222608.637167:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26895:26895:0711/222608.640103:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26895:26895:0711/222608.707530:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26895:26895:0711/222608.707724:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/222608.760842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222609.754998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7ff0a32e42e0 0xb25d3301de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222609.756607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/222609.756853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222609.758692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26895:26895:0711/222609.823354:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/222609.825449:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xb25d316a820
[1:1:0711/222609.825631:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26895:26895:0711/222609.830066:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/222609.844322:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222609.844515:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26895:26895:0711/222609.846659:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26895:26895:0711/222609.857311:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222609.858344:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222609.864309:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26895:26906:0711/222609.864401:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222609.864537:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26895:26895:0711/222609.864615:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26895:26895:0711/222609.864752:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26941, 4
[1:7:0711/222609.867857:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222610.509078:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/222611.030409:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7ff0a32e42e0 0xb25d2fa58e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222611.031501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/222611.031775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222611.032618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26895:26895:0711/222611.175319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26895:26895:0711/222611.175473:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/222611.207052:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222611.547591:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[26895:26895:0711/222611.728288:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26895:26925:0711/222611.728830:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/222611.729076:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/222611.729406:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/222611.729937:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/222611.730145:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/222611.733772:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x128f0e42, 1
[1:1:0711/222611.734275:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26d3345e, 0
[1:1:0711/222611.734499:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1aa64d7d, 3
[1:1:0711/222611.734688:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x115d540b, 2
[1:1:0711/222611.734870:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5e34ffffffd326 420effffff8f12 0b545d11 7d4dffffffa61a , 10104, 5
[1:1:0711/222611.735974:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26895:26925:0711/222611.736313:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING^4�&B�T]}M��h
[26895:26925:0711/222611.736435:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ^4�&B�T]}M�(K�h
[26895:26925:0711/222611.736725:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26994, 5, 5e34d326 420e8f12 0b545d11 7d4da61a 
[1:1:0711/222611.736312:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0b78bb0a0, 3
[1:1:0711/222611.737248:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0b7a46080, 2
[1:1:0711/222611.737524:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff0a1709d20, -2
[1:1:0711/222611.760925:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/222611.761261:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 115d540b
[1:1:0711/222611.761665:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 115d540b
[1:1:0711/222611.762285:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 115d540b
[1:1:0711/222611.763682:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.763938:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.764146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.764388:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.765108:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 115d540b
[1:1:0711/222611.765472:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff0b96807ba
[1:1:0711/222611.765648:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff0b9677def, 7ff0b968077a, 7ff0b96820cf
[1:1:0711/222611.772625:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 115d540b
[1:1:0711/222611.773127:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 115d540b
[1:1:0711/222611.774063:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 115d540b
[1:1:0711/222611.776996:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.777277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.777552:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.777798:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 115d540b
[1:1:0711/222611.779074:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 115d540b
[1:1:0711/222611.779502:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff0b96807ba
[1:1:0711/222611.779696:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff0b9677def, 7ff0b968077a, 7ff0b96820cf
[1:1:0711/222611.782442:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/222611.782980:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/222611.783167:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdc3568c48, 0x7ffdc3568bc8)
[1:1:0711/222611.795231:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/222611.800008:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/222612.028006:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb25d314b220
[1:1:0711/222612.028345:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/222612.118303:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222612.118574:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222612.623222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222612.627841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d90a9f70640, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/222612.628159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/222612.635962:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26895:26895:0711/222612.701654:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222612.707532:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222612.735237:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26895:26906:0711/222612.735353:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222612.738019:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://tech.tgbus.com/
[26895:26895:0711/222612.738126:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tech.tgbus.com/, https://tech.tgbus.com/news/48592, 1
[26895:26895:0711/222612.738294:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://tech.tgbus.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 05:26:12 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Server: nginx/1.10.2 X-Powered-By: Express Content-Encoding: gzip X-Via: 1.1 hangkuan195:0 (Cdn Cache Server V2.0), 1.1 k39:6 (Cdn Cache Server V2.0)  ,26994, 5
[1:7:0711/222612.748772:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222612.789782:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://tech.tgbus.com/
[1:1:0711/222612.875996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222612.876773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d90a9e41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/222612.876996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222612.965850:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26895:26895:0711/222612.974436:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tech.tgbus.com/, https://tech.tgbus.com/, 1
[26895:26895:0711/222612.974523:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://tech.tgbus.com/, https://tech.tgbus.com
[1:1:0711/222613.098776:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222613.169696:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222613.169945:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tech.tgbus.com/news/48592"
[1:1:0711/222613.209331:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222613.210994:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/222613.211223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d90a9f70640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/222613.211494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/222613.324020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222613.324870:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/222613.325077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d90a9f70640, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/222613.325327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/222613.493694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.tgbus.com/news/48592"
[1:1:0711/222613.496153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , function SG_GG(){var t=new RegExp("(^|&)source=([^&]*)(&|$)","i"),e=window.location.search.substr(1)
[1:1:0711/222613.496402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222613.497852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3e8959a29c8, 0xb25d2fbe200
[1:1:0711/222613.498050:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 3000
[1:1:0711/222613.498486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 176
[1:1:0711/222613.498712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 176 0x7ff0a13bc070 0xb25d3273460 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 160
[1:1:0711/222613.785731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7ff0a13bc070 0xb25d33356e0 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222613.789048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , 
    // 不是从tgbus wap端跳转过来
    // 移动设备访问pc端
    var isMobile = navigato
[1:1:0711/222613.789320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222613.790260:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222613.903151:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0906239, 463, 1
[1:1:0711/222613.903416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/222614.400618:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222614.400894:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tech.tgbus.com/news/48592"
[1:1:0711/222614.401993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 220 0x7ff0a13bc070 0xb25d33a8d60 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222614.404505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , window.__INITIAL_STATE__={"route":{"name":"tech@/news/:newsid","path":"/news/48592","hash":"","query
[1:1:0711/222614.404740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222614.513018:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222616.219804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7ff0b7a46080 0xb25d3113060 1 0 0xb25d3113078 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.238054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , /**
 * Swiper 4.3.3
 * Most modern mobile touch slider and framework with hardware accelerated trans
[1:1:0711/222616.238353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222616.275347:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7ff0b7a46080 0xb25d3113060 1 0 0xb25d3113078 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.284028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7ff0b7a46080 0xb25d3113060 1 0 0xb25d3113078 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.466878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7ff0b7a46080 0xb25d3113060 1 0 0xb25d3113078 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.653348:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xb25d3262220
[1:1:0711/222616.653631:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/222616.665775:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222616.665993:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.tgbus.com
[1:1:0711/222616.673990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7ff0b7a46080 0xb25d3113060 1 0 0xb25d3113078 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.706266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356 0x7ff0b7a46080 0xb25d34584c0 1 0 0xb25d34584d8 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.717079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , !function(t){function e(n){if(r[n])return r[n].exports;var o=r[n]={i:n,l:!1,exports:{}};return t[n].
[1:1:0711/222616.717314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222616.984925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 176, 7ff0a3d01881
[1:1:0711/222616.996179:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"160","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222616.996569:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"160","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222616.997050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222616.997703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , (){l=!1}
[1:1:0711/222616.997947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222617.207006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7ff0a32e42e0 0xb25d3271ae0 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222617.212175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , (function(){var h={},mt={},c={id:"ad6b0fd84f08dc70750c5ee6ba650172",dm:["tgbus.com"],js:"tongji.baid
[1:1:0711/222617.212419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222617.237329:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe190
[1:1:0711/222617.237654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222617.238086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 391
[1:1:0711/222617.238321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7ff0a13bc070 0xb25d3423ce0 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 385 0x7ff0a32e42e0 0xb25d3271ae0 
[1:1:0711/222621.300785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222621.301236:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222621.302205:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222621.302585:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222621.302905:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[26895:26895:0711/222625.519992:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26895:26895:0711/222625.526534:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[26895:26895:0711/222625.537531:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.tgbus.com/
[3:3:0711/222625.568380:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[26895:26895:0711/222625.686669:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222625.692922:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222625.718669:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[26895:26906:0711/222625.718766:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222625.718942:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bdtj.tagtic.cn/
[26895:26895:0711/222625.719020:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false, 4
[26895:26895:0711/222625.719163:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://bdtj.tagtic.cn/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html vary:Accept-Encoding date:Fri, 12 Jul 2019 05:26:25 GMT last-modified:Fri, 14 Jun 2019 00:46:47 GMT etag:W/"5d02ee77-200" access-control-allow-methods:GET,POST,PUT,DELETE,PATCH,OPTIONS access-control-allow-credentials:true ali-swift-global-savetime:1562909185 via:cache10.l2et2-1[22,200-0,M], cache25.l2et2-1[23,0], cache2.cn518[54,200-0,M], cache2.cn518[56,0] x-cache:MISS TCP_MISS dirn:-2:-2 x-swift-savetime:Fri, 12 Jul 2019 05:26:25 GMT x-swift-cachetime:172800 timing-allow-origin:* eagleid:7cc1e21615629091857027824e content-encoding:gzip  ,26994, 5
[1:7:0711/222625.723686:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[26895:26895:0711/222625.725453:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/222625.959915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222625.981492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , webpackJsonp([0],Array(191).concat([function(e,t,i){"use strict";function r(e){i(499)}Object.defineP
[1:1:0711/222625.981793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222626.001706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222626.129795:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3e8959a29c8, 0xb25d2fbe308
[1:1:0711/222626.130064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 0
[1:1:0711/222626.130553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 458
[1:1:0711/222626.130781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7ff0a13bc070 0xb25d3151a60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 
[26895:26895:0711/222627.431927:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tech.tgbus.com/, https://tech.tgbus.com/, 1
[26895:26895:0711/222627.432062:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://tech.tgbus.com/, https://tech.tgbus.com
		remove user.10_53723307 -> 0
[1:1:0711/222642.222292:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222642.222812:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222642.227197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222644.892204:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222644.935308:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x12c72e94e28
[1:1:0711/222644.935651:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x12c72e94e90
[26895:26895:0711/222647.622520:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/222647.647944:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://tech.tgbus.com/news/48592"
[1:1:0711/222649.326773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/222649.327099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222650.106796:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://bdtj.tagtic.cn/
[1:1:0711/222650.339102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 391, 7ff0a3d01881
[1:1:0711/222650.361942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"385 0x7ff0a32e42e0 0xb25d3271ae0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222650.362283:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"385 0x7ff0a32e42e0 0xb25d3271ae0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222650.362756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222650.363352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222650.363614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222650.364484:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222650.364711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222650.365167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 524
[1:1:0711/222650.365413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7ff0a13bc070 0xb25dbf55e60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 391 0x7ff0a13bc070 0xb25d3423ce0 
[1:1:0711/222650.422278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://tech.tgbus.com/news/48592"
[1:1:0711/222650.423671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , n, (n){n.source===t&&"string"==typeof n.data&&0===n.data.indexOf(e)&&a(+n.data.slice(e.length))}
[1:1:0711/222650.423927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222650.888699:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 458, 7ff0a3d01881
[1:1:0711/222650.911541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222650.911953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"387 0x7ff0b7a46080 0xb25d3458a60 1 0 0xb25d3458a78 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222650.912406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222650.913025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , (){Hr.devtools&&so&&so.emit("init",Ve)}
[1:1:0711/222650.913273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222651.185427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , document.readyState
[1:1:0711/222651.185724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[26895:26895:0711/222652.053467:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn/, 4
[26895:26895:0711/222652.053581:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://bdtj.tagtic.cn/, https://bdtj.tagtic.cn
[1:1:0711/222652.054869:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222652.118890:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.119618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0711/222652.119838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.131027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 524, 7ff0a3d01881
[1:1:0711/222652.157088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"391 0x7ff0a13bc070 0xb25d3423ce0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222652.157475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"391 0x7ff0a13bc070 0xb25d3423ce0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222652.157932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.158536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222652.158754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.159460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222652.159657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222652.160103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 592
[1:1:0711/222652.160329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 592 0x7ff0a13bc070 0xb25dbf82460 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 524 0x7ff0a13bc070 0xb25dbf55e60 
[1:1:0711/222652.209791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7ff0a32e42e0 0xb25dbbaa160 , "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.211057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , STARGAMEGGCALLBACKFNV2({"PositionLocation":0,"PositionState":1,"PID":"9025","PositionType":1,"Locati
[1:1:0711/222652.211286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.238043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.481339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.482099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/222652.482331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.483792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.486544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.680927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , document.readyState
[1:1:0711/222652.681217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.715938:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.716738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/222652.717052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.717574:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.720205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.750185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.750919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/222652.751167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.751671:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.754072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.889581:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.890368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/222652.890597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222652.891130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222652.893716:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.tgbus.com/news/48592"
[1:1:0711/222653.575089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://tech.tgbus.com/news/48592"
[1:1:0711/222653.575834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , window.onresize, (){return function(){e.handleRightFixed()}()}
[1:1:0711/222653.576090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222654.028621:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222654.231706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 592, 7ff0a3d01881
[1:1:0711/222654.260306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"524 0x7ff0a13bc070 0xb25dbf55e60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222654.260721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"524 0x7ff0a13bc070 0xb25dbf55e60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222654.261130:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222654.261773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222654.261992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222654.262706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222654.262939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222654.263427:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 643
[1:1:0711/222654.263676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7ff0a13bc070 0xb25dc69c560 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 592 0x7ff0a13bc070 0xb25dbf82460 
[1:1:0711/222654.380518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , document.readyState
[1:1:0711/222654.380789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222654.677061:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222654.677217:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222654.940299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 643, 7ff0a3d01881
[1:1:0711/222654.956776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"592 0x7ff0a13bc070 0xb25dbf82460 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222654.956964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"592 0x7ff0a13bc070 0xb25dbf82460 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222654.957194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222654.957515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222654.957623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222654.958003:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222654.958096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222654.958269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 675
[1:1:0711/222654.958370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7ff0a13bc070 0xb25dc67c960 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 643 0x7ff0a13bc070 0xb25dc69c560 
[1:1:0711/222654.968323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , document.readyState
[1:1:0711/222654.968470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222655.167187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654, "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222655.173187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://bdtj.tagtic.cn/, 28c0fdd062d8, , , !function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};ret
[1:1:0711/222655.173476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false", "bdtj.tagtic.cn", 4, 1, https://tech.tgbus.com, tech.tgbus.com, 3
[1:1:0711/222655.341686:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222655.341965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222655.362582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654, "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222655.973586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.tgbus.com/news/48592"
[1:1:0711/222655.974054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , cheatJS, (){var t=navigator.userAgent,e='<iframe src="//push.ppnad.com/pc/pc003.html" style="display: none;">
[1:1:0711/222655.974263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222655.975933:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26895:26895:0711/222655.980085:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26895:26895:0711/222655.985778:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0711/222655.987464:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0xb25dbfe3a20
[1:1:0711/222655.987668:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0711/222656.007634:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222656.007940:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.tgbus.com
[26895:26895:0711/222656.009846:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.tgbus.com/
[1:1:0711/222656.010143:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.tgbus.com/news/48592"
[1:1:0711/222656.013164:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://tech.tgbus.com/news/48592"
[1:1:0711/222656.014488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe2f0
[1:1:0711/222656.014665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222656.015037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 713
[1:1:0711/222656.015229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7ff0a13bc070 0xb25dbbb4a60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 661 0x7ff0a13bc070 0xb25dbb9e6e0 
[26895:26895:0711/222656.034188:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222656.035878:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222656.044057:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[26895:26895:0711/222656.044103:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://push.ppnad.com/
[26895:26895:0711/222656.044143:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://push.ppnad.com/, https://push.ppnad.com/pc/pc003.html, 5
[26895:26906:0711/222656.044154:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222656.044205:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://push.ppnad.com/, HTTP/1.1 200 status:200 server:marco/2.10 date:Fri, 12 Jul 2019 05:11:57 GMT content-type:text/html vary:Accept-Encoding x-request-id:a6447cea4b853253e2968b28fc1b29dc; 0730706a8cfe6f1f6377708d7f0f3f94; 92a1f073551e36c8949d6198d769c339; 9db2d5ac292a5ae203283573b5de7b5c x-source:U/200 x-upyun-content-length:10125 etag:W/"5baccc968e55b2b7dfa7995140da4d4e" last-modified:Thu, 11 Jul 2019 15:32:44 GMT x-upyun-content-type:text/html expires:Fri, 19 Jul 2019 15:32:43 GMT cache-control:max-age=691200 age:49154 via:T.102.H, V.403-zj-sad-102, S.mix-sd-dst-068, T.71.H, V.mix-sd-dst-073, T.3.H, M.gwn-bj-pek-004 content-encoding:br  ,26994, 5
[1:7:0711/222656.048278:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222656.342886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , , document.readyState
[1:1:0711/222656.343051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222657.020936:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://push.ppnad.com/
[1:1:0711/222657.038577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222657.039732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://bdtj.tagtic.cn/, 28c0fdd062d8, , d.(anonymous function), (){if(d&&(4===d.readyState||m)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0711/222657.039879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false", "bdtj.tagtic.cn", 4, 1, https://tech.tgbus.com, tech.tgbus.com, 3
[1:1:0711/222657.040792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222657.042577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bdtj.tagtic.cn/crossdomain/index.html?timestamp=2019-07-12T05%3A26%3A16.505Z&suuid=5b76e6a1c647e3c1cc99bf775642ef81&appkey=webtgbusweb&platform=pc&ua=Mozilla%2F5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F67.0.3391.0%20Safari%2F537.36&url=https%3A%2F%2Ftech.tgbus.com%2Fnews%2F48592&referer=&request_method=get&page_id=0a132999c992d47434ddb80630f186c1&short_cookie=81863cc2bf0d240dae01e043035bd687&event=startup&urlKey=xy-log&autoSend=true&handle=false"
[1:1:0711/222657.063280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 713, 7ff0a3d01881
[1:1:0711/222657.073429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"661 0x7ff0a13bc070 0xb25dbb9e6e0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222657.073581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"661 0x7ff0a13bc070 0xb25dbb9e6e0 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222657.073833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222657.074154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222657.074258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222657.074562:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222657.074676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222657.074850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 743
[1:1:0711/222657.074955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7ff0a13bc070 0xb25d33a8c60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 713 0x7ff0a13bc070 0xb25dbbb4a60 
[26895:26895:0711/222657.349287:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://push.ppnad.com/, https://push.ppnad.com/, 5
[26895:26895:0711/222657.349391:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://push.ppnad.com/, https://push.ppnad.com
[1:1:0711/222657.351237:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222657.465239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 743, 7ff0a3d01881
[1:1:0711/222657.476214:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"713 0x7ff0a13bc070 0xb25dbbb4a60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222657.476402:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"713 0x7ff0a13bc070 0xb25dbbb4a60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222657.476610:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222657.476914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222657.477015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222657.477341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222657.477438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222657.477608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 769
[1:1:0711/222657.477713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7ff0a13bc070 0xb25dbb37e60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 743 0x7ff0a13bc070 0xb25d33a8c60 
[1:1:0711/222657.589874:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222657.934141:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222657.934309:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://push.ppnad.com/pc/pc003.html"
[1:1:0711/222657.936369:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7ff0a13bc070 0xb25dcf2b960 , "https://push.ppnad.com/pc/pc003.html"
[1:1:0711/222657.954816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://push.ppnad.com/, 28c0fdcc5de0, , , 
 (function() {
    if (is_pc()) {
        l_yd();
    }
})();
var vol_openedWindow;

function l_yd(
[1:1:0711/222657.955079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://push.ppnad.com/pc/pc003.html", "push.ppnad.com", 5, 1, https://tech.tgbus.com, tech.tgbus.com, 3
[26895:26895:0711/222657.974231:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/222657.976099:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0xb25d3261820
[1:1:0711/222657.976351:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[26895:26895:0711/222657.990141:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0711/222657.994341:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222657.994521:INFO:render_frame_impl.cc(7019)] 	 [url] = https://push.ppnad.com
[1:1:0711/222657.999107:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0xb25dbfe5820
[1:1:0711/222657.999317:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[26895:26895:0711/222658.014127:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:5_https://push.ppnad.com/
[26895:26895:0711/222658.017412:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26895:26895:0711/222658.019258:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0711/222658.021193:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222658.021374:INFO:render_frame_impl.cc(7019)] 	 [url] = https://push.ppnad.com
[1:1:0711/222658.023100:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3131, 0x3e895ac3fb0, 0xb25d2fbe230
[1:1:0711/222658.023522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://push.ppnad.com/pc/pc003.html", 3131
[1:1:0711/222658.023925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://push.ppnad.com/, 802
[1:1:0711/222658.024113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7ff0a13bc070 0xb25dcf26be0 , 5:5_https://push.ppnad.com/, 1, -5:5_https://push.ppnad.com/, 775 0x7ff0a13bc070 0xb25dcf2b960 
[1:1:0711/222658.025221:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7516, 0x3e895ac3fb0, 0xb25d2fbe230
[1:1:0711/222658.025388:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://push.ppnad.com/pc/pc003.html", 7516
[1:1:0711/222658.025733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://push.ppnad.com/, 806
[1:1:0711/222658.025921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 806 0x7ff0a13bc070 0xb25dae38760 , 5:5_https://push.ppnad.com/, 1, -5:5_https://push.ppnad.com/, 775 0x7ff0a13bc070 0xb25dcf2b960 
[1:1:0711/222658.026394:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3e895ac3fb0, 0xb25d2fbe230
[1:1:0711/222658.026555:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://push.ppnad.com/pc/pc003.html", 5000
[1:1:0711/222658.026893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:5_https://push.ppnad.com/, 807
[1:1:0711/222658.027084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7ff0a13bc070 0xb25d33a2de0 , 5:5_https://push.ppnad.com/, 1, -5:5_https://push.ppnad.com/, 775 0x7ff0a13bc070 0xb25dcf2b960 
[26895:26895:0711/222658.028686:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:5_https://push.ppnad.com/
[26895:26895:0711/222658.045714:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222658.046198:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222658.069361:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[26895:26906:0711/222658.069463:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222658.069587:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://push.5z5zw.com/
[26895:26895:0711/222658.069660:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://push.5z5zw.com/, https://push.5z5zw.com/pc/pc003.html, 7
[26895:26895:0711/222658.069789:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://push.5z5zw.com/, HTTP/1.1 200 status:200 server:marco/2.10 date:Fri, 12 Jul 2019 05:12:00 GMT content-type:text/html vary:Accept-Encoding x-request-id:ec7d68735d97864347ac6d2ee725bd52; 68a7732dd3376f50fc391d9c6be0450c; 5c72ae70696ac24d1f804ee1eb6b14f0; b93c08a6d0db3a911ad8c280af4fdf10 x-source:U/200 x-upyun-content-length:431 etag:W/"c220a32a76364b5fd9a412de0713dcc7" last-modified:Thu, 11 Jul 2019 07:20:39 GMT x-upyun-content-type:text/html expires:Fri, 19 Jul 2019 07:20:42 GMT cache-control:max-age=691200 age:78678 via:T.206.H, V.403-zj-fud-209, S.mix-sd-dst-072, T.67.H, V.mix-sd-dst-069, T.3.H, M.gwn-bj-pek-003 content-encoding:br  ,26994, 5
[1:7:0711/222658.087171:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222658.128512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 769, 7ff0a3d01881
[1:1:0711/222658.163775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"743 0x7ff0a13bc070 0xb25d33a8c60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222658.164071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"743 0x7ff0a13bc070 0xb25d33a8c60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222658.164504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222658.165043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222658.165214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222658.165895:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222658.166053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222658.166417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 821
[1:1:0711/222658.166607:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7ff0a13bc070 0xb25d3120560 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 769 0x7ff0a13bc070 0xb25dbb37e60 
[26895:26895:0711/222658.574856:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26895:26895:0711/222658.576503:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26895:26906:0711/222658.587211:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[26895:26895:0711/222658.587249:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://newcar.xcar.com.cn/
[26895:26895:0711/222658.587319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://newcar.xcar.com.cn/, https://newcar.xcar.com.cn/new_ol_163.html, 6
[26895:26906:0711/222658.587322:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[26895:26895:0711/222658.587428:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://newcar.xcar.com.cn/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 05:26:58 GMT content-type:text/html; charset=gb2312 vary:Accept-Encoding vary:Accept-Encoding vary:Accept-Encoding traceid:1562909218683105256216662 x-xcar-via:shyt-newcar-web5621 x-xcar-via:shyt-webproxy-5818 x-xcar-via:tx-webproxy2 content-encoding:gzip server:KSYD/1.1.0 x-cache:MISS from cnc-ta-61-162-234-7  ,26994, 5
[1:7:0711/222658.591731:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222659.189449:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_https://push.5z5zw.com/
[1:1:0711/222659.308812:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 821, 7ff0a3d01881
[1:1:0711/222659.344761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"769 0x7ff0a13bc070 0xb25dbb37e60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222659.345078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"769 0x7ff0a13bc070 0xb25dbb37e60 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222659.345465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222659.346031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222659.346207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222659.346882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222659.347040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222659.347393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 847
[1:1:0711/222659.347609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7ff0a13bc070 0xb25dd013fe0 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 821 0x7ff0a13bc070 0xb25d3120560 
[1:1:0711/222659.816417:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://newcar.xcar.com.cn/
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[26895:26895:0711/222700.030773:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://push.5z5zw.com/, https://push.5z5zw.com/, 7
[26895:26895:0711/222700.030874:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://push.5z5zw.com/, https://push.5z5zw.com
[1:1:0711/222700.031817:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222700.158917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 847, 7ff0a3d01881
[1:1:0711/222700.195667:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0fdc02860","ptid":"821 0x7ff0a13bc070 0xb25d3120560 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222700.196031:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.tgbus.com/","ptid":"821 0x7ff0a13bc070 0xb25d3120560 ","rf":"5:3_https://tech.tgbus.com/"}
[1:1:0711/222700.197035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.tgbus.com/news/48592"
[1:1:0711/222700.197596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.tgbus.com/, 28c0fdc02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0711/222700.197804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.tgbus.com/news/48592", "tech.tgbus.com", 3, 1, , , 0
[1:1:0711/222700.198459:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3e8959a29c8, 0xb25d2fbe150
[1:1:0711/222700.198623:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.tgbus.com/news/48592", 100
[1:1:0711/222700.199006:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.tgbus.com/, 882
[1:1:0711/222700.199194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7ff0a13bc070 0xb25dd03ff60 , 5:3_https://tech.tgbus.com/, 1, -5:3_https://tech.tgbus.com/, 847 0x7ff0a13bc070 0xb25dd013fe0 
[1:1:0711/222700.344017:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26895:26895:0711/222700.345386:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://newcar.xcar.com.cn/, https://newcar.xcar.com.cn/, 6
[26895:26895:0711/222700.345487:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://newcar.xcar.com.cn/, https://newcar.xcar.com.cn
[1:1:0711/222700.619716:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222701.186993:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
