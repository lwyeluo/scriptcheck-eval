[0711/233036.039463:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/233036.039870:INFO:switcher_clone.cc(787)] backtrace rip is 7f5f96c37891
[0711/233037.140832:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/233037.141219:INFO:switcher_clone.cc(787)] backtrace rip is 7fd56b334891
[1:1:0711/233037.152970:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/233037.153237:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/233037.158653:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[35950:35950:0711/233038.666620:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0711/233038.677405:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/233038.677725:INFO:switcher_clone.cc(787)] backtrace rip is 7f0e1b0ae891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/734b8734-35a5-4a71-9f73-67e6f94a5ffe
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[35981:35981:0711/233038.889596:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35981
[35993:35993:0711/233038.889936:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35993
[35950:35950:0711/233039.314921:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[35950:35979:0711/233039.315668:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/233039.315901:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/233039.316141:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/233039.316755:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/233039.316993:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/233039.319822:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x37eef33e, 1
[1:1:0711/233039.320132:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2c9b283d, 0
[1:1:0711/233039.320289:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2614fafc, 3
[1:1:0711/233039.320503:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1d3dfd50, 2
[1:1:0711/233039.320700:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3d28ffffff9b2c 3efffffff3ffffffee37 50fffffffd3d1d fffffffcfffffffa1426 , 10104, 4
[1:1:0711/233039.321622:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35950:35979:0711/233039.321835:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING=(�,>��7P�=��&�*�.
[35950:35979:0711/233039.321899:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is =(�,>��7P�=��&��*�.
[1:1:0711/233039.321831:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd56956f0a0, 3
[35950:35979:0711/233039.322163:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[35950:35979:0711/233039.322234:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36001, 4, 3d289b2c 3ef3ee37 50fd3d1d fcfa1426 
[1:1:0711/233039.322216:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd5696fa080, 2
[1:1:0711/233039.322371:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd5533bdd20, -2
[1:1:0711/233039.340922:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/233039.341804:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d3dfd50
[1:1:0711/233039.342745:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d3dfd50
[1:1:0711/233039.344332:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d3dfd50
[1:1:0711/233039.345853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.346035:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.346218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.346404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.347077:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d3dfd50
[1:1:0711/233039.347396:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd56b3347ba
[1:1:0711/233039.347547:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd56b32bdef, 7fd56b33477a, 7fd56b3360cf
[1:1:0711/233039.353229:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d3dfd50
[1:1:0711/233039.353550:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d3dfd50
[1:1:0711/233039.353899:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d3dfd50
[1:1:0711/233039.354599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.354714:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.354807:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.354898:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d3dfd50
[1:1:0711/233039.355316:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d3dfd50
[1:1:0711/233039.355481:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd56b3347ba
[1:1:0711/233039.355574:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd56b32bdef, 7fd56b33477a, 7fd56b3360cf
[1:1:0711/233039.357713:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/233039.357978:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/233039.358062:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde617a228, 0x7ffde617a1a8)
[1:1:0711/233039.367689:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/233039.373658:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[35950:35950:0711/233039.970263:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35950:35950:0711/233039.971674:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35950:35960:0711/233039.986116:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[35950:35960:0711/233039.986214:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[35950:35950:0711/233039.986498:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[35950:35950:0711/233039.986606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[35950:35950:0711/233039.986808:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,36001, 4
[1:7:0711/233039.991622:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[35950:35973:0711/233040.002927:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/233040.100655:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xbe846f78220
[1:1:0711/233040.100910:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/233040.398846:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[35950:35950:0711/233041.701463:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[35950:35950:0711/233041.701584:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/233041.752495:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233041.756813:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/233043.204716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/233043.205029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233043.237726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/233043.238010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233043.318206:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233043.686748:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233043.686966:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233043.965517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233043.973263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/233043.973484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233044.006928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233044.016863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/233044.017064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233044.027757:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/233044.031324:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbe846f76e20
[1:1:0711/233044.031508:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[35950:35950:0711/233044.032642:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[35950:35950:0711/233044.047076:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[35950:35950:0711/233044.066394:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[35950:35950:0711/233044.066489:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/233044.105578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233044.994416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7fd554f982e0 0xbe8471fb760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233044.995769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/233044.995966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233044.997487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35950:35950:0711/233045.065198:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[35950:35950:0711/233045.071959:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/233045.072541:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xbe846f77820
[1:1:0711/233045.072796:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/233045.096830:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/233045.097095:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[35950:35950:0711/233045.099163:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[35950:35950:0711/233045.110122:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35950:35950:0711/233045.111082:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35950:35960:0711/233045.116888:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[35950:35960:0711/233045.117002:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[35950:35950:0711/233045.117181:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[35950:35950:0711/233045.117288:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[35950:35950:0711/233045.117456:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,36001, 4
[1:7:0711/233045.125448:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/233045.748175:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/233046.394456:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fd554f982e0 0xbe847186fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233046.395486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/233046.395718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233046.396521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35950:35950:0711/233046.513731:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[35950:35950:0711/233046.513852:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/233046.514001:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[35950:35950:0711/233046.566542:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[35950:35979:0711/233046.567071:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/233046.567371:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/233046.567609:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/233046.568091:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/233046.568378:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/233046.572008:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b23d6ba, 1
[1:1:0711/233046.572380:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10c1108c, 0
[1:1:0711/233046.572568:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb6f096f, 3
[1:1:0711/233046.572749:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26833b5a, 2
[1:1:0711/233046.572920:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8c10ffffffc110 ffffffbaffffffd6233b 5a3bffffff8326 6f096f0b , 10104, 5
[1:1:0711/233046.573916:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35950:35979:0711/233046.574212:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����#;Z;�&o	o�+�.
[35950:35979:0711/233046.574282:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����#;Z;�&o	o�O�+�.
[1:1:0711/233046.574191:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd56956f0a0, 3
[1:1:0711/233046.574430:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd5696fa080, 2
[35950:35979:0711/233046.574562:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36046, 5, 8c10c110 bad6233b 5a3b8326 6f096f0b 
[1:1:0711/233046.574622:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd5533bdd20, -2
[1:1:0711/233046.586808:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/233046.587254:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26833b5a
[1:1:0711/233046.587572:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26833b5a
[1:1:0711/233046.588201:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26833b5a
[1:1:0711/233046.589585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.589767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.589940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.590115:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.590777:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26833b5a
[1:1:0711/233046.591066:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd56b3347ba
[1:1:0711/233046.591224:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd56b32bdef, 7fd56b33477a, 7fd56b3360cf
[1:1:0711/233046.592781:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26833b5a
[1:1:0711/233046.592955:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26833b5a
[1:1:0711/233046.593250:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26833b5a
[1:1:0711/233046.593926:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.594050:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.594193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.594334:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26833b5a
[1:1:0711/233046.594995:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26833b5a
[1:1:0711/233046.595239:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd56b3347ba
[1:1:0711/233046.595352:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd56b32bdef, 7fd56b33477a, 7fd56b3360cf
[1:1:0711/233046.598852:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/233046.599272:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/233046.599390:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde617a228, 0x7ffde617a1a8)
[1:1:0711/233046.613734:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/233046.617224:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/233046.783390:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xbe846f41220
[1:1:0711/233046.783656:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/233046.901407:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233047.604550:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233047.604816:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233047.928906:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 572, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233047.933502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/233047.933788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233047.941681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233048.183809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/233048.184663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1493a6a01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/233048.184943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/233048.333338:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233048.335016:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/233048.335406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/233048.335675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233048.424151:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233048.426356:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/233048.426578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/233048.426846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233049.184155:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.hao123.com/"
[35950:35950:0711/233049.209034:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35950:35950:0711/233049.215586:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35950:35950:0711/233049.246407:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://2.fengniao.com/
[35950:35950:0711/233049.246496:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://2.fengniao.com/, https://2.fengniao.com/secforum/4006472.html, 1
[35950:35950:0711/233049.246624:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://2.fengniao.com/, HTTP/1.1 200 OK Server: nginx/1.13.7 Date: Fri, 12 Jul 2019 06:30:49 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/5.6.30 Set-Cookie: _csrf=3a2681df7a2b00358479c756d066ff646b821df8a9ab8fbf85ecd4b836698ad0a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22yJOT3Vtxx-Refspox7Wn3LUpIkWrjOtr%22%3B%7D; path=/; httponly Content-Encoding: gzip Strict-Transport-Security: max-age=63072000 X-Frame-Options: ALLOWALL X-Content-Type-Options: nosniff  ,36046, 5
[35950:35960:0711/233049.246747:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[35950:35960:0711/233049.246837:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/233049.248277:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/233049.296699:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://2.fengniao.com/
[35950:35950:0711/233049.378115:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://2.fengniao.com/, https://2.fengniao.com/, 1
[35950:35950:0711/233049.378215:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://2.fengniao.com/, https://2.fengniao.com
[1:1:0711/233049.405094:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/233049.456470:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/233049.553564:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233049.580389:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/233049.619653:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/233049.630331:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/233049.719302:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/233049.726554:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233049.726838:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233049.790088:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/233049.841906:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/233049.921118:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/233050.056351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233050.057267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/233050.057537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233050.212251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233050.213218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/233050.213504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233050.277077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/233050.277985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1493a6b309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/233050.278266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/233050.694054:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/233051.294798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7fd5533d8bd0 0xbe8468d56d8 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233051.305098:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233051.314380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , /*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL
[1:1:0711/233051.314728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
		remove user.f_cb38768e -> 0
[1:1:0711/233051.586625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7fd5533d8bd0 0xbe8468d56d8 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233051.594391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7fd5533d8bd0 0xbe8468d56d8 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233051.665606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7fd5533d8bd0 0xbe8468d56d8 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233051.731137:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.146917, 772, 1
[1:1:0711/233051.731446:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233052.554930:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233052.555185:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233052.556127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 283 0x7fd553070070 0xbe8474217e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233052.557823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , 
    var seller_id = 10337863;
    var ajax_goods_url = '/goods/ajax';
    $(function () {
        s
[1:1:0711/233052.558049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233052.598619:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0432911, 59, 1
[1:1:0711/233052.598871:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233053.515209:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233053.515415:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233053.516222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329 0x7fd553070070 0xbe84723da60 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233053.518178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , 
    (function(){
        var allClassificationBoxHeight = $('#allClassificationBox .sub-link-box').
[1:1:0711/233053.518362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233054.186944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.671415, 0, 0
[1:1:0711/233054.187214:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233055.273730:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233055.274051:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233055.309023:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.034842, 165, 1
[1:1:0711/233055.309330:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233056.464076:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233056.464358:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233056.464948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 455 0x7fd553070070 0xbe8473f65e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233056.466161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , 
                window._bd_share_config={
                    "common":{
                        "b
[1:1:0711/233056.466377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233056.538329:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.073976, 479, 1
[1:1:0711/233056.538673:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233056.771433:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233056.771962:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233056.772428:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233056.772846:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233056.773181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233057.592609:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233057.592894:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233057.593920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 506 0x7fd553070070 0xbe8473ec660 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233057.595552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , 
    //初始化数据
    var goods_id  = 4006472,
        seller_id  = 10337863,
        user_inde
[1:1:0711/233057.595787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233057.603931:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/233057.607539:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xbe8478a4420
[1:1:0711/233057.608209:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/233057.644328:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0512888, 206, 1
[1:1:0711/233057.644598:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233058.486133:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233058.486447:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233058.487337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548 0x7fd553070070 0xbe84741b360 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233058.488302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , var myDate = new Date();document.write(myDate.getFullYear());
[1:1:0711/233058.488566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233058.521944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0353501, 130, 1
[1:1:0711/233058.522208:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233059.242617:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233059.242886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233059.246120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7fd553070070 0xbe8473899e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233059.247700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , if(typeof(fn_pvhitimgview)=="undefined"){var fn_pvhitimgview=true;FN_PV_JS_OBJ={js_dom:"js.fengniao.
[1:1:0711/233059.247934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233100.363549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626, "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233100.371228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , var ip_ck = '4sKD5fP0j7QuNTUyMjkzLjE1NjI5MTMwNTk=';
var ip = '218.241.135.34';
var se = 'bfc5a49be5f
[1:1:0711/233100.371480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233100.422029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626, "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233100.433432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626, "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233100.475966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626, "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233103.187222:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.76602, 0, 0
[1:1:0711/233103.187502:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233105.307434:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233105.307693:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.311888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.319846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , /**
 * BxSlider v4.1.2 - Fully loaded, responsive content slider
 * http://bxslider.com
 *
 * Copyri
[1:1:0711/233105.320120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233105.329442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.339127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.353906:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.371512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.380473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.498924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.507652:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.553676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.563164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.570783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.580810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682 0x7fd553070070 0xbe8473929e0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233105.679813:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233105.680497:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[35950:35950:0711/233107.778034:INFO:CONSOLE(682)] "Mixed Content: The page at 'https://2.fengniao.com/secforum/4006472.html' was loaded over HTTPS, but requested an insecure script 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=434141'. This request has been blocked; the content must be served over HTTPS.", source: https://2.fengniao.com/secforum/4006472.html (682)
[35950:35950:0711/233107.786140:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[35950:35950:0711/233107.793724:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[35950:35950:0711/233107.805845:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://2.fengniao.com/, https://2.fengniao.com/, 4
[35950:35950:0711/233107.805931:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://2.fengniao.com/, https://2.fengniao.com
[35950:35950:0711/233107.869604:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/233107.893408:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[35950:35950:0711/233107.951542:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/233115.682425:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc388
[1:1:0711/233115.682681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233115.683107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 786
[1:1:0711/233115.683361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7fd553070070 0xbe84997d9e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 682 0x7fd553070070 0xbe8473929e0 
[1:1:0711/233115.688072:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 10.3802, 0, 0
[1:1:0711/233115.688314:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/233116.643279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7fd554f982e0 0xbe8473f0ce0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233116.648311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , (function(){var h={},mt={},c={id:"916ddc034db3aa7261c5d56a3001e7c5",dm:["fengniao.com"],js:"tongji.b
[1:1:0711/233116.648541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233116.699247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc190
[1:1:0711/233116.699501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233116.699970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 808
[1:1:0711/233116.700247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7fd553070070 0xbe847d603e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 711 0x7fd554f982e0 0xbe8473f0ce0 
[1:1:0711/233117.833686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/233117.833978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233118.863496:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/233118.863748:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233118.867663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7fd553070070 0xbe84ac4d660 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233118.870372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , /** 
 * @Description: the script 二手交易详情页
 * @authors: hanjw (han.jingwei@fengniao.com)
[1:1:0711/233118.870608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233118.871295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x15257e9629c8, 0xbe846dbc1b0
[1:1:0711/233118.871503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 1500
[1:1:0711/233118.872008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 858
[1:1:0711/233118.872264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7fd553070070 0xbe84ac49260 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 788 0x7fd553070070 0xbe84ac4d660 
[1:1:0711/233118.876760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7fd553070070 0xbe84ac4d660 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233118.933572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233121.010091:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc440
[1:1:0711/233121.010346:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233121.010776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 869
[1:1:0711/233121.011003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7fd553070070 0xbe84b5f7360 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 788 0x7fd553070070 0xbe84ac4d660 
[1:1:0711/233121.011553:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 1000
[1:1:0711/233121.011979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 870
[1:1:0711/233121.012179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7fd553070070 0xbe84bb751e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 788 0x7fd553070070 0xbe84ac4d660 
[1:1:0711/233121.185178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x15257e9629c8, 0xbe846dbc440
[1:1:0711/233121.185453:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 500
[1:1:0711/233121.185856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 880
[1:1:0711/233121.186047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7fd553070070 0xbe84bc38a60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 788 0x7fd553070070 0xbe84ac4d660 
[1:1:0711/233122.925029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://2.fengniao.com/secforum/4006472.html"
[35950:35950:0711/233123.015738:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: https://2.fengniao.com/secforum/4006472.html (0)
[35950:35950:0711/233123.019821:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "new-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://2.fengniao.com/secforum/4006472.html (0)
[35950:35950:0711/233123.024036:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "new-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://2.fengniao.com/secforum/4006472.html (0)
[1:1:0711/233123.147525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233123.150324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0711/233123.150561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233123.486540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 786, 7fd5559b5881
[1:1:0711/233123.516829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"682 0x7fd553070070 0xbe8473929e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233123.517026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"682 0x7fd553070070 0xbe8473929e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233123.517236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233123.517580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233123.517716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233123.520177:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233123.520294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233123.520471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 911
[1:1:0711/233123.520670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7fd553070070 0xbe84b159ae0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 786 0x7fd553070070 0xbe84997d9e0 
[1:1:0711/233124.386648:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 808, 7fd5559b5881
[1:1:0711/233124.403147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"711 0x7fd554f982e0 0xbe8473f0ce0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233124.403371:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"711 0x7fd554f982e0 0xbe8473f0ce0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233124.403628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233124.403960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233124.404064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233124.404488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233124.404590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233124.404770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 923
[1:1:0711/233124.404879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7fd553070070 0xbe84795dc60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 808 0x7fd553070070 0xbe847d603e0 
[1:1:0711/233124.805110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233124.805381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233125.241539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 853 0x7fd554f982e0 0xbe84b136fe0 , "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.243169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0711/233125.243396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233125.426114:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.426856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233125.427068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233125.428252:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.430715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.431445:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233125.537861:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.538401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233125.538564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233125.539024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.542461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233125.543385:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233125.763365:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233125.763932:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233125.764280:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/233126.524516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233126.525372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233126.525578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233126.526137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233126.528470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233126.529166:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233127.018859:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.019653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233127.019848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233127.020469:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.023198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.023825:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233127.140948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.141805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233127.142074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233127.142707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.143415:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233127.779734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 858, 7fd5559b5881
[1:1:0711/233127.816318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.816787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.817148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.817589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , (){
	priceGuideFn()
}
[1:1:0711/233127.817716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233127.826645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 869, 7fd5559b5881
[1:1:0711/233127.841626:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.841828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.842060:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.842441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233127.842550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233127.848022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233127.848180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233127.848407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1000
[1:1:0711/233127.848528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7fd553070070 0xbe84d13afe0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 869 0x7fd553070070 0xbe84b5f7360 
[1:1:0711/233127.881161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 880, 7fd5559b5881
[1:1:0711/233127.895984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.896193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.896518:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.896852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
            $.get('/common/check-user?t=' + (new Date()).getTime(), data, function (json) {
   
[1:1:0711/233127.896958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233127.936057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 870, 7fd5559b58db
[1:1:0711/233127.964157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.964507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"788 0x7fd553070070 0xbe84ac4d660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233127.964936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1003
[1:1:0711/233127.965126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7fd553070070 0xbe84bf45e60 , 5:3_https://2.fengniao.com/, 0, , 870 0x7fd553070070 0xbe84bb751e0 
[1:1:0711/233127.965468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233127.966026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233127.966195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233128.218361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233128.219067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , SesameCreditCicrle.img.onload, () {
        ctx.drawImage(img, -148, -150);
    }
[1:1:0711/233128.219276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233128.290007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 911, 7fd5559b5881
[1:1:0711/233128.327970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"786 0x7fd553070070 0xbe84997d9e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233128.328307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"786 0x7fd553070070 0xbe84997d9e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233128.328692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233128.329378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233128.329568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233128.350156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233128.350454:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233128.350938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1010
[1:1:0711/233128.351205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7fd553070070 0xbe84c6a6b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 911 0x7fd553070070 0xbe84b159ae0 
[1:1:0711/233128.658232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233128.658666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0711/233128.658774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233128.663204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 923, 7fd5559b5881
[1:1:0711/233128.678960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"808 0x7fd553070070 0xbe847d603e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233128.679173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"808 0x7fd553070070 0xbe847d603e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233128.679400:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233128.679712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233128.679817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233128.680206:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233128.680304:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233128.680472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1021
[1:1:0711/233128.680591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7fd553070070 0xbe84d21b360 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 923 0x7fd553070070 0xbe84795dc60 
[1:1:0711/233129.059731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233129.059943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[35950:35950:0711/233129.701108:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/233130.636796:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233130.637243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0711/233130.637352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233130.640086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc220
[1:1:0711/233130.640198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233130.640383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1046
[1:1:0711/233130.640537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7fd553070070 0xbe8473f6860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 
[1:1:0711/233130.641135:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc220
[1:1:0711/233130.641234:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233130.641454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1047
[1:1:0711/233130.641573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7fd553070070 0xbe84d2876e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 
[1:1:0711/233131.659395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1003, 7fd5559b58db
[1:1:0711/233131.703848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"870 0x7fd553070070 0xbe84bb751e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.704117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"870 0x7fd553070070 0xbe84bb751e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.704567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1072
[1:1:0711/233131.704756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7fd553070070 0xbe84bde7d60 , 5:3_https://2.fengniao.com/, 0, , 1003 0x7fd553070070 0xbe84bf45e60 
[1:1:0711/233131.705089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.705692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233131.705861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233131.823927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.824567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0711/233131.824728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233131.825072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.826974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.827760:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x32c98d9769f0
[1:1:0711/233131.859110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1000, 7fd5559b5881
[1:1:0711/233131.874332:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"869 0x7fd553070070 0xbe84b5f7360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.874539:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"869 0x7fd553070070 0xbe84b5f7360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.874745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.875075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233131.875209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233131.881660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233131.881828:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233131.882014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1077
[1:1:0711/233131.882149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7fd553070070 0xbe84d213b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1000 0x7fd553070070 0xbe84d13afe0 
[1:1:0711/233131.923683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1010, 7fd5559b5881
[1:1:0711/233131.940108:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"911 0x7fd553070070 0xbe84b159ae0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.940333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"911 0x7fd553070070 0xbe84b159ae0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233131.940547:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233131.940883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233131.940988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233131.945778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233131.945900:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233131.946105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1080
[1:1:0711/233131.946221:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7fd553070070 0xbe849ec2b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1010 0x7fd553070070 0xbe84c6a6b60 
[1:1:0711/233132.284816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1021, 7fd5559b5881
[1:1:0711/233132.331870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"923 0x7fd553070070 0xbe84795dc60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233132.332277:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"923 0x7fd553070070 0xbe84795dc60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233132.332660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233132.333325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233132.333502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233132.334225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233132.334400:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233132.334777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1093
[1:1:0711/233132.334992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7fd553070070 0xbe84cc03c60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1021 0x7fd553070070 0xbe84d21b360 
[1:1:0711/233132.437216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233132.437459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233133.231925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1046, 7fd5559b5881
[1:1:0711/233133.260357:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233133.260560:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233133.260822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233133.261145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , (){a.reload()}
[1:1:0711/233133.261247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233133.479370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1047, 7fd5559b5881
[1:1:0711/233133.529916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233133.530354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"969 0x7fd562381960 0xbe84c63c600 0xbe84c63c610 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233133.530840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233133.531491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , (){a.reload()}
[1:1:0711/233133.531702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233134.402108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1080, 7fd5559b5881
[1:1:0711/233134.459523:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1010 0x7fd553070070 0xbe84c6a6b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.459866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1010 0x7fd553070070 0xbe84c6a6b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.460311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233134.461037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233134.461216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233134.465240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233134.465446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233134.465843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1135
[1:1:0711/233134.466034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7fd553070070 0xbe84d5bc060 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1080 0x7fd553070070 0xbe849ec2b60 
[1:1:0711/233134.521767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1072, 7fd5559b58db
[1:1:0711/233134.543994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1003 0x7fd553070070 0xbe84bf45e60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.544343:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1003 0x7fd553070070 0xbe84bf45e60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.544902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1140
[1:1:0711/233134.545148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7fd553070070 0xbe84d25b960 , 5:3_https://2.fengniao.com/, 0, , 1072 0x7fd553070070 0xbe84bde7d60 
[1:1:0711/233134.545603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233134.546310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233134.546548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233134.695173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1077, 7fd5559b5881
[1:1:0711/233134.734525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1000 0x7fd553070070 0xbe84d13afe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.734720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1000 0x7fd553070070 0xbe84d13afe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.734952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233134.735348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233134.735466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233134.741249:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233134.741378:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233134.741549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1145
[1:1:0711/233134.741651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1145 0x7fd553070070 0xbe84d6e0460 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1077 0x7fd553070070 0xbe84d213b60 
[1:1:0711/233134.905789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1093, 7fd5559b5881
[1:1:0711/233134.959438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1021 0x7fd553070070 0xbe84d21b360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.959846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1021 0x7fd553070070 0xbe84d21b360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233134.960352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233134.961097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233134.961340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233134.962199:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233134.962422:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233134.962894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1149
[1:1:0711/233134.963137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1149 0x7fd553070070 0xbe84d3e0ee0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1093 0x7fd553070070 0xbe84cc03c60 
[1:1:0711/233134.981089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233134.981288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/233136.021330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1135, 7fd5559b5881
[1:1:0711/233136.040254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1080 0x7fd553070070 0xbe849ec2b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.040463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1080 0x7fd553070070 0xbe849ec2b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.040675:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233136.041046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233136.041156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.043212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233136.043331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233136.043512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1175
[1:1:0711/233136.043619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7fd553070070 0xbe84d5bcb60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1135 0x7fd553070070 0xbe84d5bc060 
[1:1:0711/233136.206954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233136.207123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.227305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1140, 7fd5559b58db
[1:1:0711/233136.244551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1072 0x7fd553070070 0xbe84bde7d60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.244727:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1072 0x7fd553070070 0xbe84bde7d60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.244983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1188
[1:1:0711/233136.245098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1188 0x7fd553070070 0xbe84d7461e0 , 5:3_https://2.fengniao.com/, 0, , 1140 0x7fd553070070 0xbe84d25b960 
[1:1:0711/233136.245282:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233136.245586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233136.245688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.275808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1145, 7fd5559b5881
[1:1:0711/233136.310615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1077 0x7fd553070070 0xbe84d213b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.310812:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1077 0x7fd553070070 0xbe84d213b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.311074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233136.311415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233136.311519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.322838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233136.323079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233136.323457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1189
[1:1:0711/233136.323648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1189 0x7fd553070070 0xbe84d74b660 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1145 0x7fd553070070 0xbe84d6e0460 
[1:1:0711/233136.325091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1149, 7fd5559b5881
[1:1:0711/233136.371524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1093 0x7fd553070070 0xbe84cc03c60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.371723:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1093 0x7fd553070070 0xbe84cc03c60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.372010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233136.372345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233136.372448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.372770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233136.372893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233136.373136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1190
[1:1:0711/233136.373288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1190 0x7fd553070070 0xbe84d6adfe0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1149 0x7fd553070070 0xbe84d3e0ee0 
[1:1:0711/233136.652648:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1175, 7fd5559b5881
[1:1:0711/233136.671086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1135 0x7fd553070070 0xbe84d5bc060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.671277:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1135 0x7fd553070070 0xbe84d5bc060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233136.671527:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233136.671914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233136.672022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233136.674253:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233136.674373:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233136.674559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1207
[1:1:0711/233136.674670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7fd553070070 0xbe84d295960 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1175 0x7fd553070070 0xbe84d5bcb60 
[1:1:0711/233137.006842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233137.007084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233137.140844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1190, 7fd5559b5881
[1:1:0711/233137.193444:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1149 0x7fd553070070 0xbe84d3e0ee0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.193776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1149 0x7fd553070070 0xbe84d3e0ee0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.194146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233137.194730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233137.194907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233137.195585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233137.195768:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233137.196160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1221
[1:1:0711/233137.196351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7fd553070070 0xbe84d172b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1190 0x7fd553070070 0xbe84d6adfe0 
[1:1:0711/233137.381325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233137.382053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){if(!a.V){a.V=u;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0711/233137.382243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233137.384952:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233137.386276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc2f0
[1:1:0711/233137.386434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233137.386896:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1227
[1:1:0711/233137.387138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7fd553070070 0xbe84d5bc260 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1198 0x7fd553070070 0xbe84d6b1ce0 
[1:1:0711/233137.471828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1189, 7fd5559b5881
[1:1:0711/233137.521618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1145 0x7fd553070070 0xbe84d6e0460 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.521927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1145 0x7fd553070070 0xbe84d6e0460 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.522311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233137.522995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233137.523173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233137.537414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233137.537655:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233137.538037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1230
[1:1:0711/233137.538229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7fd553070070 0xbe846ae5860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1189 0x7fd553070070 0xbe84d74b660 
[1:1:0711/233137.860001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1207, 7fd5559b5881
[1:1:0711/233137.912091:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1175 0x7fd553070070 0xbe84d5bcb60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.912398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1175 0x7fd553070070 0xbe84d5bcb60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233137.912836:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233137.913558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233137.913736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233137.917710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233137.917887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233137.918263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1240
[1:1:0711/233137.918455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7fd553070070 0xbe84d39dfe0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1207 0x7fd553070070 0xbe84d295960 
[1:1:0711/233137.973589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , document.readyState
[1:1:0711/233137.973827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233138.145058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1188, 7fd5559b58db
[1:1:0711/233138.196585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1140 0x7fd553070070 0xbe84d25b960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.196873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1140 0x7fd553070070 0xbe84d25b960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.197269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1255
[1:1:0711/233138.197481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1255 0x7fd553070070 0xbe84d3a8660 , 5:3_https://2.fengniao.com/, 0, , 1188 0x7fd553070070 0xbe84d7461e0 
[1:1:0711/233138.197816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233138.198371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233138.198564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233138.630336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1227, 7fd5559b5881
[1:1:0711/233138.683085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1198 0x7fd553070070 0xbe84d6b1ce0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.683429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1198 0x7fd553070070 0xbe84d6b1ce0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.683831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233138.684426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233138.684604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233138.685319:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233138.685477:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233138.685853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1271
[1:1:0711/233138.686041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1271 0x7fd553070070 0xbe84d3753e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1227 0x7fd553070070 0xbe84d5bc260 
[1:1:0711/233138.741518:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1230, 7fd5559b5881
[1:1:0711/233138.805033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1189 0x7fd553070070 0xbe84d74b660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.805467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1189 0x7fd553070070 0xbe84d74b660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.805907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233138.806716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233138.806929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233138.824037:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233138.824343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233138.824807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1273
[1:1:0711/233138.825040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7fd553070070 0xbe84d81a160 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1230 0x7fd553070070 0xbe846ae5860 
[1:1:0711/233138.827259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1240, 7fd5559b5881
[1:1:0711/233138.889594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1207 0x7fd553070070 0xbe84d295960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.889924:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1207 0x7fd553070070 0xbe84d295960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233138.890307:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233138.891031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233138.891221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233138.895287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233138.895455:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233138.895830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1276
[1:1:0711/233138.896020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1276 0x7fd553070070 0xbe84d630060 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1240 0x7fd553070070 0xbe84d39dfe0 
[1:1:0711/233139.406975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1271, 7fd5559b5881
[1:1:0711/233139.424622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1227 0x7fd553070070 0xbe84d5bc260 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.424849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1227 0x7fd553070070 0xbe84d5bc260 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.425053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.425426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233139.425528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.425837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233139.425931:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233139.426132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1289
[1:1:0711/233139.426244:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7fd553070070 0xbe846fc9fe0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1271 0x7fd553070070 0xbe84d3753e0 
[1:1:0711/233139.469592:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1276, 7fd5559b5881
[1:1:0711/233139.493255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1240 0x7fd553070070 0xbe84d39dfe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.493465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1240 0x7fd553070070 0xbe84d39dfe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.493673:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.494010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233139.494139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.496222:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233139.496332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233139.496516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1291
[1:1:0711/233139.496623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7fd553070070 0xbe84d275d60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1276 0x7fd553070070 0xbe84d630060 
[1:1:0711/233139.497199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1255, 7fd5559b58db
[1:1:0711/233139.519364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1188 0x7fd553070070 0xbe84d7461e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.519646:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1188 0x7fd553070070 0xbe84d7461e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.520032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1292
[1:1:0711/233139.520256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1292 0x7fd553070070 0xbe84ac445e0 , 5:3_https://2.fengniao.com/, 0, , 1255 0x7fd553070070 0xbe84d3a8660 
[1:1:0711/233139.520557:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.521110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233139.521279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.566013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1273, 7fd5559b5881
[1:1:0711/233139.584403:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1230 0x7fd553070070 0xbe846ae5860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.584622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1230 0x7fd553070070 0xbe846ae5860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.584850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.585225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233139.585332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.591145:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233139.591282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233139.591468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1296
[1:1:0711/233139.591576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1296 0x7fd553070070 0xbe84d730860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1273 0x7fd553070070 0xbe84d81a160 
[1:1:0711/233139.792856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1291, 7fd5559b5881
[1:1:0711/233139.833002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1276 0x7fd553070070 0xbe84d630060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.833218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1276 0x7fd553070070 0xbe84d630060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.833434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.833781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233139.833890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.838163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233139.838307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233139.838500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1303
[1:1:0711/233139.838614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7fd553070070 0xbe84d72b860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1291 0x7fd553070070 0xbe84d275d60 
[1:1:0711/233139.839203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1289, 7fd5559b5881
[1:1:0711/233139.875234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1271 0x7fd553070070 0xbe84d3753e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.875613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1271 0x7fd553070070 0xbe84d3753e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.876093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.876795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233139.877027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233139.877869:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233139.878094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233139.878564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1304
[1:1:0711/233139.878799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1304 0x7fd553070070 0xbe84d833060 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1289 0x7fd553070070 0xbe846fc9fe0 
[1:1:0711/233139.979328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1303, 7fd5559b5881
[1:1:0711/233139.997983:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1291 0x7fd553070070 0xbe84d275d60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.998197:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1291 0x7fd553070070 0xbe84d275d60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233139.998425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233139.998770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233139.998876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.000971:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233140.001086:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233140.001274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1309
[1:1:0711/233140.001389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1309 0x7fd553070070 0xbe84d81dc60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1303 0x7fd553070070 0xbe84d72b860 
[1:1:0711/233140.020150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1296, 7fd5559b5881
[1:1:0711/233140.037961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1273 0x7fd553070070 0xbe84d81a160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.038168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1273 0x7fd553070070 0xbe84d81a160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.038376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.038714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233140.038839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.047594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233140.047887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233140.048422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1312
[1:1:0711/233140.048669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7fd553070070 0xbe846f348e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1296 0x7fd553070070 0xbe84d730860 
[1:1:0711/233140.094898:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1304, 7fd5559b5881
[1:1:0711/233140.119795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1289 0x7fd553070070 0xbe846fc9fe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.120156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1289 0x7fd553070070 0xbe846fc9fe0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.120504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.121081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233140.121255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.121936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233140.122090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233140.122455:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1314
[1:1:0711/233140.122638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7fd553070070 0xbe84c24c660 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1304 0x7fd553070070 0xbe84d833060 
[1:1:0711/233140.124285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1309, 7fd5559b5881
[1:1:0711/233140.181134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1303 0x7fd553070070 0xbe84d72b860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.181548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1303 0x7fd553070070 0xbe84d72b860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.182024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.182905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233140.183133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.187799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233140.188030:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233140.188232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1315
[1:1:0711/233140.188347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1315 0x7fd553070070 0xbe84d726160 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1309 0x7fd553070070 0xbe84d81dc60 
[1:1:0711/233140.213022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1292, 7fd5559b58db
[1:1:0711/233140.240222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1255 0x7fd553070070 0xbe84d3a8660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.240417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1255 0x7fd553070070 0xbe84d3a8660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.240645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1318
[1:1:0711/233140.240755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1318 0x7fd553070070 0xbe84d3d4e60 , 5:3_https://2.fengniao.com/, 0, , 1292 0x7fd553070070 0xbe84ac445e0 
[1:1:0711/233140.240956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.241269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233140.241378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.299785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1315, 7fd5559b5881
[1:1:0711/233140.325501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1309 0x7fd553070070 0xbe84d81dc60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.325816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1309 0x7fd553070070 0xbe84d81dc60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.326215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.326940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233140.327167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.341779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233140.342043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233140.342439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1322
[1:1:0711/233140.342646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7fd553070070 0xbe84d3a8c60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1315 0x7fd553070070 0xbe84d726160 
[1:1:0711/233140.344177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1314, 7fd5559b5881
[1:1:0711/233140.405002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1304 0x7fd553070070 0xbe84d833060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.405411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1304 0x7fd553070070 0xbe84d833060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.405889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.406621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233140.406865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.407733:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233140.407978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233140.408460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1324
[1:1:0711/233140.408711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7fd553070070 0xbe846f77660 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1314 0x7fd553070070 0xbe84c24c660 
[1:1:0711/233140.553828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1312, 7fd5559b5881
[1:1:0711/233140.613632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1296 0x7fd553070070 0xbe84d730860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.613862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1296 0x7fd553070070 0xbe84d730860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.614092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.614423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233140.614525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.621219:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233140.621356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233140.621546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1330
[1:1:0711/233140.621678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1330 0x7fd553070070 0xbe84d7304e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1312 0x7fd553070070 0xbe846f348e0 
[1:1:0711/233140.622388:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1322, 7fd5559b5881
[1:1:0711/233140.640347:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1315 0x7fd553070070 0xbe84d726160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.640552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1315 0x7fd553070070 0xbe84d726160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.640751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.641327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233140.641501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.643996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233140.644178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233140.644564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1332
[1:1:0711/233140.644755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1332 0x7fd553070070 0xbe84d833960 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1322 0x7fd553070070 0xbe84d3a8c60 
[1:1:0711/233140.737870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1324, 7fd5559b5881
[1:1:0711/233140.757039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1314 0x7fd553070070 0xbe84c24c660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.757356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1314 0x7fd553070070 0xbe84c24c660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.757734:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.758330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233140.758506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.759208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233140.759371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233140.759816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1336
[1:1:0711/233140.760040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1336 0x7fd553070070 0xbe84d8001e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1324 0x7fd553070070 0xbe846f77660 
[1:1:0711/233140.811784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1332, 7fd5559b5881
[1:1:0711/233140.878468:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1322 0x7fd553070070 0xbe84d3a8c60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.878885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1322 0x7fd553070070 0xbe84d3a8c60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233140.879332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233140.880229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233140.880451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233140.885327:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233140.885542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233140.886051:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1338
[1:1:0711/233140.886295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7fd553070070 0xbe84d855060 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1332 0x7fd553070070 0xbe84d833960 
[1:1:0711/233140.974662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1336, 7fd5559b5881
[1:1:0711/233141.014776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1324 0x7fd553070070 0xbe846f77660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.015174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1324 0x7fd553070070 0xbe846f77660 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.015630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.016401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233141.016616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.017479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.017671:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233141.018167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1345
[1:1:0711/233141.018408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7fd553070070 0xbe84d7466e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1336 0x7fd553070070 0xbe84d8001e0 
[1:1:0711/233141.091475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1338, 7fd5559b5881
[1:1:0711/233141.111494:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1332 0x7fd553070070 0xbe84d833960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.111755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1332 0x7fd553070070 0xbe84d833960 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.111977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.112318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233141.112425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.114549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233141.114693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233141.114892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1349
[1:1:0711/233141.115001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1349 0x7fd553070070 0xbe846f8dae0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1338 0x7fd553070070 0xbe84d855060 
[1:1:0711/233141.115525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1330, 7fd5559b5881
[1:1:0711/233141.134640:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1312 0x7fd553070070 0xbe846f348e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.134873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1312 0x7fd553070070 0xbe846f348e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.135097:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.135485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233141.135638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.141433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.141540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233141.141745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1350
[1:1:0711/233141.141860:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7fd553070070 0xbe84d8334e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1330 0x7fd553070070 0xbe84d7304e0 
[1:1:0711/233141.160582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1318, 7fd5559b58db
[1:1:0711/233141.178062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1292 0x7fd553070070 0xbe84ac445e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.178245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1292 0x7fd553070070 0xbe84ac445e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.178462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1353
[1:1:0711/233141.178567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7fd553070070 0xbe84d375be0 , 5:3_https://2.fengniao.com/, 0, , 1318 0x7fd553070070 0xbe84d3d4e60 
[1:1:0711/233141.178766:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.179076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233141.179175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.270855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1345, 7fd5559b5881
[1:1:0711/233141.320641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1336 0x7fd553070070 0xbe84d8001e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.320863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1336 0x7fd553070070 0xbe84d8001e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.321084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.321410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233141.321527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.321880:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.321981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233141.322169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1357
[1:1:0711/233141.322277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1357 0x7fd553070070 0xbe84d865b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1345 0x7fd553070070 0xbe84d7466e0 
[1:1:0711/233141.322896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1349, 7fd5559b5881
[1:1:0711/233141.340954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1338 0x7fd553070070 0xbe84d855060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.341152:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1338 0x7fd553070070 0xbe84d855060 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.341358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.341724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233141.341834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.345989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233141.346121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233141.346316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1359
[1:1:0711/233141.346436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1359 0x7fd553070070 0xbe846fc9860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1349 0x7fd553070070 0xbe846f8dae0 
[1:1:0711/233141.384229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1359, 7fd5559b5881
[1:1:0711/233141.402391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1349 0x7fd553070070 0xbe846f8dae0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.402672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1349 0x7fd553070070 0xbe846f8dae0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.403134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.404011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233141.404278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.409082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233141.409265:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233141.409665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1362
[1:1:0711/233141.409805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7fd553070070 0xbe84d82ede0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1359 0x7fd553070070 0xbe846fc9860 
[1:1:0711/233141.513678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1362, 7fd5559b5881
[1:1:0711/233141.547353:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1359 0x7fd553070070 0xbe846fc9860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.547640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1359 0x7fd553070070 0xbe846fc9860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.547923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.548391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233141.548532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.551366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233141.551501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233141.551775:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1372
[1:1:0711/233141.551923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1372 0x7fd553070070 0xbe84bbf0360 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1362 0x7fd553070070 0xbe84d82ede0 
[1:1:0711/233141.552752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1350, 7fd5559b5881
[1:1:0711/233141.575788:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1330 0x7fd553070070 0xbe84d7304e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.575991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1330 0x7fd553070070 0xbe84d7304e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.576451:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.577128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233141.577303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.591779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.592004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233141.592393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1373
[1:1:0711/233141.592652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1373 0x7fd553070070 0xbe846b7ef60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1350 0x7fd553070070 0xbe84d8334e0 
[1:1:0711/233141.594031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1357, 7fd5559b5881
[1:1:0711/233141.650022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1345 0x7fd553070070 0xbe84d7466e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.650343:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1345 0x7fd553070070 0xbe84d7466e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.650719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.651283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233141.651484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.652208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.652359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233141.652777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1375
[1:1:0711/233141.652961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1375 0x7fd553070070 0xbe84d6e0160 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1357 0x7fd553070070 0xbe84d865b60 
[1:1:0711/233141.784146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1372, 7fd5559b5881
[1:1:0711/233141.802309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1362 0x7fd553070070 0xbe84d82ede0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.802536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1362 0x7fd553070070 0xbe84d82ede0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.802754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.803113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233141.803218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.805451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233141.805600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233141.805788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1381
[1:1:0711/233141.805899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7fd553070070 0xbe84d6e0860 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1372 0x7fd553070070 0xbe84bbf0360 
[1:1:0711/233141.899623:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1375, 7fd5559b5881
[1:1:0711/233141.923849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1357 0x7fd553070070 0xbe84d865b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.924064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1357 0x7fd553070070 0xbe84d865b60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.924278:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233141.924657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233141.924768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233141.925115:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233141.925211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233141.925398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1385
[1:1:0711/233141.925528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1385 0x7fd553070070 0xbe84d0f5260 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1375 0x7fd553070070 0xbe84d6e0160 
[1:1:0711/233141.945963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1381, 7fd5559b5881
[1:1:0711/233141.999383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1372 0x7fd553070070 0xbe84bbf0360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233141.999728:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1372 0x7fd553070070 0xbe84bbf0360 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.000146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.000887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233142.001063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.005016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233142.005190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233142.005584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1389
[1:1:0711/233142.005777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1389 0x7fd553070070 0xbe84d7304e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1381 0x7fd553070070 0xbe84d6e0860 
[1:1:0711/233142.007491:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1373, 7fd5559b5881
[1:1:0711/233142.064818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1350 0x7fd553070070 0xbe84d8334e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.065136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1350 0x7fd553070070 0xbe84d8334e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.065515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.066211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233142.066386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.080373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233142.080637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233142.081017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1391
[1:1:0711/233142.081208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1391 0x7fd553070070 0xbe84d6b1ce0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1373 0x7fd553070070 0xbe846b7ef60 
[1:1:0711/233142.360774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1389, 7fd5559b5881
[1:1:0711/233142.383544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1381 0x7fd553070070 0xbe84d6e0860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.383765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1381 0x7fd553070070 0xbe84d6e0860 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.383980:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.384380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233142.384494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.386604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233142.386710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233142.386893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1404
[1:1:0711/233142.386999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7fd553070070 0xbe84d371be0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1389 0x7fd553070070 0xbe84d7304e0 
[1:1:0711/233142.418526:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1353, 7fd5559b58db
[1:1:0711/233142.467082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1318 0x7fd553070070 0xbe84d3d4e60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.467368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1318 0x7fd553070070 0xbe84d3d4e60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.467776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://2.fengniao.com/, 1407
[1:1:0711/233142.467970:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1407 0x7fd553070070 0xbe84d7480e0 , 5:3_https://2.fengniao.com/, 0, , 1353 0x7fd553070070 0xbe84d375be0 
[1:1:0711/233142.468320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.468949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                if ($("#shootCountdown").attr('end_time') <= 0) {
                    clearInte
[1:1:0711/233142.469154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.505483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1385, 7fd5559b5881
[1:1:0711/233142.524820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1375 0x7fd553070070 0xbe84d6e0160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.525008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1375 0x7fd553070070 0xbe84d6e0160 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.525245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.525588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233142.525694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.526027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233142.526124:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233142.526301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1410
[1:1:0711/233142.526433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1410 0x7fd553070070 0xbe84d746de0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1385 0x7fd553070070 0xbe84d0f5260 
[1:1:0711/233142.645146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1391, 7fd5559b5881
[1:1:0711/233142.673805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1373 0x7fd553070070 0xbe846b7ef60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.674127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1373 0x7fd553070070 0xbe846b7ef60 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.674555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.675217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , , () {
                _this.obj.each(function (o) {
                    var sdt = parseInt($(this).at
[1:1:0711/233142.675492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.685622:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 280, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233142.685831:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 280
[1:1:0711/233142.686209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1413
[1:1:0711/233142.686422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7fd553070070 0xbe846ff8e60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1391 0x7fd553070070 0xbe84d6b1ce0 
[1:1:0711/233142.734466:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1404, 7fd5559b5881
[1:1:0711/233142.753369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1389 0x7fd553070070 0xbe84d7304e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.753563:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1389 0x7fd553070070 0xbe84d7304e0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.753801:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.754157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233142.754283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.758455:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233142.758564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233142.758740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1416
[1:1:0711/233142.758849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1416 0x7fd553070070 0xbe846b818e0 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1404 0x7fd553070070 0xbe84d371be0 
[1:1:0711/233142.821567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1410, 7fd5559b5881
[1:1:0711/233142.879614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1385 0x7fd553070070 0xbe84d0f5260 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.879944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1385 0x7fd553070070 0xbe84d0f5260 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.880389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.880991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0711/233142.881168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.881890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15257e9629c8, 0xbe846dbc150
[1:1:0711/233142.882046:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 100
[1:1:0711/233142.882445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1425
[1:1:0711/233142.882636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7fd553070070 0xbe84d3e7660 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1410 0x7fd553070070 0xbe84d746de0 
[1:1:0711/233142.884190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1416, 7fd5559b5881
[1:1:0711/233142.941276:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b3700902860","ptid":"1404 0x7fd553070070 0xbe84d371be0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.941588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://2.fengniao.com/","ptid":"1404 0x7fd553070070 0xbe84d371be0 ","rf":"5:3_https://2.fengniao.com/"}
[1:1:0711/233142.941948:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://2.fengniao.com/secforum/4006472.html"
[1:1:0711/233142.942661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://2.fengniao.com/, 1b3700902860, , slideValue, () {
            ctxPoint.translate(-170, -170);
            ctxPoint.clearRect(0, 0, pointer.width,
[1:1:0711/233142.942850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://2.fengniao.com/secforum/4006472.html", "2.fengniao.com", 3, 1, , , 0
[1:1:0711/233142.946710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x15257e9629c8, 0xbe846dbc158
[1:1:0711/233142.946877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://2.fengniao.com/secforum/4006472.html", 0
[1:1:0711/233142.947271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://2.fengniao.com/, 1427
[1:1:0711/233142.947464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1427 0x7fd553070070 0xbe84d3d7b60 , 5:3_https://2.fengniao.com/, 1, -5:3_https://2.fengniao.com/, 1416 0x7fd553070070 0xbe846b818e0 
