[0712/235258.423723:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/235258.423962:INFO:switcher_clone.cc(787)] backtrace rip is 7f52b83dc891
[0712/235259.515013:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/235259.515371:INFO:switcher_clone.cc(787)] backtrace rip is 7f2a52437891
[1:1:0712/235259.527019:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/235259.527268:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/235259.533060:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/235301.120773:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/235301.121150:INFO:switcher_clone.cc(787)] backtrace rip is 7fa729854891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[23027:23027:0712/235301.316358:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=23027
[23038:23038:0712/235301.316767:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=23038
[22995:22995:0712/235301.365082:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d30fbda7-3dd1-4be1-a94c-4bd5257f7ffd
[22995:22995:0712/235301.959882:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[22995:23025:0712/235301.961234:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/235301.961631:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/235301.961841:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/235301.962461:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/235301.962629:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/235301.965408:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x29377ecc, 1
[1:1:0712/235301.965735:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21354271, 0
[1:1:0712/235301.965894:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3fa78dd5, 3
[1:1:0712/235301.966050:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1004c8ac, 2
[1:1:0712/235301.966270:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 71423521 ffffffcc7e3729 ffffffacffffffc80410 ffffffd5ffffff8dffffffa73f , 10104, 4
[1:1:0712/235301.967250:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22995:23025:0712/235301.967484:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGqB5!�~7)��Ս�?L��
[22995:23025:0712/235301.967549:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is qB5!�~7)��Ս�?(�L��
[1:1:0712/235301.967476:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a506720a0, 3
[1:1:0712/235301.967656:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a507fd080, 2
[22995:23025:0712/235301.967840:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/235301.967804:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a3a4c0d20, -2
[22995:23025:0712/235301.967907:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 23048, 4, 71423521 cc7e3729 acc80410 d58da73f 
[1:1:0712/235301.986660:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/235301.987807:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1004c8ac
[1:1:0712/235301.989356:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1004c8ac
[1:1:0712/235301.992133:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1004c8ac
[1:1:0712/235301.994762:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235301.995069:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235301.995378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235301.995722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235301.996832:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1004c8ac
[1:1:0712/235301.997401:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a524377ba
[1:1:0712/235301.997646:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a5242edef, 7f2a5243777a, 7f2a524390cf
[1:1:0712/235302.007562:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1004c8ac
[1:1:0712/235302.008139:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1004c8ac
[1:1:0712/235302.009416:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1004c8ac
[1:1:0712/235302.013011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235302.013347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235302.013686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235302.013994:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1004c8ac
[1:1:0712/235302.016231:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1004c8ac
[1:1:0712/235302.016868:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a524377ba
[1:1:0712/235302.017092:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a5242edef, 7f2a5243777a, 7f2a524390cf
[1:1:0712/235302.020422:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/235302.020725:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/235302.020820:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffcae01958, 0x7fffcae018d8)
[1:1:0712/235302.034041:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/235302.039652:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[22995:22995:0712/235302.595316:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22995:22995:0712/235302.596709:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22995:23007:0712/235302.617013:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[22995:23007:0712/235302.617267:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[22995:22995:0712/235302.617641:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[22995:22995:0712/235302.617741:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[22995:22995:0712/235302.617895:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,23048, 4
[1:7:0712/235302.620089:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[22995:23019:0712/235302.652374:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/235302.688765:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3d8aaed5220
[1:1:0712/235302.689015:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/235303.031061:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/235304.553888:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/235304.557335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[22995:22995:0712/235304.593565:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[22995:22995:0712/235304.593627:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/235305.666327:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/235305.846133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/235305.846466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235305.863627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/235305.863894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235306.050979:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/235306.051252:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235306.378148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235306.387908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/235306.388159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235306.406747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235306.417556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/235306.417876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235306.430312:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/235306.434004:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3d8aaed3e20
[1:1:0712/235306.434779:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[22995:22995:0712/235306.435678:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[22995:22995:0712/235306.453422:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[22995:22995:0712/235306.485203:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[22995:22995:0712/235306.485361:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/235306.498197:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[22995:22995:0712/235306.505843:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/235307.457485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f2a3c09b2e0 0x3d8ab158660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235307.458945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/235307.459224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235307.460763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235307.541288:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3d8aaed4820
[1:1:0712/235307.542660:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[22995:22995:0712/235307.543051:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[22995:22995:0712/235307.553810:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/235307.564465:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/235307.564705:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[22995:22995:0712/235307.575122:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[22995:22995:0712/235307.587043:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22995:22995:0712/235307.588409:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22995:22995:0712/235307.592429:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[22995:22995:0712/235307.592530:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[22995:22995:0712/235307.592610:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,23048, 4
[22995:23007:0712/235307.594019:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[22995:23007:0712/235307.594074:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/235307.596206:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/235308.092230:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/235308.381686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f2a3c09b2e0 0x3d8aaf8ae60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/235308.382726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08c979641f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/235308.382948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/235308.383734:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[22995:22995:0712/235308.528326:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[22995:22995:0712/235308.528427:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/235308.539289:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[22995:22995:0712/235308.600723:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[22995:23025:0712/235308.601126:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/235308.601351:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/235308.601555:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/235308.601956:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/235308.602094:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/235308.605234:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3faf1576, 1
[1:1:0712/235308.605574:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1987c31f, 0
[1:1:0712/235308.605727:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x22193c7b, 3
[1:1:0712/235308.605869:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2927eda9, 2
[1:1:0712/235308.606008:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1fffffffc3ffffff8719 7615ffffffaf3f ffffffa9ffffffed2729 7b3c1922 , 10104, 5
[1:1:0712/235308.607033:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22995:23025:0712/235308.607286:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGÇv�?��'){<"ĸ
[22995:23025:0712/235308.607362:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Çv�?��'){<"8Nĸ
[1:1:0712/235308.607477:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a506720a0, 3
[22995:23025:0712/235308.607634:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 23092, 5, 1fc38719 7615af3f a9ed2729 7b3c1922 
[1:1:0712/235308.607663:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a507fd080, 2
[1:1:0712/235308.607834:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a3a4c0d20, -2
[1:1:0712/235308.629409:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/235308.629756:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2927eda9
[1:1:0712/235308.630056:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2927eda9
[1:1:0712/235308.630727:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2927eda9
[1:1:0712/235308.632131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.632343:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.632518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.632691:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.633377:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2927eda9
[1:1:0712/235308.633659:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a524377ba
[1:1:0712/235308.633789:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a5242edef, 7f2a5243777a, 7f2a524390cf
[1:1:0712/235308.640076:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2927eda9
[1:1:0712/235308.640553:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2927eda9
[1:1:0712/235308.641287:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2927eda9
[1:1:0712/235308.642004:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.642125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.642381:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.642622:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2927eda9
[1:1:0712/235308.644148:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2927eda9
[1:1:0712/235308.644636:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a524377ba
[1:1:0712/235308.644807:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a5242edef, 7f2a5243777a, 7f2a524390cf
[1:1:0712/235308.648037:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/235308.648398:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/235308.648492:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffcae01958, 0x7fffcae018d8)
[1:1:0712/235308.660734:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/235308.665906:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/235308.901400:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/235308.940316:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3d8aaea0220
[1:1:0712/235308.940468:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[22995:22995:0712/235309.549828:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[22995:22995:0712/235309.549966:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0712/235309.564414:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.564677:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.564836:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.564992:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.565148:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.565301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.565507:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.565668:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.565848:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.566004:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.566166:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.566321:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.566672:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.567014:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.567339:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.567691:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.568050:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.568374:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.568712:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.569059:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.569380:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.569747:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.570097:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.570466:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.570809:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.571154:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.571494:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.571831:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.572192:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.572543:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.572876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.573203:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.573557:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.573893:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.574234:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.574584:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.574951:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.575302:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.575655:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.575994:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.576336:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.576675:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/235309.662775:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/235309.701056:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/235309.701342:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/235310.181535:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/235310.235908:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/235310.236065:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/235310.255283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f2a3a173070 0x3d8aaea4360 , "chrome-error://chromewebdata/"
[1:1:0712/235310.257037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f2a3a173070 0x3d8aaea4360 , "chrome-error://chromewebdata/"
[1:1:0712/235310.258787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f2a3a173070 0x3d8aaea4360 , "chrome-error://chromewebdata/"
[1:1:0712/235310.264560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f2a3a173070 0x3d8aaea4360 , "chrome-error://chromewebdata/"
[1:1:0712/235310.324578:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0885241, 81, 1
[1:1:0712/235310.324755:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3:3:0712/235310.637602:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/235311.138112:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/235311.138382:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/235311.140124:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f2a3a173070 0x3d8aaffeae0 , "chrome-error://chromewebdata/"
[1:1:0712/235311.146883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f2a3a173070 0x3d8aaffeae0 , "chrome-error://chromewebdata/"
[1:1:0712/235311.151330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f2a3a173070 0x3d8aaffeae0 , "chrome-error://chromewebdata/"
[1:1:0712/235311.192546:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f2a3a173070 0x3d8aaffeae0 , "chrome-error://chromewebdata/"
[1:1:0712/235311.200957:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f2a3a173070 0x3d8aaffeae0 , "chrome-error://chromewebdata/"
[1:1:0712/235311.297343:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/235311.302814:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/235311.838134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/235311.876602:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/235311.891254:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/235311.905145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0712/235311.996411:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/235311.996673:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[22995:22995:0712/235311.998662:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
