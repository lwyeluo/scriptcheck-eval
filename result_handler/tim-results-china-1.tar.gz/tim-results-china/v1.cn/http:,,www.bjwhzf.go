[0713/000005.090381:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/000005.090931:INFO:switcher_clone.cc(787)] backtrace rip is 7fbdcefcb891
[0713/000006.058620:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/000006.059051:INFO:switcher_clone.cc(787)] backtrace rip is 7fda4862b891
[1:1:0713/000006.070711:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/000006.070999:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/000006.082531:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[24020:24020:0713/000007.303736:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/27c49c3c-56f9-4540-98ce-480b8f3982ac
[0713/000007.530957:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/000007.531365:INFO:switcher_clone.cc(787)] backtrace rip is 7efc30422891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[24051:24051:0713/000007.720092:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=24051
[24064:24064:0713/000007.720550:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=24064
[24020:24020:0713/000007.901792:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[24020:24049:0713/000007.902601:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/000007.902792:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/000007.903006:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/000007.903605:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/000007.903751:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/000007.906604:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x19b62d12, 1
[1:1:0713/000007.906938:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f19b42a, 0
[1:1:0713/000007.907132:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2fcad050, 3
[1:1:0713/000007.907323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x12e7f71a, 2
[1:1:0713/000007.907559:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2affffffb4191f 122dffffffb619 1afffffff7ffffffe712 50ffffffd0ffffffca2f , 10104, 4
[1:1:0713/000007.908522:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[24020:24049:0713/000007.908976:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING*�-���P��/�n�
[1:1:0713/000007.908858:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda468660a0, 3
[24020:24049:0713/000007.909101:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is *�-���P��/Ŷn�
[1:1:0713/000007.909107:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda469f1080, 2
[1:1:0713/000007.909317:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda306b4d20, -2
[24020:24049:0713/000007.909716:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[24020:24049:0713/000007.909933:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 24072, 4, 2ab4191f 122db619 1af7e712 50d0ca2f 
[1:1:0713/000007.928052:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/000007.928929:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12e7f71a
[1:1:0713/000007.929879:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12e7f71a
[1:1:0713/000007.931532:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12e7f71a
[1:1:0713/000007.933724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.934011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.934335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.934641:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.935584:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12e7f71a
[1:1:0713/000007.935961:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda4862b7ba
[1:1:0713/000007.936182:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda48622def, 7fda4862b77a, 7fda4862d0cf
[1:1:0713/000007.942057:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12e7f71a
[1:1:0713/000007.942615:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12e7f71a
[1:1:0713/000007.943690:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12e7f71a
[1:1:0713/000007.946617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.946909:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.947190:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.947514:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e7f71a
[1:1:0713/000007.949319:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12e7f71a
[1:1:0713/000007.949863:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda4862b7ba
[1:1:0713/000007.950072:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda48622def, 7fda4862b77a, 7fda4862d0cf
[1:1:0713/000007.960108:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/000007.960586:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/000007.960853:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8e0d20f8, 0x7fff8e0d2078)
[1:1:0713/000007.979561:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/000007.985326:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[24020:24020:0713/000008.583035:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[24020:24020:0713/000008.584157:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[24020:24031:0713/000008.594951:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[24020:24020:0713/000008.595051:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[24020:24031:0713/000008.595061:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[24020:24020:0713/000008.595114:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[24020:24020:0713/000008.595212:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,24072, 4
[1:7:0713/000008.598812:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[24020:24043:0713/000008.651927:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/000008.712886:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x5d335483220
[1:1:0713/000008.713121:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/000009.204716:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[24020:24020:0713/000010.808543:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[24020:24020:0713/000010.808660:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/000010.833206:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/000010.836617:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000011.523557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/000011.523867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000011.554071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/000011.554358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000011.584809:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/000011.915185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/000011.915489:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000012.171454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000012.179587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/000012.179867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000012.214800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000012.225315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/000012.225620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000012.237284:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/000012.241129:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5d335481e20
[24020:24020:0713/000012.241342:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/000012.241331:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[24020:24020:0713/000012.255676:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[24020:24020:0713/000012.282950:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[24020:24020:0713/000012.283113:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/000012.340291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000013.217515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fda3228f2e0 0x5d3356c5a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000013.218885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/000013.219086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000013.220604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[24020:24020:0713/000013.290309:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/000013.293476:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x5d335482820
[1:1:0713/000013.293672:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[24020:24020:0713/000013.297337:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/000013.316306:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/000013.316546:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[24020:24020:0713/000013.317718:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[24020:24020:0713/000013.330310:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[24020:24020:0713/000013.331367:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[24020:24031:0713/000013.337570:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[24020:24031:0713/000013.337662:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[24020:24020:0713/000013.337852:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[24020:24020:0713/000013.337932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[24020:24020:0713/000013.338078:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,24072, 4
[1:7:0713/000013.346576:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/000013.861270:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/000014.297315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fda3228f2e0 0x5d3352c0b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000014.298415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 044eea7e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/000014.298666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/000014.299502:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/000014.348942:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[24020:24020:0713/000014.350243:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[24020:24020:0713/000014.350339:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/000014.652325:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/000014.967715:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/000014.968024:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[24020:24020:0713/000015.006194:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[24020:24049:0713/000015.006761:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/000015.006948:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/000015.007208:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/000015.007663:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/000015.007845:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/000015.010889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2cb733b, 1
[1:1:0713/000015.011295:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x278ce02e, 0
[1:1:0713/000015.011499:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x14ed9817, 3
[1:1:0713/000015.011705:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e17ddf4, 2
[1:1:0713/000015.011893:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2effffffe0ffffff8c27 3b73ffffffcb02 fffffff4ffffffdd173e 17ffffff98ffffffed14 , 10104, 5
[1:1:0713/000015.013194:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[24020:24049:0713/000015.013511:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING.��';s���>��1r�
[24020:24049:0713/000015.013595:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is .��';s���>��(�1r�
[1:1:0713/000015.013499:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda468660a0, 3
[1:1:0713/000015.013721:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda469f1080, 2
[24020:24049:0713/000015.013866:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 24116, 5, 2ee08c27 3b73cb02 f4dd173e 1798ed14 
[1:1:0713/000015.013964:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda306b4d20, -2
[1:1:0713/000015.037473:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/000015.037866:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e17ddf4
[1:1:0713/000015.038285:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e17ddf4
[1:1:0713/000015.038953:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e17ddf4
[1:1:0713/000015.040416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.040660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.040891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.041121:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.041833:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e17ddf4
[1:1:0713/000015.042164:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda4862b7ba
[1:1:0713/000015.042418:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda48622def, 7fda4862b77a, 7fda4862d0cf
[1:1:0713/000015.048903:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e17ddf4
[1:1:0713/000015.049464:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e17ddf4
[1:1:0713/000015.050472:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e17ddf4
[1:1:0713/000015.052695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.053007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.053324:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.053614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e17ddf4
[1:1:0713/000015.055044:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e17ddf4
[1:1:0713/000015.055496:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda4862b7ba
[1:1:0713/000015.055687:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda48622def, 7fda4862b77a, 7fda4862d0cf
[1:1:0713/000015.064901:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/000015.065572:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/000015.065767:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8e0d20f8, 0x7fff8e0d2078)
[1:1:0713/000015.082017:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/000015.086204:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/000015.232941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/000015.238633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 044eea90e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/000015.238997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/000015.247762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/000015.356434:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5d335464220
[1:1:0713/000015.356756:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[24020:24020:0713/000015.835962:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[24020:24020:0713/000015.836083:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0713/000015.874558:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.874981:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.875305:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.875704:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.876020:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.876329:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.876676:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.877020:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.877360:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.877701:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.878006:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.878364:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.878776:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.879150:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.879527:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.879863:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.880212:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.880565:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.880888:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.881209:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.881588:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.881913:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.882289:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.882619:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.882951:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.883258:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.883604:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.883920:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.884258:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.884605:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.884936:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.885269:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.885605:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.885907:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.886237:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.886632:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.886966:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.887301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.887620:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.887927:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.888259:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000015.888682:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/000016.022233:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/000016.044694:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/000016.569328:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/000016.569599:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/000016.627450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7fda30367070 0x5d335477060 , "chrome-error://chromewebdata/"
[1:1:0713/000016.631556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7fda30367070 0x5d335477060 , "chrome-error://chromewebdata/"
[1:1:0713/000016.635881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7fda30367070 0x5d335477060 , "chrome-error://chromewebdata/"
[1:1:0713/000016.650075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7fda30367070 0x5d335477060 , "chrome-error://chromewebdata/"
[1:1:0713/000016.698307:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.128577, 81, 1
[1:1:0713/000016.698572:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3:3:0713/000016.927624:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/000017.441992:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/000017.442260:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0713/000017.444032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fda30367070 0x5d335532a60 , "chrome-error://chromewebdata/"
[1:1:0713/000017.451111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fda30367070 0x5d335532a60 , "chrome-error://chromewebdata/"
[1:1:0713/000017.455905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fda30367070 0x5d335532a60 , "chrome-error://chromewebdata/"
[1:1:0713/000017.491191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fda30367070 0x5d335532a60 , "chrome-error://chromewebdata/"
[1:1:0713/000017.497051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fda30367070 0x5d335532a60 , "chrome-error://chromewebdata/"
[1:1:0713/000017.608601:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/000017.613313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0713/000018.345650:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/000018.360024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/000018.372243:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0713/000018.384048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0713/000018.457722:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/000018.457974:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[24020:24020:0713/000102.937030:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[24020:24020:0713/000102.971174:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
