[0711/120727.035338:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/120727.035669:INFO:switcher_clone.cc(787)] backtrace rip is 7f58a8bee891
[0711/120728.059949:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/120728.060396:INFO:switcher_clone.cc(787)] backtrace rip is 7f259bbb8891
[1:1:0711/120728.075847:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/120728.076370:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/120728.083984:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[55357:55357:0711/120729.325458:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2a119e3a-6659-4654-91b9-7b83a3fa2680
[0711/120729.590471:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/120729.590810:INFO:switcher_clone.cc(787)] backtrace rip is 7f096046a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[55357:55357:0711/120730.171611:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[55357:55388:0711/120730.176878:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/120730.177455:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/120730.178105:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/120730.179178:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/120730.179565:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/120730.182528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfcc4bf9, 1
[1:1:0711/120730.182775:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3e3eb58b, 0
[1:1:0711/120730.182916:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xfe944fb, 3
[1:1:0711/120730.183019:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f8145e9, 2
[1:1:0711/120730.183123:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8bffffffb53e3e fffffff94bffffffcc0f ffffffe945ffffff811f fffffffb44ffffffe90f , 10104, 4
[1:1:0711/120730.183748:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[55357:55388:0711/120730.184003:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��>>�K��E��D�Z�'
[1:1:0711/120730.183990:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599df30a0, 3
[1:1:0711/120730.184113:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599f7e080, 2
[55357:55388:0711/120730.184086:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��>>�K��E��D�XMZ�'
[1:1:0711/120730.184202:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2583c41d20, -2
[55357:55388:0711/120730.184494:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[55357:55388:0711/120730.184557:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 55403, 4, 8bb53e3e f94bcc0f e945811f fb44e90f 
[1:1:0711/120730.195429:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/120730.196270:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f8145e9
[1:1:0711/120730.197283:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f8145e9
[1:1:0711/120730.199608:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f8145e9
[1:1:0711/120730.201227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.201416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.201601:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.201804:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.202477:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f8145e9
[1:1:0711/120730.202803:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120730.203022:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[1:1:0711/120730.209527:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f8145e9
[1:1:0711/120730.209923:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f8145e9
[1:1:0711/120730.210648:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f8145e9
[1:1:0711/120730.212679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.212903:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.213091:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.213273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f8145e9
[1:1:0711/120730.214802:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f8145e9
[1:1:0711/120730.215165:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120730.215298:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[1:1:0711/120730.223428:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/120730.224002:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/120730.224146:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff3e2d9538, 0x7fff3e2d94b8)
[1:1:0711/120730.250937:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/120730.256960:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[55390:55390:0711/120730.258436:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=55390
[55411:55411:0711/120730.262392:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=55411
[55357:55357:0711/120731.156173:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55357:55357:0711/120731.157389:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[55357:55357:0711/120731.177917:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[55357:55357:0711/120731.177965:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[55357:55357:0711/120731.178054:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,55403, 4
[55357:55369:0711/120731.182060:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[55357:55369:0711/120731.182107:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/120731.183741:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/120731.355289:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x36c01b4a3220
[1:1:0711/120731.355576:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/120731.674113:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[55357:55357:0711/120733.266347:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[55357:55357:0711/120733.266461:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/120733.298897:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/120733.303227:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/120734.183507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e8a2b2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/120734.183690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/120734.188853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e8a2b2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/120734.189051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/120734.198940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[55357:55357:0711/120734.214675:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[55357:55388:0711/120734.215112:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/120734.215320:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/120734.215538:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/120734.215931:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/120734.216108:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/120734.219566:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2bc39a13, 1
[1:1:0711/120734.220042:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3de5a02b, 0
[1:1:0711/120734.220239:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb84e2c8, 3
[1:1:0711/120734.220442:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3f916eb4, 2
[1:1:0711/120734.220633:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2bffffffa0ffffffe53d 13ffffff9affffffc32b ffffffb46effffff913f ffffffc8ffffffe2ffffff840b , 10104, 5
[1:1:0711/120734.221891:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[55357:55388:0711/120734.222157:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING+��=��+�n�?���[�'
[55357:55388:0711/120734.222237:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is +��=��+�n�?����[�'
[55357:55388:0711/120734.222518:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 55452, 5, 2ba0e53d 139ac32b b46e913f c8e2840b 
[1:1:0711/120734.222904:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599df30a0, 3
[1:1:0711/120734.223134:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599f7e080, 2
[1:1:0711/120734.223350:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2583c41d20, -2
[1:1:0711/120734.249167:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/120734.249520:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f916eb4
[1:1:0711/120734.249947:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f916eb4
[1:1:0711/120734.250697:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f916eb4
[1:1:0711/120734.252454:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.252709:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.252951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.253166:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.254033:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f916eb4
[1:1:0711/120734.254397:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120734.254578:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[1:1:0711/120734.261493:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f916eb4
[1:1:0711/120734.261955:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f916eb4
[1:1:0711/120734.262866:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f916eb4
[1:1:0711/120734.265386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.265647:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.265980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.266203:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f916eb4
[1:1:0711/120734.267736:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f916eb4
[1:1:0711/120734.267979:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120734.268084:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[1:1:0711/120734.270202:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/120734.270445:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/120734.270529:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff3e2d9538, 0x7fff3e2d94b8)
[1:1:0711/120734.281769:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/120734.287230:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/120734.454587:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36c01b4a1220
[1:1:0711/120734.454781:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/120734.465925:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/120734.466106:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[55357:55357:0711/120734.935055:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[55357:55357:0711/120734.969612:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[55357:55388:0711/120734.970086:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/120734.970308:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/120734.970505:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/120734.970891:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/120734.971063:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/120734.974060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x361afda6, 1
[1:1:0711/120734.974352:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d8157c3, 0
[1:1:0711/120734.974538:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xff43678, 3
[1:1:0711/120734.974715:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1afe68a7, 2
[1:1:0711/120734.974872:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc357ffffff812d ffffffa6fffffffd1a36 ffffffa768fffffffe1a 7836fffffff40f , 10104, 6
[1:1:0711/120734.975830:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[55357:55388:0711/120734.976117:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�W�-��6�h�x6�JZ�'
[55357:55388:0711/120734.976184:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �W�-��6�h�x6�XJZ�'
[55357:55388:0711/120734.976414:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 55465, 6, c357812d a6fd1a36 a768fe1a 7836f40f 
[1:1:0711/120734.976705:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599df30a0, 3
[1:1:0711/120734.976890:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2599f7e080, 2
[1:1:0711/120734.977245:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2583c41d20, -2
[1:1:0711/120734.999255:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/120734.999568:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1afe68a7
[1:1:0711/120734.999812:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1afe68a7
[1:1:0711/120735.000519:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1afe68a7
[1:1:0711/120735.002112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.002311:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.002498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.002676:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.003376:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1afe68a7
[1:1:0711/120735.003663:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120735.003797:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[55357:55357:0711/120735.004159:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/120735.010223:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1afe68a7
[1:1:0711/120735.010576:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1afe68a7
[1:1:0711/120735.011322:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1afe68a7
[1:1:0711/120735.013459:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.013675:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.013875:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.014080:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1afe68a7
[1:1:0711/120735.015316:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1afe68a7
[1:1:0711/120735.015682:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f259bbb87ba
[1:1:0711/120735.015815:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f259bbafdef, 7f259bbb877a, 7f259bbba0cf
[1:1:0711/120735.016241:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/120735.022209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e8a2b2c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/120735.022461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/120735.023792:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/120735.024218:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/120735.024374:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff3e2d9538, 0x7fff3e2d94b8)
[55357:55369:0711/120735.032940:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[55357:55369:0711/120735.033060:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[1:1:0711/120735.036367:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[55357:55357:0711/120735.038328:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://passport.ganji.com/
[55357:55357:0711/120735.038379:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://passport.ganji.com/, https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php, 1
[55357:55357:0711/120735.038440:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://passport.ganji.com/, HTTP/1.1 200 OK Server: Tengine Date: Thu, 11 Jul 2019 19:07:34 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,0, 6
[1:1:0711/120735.041198:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/120735.042597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 369, "chrome-search://local-ntp/local-ntp.html"
[3:3:0711/120735.046506:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/120735.047961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0e8a2b2c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/120735.048212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/120735.060933:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/120735.071276:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36c01b4a1e20
[1:1:0711/120735.071477:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:7:0711/120735.093833:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[55357:55357:0711/120735.100312:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[55357:55357:0711/120735.103331:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[55357:55357:0711/120735.144553:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[55357:55357:0711/120735.144758:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[55357:55357:0711/120735.156743:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/120735.162735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/120735.271401:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36c01b4b1220
[1:1:0711/120735.271563:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/120735.335134:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://passport.ganji.com/
[55357:55357:0711/120735.570095:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://passport.ganji.com/, https://passport.ganji.com/, 1
[55357:55357:0711/120735.570599:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://passport.ganji.com/, https://passport.ganji.com
[1:1:0711/120735.575977:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/120735.713675:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/120735.757853:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/120735.758072:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120735.773292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 122 0x7f25838f4070 0x36c01b481a60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120735.776706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , window.__GJ_PACK_CONFIG__ = {"documentDomain":"ganji.com","debug":false,"useCombine":true,"addVersio
[1:1:0711/120735.776957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "passport.ganji.com", 3, 1, , , 0
[1:1:0711/120735.779464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/120735.928680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/120736.062764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151 0x7f2583c5cbd0 0x36c01b5a6158 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.073202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * Ganji UI Library基础模块.
 * 使用全局变量GJ作为命名空间，用以包装最�
[1:1:0711/120736.073443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "passport.ganji.com", 3, 1, , , 0
		remove user.e_7b3d499c -> 0
[1:1:0711/120736.190184:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "passport.ganji.com", "ganji.com"
[1:1:0711/120736.198106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324960
[1:1:0711/120736.198226:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120736.198492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 162
[1:1:0711/120736.198612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 162 0x7f25838f4070 0x36c01b6e4660 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 151 0x7f2583c5cbd0 0x36c01b5a6158 
[1:1:0711/120736.205171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324960
[1:1:0711/120736.205361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120736.205549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 163
[1:1:0711/120736.205661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 163 0x7f25838f4070 0x36c01b6e4a60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 151 0x7f2583c5cbd0 0x36c01b5a6158 
[1:1:0711/120736.213794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151 0x7f2583c5cbd0 0x36c01b5a6158 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.251376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324998
[1:1:0711/120736.251558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120736.251757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 168
[1:1:0711/120736.251863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 168 0x7f25838f4070 0x36c01b7985e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 151 0x7f2583c5cbd0 0x36c01b5a6158 
[1:1:0711/120736.267905:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.054986, 133, 1
[1:1:0711/120736.268104:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/120736.370249:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/120736.370422:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.371608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f25838f4070 0x36c01b7d0c60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.374825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , !function(t){function e(o){if(n[o]){return n[o].exports}var i=n[o]={exports:{},id:o,loaded:!1};retur
[1:1:0711/120736.375059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.382661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f25838f4070 0x36c01b7d0c60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.389381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b3249a0
[1:1:0711/120736.389495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120736.389685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 185
[1:1:0711/120736.389792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 185 0x7f25838f4070 0x36c01b7d0d60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 173 0x7f25838f4070 0x36c01b7d0c60 
[1:1:0711/120736.396990:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.681091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 162, 7f2586239881
[1:1:0711/120736.687399:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"151 0x7f2583c5cbd0 0x36c01b5a6158 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.687701:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"151 0x7f2583c5cbd0 0x36c01b5a6158 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.688046:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.688677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120736.688905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.693637:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 163, 7f2586239881
[1:1:0711/120736.700105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"151 0x7f2583c5cbd0 0x36c01b5a6158 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.700405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"151 0x7f2583c5cbd0 0x36c01b5a6158 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.700751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.701451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120736.701664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.792232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.793040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , onCSSLoad, () {
                clearTimeout(timer);
                eventList.push([-(startTime - new Date),
[1:1:0711/120736.793253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.797188:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324a10
[1:1:0711/120736.797398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120736.797951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 205
[1:1:0711/120736.798176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 205 0x7f25838f4070 0x36c01b7ff860 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 198 0x7f258581c2e0 0x36c01b7f15e0 
[1:1:0711/120736.807908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 201 0x7f258581c2e0 0x36c01b6e4860 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.810786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('app/ms_v2/common/base_page.js', ['jquery', 'app/common/widget/widget.js'], function (require
[1:1:0711/120736.811031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.831654:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120736.831850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120736.832317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 207
[1:1:0711/120736.832563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 207 0x7f25838f4070 0x36c01b598be0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 201 0x7f258581c2e0 0x36c01b6e4860 
[1:1:0711/120736.838187:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120736.838606:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120736.839085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 208
[1:1:0711/120736.839297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 208 0x7f25838f4070 0x36c01b6e44e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 201 0x7f258581c2e0 0x36c01b6e4860 
[1:1:0711/120736.852234:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.895429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 205, 7f2586239881
[1:1:0711/120736.904294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"198 0x7f258581c2e0 0x36c01b7f15e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.904594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"198 0x7f258581c2e0 0x36c01b7f15e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.905032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.905806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120736.906020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120736.907799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120736.908004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120736.908510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 214
[1:1:0711/120736.909624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 214 0x7f25838f4070 0x36c01b7f2c60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 205 0x7f25838f4070 0x36c01b7ff860 
[1:1:0711/120736.980314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 214, 7f2586239881
[1:1:0711/120736.989578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"205 0x7f25838f4070 0x36c01b7ff860 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.989872:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"205 0x7f25838f4070 0x36c01b7ff860 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120736.990217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120736.990872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120736.991086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.038987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f258581c2e0 0x36c01b63ece0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.040244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('app/common/widget/widget.js', ['jquery', 'js/util/event/event_emitter.js'], function (requir
[1:1:0711/120737.040458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.059340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120737.059592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120737.060075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 221
[1:1:0711/120737.060293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 221 0x7f25838f4070 0x36c01b59f6e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 218 0x7f258581c2e0 0x36c01b63ece0 
[1:1:0711/120737.073074:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.167329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f258581c2e0 0x36c01b4f6d60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.169666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/util/event/event_emitter.js', [], function (require, exports, module) {
  // Events
// --
[1:1:0711/120737.169898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.175995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120737.176225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120737.176810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 230
[1:1:0711/120737.177040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 230 0x7f25838f4070 0x36c01b82aa60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 227 0x7f258581c2e0 0x36c01b4f6d60 
[1:1:0711/120737.177644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.241703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 230, 7f2586239881
[1:1:0711/120737.252029:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"227 0x7f258581c2e0 0x36c01b4f6d60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.252333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"227 0x7f258581c2e0 0x36c01b4f6d60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.252844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.253733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120737.254046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.258827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120737.259044:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120737.259522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 238
[1:1:0711/120737.259776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 238 0x7f25838f4070 0x36c01b5ae6e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 230 0x7f25838f4070 0x36c01b82aa60 
[1:1:0711/120737.288017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7f258581c2e0 0x36c01b7f8960 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.304248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /*!
 * jQuery JavaScript Library v1.8.2
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://siz
[1:1:0711/120737.304474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.317905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324948
[1:1:0711/120737.318127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120737.318650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 240
[1:1:0711/120737.318894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 240 0x7f25838f4070 0x36c01b599460 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 236 0x7f258581c2e0 0x36c01b7f8960 
[1:1:0711/120737.319537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.333631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 238, 7f2586239881
[1:1:0711/120737.336948:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"230 0x7f25838f4070 0x36c01b82aa60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.337356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"230 0x7f25838f4070 0x36c01b82aa60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.337770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.338384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120737.338614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.347627:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.348344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , dom_onReady, (){
                if (isRunning) return;
                isRunning = true;
                dom_
[1:1:0711/120737.348573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.349149:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.837289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 240, 7f2586239881
[1:1:0711/120737.848592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"236 0x7f258581c2e0 0x36c01b7f8960 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.848935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"236 0x7f258581c2e0 0x36c01b7f8960 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120737.849300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120737.849956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120737.850167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120737.905461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120737.905783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 1
[1:1:0711/120737.906266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 253
[1:1:0711/120737.906489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f25838f4070 0x36c01b15d6e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 240 0x7f25838f4070 0x36c01b599460 
[1:1:0711/120738.068075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.068344:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.068882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 255
[1:1:0711/120738.069140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 255 0x7f25838f4070 0x36c01b7d0fe0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 240 0x7f25838f4070 0x36c01b599460 
[1:1:0711/120738.069933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.070139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.070676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 256
[1:1:0711/120738.070944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 256 0x7f25838f4070 0x36c01b7f34e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 240 0x7f25838f4070 0x36c01b599460 
[1:1:0711/120738.111889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 253, 7f2586239881
[1:1:0711/120738.116893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.117195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.117546:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.118241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , ready, ( wait ) {

		// Abort if there are pending holds or we're already ready
		if ( wait === true ? --jQ
[1:1:0711/120738.118453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.206625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 255, 7f2586239881
[1:1:0711/120738.217269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.217595:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.217981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.218578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.218822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.231195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 256, 7f2586239881
[1:1:0711/120738.242300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.242607:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"240 0x7f25838f4070 0x36c01b599460 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.242995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.243615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.243851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.245694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.245916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.246406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 265
[1:1:0711/120738.246677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 265 0x7f25838f4070 0x36c01b598be0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 256 0x7f25838f4070 0x36c01b7f34e0 
[1:1:0711/120738.248383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 265, 7f2586239881
[1:1:0711/120738.259509:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"256 0x7f25838f4070 0x36c01b7f34e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.259833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"256 0x7f25838f4070 0x36c01b7f34e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.260179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.260776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.261024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.265040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.265271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.265731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 267
[1:1:0711/120738.265981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 267 0x7f25838f4070 0x36c01b59eae0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 265 0x7f25838f4070 0x36c01b598be0 
[1:1:0711/120738.267755:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 267, 7f2586239881
[1:1:0711/120738.275149:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"265 0x7f25838f4070 0x36c01b598be0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.275429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"265 0x7f25838f4070 0x36c01b598be0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.275779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.276417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.276621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.278419:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.278616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.279118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 269
[1:1:0711/120738.279335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 269 0x7f25838f4070 0x36c01b9313e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 267 0x7f25838f4070 0x36c01b59eae0 
[1:1:0711/120738.294603:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 269, 7f2586239881
[1:1:0711/120738.305996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"267 0x7f25838f4070 0x36c01b59eae0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.306272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"267 0x7f25838f4070 0x36c01b59eae0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.306630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.307369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.307606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.353454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.353711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.354357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 271
[1:1:0711/120738.354595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 271 0x7f25838f4070 0x36c01bd920e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 269 0x7f25838f4070 0x36c01b9313e0 
[1:1:0711/120738.368970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 271, 7f2586239881
[1:1:0711/120738.374677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"269 0x7f25838f4070 0x36c01b9313e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.375008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"269 0x7f25838f4070 0x36c01b9313e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.375374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.375935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.376146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.377889:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.378089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.378550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 275
[1:1:0711/120738.378763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 275 0x7f25838f4070 0x36c01b6342e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 271 0x7f25838f4070 0x36c01bd920e0 
[1:1:0711/120738.392898:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 275, 7f2586239881
[1:1:0711/120738.404336:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"271 0x7f25838f4070 0x36c01bd920e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.404643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"271 0x7f25838f4070 0x36c01bd920e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120738.405142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120738.405764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120738.405997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120738.421983:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.422187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120738.422664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 277
[1:1:0711/120738.422917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 277 0x7f25838f4070 0x36c01b7c0ee0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120738.443860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.444089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120738.444577:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 279
[1:1:0711/120738.444798:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 279 0x7f25838f4070 0x36c01bd92160 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120738.457008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.457268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120738.458071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 282
[1:1:0711/120738.458305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 282 0x7f25838f4070 0x36c01b90bfe0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120738.633092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.633355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120738.633858:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 284
[1:1:0711/120738.634131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 284 0x7f25838f4070 0x36c01b7f4ee0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120738.924934:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.925208:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120738.925712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 287
[1:1:0711/120738.925933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 287 0x7f25838f4070 0x36c01bd91060 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120738.990999:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120738.991274:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120738.991759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 293
[1:1:0711/120738.992017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 293 0x7f25838f4070 0x36c01b15f5e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.000781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.001070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120739.001555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 294
[1:1:0711/120739.001773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 294 0x7f25838f4070 0x36c01b15ebe0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.005254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.005547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120739.006053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 296
[1:1:0711/120739.006390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 296 0x7f25838f4070 0x36c01b15cde0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.018384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.018590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120739.019101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 299
[1:1:0711/120739.019322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 299 0x7f25838f4070 0x36c01b829ae0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.043300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.043537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120739.044090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 302
[1:1:0711/120739.044338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7f25838f4070 0x36c01b7d07e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.058032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.058241:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120739.058712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 304
[1:1:0711/120739.058935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 304 0x7f25838f4070 0x36c01b7f89e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.097514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.097765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120739.098282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 307
[1:1:0711/120739.098533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 307 0x7f25838f4070 0x36c01b59e9e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.110660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.110885:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 3000
[1:1:0711/120739.111395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 309
[1:1:0711/120739.111621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 309 0x7f25838f4070 0x36c01bd942e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.122137:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120739.122391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 200
[1:1:0711/120739.122904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 311
[1:1:0711/120739.123181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 311 0x7f25838f4070 0x36c01b7c0ce0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 275 0x7f25838f4070 0x36c01b6342e0 
[1:1:0711/120739.617328:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/120739.778786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 282, 7f2586239881
[1:1:0711/120739.785841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.786119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.786479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.787143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120739.787372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120739.789336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 299, 7f2586239881
[1:1:0711/120739.794671:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.794945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.795310:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.795888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120739.796104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120739.798015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 311, 7f2586239881
[1:1:0711/120739.802237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.802512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"275 0x7f25838f4070 0x36c01b6342e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120739.802841:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.803578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , (){n.loadJs(u);var _timer1=setInterval(function(){if(t.__fingerprint){t.__fingerprint.init(e);clearI
[1:1:0711/120739.803793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120739.806802:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 1000
[1:1:0711/120739.810292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://passport.ganji.com/, 372
[1:1:0711/120739.810524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7f25838f4070 0x36c01bd90de0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 311 0x7f25838f4070 0x36c01b7c0ce0 
[1:1:0711/120739.896777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7f258581c2e0 0x36c01b59ed60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.899826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 在客户机设置uuid
 *
 * @exclude 不编入文档
 * @module uuid
 * @file js/util/u
[1:1:0711/120739.900061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120739.909253:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.924362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 333 0x7f258581c2e0 0x36c01c08a560 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.926904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/util/jquery/plugin/placeholder/jquery.placeholder.js', ['jquery'], function (require, exp
[1:1:0711/120739.927113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120739.946142:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120739.946368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120739.946868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 375
[1:1:0711/120739.947089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7f25838f4070 0x36c01b930c60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 333 0x7f258581c2e0 0x36c01c08a560 
[1:1:0711/120739.948648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.985620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 335 0x7f258581c2e0 0x36c01b7f4160 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120739.993609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/v6/login/login.js', ['app/ms_v2/common/base_page.js', 'jquery', 'js/app/common/user/user.
[1:1:0711/120739.993832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.027326:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.027560:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.028057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 378
[1:1:0711/120740.028296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7f25838f4070 0x36c01bd937e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.037370:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.037570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.038075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 379
[1:1:0711/120740.038324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 379 0x7f25838f4070 0x36c01b7f8be0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.049638:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.049884:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.050434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 381
[1:1:0711/120740.050693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 381 0x7f25838f4070 0x36c01b8288e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.061418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.062307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.062828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 385
[1:1:0711/120740.063090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 385 0x7f25838f4070 0x36c01c1f8c60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.073016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.073248:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.073778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 387
[1:1:0711/120740.074036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 387 0x7f25838f4070 0x36c01c1d4be0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.095822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.096333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.096844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 391
[1:1:0711/120740.097049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7f25838f4070 0x36c01c1d49e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.102579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.102788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.103274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 392
[1:1:0711/120740.103493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 392 0x7f25838f4070 0x36c01c229460 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.105504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.105753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.106273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 394
[1:1:0711/120740.106500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7f25838f4070 0x36c01c1e59e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 335 0x7f258581c2e0 0x36c01b7f4160 
[1:1:0711/120740.108940:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.120516:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 336 0x7f258581c2e0 0x36c01b7f41e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.122907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/v6/login/wx_scan_login.js', ['app/ms_v2/common/base_page.js', 'jquery', 'js/app/common/us
[1:1:0711/120740.123126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.157010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.157336:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.158022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 400
[1:1:0711/120740.158251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 400 0x7f25838f4070 0x36c01c1e51e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 336 0x7f258581c2e0 0x36c01b7f41e0 
[1:1:0711/120740.161447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.161638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.162118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 401
[1:1:0711/120740.162392:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 401 0x7f25838f4070 0x36c01b15f7e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 336 0x7f258581c2e0 0x36c01b7f41e0 
[1:1:0711/120740.163693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.163882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.164381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 402
[1:1:0711/120740.164600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7f25838f4070 0x36c01bd91860 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 336 0x7f258581c2e0 0x36c01b7f41e0 
[1:1:0711/120740.166118:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.207930:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7f258581c2e0 0x36c01b7f5a60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.209028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 在客户机设置uuid, 本文件是生成脚本
 * 
 * @exclude 不编入文档
 * @module u
[1:1:0711/120740.209307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.221269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.221500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.221986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 408
[1:1:0711/120740.222218:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 408 0x7f25838f4070 0x36c01b15f6e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 338 0x7f258581c2e0 0x36c01b7f5a60 
[1:1:0711/120740.222722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.241637:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f258581c2e0 0x36c01b7f49e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.246613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 日志记录
 * 收集页面信息，通过远程请求保存日志
 * 异步载入的html
[1:1:0711/120740.246828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.277235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324948
[1:1:0711/120740.277526:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.278023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 410
[1:1:0711/120740.278233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7f25838f4070 0x36c01c279160 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 339 0x7f258581c2e0 0x36c01b7f49e0 
[1:1:0711/120740.286907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x4711ae629c8, 0x36c01b324948
[1:1:0711/120740.287127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 30000
[1:1:0711/120740.287638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 411
[1:1:0711/120740.287868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 411 0x7f25838f4070 0x36c01b7f4560 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 339 0x7f258581c2e0 0x36c01b7f49e0 
[1:1:0711/120740.305499:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324948
[1:1:0711/120740.305728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.306367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 415
[1:1:0711/120740.306585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f25838f4070 0x36c01b1602e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 339 0x7f258581c2e0 0x36c01b7f49e0 
[1:1:0711/120740.308443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.333230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7f258581c2e0 0x36c01c08a060 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.337405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/util/iframe/rpc3.js', ['js/util/event/event_emitter.js', 'jquery'], function(require, exp
[1:1:0711/120740.337643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.362284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.362510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.363003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 420
[1:1:0711/120740.363223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 420 0x7f25838f4070 0x36c01c2294e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 341 0x7f258581c2e0 0x36c01c08a060 
[1:1:0711/120740.364696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.364897:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.365409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 421
[1:1:0711/120740.365624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7f25838f4070 0x36c01c2b17e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 341 0x7f258581c2e0 0x36c01c08a060 
[1:1:0711/120740.366651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.404726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7f258581c2e0 0x36c01b7d5b60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.406158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * google相关操作
 * 
 * @module google
 * @file js/app/common/google/google.js
 * @requires
[1:1:0711/120740.406401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.425204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.425466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.425991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 424
[1:1:0711/120740.426215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7f25838f4070 0x36c01c2b1360 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 342 0x7f258581c2e0 0x36c01b7d5b60 
[1:1:0711/120740.427543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.481551:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346 0x7f258581c2e0 0x36c01b59e3e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.482853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add("js/util/log_tracker/check_dnspod.js",[],function(b,a,c){c.exports=function(){var i=window.pe
[1:1:0711/120740.483074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.494695:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.494930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.495437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 426
[1:1:0711/120740.495674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7f25838f4070 0x36c01b7f8de0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 346 0x7f258581c2e0 0x36c01b59e3e0 
[1:1:0711/120740.496138:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.521946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 347 0x7f258581c2e0 0x36c01bd94160 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.524603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 定向推广绑定事件JS
 * @module self_direction
 * @file js/app/self_direction/direction
[1:1:0711/120740.525556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.575874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.576081:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.576559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 428
[1:1:0711/120740.576757:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 428 0x7f25838f4070 0x36c01c2a7f60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 347 0x7f258581c2e0 0x36c01bd94160 
[1:1:0711/120740.582114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120740.582278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.582852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 429
[1:1:0711/120740.583113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 429 0x7f25838f4070 0x36c01b7f5d60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 347 0x7f258581c2e0 0x36c01bd94160 
[1:1:0711/120740.584583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.607847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348 0x7f258581c2e0 0x36c01b15c060 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.613268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , var swfobject=function(){var D="undefined",r="object",S="Shockwave Flash",W="ShockwaveFlash.Shockwav
[1:1:0711/120740.613475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.655358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 349 0x7f258581c2e0 0x36c01b59e5e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.659720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , var CryptoJS=CryptoJS||function(e,m){var p={},j=p.lib={},l=function(){},f=j.Base={extend:function(a)
[1:1:0711/120740.659946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.941226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 375, 7f2586239881
[1:1:0711/120740.947964:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"333 0x7f258581c2e0 0x36c01c08a560 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120740.948158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"333 0x7f258581c2e0 0x36c01c08a560 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120740.948380:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120740.948800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120740.948950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120740.950043:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120740.950179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120740.950488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 437
[1:1:0711/120740.950643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 437 0x7f25838f4070 0x36c01c1eafe0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 375 0x7f25838f4070 0x36c01b930c60 
[1:1:0711/120741.203199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 391, 7f2586239881
[1:1:0711/120741.217674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.217824:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.217990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.218282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.218384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.218964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 392, 7f2586239881
[1:1:0711/120741.223985:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.224121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.224277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.224547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.224654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.225193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 394, 7f2586239881
[1:1:0711/120741.230053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.230191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"335 0x7f258581c2e0 0x36c01b7f4160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.230346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.230658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.230768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.242683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 400, 7f2586239881
[1:1:0711/120741.248955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.249087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.249240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.249484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.249624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.250143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 401, 7f2586239881
[1:1:0711/120741.255799:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.255929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.256082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.256326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.256426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.256968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 402, 7f2586239881
[1:1:0711/120741.262139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.262332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"336 0x7f258581c2e0 0x36c01b7f41e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.262550:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.262859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.262962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.275635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 408, 7f2586239881
[1:1:0711/120741.280587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"338 0x7f258581c2e0 0x36c01b7f5a60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.280720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"338 0x7f258581c2e0 0x36c01b7f5a60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.280878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.281140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.281242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.282826:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.282933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.283125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 457
[1:1:0711/120741.283230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 457 0x7f25838f4070 0x36c01b90b4e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 408 0x7f25838f4070 0x36c01b15f6e0 
[1:1:0711/120741.283639:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.283740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.283918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 458
[1:1:0711/120741.284020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 458 0x7f25838f4070 0x36c01c1deee0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 408 0x7f25838f4070 0x36c01b15f6e0 
[1:1:0711/120741.284344:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.284443:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.284646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 459
[1:1:0711/120741.284754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 459 0x7f25838f4070 0x36c01bd920e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 408 0x7f25838f4070 0x36c01b15f6e0 
[1:1:0711/120741.300351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 415, 7f2586239881
[1:1:0711/120741.305327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"339 0x7f258581c2e0 0x36c01b7f49e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.305458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"339 0x7f258581c2e0 0x36c01b7f49e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.305649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.305915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.306018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.320903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 420, 7f2586239881
[1:1:0711/120741.326041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"341 0x7f258581c2e0 0x36c01c08a060 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.326178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"341 0x7f258581c2e0 0x36c01c08a060 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.326332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.326609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.326715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.327226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 421, 7f2586239881
[1:1:0711/120741.332194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"341 0x7f258581c2e0 0x36c01c08a060 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.332325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"341 0x7f258581c2e0 0x36c01c08a060 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.332479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.332755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.332865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.333541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.333661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.333848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 470
[1:1:0711/120741.333971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7f25838f4070 0x36c01b4f1ee0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 421 0x7f25838f4070 0x36c01c2b17e0 
[1:1:0711/120741.334456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 424, 7f2586239881
[1:1:0711/120741.339447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"342 0x7f258581c2e0 0x36c01b7d5b60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.339600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"342 0x7f258581c2e0 0x36c01b7d5b60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.339764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.340011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.340111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.340785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.340927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.341111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 471
[1:1:0711/120741.341213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f25838f4070 0x36c01c279fe0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 424 0x7f25838f4070 0x36c01c2b1360 
[1:1:0711/120741.352099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 426, 7f2586239881
[1:1:0711/120741.357275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"346 0x7f258581c2e0 0x36c01b59e3e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.357406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"346 0x7f258581c2e0 0x36c01b59e3e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.357586:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.357876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.357980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.359402:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120741.359507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120741.359712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 474
[1:1:0711/120741.359821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7f25838f4070 0x36c01c1e5960 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 426 0x7f25838f4070 0x36c01b7f8de0 
[1:1:0711/120741.360325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 428, 7f2586239881
[1:1:0711/120741.365939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"347 0x7f258581c2e0 0x36c01bd94160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.366072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"347 0x7f258581c2e0 0x36c01bd94160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.366226:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.366472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.366619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.367831:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 429, 7f2586239881
[1:1:0711/120741.372815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"347 0x7f258581c2e0 0x36c01bd94160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.372945:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"347 0x7f258581c2e0 0x36c01bd94160 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.373099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.373346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                            cb.apply( {}, args );
                        }
[1:1:0711/120741.373446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.393282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7f258581c2e0 0x36c01b90d760 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.403247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , (function(window,undefined){if(!Array.prototype.indexOf){Array.prototype.indexOf=function(searchElem
[1:1:0711/120741.403431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120741.411879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://passport.ganji.com/, 372, 7f25862398db
[1:1:0711/120741.429827:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"311 0x7f25838f4070 0x36c01b7c0ce0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.430117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"311 0x7f25838f4070 0x36c01b7c0ce0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120741.430504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://passport.ganji.com/, 477
[1:1:0711/120741.430715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7f25838f4070 0x36c01b90dee0 , 6:3_https://passport.ganji.com/, 0, , 372 0x7f25838f4070 0x36c01bd90de0 
[1:1:0711/120741.430983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120741.431604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , (){if(t.__fingerprint){t.__fingerprint.init(e);clearInterval(_timer1)}}
[1:1:0711/120741.431781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
		remove user.e_289120de -> 0
[1:1:0711/120745.274379:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[55357:55357:0711/120745.388228:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php (0)
[3:3:0711/120745.663565:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/120745.698434:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/120745.713568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120745.713854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 5000
[1:1:0711/120745.714371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 505
[1:1:0711/120745.714595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 505 0x7f25838f4070 0x36c01cdd5060 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 372 0x7f25838f4070 0x36c01bd90de0 
[1:1:0711/120745.729865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f258581c2e0 0x36c01b8299e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.733650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 用户信息与登录注册
 *
 * @module user
 * @file js/app/common/user/user.js
 * @requir
[1:1:0711/120745.735917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120745.764685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120745.764935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120745.765484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 516
[1:1:0711/120745.765729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7f25838f4070 0x36c01c2778e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 436 0x7f258581c2e0 0x36c01b8299e0 
[1:1:0711/120745.767084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.769983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 437, 7f2586239881
[1:1:0711/120745.785953:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"375 0x7f25838f4070 0x36c01b930c60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120745.786244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"375 0x7f25838f4070 0x36c01b930c60 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120745.786607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.787332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120745.787550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120745.798478:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120745.798702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120745.799218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 518
[1:1:0711/120745.799441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f25838f4070 0x36c01c2a7ce0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 437 0x7f25838f4070 0x36c01c1eafe0 
[1:1:0711/120745.861366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7f258581c2e0 0x36c01c2297e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.862795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /*
 * 事件处理
 * 
 * @author chan.jianbin@gmail.com
 * @example
 * var A = function () {}
[1:1:0711/120745.863020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120745.882016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120745.882231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120745.882771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 520
[1:1:0711/120745.882996:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f25838f4070 0x36c01cdebe60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 440 0x7f258581c2e0 0x36c01c2297e0 
[1:1:0711/120745.884346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.910077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 441 0x7f258581c2e0 0x36c01b15d3e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120745.913937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**
 * 表单验证
 *
 * @module json
 * @file js/util/validator/validator-2.js
 * @requires jquery
[1:1:0711/120745.914158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120745.938585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324948
[1:1:0711/120745.938808:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120745.939300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 522
[1:1:0711/120745.939523:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7f25838f4070 0x36c01cde32e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 441 0x7f258581c2e0 0x36c01b15d3e0 
[1:1:0711/120745.940851:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.001907:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 443 0x7f258581c2e0 0x36c01b7f8760 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.005346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , /**

 * Passport
 *
 * @module user
 * @file js/app/common/user/passport.js
 * @requires js/app/comm
[1:1:0711/120746.005588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.024647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120746.024875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.025406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 525
[1:1:0711/120746.025637:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f25838f4070 0x36c01bd93560 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 443 0x7f258581c2e0 0x36c01b7f8760 
[1:1:0711/120746.027040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.053667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f258581c2e0 0x36c01c2a73e0 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.055239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add('js/v6/login/placeholder.js', ['jquery'], function (require, exports, module) {
    var $ = 
[1:1:0711/120746.055459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.062969:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120746.063178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.063671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 527
[1:1:0711/120746.063934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 527 0x7f25838f4070 0x36c01cde5e60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 444 0x7f258581c2e0 0x36c01c2a73e0 
[1:1:0711/120746.065300:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.108327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f258581c2e0 0x36c01c1def60 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.109499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add("js/util/seo/baidu_js_push.js",function(){if((location.href).indexOf("passport.ganji.com")==-
[1:1:0711/120746.109722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.121277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120746.121486:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.122005:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 529
[1:1:0711/120746.122237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7f25838f4070 0x36c01cde0e60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 447 0x7f258581c2e0 0x36c01c1def60 
[1:1:0711/120746.122678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.166568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f258581c2e0 0x36c01bff4160 , "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.167842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , GJ.add("js/util/randomid/random_id.js","jquery",function(){$("body").delegate("a","click",function()
[1:1:0711/120746.168067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.187367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324990
[1:1:0711/120746.187575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.188091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 531
[1:1:0711/120746.188340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7f25838f4070 0x36c01c2b1f60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 448 0x7f258581c2e0 0x36c01bff4160 
[1:1:0711/120746.189514:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.319453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 457, 7f2586239881
[1:1:0711/120746.344306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.344652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.345027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.345771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.346018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.368842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 458, 7f2586239881
[1:1:0711/120746.389253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.389576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.389949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.390562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.390776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.392561:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120746.392752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.393685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 534
[1:1:0711/120746.394063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f25838f4070 0x36c01cde8660 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 458 0x7f25838f4070 0x36c01c1deee0 
[1:1:0711/120746.457948:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 459, 7f2586239881
[1:1:0711/120746.476734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.477160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"408 0x7f25838f4070 0x36c01b15f6e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.477567:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.478307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.478562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.545736:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 470, 7f2586239881
[1:1:0711/120746.566343:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"421 0x7f25838f4070 0x36c01c2b17e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.566846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"421 0x7f25838f4070 0x36c01c2b17e0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.567506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.568686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.569111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.575072:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120746.575368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.575945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 536
[1:1:0711/120746.576251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f25838f4070 0x36c01b6e4860 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 470 0x7f25838f4070 0x36c01b4f1ee0 
[1:1:0711/120746.577183:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120746.577433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.578019:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 537
[1:1:0711/120746.578402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7f25838f4070 0x36c01cdf9560 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 470 0x7f25838f4070 0x36c01b4f1ee0 
[1:1:0711/120746.581174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 471, 7f2586239881
[1:1:0711/120746.603145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"424 0x7f25838f4070 0x36c01c2b1360 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.603441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"424 0x7f25838f4070 0x36c01c2b1360 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.603790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.604439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.604650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.608963:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120746.609163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.609655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 540
[1:1:0711/120746.609901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7f25838f4070 0x36c01cde02e0 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 471 0x7f25838f4070 0x36c01c279fe0 
[1:1:0711/120746.611574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 474, 7f2586239881
[1:1:0711/120746.631495:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2d1e194a2860","ptid":"426 0x7f25838f4070 0x36c01b7f8de0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.631810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://passport.ganji.com/","ptid":"426 0x7f25838f4070 0x36c01b7f8de0 ","rf":"6:3_https://passport.ganji.com/"}
[1:1:0711/120746.632200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120746.632804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , () {
                                fn.apply( {}, args );
                            }
[1:1:0711/120746.633223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120746.636645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4711ae629c8, 0x36c01b324950
[1:1:0711/120746.636870:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", 0
[1:1:0711/120746.637967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://passport.ganji.com/, 542
[1:1:0711/120746.638408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7f25838f4070 0x36c01cdf9b60 , 6:3_https://passport.ganji.com/, 1, -6:3_https://passport.ganji.com/, 474 0x7f25838f4070 0x36c01c1e5960 
[1:1:0711/120746.763366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/120746.763688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
[1:1:0711/120747.140173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "complete", "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php"
[1:1:0711/120747.142920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://passport.ganji.com/, 2d1e194a2860, , context.oncomplete, (evnt){audioData.pxi_output=0;var sha1=CryptoJS.algo.SHA1.create();for(var i=0;i<evnt.renderedBuffer
[1:1:0711/120747.143476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://passport.ganji.com/login.php?next=%2Fvip%2Fmy_favorite_post_list.php", "ganji.com", 3, 1, , , 0
		remove user.f_b0f033a6 -> 0
		remove user.10_76ebe6c6 -> 0
