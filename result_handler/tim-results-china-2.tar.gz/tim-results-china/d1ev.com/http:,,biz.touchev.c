[0713/010050.540483:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010050.540888:INFO:switcher_clone.cc(787)] backtrace rip is 7f0994698891
[0713/010051.504886:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010051.505425:INFO:switcher_clone.cc(787)] backtrace rip is 7f47d0c87891
[1:1:0713/010051.520094:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/010051.520370:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/010051.525506:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[29584:29584:0713/010052.586807:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/71660e11-25de-4265-96ad-8aa98c7c517b
[29584:29584:0713/010052.952500:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[29584:29616:0713/010052.953245:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/010052.953437:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010052.953670:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010052.954250:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010052.954390:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/010052.957166:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25dd0998, 1
[1:1:0713/010052.957510:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25f2a186, 0
[1:1:0713/010052.957717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x37945c, 3
[1:1:0713/010052.957875:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1559a0f6, 2
[1:1:0713/010052.958065:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff86ffffffa1fffffff225 ffffff9809ffffffdd25 fffffff6ffffffa05915 5cffffff943700 , 10104, 4
[1:1:0713/010052.958995:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29584:29616:0713/010052.959207:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���%�	�%��Y\�7
[29584:29616:0713/010052.959277:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���%�	�%��Y\�7
[1:1:0713/010052.959197:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47ceec20a0, 3
[1:1:0713/010052.959408:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47cf04d080, 2
[29584:29616:0713/010052.959584:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/010052.959553:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47b8d10d20, -2
[29584:29616:0713/010052.959719:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29630, 4, 86a1f225 9809dd25 f6a05915 5c943700 
[0713/010052.968448:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010052.968939:INFO:switcher_clone.cc(787)] backtrace rip is 7f5dc331d891
[1:1:0713/010052.973134:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010052.973749:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1559a0f6
[1:1:0713/010052.974394:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1559a0f6
[1:1:0713/010052.975391:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1559a0f6
[1:1:0713/010052.975932:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.976045:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.976139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.976232:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.976449:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1559a0f6
[1:1:0713/010052.976584:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f47d0c877ba
[1:1:0713/010052.976751:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f47d0c7edef, 7f47d0c8777a, 7f47d0c890cf
[1:1:0713/010052.978202:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1559a0f6
[1:1:0713/010052.978368:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1559a0f6
[1:1:0713/010052.978653:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1559a0f6
[1:1:0713/010052.979313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.979428:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.979525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.979636:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1559a0f6
[1:1:0713/010052.980083:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1559a0f6
[1:1:0713/010052.980239:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f47d0c877ba
[1:1:0713/010052.980314:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f47d0c7edef, 7f47d0c8777a, 7f47d0c890cf
[1:1:0713/010052.982512:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010052.982871:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010052.982958:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc633b1108, 0x7ffc633b1088)
[1:1:0713/010052.993539:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010052.999488:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[29619:29619:0713/010053.292591:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29619
[29654:29654:0713/010053.293050:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=29654
[29584:29584:0713/010053.529549:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29584:29584:0713/010053.530927:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29584:29596:0713/010053.543675:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[29584:29584:0713/010053.543788:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[29584:29596:0713/010053.543816:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[29584:29584:0713/010053.543852:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[29584:29584:0713/010053.543955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,29630, 4
[1:7:0713/010053.545712:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010053.592051:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2eba93d9e220
[1:1:0713/010053.592312:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[29584:29609:0713/010053.614301:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/010053.888838:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/010054.972880:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010054.977590:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[29584:29584:0713/010055.833940:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[29584:29584:0713/010055.834049:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010056.012326:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010056.341315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010056.341615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010056.357647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010056.357887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010056.451083:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010056.451357:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010056.711563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010056.717911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010056.718462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010056.807184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010056.819826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010056.820118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010056.832704:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/010056.836829:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2eba93d9ce20
[1:1:0713/010056.837031:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[29584:29584:0713/010056.855447:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[29584:29584:0713/010056.859413:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[29584:29584:0713/010056.906965:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[29584:29584:0713/010056.907122:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010056.954938:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010057.831402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f47ba8eb2e0 0x2eba93ff40e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010057.834406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/010057.834974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010057.838741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[29584:29584:0713/010057.914837:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/010057.916186:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2eba93d9d820
[1:1:0713/010057.916479:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[29584:29584:0713/010057.921687:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/010057.935674:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/010057.935912:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[29584:29584:0713/010057.941949:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[29584:29584:0713/010057.951022:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29584:29584:0713/010057.952065:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29584:29596:0713/010057.957408:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[29584:29584:0713/010057.957455:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[29584:29584:0713/010057.957501:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[29584:29596:0713/010057.957503:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[29584:29584:0713/010057.957632:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,29630, 4
[1:7:0713/010057.960187:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010058.587246:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/010059.167951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f47ba8eb2e0 0x2eba94087560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010059.169141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/010059.170589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010059.172597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[29584:29584:0713/010059.325424:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[29584:29584:0713/010059.325544:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/010059.346043:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/010059.741206:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010100.281296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010100.281582:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010100.692474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010100.695255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36ad083f09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/010100.695578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/010100.703325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[29584:29584:0713/010100.808003:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[29584:29616:0713/010100.808376:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/010100.808602:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010100.808845:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010100.809279:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010100.809453:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/010100.812525:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2bab5b3a, 1
[1:1:0713/010100.812989:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x6556f1b, 0
[1:1:0713/010100.813276:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1899e4f6, 3
[1:1:0713/010100.813504:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8e0ef0b, 2
[1:1:0713/010100.813732:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1b6f5506 3a5bffffffab2b 0bffffffefffffffe008 fffffff6ffffffe4ffffff9918 , 10104, 5
[1:1:0713/010100.815001:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[29584:29616:0713/010100.815294:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGoU:[�+�������?
[29584:29616:0713/010100.815384:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is oU:[�+��������?
[29584:29616:0713/010100.815682:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 29684, 5, 1b6f5506 3a5bab2b 0befe008 f6e49918 
[1:1:0713/010100.815537:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47ceec20a0, 3
[1:1:0713/010100.816270:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47cf04d080, 2
[1:1:0713/010100.816536:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f47b8d10d20, -2
[1:1:0713/010100.841086:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010100.841499:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8e0ef0b
[1:1:0713/010100.841839:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8e0ef0b
[1:1:0713/010100.842503:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8e0ef0b
[1:1:0713/010100.843891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.844144:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.844494:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.844742:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.845531:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8e0ef0b
[1:1:0713/010100.845844:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f47d0c877ba
[1:1:0713/010100.846013:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f47d0c7edef, 7f47d0c8777a, 7f47d0c890cf
[1:1:0713/010100.852174:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8e0ef0b
[1:1:0713/010100.852640:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8e0ef0b
[1:1:0713/010100.853498:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8e0ef0b
[1:1:0713/010100.855656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.855915:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.856164:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.856406:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8e0ef0b
[1:1:0713/010100.857762:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8e0ef0b
[1:1:0713/010100.858210:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f47d0c877ba
[1:1:0713/010100.858390:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f47d0c7edef, 7f47d0c8777a, 7f47d0c890cf
[1:1:0713/010100.866641:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010100.867257:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010100.867462:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc633b1108, 0x7ffc633b1088)
[1:1:0713/010100.881673:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010100.884401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010100.885161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36ad082c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/010100.885389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010100.886086:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/010101.100506:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2eba93d7e220
[1:1:0713/010101.100820:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/010101.198566:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010101.200233:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/010101.200461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36ad083f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/010101.200789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[29584:29584:0713/010101.245071:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[29584:29584:0713/010101.251204:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[29584:29584:0713/010101.292993:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://biz.touchev.com/
[29584:29584:0713/010101.293116:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://biz.touchev.com/, http://biz.touchev.com/guide.php, 1
[29584:29584:0713/010101.293302:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://biz.touchev.com/, HTTP/1.1 200 OK Server: Tengine Date: Sat, 13 Jul 2019 08:01:01 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,29684, 5
[29584:29596:0713/010101.330003:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[29584:29596:0713/010101.330124:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/010101.333308:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010101.359969:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010101.382173:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/010101.382382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36ad083f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/010101.382600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/010101.405414:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://biz.touchev.com/
[1:1:0713/010101.531641:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[29584:29584:0713/010101.535470:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://biz.touchev.com/, http://biz.touchev.com/, 1
[29584:29584:0713/010101.535579:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://biz.touchev.com/, http://biz.touchev.com
[1:1:0713/010101.608067:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010101.660033:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010101.660290:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://biz.touchev.com/guide.php"
[1:1:0713/010101.678097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 119 0x7f47b89c3070 0x2eba93d9b0e0 , "http://biz.touchev.com/guide.php"
[1:1:0713/010101.680140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://biz.touchev.com/, 2de78a1c2860, , , 
document.onclick=function(){
	window.location.href='./guide.php?step=2';
};

[1:1:0713/010101.680373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://biz.touchev.com/guide.php", "biz.touchev.com", 3, 1, , , 0
[1:1:0713/010101.712713:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0713/010102.408645:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0713/010102.482389:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://qq.com/"
[1:1:0713/010102.536035:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://ikea.com/"
[1:1:0713/010102.611072:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0713/010102.699228:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0713/010102.739324:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0713/010102.841017:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.alibaba.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/010104.085922:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010104.086401:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010104.092753:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010104.093142:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010104.093500:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010136.253941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://biz.touchev.com/, 2de78a1c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/010136.254315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://biz.touchev.com/guide.php", "biz.touchev.com", 3, 1, , , 0
[1:1:0713/010136.260721:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[29584:29584:0713/010136.730853:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/010136.742342:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
