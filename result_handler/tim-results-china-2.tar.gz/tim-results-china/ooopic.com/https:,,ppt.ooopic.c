[0712/084503.410191:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/084503.410620:INFO:switcher_clone.cc(787)] backtrace rip is 7f32459e9891
[0712/084504.358257:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/084504.358680:INFO:switcher_clone.cc(787)] backtrace rip is 7f8e12ecb891
[1:1:0712/084504.372568:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/084504.372932:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/084504.378262:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[110882:110882:0712/084505.857414:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f35557bd-c0a6-489f-ab76-5ffb7c989df4
[0712/084506.036809:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/084506.037246:INFO:switcher_clone.cc(787)] backtrace rip is 7f4b69244891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[110914:110914:0712/084506.302086:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=110914
[110926:110926:0712/084506.302602:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=110926
[110882:110882:0712/084506.442287:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[110882:110911:0712/084506.443216:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/084506.443547:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/084506.443848:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/084506.444702:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/084506.444915:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/084506.448465:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1aa70a32, 1
[1:1:0712/084506.448901:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x323c3ab3, 0
[1:1:0712/084506.449126:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e0c6c59, 3
[1:1:0712/084506.449323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1836c015, 2
[1:1:0712/084506.449564:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb33a3c32 320affffffa71a 15ffffffc03618 596c0c2e , 10104, 4
[1:1:0712/084506.450581:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[110882:110911:0712/084506.450862:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�:<22
��6Yl.\��7
[110882:110911:0712/084506.450937:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �:<22
��6Yl.\��7
[1:1:0712/084506.450851:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e111060a0, 3
[1:1:0712/084506.451147:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e11291080, 2
[110882:110911:0712/084506.451359:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/084506.451303:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8dfaf54d20, -2
[110882:110911:0712/084506.451455:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 110934, 4, b33a3c32 320aa71a 15c03618 596c0c2e 
[1:1:0712/084506.471274:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/084506.471917:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1836c015
[1:1:0712/084506.472861:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1836c015
[1:1:0712/084506.474020:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1836c015
[1:1:0712/084506.474654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.474784:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.474946:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.475245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.476068:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1836c015
[1:1:0712/084506.476262:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e12ecb7ba
[1:1:0712/084506.476354:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e12ec2def, 7f8e12ecb77a, 7f8e12ecd0cf
[1:1:0712/084506.480301:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1836c015
[1:1:0712/084506.480522:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1836c015
[1:1:0712/084506.480818:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1836c015
[1:1:0712/084506.481562:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.481684:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.481785:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.481884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1836c015
[1:1:0712/084506.482415:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1836c015
[1:1:0712/084506.482585:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e12ecb7ba
[1:1:0712/084506.482667:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e12ec2def, 7f8e12ecb77a, 7f8e12ecd0cf
[1:1:0712/084506.485121:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/084506.485589:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/084506.485749:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff77d5f878, 0x7fff77d5f7f8)
[1:1:0712/084506.505265:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/084506.510595:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[110882:110882:0712/084507.124947:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[110882:110882:0712/084507.126136:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[110882:110893:0712/084507.172741:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[110882:110882:0712/084507.172889:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[110882:110882:0712/084507.172997:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[110882:110882:0712/084507.173142:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,110934, 4
[110882:110893:0712/084507.172875:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/084507.187709:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[110882:110906:0712/084507.313841:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/084507.333669:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x73c257db220
[1:1:0712/084507.333967:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/084507.805688:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[110882:110882:0712/084509.747804:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[110882:110882:0712/084509.748002:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/084509.780887:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084509.785693:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/084510.876383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/084510.876713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084510.893556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/084510.893906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084510.969302:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/084511.313812:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/084511.314102:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084511.638938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084511.647376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/084511.647813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084511.673382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084511.685242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/084511.685644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084511.693049:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[110882:110882:0712/084511.697996:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/084511.700512:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x73c257d9e20
[1:1:0712/084511.700840:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[110882:110882:0712/084511.705507:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[110882:110882:0712/084511.740274:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[110882:110882:0712/084511.740508:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/084511.811711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084512.546253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f8dfcb2f2e0 0x73c25a79fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084512.547760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/084512.548002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084512.549505:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[110882:110882:0712/084512.633276:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/084512.635430:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x73c257da820
[1:1:0712/084512.635640:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[110882:110882:0712/084512.640433:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/084512.655523:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/084512.655698:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[110882:110882:0712/084512.657028:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[110882:110882:0712/084512.667830:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[110882:110882:0712/084512.670433:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[110882:110893:0712/084512.676702:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[110882:110893:0712/084512.676834:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[110882:110882:0712/084512.677073:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[110882:110882:0712/084512.677167:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[110882:110882:0712/084512.677342:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,110934, 4
[1:7:0712/084512.681204:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/084513.398065:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[110882:110882:0712/084513.944145:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[110882:110911:0712/084513.944543:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/084513.944768:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/084513.945014:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/084513.945454:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/084513.946391:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/084513.949808:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3e9687b, 1
[1:1:0712/084513.950341:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2314b780, 0
[1:1:0712/084513.950602:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1d33a608, 3
[1:1:0712/084513.950831:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x85924ac, 2
[1:1:0712/084513.951055:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff80ffffffb71423 7b68ffffffe903 ffffffac245908 08ffffffa6331d , 10104, 5
[1:1:0712/084513.952444:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[110882:110911:0712/084513.952766:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��#{h��$Y�3C��7
[110882:110911:0712/084513.952855:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��#{h��$Y�3h�C��7
[1:1:0712/084513.952754:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e111060a0, 3
[1:1:0712/084513.953054:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e11291080, 2
[110882:110911:0712/084513.953184:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 110978, 5, 80b71423 7b68e903 ac245908 08a6331d 
[1:1:0712/084513.953303:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8dfaf54d20, -2
[1:1:0712/084513.975680:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/084513.976041:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 85924ac
[1:1:0712/084513.976382:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 85924ac
[1:1:0712/084513.976995:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 85924ac
[1:1:0712/084513.978427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.978614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.978792:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.978969:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.979640:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 85924ac
[1:1:0712/084513.979939:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e12ecb7ba
[1:1:0712/084513.980100:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e12ec2def, 7f8e12ecb77a, 7f8e12ecd0cf
[1:1:0712/084513.986447:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 85924ac
[1:1:0712/084513.986836:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 85924ac
[1:1:0712/084513.987044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f8dfcb2f2e0 0x73c25b50ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084513.987772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 85924ac
[1:1:0712/084513.988016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 160904481f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/084513.988320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/084513.989158:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/084513.990491:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.990780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.991019:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.991270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85924ac
[1:1:0712/084513.992576:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 85924ac
[1:1:0712/084513.992994:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e12ecb7ba
[1:1:0712/084513.993158:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e12ec2def, 7f8e12ecb77a, 7f8e12ecd0cf
[1:1:0712/084513.999713:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/084514.000127:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/084514.000230:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff77d5f878, 0x7fff77d5f7f8)
[1:1:0712/084514.007930:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/084514.013282:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[110882:110882:0712/084514.135085:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[110882:110882:0712/084514.135273:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/084514.161984:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/084514.240436:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x73c2579e220
[1:1:0712/084514.240707:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/084514.638826:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[110882:110882:0712/084514.912165:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[110882:110882:0712/084514.918916:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[110882:110893:0712/084514.957028:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[110882:110893:0712/084514.957137:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[110882:110882:0712/084514.957722:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ppt.ooopic.com/
[110882:110882:0712/084514.957816:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://ppt.ooopic.com/, https://ppt.ooopic.com/, 1
[110882:110882:0712/084514.957956:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://ppt.ooopic.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 15:45:14 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Keep-Alive: timeout=20 Set-Cookie: returnurl=https%3A%2F%2Fppt.ooopic.com%2F; expires=Fri, 12-Jul-2019 16:45:14 GMT; path=/; domain=.ooopic.com Set-Cookie: showCollectButton=6; expires=Fri, 12-Jul-2019 15:59:59 GMT; path=/; domain=.ooopic.com Content-Encoding: gzip  ,110978, 5
[1:7:0712/084514.962752:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/084514.995691:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://ppt.ooopic.com/
[110882:110882:0712/084515.117121:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://ppt.ooopic.com/, https://ppt.ooopic.com/, 1
[110882:110882:0712/084515.117240:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://ppt.ooopic.com/, https://ppt.ooopic.com
[1:1:0712/084515.132825:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/084515.251075:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/084515.327181:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/084515.355814:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/084515.356121:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/084515.393587:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/084515.393888:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ppt.ooopic.com/"
[1:1:0712/084515.910641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176 0x7f8dfac07070 0x73c2596ea60 , "https://ppt.ooopic.com/"
[1:1:0712/084515.913441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , 
        var now=new Date();
        var beginTime=now.getTime();
        var obj={};
        obj.pi
[1:1:0712/084515.913738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084516.105985:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.18913, 1304, 1
[1:1:0712/084516.106251:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/084516.775335:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/084516.775553:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ppt.ooopic.com/"
[1:1:0712/084516.788999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f8dfac07070 0x73c259a8be0 , "https://ppt.ooopic.com/"
[1:1:0712/084516.849164:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084516.859635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , /* COMBO: filename = framework/vendor/jquery/jquery-1.9.1.min.js, type = application/javascript, res
[1:1:0712/084516.859832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084517.125027:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084517.129097:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084517.131445:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084517.132214:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084517.132710:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/084518.589661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282, "https://ppt.ooopic.com/"
[1:1:0712/084518.596785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , (function(){function p(){this.c="1275195743";this.ca="z";this.Y="pic";this.V="";this.X="";this.D="15
[1:1:0712/084518.597073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084520.023737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "https://ppt.ooopic.com/"
[1:1:0712/084520.030678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/084520.031049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084520.060709:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0206861, 323, 1
[1:1:0712/084520.061066:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/084520.404968:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/084520.405274:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ppt.ooopic.com/"
[1:1:0712/084520.410775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f8dfac07070 0x73c258b8a60 , "https://ppt.ooopic.com/"
[1:1:0712/084520.423022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , /* COMBO: filename = framework/vendor/layer/layer.js, type = application/javascript, resp = 200 */
/
[1:1:0712/084520.423341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084520.457986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f8dfac07070 0x73c258b8a60 , "https://ppt.ooopic.com/"
[1:1:0712/084520.470707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f8dfac07070 0x73c258b8a60 , "https://ppt.ooopic.com/"
[1:1:0712/084520.553578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f8dfac07070 0x73c258b8a60 , "https://ppt.ooopic.com/"
[1:1:0712/084520.561465:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://ppt.ooopic.com/"
[1:1:0712/084522.104599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://ppt.ooopic.com/"
[1:1:0712/084522.105415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/084522.105677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084522.569994:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ppt.ooopic.com/"
[1:1:0712/084522.570753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0712/084522.570987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084522.572644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ppt.ooopic.com/"
[1:1:0712/084522.575810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://ppt.ooopic.com/"
[1:1:0712/084522.576629:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2ddad0924328
[1:1:0712/084522.733927:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f8dfcb2f2e0 0x73c25beb0e0 , "https://ppt.ooopic.com/"
[1:1:0712/084522.758787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , (function(){var h={},mt={},c={id:"085fcfaad0bfb865ec3e7201cd64a3c5",dm:["ppt.ooopic.com"],js:"tongji
[1:1:0712/084522.759105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084522.795033:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582990
[1:1:0712/084522.795355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084522.795867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 448
[1:1:0712/084522.796113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7f8dfac07070 0x73c258cbce0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 425 0x7f8dfcb2f2e0 0x73c25beb0e0 
[110882:110882:0712/084538.114619:INFO:CONSOLE(808)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s19.cnzz.com/z_stat.php?id=1275195743&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://js.wotucdn.com/!!framework/vendor/jquery/jquery-1.9.1.min.js,framework/public/common/js/refresh_js_ppt.v3.6.10.js,2017/ppt/common/js/ppt-public-function.v1.js,framework/public/common/js/common_function.js,framework/web/ppt/js/ppt-common.v7.js,framework/web/ppt/js/ppt-tj.js,framework/public/common/js/wotu_statistics.js,2017/ppt/www/js/jquery-num.js?v=201907061556 (808)
[110882:110882:0712/084538.115440:INFO:CONSOLE(808)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s19.cnzz.com/z_stat.php?id=1275195743&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://js.wotucdn.com/!!framework/vendor/jquery/jquery-1.9.1.min.js,framework/public/common/js/refresh_js_ppt.v3.6.10.js,2017/ppt/common/js/ppt-public-function.v1.js,framework/public/common/js/common_function.js,framework/web/ppt/js/ppt-common.v7.js,framework/web/ppt/js/ppt-tj.js,framework/public/common/js/wotu_statistics.js,2017/ppt/www/js/jquery-num.js?v=201907061556 (808)
[110882:110882:0712/084538.163408:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1275195743&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s19.cnzz.com/z_stat.php?id=1275195743&show=pic (17)
[110882:110882:0712/084538.164251:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1275195743&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s19.cnzz.com/z_stat.php?id=1275195743&show=pic (17)
[110882:110882:0712/084538.256566:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/084538.261873:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/084538.457007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 600000
[1:1:0712/084538.457467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 485
[1:1:0712/084538.457704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7f8dfac07070 0x73c259ab760 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 425 0x7f8dfcb2f2e0 0x73c25beb0e0 
[1:1:0712/084538.458600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 5000
[1:1:0712/084538.459127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 486
[1:1:0712/084538.459398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f8dfac07070 0x73c253baae0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 425 0x7f8dfcb2f2e0 0x73c25beb0e0 
[1:1:0712/084538.538585:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f8dfcb2f2e0 0x73c25963b60 , "https://ppt.ooopic.com/"
[1:1:0712/084538.552520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , (function(){var h={},mt={},c={id:"6260fe7b21d72d3521d999c79fe01fc7",dm:["ooopic.com"],js:"tongji.bai
[1:1:0712/084538.552797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084538.580282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582990
[1:1:0712/084538.580578:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084538.581006:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 501
[1:1:0712/084538.581266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f8dfac07070 0x73c258bd5e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 426 0x7f8dfcb2f2e0 0x73c25963b60 
[1:1:0712/084538.730711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7f8dfcb2f2e0 0x73c25bcefe0 , "https://ppt.ooopic.com/"
[1:1:0712/084538.756076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , (function(){var h={},mt={},c={id:"5b1cb8ea5bd686369a321f1c5e6408b6",dm:["ooopic.com","m-ooopic-com-0
[1:1:0712/084538.756412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084538.778792:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582988
[1:1:0712/084538.779096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084538.779484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 520
[1:1:0712/084538.779736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f8dfac07070 0x73c25bc5de0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 429 0x7f8dfcb2f2e0 0x73c25bcefe0 
[1:1:0712/084538.834785:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 600000
[1:1:0712/084538.835257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 532
[1:1:0712/084538.835501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f8dfac07070 0x73c258b98e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 429 0x7f8dfcb2f2e0 0x73c25bcefe0 
[1:1:0712/084538.836339:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 5000
[1:1:0712/084538.836718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 533
[1:1:0712/084538.836954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7f8dfac07070 0x73c258cb2e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 429 0x7f8dfcb2f2e0 0x73c25bcefe0 
[1:1:0712/084538.892440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7f8dfcb2f2e0 0x73c25bf12e0 , "https://ppt.ooopic.com/"
[1:1:0712/084538.893492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , jQuery191040023819715484965_1562946317104({"code":"0","msg":"成功","data":[]})
[1:1:0712/084538.893744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084538.894711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084539.236409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/084539.236734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084540.143711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 448, 7f8dfd54c881
[1:1:0712/084540.171962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"425 0x7f8dfcb2f2e0 0x73c25beb0e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084540.172388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"425 0x7f8dfcb2f2e0 0x73c25beb0e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084540.172764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084540.173333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084540.173582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084540.174384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084540.174611:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084540.174978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 550
[1:1:0712/084540.175530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7f8dfac07070 0x73c253ba0e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 448 0x7f8dfac07070 0x73c258cbce0 
[1:1:0712/084540.812456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 501, 7f8dfd54c881
[1:1:0712/084540.844753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"426 0x7f8dfcb2f2e0 0x73c25963b60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084540.845218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"426 0x7f8dfcb2f2e0 0x73c25963b60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084540.845642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084540.846358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084540.846717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084540.848351:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084540.849521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084540.850365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 558
[1:1:0712/084540.851145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7f8dfac07070 0x73c25c0bce0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 501 0x7f8dfac07070 0x73c258bd5e0 
[1:1:0712/084541.508701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 520, 7f8dfd54c881
[1:1:0712/084541.538247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"429 0x7f8dfcb2f2e0 0x73c25bcefe0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084541.538711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"429 0x7f8dfcb2f2e0 0x73c25bcefe0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084541.539161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084541.540080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084541.540347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084541.541231:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084541.541461:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084541.541879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 566
[1:1:0712/084541.542136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7f8dfac07070 0x73c26567960 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 520 0x7f8dfac07070 0x73c25bc5de0 
[1:1:0712/084541.573723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , document.readyState
[1:1:0712/084541.574060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.290394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.291326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0712/084542.291742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.301735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 550, 7f8dfd54c881
[1:1:0712/084542.333526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"448 0x7f8dfac07070 0x73c258cbce0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084542.333901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"448 0x7f8dfac07070 0x73c258cbce0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084542.334475:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084542.336447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084542.336738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.337659:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084542.337930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084542.338359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 599
[1:1:0712/084542.338606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 599 0x7f8dfac07070 0x73c258ca560 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 550 0x7f8dfac07070 0x73c253ba0e0 
[1:1:0712/084542.472131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.472878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/084542.473171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.478959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 558, 7f8dfd54c881
[1:1:0712/084542.506984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"501 0x7f8dfac07070 0x73c258bd5e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084542.510780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"501 0x7f8dfac07070 0x73c258bd5e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084542.511233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084542.511949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084542.512301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.513036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084542.513258:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084542.513683:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 604
[1:1:0712/084542.513937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f8dfac07070 0x73c265671e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 558 0x7f8dfac07070 0x73c25c0bce0 
[1:1:0712/084542.581917:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.582781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0712/084542.583073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084542.594133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.595360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.596543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ppt.ooopic.com/"
[1:1:0712/084542.600782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://ppt.ooopic.com/"
[1:1:0712/084542.603028:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582af0
[1:1:0712/084542.603350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084542.603752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 608
[1:1:0712/084542.603987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f8dfac07070 0x73c25a42de0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 564 0x7f8dfac07070 0x73c2656a060 
[1:1:0712/084542.604385:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://ppt.ooopic.com/"
[1:1:0712/084542.604985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c255829f0
[1:1:0712/084542.605194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084542.605634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 609
[1:1:0712/084542.605894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f8dfac07070 0x73c2599dd60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 564 0x7f8dfac07070 0x73c2656a060 
[1:1:0712/084542.606340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://ppt.ooopic.com/"
[1:1:0712/084542.607393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c255829f0
[1:1:0712/084542.607611:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084542.608003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 610
[1:1:0712/084542.608291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f8dfac07070 0x73c25bd9de0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 564 0x7f8dfac07070 0x73c2656a060 
[1:1:0712/084542.712904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , , document.readyState
[1:1:0712/084542.713098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084543.756662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 608, 7f8dfd54c881
[1:1:0712/084543.790568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.790988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.791363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084543.792028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084543.792265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084543.793078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084543.793281:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084543.793706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 633
[1:1:0712/084543.793964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f8dfac07070 0x73c2663b460 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 608 0x7f8dfac07070 0x73c25a42de0 
[1:1:0712/084543.795646:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 609, 7f8dfd54c881
[1:1:0712/084543.828705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.829051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.829354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084543.829984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084543.830208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084543.831015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084543.831177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084543.831510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 634
[1:1:0712/084543.831718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f8dfac07070 0x73c26c76f60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 609 0x7f8dfac07070 0x73c2599dd60 
[1:1:0712/084543.833122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 610, 7f8dfd54c881
[1:1:0712/084543.862222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.862658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"564 0x7f8dfac07070 0x73c2656a060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084543.863020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084543.863719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084543.863983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084543.864781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084543.864962:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084543.865277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 635
[1:1:0712/084543.865493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f8dfac07070 0x73c26c7a460 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 610 0x7f8dfac07070 0x73c25bd9de0 
[1:1:0712/084544.199837:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 486, 7f8dfd54c8db
[1:1:0712/084544.228047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"425 0x7f8dfcb2f2e0 0x73c25beb0e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.228355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"425 0x7f8dfcb2f2e0 0x73c25beb0e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.228703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 654
[1:1:0712/084544.228900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f8dfac07070 0x73c26ca50e0 , 5:3_https://ppt.ooopic.com/, 0, , 486 0x7f8dfac07070 0x73c253baae0 
[1:1:0712/084544.229168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084544.229670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/084544.229846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084544.269804:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 533, 7f8dfd54c8db
[1:1:0712/084544.302150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"429 0x7f8dfcb2f2e0 0x73c25bcefe0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.302449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"429 0x7f8dfcb2f2e0 0x73c25bcefe0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.302792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ppt.ooopic.com/, 657
[1:1:0712/084544.302987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7f8dfac07070 0x73c26ca4e60 , 5:3_https://ppt.ooopic.com/, 0, , 533 0x7f8dfac07070 0x73c258cb2e0 
[1:1:0712/084544.303240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084544.303754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/084544.303939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084544.380237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 633, 7f8dfd54c881
[1:1:0712/084544.408725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"608 0x7f8dfac07070 0x73c25a42de0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.409115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"608 0x7f8dfac07070 0x73c25a42de0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.409438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084544.410104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084544.410326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084544.411129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084544.411329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084544.411778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 660
[1:1:0712/084544.412019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 660 0x7f8dfac07070 0x73c26c7e960 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 633 0x7f8dfac07070 0x73c2663b460 
[1:1:0712/084544.446200:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 634, 7f8dfd54c881
[1:1:0712/084544.481384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"609 0x7f8dfac07070 0x73c2599dd60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.481720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"609 0x7f8dfac07070 0x73c2599dd60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.482034:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084544.482554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084544.482815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084544.483737:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084544.483970:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084544.484418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 663
[1:1:0712/084544.484688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f8dfac07070 0x73c25533860 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 634 0x7f8dfac07070 0x73c26c76f60 
[1:1:0712/084544.499524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 635, 7f8dfd54c881
[1:1:0712/084544.516832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"610 0x7f8dfac07070 0x73c25bd9de0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.517202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"610 0x7f8dfac07070 0x73c25bd9de0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084544.517582:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084544.518261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084544.518505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084544.518968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084544.519091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084544.519282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 664
[1:1:0712/084544.519413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f8dfac07070 0x73c2583f460 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 635 0x7f8dfac07070 0x73c26c7a460 
[1:1:0712/084544.943199:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://ppt.ooopic.com/"
[1:1:0712/084544.944328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/084544.944472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/084545.061148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 660, 7f8dfd54c881
[1:1:0712/084545.090368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"633 0x7f8dfac07070 0x73c2663b460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.090720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"633 0x7f8dfac07070 0x73c2663b460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.091034:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.091600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084545.091828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.092482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.092644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.093128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 684
[1:1:0712/084545.093325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f8dfac07070 0x73c26c01c60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 660 0x7f8dfac07070 0x73c26c7e960 
[1:1:0712/084545.094598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 663, 7f8dfd54c881
[1:1:0712/084545.123423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"634 0x7f8dfac07070 0x73c26c76f60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.123735:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"634 0x7f8dfac07070 0x73c26c76f60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.124062:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.124576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084545.124779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.125434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.125590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.125949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 686
[1:1:0712/084545.126144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f8dfac07070 0x73c25be33e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 663 0x7f8dfac07070 0x73c25533860 
[1:1:0712/084545.132435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 664, 7f8dfd54c881
[1:1:0712/084545.161858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"635 0x7f8dfac07070 0x73c26c7a460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.162295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"635 0x7f8dfac07070 0x73c26c7a460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.162668:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.163725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084545.164034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.164924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.165160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.165588:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 690
[1:1:0712/084545.165868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f8dfac07070 0x73c26c9da60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 664 0x7f8dfac07070 0x73c2583f460 
[1:1:0712/084545.486230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 684, 7f8dfd54c881
[1:1:0712/084545.495777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"660 0x7f8dfac07070 0x73c26c7e960 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.496059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"660 0x7f8dfac07070 0x73c26c7e960 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.496272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.496574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084545.496682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.497018:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.497123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.497286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 712
[1:1:0712/084545.497395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f8dfac07070 0x73c25968be0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 684 0x7f8dfac07070 0x73c26c01c60 
[1:1:0712/084545.508043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 686, 7f8dfd54c881
[1:1:0712/084545.517832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"663 0x7f8dfac07070 0x73c25533860 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.518023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"663 0x7f8dfac07070 0x73c25533860 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.518204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.518499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084545.518605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.518914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.519029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.519203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 713
[1:1:0712/084545.519312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f8dfac07070 0x73c267d72e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 686 0x7f8dfac07070 0x73c25be33e0 
[1:1:0712/084545.570371:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 690, 7f8dfd54c881
[1:1:0712/084545.588338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"664 0x7f8dfac07070 0x73c2583f460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.588642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"664 0x7f8dfac07070 0x73c2583f460 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084545.588951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084545.589466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084545.589647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.590293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084545.590453:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084545.590767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 714
[1:1:0712/084545.590977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7f8dfac07070 0x73c26519e60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 690 0x7f8dfac07070 0x73c26c9da60 
[1:1:0712/084545.669141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseout", "https://ppt.ooopic.com/"
[1:1:0712/084545.669737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/084545.669901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084545.970010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 712, 7f8dfd54c881
[1:1:0712/084546.003797:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"684 0x7f8dfac07070 0x73c26c01c60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.004254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"684 0x7f8dfac07070 0x73c26c01c60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.004623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.005334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084546.005682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.006453:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.006649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.006979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 726
[1:1:0712/084546.007232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f8dfac07070 0x73c25531060 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 712 0x7f8dfac07070 0x73c25968be0 
[1:1:0712/084546.008675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 713, 7f8dfd54c881
[1:1:0712/084546.047730:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"686 0x7f8dfac07070 0x73c25be33e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.048178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"686 0x7f8dfac07070 0x73c25be33e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.048522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.049191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084546.049419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.050229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.050436:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.050845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 728
[1:1:0712/084546.051109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f8dfac07070 0x73c25531360 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 713 0x7f8dfac07070 0x73c267d72e0 
[1:1:0712/084546.052776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 714, 7f8dfd54c881
[1:1:0712/084546.091818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"690 0x7f8dfac07070 0x73c26c9da60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.092172:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"690 0x7f8dfac07070 0x73c26c9da60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.092450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.092963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084546.093177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.093828:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.093987:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.094339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 729
[1:1:0712/084546.094549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f8dfac07070 0x73c2583f5e0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 714 0x7f8dfac07070 0x73c26519e60 
[1:1:0712/084546.371445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 726, 7f8dfd54c881
[1:1:0712/084546.381968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"712 0x7f8dfac07070 0x73c25968be0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.382152:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"712 0x7f8dfac07070 0x73c25968be0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.382361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.382685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084546.382819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.383127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.383253:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.383422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 748
[1:1:0712/084546.383533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f8dfac07070 0x73c26c79ee0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 726 0x7f8dfac07070 0x73c25531060 
[1:1:0712/084546.403291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 728, 7f8dfd54c881
[1:1:0712/084546.412274:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"713 0x7f8dfac07070 0x73c267d72e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.412435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"713 0x7f8dfac07070 0x73c267d72e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.412581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.412857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084546.412967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.413365:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.413471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.413634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 750
[1:1:0712/084546.413745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7f8dfac07070 0x73c26c7ace0 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 728 0x7f8dfac07070 0x73c25531360 
[1:1:0712/084546.414187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 729, 7f8dfd54c881
[1:1:0712/084546.424233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"714 0x7f8dfac07070 0x73c26519e60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.424415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"714 0x7f8dfac07070 0x73c26519e60 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.424596:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.424879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084546.424984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.425311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.425417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.425582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 752
[1:1:0712/084546.425693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7f8dfac07070 0x73c2583f160 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 729 0x7f8dfac07070 0x73c2583f5e0 
[1:1:0712/084546.917700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 748, 7f8dfd54c881
[1:1:0712/084546.930866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"726 0x7f8dfac07070 0x73c25531060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.931077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"726 0x7f8dfac07070 0x73c25531060 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084546.931320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084546.931994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084546.932252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084546.933080:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084546.933335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084546.933919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 788
[1:1:0712/084546.934167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7f8dfac07070 0x73c26738f60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 748 0x7f8dfac07070 0x73c26c79ee0 
[1:1:0712/084547.106845:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 750, 7f8dfd54c881
[1:1:0712/084547.144564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"728 0x7f8dfac07070 0x73c25531360 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084547.144900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"728 0x7f8dfac07070 0x73c25531360 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084547.145213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084547.145808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/084547.146024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084547.146678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084547.146842:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084547.147162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 803
[1:1:0712/084547.147387:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f8dfac07070 0x73c2686f160 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 750 0x7f8dfac07070 0x73c26c7ace0 
[1:1:0712/084547.148775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 752, 7f8dfd54c881
[1:1:0712/084547.182963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38181e242860","ptid":"729 0x7f8dfac07070 0x73c2583f5e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084547.183271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ppt.ooopic.com/","ptid":"729 0x7f8dfac07070 0x73c2583f5e0 ","rf":"5:3_https://ppt.ooopic.com/"}
[1:1:0712/084547.183611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ppt.ooopic.com/"
[1:1:0712/084547.184151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ppt.ooopic.com/, 38181e242860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/084547.184351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ppt.ooopic.com/", "ppt.ooopic.com", 3, 1, , , 0
[1:1:0712/084547.185008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28346d9a29c8, 0x73c25582950
[1:1:0712/084547.185165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ppt.ooopic.com/", 100
[1:1:0712/084547.185512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ppt.ooopic.com/, 807
[1:1:0712/084547.185706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f8dfac07070 0x73c26871c60 , 5:3_https://ppt.ooopic.com/, 1, -5:3_https://ppt.ooopic.com/, 752 0x7f8dfac07070 0x73c2583f160 
