[0712/052330.063344:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/052330.063744:INFO:switcher_clone.cc(787)] backtrace rip is 7fe3022b5891
[0712/052330.966397:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/052330.966673:INFO:switcher_clone.cc(787)] backtrace rip is 7f58438b1891
[1:1:0712/052330.970852:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/052330.971064:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/052330.975081:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[82726:82726:0712/052331.977020:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dde62043-8db9-4bbc-93c5-9032016a774e
[82726:82726:0712/052332.364808:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[82726:82757:0712/052332.365523:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/052332.365758:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/052332.365985:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/052332.366636:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/052332.367528:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/052332.370198:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ed7671c, 1
[1:1:0712/052332.370586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x179d6c59, 0
[1:1:0712/052332.370801:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x23e04745, 3
[1:1:0712/052332.370968:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x284e5db0, 2
[1:1:0712/052332.371161:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 596cffffff9d17 1c67ffffffd71e ffffffb05d4e28 4547ffffffe023 , 10104, 4
[1:1:0712/052332.372105:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[82726:82757:0712/052332.372391:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGYl�g��]N(EG�#�}<
[82726:82757:0712/052332.372457:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Yl�g��]N(EG�#8��}<
[1:1:0712/052332.372567:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5841aec0a0, 3
[82726:82757:0712/052332.372752:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/052332.372777:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5841c77080, 2
[82726:82757:0712/052332.372853:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 82772, 4, 596c9d17 1c67d71e b05d4e28 4547e023 
[1:1:0712/052332.372942:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f582b93ad20, -2
[1:1:0712/052332.388279:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/052332.388875:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 284e5db0
[1:1:0712/052332.389540:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 284e5db0
[1:1:0712/052332.390595:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 284e5db0
[1:1:0712/052332.391113:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.391239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.391339:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.391429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.391653:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 284e5db0
[1:1:0712/052332.391784:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58438b17ba
[1:1:0712/052332.391857:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f58438a8def, 7f58438b177a, 7f58438b30cf
[1:1:0712/052332.393364:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 284e5db0
[1:1:0712/052332.393533:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 284e5db0
[1:1:0712/052332.393794:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 284e5db0
[1:1:0712/052332.394514:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.394627:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.394725:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.394826:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 284e5db0
[1:1:0712/052332.395269:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 284e5db0
[1:1:0712/052332.395423:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58438b17ba
[1:1:0712/052332.395509:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f58438a8def, 7f58438b177a, 7f58438b30cf
[1:1:0712/052332.397660:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/052332.397994:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/052332.398086:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce15800c8, 0x7ffce1580048)
[1:1:0712/052332.419071:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/052332.424919:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[0712/052332.483515:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/052332.484019:INFO:switcher_clone.cc(787)] backtrace rip is 7fa17f03d891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[82759:82759:0712/052332.835473:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=82759
[82799:82799:0712/052332.836058:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=82799
[82726:82726:0712/052332.949632:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[82726:82726:0712/052332.950084:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[82726:82738:0712/052332.961717:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[82726:82738:0712/052332.961817:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[82726:82726:0712/052332.961948:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[82726:82726:0712/052332.962028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[82726:82726:0712/052332.962170:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,82772, 4
[1:7:0712/052332.964523:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[82726:82751:0712/052333.018660:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/052333.100037:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x18b3b922e220
[1:1:0712/052333.100353:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/052333.483634:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[82726:82726:0712/052334.999604:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[82726:82726:0712/052334.999766:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/052335.015313:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052335.029799:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/052336.305142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/052336.305487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052336.322240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/052336.322521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052336.339361:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/052336.651296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/052336.651670:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052336.861831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 347, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052336.868014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/052336.868288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052336.931149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052336.941787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/052336.942093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052336.954211:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[82726:82726:0712/052336.957739:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/052336.958726:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x18b3b922ce20
[1:1:0712/052336.959158:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[82726:82726:0712/052336.975077:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[82726:82726:0712/052337.021510:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[82726:82726:0712/052337.021674:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/052337.046037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052338.125227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f582d5152e0 0x18b3b934f660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052338.126653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/052338.126900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052338.128513:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[82726:82726:0712/052338.168335:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/052338.172745:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x18b3b922d820
[1:1:0712/052338.173002:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[82726:82726:0712/052338.176765:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/052338.186937:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/052338.187156:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[82726:82726:0712/052338.205766:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[82726:82726:0712/052338.224900:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[82726:82726:0712/052338.226197:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[82726:82738:0712/052338.233931:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[82726:82738:0712/052338.234048:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[82726:82726:0712/052338.238250:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[82726:82726:0712/052338.238357:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[82726:82726:0712/052338.238529:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,82772, 4
[1:7:0712/052338.243535:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/052338.657423:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/052339.129972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f582d5152e0 0x18b3b93f13e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/052339.131134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0de0fd2c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/052339.131377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/052339.132251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[82726:82726:0712/052339.235366:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[82726:82726:0712/052339.235510:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/052339.257833:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/052339.670915:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/052340.264929:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/052340.265223:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[82726:82726:0712/052340.319751:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[82726:82757:0712/052340.320297:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/052340.320509:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/052340.320719:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/052340.321103:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/052340.321269:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/052340.324426:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13e7162f, 1
[1:1:0712/052340.324822:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x376cc4ec, 0
[1:1:0712/052340.325010:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x957af8b, 3
[1:1:0712/052340.325247:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1da14025, 2
[1:1:0712/052340.325453:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffecffffffc46c37 2f16ffffffe713 2540ffffffa11d ffffff8bffffffaf5709 , 10104, 5
[1:1:0712/052340.326735:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[82726:82757:0712/052340.327029:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��l7/�%@���W	��<
[82726:82757:0712/052340.327125:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��l7/�%@���W	��<
[82726:82757:0712/052340.327589:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 82824, 5, ecc46c37 2f16e713 2540a11d 8baf5709 
[1:1:0712/052340.327318:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5841aec0a0, 3
[1:1:0712/052340.328130:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5841c77080, 2
[1:1:0712/052340.328389:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f582b93ad20, -2
[1:1:0712/052340.351264:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/052340.351706:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1da14025
[1:1:0712/052340.352180:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1da14025
[1:1:0712/052340.352894:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1da14025
[1:1:0712/052340.354356:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.354584:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.354814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.355033:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.355754:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1da14025
[1:1:0712/052340.356120:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58438b17ba
[1:1:0712/052340.356352:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f58438a8def, 7f58438b177a, 7f58438b30cf
[1:1:0712/052340.360910:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1da14025
[1:1:0712/052340.361372:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1da14025
[1:1:0712/052340.362131:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1da14025
[1:1:0712/052340.364748:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.365011:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.365254:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.365484:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1da14025
[1:1:0712/052340.366712:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1da14025
[1:1:0712/052340.367151:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58438b17ba
[1:1:0712/052340.367386:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f58438a8def, 7f58438b177a, 7f58438b30cf
[1:1:0712/052340.376915:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/052340.377570:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/052340.377772:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce15800c8, 0x7ffce1580048)
[1:1:0712/052340.393187:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/052340.397695:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/052340.560482:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/052340.565197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0de0fd3f09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/052340.565524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/052340.573348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/052340.583476:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x18b3b91ff220
[1:1:0712/052340.583800:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[82726:82726:0712/052341.027293:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[82726:82726:0712/052341.031180:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[82726:82738:0712/052341.058197:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[82726:82738:0712/052341.058335:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[82726:82726:0712/052341.058911:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://daxue.imooc.com/
[82726:82726:0712/052341.059031:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://daxue.imooc.com/, http://daxue.imooc.com/, 1
[82726:82726:0712/052341.059204:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://daxue.imooc.com/, HTTP/1.1 200 OK Server: nginx/1.4.2 Date: Fri, 12 Jul 2019 12:23:40 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: PHPSESSID=im8hirepo2o7tr7nhbros02jo4; expires=Fri, 12-Jul-2019 22:23:40 GMT; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache  ,82824, 5
[1:7:0712/052341.064076:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/052341.096705:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://daxue.imooc.com/
[82726:82726:0712/052341.224009:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://daxue.imooc.com/, http://daxue.imooc.com/, 1
[82726:82726:0712/052341.224144:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://daxue.imooc.com/, http://daxue.imooc.com
[1:1:0712/052341.257275:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/052341.345862:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/052341.386108:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/052341.386428:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://daxue.imooc.com/"
[1:1:0712/052341.490033:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/052342.034465:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052342.056695:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052342.057975:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052342.058431:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052342.060070:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052342.060481:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052343.404067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.415873:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/052343.426490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , /*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
*/(function(e,t){var
[1:1:0712/052343.426794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
		remove user.f_992f5eb2 -> 0
		remove user.10_b0d4f0c -> 0
		remove user.11_2f95268d -> 0
		remove user.13_10717ae -> 0
		remove user.12_d41db4dd -> 0
		remove user.14_1f537bb3 -> 0
[1:1:0712/052343.620647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.646423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.820753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.834406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.841857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f582b5ed070 0x18b3b951e7e0 , "http://daxue.imooc.com/"
[1:1:0712/052343.909407:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.29045, 335, 1
[1:1:0712/052343.909693:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/052344.271224:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/052344.271511:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://daxue.imooc.com/"
[1:1:0712/052344.272361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f582b5ed070 0x18b3b8f386e0 , "http://daxue.imooc.com/"
[1:1:0712/052344.273410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.
[1:1:0712/052344.273644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052344.286181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://daxue.imooc.com/"
[1:1:0712/052345.333399:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://daxue.imooc.com/"
[1:1:0712/052345.352402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 50
[1:1:0712/052345.352884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 311
[1:1:0712/052345.353116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 311 0x7f582b5ed070 0x18b3b8ed83e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 282 0x7f582b5ed070 0x18b3b8f386e0 
[1:1:0712/052345.926975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 311, 7f582df328db
[1:1:0712/052345.942194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"282 0x7f582b5ed070 0x18b3b8f386e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052345.942614:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"282 0x7f582b5ed070 0x18b3b8f386e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052345.943070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 333
[1:1:0712/052345.943323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f582b5ed070 0x18b3b91d5460 , 5:3_http://daxue.imooc.com/, 0, , 311 0x7f582b5ed070 0x18b3b8ed83e0 
[1:1:0712/052345.943716:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052345.944847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052345.945085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052346.298780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 333, 7f582df328db
[1:1:0712/052346.314558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"311 0x7f582b5ed070 0x18b3b8ed83e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.314982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"311 0x7f582b5ed070 0x18b3b8ed83e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.315481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 353
[1:1:0712/052346.315794:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 353 0x7f582b5ed070 0x18b3b8f3c760 , 5:3_http://daxue.imooc.com/, 0, , 333 0x7f582b5ed070 0x18b3b91d5460 
[1:1:0712/052346.316143:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052346.316695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052346.316912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052346.583568:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 353, 7f582df328db
[1:1:0712/052346.600020:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"333 0x7f582b5ed070 0x18b3b91d5460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.600321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"333 0x7f582b5ed070 0x18b3b91d5460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.600732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 368
[1:1:0712/052346.601007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 368 0x7f582b5ed070 0x18b3b94789e0 , 5:3_http://daxue.imooc.com/, 0, , 353 0x7f582b5ed070 0x18b3b8f3c760 
[1:1:0712/052346.601341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052346.602143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052346.602453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052346.853935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 368, 7f582df328db
[1:1:0712/052346.871732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"353 0x7f582b5ed070 0x18b3b8f3c760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.872073:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"353 0x7f582b5ed070 0x18b3b8f3c760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052346.872514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 382
[1:1:0712/052346.872778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 382 0x7f582b5ed070 0x18b3b99d7960 , 5:3_http://daxue.imooc.com/, 0, , 368 0x7f582b5ed070 0x18b3b94789e0 
[1:1:0712/052346.873127:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052346.873658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052346.873910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052347.028186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376 0x7f582d5152e0 0x18b3b99d79e0 , "http://daxue.imooc.com/"
[1:1:0712/052347.037564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (function(){var h={},mt={},c={id:"f0cfcccd7b1393990c78efdeebff3968",dm:["imooc.com"],js:"tongji.baid
[1:1:0712/052347.037845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052347.072203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20148
[1:1:0712/052347.072489:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052347.072876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 394
[1:1:0712/052347.073137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7f582b5ed070 0x18b3b95b3460 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 376 0x7f582d5152e0 0x18b3b99d79e0 
[82726:82726:0712/052359.270743:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/052359.329749:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/052359.703511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 382, 7f582df328db
[1:1:0712/052359.728847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"368 0x7f582b5ed070 0x18b3b94789e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052359.729281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"368 0x7f582b5ed070 0x18b3b94789e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052359.729817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 482
[1:1:0712/052359.730133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7f582b5ed070 0x18b3b99d8860 , 5:3_http://daxue.imooc.com/, 0, , 382 0x7f582b5ed070 0x18b3b99d7960 
[1:1:0712/052359.730488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052359.731115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052359.731395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052400.118979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/052400.119327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052401.111979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 394, 7f582df32881
[1:1:0712/052401.122077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"376 0x7f582d5152e0 0x18b3b99d79e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052401.122470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"376 0x7f582d5152e0 0x18b3b99d79e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052401.122933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052401.123614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052401.123887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052401.124718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052401.124945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052401.125463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 516
[1:1:0712/052401.125711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7f582b5ed070 0x18b3b926e460 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 394 0x7f582b5ed070 0x18b3b95b3460 
[1:1:0712/052401.237052:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 482, 7f582df328db
[1:1:0712/052401.263252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"382 0x7f582b5ed070 0x18b3b99d7960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052401.263596:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"382 0x7f582b5ed070 0x18b3b99d7960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052401.264093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 521
[1:1:0712/052401.264338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7f582b5ed070 0x18b3b9324960 , 5:3_http://daxue.imooc.com/, 0, , 482 0x7f582b5ed070 0x18b3b99d8860 
[1:1:0712/052401.264679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052401.265206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052401.265440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[82726:82726:0712/052401.463156:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='name', confirm at https://goo.gl/6KgkJg) %o", source: http://daxue.imooc.com/ (0)
[82726:82726:0712/052401.467966:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='tel', confirm at https://goo.gl/6KgkJg) %o", source: http://daxue.imooc.com/ (0)
[82726:82726:0712/052401.471819:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='email', confirm at https://goo.gl/6KgkJg) %o", source: http://daxue.imooc.com/ (0)
[1:1:0712/052401.563047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return f.customStyle(a,b,d,c,e)}
[1:1:0712/052401.563392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052401.764910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , document.readyState
[1:1:0712/052401.765299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052402.273235:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 516, 7f582df32881
[1:1:0712/052402.304074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"394 0x7f582b5ed070 0x18b3b95b3460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052402.304502:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"394 0x7f582b5ed070 0x18b3b95b3460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052402.304987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052402.305679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052402.305965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052402.306870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052402.307114:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052402.307567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 575
[1:1:0712/052402.307923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f582b5ed070 0x18b3b951e1e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 516 0x7f582b5ed070 0x18b3b926e460 
[1:1:0712/052402.342458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 521, 7f582df328db
[1:1:0712/052402.369855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"482 0x7f582b5ed070 0x18b3b99d8860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052402.370210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"482 0x7f582b5ed070 0x18b3b99d8860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052402.370645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 580
[1:1:0712/052402.370923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f582b5ed070 0x18b3b9ff9fe0 , 5:3_http://daxue.imooc.com/, 0, , 521 0x7f582b5ed070 0x18b3b9324960 
[1:1:0712/052402.371262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052402.371850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052402.372076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052402.720162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://daxue.imooc.com/"
[1:1:0712/052402.720913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , window.onresize, (){//窗口缩放
		resizeTimer = resizeTimer?null:setTimeout(divMiddle,0);
	}
[1:1:0712/052402.721140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052402.721948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3ad23d4629c8, 0x18b3b8e20220
[1:1:0712/052402.722161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 0
[1:1:0712/052402.722527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 601
[1:1:0712/052402.722794:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7f582b5ed070 0x18b3ba1962e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 538 0x7f583a8fe960 0x18b3b8e564c0 0x18b3b8e564d0 
[1:1:0712/052402.723270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://daxue.imooc.com/"
[1:1:0712/052402.758314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , document.readyState
[1:1:0712/052402.758671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052403.513528:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://daxue.imooc.com/"
[1:1:0712/052403.514440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/052403.514685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052403.991137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 580, 7f582df328db
[1:1:0712/052404.005967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"521 0x7f582b5ed070 0x18b3b9324960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.006202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"521 0x7f582b5ed070 0x18b3b9324960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.006457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 662
[1:1:0712/052404.006576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f582b5ed070 0x18b3b8f3a4e0 , 5:3_http://daxue.imooc.com/, 0, , 580 0x7f582b5ed070 0x18b3b9ff9fe0 
[1:1:0712/052404.006732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052404.007027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052404.007156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052404.024336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 575, 7f582df32881
[1:1:0712/052404.059745:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"516 0x7f582b5ed070 0x18b3b926e460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.060062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"516 0x7f582b5ed070 0x18b3b926e460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.060566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052404.061364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052404.061629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052404.062567:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052404.062794:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052404.063266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 663
[1:1:0712/052404.063542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f582b5ed070 0x18b3ba020460 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 575 0x7f582b5ed070 0x18b3b951e1e0 
[1:1:0712/052404.496763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 601, 7f582df32881
[1:1:0712/052404.525928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"538 0x7f583a8fe960 0x18b3b8e564c0 0x18b3b8e564d0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.526272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"538 0x7f583a8fe960 0x18b3b8e564c0 0x18b3b8e564d0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052404.526655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052404.527178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , divMiddle, (){
		var hTop = $('.container h1');
		var divHeight = $(window).height();
		var bodyHeight = docume
[1:1:0712/052404.527409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/052404.818216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , document.readyState
[1:1:0712/052404.818587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052406.214296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://daxue.imooc.com/"
[1:1:0712/052406.215219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/052406.215508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052406.248511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://daxue.imooc.com/"
[1:1:0712/052406.263446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://daxue.imooc.com/"
[1:1:0712/052406.267602:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://daxue.imooc.com/"
[1:1:0712/052406.269402:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e202f0
[1:1:0712/052406.269621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052406.270137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 771
[1:1:0712/052406.270388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f582b5ed070 0x18b3b8f38460 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 649 0x7f5841c77080 0x18b3b905fe20 1 0 0x18b3b905fe38 
[1:1:0712/052406.750052:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 662, 7f582df328db
[1:1:0712/052406.761371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"580 0x7f582b5ed070 0x18b3b9ff9fe0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052406.761560:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"580 0x7f582b5ed070 0x18b3b9ff9fe0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052406.761834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 777
[1:1:0712/052406.761953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 777 0x7f582b5ed070 0x18b3ba0425e0 , 5:3_http://daxue.imooc.com/, 0, , 662 0x7f582b5ed070 0x18b3b8f3a4e0 
[1:1:0712/052406.762112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052406.762411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052406.762524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052407.182490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , document.readyState
[1:1:0712/052407.182666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052409.438180:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 771, 7f582df32881
[1:1:0712/052409.472632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"649 0x7f5841c77080 0x18b3b905fe20 1 0 0x18b3b905fe38 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.473005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"649 0x7f5841c77080 0x18b3b905fe20 1 0 0x18b3b905fe38 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.473478:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052409.474021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052409.474227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052409.474964:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052409.475133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052409.475494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 802
[1:1:0712/052409.475738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f582b5ed070 0x18b3b9ff36e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 771 0x7f582b5ed070 0x18b3b8f38460 
[1:1:0712/052409.512095:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 777, 7f582df328db
[1:1:0712/052409.536595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"662 0x7f582b5ed070 0x18b3b8f3a4e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.536851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"662 0x7f582b5ed070 0x18b3b8f3a4e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.537206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 803
[1:1:0712/052409.537322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f582b5ed070 0x18b3ba369ce0 , 5:3_http://daxue.imooc.com/, 0, , 777 0x7f582b5ed070 0x18b3ba0425e0 
[1:1:0712/052409.537504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052409.537798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052409.537903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052409.940790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 803, 7f582df328db
[1:1:0712/052409.953311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"777 0x7f582b5ed070 0x18b3ba0425e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.953488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"777 0x7f582b5ed070 0x18b3ba0425e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.953750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 811
[1:1:0712/052409.953864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7f582b5ed070 0x18b3b9bbefe0 , 5:3_http://daxue.imooc.com/, 0, , 803 0x7f582b5ed070 0x18b3ba369ce0 
[1:1:0712/052409.954024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052409.954299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052409.954398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052409.965458:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 802, 7f582df32881
[1:1:0712/052409.981368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"771 0x7f582b5ed070 0x18b3b8f38460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.981621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"771 0x7f582b5ed070 0x18b3b8f38460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052409.981878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052409.982203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052409.982310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052409.982768:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052409.982970:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052409.983369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 812
[1:1:0712/052409.983666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7f582b5ed070 0x18b3ba3a1960 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 802 0x7f582b5ed070 0x18b3b9ff36e0 
[1:1:0712/052410.209178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 811, 7f582df328db
[1:1:0712/052410.225279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"803 0x7f582b5ed070 0x18b3ba369ce0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.225476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"803 0x7f582b5ed070 0x18b3ba369ce0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.225724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 821
[1:1:0712/052410.225839:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f582b5ed070 0x18b3ba3a0c60 , 5:3_http://daxue.imooc.com/, 0, , 811 0x7f582b5ed070 0x18b3b9bbefe0 
[1:1:0712/052410.225990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.226268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052410.226370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.387087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 812, 7f582df32881
[1:1:0712/052410.431223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"802 0x7f582b5ed070 0x18b3b9ff36e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.431463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"802 0x7f582b5ed070 0x18b3b9ff36e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.431717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.432030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052410.432134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.432431:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052410.432527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052410.432728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 827
[1:1:0712/052410.432842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f582b5ed070 0x18b3b8d842e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 812 0x7f582b5ed070 0x18b3ba3a1960 
[1:1:0712/052410.587876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 821, 7f582df328db
[1:1:0712/052410.623408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"811 0x7f582b5ed070 0x18b3b9bbefe0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.623747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"811 0x7f582b5ed070 0x18b3b9bbefe0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.624151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 833
[1:1:0712/052410.624348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f582b5ed070 0x18b3ba3924e0 , 5:3_http://daxue.imooc.com/, 0, , 821 0x7f582b5ed070 0x18b3ba3a0c60 
[1:1:0712/052410.624631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.625142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052410.625320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.651498:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 827, 7f582df32881
[1:1:0712/052410.662977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"812 0x7f582b5ed070 0x18b3ba3a1960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.663159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"812 0x7f582b5ed070 0x18b3ba3a1960 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.663363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.663663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052410.663881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.664521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052410.664681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052410.665029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 836
[1:1:0712/052410.665219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f582b5ed070 0x18b3ba390860 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 827 0x7f582b5ed070 0x18b3b8d842e0 
[1:1:0712/052410.696561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 833, 7f582df328db
[1:1:0712/052410.723186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"821 0x7f582b5ed070 0x18b3ba3a0c60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.723471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"821 0x7f582b5ed070 0x18b3ba3a0c60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.723876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 840
[1:1:0712/052410.724079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f582b5ed070 0x18b3ba37f1e0 , 5:3_http://daxue.imooc.com/, 0, , 833 0x7f582b5ed070 0x18b3ba3924e0 
[1:1:0712/052410.724366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.724873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052410.725050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.792514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 840, 7f582df328db
[1:1:0712/052410.811172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7f582b5ed070 0x18b3ba3924e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.811343:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7f582b5ed070 0x18b3ba3924e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.811550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 846
[1:1:0712/052410.811656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7f582b5ed070 0x18b3b9215a60 , 5:3_http://daxue.imooc.com/, 0, , 840 0x7f582b5ed070 0x18b3ba37f1e0 
[1:1:0712/052410.811835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.812115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052410.812221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.847183:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 836, 7f582df32881
[1:1:0712/052410.877139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"827 0x7f582b5ed070 0x18b3b8d842e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.877340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"827 0x7f582b5ed070 0x18b3b8d842e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.877544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.878012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052410.878122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052410.879022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052410.879131:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052410.879303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 849
[1:1:0712/052410.879410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f582b5ed070 0x18b3ba376460 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 836 0x7f582b5ed070 0x18b3ba390860 
[1:1:0712/052410.879985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 846, 7f582df328db
[1:1:0712/052410.891632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"840 0x7f582b5ed070 0x18b3ba37f1e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.892253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"840 0x7f582b5ed070 0x18b3ba37f1e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052410.892631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 852
[1:1:0712/052410.892844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f582b5ed070 0x18b3ba1d9860 , 5:3_http://daxue.imooc.com/, 0, , 846 0x7f582b5ed070 0x18b3b9215a60 
[1:1:0712/052410.893109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052410.893564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052410.893739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.004691:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 852, 7f582df328db
[1:1:0712/052411.022683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"846 0x7f582b5ed070 0x18b3b9215a60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.022978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"846 0x7f582b5ed070 0x18b3b9215a60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.023301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 859
[1:1:0712/052411.023464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f582b5ed070 0x18b3ba1d99e0 , 5:3_http://daxue.imooc.com/, 0, , 852 0x7f582b5ed070 0x18b3ba1d9860 
[1:1:0712/052411.023685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.024134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.024287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.043442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 849, 7f582df32881
[1:1:0712/052411.061596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"836 0x7f582b5ed070 0x18b3ba390860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.061942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"836 0x7f582b5ed070 0x18b3ba390860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.062242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.062665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052411.062835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.063305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052411.063464:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052411.063720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 862
[1:1:0712/052411.063948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f582b5ed070 0x18b3ba389d60 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 849 0x7f582b5ed070 0x18b3ba376460 
[1:1:0712/052411.100770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 859, 7f582df328db
[1:1:0712/052411.120935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"852 0x7f582b5ed070 0x18b3ba1d9860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.121284:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"852 0x7f582b5ed070 0x18b3ba1d9860 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.121775:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 868
[1:1:0712/052411.122034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f582b5ed070 0x18b3ba04ede0 , 5:3_http://daxue.imooc.com/, 0, , 859 0x7f582b5ed070 0x18b3ba1d99e0 
[1:1:0712/052411.122401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.123023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.123242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.170464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 868, 7f582df328db
[1:1:0712/052411.207219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"859 0x7f582b5ed070 0x18b3ba1d99e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.207517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"859 0x7f582b5ed070 0x18b3ba1d99e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.207969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 873
[1:1:0712/052411.208222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7f582b5ed070 0x18b3b8d82ce0 , 5:3_http://daxue.imooc.com/, 0, , 868 0x7f582b5ed070 0x18b3ba04ede0 
[1:1:0712/052411.208499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.209002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.209180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.244697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 862, 7f582df32881
[1:1:0712/052411.255508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"849 0x7f582b5ed070 0x18b3ba376460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.255701:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"849 0x7f582b5ed070 0x18b3ba376460 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.255918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.256227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052411.256330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.256629:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052411.256731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052411.257448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 876
[1:1:0712/052411.257561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 876 0x7f582b5ed070 0x18b3b8f3b760 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 862 0x7f582b5ed070 0x18b3ba389d60 
[1:1:0712/052411.258118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 873, 7f582df328db
[1:1:0712/052411.269355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"868 0x7f582b5ed070 0x18b3ba04ede0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.269486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"868 0x7f582b5ed070 0x18b3ba04ede0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.269669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 879
[1:1:0712/052411.269775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 879 0x7f582b5ed070 0x18b3b91eece0 , 5:3_http://daxue.imooc.com/, 0, , 873 0x7f582b5ed070 0x18b3b8d82ce0 
[1:1:0712/052411.269928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.270163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.270264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.377814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 879, 7f582df328db
[1:1:0712/052411.392639:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"873 0x7f582b5ed070 0x18b3b8d82ce0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.392794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"873 0x7f582b5ed070 0x18b3b8d82ce0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.393007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 888
[1:1:0712/052411.393118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f582b5ed070 0x18b3ba39d3e0 , 5:3_http://daxue.imooc.com/, 0, , 879 0x7f582b5ed070 0x18b3b91eece0 
[1:1:0712/052411.393274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.393552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.393657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.405174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 876, 7f582df32881
[1:1:0712/052411.415674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"862 0x7f582b5ed070 0x18b3ba389d60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.415821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"862 0x7f582b5ed070 0x18b3ba389d60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.416029:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.416293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052411.416396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.416687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052411.416782:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052411.416962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 892
[1:1:0712/052411.417073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f582b5ed070 0x18b3b9a1aa60 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 876 0x7f582b5ed070 0x18b3b8f3b760 
[1:1:0712/052411.439169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 888, 7f582df328db
[1:1:0712/052411.449979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"879 0x7f582b5ed070 0x18b3b91eece0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.450113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"879 0x7f582b5ed070 0x18b3b91eece0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.450294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 895
[1:1:0712/052411.450399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7f582b5ed070 0x18b3ba410760 , 5:3_http://daxue.imooc.com/, 0, , 888 0x7f582b5ed070 0x18b3ba39d3e0 
[1:1:0712/052411.450549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.450809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.450940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.462789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 895, 7f582df328db
[1:1:0712/052411.494236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"888 0x7f582b5ed070 0x18b3ba39d3e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.494513:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"888 0x7f582b5ed070 0x18b3ba39d3e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.494891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 897
[1:1:0712/052411.495103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7f582b5ed070 0x18b3ba383de0 , 5:3_http://daxue.imooc.com/, 0, , 895 0x7f582b5ed070 0x18b3ba410760 
[1:1:0712/052411.495394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.495868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.496099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.536468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 897, 7f582df328db
[1:1:0712/052411.573327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"895 0x7f582b5ed070 0x18b3ba410760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.573594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"895 0x7f582b5ed070 0x18b3ba410760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.573989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 901
[1:1:0712/052411.574183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7f582b5ed070 0x18b3ba1d92e0 , 5:3_http://daxue.imooc.com/, 0, , 897 0x7f582b5ed070 0x18b3ba383de0 
[1:1:0712/052411.574463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.574962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.575140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.576922:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 892, 7f582df32881
[1:1:0712/052411.622226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"876 0x7f582b5ed070 0x18b3b8f3b760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.622613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"876 0x7f582b5ed070 0x18b3b8f3b760 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.623053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.623687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052411.623906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.624766:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052411.624977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052411.625386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 903
[1:1:0712/052411.625623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7f582b5ed070 0x18b3ba40c1e0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 892 0x7f582b5ed070 0x18b3b9a1aa60 
[1:1:0712/052411.627588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 901, 7f582df328db
[1:1:0712/052411.642537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"897 0x7f582b5ed070 0x18b3ba383de0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.642700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"897 0x7f582b5ed070 0x18b3ba383de0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.642897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 906
[1:1:0712/052411.643021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7f582b5ed070 0x18b3ba3627e0 , 5:3_http://daxue.imooc.com/, 0, , 901 0x7f582b5ed070 0x18b3ba1d92e0 
[1:1:0712/052411.643166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.643417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.643517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.676698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 906, 7f582df328db
[1:1:0712/052411.687156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"901 0x7f582b5ed070 0x18b3ba1d92e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.687285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"901 0x7f582b5ed070 0x18b3ba1d92e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.687463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 912
[1:1:0712/052411.687567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7f582b5ed070 0x18b3ba3a1560 , 5:3_http://daxue.imooc.com/, 0, , 906 0x7f582b5ed070 0x18b3ba3627e0 
[1:1:0712/052411.687706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.687952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.688107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.731840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 912, 7f582df328db
[1:1:0712/052411.769400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"906 0x7f582b5ed070 0x18b3ba3627e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.769678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"906 0x7f582b5ed070 0x18b3ba3627e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.770084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 917
[1:1:0712/052411.770281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f582b5ed070 0x18b3b8d82560 , 5:3_http://daxue.imooc.com/, 0, , 912 0x7f582b5ed070 0x18b3ba3a1560 
[1:1:0712/052411.770557:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.771068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.771264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.847263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 903, 7f582df32881
[1:1:0712/052411.884172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"892 0x7f582b5ed070 0x18b3b9a1aa60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.884446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"892 0x7f582b5ed070 0x18b3b9a1aa60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.884776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.885290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052411.885469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052411.886123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052411.886284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052411.886600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 921
[1:1:0712/052411.886787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f582b5ed070 0x18b3b9630c60 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 903 0x7f582b5ed070 0x18b3ba40c1e0 
[1:1:0712/052411.888062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 917, 7f582df328db
[1:1:0712/052411.930328:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"912 0x7f582b5ed070 0x18b3ba3a1560 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.930724:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"912 0x7f582b5ed070 0x18b3ba3a1560 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052411.931281:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 922
[1:1:0712/052411.931550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f582b5ed070 0x18b3ba1d8c60 , 5:3_http://daxue.imooc.com/, 0, , 917 0x7f582b5ed070 0x18b3b8d82560 
[1:1:0712/052411.931929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052411.932641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052411.932896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052412.028584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 922, 7f582df328db
[1:1:0712/052412.067094:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"917 0x7f582b5ed070 0x18b3b8d82560 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.067384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"917 0x7f582b5ed070 0x18b3b8d82560 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.067768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 929
[1:1:0712/052412.067950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f582b5ed070 0x18b3ba3959e0 , 5:3_http://daxue.imooc.com/, 0, , 922 0x7f582b5ed070 0x18b3ba1d8c60 
[1:1:0712/052412.068265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052412.068735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052412.068901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052412.070411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 921, 7f582df32881
[1:1:0712/052412.092551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2842b5362860","ptid":"903 0x7f582b5ed070 0x18b3ba40c1e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.092735:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://daxue.imooc.com/","ptid":"903 0x7f582b5ed070 0x18b3ba40c1e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.092941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052412.093270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/052412.093394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052412.093762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3ad23d4629c8, 0x18b3b8e20150
[1:1:0712/052412.093875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://daxue.imooc.com/", 100
[1:1:0712/052412.094066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://daxue.imooc.com/, 930
[1:1:0712/052412.094230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7f582b5ed070 0x18b3b947ede0 , 5:3_http://daxue.imooc.com/, 1, -5:3_http://daxue.imooc.com/, 921 0x7f582b5ed070 0x18b3b9630c60 
[1:1:0712/052412.132311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 929, 7f582df328db
[1:1:0712/052412.150890:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"922 0x7f582b5ed070 0x18b3ba1d8c60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.151273:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"922 0x7f582b5ed070 0x18b3ba1d8c60 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.151684:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 937
[1:1:0712/052412.151909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f582b5ed070 0x18b3b8d84360 , 5:3_http://daxue.imooc.com/, 0, , 929 0x7f582b5ed070 0x18b3ba3959e0 
[1:1:0712/052412.152260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052412.152793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052412.153009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
[1:1:0712/052412.154279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 937, 7f582df328db
[1:1:0712/052412.191582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"929 0x7f582b5ed070 0x18b3ba3959e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.191940:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"929 0x7f582b5ed070 0x18b3ba3959e0 ","rf":"5:3_http://daxue.imooc.com/"}
[1:1:0712/052412.192479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://daxue.imooc.com/, 939
[1:1:0712/052412.192729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f582b5ed070 0x18b3ba367460 , 5:3_http://daxue.imooc.com/, 0, , 937 0x7f582b5ed070 0x18b3b8d84360 
[1:1:0712/052412.193038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://daxue.imooc.com/"
[1:1:0712/052412.193660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://daxue.imooc.com/, 2842b5362860, , , (){return a.apply(b,arguments)}
[1:1:0712/052412.193885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://daxue.imooc.com/", "daxue.imooc.com", 3, 1, , , 0
