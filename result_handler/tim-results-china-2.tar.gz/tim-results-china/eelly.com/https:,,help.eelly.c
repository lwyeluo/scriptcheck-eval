[0711/193544.259416:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193544.259717:INFO:switcher_clone.cc(787)] backtrace rip is 7f1e62930891
[0711/193545.493297:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193545.493810:INFO:switcher_clone.cc(787)] backtrace rip is 7fe7abe64891
[1:1:0711/193545.510449:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/193545.510825:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/193545.523011:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[3054:3054:0711/193546.851332:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f4032dd8-b379-47e1-a74d-320a86e32a13
[0711/193547.291755:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/193547.292200:INFO:switcher_clone.cc(787)] backtrace rip is 7f73fc68b891
[3054:3054:0711/193547.327888:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[3054:3084:0711/193547.329273:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/193547.329528:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193547.329804:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193547.330430:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193547.330599:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/193547.333330:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8476caf, 1
[1:1:0711/193547.333658:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x108a89e7, 0
[1:1:0711/193547.333848:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1ba22781, 3
[1:1:0711/193547.334075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10b083c4, 2
[1:1:0711/193547.334296:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe7ffffff89ffffff8a10 ffffffaf6c4708 ffffffc4ffffff83ffffffb010 ffffff8127ffffffa21b , 10104, 4
[1:1:0711/193547.335262:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3054:3084:0711/193547.335573:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING牊�lGă��'�S[�
[3054:3084:0711/193547.335640:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 牊�lGă��'��%S[�
[1:1:0711/193547.335561:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe7aa09f0a0, 3
[1:1:0711/193547.335797:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe7aa22a080, 2
[3054:3084:0711/193547.335967:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[3054:3084:0711/193547.336067:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3099, 4, e7898a10 af6c4708 c483b010 8127a21b 
[1:1:0711/193547.336036:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe793eedd20, -2
[1:1:0711/193547.357749:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193547.358708:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10b083c4
[1:1:0711/193547.359722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10b083c4
[1:1:0711/193547.361351:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10b083c4
[1:1:0711/193547.362935:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.363268:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.363735:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.363984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.364705:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10b083c4
[1:1:0711/193547.365073:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe7abe647ba
[1:1:0711/193547.365269:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe7abe5bdef, 7fe7abe6477a, 7fe7abe660cf
[1:1:0711/193547.371307:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10b083c4
[1:1:0711/193547.371722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10b083c4
[1:1:0711/193547.372535:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10b083c4
[1:1:0711/193547.374599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.374857:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.375116:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.375335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10b083c4
[1:1:0711/193547.376649:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10b083c4
[1:1:0711/193547.377074:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe7abe647ba
[1:1:0711/193547.377311:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe7abe5bdef, 7fe7abe6477a, 7fe7abe660cf
[1:1:0711/193547.384344:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193547.384915:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193547.385107:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff891f6768, 0x7fff891f66e8)
[1:1:0711/193547.398360:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193547.404324:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3086:3086:0711/193547.519621:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3086
[3113:3113:0711/193547.520044:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3113
[3054:3054:0711/193547.940437:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3054:3054:0711/193547.941833:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3054:3054:0711/193547.956984:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[3054:3065:0711/193547.956994:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[3054:3054:0711/193547.957039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[3054:3054:0711/193547.957104:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,3099, 4
[3054:3065:0711/193547.957108:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/193547.959700:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[3054:3078:0711/193547.987084:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/193548.050978:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xf6c143a1220
[1:1:0711/193548.051305:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/193548.351959:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0711/193549.442801:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193549.446168:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3054:3054:0711/193549.742175:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[3054:3054:0711/193549.742273:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193550.971530:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193551.322304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193551.322502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193551.328698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/193551.328912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193551.521844:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193551.522044:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193551.866583:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193551.877269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193551.877629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193551.904777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193551.916228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/193551.916469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193551.929167:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[3054:3054:0711/193551.931899:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193551.932096:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf6c1439fe20
[1:1:0711/193551.932231:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[3054:3054:0711/193551.940600:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[3054:3054:0711/193551.977181:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[3054:3054:0711/193551.977394:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/193552.012131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193553.021367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fe795ac82e0 0xf6c14622fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193553.022612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/193553.022801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193553.024309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3054:3054:0711/193553.113075:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/193553.120966:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xf6c143a0820
[1:1:0711/193553.121500:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[3054:3054:0711/193553.124877:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/193553.143401:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/193553.143592:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[3054:3054:0711/193553.168917:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[3054:3054:0711/193553.185919:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3054:3054:0711/193553.187019:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3054:3065:0711/193553.193760:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[3054:3054:0711/193553.193941:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[3054:3065:0711/193553.193919:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[3054:3054:0711/193553.194028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[3054:3054:0711/193553.194172:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,3099, 4
[1:7:0711/193553.204403:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193553.985754:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/193554.641015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7fe795ac82e0 0xf6c14670f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193554.642268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/193554.642642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193554.643567:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3054:3054:0711/193554.984986:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[3054:3054:0711/193554.985111:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/193554.997841:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3054:3054:0711/193555.182994:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[3054:3084:0711/193555.183841:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/193555.184212:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/193555.185008:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/193555.186129:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/193555.186510:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/193555.192450:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x27c4ffb4, 1
[1:1:0711/193555.192995:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3212bd91, 0
[1:1:0711/193555.193324:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x12cda3f4, 3
[1:1:0711/193555.193615:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e73f22a, 2
[1:1:0711/193555.193938:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff91ffffffbd1232 ffffffb4ffffffffffffffc427 2afffffff2731e fffffff4ffffffa3ffffffcd12 , 10104, 5
[1:1:0711/193555.195264:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3054:3084:0711/193555.195713:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��2���'*�s����Z�
[1:1:0711/193555.195669:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe7aa09f0a0, 3
[3054:3084:0711/193555.195957:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��2���'*�s�����Z�
[1:1:0711/193555.196057:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe7aa22a080, 2
[1:1:0711/193555.196412:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe793eedd20, -2
[3054:3084:0711/193555.196615:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3156, 5, 91bd1232 b4ffc427 2af2731e f4a3cd12 
[1:1:0711/193555.219676:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/193555.220127:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e73f22a
[1:1:0711/193555.220552:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e73f22a
[1:1:0711/193555.221297:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e73f22a
[1:1:0711/193555.222290:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.222581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.222985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.223337:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.224538:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e73f22a
[1:1:0711/193555.225040:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe7abe647ba
[1:1:0711/193555.225260:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe7abe5bdef, 7fe7abe6477a, 7fe7abe660cf
[1:1:0711/193555.235202:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e73f22a
[1:1:0711/193555.235820:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e73f22a
[1:1:0711/193555.237086:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e73f22a
[1:1:0711/193555.240543:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.240925:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.241243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.241553:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e73f22a
[1:1:0711/193555.243520:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e73f22a
[1:1:0711/193555.243952:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe7abe647ba
[1:1:0711/193555.244122:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe7abe5bdef, 7fe7abe6477a, 7fe7abe660cf
[1:1:0711/193555.250649:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/193555.251332:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/193555.251474:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff891f6768, 0x7fff891f66e8)
[1:1:0711/193555.263041:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/193555.268099:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/193555.396603:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193555.487748:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf6c14389220
[1:1:0711/193555.488044:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/193555.914054:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193555.914194:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[3054:3054:0711/193556.218610:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3054:3054:0711/193556.234951:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3054:3065:0711/193556.248592:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[3054:3065:0711/193556.248682:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[3054:3054:0711/193556.250783:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://help.eelly.com/
[3054:3054:0711/193556.251023:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://help.eelly.com/, https://help.eelly.com/help-common_question.html, 1
[3054:3054:0711/193556.251393:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://help.eelly.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=UTF-8 date:Fri, 12 Jul 2019 02:35:56 GMT vary:Accept-Encoding vary:Accept-Encoding vary:Accept-Encoding access-control-allow-origin:* access-control-allow-headers:content-type,transmission-mode,transmission-token,transmission-version x-xss-protection:1; mode=block x-xss-protection:1; mode=block x-frame-options:SAMEORIGIN x-content-type-options:SAMEORIGIN content-encoding:gzip via:cache3.l2su18-1[207,0], cache4.cn538[230,0] timing-allow-origin:* eagleid:2be0b8cc15628989560033651e  ,3156, 5
[1:7:0711/193556.256758:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/193556.285958:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://help.eelly.com/
[1:1:0711/193556.442003:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/193556.447429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 150e26d4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/193556.447721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/193556.455839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/193556.487011:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3054:3054:0711/193556.510968:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://help.eelly.com/, https://help.eelly.com/, 1
[3054:3054:0711/193556.511077:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://help.eelly.com/, https://help.eelly.com
[1:1:0711/193556.582167:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193556.651893:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193556.652163:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://help.eelly.com/help-common_question.html"
[1:1:0711/193556.791704:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/193556.792431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 150e26c21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/193556.792646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/193556.892105:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7fe793ba0070 0xf6c13f3d060 , "https://help.eelly.com/help-common_question.html"
[1:1:0711/193556.893512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , , 
    staticUrl = 'https://mallstatic.eelly.com';

[1:1:0711/193556.893703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[1:1:0711/193556.909015:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 ()","https://mallstatic.eelly.com/assets/js/help_c781d23.js"
[1:1:0711/193556.918307:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193556.930995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7fe7aa22a080 0xf6c144f3740 1 0 0xf6c144f3758 , "https://help.eelly.com/help-common_question.html"
[1:1:0711/193556.932981:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193556.944099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , , ;/*!/js/jquery-1.8.2.min.js*/
!function(e,t){function n(e){var t=ht[e]={};return K.each(e.split(tt),
[1:1:0711/193556.944339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[1:1:0711/193557.235328:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 ()","https://mallstatic.eelly.com/assets/js/help_c781d23.js"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/193557.303497:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0600221, 428, 1
[1:1:0711/193557.303737:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193557.362820:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193557.363050:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://help.eelly.com/help-common_question.html"
[1:1:0711/193557.363984:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fe793ba0070 0xf6c14620860 , "https://help.eelly.com/help-common_question.html"
[1:1:0711/193557.365417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , , 
 $(document).ready(function(){
     if(typeof($('#select_flag').val()) !='undefined'){
         $('
[1:1:0711/193557.365638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[1:1:0711/193557.388895:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0255842, 78, 1
[1:1:0711/193557.389064:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/193557.416461:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/193557.416616:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://help.eelly.com/help-common_question.html"
[1:1:0711/193557.417391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fe793ba0070 0xf6c145ee1e0 , "https://help.eelly.com/help-common_question.html"
[1:1:0711/193557.418425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , , 
                        $(document).ready(function(){
                            $("#pageTrunTo").
[1:1:0711/193557.418599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[1:1:0711/193557.452597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://help.eelly.com/help-common_question.html"
[1:1:0711/193559.065577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://help.eelly.com/help-common_question.html"
[1:1:0711/193559.066371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , ready, (e){if(e===!0?!--K.readyWait:!K.isReady){if(!R.body)return setTimeout(K.ready,1);K.isReady=!0,e!==!0
[1:1:0711/193559.066631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[1:1:0711/193604.692104:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193604.692563:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193604.692922:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193604.693265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193604.693567:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/193605.733759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://help.eelly.com/, 3a5eb9ae2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/193605.734061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://help.eelly.com/help-common_question.html", "help.eelly.com", 3, 1, , , 0
[3054:3054:0711/193605.793594:INFO:CONSOLE(0)] "Error parsing header X-XSS-Protection: 1; mode=block, 1; mode=block: expected semicolon at character position 13. The default protections will be applied.", source: https://help.eelly.com/help-common_question.html (0)
[3:3:0711/193607.141584:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3054:3054:0711/193609.003540:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
