[0711/195247.044183:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195247.044752:INFO:switcher_clone.cc(787)] backtrace rip is 7fcd14f7b891
[0711/195247.955819:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195247.956108:INFO:switcher_clone.cc(787)] backtrace rip is 7fc9e2e7c891
[1:1:0711/195247.959943:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/195247.960098:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/195247.965006:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[5264:5264:0711/195249.146585:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/494aaf11-86a1-4054-878f-9e286a39aa9f
[0711/195249.355462:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/195249.355782:INFO:switcher_clone.cc(787)] backtrace rip is 7fc2ccb36891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5297:5297:0711/195249.567789:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5297
[5309:5309:0711/195249.568225:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5309
[5264:5264:0711/195249.668000:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5264:5295:0711/195249.668774:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/195249.669038:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195249.669249:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195249.669843:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195249.670011:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/195249.672774:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb87a771, 1
[1:1:0711/195249.673156:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d6a9009, 0
[1:1:0711/195249.673351:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1632b7ca, 3
[1:1:0711/195249.673542:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x12e782c4, 2
[1:1:0711/195249.673801:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 09ffffff906a2d 71ffffffa7ffffff870b ffffffc4ffffff82ffffffe712 ffffffcaffffffb73216 , 10104, 4
[1:1:0711/195249.675026:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5264:5295:0711/195249.675266:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING	�j-q��Ă�ʷ2f��3
[5264:5295:0711/195249.675347:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 	�j-q��Ă�ʷ2X�f��3
[5264:5295:0711/195249.675698:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5264:5295:0711/195249.675785:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5317, 4, 09906a2d 71a7870b c482e712 cab73216 
[1:1:0711/195249.676315:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e10b70a0, 3
[1:1:0711/195249.676540:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e1242080, 2
[1:1:0711/195249.676746:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9caf05d20, -2
[1:1:0711/195249.697477:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195249.698062:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12e782c4
[1:1:0711/195249.698682:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12e782c4
[1:1:0711/195249.699601:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12e782c4
[1:1:0711/195249.700167:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.700273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.700364:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.700460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.700709:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12e782c4
[1:1:0711/195249.700840:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e2e7c7ba
[1:1:0711/195249.700911:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e2e73def, 7fc9e2e7c77a, 7fc9e2e7e0cf
[1:1:0711/195249.702322:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12e782c4
[1:1:0711/195249.702475:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12e782c4
[1:1:0711/195249.702760:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12e782c4
[1:1:0711/195249.703429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.703530:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.703616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.703815:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12e782c4
[1:1:0711/195249.704705:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12e782c4
[1:1:0711/195249.704862:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e2e7c7ba
[1:1:0711/195249.704938:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e2e73def, 7fc9e2e7c77a, 7fc9e2e7e0cf
[1:1:0711/195249.707102:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195249.707378:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195249.707462:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff73f70f68, 0x7fff73f70ee8)
[1:1:0711/195249.718631:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195249.724608:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5264:5264:0711/195250.357577:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5264:5264:0711/195250.358700:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5264:5276:0711/195250.370906:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5264:5264:0711/195250.370940:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5264:5276:0711/195250.371036:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[5264:5264:0711/195250.371060:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5264:5264:0711/195250.371202:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5317, 4
[1:7:0711/195250.375238:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[5264:5287:0711/195250.419559:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/195250.552557:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xb6de2233220
[1:1:0711/195250.552822:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/195251.074656:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[5264:5264:0711/195252.697378:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5264:5264:0711/195252.697703:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195252.729653:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195252.733884:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195254.024125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195254.024451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195254.058832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/195254.059142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195254.142173:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195254.340012:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195254.340302:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195254.789721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195254.795746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195254.796026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195254.823946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195254.831991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/195254.832272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195254.844184:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5264:5264:0711/195254.846572:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195254.847562:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb6de2231e20
[1:1:0711/195254.847761:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5264:5264:0711/195254.854457:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5264:5264:0711/195254.889599:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5264:5264:0711/195254.889759:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/195254.958071:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195255.939157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7fc9ccae02e0 0xb6de246ace0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195255.940646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/195255.940897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195255.942426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5264:5264:0711/195256.014633:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/195256.015647:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xb6de2232820
[1:1:0711/195256.015972:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5264:5264:0711/195256.022380:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/195256.027585:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/195256.027900:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5264:5264:0711/195256.043717:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5264:5264:0711/195256.057974:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5264:5264:0711/195256.058995:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5264:5276:0711/195256.065920:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5264:5276:0711/195256.066013:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5264:5264:0711/195256.066188:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5264:5264:0711/195256.066263:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5264:5264:0711/195256.066399:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5317, 4
[1:7:0711/195256.076611:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195256.582247:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/195257.069344:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fc9ccae02e0 0xb6de23eebe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/195257.070370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd491aa1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/195257.070600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/195257.071366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5264:5264:0711/195257.146600:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5264:5264:0711/195257.146737:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/195257.177459:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5264:5264:0711/195257.377584:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5264:5295:0711/195257.378077:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/195257.378269:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/195257.378467:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/195257.378847:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/195257.378982:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/195257.381947:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfc3df50, 1
[1:1:0711/195257.382299:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x392fc705, 0
[1:1:0711/195257.382499:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17949597, 3
[1:1:0711/195257.382676:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3259af8a, 2
[1:1:0711/195257.382844:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 05ffffffc72f39 50ffffffdfffffffc30f ffffff8affffffaf5932 ffffff97ffffff95ffffff9417 , 10104, 5
[1:1:0711/195257.383866:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5264:5295:0711/195257.384218:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�/9P����Y2���ӓ�3
[5264:5295:0711/195257.384318:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �/9P����Y2����ӓ�3
[1:1:0711/195257.384169:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e10b70a0, 3
[1:1:0711/195257.384493:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e1242080, 2
[5264:5295:0711/195257.384626:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5363, 5, 05c72f39 50dfc30f 8aaf5932 97959417 
[1:1:0711/195257.384713:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9caf05d20, -2
[1:1:0711/195257.405498:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/195257.405994:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3259af8a
[1:1:0711/195257.406409:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3259af8a
[1:1:0711/195257.407058:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3259af8a
[1:1:0711/195257.408610:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.408847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.409060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.409272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.409955:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3259af8a
[1:1:0711/195257.410272:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e2e7c7ba
[1:1:0711/195257.410468:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e2e73def, 7fc9e2e7c77a, 7fc9e2e7e0cf
[1:1:0711/195257.416285:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3259af8a
[1:1:0711/195257.416767:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3259af8a
[1:1:0711/195257.417594:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3259af8a
[1:1:0711/195257.419681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.419953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.420181:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.420442:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3259af8a
[1:1:0711/195257.421808:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3259af8a
[1:1:0711/195257.422234:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e2e7c7ba
[1:1:0711/195257.422490:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e2e73def, 7fc9e2e7c77a, 7fc9e2e7e0cf
[1:1:0711/195257.427214:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/195257.427811:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/195257.427991:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff73f70f68, 0x7fff73f70ee8)
[1:1:0711/195257.442405:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/195257.444481:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/195257.725937:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xb6de21a5220
[1:1:0711/195257.726181:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/195257.726940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[5264:5264:0711/195258.279366:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5264:5264:0711/195258.284390:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5264:5276:0711/195258.318196:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[5264:5276:0711/195258.318300:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[5264:5264:0711/195258.318949:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://gsxt.gzaic.gov.cn/
[5264:5264:0711/195258.319049:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://gsxt.gzaic.gov.cn/, http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug==, 1
[5264:5264:0711/195258.319222:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://gsxt.gzaic.gov.cn/, HTTP/1.1 200 OK Server: wds Date: Fri, 12 Jul 2019 02:52:58 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Content-Language: en-US Content-Encoding: gzip Vary: Accept-Encoding X-Cache-Status: BYPASS X-Cache-Valid: 0 X-Node-ID: WAF-FJ-XiaMen-BGP-2  ,5363, 5
[1:7:0711/195258.323665:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/195258.356405:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://gsxt.gzaic.gov.cn/
[1:1:0711/195258.383927:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195258.384239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5264:5264:0711/195258.482990:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://gsxt.gzaic.gov.cn/, http://gsxt.gzaic.gov.cn/, 1
[5264:5264:0711/195258.483114:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://gsxt.gzaic.gov.cn/, http://gsxt.gzaic.gov.cn
[1:1:0711/195258.557960:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/195258.636665:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/195258.685132:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/195258.685380:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195258.836074:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_NAME_NOT_RESOLVED","http://fwtj.gsxt.gov.cn/js/logcollector.js?nodenum=440000"
[1:1:0711/195258.992470:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195258.997027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bd491bce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/195258.997318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/195259.005570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/195259.124856:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195259.330893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fc9caf20bd0 0xb6de22b4d58 , "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195259.338120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://gsxt.gzaic.gov.cn/, 13f6739a2860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0711/195259.338398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug==", "gsxt.gzaic.gov.cn", 3, 1, , , 0
[1:1:0711/195259.346588:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195259.504524:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fc9caf20bd0 0xb6de22b4d58 , "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195259.507922:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7fc9caf20bd0 0xb6de22b4d58 , "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195259.532916:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/195259.946237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195259.947401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://gsxt.gzaic.gov.cn/, 13f6739a2860, , ready, (a){if(a===!0&&!--e.readyWait||a!==!0&&!e.isReady){if(!c.body)return setTimeout(e.ready,1);e.isReady
[1:1:0711/195259.947666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug==", "gsxt.gzaic.gov.cn", 3, 1, , , 0
[1:1:0711/195259.948486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug=="
[1:1:0711/195300.246810:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195300.247356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195300.247756:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195300.248176:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195300.248542:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/195308.993797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://gsxt.gzaic.gov.cn/, 13f6739a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/195308.994100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug==", "gsxt.gzaic.gov.cn", 3, 1, , , 0
[5264:5264:0711/195309.484692:INFO:CONSOLE(15)] "Uncaught ReferenceError: t1Collect_gsxt is not defined", source: http://gsxt.gzaic.gov.cn/aiccips/GSpublicity/GSpublicityList.html?service=entInfo_2V8NKBAOojn27aIFriSuzsvgI1bo4dnhDyDH2JsUMp8=-QAkwbt3uFdOBC199fZkRug== (15)
[3:3:0711/195309.591938:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/195310.301314:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://gsxt.gzaic.gov.cn/favicon.ico"
[5264:5264:0711/195311.435984:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
