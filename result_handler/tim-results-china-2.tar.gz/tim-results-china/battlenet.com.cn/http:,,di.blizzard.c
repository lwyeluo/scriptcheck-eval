[0712/035019.947532:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/035019.947940:INFO:switcher_clone.cc(787)] backtrace rip is 7f861c009891
[0712/035021.026196:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/035021.026541:INFO:switcher_clone.cc(787)] backtrace rip is 7f7015227891
[1:1:0712/035021.038199:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/035021.038455:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/035021.047246:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[69046:69046:0712/035022.582155:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/035022.649776:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/035022.650123:INFO:switcher_clone.cc(787)] backtrace rip is 7f483edf4891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/91bdccae-8b38-44d8-9368-3dd7ed4d6979
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[69080:69080:0712/035022.886736:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=69080
[69091:69091:0712/035022.886993:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=69091
[69046:69046:0712/035023.211880:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[69046:69076:0712/035023.212781:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/035023.212959:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/035023.213301:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/035023.214131:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/035023.214339:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/035023.217904:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8b9493d, 1
[1:1:0712/035023.218236:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e53dda1, 0
[1:1:0712/035023.218402:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x51d02d1, 3
[1:1:0712/035023.218563:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d06cce3, 2
[1:1:0712/035023.218771:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa1ffffffdd531e 3d49ffffffb908 ffffffe3ffffffcc063d ffffffd1021d05 , 10104, 4
[1:1:0712/035023.219681:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[69046:69076:0712/035023.219970:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��S=I���=�
�:
[69046:69076:0712/035023.220040:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��S=I���=��
�:
[1:1:0712/035023.219961:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70134620a0, 3
[1:1:0712/035023.220169:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70135ed080, 2
[69046:69076:0712/035023.220332:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/035023.220326:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6ffd2b0d20, -2
[69046:69076:0712/035023.220413:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 69099, 4, a1dd531e 3d49b908 e3cc063d d1021d05 
[1:1:0712/035023.238949:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/035023.239779:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d06cce3
[1:1:0712/035023.240760:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d06cce3
[1:1:0712/035023.242346:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d06cce3
[1:1:0712/035023.243913:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.244099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.244277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.244463:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.245107:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d06cce3
[1:1:0712/035023.245457:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70152277ba
[1:1:0712/035023.245588:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f701521edef, 7f701522777a, 7f70152290cf
[1:1:0712/035023.251227:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d06cce3
[1:1:0712/035023.251570:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d06cce3
[1:1:0712/035023.252311:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d06cce3
[1:1:0712/035023.254312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.254506:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.254692:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.254905:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d06cce3
[1:1:0712/035023.256161:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d06cce3
[1:1:0712/035023.256519:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70152277ba
[1:1:0712/035023.256677:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f701521edef, 7f701522777a, 7f70152290cf
[1:1:0712/035023.264717:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/035023.265228:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/035023.265400:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd9964ba08, 0x7ffd9964b988)
[1:1:0712/035023.284798:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/035023.292397:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[69046:69046:0712/035023.888076:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[69046:69046:0712/035023.889716:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[69046:69058:0712/035023.908485:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[69046:69058:0712/035023.908597:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[69046:69046:0712/035023.908709:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[69046:69046:0712/035023.908787:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[69046:69046:0712/035023.908955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,69099, 4
[1:7:0712/035023.915128:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[69046:69071:0712/035023.942139:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/035024.014196:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x19289435e220
[1:1:0712/035024.014455:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/035024.514679:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/035025.777716:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035025.779418:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[69046:69046:0712/035025.818224:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[69046:69046:0712/035025.818357:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/035026.868213:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035027.117408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/035027.117789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035027.134112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/035027.134335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035027.185202:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035027.185363:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035027.417517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035027.420293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/035027.420441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035027.437376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035027.441297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/035027.441505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035027.446378:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/035027.450232:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x19289435ce20
[1:1:0712/035027.450551:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[69046:69046:0712/035027.451927:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[69046:69046:0712/035027.467655:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[69046:69046:0712/035027.499056:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[69046:69046:0712/035027.499221:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/035027.561451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035028.646021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f6ffee8b2e0 0x19289453e7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035028.647314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/035028.647515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035028.648993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035028.724003:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x19289435d820
[1:1:0712/035028.724242:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[69046:69046:0712/035028.724736:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/035028.742640:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/035028.742835:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[69046:69046:0712/035028.745289:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[69046:69046:0712/035028.780823:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[69046:69046:0712/035028.793773:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[69046:69046:0712/035028.794826:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[69046:69058:0712/035028.801073:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[69046:69058:0712/035028.801156:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[69046:69046:0712/035028.801352:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[69046:69046:0712/035028.801430:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[69046:69046:0712/035028.801569:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,69099, 4
[1:7:0712/035028.805276:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/035029.395092:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/035029.822502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f6ffee8b2e0 0x1928946c6260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035029.823570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/035029.823864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/035029.824716:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[69046:69046:0712/035030.054700:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[69046:69046:0712/035030.054853:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/035030.087891:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[69046:69046:0712/035030.530738:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[69046:69076:0712/035030.531359:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/035030.531580:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/035030.531907:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/035030.532358:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/035030.532539:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/035030.536374:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1690841c, 1
[1:1:0712/035030.537173:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x38b3a5d9, 0
[1:1:0712/035030.537505:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c423e62, 3
[1:1:0712/035030.537856:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x778b9c2, 2
[1:1:0712/035030.538171:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd9ffffffa5ffffffb338 1cffffff84ffffff9016 ffffffc2ffffffb97807 623e421c , 10104, 5
[1:1:0712/035030.540020:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[69046:69076:0712/035030.540246:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING٥�8��¹xb>Bx�:
[1:1:0712/035030.540226:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70134620a0, 3
[69046:69076:0712/035030.540342:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ٥�8��¹xb>B��x�:
[1:1:0712/035030.540353:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f70135ed080, 2
[1:1:0712/035030.540484:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6ffd2b0d20, -2
[69046:69076:0712/035030.540636:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 69144, 5, d9a5b338 1c849016 c2b97807 623e421c 
[1:1:0712/035030.542433:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035030.552412:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/035030.552636:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 778b9c2
[1:1:0712/035030.552876:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 778b9c2
[1:1:0712/035030.553197:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 778b9c2
[1:1:0712/035030.553773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.553902:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.554012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.554119:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.554403:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 778b9c2
[1:1:0712/035030.554567:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70152277ba
[1:1:0712/035030.554674:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f701521edef, 7f701522777a, 7f70152290cf
[1:1:0712/035030.556497:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 778b9c2
[1:1:0712/035030.556715:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 778b9c2
[1:1:0712/035030.557057:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 778b9c2
[1:1:0712/035030.557929:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.558076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.558191:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.558309:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 778b9c2
[1:1:0712/035030.558873:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 778b9c2
[1:1:0712/035030.559073:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f70152277ba
[1:1:0712/035030.559170:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f701521edef, 7f701522777a, 7f70152290cf
[1:1:0712/035030.561953:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/035030.562354:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/035030.562468:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd9964ba08, 0x7ffd9964b988)
[1:1:0712/035030.578614:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/035030.583110:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/035030.769220:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x192894329220
[1:1:0712/035030.769475:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/035031.138624:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035031.139002:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[69046:69046:0712/035031.343563:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[69046:69046:0712/035031.349521:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/035031.370117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/035031.379364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 268e0c80e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/035031.379920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/035031.392636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[69046:69058:0712/035031.393980:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[69046:69058:0712/035031.394083:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[69046:69046:0712/035031.396668:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://di.blizzard.cn/
[69046:69046:0712/035031.396759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://di.blizzard.cn/, http://di.blizzard.cn/, 1
[69046:69046:0712/035031.396979:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://di.blizzard.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 10:49:57 GMT Server: ATS Accept-Ranges: bytes Vary: Accept-Encoding Content-Encoding: gzip Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 10:59:57 GMT Content-Length: 8972 Content-Type: text/html Age: 34 Connection: keep-alive  ,69144, 5
[1:7:0712/035031.405538:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/035031.425593:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://di.blizzard.cn/
[1:1:0712/035031.556508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/035031.557277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 268e0c6e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/035031.557528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[69046:69046:0712/035031.583287:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://di.blizzard.cn/, http://di.blizzard.cn/, 1
[69046:69046:0712/035031.583395:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://di.blizzard.cn/, http://di.blizzard.cn
[1:1:0712/035031.628821:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/035031.756640:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035031.856889:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035031.857162:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://di.blizzard.cn/"
[1:1:0712/035032.054484:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.197206, 731, 1
[1:1:0712/035032.054702:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035032.273445:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/035032.599485:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035032.600362:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035032.600741:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035032.601157:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035032.601555:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035032.848759:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035032.849006:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://di.blizzard.cn/"
[1:1:0712/035032.910357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://di.blizzard.cn/"
[1:1:0712/035033.181976:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035033.396006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://di.blizzard.cn/"
[1:1:0712/035033.554957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://di.blizzard.cn/"
[1:1:0712/035033.680975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://di.blizzard.cn/"
[1:1:0712/035035.038676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.054290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , ;/*!src/jquery.1.11.before.js*/
"object"!=typeof JSON&&(JSON={}),function(){"use strict";function f(
[1:1:0712/035035.054577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035035.060595:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x13061c0429c8, 0x1928941a1960
[1:1:0712/035035.060818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 0
[1:1:0712/035035.061193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 373
[1:1:0712/035035.061422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 373 0x7f6ffcf63070 0x1928944a97e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 357 0x7f6ffd2cbbd0 0x192894334058 
[1:1:0712/035035.067382:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_bc0d39 -> 0
		remove user.11_21641874 -> 0
		remove user.12_f79f52f3 -> 0
		remove user.13_aaa4775c -> 0
		remove user.14_8f97936e -> 0
[1:1:0712/035035.425905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.435009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.488703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.512381:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.554259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7f6ffd2cbbd0 0x192894334058 , "http://di.blizzard.cn/"
[1:1:0712/035035.559829:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://di.blizzard.cn/"
[1:1:0712/035038.350323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x13061c0429c8, 0x1928941a1c40
[1:1:0712/035038.350576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 0
[1:1:0712/035038.351035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 447
[1:1:0712/035038.351283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 447 0x7f6ffcf63070 0x192894d9d660 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 357 0x7f6ffd2cbbd0 0x192894334058 
[1:1:0712/035038.352131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x13061c0429c8, 0x1928941a1c40
[1:1:0712/035038.352336:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 0
[1:1:0712/035038.352695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 448
[1:1:0712/035038.352982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7f6ffcf63070 0x1928948179e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 357 0x7f6ffd2cbbd0 0x192894334058 
[1:1:0712/035038.360042:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x13061c0429c8, 0x1928941a1c40
[1:1:0712/035038.360263:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 2000
[1:1:0712/035038.360617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 449
[1:1:0712/035038.360877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 449 0x7f6ffcf63070 0x192893f71b60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 357 0x7f6ffd2cbbd0 0x192894334058 
[1:1:0712/035040.022377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 373, 7f6fff8a8881
[1:1:0712/035040.043674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.044030:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.044382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035040.044927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){var t=((location.hash||"").match(/([#&])BJ_ERROR=([^&$]+)/)||[])[2];t&&console.error("BJ_ERROR",d
[1:1:0712/035040.045146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035040.047437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 447, 7f6fff8a8881
[1:1:0712/035040.069067:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.069429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.069759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035040.070364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035040.070580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035040.073582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 448, 7f6fff8a8881
[1:1:0712/035040.080851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.081215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035040.081545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035040.082060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035040.082290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[69046:69069:0712/035040.936214:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/035040.988341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 494 0x7f6ffee8b2e0 0x1928945da860 , "http://di.blizzard.cn/"
[1:1:0712/035040.989665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/035040.989895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035041.022607:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7f6ffee8b2e0 0x1928948461e0 , "http://di.blizzard.cn/"
[1:1:0712/035041.031131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , var Placeholer=function(){function e(){return"placeholder"in document.createElement("input")}functio
[1:1:0712/035041.031409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035041.043947:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035041.413577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1a10
[1:1:0712/035041.413872:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035041.414339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 560
[1:1:0712/035041.414589:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 560 0x7f6ffcf63070 0x192894824260 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 495 0x7f6ffee8b2e0 0x1928948461e0 
[1:1:0712/035042.011675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 449, 7f6fff8a8881
[1:1:0712/035042.036397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035042.036792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"357 0x7f6ffd2cbbd0 0x192894334058 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035042.037126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035042.037725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035042.037959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035043.548264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 617 0x7f6ffee8b2e0 0x192894430ee0 , "http://di.blizzard.cn/"
[1:1:0712/035043.557736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , window.NECaptcha_plugin=function(t){function n(r){if(e[r])return e[r].exports;var o=e[r]={exports:{}
[1:1:0712/035043.558012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035043.592662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035043.596373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1a10
[1:1:0712/035043.596619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035043.597011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 678
[1:1:0712/035043.597296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f6ffcf63070 0x1928945f93e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 617 0x7f6ffee8b2e0 0x192894430ee0 
[1:2:0712/035044.161451:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:2:0712/035044.431546:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:2:0712/035044.524532:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035044.630522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 678, 7f6fff8a8881
[1:1:0712/035044.644342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"617 0x7f6ffee8b2e0 0x192894430ee0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035044.644714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"617 0x7f6ffee8b2e0 0x192894430ee0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035044.645107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035044.645668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035044.645884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035044.649172:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035044.649410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035044.649783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 745
[1:1:0712/035044.650011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f6ffcf63070 0x192893f2fd60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 678 0x7f6ffcf63070 0x1928945f93e0 
[1:2:0712/035044.652567:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035044.694187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035045.140814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 703 0x7f6ffee8b2e0 0x1928947598e0 , "http://di.blizzard.cn/"
[1:1:0712/035045.141795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , /**/jQuery1113025038561842032836_1562928635348({"appId":"wx96c5b760f77f42cd","sign":"5583c50dae2c348
[1:1:0712/035045.142047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035045.142999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035045.400271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035045.421702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035045.992411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035046.211220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 745, 7f6fff8a8881
[1:1:0712/035046.243351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"678 0x7f6ffcf63070 0x1928945f93e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035046.243720:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"678 0x7f6ffcf63070 0x1928945f93e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035046.244153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035046.244700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035046.244936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
		remove user.12_aa900984 -> 0
		remove user.13_8c2fc3b5 -> 0
		remove user.14_62826ded -> 0
		remove user.15_75784fca -> 0
[1:1:0712/035046.263505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035046.263787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035046.264212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 796
[1:1:0712/035046.264442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7f6ffcf63070 0x1928944681e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 745 0x7f6ffcf63070 0x192893f2fd60 
[1:1:0712/035046.266325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035046.266529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035046.266917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 797
[1:1:0712/035046.267162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f6ffcf63070 0x1928956570e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 745 0x7f6ffcf63070 0x192893f2fd60 
[1:1:0712/035046.269178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035046.269384:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035046.269732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 798
[1:1:0712/035046.269975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7f6ffcf63070 0x192895657a60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 745 0x7f6ffcf63070 0x192893f2fd60 
[1:1:0712/035046.320353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035046.808468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035046.893907:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[69046:69046:0712/035046.930125:INFO:CONSOLE(4)] "1025", source: https://di.res.netease.com/pc/gw/20181025184036/pkg/app_840ebe8.js (4)
[69046:69046:0712/035046.987272:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/035047.001404:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/035047.492693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 796, 7f6fff8a8881
[1:1:0712/035047.528354:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.528741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.529171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035047.529732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035047.529946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035047.539384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035047.539724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035047.540094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 867
[1:1:0712/035047.540398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 867 0x7f6ffcf63070 0x19289569e160 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 796 0x7f6ffcf63070 0x1928944681e0 
[1:1:0712/035047.550530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035047.550844:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035047.551227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 868
[1:1:0712/035047.551454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f6ffcf63070 0x192895577060 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 796 0x7f6ffcf63070 0x1928944681e0 
[1:1:0712/035047.557578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 797, 7f6fff8a8881
[1:1:0712/035047.570148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.570518:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.570932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035047.571531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035047.571805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035047.573726:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 798, 7f6fff8a8881
[1:1:0712/035047.603329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.603734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"745 0x7f6ffcf63070 0x192893f2fd60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035047.604242:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035047.604807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035047.605058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035047.644282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035047.707549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035047.755030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/035047.755417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:15:0712/035048.425941:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0712/035048.720553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035048.948910:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035049.486991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 560, 7f6fff8a8881
[1:1:0712/035049.513546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"495 0x7f6ffee8b2e0 0x1928948461e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035049.514240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"495 0x7f6ffee8b2e0 0x1928948461e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035049.514682:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035049.515259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035049.515460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035049.779573:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035050.247847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035050.248176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035050.994090:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0712/035052.040792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035052.041365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://di.blizzard.cn/"
[1:1:0712/035052.311197:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 935 0x7f6ffee8b2e0 0x1928958165e0 , "http://di.blizzard.cn/"
[1:1:0712/035052.312575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , __JSONP_zq97qiv_0({"data":{"ac":{"enable":2,"bid":"","pn":"","token":"9ca17ae2e6fecda16ae2e6eeb5cb52
[1:1:0712/035052.312810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035052.317720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1988
[1:1:0712/035052.317935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035052.318312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1028
[1:1:0712/035052.318560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7f6ffcf63070 0x192895c40a60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 935 0x7f6ffee8b2e0 0x1928958165e0 
[1:1:0712/035053.458233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035053.458503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035053.736800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://di.blizzard.cn/"
[1:1:0712/035053.737597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , g.handle, (e){return typeof it===Ct||e&&it.event.triggered===e.type?void 0:it.event.dispatch.apply(c.elem,argu
[1:1:0712/035053.737864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[69046:69046:0712/035053.758042:INFO:CONSOLE(4)] "1025", source: https://di.res.netease.com/pc/gw/20181025184036/pkg/app_840ebe8.js (4)
[1:1:0712/035054.498304:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035056.474949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1028, 7f6fff8a8881
[1:1:0712/035056.526899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"935 0x7f6ffee8b2e0 0x1928958165e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035056.527207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"935 0x7f6ffee8b2e0 0x1928958165e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035056.527628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035056.528165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035056.528370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035056.530602:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035056.530769:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035056.531081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1134
[1:1:0712/035056.531271:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1134 0x7f6ffcf63070 0x19289499a7e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1028 0x7f6ffcf63070 0x192895c40a60 
[1:1:0712/035057.199923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035057.200171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035057.301454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 868, 7f6fff8a8881
[1:1:0712/035057.354166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"796 0x7f6ffcf63070 0x1928944681e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035057.354555:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"796 0x7f6ffcf63070 0x1928944681e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035057.354978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035057.355570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035057.355771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035058.698012:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:15:0712/035059.577561:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0712/035100.144955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1134, 7f6fff8a8881
[1:1:0712/035100.205387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1028 0x7f6ffcf63070 0x192895c40a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035100.205804:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1028 0x7f6ffcf63070 0x192895c40a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035100.206236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035100.206797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035100.207015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035100.214465:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035100.214770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035100.215151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1251
[1:1:0712/035100.215402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f6ffcf63070 0x1928960694e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1134 0x7f6ffcf63070 0x19289499a7e0 
[1:1:0712/035100.217299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035100.217548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035100.217903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1252
[1:1:0712/035100.218131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7f6ffcf63070 0x19289606f1e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1134 0x7f6ffcf63070 0x19289499a7e0 
[1:1:0712/035100.220054:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035100.220262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035100.220625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1253
[1:1:0712/035100.220865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7f6ffcf63070 0x192895f418e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1134 0x7f6ffcf63070 0x19289499a7e0 
[1:1:0712/035100.952049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035100.952360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/035102.444230:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035102.948171:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0712/035103.254750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1251, 7f6fff8a8881
[1:1:0712/035103.306537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.306851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.307206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035103.307788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035103.307997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035103.311407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035103.311596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035103.311918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1352
[1:1:0712/035103.312139:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1352 0x7f6ffcf63070 0x192896051a60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1251 0x7f6ffcf63070 0x1928960694e0 
[1:1:0712/035103.314006:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035103.314176:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035103.314509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1353
[1:1:0712/035103.314703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7f6ffcf63070 0x1928944a7060 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1251 0x7f6ffcf63070 0x1928960694e0 
[1:1:0712/035103.316702:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035103.316965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035103.317395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1354
[1:1:0712/035103.317591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1354 0x7f6ffcf63070 0x192894760260 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1251 0x7f6ffcf63070 0x1928960694e0 
[1:1:0712/035103.319543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1252, 7f6fff8a8881
[1:1:0712/035103.378264:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.378670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.379149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035103.379797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035103.380017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035103.382555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1253, 7f6fff8a8881
[1:1:0712/035103.432482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.432802:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1134 0x7f6ffcf63070 0x19289499a7e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035103.433185:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035103.433730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035103.433911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035103.982896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035103.983144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:15:0712/035105.279692:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:15:0712/035105.919749:ERROR:render_media_log.cc(30)] MediaEvent: MEDIA_ERROR_LOG_ENTRY {"error":"FFmpegDemuxer: no supported streams"}
[1:1:0712/035106.086665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035106.087261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://di.blizzard.cn/"
[1:1:0712/035106.503795:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1352, 7f6fff8a8881
[1:1:0712/035106.561497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.561697:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.561897:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035106.562232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035106.562342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035106.570287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035106.570603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035106.571001:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1442
[1:1:0712/035106.571255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1442 0x7f6ffcf63070 0x192895dc8ce0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1352 0x7f6ffcf63070 0x192896051a60 
[1:1:0712/035106.589571:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035106.589823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035106.590160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1444
[1:1:0712/035106.590514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1444 0x7f6ffcf63070 0x1928958a8560 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1352 0x7f6ffcf63070 0x192896051a60 
[1:1:0712/035106.602701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1353, 7f6fff8a8881
[1:1:0712/035106.669438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.669650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.669944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035106.670622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035106.670866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035106.723077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1354, 7f6fff8a8881
[1:1:0712/035106.747841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.748040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1251 0x7f6ffcf63070 0x1928960694e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035106.748270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035106.748592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035106.748699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035107.050259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035107.050476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035108.267231:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[1:1:0712/035108.599450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://di.blizzard.cn/"
[1:1:0712/035108.752430:ERROR:render_media_log.cc(30)] MediaEvent: PIPELINE_ERROR DEMUXER_ERROR_NO_SUPPORTED_STREAMS
[69046:69046:0712/035109.069626:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/035109.549774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035109.550120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035110.164687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://di.blizzard.cn/"
[1:1:0712/035110.669135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://di.blizzard.cn/"
[1:1:0712/035111.117843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1507 0x7f6ffee8b2e0 0x192895dc8660 , "http://di.blizzard.cn/"
[1:1:0712/035111.122597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , window.NECaptcha_theme_light=function(i){function n(e){if(d[e])return d[e].exports;var o=d[e]={expor
[1:1:0712/035111.122887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035111.140957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035111.143195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1a10
[1:1:0712/035111.143379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035111.143724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1555
[1:1:0712/035111.144000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1555 0x7f6ffcf63070 0x1928945d5060 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1507 0x7f6ffee8b2e0 0x192895dc8660 
[1:1:0712/035111.497290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035111.497474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035112.356790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1555, 7f6fff8a8881
[1:1:0712/035112.403954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1507 0x7f6ffee8b2e0 0x192895dc8660 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035112.404272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1507 0x7f6ffee8b2e0 0x192895dc8660 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035112.404686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035112.405225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035112.405408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035112.407751:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035112.407924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035112.408249:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1584
[1:1:0712/035112.408441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1584 0x7f6ffcf63070 0x1928947b7e60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1555 0x7f6ffcf63070 0x1928945d5060 
[1:1:0712/035112.543575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035112.543795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035112.962999:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1584, 7f6fff8a8881
[1:1:0712/035112.985290:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1555 0x7f6ffcf63070 0x1928945d5060 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035112.985499:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1555 0x7f6ffcf63070 0x1928945d5060 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035112.985723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035112.986067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035112.986180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035113.032609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1588 0x7f6ffee8b2e0 0x192895cdc160 , "http://di.blizzard.cn/"
[1:1:0712/035113.046914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , window.NECaptcha=function(e){function t(i){if(n[i])return n[i].exports;var r=n[i]={exports:{},id:i,l
[1:1:0712/035113.047161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035113.913330:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035115.059956:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035115.060412:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035117.404609:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 840000, 0x13061c0429c8, 0x1928941a1948
[1:1:0712/035117.404889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 840000
[1:1:0712/035117.405296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1621
[1:1:0712/035117.405533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1621 0x7f6ffcf63070 0x19289588c6e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1588 0x7f6ffee8b2e0 0x192895cdc160 
[1:1:0712/035117.579989:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035117.582139:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1a10
[1:1:0712/035117.582333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035117.582660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1622
[1:1:0712/035117.582851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1622 0x7f6ffcf63070 0x1928958a8460 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1588 0x7f6ffee8b2e0 0x192895cdc160 
[1:1:0712/035117.860730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035117.860982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035117.938892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1442, 7f6fff8a8881
[1:1:0712/035118.005988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1352 0x7f6ffcf63070 0x192896051a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035118.006320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1352 0x7f6ffcf63070 0x192896051a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035118.006685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035118.007189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035118.007410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035118.009747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1444, 7f6fff8a8881
[1:1:0712/035118.054574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1352 0x7f6ffcf63070 0x192896051a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035118.054879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1352 0x7f6ffcf63070 0x192896051a60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035118.055228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035118.055754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035118.055933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035119.561341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035119.561587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035119.775318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1622, 7f6fff8a8881
[1:1:0712/035119.796028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1588 0x7f6ffee8b2e0 0x192895cdc160 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035119.796218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1588 0x7f6ffee8b2e0 0x192895cdc160 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035119.796455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035119.796790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035119.796896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035119.797695:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035119.797798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035119.797972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1671
[1:1:0712/035119.798075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1671 0x7f6ffcf63070 0x192895cce4e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1622 0x7f6ffcf63070 0x1928958a8460 
[1:1:0712/035120.107849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035120.108106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035120.385786:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://di.blizzard.cn/"
[1:1:0712/035120.386631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , g.handle, (e){return typeof it===Ct||e&&it.event.triggered===e.type?void 0:it.event.dispatch.apply(c.elem,argu
[1:1:0712/035120.386817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035120.629951:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1671, 7f6fff8a8881
[1:1:0712/035120.695859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1622 0x7f6ffcf63070 0x1928958a8460 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035120.696254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1622 0x7f6ffcf63070 0x1928958a8460 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035120.696616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035120.697144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035120.697323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035120.699346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035120.699509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035120.699830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1695
[1:1:0712/035120.700063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1695 0x7f6ffcf63070 0x1928969a8d60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1671 0x7f6ffcf63070 0x192895cce4e0 
[1:1:0712/035120.929165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , document.readyState
[1:1:0712/035120.929459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035121.085042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1695, 7f6fff8a8881
[1:1:0712/035121.153750:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1671 0x7f6ffcf63070 0x192895cce4e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035121.154115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1671 0x7f6ffcf63070 0x192895cce4e0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035121.154485:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035121.155002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035121.155200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035121.356623:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[69046:69046:0712/035121.361433:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/035121.364418:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x192893f4ce20
[1:1:0712/035121.364739:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[69046:69046:0712/035121.368674:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 4, 
[69046:69046:0712/035121.424471:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://di.blizzard.cn/, http://di.blizzard.cn/, 4
[69046:69046:0712/035121.424570:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 8, http://di.blizzard.cn/, http://di.blizzard.cn
[1:1:0712/035121.503801:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035121.504091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035121.504594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1730
[1:1:0712/035121.504881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1730 0x7f6ffcf63070 0x192895f6a260 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035121.973588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035121.973843:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035121.974182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1731
[1:1:0712/035121.974399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1731 0x7f6ffcf63070 0x192893ea8560 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035121.992125:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035121.992389:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035121.992772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1732
[1:1:0712/035121.993027:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1732 0x7f6ffcf63070 0x1928958acae0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035121.999092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035121.999309:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035121.999704:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1734
[1:1:0712/035121.999965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1734 0x7f6ffcf63070 0x192895cceee0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035122.007397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035122.007679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035122.008071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1737
[1:1:0712/035122.008440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1737 0x7f6ffcf63070 0x1928957dd560 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035122.010787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035122.011004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035122.011411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1738
[1:1:0712/035122.011655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1738 0x7f6ffcf63070 0x192895778a60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1695 0x7f6ffcf63070 0x1928969a8d60 
[1:1:0712/035124.016928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1730, 7f6fff8a8881
[1:1:0712/035124.081171:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.081386:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.081598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035124.081927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035124.082041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035124.117794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1734, 7f6fff8a8881
[1:1:0712/035124.146318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.146528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.146735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035124.147055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035124.147172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035124.147866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1737, 7f6fff8a8881
[1:1:0712/035124.172539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.172745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.172976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035124.173282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035124.173398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035124.206576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1738, 7f6fff8a8881
[1:1:0712/035124.231405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.231615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1695 0x7f6ffcf63070 0x1928969a8d60 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035124.231820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035124.232205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035124.232312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035124.945498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1777 0x7f6ffee8b2e0 0x192894798de0 , "http://di.blizzard.cn/"
[1:1:0712/035124.946578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , __JSONP_0d8wk8y_0({"data":{"bg":["http://necaptcha.nosdn.127.net/7e8729858e0d45588fb92f523b144374.jp
[1:1:0712/035124.946806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035124.950648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1988
[1:1:0712/035124.950856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035124.951250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1801
[1:1:0712/035124.951499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1801 0x7f6ffcf63070 0x1928944f1460 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1777 0x7f6ffee8b2e0 0x192894798de0 
[1:1:0712/035125.432778:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1801, 7f6fff8a8881
[1:1:0712/035125.462120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1777 0x7f6ffee8b2e0 0x192894798de0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035125.462706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1777 0x7f6ffee8b2e0 0x192894798de0 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035125.463455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035125.464511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035125.464909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035125.470534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035125.470907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 1
[1:1:0712/035125.471608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1820
[1:1:0712/035125.472082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1820 0x7f6ffcf63070 0x192896051a60 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1801 0x7f6ffcf63070 0x1928944f1460 
[1:1:0712/035125.581112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1820, 7f6fff8a8881
[1:1:0712/035125.650995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3495f5842860","ptid":"1801 0x7f6ffcf63070 0x1928944f1460 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035125.651453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://di.blizzard.cn/","ptid":"1801 0x7f6ffcf63070 0x1928944f1460 ","rf":"5:3_http://di.blizzard.cn/"}
[1:1:0712/035125.652151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://di.blizzard.cn/"
[1:1:0712/035125.652585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://di.blizzard.cn/, 3495f5842860, , , (){try{return r.apply(this,o||arguments)}catch(u){if(n(u),u.stack&&console&&console.error&&console.e
[1:1:0712/035125.652900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://di.blizzard.cn/", "di.blizzard.cn", 3, 1, , , 0
[1:1:0712/035125.725927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035125.726307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035125.726708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1828
[1:1:0712/035125.726950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1828 0x7f6ffcf63070 0x192893f383e0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1820 0x7f6ffcf63070 0x192896051a60 
[1:1:0712/035125.733072:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x13061c0429c8, 0x1928941a1950
[1:1:0712/035125.733328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://di.blizzard.cn/", 6000
[1:1:0712/035125.733689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://di.blizzard.cn/, 1829
[1:1:0712/035125.733924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1829 0x7f6ffcf63070 0x192895fa4ee0 , 5:3_http://di.blizzard.cn/, 1, -5:3_http://di.blizzard.cn/, 1820 0x7f6ffcf63070 0x192896051a60 
