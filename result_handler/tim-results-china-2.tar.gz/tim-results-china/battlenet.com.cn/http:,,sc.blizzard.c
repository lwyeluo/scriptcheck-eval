[0712/034945.785927:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034945.786328:INFO:switcher_clone.cc(787)] backtrace rip is 7f2393f3f891
[0712/034946.786207:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034946.786601:INFO:switcher_clone.cc(787)] backtrace rip is 7f9854ffb891
[1:1:0712/034946.798430:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/034946.798679:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/034946.803966:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[68922:68922:0712/034947.839496:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/81670bf0-8568-4652-a8cd-dec325357461
[0712/034948.009643:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034948.010074:INFO:switcher_clone.cc(787)] backtrace rip is 7fa18c6af891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[68954:68954:0712/034948.181776:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68954
[68966:68966:0712/034948.182209:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68966
[68922:68922:0712/034948.482286:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[68922:68952:0712/034948.483050:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/034948.483266:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034948.483479:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034948.484110:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034948.484262:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/034948.487184:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x19b14934, 1
[1:1:0712/034948.487513:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x9d03914, 0
[1:1:0712/034948.487807:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xa4207c3, 3
[1:1:0712/034948.488023:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x345e0a5a, 2
[1:1:0712/034948.488275:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1439ffffffd009 3449ffffffb119 5a0a5e34 ffffffc307420a , 10104, 4
[1:1:0712/034948.489420:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68922:68952:0712/034948.489699:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING9�	4I�Z
^4�B
Xl&8
[1:1:0712/034948.489684:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98532360a0, 3
[68922:68952:0712/034948.489792:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 9�	4I�Z
^4�B
h�Xl&8
[1:1:0712/034948.489867:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98533c1080, 2
[68922:68952:0712/034948.490077:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/034948.490042:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f983d084d20, -2
[68922:68952:0712/034948.490194:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68974, 4, 1439d009 3449b119 5a0a5e34 c307420a 
[1:1:0712/034948.508938:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034948.509775:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 345e0a5a
[1:1:0712/034948.510697:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 345e0a5a
[1:1:0712/034948.512271:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 345e0a5a
[1:1:0712/034948.513740:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.513917:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.514088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.514269:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.514880:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 345e0a5a
[1:1:0712/034948.515190:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9854ffb7ba
[1:1:0712/034948.515319:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9854ff2def, 7f9854ffb77a, 7f9854ffd0cf
[1:1:0712/034948.520760:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 345e0a5a
[1:1:0712/034948.521083:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 345e0a5a
[1:1:0712/034948.521772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 345e0a5a
[1:1:0712/034948.523715:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.523905:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.524078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.524253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 345e0a5a
[1:1:0712/034948.525429:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 345e0a5a
[1:1:0712/034948.525797:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9854ffb7ba
[1:1:0712/034948.525927:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9854ff2def, 7f9854ffb77a, 7f9854ffd0cf
[1:1:0712/034948.533843:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034948.534384:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034948.534583:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd03423318, 0x7ffd03423298)
[1:1:0712/034948.553241:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034948.560457:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[68922:68922:0712/034949.160021:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68922:68922:0712/034949.161336:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68922:68933:0712/034949.183793:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[68922:68933:0712/034949.183925:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[68922:68922:0712/034949.184108:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[68922:68922:0712/034949.184628:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[68922:68922:0712/034949.184839:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,68974, 4
[1:7:0712/034949.190360:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68922:68944:0712/034949.248259:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/034949.295097:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe07b259b220
[1:1:0712/034949.295379:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/034949.666509:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[68922:68922:0712/034951.409222:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[68922:68922:0712/034951.409364:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034951.451648:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034951.455468:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034952.575299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034952.575657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034952.591890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034952.592162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034952.658110:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034952.915114:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034952.915289:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034953.133555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034953.141684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034953.141919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034953.176670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034953.187252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034953.187473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034953.199344:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/034953.202698:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe07b2599e20
[1:1:0712/034953.202895:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[68922:68922:0712/034953.203596:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[68922:68922:0712/034953.218251:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[68922:68922:0712/034953.243197:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[68922:68922:0712/034953.243355:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034953.250155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034954.029523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f983ec5f2e0 0xe07b2578160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034954.030217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/034954.030339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034954.030865:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68922:68922:0712/034954.065986:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/034954.067899:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe07b259a820
[1:1:0712/034954.068174:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[68922:68922:0712/034954.073814:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/034954.078658:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034954.078797:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[68922:68922:0712/034954.091314:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[68922:68922:0712/034954.102229:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68922:68922:0712/034954.103204:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68922:68933:0712/034954.109037:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[68922:68933:0712/034954.109130:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[68922:68922:0712/034954.109260:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[68922:68922:0712/034954.109332:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[68922:68922:0712/034954.109463:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,68974, 4
[1:7:0712/034954.119267:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034954.731961:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/034955.122475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7f983ec5f2e0 0xe07b293fae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034955.123565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/034955.123858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034955.124638:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68922:68922:0712/034955.179730:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[68922:68922:0712/034955.179802:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/034955.198195:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034955.603150:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[68922:68922:0712/034955.875390:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[68922:68952:0712/034955.875898:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/034955.876094:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034955.876370:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034955.876821:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034955.877012:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/034955.880701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x90b5e58, 1
[1:1:0712/034955.881082:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24d54996, 0
[1:1:0712/034955.881230:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1e024c05, 3
[1:1:0712/034955.881370:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b9558f3, 2
[1:1:0712/034955.881552:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9649ffffffd524 585e0b09 fffffff358ffffff951b 054c021e , 10104, 5
[1:1:0712/034955.882562:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68922:68952:0712/034955.882843:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�I�$X^	�X�L�n&8
[68922:68952:0712/034955.882933:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �I�$X^	�X�L�*�n&8
[1:1:0712/034955.883070:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98532360a0, 3
[68922:68952:0712/034955.883253:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 69019, 5, 9649d524 585e0b09 f358951b 054c021e 
[1:1:0712/034955.883285:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f98533c1080, 2
[1:1:0712/034955.883576:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f983d084d20, -2
[1:1:0712/034955.906619:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034955.906943:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b9558f3
[1:1:0712/034955.907283:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b9558f3
[1:1:0712/034955.907964:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b9558f3
[1:1:0712/034955.909363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.909571:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.909753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.909928:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.910581:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b9558f3
[1:1:0712/034955.910878:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9854ffb7ba
[1:1:0712/034955.911009:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9854ff2def, 7f9854ffb77a, 7f9854ffd0cf
[1:1:0712/034955.917883:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b9558f3
[1:1:0712/034955.918343:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b9558f3
[1:1:0712/034955.919239:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b9558f3
[1:1:0712/034955.921749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.922030:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.922264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.922521:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b9558f3
[1:1:0712/034955.924093:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b9558f3
[1:1:0712/034955.924579:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9854ffb7ba
[1:1:0712/034955.924750:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9854ff2def, 7f9854ffb77a, 7f9854ffd0cf
[1:1:0712/034955.934357:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034955.934999:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034955.935186:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd03423318, 0x7ffd03423298)
[1:1:0712/034955.949167:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034955.951405:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/034956.050492:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034956.050783:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034956.169377:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe07b2574220
[1:1:0712/034956.169656:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[68922:68922:0712/034956.246354:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68922:68922:0712/034956.248251:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68922:68933:0712/034956.266819:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[68922:68933:0712/034956.266919:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[68922:68922:0712/034956.268853:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://sc.blizzard.cn/
[68922:68922:0712/034956.268954:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sc.blizzard.cn/, http://sc.blizzard.cn/, 1
[68922:68922:0712/034956.269106:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://sc.blizzard.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:49:56 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 10:52:56 GMT Cache-Control: max-age=180 Content-Encoding: gzip  ,69019, 5
[1:7:0712/034956.275355:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034956.370022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034956.375500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 073610b2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/034956.375921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034956.377027:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://sc.blizzard.cn/
[1:1:0712/034956.385162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034956.529028:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68922:68922:0712/034956.536822:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sc.blizzard.cn/, http://sc.blizzard.cn/, 1
[68922:68922:0712/034956.536933:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://sc.blizzard.cn/, http://sc.blizzard.cn
[1:1:0712/034956.581369:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034956.667577:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034956.667882:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sc.blizzard.cn/"
[1:1:0712/034956.698902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 117 0x7f983cd37070 0xe07b257dc60 , "http://sc.blizzard.cn/"
[1:1:0712/034956.701507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , 
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
 
[1:1:0712/034956.701795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034956.701760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/034956.702444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 073610a01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/034956.702671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034957.167818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143, "http://sc.blizzard.cn/"
[1:1:0712/034957.171590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , !function(g,a,e){var t,o,r,n,s={};function i(){var e,t,o=s.cookie.get("mp_versions_hubble_jsSDK"),r=
[1:1:0712/034957.171971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/034957.184259:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034957.199727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143, "http://sc.blizzard.cn/"
[1:1:0712/034957.220609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143, "http://sc.blizzard.cn/"
[1:1:0712/034957.227691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 143, "http://sc.blizzard.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/034957.975497:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034957.975973:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034957.981295:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034957.981707:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034957.982097:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[68922:68922:0712/035012.374103:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/035012.426758:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/035012.497216:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 15.2984, 0, 0
[1:1:0712/035012.497444:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035012.526281:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/035012.739217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/035012.739464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035013.109332:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035013.109549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sc.blizzard.cn/"
[1:1:0712/035013.189301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f98533c1080 0xe07b263b380 1 0 0xe07b263b398 , "http://sc.blizzard.cn/"
[1:1:0712/035013.223429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , /*! jQuery v3.3.1 | (c) JS Foundation and other contributors | jquery.org/license */
!function(e,t){
[1:1:0712/035013.223621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035013.412046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://sc.blizzard.cn/"
[1:1:0712/035013.485217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f983ec5f2e0 0xe07b264c9e0 , "http://sc.blizzard.cn/"
[1:1:0712/035013.485751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , getHubbleJSSDKVersions('DATracker.globals.1.6.12.2');
[1:1:0712/035013.485861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035013.494402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sc.blizzard.cn/"
[1:1:0712/035013.513390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f983ec5f2e0 0xe07b2692460 , "http://sc.blizzard.cn/"
[1:1:0712/035013.529296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/035013.529575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035013.561028:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2150cf8c29c8, 0xe07b20af160
[1:1:0712/035013.561319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sc.blizzard.cn/", 0
[1:1:0712/035013.561679:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 255
[1:1:0712/035013.561918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 255 0x7f983cd37070 0xe07b2692f60 , 5:3_http://sc.blizzard.cn/, 1, -5:3_http://sc.blizzard.cn/, 209 0x7f983ec5f2e0 0xe07b2692460 
[1:1:0712/035013.563275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2150cf8c29c8, 0xe07b20af160
[1:1:0712/035013.563485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sc.blizzard.cn/", 0
[1:1:0712/035013.563865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 256
[1:1:0712/035013.564122:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 256 0x7f983cd37070 0xe07b2b170e0 , 5:3_http://sc.blizzard.cn/, 1, -5:3_http://sc.blizzard.cn/, 209 0x7f983ec5f2e0 0xe07b2692460 
[1:1:0712/035013.863081:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/035013.863350:INFO:render_frame_impl.cc(7019)] 	 [url] = http://sc.blizzard.cn
[68922:68922:0712/035013.864806:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://sc.blizzard.cn/
[68922:68922:0712/035013.933041:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68922:68922:0712/035013.936466:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68922:68933:0712/035013.946062:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[68922:68933:0712/035013.946160:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[68922:68922:0712/035013.946334:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://sc.blizzard.cn/
[68922:68922:0712/035013.946411:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sc.blizzard.cn/, http://sc.blizzard.cn/home, 1
[68922:68922:0712/035013.946497:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://sc.blizzard.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:50:13 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Vary: Accept-Encoding Content-Encoding: gzip  ,69019, 5
[1:7:0712/035013.949067:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/035013.972508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , document.readyState
[1:1:0712/035013.972768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035014.003132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sc.blizzard.cn/"
[1:1:0712/035014.003963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , a.onload, (){window[e]=null;d()}
[1:1:0712/035014.004256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035014.056707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 255, 7f983f67c881
[1:1:0712/035014.068867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38fb98762860","ptid":"209 0x7f983ec5f2e0 0xe07b2692460 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035014.069205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sc.blizzard.cn/","ptid":"209 0x7f983ec5f2e0 0xe07b2692460 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035014.069720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sc.blizzard.cn/"
[1:1:0712/035014.070313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0712/035014.070533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035014.284928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 256, 7f983f67c881
[1:1:0712/035014.299257:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38fb98762860","ptid":"209 0x7f983ec5f2e0 0xe07b2692460 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035014.299601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sc.blizzard.cn/","ptid":"209 0x7f983ec5f2e0 0xe07b2692460 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035014.299993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sc.blizzard.cn/"
[1:1:0712/035014.300513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0712/035014.300727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035014.611850:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://sc.blizzard.cn/
[1:1:0712/035015.135376:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68922:68922:0712/035015.158095:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sc.blizzard.cn/, http://sc.blizzard.cn/, 1
[68922:68922:0712/035015.158212:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://sc.blizzard.cn/, http://sc.blizzard.cn
[1:1:0712/035015.243580:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035015.324543:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/035015.357229:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/035015.357558:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sc.blizzard.cn/home"
[1:1:0712/035015.629908:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/035015.761709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7f983ec5f2e0 0xe07b279c4e0 , "http://sc.blizzard.cn/home"
[1:1:0712/035015.766118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/035015.766426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/home", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035015.816043:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2150cf8cba18, 0xe07b20af198
[1:1:0712/035015.816382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sc.blizzard.cn/home", 0
[1:1:0712/035015.816955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 387
[1:1:0712/035015.817215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 387 0x7f983cd37070 0xe07b2250ee0 , 5:3_http://sc.blizzard.cn/, 1, -5:3_http://sc.blizzard.cn/, 362 0x7f983ec5f2e0 0xe07b279c4e0 
[1:1:0712/035016.068501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sc.blizzard.cn/, 387, 7f983f67c881
[1:1:0712/035016.086929:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"38fb98762860","ptid":"362 0x7f983ec5f2e0 0xe07b279c4e0 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035016.087326:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sc.blizzard.cn/","ptid":"362 0x7f983ec5f2e0 0xe07b279c4e0 ","rf":"5:3_http://sc.blizzard.cn/"}
[1:1:0712/035016.087723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sc.blizzard.cn/home"
[1:1:0712/035016.088383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0712/035016.088618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/home", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035016.977185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f983cd37070 0xe07b2e9f560 , "http://sc.blizzard.cn/home"
[1:1:0712/035016.979308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , 
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('
[1:1:0712/035016.979541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/home", "sc.blizzard.cn", 3, 1, , , 0
[1:1:0712/035017.647795:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.542548, 1133, 0
[1:1:0712/035017.648061:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/035017.882670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f983ec5f2e0 0xe07b25a7e60 , "http://sc.blizzard.cn/home"
[1:1:0712/035017.892170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sc.blizzard.cn/, 38fb98762860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/035017.892450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sc.blizzard.cn/home", "sc.blizzard.cn", 3, 1, , , 0
		remove user.10_30fc8c06 -> 0
