[0712/120433.869439:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120433.869819:INFO:switcher_clone.cc(787)] backtrace rip is 7f1ad96f8891
[0712/120434.868923:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120434.869269:INFO:switcher_clone.cc(787)] backtrace rip is 7feaa59e3891
[1:1:0712/120434.880931:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/120434.881176:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/120434.893064:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/120436.239840:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120436.240245:INFO:switcher_clone.cc(787)] backtrace rip is 7f7fa96e1891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5264:5264:0712/120436.406172:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5264
[5274:5274:0712/120436.406579:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5274
[5232:5232:0712/120436.426472:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/60cbd3fd-9f47-4c36-b3a3-0c0ac7f83be6
[5232:5232:0712/120436.837058:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5232:5262:0712/120436.837916:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/120436.838264:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120436.838661:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120436.839766:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120436.840111:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/120436.845147:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x83817d3, 1
[1:1:0712/120436.845783:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x305bc4de, 0
[1:1:0712/120436.846220:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2459c5e0, 3
[1:1:0712/120436.846590:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x93f7770, 2
[1:1:0712/120436.846957:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdeffffffc45b30 ffffffd3173808 70773f09 ffffffe0ffffffc55924 , 10104, 4
[1:1:0712/120436.848355:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5232:5262:0712/120436.848683:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��[0�8pw?	��Y$���"
[5232:5262:0712/120436.848746:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��[0�8pw?	��Y$8�"
[1:1:0712/120436.848675:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feaa3c1e0a0, 3
[5232:5262:0712/120436.849041:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5232:5262:0712/120436.849112:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5284, 4, dec45b30 d3173808 70773f09 e0c55924 
[1:1:0712/120436.849115:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feaa3da9080, 2
[1:1:0712/120436.849368:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea8da6cd20, -2
[1:1:0712/120436.867569:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120436.868504:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 93f7770
[1:1:0712/120436.869464:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 93f7770
[1:1:0712/120436.871059:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 93f7770
[1:1:0712/120436.872543:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.872843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.873126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.873389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.874115:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 93f7770
[1:1:0712/120436.874500:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feaa59e37ba
[1:1:0712/120436.874720:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feaa59dadef, 7feaa59e377a, 7feaa59e50cf
[1:1:0712/120436.880212:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 93f7770
[1:1:0712/120436.880624:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 93f7770
[1:1:0712/120436.881405:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 93f7770
[1:1:0712/120436.883429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.883726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.884053:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.884322:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 93f7770
[1:1:0712/120436.885580:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 93f7770
[1:1:0712/120436.886005:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feaa59e37ba
[1:1:0712/120436.886228:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feaa59dadef, 7feaa59e377a, 7feaa59e50cf
[1:1:0712/120436.893592:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120436.894182:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120436.894426:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffdcb8f3c8, 0x7fffdcb8f348)
[1:1:0712/120436.909204:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120436.914693:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5232:5232:0712/120437.514097:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5232:5232:0712/120437.515260:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5232:5232:0712/120437.526358:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5232:5232:0712/120437.526414:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5232:5232:0712/120437.526479:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5284, 4
[5232:5243:0712/120437.528062:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5232:5243:0712/120437.528199:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/120437.529102:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[5232:5255:0712/120437.600721:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/120437.655087:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x14dc4a85e220
[1:1:0712/120437.655390:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/120438.064833:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[5232:5232:0712/120439.786548:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5232:5232:0712/120439.786669:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/120439.793494:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120439.795914:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120440.695691:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120440.764293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120440.764524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120440.769495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120440.769644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120440.859403:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120440.859561:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120441.097083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120441.105768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120441.106075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120441.137668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120441.148002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120441.148384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120441.162333:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/120441.166303:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x14dc4a85ce20
[1:1:0712/120441.166485:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5232:5232:0712/120441.169271:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[5232:5232:0712/120441.177383:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5232:5232:0712/120441.195934:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5232:5232:0712/120441.196086:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/120441.233410:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120442.191021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fea8f6472e0 0x14dc4aa298e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120442.192253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/120442.192505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120442.193901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120442.266094:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x14dc4a85d820
[1:1:0712/120442.266505:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5232:5232:0712/120442.283352:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[5232:5232:0712/120442.288863:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/120442.290518:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/120442.290718:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5232:5232:0712/120442.303804:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5232:5232:0712/120442.316125:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5232:5232:0712/120442.317168:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5232:5243:0712/120442.323397:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5232:5243:0712/120442.323513:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5232:5232:0712/120442.323677:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5232:5232:0712/120442.323754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5232:5232:0712/120442.323892:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5284, 4
[1:7:0712/120442.327194:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120442.946254:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/120443.175623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fea8f6472e0 0x14dc4ac262e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120443.176662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/120443.176981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120443.177764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5232:5232:0712/120443.302434:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5232:5232:0712/120443.302543:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/120443.317008:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120443.772166:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[5232:5232:0712/120444.051429:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5232:5262:0712/120444.052050:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/120444.052329:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120444.052620:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120444.053053:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120444.053267:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/120444.056464:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x785e648, 1
[1:1:0712/120444.056891:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e2b2fe0, 0
[1:1:0712/120444.057118:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x25450e4e, 3
[1:1:0712/120444.057278:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30e4bb55, 2
[1:1:0712/120444.057430:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe02f2b1e 48ffffffe6ffffff8507 55ffffffbbffffffe430 4e0e4525 , 10104, 5
[1:1:0712/120444.058425:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5232:5262:0712/120444.058686:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�/+H�U��0NE%���"
[5232:5262:0712/120444.058762:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �/+H�U��0NE%ȍ���"
[1:1:0712/120444.058675:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feaa3c1e0a0, 3
[5232:5262:0712/120444.059024:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5328, 5, e02f2b1e 48e68507 55bbe430 4e0e4525 
[1:1:0712/120444.058948:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feaa3da9080, 2
[1:1:0712/120444.059217:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea8da6cd20, -2
[1:1:0712/120444.083567:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120444.083804:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30e4bb55
[1:1:0712/120444.084058:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30e4bb55
[1:1:0712/120444.084339:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30e4bb55
[1:1:0712/120444.084800:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.084930:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.085036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.085134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.085377:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30e4bb55
[1:1:0712/120444.085515:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feaa59e37ba
[1:1:0712/120444.085605:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feaa59dadef, 7feaa59e377a, 7feaa59e50cf
[1:1:0712/120444.087159:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30e4bb55
[1:1:0712/120444.087330:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30e4bb55
[1:1:0712/120444.087611:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30e4bb55
[1:1:0712/120444.088387:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.088512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.088619:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.088718:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30e4bb55
[1:1:0712/120444.089196:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30e4bb55
[1:1:0712/120444.089364:INFO:switcher_clone.cc(775)] clone wrapper rip is 7feaa59e37ba
[1:1:0712/120444.089447:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7feaa59dadef, 7feaa59e377a, 7feaa59e50cf
[1:1:0712/120444.091739:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120444.092110:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120444.092213:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffdcb8f3c8, 0x7fffdcb8f348)
[1:1:0712/120444.104100:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120444.108407:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/120444.142731:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120444.143010:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120444.310472:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x14dc4a820220
[1:1:0712/120444.310651:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/120444.635481:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120444.640403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 30d32932e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/120444.640723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120444.643169:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120444.861206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120444.862545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 30d329201f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/120444.862890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[5232:5232:0712/120445.119015:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5232:5232:0712/120445.125675:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5232:5243:0712/120445.147734:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[5232:5243:0712/120445.147788:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[5232:5232:0712/120445.149973:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://sg.godaddy.com/
[5232:5232:0712/120445.150022:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://sg.godaddy.com/, https://sg.godaddy.com/zh/legal/agreements/privacy-policy, 1
[5232:5232:0712/120445.150084:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://sg.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 19:04:45 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 19:04:45 GMT x-frame-options:DENY x-arc:6  ,5328, 5
[1:7:0712/120445.151076:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120445.204979:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://sg.godaddy.com/
[1:1:0712/120445.207712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120445.209830:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/120445.210074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 30d32932e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/120445.210370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[5232:5232:0712/120445.392850:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://sg.godaddy.com/, https://sg.godaddy.com/, 1
[5232:5232:0712/120445.392975:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://sg.godaddy.com/, https://sg.godaddy.com
[1:1:0712/120445.401876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120445.412672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120445.413789:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/120445.414076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 30d32932e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/120445.414438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120445.490204:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120445.559931:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120445.676004:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120445.676342:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120445.700172:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7fea8d71f070 0x14dc4a94ca60 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120445.701795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/120445.702062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120445.705165:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120445.824840:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120446.079083:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/120446.148294:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120446.478755:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/120446.883116:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/120446.933154:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/120447.029036:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/120447.060884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fea8d71f070 0x14dc4a9fb760 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.062159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/120447.062416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120447.063737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7fea8d71f070 0x14dc4a9fb760 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.084135:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/120447.322037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fea8d71f070 0x14dc4aa24ce0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.323387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/120447.323675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120447.326438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fea8d71f070 0x14dc4aa24ce0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.335623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fea8d71f070 0x14dc4aa24ce0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.345848:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 200
[1:1:0712/120447.346452:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 229
[1:1:0712/120447.346758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 229 0x7fea8d71f070 0x14dc4a9f4ce0 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 221 0x7fea8d71f070 0x14dc4aa24ce0 
[1:1:0712/120447.349563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fea8d71f070 0x14dc4aa24ce0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.360235:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fea8d71f070 0x14dc4aa24ce0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.464082:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.138539, 1523, 1
[1:1:0712/120447.464379:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120447.622162:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120447.622463:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.623402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7fea8d71f070 0x14dc4a9f08e0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.624343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/120447.624578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120447.626531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7fea8d71f070 0x14dc4a9f08e0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.635340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7fea8d71f070 0x14dc4a9f08e0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.656011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7fea8d71f070 0x14dc4a9f08e0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.748219:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.125616, 1218, 1
[1:1:0712/120447.748545:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120447.750254:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 229, 7fea900648db
[1:1:0712/120447.763554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"221 0x7fea8d71f070 0x14dc4aa24ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120447.763863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"221 0x7fea8d71f070 0x14dc4aa24ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120447.764213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 257
[1:1:0712/120447.764441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 257 0x7fea8d71f070 0x14dc4a9c2ce0 , 5:3_https://sg.godaddy.com/, 0, , 229 0x7fea8d71f070 0x14dc4a9f4ce0 
[1:1:0712/120447.764766:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.765399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120447.765609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120447.957884:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120447.958183:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.959100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.960051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/120447.960297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120447.962982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.967195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.971418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.978411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120447.980994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fea8d71f070 0x14dc4a9c3be0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/120448.832331:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120448.832890:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120448.833370:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120448.834715:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120448.835151:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120452.383804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120452.419883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120452.611732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 257, 7fea900648db
[1:1:0712/120452.625136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"229 0x7fea8d71f070 0x14dc4a9f4ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120452.625411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"229 0x7fea8d71f070 0x14dc4a9f4ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120452.625731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 308
[1:1:0712/120452.625959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 308 0x7fea8d71f070 0x14dc4ac55ae0 , 5:3_https://sg.godaddy.com/, 0, , 257 0x7fea8d71f070 0x14dc4a9c2ce0 
[1:1:0712/120452.626299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120452.626900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120452.627149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120452.917696:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120452.949154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 308, 7fea900648db
[1:1:0712/120452.963614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"257 0x7fea8d71f070 0x14dc4a9c2ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120452.963955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"257 0x7fea8d71f070 0x14dc4a9c2ce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120452.964395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 320
[1:1:0712/120452.964632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 320 0x7fea8d71f070 0x14dc4b33dce0 , 5:3_https://sg.godaddy.com/, 0, , 308 0x7fea8d71f070 0x14dc4ac55ae0 
[1:1:0712/120452.965079:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120452.965721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120452.965936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120453.124218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7fea8f6472e0 0x14dc4b1947e0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120453.134607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/120453.134900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120453.182982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7fea8f6472e0 0x14dc4aa24760 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120453.195888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/120453.196164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120453.495822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 100
[1:1:0712/120453.496482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 338
[1:1:0712/120453.496765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 338 0x7fea8d71f070 0x14dc4b4b1560 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 323 0x7fea8f6472e0 0x14dc4aa24760 
		remove user.10_5198e327 -> 0
[1:1:0712/120455.067214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a198
[1:1:0712/120455.067530:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120455.068128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 375
[1:1:0712/120455.068384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7fea8d71f070 0x14dc4bb9b960 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 323 0x7fea8f6472e0 0x14dc4aa24760 
[1:1:0712/120455.093472:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.213432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fea8f6472e0 0x14dc4a941fe0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.213996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/120455.214127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120455.214365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.219734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 320, 7fea900648db
[1:1:0712/120455.229383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"308 0x7fea8d71f070 0x14dc4ac55ae0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.229536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"308 0x7fea8d71f070 0x14dc4ac55ae0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.229753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 388
[1:1:0712/120455.229871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7fea8d71f070 0x14dc4b194b60 , 5:3_https://sg.godaddy.com/, 0, , 320 0x7fea8d71f070 0x14dc4b33dce0 
[1:1:0712/120455.230014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.230267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120455.230371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120455.893256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 338, 7fea900648db
[1:1:0712/120455.898112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"323 0x7fea8f6472e0 0x14dc4aa24760 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.898274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"323 0x7fea8f6472e0 0x14dc4aa24760 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.898460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 393
[1:1:0712/120455.898571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 393 0x7fea8d71f070 0x14dc4bc2ece0 , 5:3_https://sg.godaddy.com/, 0, , 338 0x7fea8d71f070 0x14dc4b4b1560 
[1:1:0712/120455.898723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.899053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120455.899164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120455.905486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 375, 7fea90064881
[1:1:0712/120455.910390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"323 0x7fea8f6472e0 0x14dc4aa24760 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.910561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"323 0x7fea8f6472e0 0x14dc4aa24760 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120455.910755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120455.911081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/120455.911202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120456.543460:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 388, 7fea900648db
[1:1:0712/120456.565576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"320 0x7fea8d71f070 0x14dc4b33dce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120456.565961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"320 0x7fea8d71f070 0x14dc4b33dce0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120456.566479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 416
[1:1:0712/120456.566727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7fea8d71f070 0x14dc4bf430e0 , 5:3_https://sg.godaddy.com/, 0, , 388 0x7fea8d71f070 0x14dc4b194b60 
[1:1:0712/120456.567099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120456.567834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120456.568111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120456.804402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 393, 7fea900648db
[1:1:0712/120456.822486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"338 0x7fea8d71f070 0x14dc4b4b1560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120456.822734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"338 0x7fea8d71f070 0x14dc4b4b1560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120456.823101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 425
[1:1:0712/120456.823316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 425 0x7fea8d71f070 0x14dc4bf469e0 , 5:3_https://sg.godaddy.com/, 0, , 393 0x7fea8d71f070 0x14dc4bc2ece0 
[1:1:0712/120456.823600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120456.824226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120456.824423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120456.891943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7fea8f6472e0 0x14dc4a9d2560 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120456.905162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/120456.905459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120456.966300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a148
[1:1:0712/120456.966613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120456.967171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 426
[1:1:0712/120456.967429:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7fea8d71f070 0x14dc4bf48a60 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 405 0x7fea8f6472e0 0x14dc4a9d2560 
[1:1:0712/120456.969123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a148
[1:1:0712/120456.969353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120456.969852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 427
[1:1:0712/120456.970094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7fea8d71f070 0x14dc4bebaa60 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 405 0x7fea8f6472e0 0x14dc4a9d2560 
[1:1:0712/120456.971472:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a148
[1:1:0712/120456.971678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120456.972208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 428
[1:1:0712/120456.972457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 428 0x7fea8d71f070 0x14dc4a56bb60 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 405 0x7fea8f6472e0 0x14dc4a9d2560 
[1:1:0712/120457.053631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7fea8f6472e0 0x14dc4b194860 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120457.058636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/120457.058767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120457.342166:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120457.438439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120457.438879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , i.onload, (){}
[1:1:0712/120457.438991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120457.455502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fea8f6472e0 0x14dc4b457460 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120457.461792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/120457.461942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[5232:5232:0712/120512.508502:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[5232:5232:0712/120512.512099:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[5232:5232:0712/120512.515709:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[5232:5232:0712/120512.519356:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[5232:5232:0712/120512.520133:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/120512.526460:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/120512.655352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120512.698861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fea8f6472e0 0x14dc4bf53fe0 , "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120512.709271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/120512.709562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120513.066827:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120513.110025:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120513.110337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120513.110819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 483
[1:1:0712/120513.111053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7fea8d71f070 0x14dc4c589960 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[1:1:0712/120515.105167:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120515.106374:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120526.053191:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120526.053763:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120526.054053:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120530.176566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120530.176907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120530.177369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 517
[1:1:0712/120530.177570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 517 0x7fea8d71f070 0x14dc50fecde0 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[1:1:0712/120530.178060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 150, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120530.178227:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 150
[1:1:0712/120530.178819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 518
[1:1:0712/120530.179018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7fea8d71f070 0x14dc4a19eb60 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[1:1:0712/120530.224493:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120530.224749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 0
[1:1:0712/120530.225176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 519
[1:1:0712/120530.225371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7fea8d71f070 0x14dc51a2fce0 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[1:1:0712/120531.369517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120531.369830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 30000
[1:1:0712/120531.370716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 539
[1:1:0712/120531.370981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 539 0x7fea8d71f070 0x14dc51d937e0 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[5232:5232:0712/120534.642212:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/120538.779657:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x6df7b2229c8, 0x14dc4a69a210
[1:1:0712/120538.780210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", 30000
[1:1:0712/120538.781086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 543
[1:1:0712/120538.781484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7fea8d71f070 0x14dc545de6e0 , 5:3_https://sg.godaddy.com/, 1, -5:3_https://sg.godaddy.com/, 418 0x7fea8f6472e0 0x14dc4bf53fe0 
[1:1:0712/120540.332759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120540.333543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , i.onload, (){}
[1:1:0712/120540.333805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120540.335503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 416, 7fea900648db
[1:1:0712/120540.358254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"388 0x7fea8d71f070 0x14dc4b194b60 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120540.358567:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"388 0x7fea8d71f070 0x14dc4b194b60 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120540.359017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 559
[1:1:0712/120540.359305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 559 0x7fea8d71f070 0x14dc4a5249e0 , 5:3_https://sg.godaddy.com/, 0, , 416 0x7fea8d71f070 0x14dc4bf430e0 
[1:1:0712/120540.359652:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120540.360329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () { _checkPosition(true); }
[1:1:0712/120540.360657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120540.396879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 425, 7fea900648db
[1:1:0712/120540.403870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"393 0x7fea8d71f070 0x14dc4bc2ece0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120540.404251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"393 0x7fea8d71f070 0x14dc4bc2ece0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120540.404778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://sg.godaddy.com/, 560
[1:1:0712/120540.405077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 560 0x7fea8d71f070 0x14dc4bee03e0 , 5:3_https://sg.godaddy.com/, 0, , 425 0x7fea8d71f070 0x14dc4bf469e0 
[1:1:0712/120540.405492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120540.406162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120540.406481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
		remove user.11_9fcb0fe4 -> 0
		remove user.12_c3798eeb -> 0
		remove user.13_d178df50 -> 0
		remove user.14_37bd5b9a -> 0
		remove user.15_2f10bc48 -> 0
[1:1:0712/120543.967906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 426, 7fea90064881
[1:1:0712/120544.004474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.004904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.005405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120544.006121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , of, (){var a=nf();try{var b=yc.h,c=v["_analyticsDataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var
[1:1:0712/120544.006424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120544.033543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 427, 7fea90064881
[1:1:0712/120544.056484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.056853:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.057328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120544.057993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0712/120544.058284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120544.106816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 428, 7fea90064881
[1:1:0712/120544.148317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.149087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"405 0x7fea8f6472e0 0x14dc4a9d2560 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120544.149995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120544.151419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0712/120544.152007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120544.343027:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120544.345073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , i.onload, (){}
[1:1:0712/120544.345578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120544.419763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/120544.420164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120545.163370:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120545.164310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , m, (e){e.source!==a||"string"!=typeof e.data||e.data.indexOf(i)||p(+e.data.slice(i.length))}
[1:1:0712/120545.164488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120546.823725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120546.824212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , Nn, (e,t){if(_n){var n=He(t);if(null===(n=D(n))||"number"!=typeof n.tag||2===nn(n)||(n=null),En.length){
[1:1:0712/120546.824334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120546.882966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120546.883800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , Nn, (e,t){if(_n){var n=He(t);if(null===(n=D(n))||"number"!=typeof n.tag||2===nn(n)||(n=null),En.length){
[1:1:0712/120546.884118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120546.961034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120546.961836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , Nn, (e,t){if(_n){var n=He(t);if(null===(n=D(n))||"number"!=typeof n.tag||2===nn(n)||(n=null),En.length){
[1:1:0712/120546.962048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120547.024269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 483, 7fea90064881
[1:1:0712/120547.031450:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.031605:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.031790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120547.032138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , () {
      window._gaDataLayer = window._gaDataLayer || [];
      window._gaDataLayer.push({ 'tcc.te
[1:1:0712/120547.032250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120547.045442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 517, 7fea90064881
[1:1:0712/120547.054454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.054637:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.054836:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120547.055171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){pn(N,Bt)}
[1:1:0712/120547.055284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120547.056339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 519, 7fea90064881
[1:1:0712/120547.064125:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.064294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.064488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120547.064792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){u(),e&&(c(e),l(e))}
[1:1:0712/120547.064899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
[1:1:0712/120547.246714:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://sg.godaddy.com/, 518, 7fea90064881
[1:1:0712/120547.272223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d639cae2860","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.272551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://sg.godaddy.com/","ptid":"418 0x7fea8f6472e0 0x14dc4bf53fe0 ","rf":"5:3_https://sg.godaddy.com/"}
[1:1:0712/120547.272934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://sg.godaddy.com/zh/legal/agreements/privacy-policy"
[1:1:0712/120547.273591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://sg.godaddy.com/, 3d639cae2860, , , (){a[Pt].display="block",D(),O(),P(),z(),W(),U(),pn(n,"cms-"+f+"-open"),pn(a,Bt),a[St](st,!1);if(!Xt
[1:1:0712/120547.273714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://sg.godaddy.com/zh/legal/agreements/privacy-policy", "sg.godaddy.com", 3, 1, , , 0
