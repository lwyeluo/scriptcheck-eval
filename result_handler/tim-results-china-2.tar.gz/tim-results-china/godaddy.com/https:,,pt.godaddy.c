[0712/115619.496947:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115619.497379:INFO:switcher_clone.cc(787)] backtrace rip is 7fb37e93f891
[0712/115620.495880:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115620.496188:INFO:switcher_clone.cc(787)] backtrace rip is 7fa6165e1891
[1:1:0712/115620.501778:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/115620.502025:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/115620.508664:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/115622.169135:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115622.169541:INFO:switcher_clone.cc(787)] backtrace rip is 7f832795e891
[4333:4333:0712/115622.274924:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c27576d5-bf16-4f4b-9aa9-1f30e0e91b61
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[4364:4364:0712/115622.442413:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4364
[4376:4376:0712/115622.442851:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4376
[4333:4333:0712/115622.768661:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4333:4362:0712/115622.769843:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/115622.770121:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115622.770339:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115622.770941:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115622.771092:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/115622.774352:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23efe74f, 1
[1:1:0712/115622.774878:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3cbfa36f, 0
[1:1:0712/115622.775163:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x30d9bd59, 3
[1:1:0712/115622.775440:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3f4c1e0e, 2
[1:1:0712/115622.775859:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6fffffffa3ffffffbf3c 4fffffffe7ffffffef23 0e1e4c3f 59ffffffbdffffffd930 , 10104, 4
[1:1:0712/115622.776933:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4333:4362:0712/115622.777258:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGo��<O��#L?Y��0d��
[4333:4362:0712/115622.777372:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is o��<O��#L?Y��0��d��
[1:1:0712/115622.777229:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa61481c0a0, 3
[4333:4362:0712/115622.777890:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/115622.777537:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa6149a7080, 2
[4333:4362:0712/115622.778041:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4384, 4, 6fa3bf3c 4fe7ef23 0e1e4c3f 59bdd930 
[1:1:0712/115622.778044:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa5fe66ad20, -2
[1:1:0712/115622.797165:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115622.798049:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f4c1e0e
[1:1:0712/115622.799044:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f4c1e0e
[1:1:0712/115622.800641:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f4c1e0e
[1:1:0712/115622.802116:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.802375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.802695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.803076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.804323:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f4c1e0e
[1:1:0712/115622.804953:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa6165e17ba
[1:1:0712/115622.805205:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa6165d8def, 7fa6165e177a, 7fa6165e30cf
[1:1:0712/115622.815520:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f4c1e0e
[1:1:0712/115622.816182:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f4c1e0e
[1:1:0712/115622.817479:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f4c1e0e
[1:1:0712/115622.821156:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.821565:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.821850:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.822105:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f4c1e0e
[1:1:0712/115622.823369:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f4c1e0e
[1:1:0712/115622.823906:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa6165e17ba
[1:1:0712/115622.824120:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa6165d8def, 7fa6165e177a, 7fa6165e30cf
[1:1:0712/115622.831510:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115622.832016:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115622.832224:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc1503a478, 0x7ffc1503a3f8)
[1:1:0712/115622.854455:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115622.860148:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[4333:4333:0712/115623.475778:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4333:4333:0712/115623.477194:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4333:4343:0712/115623.484906:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4333:4333:0712/115623.484987:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4333:4333:0712/115623.485032:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4333:4343:0712/115623.485010:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4333:4333:0712/115623.485098:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,4384, 4
[1:7:0712/115623.489167:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[4333:4355:0712/115623.589176:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/115623.656684:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x224be6fcc220
[1:1:0712/115623.657031:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/115623.986652:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/115625.531783:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115625.535913:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[4333:4333:0712/115625.660221:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4333:4333:0712/115625.660360:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115626.658524:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115626.768961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115626.769153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115626.774454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115626.774624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115626.897504:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115626.897673:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115627.289307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115627.297472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115627.297706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115627.348987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115627.359904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115627.360134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115627.372459:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[4333:4333:0712/115627.375591:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/115627.376174:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x224be6fcae20
[1:1:0712/115627.376388:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4333:4333:0712/115627.381411:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4333:4333:0712/115627.404081:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4333:4333:0712/115627.404285:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115627.431622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115627.895086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7fa6002452e0 0x224be71c90e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115627.895782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/115627.895919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115627.896445:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4333:4333:0712/115627.926889:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/115627.929039:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x224be6fcb820
[1:1:0712/115627.929308:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4333:4333:0712/115627.934585:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/115627.948832:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/115627.949040:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4333:4333:0712/115627.951913:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4333:4333:0712/115627.963109:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4333:4333:0712/115627.964176:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4333:4343:0712/115627.969948:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4333:4343:0712/115627.970064:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[4333:4333:0712/115627.970164:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4333:4333:0712/115627.970236:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4333:4333:0712/115627.970368:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,4384, 4
[1:7:0712/115627.974179:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115628.551282:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/115628.893900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fa6002452e0 0x224be72327e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115628.894534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/115628.895225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115628.896002:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4333:4333:0712/115629.054865:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4333:4333:0712/115629.054972:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/115629.079000:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115629.388104:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[4333:4333:0712/115629.498659:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4333:4362:0712/115629.499218:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/115629.499461:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115629.499787:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115629.500360:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115629.500558:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/115629.503476:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x71e8240, 1
[1:1:0712/115629.503889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d2b6e7e, 0
[1:1:0712/115629.504062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d314d38, 3
[1:1:0712/115629.504286:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x275ac659, 2
[1:1:0712/115629.504461:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7e6e2b2d 40ffffff821e07 59ffffffc65a27 384d312d , 10104, 5
[1:1:0712/115629.505543:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4333:4362:0712/115629.505833:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING~n+-@�Y�Z'8M1-���
[1:1:0712/115629.505813:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa61481c0a0, 3
[4333:4362:0712/115629.505940:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ~n+-@�Y�Z'8M1-\���
[1:1:0712/115629.506003:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa6149a7080, 2
[1:1:0712/115629.506235:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa5fe66ad20, -2
[4333:4362:0712/115629.506292:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4429, 5, 7e6e2b2d 40821e07 59c65a27 384d312d 
[1:1:0712/115629.528897:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115629.529251:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 275ac659
[1:1:0712/115629.529605:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 275ac659
[1:1:0712/115629.530278:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 275ac659
[1:1:0712/115629.531747:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.531943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.532135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.532389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.533085:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 275ac659
[1:1:0712/115629.533308:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa6165e17ba
[1:1:0712/115629.533406:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa6165d8def, 7fa6165e177a, 7fa6165e30cf
[1:1:0712/115629.539125:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 275ac659
[1:1:0712/115629.539649:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 275ac659
[1:1:0712/115629.540588:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 275ac659
[1:1:0712/115629.543080:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.543357:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.543599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.543835:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 275ac659
[1:1:0712/115629.545390:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 275ac659
[1:1:0712/115629.545835:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa6165e17ba
[1:1:0712/115629.545998:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa6165d8def, 7fa6165e177a, 7fa6165e30cf
[1:1:0712/115629.555492:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115629.556082:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115629.556289:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc1503a478, 0x7ffc1503a3f8)
[1:1:0712/115629.572661:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115629.577871:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/115629.622849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115629.623118:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115629.799763:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x224be6f4d220
[1:1:0712/115629.800038:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/115630.106980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115630.111593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d1990f6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/115630.111932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/115630.120531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115630.342260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115630.343054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d1990e41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/115630.343279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115630.575534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115630.577276:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/115630.577534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d1990f6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/115630.577801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/115630.717847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115630.745488:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/115630.745732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d1990f6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/115630.746011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[4333:4333:0712/115630.849942:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4333:4333:0712/115630.853171:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4333:4343:0712/115630.896386:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4333:4343:0712/115630.896484:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[4333:4333:0712/115630.896897:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pt.godaddy.com/
[4333:4333:0712/115630.896977:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://pt.godaddy.com/, https://pt.godaddy.com/, 1
[4333:4333:0712/115630.897103:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://pt.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 18:56:30 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 18:56:30 GMT set-cookie:ASP.NET_SessionId=wcjaot04uvgvn1gcoeuh0oax; path=/; HttpOnly set-cookie:market=pt-PT; expires=Sat, 11-Jul-2020 18:56:30 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,4429, 5
[1:7:0712/115630.903478:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115630.918244:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://pt.godaddy.com/
[4333:4333:0712/115631.041559:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://pt.godaddy.com/, https://pt.godaddy.com/, 1
[4333:4333:0712/115631.041700:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://pt.godaddy.com/, https://pt.godaddy.com
[1:1:0712/115631.044297:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115631.085114:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/115631.167136:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115631.268529:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115631.340906:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115631.341253:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pt.godaddy.com/"
[1:1:0712/115631.361319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7fa5fe31d070 0x224be6da4260 , "https://pt.godaddy.com/"
[1:1:0712/115631.363614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/115631.363891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115631.367149:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115631.408947:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/115631.554784:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/115631.608178:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115631.693487:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/115631.754901:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/115631.806583:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/115631.894607:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/115631.955312:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115631.968666:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/115632.131563:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115632.164844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115632.165770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d1990f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/115632.166064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/115632.673632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fa5fe31d070 0x224be7179260 , "https://pt.godaddy.com/"
[1:1:0712/115632.674727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/115632.675010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115632.678217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fa5fe31d070 0x224be7179260 , "https://pt.godaddy.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/115633.103651:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fa5fe31d070 0x224be719d7e0 , "https://pt.godaddy.com/"
[1:1:0712/115633.104842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/115633.105109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115633.107827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fa5fe31d070 0x224be719d7e0 , "https://pt.godaddy.com/"
[1:1:0712/115633.118971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fa5fe31d070 0x224be719d7e0 , "https://pt.godaddy.com/"
[1:1:0712/115633.125247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 200
[1:1:0712/115633.125708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 265
[1:1:0712/115633.125954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 265 0x7fa5fe31d070 0x224be708e360 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 252 0x7fa5fe31d070 0x224be719d7e0 
[1:1:0712/115633.128656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fa5fe31d070 0x224be719d7e0 , "https://pt.godaddy.com/"
[1:1:0712/115633.134114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fa5fe31d070 0x224be719d7e0 , "https://pt.godaddy.com/"
[1:1:0712/115633.272289:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115633.272772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115633.273157:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115633.273577:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115633.273977:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115633.305149:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.198254, 1533, 1
[1:1:0712/115633.305465:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115633.496719:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115633.497012:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pt.godaddy.com/"
[1:1:0712/115633.497797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7fa5fe31d070 0x224be6fef660 , "https://pt.godaddy.com/"
[1:1:0712/115633.498943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/115633.499202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115633.501004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7fa5fe31d070 0x224be6fef660 , "https://pt.godaddy.com/"
[1:1:0712/115633.509997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7fa5fe31d070 0x224be6fef660 , "https://pt.godaddy.com/"
[1:1:0712/115633.514654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 273 0x7fa5fe31d070 0x224be6fef660 , "https://pt.godaddy.com/"
[1:1:0712/115633.670483:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.173372, 1481, 1
[1:1:0712/115633.670788:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115633.704375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 265, 7fa600c628db
[1:1:0712/115633.712398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"252 0x7fa5fe31d070 0x224be719d7e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115633.712721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"252 0x7fa5fe31d070 0x224be719d7e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115633.713059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 313
[1:1:0712/115633.713341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 313 0x7fa5fe31d070 0x224be6c9b560 , 5:3_https://pt.godaddy.com/, 0, , 265 0x7fa5fe31d070 0x224be708e360 
[1:1:0712/115633.713678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115633.714199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115633.714431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115636.412819:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115636.413123:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pt.godaddy.com/"
[1:1:0712/115636.413951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.414793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/115636.415041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115636.417539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.421443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.425004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.430985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.433956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa5fe31d070 0x224be7174960 , "https://pt.godaddy.com/"
[1:1:0712/115636.968002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 313, 7fa600c628db
[1:1:0712/115636.975935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"265 0x7fa5fe31d070 0x224be708e360 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115636.976262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"265 0x7fa5fe31d070 0x224be708e360 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115636.976579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 370
[1:1:0712/115636.976805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7fa5fe31d070 0x224be70c62e0 , 5:3_https://pt.godaddy.com/, 0, , 313 0x7fa5fe31d070 0x224be6c9b560 
[1:1:0712/115636.977127:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115636.977626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115636.977837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115637.116986:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115637.118939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/115637.119184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115637.129165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115637.417690:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 370, 7fa600c628db
[1:1:0712/115637.435984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"313 0x7fa5fe31d070 0x224be6c9b560 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115637.436348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"313 0x7fa5fe31d070 0x224be6c9b560 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115637.436682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 395
[1:1:0712/115637.436911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7fa5fe31d070 0x224be78a6860 , 5:3_https://pt.godaddy.com/, 0, , 370 0x7fa5fe31d070 0x224be70c62e0 
[1:1:0712/115637.437251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115637.437753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115637.437963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115637.529265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115637.565765:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 395, 7fa600c628db
[1:1:0712/115637.575479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"370 0x7fa5fe31d070 0x224be70c62e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115637.575795:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"370 0x7fa5fe31d070 0x224be70c62e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115637.576210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 408
[1:1:0712/115637.576440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 408 0x7fa5fe31d070 0x224be78a6460 , 5:3_https://pt.godaddy.com/, 0, , 395 0x7fa5fe31d070 0x224be78a6860 
[1:1:0712/115637.576739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115637.577249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115637.577462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115637.651778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 402 0x7fa6002452e0 0x224be76581e0 , "https://pt.godaddy.com/"
[1:1:0712/115637.654960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/115637.655186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115637.847535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7fa6002452e0 0x224be7472ee0 , "https://pt.godaddy.com/"
[1:1:0712/115637.860395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/115637.860652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115638.140780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x10fc78fa29c8, 0x224be6dc8198
[1:1:0712/115638.141053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 500
[1:1:0712/115638.141443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 422
[1:1:0712/115638.141687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7fa5fe31d070 0x224be6b69a60 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 406 0x7fa6002452e0 0x224be7472ee0 
		remove user.10_898917f0 -> 0
[1:1:0712/115640.186392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x10fc78fa29c8, 0x224be6dc8198
[1:1:0712/115640.186707:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 0
[1:1:0712/115640.187137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 473
[1:1:0712/115640.187377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7fa5fe31d070 0x224be78a6fe0 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 406 0x7fa6002452e0 0x224be7472ee0 
[1:1:0712/115640.195967:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115640.259064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 408, 7fa600c628db
[1:1:0712/115640.270164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"395 0x7fa5fe31d070 0x224be78a6860 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115640.270470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"395 0x7fa5fe31d070 0x224be78a6860 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115640.270950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 488
[1:1:0712/115640.271227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 488 0x7fa5fe31d070 0x224be707e3e0 , 5:3_https://pt.godaddy.com/, 0, , 408 0x7fa5fe31d070 0x224be78a6460 
[1:1:0712/115640.271562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115640.272130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115640.272363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115641.618514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 422, 7fa600c62881
[1:1:0712/115641.640338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"406 0x7fa6002452e0 0x224be7472ee0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115641.640667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"406 0x7fa6002452e0 0x224be7472ee0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115641.641056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115641.641657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/115641.641869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115641.655024:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x10fc78fa29c8, 0x224be6dc8150
[1:1:0712/115641.655253:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 500
[1:1:0712/115641.655580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 501
[1:1:0712/115641.655766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7fa5fe31d070 0x224be73c2060 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 422 0x7fa5fe31d070 0x224be6b69a60 
[1:1:0712/115641.671515:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 473, 7fa600c62881
[1:1:0712/115641.697866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"406 0x7fa6002452e0 0x224be7472ee0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115641.698233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"406 0x7fa6002452e0 0x224be7472ee0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115641.698641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115641.699302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/115641.699518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.035825:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 488, 7fa600c628db
[1:1:0712/115642.057666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"408 0x7fa5fe31d070 0x224be78a6460 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.057955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"408 0x7fa5fe31d070 0x224be78a6460 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.058376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 514
[1:1:0712/115642.058609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 514 0x7fa5fe31d070 0x224be76581e0 , 5:3_https://pt.godaddy.com/, 0, , 488 0x7fa5fe31d070 0x224be707e3e0 
[1:1:0712/115642.058922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115642.059489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115642.059745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.124208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 494 0x7fa6002452e0 0x224be78419e0 , "https://pt.godaddy.com/"
[1:1:0712/115642.125096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/115642.125335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.126029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115642.318347:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115642.319041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , i.onload, (){}
[1:1:0712/115642.319277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.321078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 514, 7fa600c628db
[1:1:0712/115642.335736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"488 0x7fa5fe31d070 0x224be707e3e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.336043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"488 0x7fa5fe31d070 0x224be707e3e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.336476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 528
[1:1:0712/115642.336719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7fa5fe31d070 0x224be73ef5e0 , 5:3_https://pt.godaddy.com/, 0, , 514 0x7fa5fe31d070 0x224be76581e0 
[1:1:0712/115642.337044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115642.337558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115642.337775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.434871:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115642.435606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , i.onload, (){}
[1:1:0712/115642.435889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.437487:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 501, 7fa600c62881
[1:1:0712/115642.460121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"422 0x7fa5fe31d070 0x224be6b69a60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.460486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"422 0x7fa5fe31d070 0x224be6b69a60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.460861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115642.461365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/115642.461589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.474680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x10fc78fa29c8, 0x224be6dc8150
[1:1:0712/115642.474909:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 500
[1:1:0712/115642.475270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 532
[1:1:0712/115642.475513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7fa5fe31d070 0x224be82f0f60 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 501 0x7fa5fe31d070 0x224be73c2060 
[1:1:0712/115642.586237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115642.586950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , i.onload, (){}
[1:1:0712/115642.587170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.771753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115642.772449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , i.onload, (){}
[1:1:0712/115642.772686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.774241:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 528, 7fa600c628db
[1:1:0712/115642.797047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"514 0x7fa5fe31d070 0x224be76581e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.797339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"514 0x7fa5fe31d070 0x224be76581e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115642.797754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 542
[1:1:0712/115642.797982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7fa5fe31d070 0x224be765a060 , 5:3_https://pt.godaddy.com/, 0, , 528 0x7fa5fe31d070 0x224be73ef5e0 
[1:1:0712/115642.798293:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115642.798781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115642.799007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115642.892899:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537 0x7fa6002452e0 0x224be856f860 , "https://pt.godaddy.com/"
[1:1:0712/115642.950675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/115642.950998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115643.282776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115643.310086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fa6002452e0 0x224be78acf60 , "https://pt.godaddy.com/"
[1:1:0712/115643.334691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/115643.334941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115643.710053:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115643.710564:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4333:4333:0712/115658.422059:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4333:4333:0712/115658.423162:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4333:4333:0712/115658.424596:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4333:4333:0712/115658.425225:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4333:4333:0712/115658.425650:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/115658.428679:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/115658.569903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115658.593800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7fa6002452e0 0x224be708fe60 , "https://pt.godaddy.com/"
[1:1:0712/115658.606924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/115658.607104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115658.849949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115658.943361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115658.943726:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 0
[1:1:0712/115658.944110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 587
[1:1:0712/115658.944341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7fa5fe31d070 0x224be8654c60 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[1:1:0712/115707.431834:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115707.432423:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115707.432830:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115716.112379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115716.112684:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 100
[1:1:0712/115716.113049:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 621
[1:1:0712/115716.113308:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7fa5fe31d070 0x224be792f260 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[1:1:0712/115716.114137:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115716.114330:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 400
[1:1:0712/115716.114824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 622
[1:1:0712/115716.115104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7fa5fe31d070 0x224bed136860 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[1:1:0712/115718.381292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115718.381613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 0
[1:1:0712/115718.381997:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 673
[1:1:0712/115718.382232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7fa5fe31d070 0x224be6b515e0 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[1:1:0712/115719.410161:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115719.410375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 30000
[1:1:0712/115719.410625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 693
[1:1:0712/115719.410750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7fa5fe31d070 0x224bec640260 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[4333:4333:0712/115720.269215:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/115725.856963:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x10fc78fa29c8, 0x224be6dc8210
[1:1:0712/115725.857313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 30000
[1:1:0712/115725.857703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 697
[1:1:0712/115725.857918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7fa5fe31d070 0x224bf0d158e0 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 539 0x7fa6002452e0 0x224be708fe60 
[1:1:0712/115727.526941:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 542, 7fa600c628db
[1:1:0712/115727.556606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"528 0x7fa5fe31d070 0x224be73ef5e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115727.556932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"528 0x7fa5fe31d070 0x224be73ef5e0 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115727.557332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://pt.godaddy.com/, 722
[1:1:0712/115727.557525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7fa5fe31d070 0x224be7378b60 , 5:3_https://pt.godaddy.com/, 0, , 542 0x7fa5fe31d070 0x224be765a060 
[1:1:0712/115727.557831:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115727.558322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () { _checkPosition(true); }
[1:1:0712/115727.558499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115727.572959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 532, 7fa600c62881
[1:1:0712/115727.603036:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"501 0x7fa5fe31d070 0x224be73c2060 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115727.603389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"501 0x7fa5fe31d070 0x224be73c2060 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115727.603794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115727.604303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/115727.604481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115727.618324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x10fc78fa29c8, 0x224be6dc8150
[1:1:0712/115727.618551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pt.godaddy.com/", 500
[1:1:0712/115727.618893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 726
[1:1:0712/115727.619094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7fa5fe31d070 0x224bf10c7360 , 5:3_https://pt.godaddy.com/, 1, -5:3_https://pt.godaddy.com/, 532 0x7fa5fe31d070 0x224be82f0f60 
[1:1:0712/115727.679977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/115727.680150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115728.589083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://pt.godaddy.com/"
[1:1:0712/115728.590561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , m, (e){e.source!==a||"string"!=typeof e.data||e.data.indexOf(i)||p(+e.data.slice(i.length))}
[1:1:0712/115728.590793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115732.088894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pt.godaddy.com/"
[1:1:0712/115732.089582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , On, (e,t){if(_n){var n=He(t);if(null===(n=D(n))||"number"!=typeof n.tag||2===nn(n)||(n=null),kn.length){
[1:1:0712/115732.089765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115732.677481:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 587, 7fa600c62881
[1:1:0712/115732.688878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"539 0x7fa6002452e0 0x224be708fe60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115732.689111:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"539 0x7fa6002452e0 0x224be708fe60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0712/115732.689345:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0712/115732.689654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , () {
      window._gaDataLayer = window._gaDataLayer || [];
      window._gaDataLayer.push({ 'tcc.te
[1:1:0712/115732.689766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0712/115732.703520:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://pt.godaddy.com/, 621, 7fa600c62881
[1:1:0712/115732.730448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2219b44c2860","ptid":"539 0x7fa6002452e0 0x224be708fe60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0100/000000.730810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://pt.godaddy.com/","ptid":"539 0x7fa6002452e0 0x224be708fe60 ","rf":"5:3_https://pt.godaddy.com/"}
[1:1:0100/000000.754810:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pt.godaddy.com/"
[1:1:0100/000000.755223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://pt.godaddy.com/, 2219b44c2860, , , (){var e=document.createEvent("HTMLEvents");e.initEvent("resize",!0,!1),window.dispatchEvent(e)}
[1:1:0100/000000.755421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pt.godaddy.com/", "pt.godaddy.com", 3, 1, , , 0
[1:1:0100/000000.756813:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://pt.godaddy.com/"
