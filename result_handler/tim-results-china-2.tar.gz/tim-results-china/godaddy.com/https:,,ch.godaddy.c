[0712/114805.292292:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114805.292566:INFO:switcher_clone.cc(787)] backtrace rip is 7f050a64d891
[0712/114806.392168:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114806.392630:INFO:switcher_clone.cc(787)] backtrace rip is 7f8791e5f891
[1:1:0712/114806.405251:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/114806.405609:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/114806.411212:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/114807.672946:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114807.673222:INFO:switcher_clone.cc(787)] backtrace rip is 7f6981a7d891
[3407:3407:0712/114807.796794:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/a71c8232-afa3-427d-845d-55ba906df93b
[3441:3441:0712/114807.904125:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3441
[3453:3453:0712/114807.904552:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3453
[3407:3407:0712/114808.315568:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[3407:3439:0712/114808.316407:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/114808.316636:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114808.316903:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114808.317497:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114808.317674:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/114808.320843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x388285be, 1
[1:1:0712/114808.321242:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22cd16ad, 0
[1:1:0712/114808.321455:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x34bca9a8, 3
[1:1:0712/114808.321656:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8a1bb16, 2
[1:1:0712/114808.321916:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffad16ffffffcd22 ffffffbeffffff85ffffff8238 16ffffffbbffffffa108 ffffffa8ffffffa9ffffffbc34 , 10104, 4
[1:1:0712/114808.323172:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3407:3439:0712/114808.323450:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��"���8�����4w�
[3407:3439:0712/114808.323515:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��"���8�����4�w�
[1:1:0712/114808.323447:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f879009a0a0, 3
[3407:3439:0712/114808.323932:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[3407:3439:0712/114808.324002:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3461, 4, ad16cd22 be858238 16bba108 a8a9bc34 
[1:1:0712/114808.323965:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8790225080, 2
[1:1:0712/114808.324179:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8779ee8d20, -2
[1:1:0712/114808.347713:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114808.348818:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8a1bb16
[1:1:0712/114808.350010:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8a1bb16
[1:1:0712/114808.351988:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8a1bb16
[1:1:0712/114808.353820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.354054:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.354276:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.354516:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.355320:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8a1bb16
[1:1:0712/114808.355719:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8791e5f7ba
[1:1:0712/114808.355932:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8791e56def, 7f8791e5f77a, 7f8791e610cf
[1:1:0712/114808.362902:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8a1bb16
[1:1:0712/114808.363342:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8a1bb16
[1:1:0712/114808.364258:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8a1bb16
[1:1:0712/114808.366773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.367031:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.367256:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.367487:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8a1bb16
[1:1:0712/114808.369066:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8a1bb16
[1:1:0712/114808.369538:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8791e5f7ba
[1:1:0712/114808.369722:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8791e56def, 7f8791e5f77a, 7f8791e610cf
[1:1:0712/114808.379257:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114808.379832:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114808.380021:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffb192f818, 0x7fffb192f798)
[1:1:0712/114808.399046:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114808.405722:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3407:3407:0712/114808.990777:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3407:3407:0712/114808.992191:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3407:3420:0712/114809.012819:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[3407:3420:0712/114809.012919:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[3407:3407:0712/114809.013102:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[3407:3407:0712/114809.013180:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[3407:3407:0712/114809.013321:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,3461, 4
[1:7:0712/114809.014941:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[3407:3432:0712/114809.053189:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/114809.118064:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x17f3f3ebb220
[1:1:0712/114809.118347:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/114809.352262:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/114811.192589:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3407:3407:0712/114811.195581:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[3407:3407:0712/114811.195703:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114811.196355:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114812.217589:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114812.389084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114812.389610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114812.414559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114812.414910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114812.678709:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114812.679026:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114812.996341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114813.000799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114813.001149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114813.052049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114813.061661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114813.061943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114813.074471:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[3407:3407:0712/114813.077207:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114813.078022:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x17f3f3eb9e20
[1:1:0712/114813.078250:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[3407:3407:0712/114813.083720:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[3407:3407:0712/114813.112738:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[3407:3407:0712/114813.112829:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114813.140212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114814.216317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f877bac32e0 0x17f3f4173460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114814.219335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/114814.219782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114814.223379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3407:3407:0712/114814.292178:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114814.298502:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x17f3f3eba820
[1:1:0712/114814.298859:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[3407:3407:0712/114814.300392:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/114814.324477:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/114814.324741:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[3407:3407:0712/114814.327229:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[3407:3407:0712/114814.338848:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3407:3407:0712/114814.340074:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3407:3407:0712/114814.348179:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[3407:3407:0712/114814.348289:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[3407:3407:0712/114814.348511:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,3461, 4
[3407:3420:0712/114814.348837:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[3407:3420:0712/114814.348925:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/114814.350582:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114814.962290:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/114815.241891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f877bac32e0 0x17f3f428e960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114815.242997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/114815.243268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114815.244128:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114815.407201:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3407:3407:0712/114815.409526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[3407:3407:0712/114815.409686:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[3407:3407:0712/114815.546279:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[3407:3439:0712/114815.546738:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/114815.546968:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114815.547214:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114815.547658:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114815.547841:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/114815.550935:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1f216bb7, 1
[1:1:0712/114815.551260:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xee91c63, 0
[1:1:0712/114815.551415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2cdbdead, 3
[1:1:0712/114815.551552:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x4bc0d00, 2
[1:1:0712/114815.551759:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 631cffffffe90e ffffffb76b211f 000dffffffbc04 ffffffadffffffdeffffffdb2c , 10104, 5
[1:1:0712/114815.552749:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3407:3439:0712/114815.552978:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGc��k!
[3407:3439:0712/114815.553040:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is c��k!
[1:1:0712/114815.553150:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f879009a0a0, 3
[3407:3439:0712/114815.553310:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3505, 5, 631ce90e b76b211f 000dbc04 addedb2c 
[1:1:0712/114815.553337:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8790225080, 2
[1:1:0712/114815.553509:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8779ee8d20, -2
[1:1:0712/114815.574297:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114815.574677:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4bc0d00
[1:1:0712/114815.574988:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4bc0d00
[1:1:0712/114815.575661:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4bc0d00
[1:1:0712/114815.577020:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.577205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.577375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.577545:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.578185:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4bc0d00
[1:1:0712/114815.578459:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8791e5f7ba
[1:1:0712/114815.578589:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8791e56def, 7f8791e5f77a, 7f8791e610cf
[1:1:0712/114815.584117:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4bc0d00
[1:1:0712/114815.584458:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4bc0d00
[1:1:0712/114815.585186:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4bc0d00
[1:1:0712/114815.587215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.587421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.587597:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.587829:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4bc0d00
[1:1:0712/114815.588993:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4bc0d00
[1:1:0712/114815.589338:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8791e5f7ba
[1:1:0712/114815.589467:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8791e56def, 7f8791e5f77a, 7f8791e610cf
[1:1:0712/114815.596929:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114815.597445:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114815.597645:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffb192f818, 0x7fffb192f798)
[1:1:0712/114815.612496:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114815.616710:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/114815.773483:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x17f3f3e98220
[1:1:0712/114815.773640:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/114815.907102:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114816.419807:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114816.420110:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114816.665631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114816.670249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/114816.670585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114816.675298:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114816.775417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114816.776192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fac5b381f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/114816.776416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114817.059102:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114817.060857:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114817.061119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114817.061403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114817.173369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114817.174307:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114817.174526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114817.174801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114817.379995:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/114817.759444:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/114817.827807:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/114817.905885:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/114817.974298:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[3407:3407:0712/114818.091171:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3407:3407:0712/114818.094447:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3407:3420:0712/114818.106522:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[3407:3420:0712/114818.106614:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[3407:3407:0712/114818.106696:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://ch.godaddy.com/
[3407:3407:0712/114818.106734:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://ch.godaddy.com/, https://ch.godaddy.com/it, 1
[3407:3407:0712/114818.106784:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://ch.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 18:48:18 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 18:48:18 GMT set-cookie:ASP.NET_SessionId=5boxwnzqlq3cmboylbqaoshk; path=/; HttpOnly set-cookie:market=it-CH; expires=Sat, 11-Jul-2020 18:48:18 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,3505, 5
[1:7:0712/114818.111069:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114818.135177:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://ch.godaddy.com/
[1:1:0712/114818.150920:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/114818.228188:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[3407:3407:0712/114818.247492:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://ch.godaddy.com/, https://ch.godaddy.com/, 1
[3407:3407:0712/114818.247588:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://ch.godaddy.com/, https://ch.godaddy.com
[1:1:0712/114818.274136:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/114818.306619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114818.319847:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/114818.408055:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114818.479177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.480055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114818.480394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.520053:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114818.520309:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ch.godaddy.com/it"
[1:1:0712/114818.520523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.521401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114818.521688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.540241:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f8779b9b070 0x17f3f3bff160 , "https://ch.godaddy.com/it"
[1:1:0712/114818.542836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/114818.543072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114818.546677:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114818.554632:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.555435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114818.555717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.670795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.671765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114818.672087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.711389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.712299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114818.712579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.774588:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.775495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114818.775793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114818.782569:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114818.935306:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114818.936238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114818.936539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.033919:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.034842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114819.035109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.102080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.103017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114819.103282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.178538:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114819.205244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.206201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114819.206472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.231140:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.232075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114819.232342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.359362:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114819.547520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.548491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114819.548779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114819.611598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114819.612510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fac5b4ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114819.612805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114820.115033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 240 0x7f8779b9b070 0x17f3f40c6060 , "https://ch.godaddy.com/it"
[1:1:0712/114820.116032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/114820.116220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114820.119201:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 240 0x7f8779b9b070 0x17f3f40c6060 , "https://ch.godaddy.com/it"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/114820.853833:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f8779b9b070 0x17f3f3aa3e60 , "https://ch.godaddy.com/it"
[1:1:0712/114820.854516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/114820.854645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114820.855564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f8779b9b070 0x17f3f3aa3e60 , "https://ch.godaddy.com/it"
[1:1:0712/114820.863656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f8779b9b070 0x17f3f3aa3e60 , "https://ch.godaddy.com/it"
[1:1:0712/114820.872803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 200
[1:1:0712/114820.873269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 274
[1:1:0712/114820.873456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 274 0x7f8779b9b070 0x17f3f40c5b60 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 263 0x7f8779b9b070 0x17f3f3aa3e60 
[1:1:0712/114820.875891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f8779b9b070 0x17f3f3aa3e60 , "https://ch.godaddy.com/it"
[1:1:0712/114820.885145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f8779b9b070 0x17f3f3aa3e60 , "https://ch.godaddy.com/it"
[1:1:0712/114820.946311:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0912461, 1547, 1
[1:1:0712/114820.946494:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114821.018523:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114821.018687:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ch.godaddy.com/it"
[1:1:0712/114821.019081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f8779b9b070 0x17f3f3fbe960 , "https://ch.godaddy.com/it"
[1:1:0712/114821.019648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/114821.019757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114821.021004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f8779b9b070 0x17f3f3fbe960 , "https://ch.godaddy.com/it"
[1:1:0712/114821.023705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f8779b9b070 0x17f3f3fbe960 , "https://ch.godaddy.com/it"
[1:1:0712/114821.027938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f8779b9b070 0x17f3f3fbe960 , "https://ch.godaddy.com/it"
[1:1:0712/114821.124636:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.10606, 1494, 1
[1:1:0712/114821.124939:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114821.627443:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114821.627619:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://ch.godaddy.com/it"
[1:1:0712/114821.628035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114821.628604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/114821.628719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114821.629557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114821.631026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114821.632477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114821.634702:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114821.636127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f8779b9b070 0x17f3f40c27e0 , "https://ch.godaddy.com/it"
[1:1:0712/114824.341435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114824.343581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/114824.343905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114824.378144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114824.397063:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 274, 7f877c4e08db
[1:1:0712/114824.402318:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1acca1642860","ptid":"263 0x7f8779b9b070 0x17f3f3aa3e60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114824.402474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ch.godaddy.com/","ptid":"263 0x7f8779b9b070 0x17f3f3aa3e60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114824.402631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 371
[1:1:0712/114824.402733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 371 0x7f8779b9b070 0x17f3f478df60 , 5:3_https://ch.godaddy.com/, 0, , 274 0x7f8779b9b070 0x17f3f40c5b60 
[1:1:0712/114824.402913:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114824.403199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114824.403311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114825.187168:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114825.264208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 371, 7f877c4e08db
[1:1:0712/114825.281027:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"274 0x7f8779b9b070 0x17f3f40c5b60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114825.281275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"274 0x7f8779b9b070 0x17f3f40c5b60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114825.281627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 396
[1:1:0712/114825.281815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7f8779b9b070 0x17f3f408a5e0 , 5:3_https://ch.godaddy.com/, 0, , 371 0x7f8779b9b070 0x17f3f478df60 
[1:1:0712/114825.282117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114825.282592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114825.282769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114825.699596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 396, 7f877c4e08db
[1:1:0712/114825.717385:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"371 0x7f8779b9b070 0x17f3f478df60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114825.717626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"371 0x7f8779b9b070 0x17f3f478df60 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114825.717976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 417
[1:1:0712/114825.718165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 417 0x7f8779b9b070 0x17f3f4091260 , 5:3_https://ch.godaddy.com/, 0, , 396 0x7f8779b9b070 0x17f3f408a5e0 
[1:1:0712/114825.718444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114825.718898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114825.719073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114825.793604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7f877bac32e0 0x17f3f45b5e60 , "https://ch.godaddy.com/it"
[1:1:0712/114825.804168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/114825.804488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114825.912469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f877bac32e0 0x17f3f409a560 , "https://ch.godaddy.com/it"
[1:1:0712/114825.925458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/114825.925716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114826.168943:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x161736ec29c8, 0x17f3f3a75198
[1:1:0712/114826.169181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 500
[1:1:0712/114826.169530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 426
[1:1:0712/114826.169732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7f8779b9b070 0x17f3f4158ce0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 406 0x7f877bac32e0 0x17f3f409a560 
[1:1:0712/114826.526654:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114826.533286:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114826.533867:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114826.534443:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114826.534780:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_3c011c54 -> 0
[1:1:0712/114828.201607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x161736ec29c8, 0x17f3f3a75198
[1:1:0712/114828.201914:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 0
[1:1:0712/114828.202280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 475
[1:1:0712/114828.202508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 475 0x7f8779b9b070 0x17f3f51d3ae0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 406 0x7f877bac32e0 0x17f3f409a560 
[1:1:0712/114828.218373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114828.260717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410 0x7f877bac32e0 0x17f3f4617560 , "https://ch.godaddy.com/it"
[1:1:0712/114828.261531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/114828.261752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114828.262242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114828.391499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 417, 7f877c4e08db
[1:1:0712/114828.408242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"396 0x7f8779b9b070 0x17f3f408a5e0 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114828.408544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"396 0x7f8779b9b070 0x17f3f408a5e0 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114828.408960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 491
[1:1:0712/114828.409209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f8779b9b070 0x17f3f43c4360 , 5:3_https://ch.godaddy.com/, 0, , 417 0x7f8779b9b070 0x17f3f4091260 
[1:1:0712/114828.409545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114828.410082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114828.410297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114829.192934:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 426, 7f877c4e0881
[1:1:0712/114829.209654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1acca1642860","ptid":"406 0x7f877bac32e0 0x17f3f409a560 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.209968:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ch.godaddy.com/","ptid":"406 0x7f877bac32e0 0x17f3f409a560 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.210336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114829.210858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/114829.211094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114829.223399:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x161736ec29c8, 0x17f3f3a75150
[1:1:0712/114829.223649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 500
[1:1:0712/114829.224041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 502
[1:1:0712/114829.224309:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7f8779b9b070 0x17f3f53a6360 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 426 0x7f8779b9b070 0x17f3f4158ce0 
[1:1:0712/114829.225820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 475, 7f877c4e0881
[1:1:0712/114829.246671:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1acca1642860","ptid":"406 0x7f877bac32e0 0x17f3f409a560 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.246981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ch.godaddy.com/","ptid":"406 0x7f877bac32e0 0x17f3f409a560 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.247400:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114829.248002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/114829.248243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114829.637485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 491, 7f877c4e08db
[1:1:0712/114829.664341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"417 0x7f8779b9b070 0x17f3f4091260 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.664647:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"417 0x7f8779b9b070 0x17f3f4091260 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114829.665052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 518
[1:1:0712/114829.665298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f8779b9b070 0x17f3f477b460 , 5:3_https://ch.godaddy.com/, 0, , 491 0x7f8779b9b070 0x17f3f43c4360 
[1:1:0712/114829.665624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114829.666131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114829.666368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114830.207465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7f877bac32e0 0x17f3f53a6fe0 , "https://ch.godaddy.com/it"
[1:1:0712/114830.286818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/114830.287130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114830.745569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114830.793675:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f877bac32e0 0x17f3f47ce4e0 , "https://ch.godaddy.com/it"
[1:1:0712/114830.811775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/114830.812050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114831.263746:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3407:3407:0712/114844.616243:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3407:3407:0712/114844.617642:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3407:3407:0712/114844.618799:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3407:3407:0712/114844.619596:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3407:3407:0712/114844.620707:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3:3:0712/114844.635021:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/114844.756584:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114844.822519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114844.823286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , i.onload, (){}
[1:1:0712/114844.823514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114844.825271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 518, 7f877c4e08db
[1:1:0712/114844.849008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"491 0x7f8779b9b070 0x17f3f43c4360 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114844.849364:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"491 0x7f8779b9b070 0x17f3f43c4360 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114844.849800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 574
[1:1:0712/114844.850070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f8779b9b070 0x17f3f55a0f60 , 5:3_https://ch.godaddy.com/, 0, , 518 0x7f8779b9b070 0x17f3f477b460 
[1:1:0712/114844.850413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114844.850953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114844.851310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114845.489534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114845.490338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , i.onload, (){}
[1:1:0712/114845.490630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114845.516620:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 502, 7f877c4e0881
[1:1:0712/114845.569464:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1acca1642860","ptid":"426 0x7f8779b9b070 0x17f3f4158ce0 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114845.569982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://ch.godaddy.com/","ptid":"426 0x7f8779b9b070 0x17f3f4158ce0 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114845.570828:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114845.571556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/114845.571973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114845.593791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x161736ec29c8, 0x17f3f3a75150
[1:1:0712/114845.594122:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 500
[1:1:0712/114845.594582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 580
[1:1:0712/114845.594877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f8779b9b070 0x17f3f577f5e0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 502 0x7f8779b9b070 0x17f3f53a6360 
[1:1:0712/114845.652866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114845.653681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , i.onload, (){}
[1:1:0712/114845.653977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114845.759699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7f877bac32e0 0x17f3f501af60 , "https://ch.godaddy.com/it"
[1:1:0712/114845.784501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/114845.784978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114846.042833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114846.090557:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114846.090964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 0
[1:1:0712/114846.091452:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 587
[1:1:0712/114846.091873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7f8779b9b070 0x17f3f438d4e0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[1:1:0712/114847.156260:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114853.559051:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114853.559675:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114853.560017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114903.295146:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114903.295545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 100
[1:1:0712/114903.296224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 621
[1:1:0712/114903.296555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f8779b9b070 0x17f3f4131960 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[1:1:0712/114903.298107:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114903.298380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 400
[1:1:0712/114903.298938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 622
[1:1:0712/114903.299258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f8779b9b070 0x17f3f9d49160 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[1:1:0712/114906.279213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114906.279746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 0
[1:1:0712/114906.280369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 673
[1:1:0712/114906.280608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f8779b9b070 0x17f3f3ac51e0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[3407:3407:0712/114906.539895:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/114907.348550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114907.348820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 30000
[1:1:0712/114907.349167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 693
[1:1:0712/114907.349358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f8779b9b070 0x17f3fa0338e0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[1:1:0712/114915.406493:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x161736ec29c8, 0x17f3f3a75210
[1:1:0712/114915.406753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://ch.godaddy.com/it", 30000
[1:1:0712/114915.407089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://ch.godaddy.com/, 700
[1:1:0712/114915.407279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f8779b9b070 0x17f3fdbecde0 , 5:3_https://ch.godaddy.com/, 1, -5:3_https://ch.godaddy.com/, 530 0x7f877bac32e0 0x17f3f501af60 
[1:1:0712/114916.738901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/114916.739207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114917.676913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 574, 7f877c4e08db
[1:1:0712/114917.687728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"518 0x7f8779b9b070 0x17f3f477b460 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114917.687877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"518 0x7f8779b9b070 0x17f3f477b460 ","rf":"5:3_https://ch.godaddy.com/"}
[1:1:0712/114917.688110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://ch.godaddy.com/, 741
[1:1:0712/114917.688233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f8779b9b070 0x17f3fa046460 , 5:3_https://ch.godaddy.com/, 0, , 574 0x7f8779b9b070 0x17f3f55a0f60 
[1:1:0712/114917.688414:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://ch.godaddy.com/it"
[1:1:0712/114917.688710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , , () { _checkPosition(true); }
[1:1:0712/114917.688828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114917.724332:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://ch.godaddy.com/it"
[1:1:0712/114917.724708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , i.onload, (){}
[1:1:0712/114917.724821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
[1:1:0712/114917.758483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://ch.godaddy.com/it"
[1:1:0712/114917.759263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://ch.godaddy.com/, 1acca1642860, , m, (e){e.source!==a||"string"!=typeof e.data||e.data.indexOf(i)||p(+e.data.slice(i.length))}
[1:1:0712/114917.759424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://ch.godaddy.com/it", "ch.godaddy.com", 3, 1, , , 0
