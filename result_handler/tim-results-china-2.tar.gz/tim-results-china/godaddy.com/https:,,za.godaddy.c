[0712/115843.494169:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115843.494537:INFO:switcher_clone.cc(787)] backtrace rip is 7f927c19b891
[0712/115844.605517:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115844.605865:INFO:switcher_clone.cc(787)] backtrace rip is 7f426ee0e891
[1:1:0712/115844.617571:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/115844.617816:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/115844.626387:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/115846.028804:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115846.029153:INFO:switcher_clone.cc(787)] backtrace rip is 7ff778abc891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[4623:4623:0712/115846.219819:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4623
[4633:4633:0712/115846.220241:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4633
[4590:4590:0712/115846.302931:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6c9da7c6-52b1-4a2b-a2cf-8bb3c7267b9e
[4590:4590:0712/115846.930562:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4590:4621:0712/115846.931343:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/115846.931652:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115846.931994:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115846.932849:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115846.933081:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/115846.936853:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1701a1e1, 1
[1:1:0712/115846.937207:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1789c143, 0
[1:1:0712/115846.937378:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1df65615, 3
[1:1:0712/115846.937552:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x25721b15, 2
[1:1:0712/115846.937768:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 43ffffffc1ffffff8917 ffffffe1ffffffa10117 151b7225 1556fffffff61d , 10104, 4
[1:1:0712/115846.938748:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4590:4621:0712/115846.938953:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGC���r%V�5��
[4590:4621:0712/115846.938991:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is C���r%V��E5��
[1:1:0712/115846.939056:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f426d0490a0, 3
[1:1:0712/115846.939191:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f426d1d4080, 2
[1:1:0712/115846.939285:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4256e97d20, -2
[4590:4621:0712/115846.939447:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[4590:4621:0712/115846.939616:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4643, 4, 43c18917 e1a10117 151b7225 1556f61d 
[1:1:0712/115846.947810:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115846.948390:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25721b15
[1:1:0712/115846.949060:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25721b15
[1:1:0712/115846.950090:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25721b15
[1:1:0712/115846.950617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.950726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.950847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.950955:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.951187:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25721b15
[1:1:0712/115846.951326:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f426ee0e7ba
[1:1:0712/115846.951407:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f426ee05def, 7f426ee0e77a, 7f426ee100cf
[1:1:0712/115846.952861:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25721b15
[1:1:0712/115846.953026:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25721b15
[1:1:0712/115846.953293:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25721b15
[1:1:0712/115846.953988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.954103:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.954200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.954297:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25721b15
[1:1:0712/115846.954736:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25721b15
[1:1:0712/115846.954927:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f426ee0e7ba
[1:1:0712/115846.955009:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f426ee05def, 7f426ee0e77a, 7f426ee100cf
[1:1:0712/115846.957180:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115846.957447:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115846.957542:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe3bb00978, 0x7ffe3bb008f8)
[1:1:0712/115846.971367:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115846.977274:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[4590:4590:0712/115847.532599:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4590:4590:0712/115847.533732:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4590:4602:0712/115847.552855:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4590:4602:0712/115847.552967:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4590:4590:0712/115847.553139:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4590:4590:0712/115847.553215:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4590:4590:0712/115847.553353:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,4643, 4
[1:7:0712/115847.555353:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[4590:4614:0712/115847.614173:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/115847.633273:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x220d19371220
[1:1:0712/115847.633507:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/115847.799340:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/115849.208712:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115849.213051:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[4590:4590:0712/115849.667687:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4590:4590:0712/115849.667796:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115850.074375:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115850.358638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115850.359003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115850.375350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115850.375641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115850.470045:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115850.470537:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115850.649683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115850.657827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115850.658086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115850.697960:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115850.705487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115850.705818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115850.710930:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/115850.715684:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220d1936fe20
[1:1:0712/115850.716012:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4590:4590:0712/115850.716276:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[4590:4590:0712/115850.725577:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4590:4590:0712/115850.759123:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4590:4590:0712/115850.759277:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115850.782868:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115851.430883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f4258a722e0 0x220d19577be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115851.433754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/115851.434234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115851.437306:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115851.496237:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x220d19370820
[1:1:0712/115851.496460:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4590:4590:0712/115851.499918:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/115851.515566:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/115851.515771:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4590:4590:0712/115851.520768:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[4590:4590:0712/115851.539206:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4590:4590:0712/115851.552399:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4590:4590:0712/115851.553415:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4590:4602:0712/115851.559472:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4590:4602:0712/115851.559578:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[4590:4590:0712/115851.559698:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4590:4590:0712/115851.559773:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4590:4590:0712/115851.559903:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,4643, 4
[1:7:0712/115851.563815:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115852.090764:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/115852.691699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f4258a722e0 0x220d193e3ce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115852.692746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1a788c2c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/115852.693155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115852.693955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4590:4590:0712/115852.801887:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4590:4590:0712/115852.802025:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/115852.832681:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115853.285510:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115853.937890:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115853.938165:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4590:4590:0712/115853.940507:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4590:4621:0712/115853.941069:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/115853.941306:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115853.941550:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115853.942086:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115853.942275:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/115853.946506:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e061638, 1
[1:1:0712/115853.947079:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8f56a2f, 0
[1:1:0712/115853.947239:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x20ea9d33, 3
[1:1:0712/115853.947388:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30a5d930, 2
[1:1:0712/115853.947538:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2f6afffffff508 3816062e 30ffffffd9ffffffa530 33ffffff9dffffffea20 , 10104, 5
[1:1:0712/115853.948555:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4590:4621:0712/115853.948819:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING/j�8.0٥03�� ���
[4590:4621:0712/115853.948870:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is /j�8.0٥03�� H󇸫
[1:1:0712/115853.948958:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f426d0490a0, 3
[4590:4621:0712/115853.949122:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4688, 5, 2f6af508 3816062e 30d9a530 339dea20 
[1:1:0712/115853.949118:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f426d1d4080, 2
[1:1:0712/115853.949252:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4256e97d20, -2
[1:1:0712/115853.963505:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115853.963903:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30a5d930
[1:1:0712/115853.964225:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30a5d930
[1:1:0712/115853.964895:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30a5d930
[1:1:0712/115853.966358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.966556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.966785:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.966975:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.967687:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30a5d930
[1:1:0712/115853.967990:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f426ee0e7ba
[1:1:0712/115853.968129:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f426ee05def, 7f426ee0e77a, 7f426ee100cf
[1:1:0712/115853.971515:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30a5d930
[1:1:0712/115853.971749:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30a5d930
[1:1:0712/115853.972051:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30a5d930
[1:1:0712/115853.972779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.972902:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.973003:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.973115:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30a5d930
[1:1:0712/115853.973573:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30a5d930
[1:1:0712/115853.973766:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f426ee0e7ba
[1:1:0712/115853.973853:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f426ee05def, 7f426ee0e77a, 7f426ee100cf
[1:1:0712/115853.976163:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115853.976522:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115853.976622:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe3bb00978, 0x7ffe3bb008f8)
[1:1:0712/115853.989601:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115853.994179:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/115854.225660:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220d1933d220
[1:1:0712/115854.225888:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/115854.523957:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115854.529601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1a788c3ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/115854.530150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/115854.548435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4590:4590:0712/115855.747015:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4590:4590:0712/115855.753692:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4590:4590:0712/115855.794571:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://za.godaddy.com/
[4590:4590:0712/115855.794661:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://za.godaddy.com/, https://za.godaddy.com/, 1
[4590:4590:0712/115855.794784:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://za.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 18:58:55 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 18:58:55 GMT set-cookie:ASP.NET_SessionId=dv32phvb4ke2x3edgozh45z1; path=/; HttpOnly set-cookie:market=en-ZA; expires=Sat, 11-Jul-2020 18:58:55 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,4688, 5
[4590:4602:0712/115855.800380:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4590:4602:0712/115855.800479:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/115855.802511:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115855.848388:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://za.godaddy.com/
[4590:4590:0712/115855.966089:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://za.godaddy.com/, https://za.godaddy.com/, 1
[4590:4590:0712/115855.966173:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://za.godaddy.com/, https://za.godaddy.com
[1:1:0712/115856.020466:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115856.120850:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115856.177006:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115856.189719:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115856.189944:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://za.godaddy.com/"
[1:1:0712/115856.207434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 137 0x7f4256b4a070 0x220d19461b60 , "https://za.godaddy.com/"
[1:1:0712/115856.208701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/115856.208929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115856.210870:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/115856.478843:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115856.898426:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115857.151704:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115858.010212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231 0x7f4256b4a070 0x220d195474e0 , "https://za.godaddy.com/"
[1:1:0712/115858.011397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/115858.011634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115858.015284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231 0x7f4256b4a070 0x220d195474e0 , "https://za.godaddy.com/"
[1:1:0712/115858.309227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f4256b4a070 0x220d195723e0 , "https://za.godaddy.com/"
[1:1:0712/115858.309880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/115858.310002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115858.310889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f4256b4a070 0x220d195723e0 , "https://za.godaddy.com/"
[1:1:0712/115858.319130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f4256b4a070 0x220d195723e0 , "https://za.godaddy.com/"
[1:1:0712/115858.328123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 200
[1:1:0712/115858.328486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 266
[1:1:0712/115858.328669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7f4256b4a070 0x220d19546de0 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 250 0x7f4256b4a070 0x220d195723e0 
[1:1:0712/115858.331067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f4256b4a070 0x220d195723e0 , "https://za.godaddy.com/"
[1:1:0712/115858.341113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f4256b4a070 0x220d195723e0 , "https://za.godaddy.com/"
[1:1:0712/115858.437644:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.127278, 1581, 1
[1:1:0712/115858.437850:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115858.757258:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115858.757485:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://za.godaddy.com/"
[1:1:0712/115858.758192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f4256b4a070 0x220d19537560 , "https://za.godaddy.com/"
[1:1:0712/115858.759293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/115858.759478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115858.762800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f4256b4a070 0x220d19537560 , "https://za.godaddy.com/"
[1:1:0712/115858.771804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f4256b4a070 0x220d19537560 , "https://za.godaddy.com/"
[1:1:0712/115858.790239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f4256b4a070 0x220d19537560 , "https://za.godaddy.com/"
[1:1:0712/115859.040177:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.282675, 1655, 1
[1:1:0712/115859.040474:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115859.125892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 266, 7f425948f8db
[1:1:0712/115859.139514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2fc317b82860","ptid":"250 0x7f4256b4a070 0x220d195723e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115859.139779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://za.godaddy.com/","ptid":"250 0x7f4256b4a070 0x220d195723e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115859.140102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 318
[1:1:0712/115859.140295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 318 0x7f4256b4a070 0x220d19538560 , 5:3_https://za.godaddy.com/, 0, , 266 0x7f4256b4a070 0x220d19546de0 
[1:1:0712/115859.140578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115859.141068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115859.141246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115902.076775:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115902.077027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://za.godaddy.com/"
[1:1:0712/115902.077835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.078689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/115902.078933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115902.081521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.085545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.089128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.095146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.099929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310 0x7f4256b4a070 0x220d1956f660 , "https://za.godaddy.com/"
[1:1:0712/115902.808319:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 318, 7f425948f8db
[1:1:0712/115902.825061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"266 0x7f4256b4a070 0x220d19546de0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115902.825374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"266 0x7f4256b4a070 0x220d19546de0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115902.825713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 375
[1:1:0712/115902.825958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7f4256b4a070 0x220d19537760 , 5:3_https://za.godaddy.com/, 0, , 318 0x7f4256b4a070 0x220d19538560 
[1:1:0712/115902.826306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115902.826819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115902.827060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115902.936297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115902.938210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/115902.938437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115902.967073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115903.054605:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 375, 7f425948f8db
[1:1:0712/115903.075177:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"318 0x7f4256b4a070 0x220d19538560 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.075474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"318 0x7f4256b4a070 0x220d19538560 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.075880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 400
[1:1:0712/115903.076127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 400 0x7f4256b4a070 0x220d19c945e0 , 5:3_https://za.godaddy.com/, 0, , 375 0x7f4256b4a070 0x220d19537760 
[1:1:0712/115903.076444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115903.076965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115903.077217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115903.518389:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115903.546380:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 400, 7f425948f8db
[1:1:0712/115903.565380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"375 0x7f4256b4a070 0x220d19537760 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.567199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"375 0x7f4256b4a070 0x220d19537760 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.567647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 412
[1:1:0712/115903.568039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 412 0x7f4256b4a070 0x220d19421be0 , 5:3_https://za.godaddy.com/, 0, , 400 0x7f4256b4a070 0x220d19c945e0 
[1:1:0712/115903.568406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115903.568933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115903.569190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115903.815374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7f4258a722e0 0x220d198426e0 , "https://za.godaddy.com/"
[1:1:0712/115903.824969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/115903.825244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115903.895065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 412, 7f425948f8db
[1:1:0712/115903.914345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"400 0x7f4256b4a070 0x220d19c945e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.914691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"400 0x7f4256b4a070 0x220d19c945e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115903.915122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 427
[1:1:0712/115903.915408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7f4256b4a070 0x220d19533760 , 5:3_https://za.godaddy.com/, 0, , 412 0x7f4256b4a070 0x220d19421be0 
[1:1:0712/115903.915752:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115903.916289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115903.916522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115904.021289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f4258a722e0 0x220d195721e0 , "https://za.godaddy.com/"
[1:1:0712/115904.030772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115904.031228:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115904.031703:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115904.032104:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115904.032494:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115904.035118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/115904.035392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115904.323562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 100
[1:1:0712/115904.324003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 439
[1:1:0712/115904.324228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7f4256b4a070 0x220d19c939e0 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 420 0x7f4258a722e0 0x220d195721e0 
		remove user.10_6f1837e -> 0
[1:1:0712/115906.276134:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x119dcaca29c8, 0x220d191b5198
[1:1:0712/115906.276422:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 0
[1:1:0712/115906.276807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 490
[1:1:0712/115906.277071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7f4256b4a070 0x220d1a7a4360 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 420 0x7f4258a722e0 0x220d195721e0 
[1:1:0712/115906.294008:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115906.386423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f4258a722e0 0x220d197310e0 , "https://za.godaddy.com/"
[1:1:0712/115906.387372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/115906.387673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115906.388204:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115906.532643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 427, 7f425948f8db
[1:1:0712/115906.544033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"412 0x7f4256b4a070 0x220d19421be0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115906.544351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"412 0x7f4256b4a070 0x220d19421be0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115906.544779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 506
[1:1:0712/115906.545036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7f4256b4a070 0x220d196d4860 , 5:3_https://za.godaddy.com/, 0, , 427 0x7f4256b4a070 0x220d19533760 
[1:1:0712/115906.545398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115906.545952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115906.546206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115907.527408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 439, 7f425948f8db
[1:1:0712/115907.549888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2fc317b82860","ptid":"420 0x7f4258a722e0 0x220d195721e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115907.550294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://za.godaddy.com/","ptid":"420 0x7f4258a722e0 0x220d195721e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115907.550736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 513
[1:1:0712/115907.550969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7f4256b4a070 0x220d1a903de0 , 5:3_https://za.godaddy.com/, 0, , 439 0x7f4256b4a070 0x220d19c939e0 
[1:1:0712/115907.551325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115907.551862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/115907.552084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115907.606454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 490, 7f425948f881
[1:1:0712/115907.616043:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2fc317b82860","ptid":"420 0x7f4258a722e0 0x220d195721e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115907.616512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://za.godaddy.com/","ptid":"420 0x7f4258a722e0 0x220d195721e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115907.616910:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115907.617514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/115907.617740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115907.979891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7f4258a722e0 0x220d18d157e0 , "https://za.godaddy.com/"
[1:1:0712/115908.059120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/115908.059570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115908.670550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115908.694330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504 0x7f4258a722e0 0x220d195140e0 , "https://za.godaddy.com/"
[1:1:0712/115908.711804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/115908.712085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115908.924063:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115908.924640:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4590:4590:0712/115920.851532:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[4590:4590:0712/115920.852393:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4590:4590:0712/115920.853049:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4590:4590:0712/115920.853704:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4590:4590:0712/115920.854345:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3:3:0712/115920.861039:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/115920.975565:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115921.105150:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 506, 7f425948f8db
[1:1:0712/115921.136159:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"427 0x7f4256b4a070 0x220d19533760 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115921.136608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"427 0x7f4256b4a070 0x220d19533760 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115921.137106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 580
[1:1:0712/115921.137436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7f4256b4a070 0x220d195349e0 , 5:3_https://za.godaddy.com/, 0, , 506 0x7f4256b4a070 0x220d196d4860 
[1:1:0712/115921.137921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115921.138493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115921.138805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115921.818285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 513, 7f425948f8db
[1:1:0712/115921.842911:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"439 0x7f4256b4a070 0x220d19c939e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115921.843262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"439 0x7f4256b4a070 0x220d19c939e0 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115921.843701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 587
[1:1:0712/115921.843968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7f4256b4a070 0x220d1951dfe0 , 5:3_https://za.godaddy.com/, 0, , 513 0x7f4256b4a070 0x220d1a903de0 
[1:1:0712/115921.844309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115921.844842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/115921.845106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115921.966132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/115921.966453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.514201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115922.514635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , i.onload, (){}
[1:1:0712/115922.514750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.537043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115922.537393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , i.onload, (){}
[1:1:0712/115922.537510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.553777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7f4258a722e0 0x220d18d15a60 , "https://za.godaddy.com/"
[1:1:0712/115922.555834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/115922.555955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.568945:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x119dcaca29c8, 0x220d191b5190
[1:1:0712/115922.569068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 0
[1:1:0712/115922.569310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 600
[1:1:0712/115922.569450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f4256b4a070 0x220d1af1cde0 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 574 0x7f4258a722e0 0x220d18d15a60 
[1:1:0712/115922.569874:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x119dcaca29c8, 0x220d191b5190
[1:1:0712/115922.569978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 0
[1:1:0712/115922.570153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 601
[1:1:0712/115922.570277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7f4256b4a070 0x220d1aecaee0 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 574 0x7f4258a722e0 0x220d18d15a60 
[1:1:0712/115922.570689:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x119dcaca29c8, 0x220d191b5190
[1:1:0712/115922.570793:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 0
[1:1:0712/115922.570947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 602
[1:1:0712/115922.571056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f4256b4a070 0x220d1a9ed4e0 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 574 0x7f4258a722e0 0x220d18d15a60 
[1:1:0712/115922.601775:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115922.602350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , i.onload, (){}
[1:1:0712/115922.602541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.604078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 580, 7f425948f8db
[1:1:0712/115922.617251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"506 0x7f4256b4a070 0x220d196d4860 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115922.617452:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"506 0x7f4256b4a070 0x220d196d4860 ","rf":"5:3_https://za.godaddy.com/"}
[1:1:0712/115922.617671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://za.godaddy.com/, 606
[1:1:0712/115922.617784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f4256b4a070 0x220d197e3460 , 5:3_https://za.godaddy.com/, 0, , 580 0x7f4256b4a070 0x220d195349e0 
[1:1:0712/115922.617948:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://za.godaddy.com/"
[1:1:0712/115922.618268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , () { _checkPosition(true); }
[1:1:0712/115922.618381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115922.704344:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 585 0x7f4258a722e0 0x220d194bda60 , "https://za.godaddy.com/"
[1:1:0712/115922.736684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://za.godaddy.com/, 2fc317b82860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/115922.736947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://za.godaddy.com/", "za.godaddy.com", 3, 1, , , 0
[1:1:0712/115923.108924:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://za.godaddy.com/"
[1:1:0712/115923.142561:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x119dcaca29c8, 0x220d191b5210
[1:1:0712/115923.142744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://za.godaddy.com/", 0
[1:1:0712/115923.142928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://za.godaddy.com/, 609
[1:1:0712/115923.143037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f4256b4a070 0x220d197e2360 , 5:3_https://za.godaddy.com/, 1, -5:3_https://za.godaddy.com/, 585 0x7f4258a722e0 0x220d194bda60 
[1:1:0712/115928.301427:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115928.301959:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115928.302336:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
