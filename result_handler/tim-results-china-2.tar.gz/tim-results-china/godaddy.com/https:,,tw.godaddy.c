[0712/120203.705124:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120203.705571:INFO:switcher_clone.cc(787)] backtrace rip is 7f8281a74891
[0712/120204.652979:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120204.653378:INFO:switcher_clone.cc(787)] backtrace rip is 7fd9968d8891
[1:1:0712/120204.665268:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/120204.665527:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/120204.670825:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[4972:4972:0712/120205.662233:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4b69ce95-79ba-4441-98a0-210c41905f2c
[0712/120206.053231:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/120206.053662:INFO:switcher_clone.cc(787)] backtrace rip is 7fd6e9ed8891
[4972:4972:0712/120206.132026:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4972:5003:0712/120206.132792:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/120206.133028:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120206.133290:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120206.134028:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120206.134220:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/120206.137098:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5e2ad85, 1
[1:1:0712/120206.137453:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2fdac536, 0
[1:1:0712/120206.137623:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xd6bd266, 3
[1:1:0712/120206.137786:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10f3eccb, 2
[1:1:0712/120206.137981:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 36ffffffc5ffffffda2f ffffff85ffffffadffffffe205 ffffffcbffffffecfffffff310 66ffffffd26b0d , 10104, 4
[1:1:0712/120206.138997:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4972:5003:0712/120206.139237:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING6��/������f�k�%3
[4972:5003:0712/120206.139340:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 6��/������f�k�g�%3
[1:1:0712/120206.139226:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd994b130a0, 3
[1:1:0712/120206.139539:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd994c9e080, 2
[4972:5003:0712/120206.139690:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[4972:5003:0712/120206.139763:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5018, 4, 36c5da2f 85ade205 cbecf310 66d26b0d 
[1:1:0712/120206.139764:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd97e961d20, -2
[1:1:0712/120206.154333:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120206.155033:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10f3eccb
[1:1:0712/120206.155727:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10f3eccb
[1:1:0712/120206.156801:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10f3eccb
[1:1:0712/120206.157378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.157534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.157643:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.157737:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.157964:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10f3eccb
[1:1:0712/120206.158110:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd9968d87ba
[1:1:0712/120206.158198:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd9968cfdef, 7fd9968d877a, 7fd9968da0cf
[1:1:0712/120206.161578:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10f3eccb
[1:1:0712/120206.161824:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10f3eccb
[1:1:0712/120206.162108:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10f3eccb
[1:1:0712/120206.162834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.162959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.163060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.163155:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10f3eccb
[1:1:0712/120206.163684:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10f3eccb
[1:1:0712/120206.163847:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd9968d87ba
[1:1:0712/120206.163926:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd9968cfdef, 7fd9968d877a, 7fd9968da0cf
[1:1:0712/120206.166140:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120206.166504:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120206.166601:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffd0d78008, 0x7fffd0d77f88)
[1:1:0712/120206.181636:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120206.187620:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5005:5005:0712/120206.299969:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5005
[5032:5032:0712/120206.300572:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5032
[4972:4972:0712/120206.683726:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4972:4972:0712/120206.684146:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4972:4984:0712/120206.704322:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4972:4972:0712/120206.704361:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4972:4984:0712/120206.704435:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4972:4972:0712/120206.704456:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4972:4972:0712/120206.704651:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5018, 4
[1:7:0712/120206.710735:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120206.776597:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe546daad220
[1:1:0712/120206.776925:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[4972:4997:0712/120206.784116:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/120207.035369:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/120208.435649:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120208.439410:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[4972:4972:0712/120208.898963:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4972:4972:0712/120208.899028:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/120209.437160:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120209.646713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120209.647059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120209.667186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/120209.667554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120209.793175:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120209.793484:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120210.323740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120210.332021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120210.332424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120210.359975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120210.368222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/120210.368543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120210.380691:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[4972:4972:0712/120210.383216:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/120210.384249:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe546daabe20
[1:1:0712/120210.384460:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4972:4972:0712/120210.387265:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4972:4972:0712/120210.421261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4972:4972:0712/120210.421359:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/120210.487094:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120211.157832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fd98053c2e0 0xe546dd654e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120211.159184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/120211.159425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120211.160993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4972:4972:0712/120211.230772:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/120211.232468:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe546daac820
[1:1:0712/120211.232749:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4972:4972:0712/120211.243862:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/120211.251461:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/120211.251769:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4972:4972:0712/120211.262300:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4972:4972:0712/120211.267207:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4972:4972:0712/120211.267546:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4972:4984:0712/120211.269172:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4972:4984:0712/120211.269215:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[4972:4972:0712/120211.270995:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4972:4972:0712/120211.271033:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4972:4972:0712/120211.271093:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5018, 4
[1:7:0712/120211.271984:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120211.713858:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/120212.381385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7fd98053c2e0 0xe546dec05e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120212.382523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/120212.383089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120212.383885:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4972:4972:0712/120212.505163:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4972:4972:0712/120212.505236:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/120212.537489:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120212.901619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120213.226593:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120213.226865:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120213.615461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120213.619985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/120213.620391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120213.627888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4972:4972:0712/120213.709139:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4972:5003:0712/120213.709665:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/120213.709865:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/120213.710128:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/120213.710560:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/120213.710749:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/120213.713916:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x4eeb6ab, 1
[1:1:0712/120213.714293:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1d366d11, 0
[1:1:0712/120213.714509:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2dc42d56, 3
[1:1:0712/120213.714695:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15b4c5a3, 2
[1:1:0712/120213.714873:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 116d361d ffffffabffffffb6ffffffee04 ffffffa3ffffffc5ffffffb415 562dffffffc42d , 10104, 5
[1:1:0712/120213.715887:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4972:5003:0712/120213.716182:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGm6����ŴV-�-/)3
[4972:5003:0712/120213.716258:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is m6����ŴV-�-ع/)3
[1:1:0712/120213.716158:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd994b130a0, 3
[4972:5003:0712/120213.716532:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5070, 5, 116d361d abb6ee04 a3c5b415 562dc42d 
[1:1:0712/120213.716426:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd994c9e080, 2
[1:1:0712/120213.716665:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd97e961d20, -2
[1:1:0712/120213.738042:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/120213.738514:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15b4c5a3
[1:1:0712/120213.738914:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15b4c5a3
[1:1:0712/120213.739658:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15b4c5a3
[1:1:0712/120213.741170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.741571:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.741832:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.742085:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.742799:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15b4c5a3
[1:1:0712/120213.743144:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd9968d87ba
[1:1:0712/120213.743325:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd9968cfdef, 7fd9968d877a, 7fd9968da0cf
[1:1:0712/120213.750269:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15b4c5a3
[1:1:0712/120213.750744:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15b4c5a3
[1:1:0712/120213.751489:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15b4c5a3
[1:1:0712/120213.753480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.753730:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.753967:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.754200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15b4c5a3
[1:1:0712/120213.755699:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15b4c5a3
[1:1:0712/120213.756141:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd9968d87ba
[1:1:0712/120213.756313:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd9968cfdef, 7fd9968d877a, 7fd9968da0cf
[1:1:0712/120213.764013:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/120213.764648:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/120213.764834:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffd0d78008, 0x7fffd0d77f88)
[1:1:0712/120213.778746:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/120213.781096:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/120213.881421:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/120213.882185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197785ae1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/120213.882441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/120213.938216:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe546da8e220
[1:1:0712/120213.938528:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/120214.164937:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120214.166701:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/120214.166960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/120214.167235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120214.282908:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120214.283875:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/120214.284126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/120214.284394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120214.526269:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/120215.099967:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/120215.195148:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/120215.244755:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/120215.314587:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/120215.384162:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/120215.479778:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/120215.548732:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/120215.676690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120215.677633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120215.677937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120215.720069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120215.721012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120215.721296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120215.785669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120215.786611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120215.786940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[4972:4972:0712/120215.805594:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4972:4972:0712/120215.812377:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4972:4984:0712/120215.856131:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4972:4984:0712/120215.856230:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[4972:4972:0712/120215.856756:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://tw.godaddy.com/
[4972:4972:0712/120215.856854:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tw.godaddy.com/, https://tw.godaddy.com/, 1
[4972:4972:0712/120215.857035:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://tw.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 19:02:15 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 19:02:15 GMT set-cookie:ASP.NET_SessionId=zjuqcsfif5vldnz5tqvjdslx; path=/; HttpOnly set-cookie:market=zh-TW; expires=Sat, 11-Jul-2020 19:02:15 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,5070, 5
[1:7:0712/120215.861099:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/120215.903291:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://tw.godaddy.com/
[1:1:0712/120215.975824:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120215.976548:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[4972:4972:0712/120216.047726:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tw.godaddy.com/, https://tw.godaddy.com/, 1
[4972:4972:0712/120216.047796:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://tw.godaddy.com/, https://tw.godaddy.com
[1:1:0712/120216.053710:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120216.099046:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120216.111535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.112475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.112749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.154846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120216.155146:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tw.godaddy.com/"
[1:1:0712/120216.164918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 135 0x7fd97e614070 0xe546db86560 , "https://tw.godaddy.com/"
[1:1:0712/120216.167550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/120216.167808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120216.170683:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120216.207020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.207902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.208240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.272849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.273832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.274144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.310884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.311841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.312155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.341872:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.342764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.343084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.350990:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120216.442603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.443596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.443936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.543940:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.544924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.545212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.594503:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.595544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.595866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.627956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.628896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.629196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.697630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.698592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.698868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.766858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.767813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.768160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.832810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.833745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/120216.834020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.881435:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120216.949486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/120216.950449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 197785c0e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/120216.950734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/120216.960074:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/120217.618172:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 224 0x7fd97e614070 0xe546ddb1760 , "https://tw.godaddy.com/"
[1:1:0712/120217.619456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/120217.619764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120217.623396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 224 0x7fd97e614070 0xe546ddb1760 , "https://tw.godaddy.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/120218.502786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7fd97e614070 0xe546dde5fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.504129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/120218.504396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120218.507078:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7fd97e614070 0xe546dde5fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.515970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7fd97e614070 0xe546dde5fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.526190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 200
[1:1:0712/120218.526695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 263
[1:1:0712/120218.526928:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 263 0x7fd97e614070 0xe546dbab560 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 248 0x7fd97e614070 0xe546dde5fe0 
[1:1:0712/120218.529635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7fd97e614070 0xe546dde5fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.537145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7fd97e614070 0xe546dde5fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.724968:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.21884, 1609, 1
[1:1:0712/120218.725283:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120218.835411:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120218.835775:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tw.godaddy.com/"
[1:1:0712/120218.836528:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fd97e614070 0xe546dda6fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.837672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/120218.837897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120218.841642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fd97e614070 0xe546dda6fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.850139:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fd97e614070 0xe546dda6fe0 , "https://tw.godaddy.com/"
[1:1:0712/120218.868157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fd97e614070 0xe546dda6fe0 , "https://tw.godaddy.com/"
[1:1:0712/120219.045744:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.209907, 1526, 1
[1:1:0712/120219.046055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/120219.094703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 263, 7fd980f598db
[1:1:0712/120219.108553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"248 0x7fd97e614070 0xe546dde5fe0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120219.108931:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"248 0x7fd97e614070 0xe546dde5fe0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120219.109280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 317
[1:1:0712/120219.109510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 317 0x7fd97e614070 0xe546ddb0c60 , 5:3_https://tw.godaddy.com/, 0, , 263 0x7fd97e614070 0xe546dbab560 
[1:1:0712/120219.109856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120219.110392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120219.110606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120223.571363:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/120223.571683:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tw.godaddy.com/"
[1:1:0712/120223.572555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.573439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/120223.573660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120223.576183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.580146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.583692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.590512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.594868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7fd97e614070 0xe546dde54e0 , "https://tw.godaddy.com/"
[1:1:0712/120223.978667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 317, 7fd980f598db
[1:1:0712/120223.997054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"263 0x7fd97e614070 0xe546dbab560 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120223.997417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"263 0x7fd97e614070 0xe546dbab560 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120223.997801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 366
[1:1:0712/120223.998077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 366 0x7fd97e614070 0xe546db2af60 , 5:3_https://tw.godaddy.com/, 0, , 317 0x7fd97e614070 0xe546ddb0c60 
[1:1:0712/120223.998436:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120223.998978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120223.999237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120224.164368:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.164850:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.165286:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.165708:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.166129:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.242380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120224.244518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/120224.244752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120224.270253:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120224.295507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 366, 7fd980f598db
[1:1:0712/120224.303667:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"317 0x7fd97e614070 0xe546ddb0c60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.303992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"317 0x7fd97e614070 0xe546ddb0c60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.304421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 386
[1:1:0712/120224.304669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 386 0x7fd97e614070 0xe546e5f7b60 , 5:3_https://tw.godaddy.com/, 0, , 366 0x7fd97e614070 0xe546db2af60 
[1:1:0712/120224.305002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120224.305579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120224.305812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120224.679288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 386, 7fd980f598db
[1:1:0712/120224.700451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"366 0x7fd97e614070 0xe546db2af60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.700812:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"366 0x7fd97e614070 0xe546db2af60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.701184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 397
[1:1:0712/120224.701417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 397 0x7fd97e614070 0xe546dbb06e0 , 5:3_https://tw.godaddy.com/, 0, , 386 0x7fd97e614070 0xe546e5f7b60 
[1:1:0712/120224.701740:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120224.702269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120224.702482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120224.738141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120224.887288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 397, 7fd980f598db
[1:1:0712/120224.898644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"386 0x7fd97e614070 0xe546e5f7b60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.898949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"386 0x7fd97e614070 0xe546e5f7b60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120224.899307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 410
[1:1:0712/120224.899533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7fd97e614070 0xe546dd7fde0 , 5:3_https://tw.godaddy.com/, 0, , 397 0x7fd97e614070 0xe546dbb06e0 
[1:1:0712/120224.899893:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120224.900441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120224.900662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120224.968040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7fd98053c2e0 0xe546e00b8e0 , "https://tw.godaddy.com/"
[1:1:0712/120224.978038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/120224.978372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120225.110484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7fd98053c2e0 0xe546dbafae0 , "https://tw.godaddy.com/"
[1:1:0712/120225.125045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/120225.125426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120225.440127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 100
[1:1:0712/120225.440669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 422
[1:1:0712/120225.440939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7fd97e614070 0xe546e073060 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 406 0x7fd98053c2e0 0xe546dbafae0 
		remove user.10_ed48d41d -> 0
		remove user.11_b817d5b5 -> 0
		remove user.12_dd274ad -> 0
		remove user.13_803ba75c -> 0
		remove user.14_e6c8ec77 -> 0
[1:1:0712/120227.526827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e198
[1:1:0712/120227.527149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120227.527523:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 473
[1:1:0712/120227.527778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7fd97e614070 0xe546f21f9e0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 406 0x7fd98053c2e0 0xe546dbafae0 
[1:1:0712/120227.549869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120227.627031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7fd98053c2e0 0xe546dbb06e0 , "https://tw.godaddy.com/"
[1:1:0712/120227.627906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/120227.628186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120227.628674:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120227.651527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 410, 7fd980f598db
[1:1:0712/120227.671628:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"397 0x7fd97e614070 0xe546dbb06e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120227.671943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"397 0x7fd97e614070 0xe546dbb06e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120227.672305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 488
[1:1:0712/120227.672534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 488 0x7fd97e614070 0xe546dda90e0 , 5:3_https://tw.godaddy.com/, 0, , 410 0x7fd97e614070 0xe546dd7fde0 
[1:1:0712/120227.672856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120227.673439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120227.673664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120228.833883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 422, 7fd980f598db
[1:1:0712/120228.855034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"406 0x7fd98053c2e0 0xe546dbafae0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120228.855425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"406 0x7fd98053c2e0 0xe546dbafae0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120228.855844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 496
[1:1:0712/120228.856083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 496 0x7fd97e614070 0xe546e4d9d60 , 5:3_https://tw.godaddy.com/, 0, , 422 0x7fd97e614070 0xe546e073060 
[1:1:0712/120228.856441:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120228.856983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120228.857199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120228.881439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 473, 7fd980f59881
[1:1:0712/120228.902653:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"406 0x7fd98053c2e0 0xe546dbafae0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120228.902998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"406 0x7fd98053c2e0 0xe546dbafae0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120228.903332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120228.903892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/120228.904144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120229.269259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 488, 7fd980f598db
[1:1:0712/120229.275648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"410 0x7fd97e614070 0xe546dd7fde0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120229.275792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"410 0x7fd97e614070 0xe546dd7fde0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120229.275949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 513
[1:1:0712/120229.276057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7fd97e614070 0xe546f3910e0 , 5:3_https://tw.godaddy.com/, 0, , 488 0x7fd97e614070 0xe546dda90e0 
[1:1:0712/120229.276198:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120229.276485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120229.276597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120229.524787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 496, 7fd980f598db
[1:1:0712/120229.531255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"422 0x7fd97e614070 0xe546e073060 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120229.531397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"422 0x7fd97e614070 0xe546e073060 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120229.531586:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 527
[1:1:0712/120229.531693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 527 0x7fd97e614070 0xe546f391a60 , 5:3_https://tw.godaddy.com/, 0, , 496 0x7fd97e614070 0xe546e4d9d60 
[1:1:0712/120229.531843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120229.532127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120229.532243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120229.583127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7fd98053c2e0 0xe546e316a60 , "https://tw.godaddy.com/"
[1:1:0712/120229.591446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0712/120229.591690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120229.650740:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e190
[1:1:0712/120229.650988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120229.651326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 529
[1:1:0712/120229.651541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7fd97e614070 0xe546dd7f1e0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 509 0x7fd98053c2e0 0xe546e316a60 
[1:1:0712/120229.652411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e190
[1:1:0712/120229.652636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120229.652938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 530
[1:1:0712/120229.653130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7fd97e614070 0xe546f391c60 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 509 0x7fd98053c2e0 0xe546e316a60 
[1:1:0712/120229.654002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e190
[1:1:0712/120229.654163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120229.654489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 531
[1:1:0712/120229.654684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7fd97e614070 0xe546e57a4e0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 509 0x7fd98053c2e0 0xe546e316a60 
[1:1:0712/120229.685070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7fd98053c2e0 0xe546e3f5be0 , "https://tw.godaddy.com/"
[1:1:0712/120229.709149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/120229.709484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120230.020322:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120230.093848:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120230.094494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , i.onload, (){}
[1:1:0712/120230.094692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120230.142229:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120230.142837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , i.onload, (){}
[1:1:0712/120230.143018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120230.202716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 513, 7fd980f598db
[1:1:0712/120230.225904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"488 0x7fd97e614070 0xe546dda90e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120230.226198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"488 0x7fd97e614070 0xe546dda90e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120230.226514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 546
[1:1:0712/120230.226720:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7fd97e614070 0xe546e57fbe0 , 5:3_https://tw.godaddy.com/, 0, , 513 0x7fd97e614070 0xe546f3910e0 
[1:1:0712/120230.227010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120230.227484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120230.227736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120231.144412:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120231.145079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , i.onload, (){}
[1:1:0712/120231.145264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120231.237458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fd98053c2e0 0xe546e3154e0 , "https://tw.godaddy.com/"
[1:1:0712/120231.262119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/120231.262362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120231.457032:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120231.457629:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4972:4972:0712/120242.371184:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[4972:4972:0712/120242.417628:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4972:4972:0712/120242.421476:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4972:4972:0712/120242.425258:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4972:4972:0712/120242.428869:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[1:1:0712/120242.551195:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120242.620455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 524 0x7fd98053c2e0 0xe546e314ee0 , "https://tw.godaddy.com/"
[1:1:0712/120242.646739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/120242.647050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120242.883678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120242.941680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120242.941997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120242.943142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 581
[1:1:0712/120242.943388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 581 0x7fd97e614070 0xe546dd871e0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[3:3:0712/120243.305390:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/120250.480150:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120250.480930:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120250.494958:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/120300.891009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120300.891315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 100
[1:1:0712/120300.891707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 619
[1:1:0712/120300.891968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7fd97e614070 0xe5473bdbce0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[1:1:0712/120300.892841:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120300.893091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 400
[1:1:0712/120300.893487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 620
[1:1:0712/120300.893728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7fd97e614070 0xe5474290d60 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[4972:4972:0712/120304.355793:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/120307.723546:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120307.723910:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 0
[1:1:0712/120307.724275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 685
[1:1:0712/120307.724475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7fd97e614070 0xe5476781360 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[1:1:0712/120308.739841:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120308.740159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 30000
[1:1:0712/120308.741169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 706
[1:1:0712/120308.741367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7fd97e614070 0xe5476e18e60 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[1:1:0712/120314.697481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x3b98fb9429c8, 0xe546d90e210
[1:1:0712/120314.697722:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tw.godaddy.com/", 30000
[1:1:0712/120314.698080:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 713
[1:1:0712/120314.698281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7fd97e614070 0xe54793e90e0 , 5:3_https://tw.godaddy.com/, 1, -5:3_https://tw.godaddy.com/, 524 0x7fd98053c2e0 0xe546e314ee0 
[1:1:0712/120316.119747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 527, 7fd980f598db
[1:1:0712/120316.150429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"496 0x7fd97e614070 0xe546e4d9d60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120316.150718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"496 0x7fd97e614070 0xe546e4d9d60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120316.151129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 740
[1:1:0712/120316.151327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7fd97e614070 0xe546f552560 , 5:3_https://tw.godaddy.com/, 0, , 527 0x7fd97e614070 0xe546f391a60 
[1:1:0712/120316.151659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120316.152167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , S, (){if(0<T.length&&(0<k||!C(T[0])))try{var e=T.shift();L.apply(null,e),C(e)&&(k-=1),0===k&&setTimeout
[1:1:0712/120316.152346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
		remove user.13_46a46475 -> 0
		remove user.14_a5cf2bbd -> 0
		remove user.15_e127ffcd -> 0
[1:1:0712/120317.446968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 529, 7fd980f59881
[1:1:0712/120317.465487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.465856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.466205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120317.466700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , of, (){var a=nf();try{var b=yc.h,c=v["_analyticsDataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var
[1:1:0712/120317.466992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120317.478280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 530, 7fd980f59881
[1:1:0712/120317.488551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.488782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.489005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120317.489309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0712/120317.489420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120317.505571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tw.godaddy.com/, 531, 7fd980f59881
[1:1:0712/120317.516229:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"23b735e82860","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.516439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tw.godaddy.com/","ptid":"509 0x7fd98053c2e0 0xe546e316a60 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.516646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120317.516957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0712/120317.517082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120317.615212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tw.godaddy.com/"
[1:1:0712/120317.615954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , i.onload, (){}
[1:1:0712/120317.616143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
[1:1:0712/120317.617682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 546, 7fd980f598db
[1:1:0712/120317.648218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"513 0x7fd97e614070 0xe546f3910e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.648535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"513 0x7fd97e614070 0xe546f3910e0 ","rf":"5:3_https://tw.godaddy.com/"}
[1:1:0712/120317.648960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tw.godaddy.com/, 756
[1:1:0712/120317.649161:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7fd97e614070 0xe5479f7ee60 , 5:3_https://tw.godaddy.com/, 0, , 546 0x7fd97e614070 0xe546e57fbe0 
[1:1:0712/120317.649448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tw.godaddy.com/"
[1:1:0712/120317.649950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tw.godaddy.com/, 23b735e82860, , , () { _checkPosition(true); }
[1:1:0712/120317.650137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tw.godaddy.com/", "tw.godaddy.com", 3, 1, , , 0
