[0712/115417.651527:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115417.651912:INFO:switcher_clone.cc(787)] backtrace rip is 7f4116ee6891
[0712/115418.692394:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115418.692770:INFO:switcher_clone.cc(787)] backtrace rip is 7faf8db38891
[1:1:0712/115418.704505:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/115418.704763:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/115418.712643:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[4072:4072:0712/115420.176385:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/96f4e968-a6e6-46f6-9533-b3f3ba0a5187
[0712/115420.321600:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/115420.321907:INFO:switcher_clone.cc(787)] backtrace rip is 7f92183b7891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[4104:4104:0712/115420.551355:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4104
[4115:4115:0712/115420.551758:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4115
[4072:4072:0712/115420.777218:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4072:4100:0712/115420.778084:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/115420.778321:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115420.778548:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115420.779165:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115420.779330:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/115420.782281:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ecb037a, 1
[1:1:0712/115420.782611:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x188866db, 0
[1:1:0712/115420.782775:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x30774852, 3
[1:1:0712/115420.782936:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x10544405, 2
[1:1:0712/115420.783172:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdb66ffffff8818 7a03ffffffcb1e 05445410 52487730 , 10104, 4
[1:1:0712/115420.784177:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4072:4100:0712/115420.784399:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�f�z�DTRHw0��;%
[4072:4100:0712/115420.784503:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �f�z�DTRHw0����;%
[1:1:0712/115420.784394:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf8bd730a0, 3
[1:1:0712/115420.784605:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf8befe080, 2
[4072:4100:0712/115420.784800:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/115420.784760:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf75bc1d20, -2
[4072:4100:0712/115420.784869:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4123, 4, db668818 7a03cb1e 05445410 52487730 
[1:1:0712/115420.803730:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115420.804639:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10544405
[1:1:0712/115420.805617:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10544405
[1:1:0712/115420.807238:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10544405
[1:1:0712/115420.808749:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.808937:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.809149:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.809346:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.810019:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10544405
[1:1:0712/115420.810346:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8db387ba
[1:1:0712/115420.810484:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf8db2fdef, 7faf8db3877a, 7faf8db3a0cf
[1:1:0712/115420.816437:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 10544405
[1:1:0712/115420.816879:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 10544405
[1:1:0712/115420.817811:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 10544405
[1:1:0712/115420.820407:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.820658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.820891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.821140:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 10544405
[1:1:0712/115420.822725:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 10544405
[1:1:0712/115420.823197:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8db387ba
[1:1:0712/115420.823373:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf8db2fdef, 7faf8db3877a, 7faf8db3a0cf
[1:1:0712/115420.833151:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115420.833680:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115420.833867:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcac06cbe8, 0x7ffcac06cb68)
[1:1:0712/115420.852295:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115420.858026:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[4072:4072:0712/115421.411356:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4072:4072:0712/115421.412355:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4072:4072:0712/115421.422824:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4072:4082:0712/115421.422829:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4072:4072:0712/115421.422877:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4072:4082:0712/115421.422942:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4072:4072:0712/115421.423018:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,4123, 4
[1:7:0712/115421.431071:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[4072:4093:0712/115421.523513:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/115421.547759:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x32d9972c0220
[1:1:0712/115421.548007:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/115421.751812:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/115423.016812:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115423.020453:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[4072:4072:0712/115423.561988:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4072:4072:0712/115423.562049:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115423.771883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115423.910097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115423.910417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115423.931475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/115423.931734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115424.001521:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115424.001699:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115424.389202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115424.398491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115424.398779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115424.437400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115424.448398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/115424.448618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115424.458764:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/115424.462084:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x32d9972bee20
[1:1:0712/115424.462281:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4072:4072:0712/115424.463326:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[4072:4072:0712/115424.470296:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4072:4072:0712/115424.493350:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4072:4072:0712/115424.493449:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/115424.533485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115425.249820:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7faf7779c2e0 0x32d9973f15e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115425.251238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/115425.251448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115425.252940:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4072:4072:0712/115425.325335:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/115425.327521:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x32d9972bf820
[1:1:0712/115425.327902:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4072:4072:0712/115425.337720:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/115425.351563:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/115425.352229:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4072:4072:0712/115425.362847:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4072:4072:0712/115425.375143:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4072:4072:0712/115425.376397:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4072:4082:0712/115425.382316:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4072:4082:0712/115425.382399:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[4072:4072:0712/115425.382551:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4072:4072:0712/115425.382626:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4072:4072:0712/115425.382759:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,4123, 4
[1:7:0712/115425.387517:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115425.989497:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/115426.636849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7faf7779c2e0 0x32d9976724e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/115426.637976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 366763501f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/115426.638338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/115426.639162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4072:4072:0712/115426.739254:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4072:4072:0712/115426.739387:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/115426.772171:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115427.149267:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115427.756163:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115427.756504:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4072:4072:0712/115427.885173:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4072:4100:0712/115427.885722:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/115427.886087:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/115427.886512:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/115427.887360:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/115427.887625:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/115427.893444:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x20267ab2, 1
[1:1:0712/115427.894255:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x23d4eb35, 0
[1:1:0712/115427.894600:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a4c3ec8, 3
[1:1:0712/115427.894967:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3689a44, 2
[1:1:0712/115427.895293:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 35ffffffebffffffd423 ffffffb27a2620 44ffffff9a6803 ffffffc83e4c3a , 10104, 5
[1:1:0712/115427.896839:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4072:4100:0712/115427.897197:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING5��#�z& D�h�>L:B�;%
[1:1:0712/115427.897167:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf8bd730a0, 3
[4072:4100:0712/115427.897348:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 5��#�z& D�h�>L:��B�;%
[1:1:0712/115427.897415:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf8befe080, 2
[1:1:0712/115427.897645:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf75bc1d20, -2
[4072:4100:0712/115427.897958:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4172, 5, 35ebd423 b27a2620 449a6803 c83e4c3a 
[1:1:0712/115427.921588:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/115427.921960:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3689a44
[1:1:0712/115427.922279:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3689a44
[1:1:0712/115427.922908:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3689a44
[1:1:0712/115427.924307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.924497:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.924674:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.924858:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.925532:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3689a44
[1:1:0712/115427.925820:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8db387ba
[1:1:0712/115427.925984:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf8db2fdef, 7faf8db3877a, 7faf8db3a0cf
[1:1:0712/115427.931634:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3689a44
[1:1:0712/115427.932016:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3689a44
[1:1:0712/115427.932742:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3689a44
[1:1:0712/115427.935276:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.935547:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.935781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.936074:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3689a44
[1:1:0712/115427.937642:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3689a44
[1:1:0712/115427.938121:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8db387ba
[1:1:0712/115427.938298:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf8db2fdef, 7faf8db3877a, 7faf8db3a0cf
[1:1:0712/115427.948656:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/115427.949283:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/115427.949472:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcac06cbe8, 0x7ffcac06cb68)
[1:1:0712/115427.966201:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/115427.971391:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/115428.271992:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x32d997283220
[1:1:0712/115428.272241:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/115428.289510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/115428.294346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36676362e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/115428.294678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/115428.300261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4072:4072:0712/115429.593966:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4072:4072:0712/115429.599728:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4072:4082:0712/115429.617472:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4072:4082:0712/115429.617573:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[4072:4072:0712/115429.618151:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://it.godaddy.com/
[4072:4072:0712/115429.618253:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://it.godaddy.com/, https://it.godaddy.com/, 1
[4072:4072:0712/115429.618425:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://it.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 18:54:29 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 18:54:29 GMT set-cookie:ASP.NET_SessionId=fxj02tahw2esv0u5juy3lzdl; path=/; HttpOnly set-cookie:market=it-IT; expires=Sat, 11-Jul-2020 18:54:29 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,4172, 5
[1:7:0712/115429.625634:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/115429.638160:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://it.godaddy.com/
[4072:4072:0712/115429.744128:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://it.godaddy.com/, https://it.godaddy.com/, 1
[4072:4072:0712/115429.744228:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://it.godaddy.com/, https://it.godaddy.com
[1:1:0712/115429.752868:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115429.873955:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115429.987828:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115430.067041:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115430.067328:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://it.godaddy.com/"
[1:1:0712/115430.090102:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7faf75874070 0x32d996e93ee0 , "https://it.godaddy.com/"
[1:1:0712/115430.092809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/115430.093064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115430.096047:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115430.357688:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/115430.870659:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115431.114301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/115431.659338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7faf75874070 0x32d9974a1b60 , "https://it.godaddy.com/"
[1:1:0712/115431.660381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/115431.660615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115431.663546:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7faf75874070 0x32d9974a1b60 , "https://it.godaddy.com/"
[1:1:0712/115432.205058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7faf75874070 0x32d996e8ce60 , "https://it.godaddy.com/"
[1:1:0712/115432.206310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/115432.206544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115432.209238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7faf75874070 0x32d996e8ce60 , "https://it.godaddy.com/"
[1:1:0712/115432.219624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7faf75874070 0x32d996e8ce60 , "https://it.godaddy.com/"
[1:1:0712/115432.230714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 200
[1:1:0712/115432.231204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 266
[1:1:0712/115432.231442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7faf75874070 0x32d99749c7e0 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 251 0x7faf75874070 0x32d996e8ce60 
[1:1:0712/115432.234100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7faf75874070 0x32d996e8ce60 , "https://it.godaddy.com/"
[1:1:0712/115432.245753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251 0x7faf75874070 0x32d996e8ce60 , "https://it.godaddy.com/"
[1:1:0712/115432.394317:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.186032, 1539, 1
[1:1:0712/115432.394642:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115432.743855:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115432.744150:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://it.godaddy.com/"
[1:1:0712/115432.744854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7faf75874070 0x32d9973ee3e0 , "https://it.godaddy.com/"
[1:1:0712/115432.745974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/115432.746208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115432.749537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7faf75874070 0x32d9973ee3e0 , "https://it.godaddy.com/"
[1:1:0712/115432.758416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7faf75874070 0x32d9973ee3e0 , "https://it.godaddy.com/"
[1:1:0712/115432.776403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7faf75874070 0x32d9973ee3e0 , "https://it.godaddy.com/"
[1:1:0712/115432.928005:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.183862, 1521, 1
[1:1:0712/115432.928353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/115432.962038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 266, 7faf781b98db
[1:1:0712/115432.976299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b1d06842860","ptid":"251 0x7faf75874070 0x32d996e8ce60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115432.976644:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://it.godaddy.com/","ptid":"251 0x7faf75874070 0x32d996e8ce60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115432.976996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 329
[1:1:0712/115432.977258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 329 0x7faf75874070 0x32d9973de260 , 5:3_https://it.godaddy.com/, 0, , 266 0x7faf75874070 0x32d99749c7e0 
[1:1:0712/115432.977589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115432.978113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115432.978342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115435.897718:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/115435.898027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://it.godaddy.com/"
[1:1:0712/115435.898797:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115435.899623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/115435.899922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115435.902288:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115435.906025:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115435.909571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115435.915564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115435.919873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7faf75874070 0x32d99746efe0 , "https://it.godaddy.com/"
[1:1:0712/115436.557887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 329, 7faf781b98db
[1:1:0712/115436.575550:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"266 0x7faf75874070 0x32d99749c7e0 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115436.575969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"266 0x7faf75874070 0x32d99749c7e0 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115436.576403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 388
[1:1:0712/115436.576696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7faf75874070 0x32d997562f60 , 5:3_https://it.godaddy.com/, 0, , 329 0x7faf75874070 0x32d9973de260 
[1:1:0712/115436.577058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115436.577602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115436.577822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115436.782314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115436.784240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/115436.784474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115436.809494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115436.888991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 388, 7faf781b98db
[1:1:0712/115436.911367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"329 0x7faf75874070 0x32d9973de260 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115436.911763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"329 0x7faf75874070 0x32d9973de260 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115436.912215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 413
[1:1:0712/115436.912466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 413 0x7faf75874070 0x32d99746c360 , 5:3_https://it.godaddy.com/, 0, , 388 0x7faf75874070 0x32d997562f60 
[1:1:0712/115436.912840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115436.913448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115436.913723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115437.338552:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115437.372443:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 413, 7faf781b98db
[1:1:0712/115437.380703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"388 0x7faf75874070 0x32d997562f60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115437.380991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"388 0x7faf75874070 0x32d997562f60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115437.381421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 425
[1:1:0712/115437.381645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 425 0x7faf75874070 0x32d99749f360 , 5:3_https://it.godaddy.com/, 0, , 413 0x7faf75874070 0x32d99746c360 
[1:1:0712/115437.382057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115437.382583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115437.382792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115437.681101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7faf7779c2e0 0x32d9979ecc60 , "https://it.godaddy.com/"
[1:1:0712/115437.692611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/115437.692936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115437.747383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 425, 7faf781b98db
[1:1:0712/115437.759458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"413 0x7faf75874070 0x32d99746c360 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115437.759777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"413 0x7faf75874070 0x32d99746c360 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115437.760194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 439
[1:1:0712/115437.760445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7faf75874070 0x32d9973df760 , 5:3_https://it.godaddy.com/, 0, , 425 0x7faf75874070 0x32d99749f360 
[1:1:0712/115437.760758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115437.761270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115437.761497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115437.822423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7faf7779c2e0 0x32d9979ece60 , "https://it.godaddy.com/"
[1:1:0712/115437.837243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/115437.837577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115437.988277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xf11abfe29c8, 0x32d9970e6998
[1:1:0712/115437.988605:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 500
[1:1:0712/115437.989011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 450
[1:1:0712/115437.989262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7faf75874070 0x32d9973f2d60 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 433 0x7faf7779c2e0 0x32d9979ece60 
[1:1:0712/115438.069534:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115438.070029:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115438.070384:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115438.073603:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115438.074001:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_64daef57 -> 0
[1:1:0712/115440.014354:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11abfe29c8, 0x32d9970e6998
[1:1:0712/115440.014648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 0
[1:1:0712/115440.015041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 499
[1:1:0712/115440.015275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7faf75874070 0x32d9985fab60 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 433 0x7faf7779c2e0 0x32d9979ece60 
[1:1:0712/115440.032151:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115440.085003:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 435 0x7faf7779c2e0 0x32d996e8a160 , "https://it.godaddy.com/"
[1:1:0712/115440.085862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/115440.086105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115440.086603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115441.301296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 439, 7faf781b98db
[1:1:0712/115441.323097:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"425 0x7faf75874070 0x32d99749f360 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.323401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"425 0x7faf75874070 0x32d99749f360 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.323834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 519
[1:1:0712/115441.324084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7faf75874070 0x32d9973b77e0 , 5:3_https://it.godaddy.com/, 0, , 439 0x7faf75874070 0x32d9973df760 
[1:1:0712/115441.324458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115441.325000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115441.325250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115441.339682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 450, 7faf781b9881
[1:1:0712/115441.361827:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b1d06842860","ptid":"433 0x7faf7779c2e0 0x32d9979ece60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.362150:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://it.godaddy.com/","ptid":"433 0x7faf7779c2e0 0x32d9979ece60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.362556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115441.363064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/115441.363314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115441.382223:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xf11abfe29c8, 0x32d9970e6950
[1:1:0712/115441.382554:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 500
[1:1:0712/115441.383003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 523
[1:1:0712/115441.383346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7faf75874070 0x32d9987af5e0 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 450 0x7faf75874070 0x32d9973f2d60 
[1:1:0712/115441.407334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 499, 7faf781b9881
[1:1:0712/115441.429664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b1d06842860","ptid":"433 0x7faf7779c2e0 0x32d9979ece60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.430057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://it.godaddy.com/","ptid":"433 0x7faf7779c2e0 0x32d9979ece60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115441.430524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115441.431154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/115441.431510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115442.000101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7faf7779c2e0 0x32d9979ed360 , "https://it.godaddy.com/"
[1:1:0712/115442.087856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/115442.088168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115442.377305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115442.484196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7faf7779c2e0 0x32d9975f26e0 , "https://it.godaddy.com/"
[1:1:0712/115442.509088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/115442.509419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115442.771767:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/115442.772298:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4072:4072:0712/115456.891883:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[4072:4072:0712/115456.896251:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4072:4072:0712/115456.896900:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4072:4072:0712/115456.898285:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[4072:4072:0712/115456.899815:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3:3:0712/115456.909402:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/115456.998419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115457.249365:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 519, 7faf781b98db
[1:1:0712/115457.269711:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"439 0x7faf75874070 0x32d9973df760 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115457.270022:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"439 0x7faf75874070 0x32d9973df760 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115457.270447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://it.godaddy.com/, 589
[1:1:0712/115457.270708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7faf75874070 0x32d997695ae0 , 5:3_https://it.godaddy.com/, 0, , 519 0x7faf75874070 0x32d9973b77e0 
[1:1:0712/115457.271043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115457.271564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , () { _checkPosition(true); }
[1:1:0712/115457.271850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115458.270334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 523, 7faf781b9881
[1:1:0712/115458.295412:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b1d06842860","ptid":"450 0x7faf75874070 0x32d9973f2d60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115458.295778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://it.godaddy.com/","ptid":"450 0x7faf75874070 0x32d9973f2d60 ","rf":"5:3_https://it.godaddy.com/"}
[1:1:0712/115458.296201:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://it.godaddy.com/"
[1:1:0712/115458.296744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/115458.296980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115458.310708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0xf11abfe29c8, 0x32d9970e6950
[1:1:0712/115458.310976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 500
[1:1:0712/115458.311348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 597
[1:1:0712/115458.311585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7faf75874070 0x32d998abdce0 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 523 0x7faf75874070 0x32d9987af5e0 
[1:1:0712/115458.430977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/115458.431243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115459.772840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7faf7779c2e0 0x32d9989796e0 , "https://it.godaddy.com/"
[1:1:0712/115459.815544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://it.godaddy.com/, 2b1d06842860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/115459.815900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://it.godaddy.com/", "it.godaddy.com", 3, 1, , , 0
[1:1:0712/115500.262271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://it.godaddy.com/"
[1:1:0712/115500.340296:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11abfe29c8, 0x32d9970e6a10
[1:1:0712/115500.340634:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://it.godaddy.com/", 0
[1:1:0712/115500.341036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://it.godaddy.com/, 619
[1:1:0712/115500.341297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7faf75874070 0x32d998eb87e0 , 5:3_https://it.godaddy.com/, 1, -5:3_https://it.godaddy.com/, 579 0x7faf7779c2e0 0x32d9989796e0 
