[0712/114606.735852:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114606.736182:INFO:switcher_clone.cc(787)] backtrace rip is 7ff36a8b0891
[0712/114607.521363:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114607.521787:INFO:switcher_clone.cc(787)] backtrace rip is 7f8422c5d891
[1:1:0712/114607.533701:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/114607.534022:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/114607.539476:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[3150:3150:0712/114608.828448:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/fdb0568d-b9e9-4c47-b4d9-221f7f3eb42e
[0712/114608.971991:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114608.972517:INFO:switcher_clone.cc(787)] backtrace rip is 7f5e501b8891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3182:3182:0712/114609.199940:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3182
[3194:3194:0712/114609.200349:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3194
[3150:3150:0712/114609.445004:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[3150:3180:0712/114609.445698:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/114609.445905:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114609.446174:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114609.446798:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114609.446956:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/114609.449704:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x10a61c9e, 1
[1:1:0712/114609.450023:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1de10fd7, 0
[1:1:0712/114609.450178:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2526fc1d, 3
[1:1:0712/114609.450381:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2acf7fc3, 2
[1:1:0712/114609.450568:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd70fffffffe11d ffffff9e1cffffffa610 ffffffc37fffffffcf2a 1dfffffffc2625 , 10104, 4
[1:1:0712/114609.451489:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3150:3180:0712/114609.451734:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING������*�&%�c�
[3150:3180:0712/114609.451819:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ������*�&%h�c�
[1:1:0712/114609.451730:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8420e980a0, 3
[1:1:0712/114609.451931:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8421023080, 2
[3150:3180:0712/114609.452127:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/114609.452084:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f840ace6d20, -2
[3150:3180:0712/114609.452244:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3202, 4, d70fe11d 9e1ca610 c37fcf2a 1dfc2625 
[1:1:0712/114609.465951:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114609.466782:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2acf7fc3
[1:1:0712/114609.467704:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2acf7fc3
[1:1:0712/114609.469263:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2acf7fc3
[1:1:0712/114609.470666:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.470862:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.471041:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.471240:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.471858:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2acf7fc3
[1:1:0712/114609.472146:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8422c5d7ba
[1:1:0712/114609.472343:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8422c54def, 7f8422c5d77a, 7f8422c5f0cf
[1:1:0712/114609.477728:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2acf7fc3
[1:1:0712/114609.478060:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2acf7fc3
[1:1:0712/114609.478755:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2acf7fc3
[1:1:0712/114609.480433:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.480550:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.480644:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.480732:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2acf7fc3
[1:1:0712/114609.481153:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2acf7fc3
[1:1:0712/114609.481325:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8422c5d7ba
[1:1:0712/114609.481410:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8422c54def, 7f8422c5d77a, 7f8422c5f0cf
[1:1:0712/114609.483523:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114609.483804:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114609.483899:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdd6d5f198, 0x7ffdd6d5f118)
[1:1:0712/114609.498764:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114609.504617:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3150:3150:0712/114610.086238:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3150:3150:0712/114610.086693:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3150:3161:0712/114610.094584:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[3150:3161:0712/114610.094694:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[3150:3150:0712/114610.094912:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[3150:3150:0712/114610.095005:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[3150:3150:0712/114610.095178:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,3202, 4
[1:7:0712/114610.098361:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[3150:3174:0712/114610.158796:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/114610.238104:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x36fef0d24220
[1:1:0712/114610.238392:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/114610.655827:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[3150:3150:0712/114612.229419:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[3150:3150:0712/114612.229540:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114612.280089:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114612.284212:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114613.290896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114613.291242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114613.308334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114613.308638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114613.335556:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114613.728481:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114613.728779:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114614.000208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114614.008324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114614.008610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114614.042866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114614.053189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114614.053488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114614.065094:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[3150:3150:0712/114614.066247:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114614.068430:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36fef0d22e20
[1:1:0712/114614.068644:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[3150:3150:0712/114614.077427:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[3150:3150:0712/114614.105316:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[3150:3150:0712/114614.105437:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114614.161965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114614.928056:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f840c8c12e0 0x36fef0f8fee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114614.929389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/114614.929649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114614.931141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3150:3150:0712/114614.998701:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114615.000994:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x36fef0d23820
[1:1:0712/114615.001210:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[3150:3150:0712/114615.008193:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/114615.022089:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/114615.022277:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[3150:3150:0712/114615.025735:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[3150:3150:0712/114615.038733:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3150:3150:0712/114615.040028:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[3150:3161:0712/114615.047562:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[3150:3161:0712/114615.047711:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[3150:3150:0712/114615.047947:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[3150:3150:0712/114615.048040:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[3150:3150:0712/114615.048211:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,3202, 4
[1:7:0712/114615.051841:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114615.574241:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/114616.135587:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f840c8c12e0 0x36fef10a59e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114616.136640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/114616.136886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114616.137755:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3150:3150:0712/114616.281723:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[3150:3150:0712/114616.281864:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/114616.306754:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114616.780246:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[3150:3150:0712/114616.987721:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[3150:3180:0712/114616.988225:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/114616.988443:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114616.988690:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114616.989106:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114616.989319:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/114616.992492:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x44c507f, 1
[1:1:0712/114616.992845:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25db4294, 0
[1:1:0712/114616.992997:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x70b2819, 3
[1:1:0712/114616.993171:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x18ed9ef7, 2
[1:1:0712/114616.993322:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9442ffffffdb25 7f504c04 fffffff7ffffff9effffffed18 19280b07 , 10104, 5
[1:1:0712/114616.994274:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[3150:3180:0712/114616.994497:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�B�%PL���(�f�
[3150:3180:0712/114616.994563:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �B�%PL���(x�f�
[1:1:0712/114616.994678:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8420e980a0, 3
[3150:3180:0712/114616.994826:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3246, 5, 9442db25 7f504c04 f79eed18 19280b07 
[1:1:0712/114616.994874:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8421023080, 2
[1:1:0712/114616.995056:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f840ace6d20, -2
[1:1:0712/114617.013613:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114617.013844:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18ed9ef7
[1:1:0712/114617.014020:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18ed9ef7
[1:1:0712/114617.014301:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18ed9ef7
[1:1:0712/114617.014744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.014849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.014940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.015026:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.015286:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18ed9ef7
[1:1:0712/114617.015435:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8422c5d7ba
[1:1:0712/114617.015511:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8422c54def, 7f8422c5d77a, 7f8422c5f0cf
[1:1:0712/114617.016966:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18ed9ef7
[1:1:0712/114617.017158:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18ed9ef7
[1:1:0712/114617.017438:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18ed9ef7
[1:1:0712/114617.018104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.018239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.018340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.018437:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18ed9ef7
[1:1:0712/114617.018876:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18ed9ef7
[1:1:0712/114617.019034:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8422c5d7ba
[1:1:0712/114617.019115:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8422c54def, 7f8422c5d77a, 7f8422c5f0cf
[1:1:0712/114617.021323:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114617.021664:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114617.021757:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdd6d5f198, 0x7ffdd6d5f118)
[1:1:0712/114617.034589:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114617.039032:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/114617.185101:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114617.185395:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114617.282475:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36fef0ccb220
[1:1:0712/114617.282727:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/114617.590718:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114617.595292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/114617.595862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114617.604479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114617.778103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114617.778859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1d1543ba1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/114617.779094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114617.959341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114617.961102:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114617.961350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114617.961702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114618.069443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114618.070355:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114618.070569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114618.070994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114618.326501:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[3150:3150:0712/114618.388217:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[3150:3150:0712/114618.395490:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/114618.405485:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[3150:3161:0712/114618.421567:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[3150:3161:0712/114618.421708:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[3150:3150:0712/114618.421847:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://be.godaddy.com/
[3150:3150:0712/114618.421907:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://be.godaddy.com/, https://be.godaddy.com/, 1
[3150:3150:0712/114618.421994:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://be.godaddy.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 content-encoding:gzip vary:Accept-Encoding server:Microsoft-IIS/10.0 p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR OUR IND" p3p:policyref="/w3c/p3p.xml", CP="COM CNT DEM FIN GOV INT NAV ONL PHY PRE PUR STA UNI IDC CAO OTI DSP COR CUR i OUR IND" x-powered-by:ARR/3.0 x-powered-by:ASP.NET expires:Fri, 12 Jul 2019 18:46:18 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 18:46:18 GMT content-length:70061 set-cookie:market=nl-BE; expires=Sat, 11-Jul-2020 18:46:18 GMT; path=/; domain=.godaddy.com x-frame-options:DENY x-arc:6  ,3246, 5
[1:7:0712/114618.430101:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114618.490566:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://be.godaddy.com/
[1:1:0712/114618.602695:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[3150:3150:0712/114618.644176:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://be.godaddy.com/, https://be.godaddy.com/, 1
[3150:3150:0712/114618.644274:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://be.godaddy.com/, https://be.godaddy.com
[1:1:0712/114618.687032:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114618.687850:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114618.694593:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/114618.820551:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114618.925814:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114618.933460:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/114618.972050:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114618.972307:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://be.godaddy.com/"
[1:1:0712/114618.987691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 137 0x7f840a999070 0x36fef0cdb060 , "https://be.godaddy.com/"
[1:1:0712/114618.989092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , 
var version = navigator && navigator.userAgent && navigator.userAgent.match(/MSIE (\d+)./);
if(vers
[1:1:0712/114618.989323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114618.990673:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114619.056740:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/114619.138641:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/114619.158720:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114619.233940:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/114619.518911:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.519934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114619.520226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.572211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.573178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114619.573457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.612824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.613699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114619.613988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.672278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.673233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114619.673508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.775014:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114619.821996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.822932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114619.823225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.894276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114619.895225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1d1543cce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114619.895497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114619.939926:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114620.545184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f840a999070 0x36fef0efa7e0 , "https://be.godaddy.com/"
[1:1:0712/114620.546236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , 
  window.cms = window.cms || {};
  window.cms.geo = window.cms.geo || {};

  window.cms.geo.country
[1:1:0712/114620.546464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114620.549600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7f840a999070 0x36fef0efa7e0 , "https://be.godaddy.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/114620.869809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f840a999070 0x36fef08d4160 , "https://be.godaddy.com/"
[1:1:0712/114620.871035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , 
  (function(){
    var cookies;

    function readCookie(name) {
      if (cookies) {
        retur
[1:1:0712/114620.871280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114620.872749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f840a999070 0x36fef08d4160 , "https://be.godaddy.com/"
[1:1:0712/114620.883010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f840a999070 0x36fef08d4160 , "https://be.godaddy.com/"
[1:1:0712/114620.892641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 200
[1:1:0712/114620.893096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 272
[1:1:0712/114620.893379:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 272 0x7f840a999070 0x36fef0d9f560 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 263 0x7f840a999070 0x36fef08d4160 
[1:1:0712/114620.895973:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f840a999070 0x36fef08d4160 , "https://be.godaddy.com/"
[1:1:0712/114620.905659:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7f840a999070 0x36fef08d4160 , "https://be.godaddy.com/"
[1:1:0712/114620.952218:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.080066, 1533, 1
[1:1:0712/114620.952499:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114621.193262:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114621.193535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://be.godaddy.com/"
[1:1:0712/114621.194297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f840a999070 0x36fef0eea5e0 , "https://be.godaddy.com/"
[1:1:0712/114621.195439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , 
window.ux = window.ux || {};
window.ux.eldorado = window.ux.eldorado || {};

(function trfqConfig()
[1:1:0712/114621.195661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114621.199009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f840a999070 0x36fef0eea5e0 , "https://be.godaddy.com/"
[1:1:0712/114621.207937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f840a999070 0x36fef0eea5e0 , "https://be.godaddy.com/"
[1:1:0712/114621.219158:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f840a999070 0x36fef0eea5e0 , "https://be.godaddy.com/"
[1:1:0712/114621.394504:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.200927, 1480, 1
[1:1:0712/114621.394808:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114621.458212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 272, 7f840d2de8db
[1:1:0712/114621.471990:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37f083c42860","ptid":"263 0x7f840a999070 0x36fef08d4160 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114621.472345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://be.godaddy.com/","ptid":"263 0x7f840a999070 0x36fef08d4160 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114621.472674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 321
[1:1:0712/114621.472899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 321 0x7f840a999070 0x36fef0ec10e0 , 5:3_https://be.godaddy.com/, 0, , 272 0x7f840a999070 0x36fef0d9f560 
[1:1:0712/114621.473217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114621.473735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114621.473943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114624.491846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114624.492134:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://be.godaddy.com/"
[1:1:0712/114624.492928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.493831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , 
  window.cms = window.cms || {};
  window.cms.moduleView = "default";

[1:1:0712/114624.494150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114624.496628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.498370:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.501410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.507115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.511127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f840a999070 0x36fef0ef6a60 , "https://be.godaddy.com/"
[1:1:0712/114624.730129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 321, 7f840d2de8db
[1:1:0712/114624.737155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"272 0x7f840a999070 0x36fef0d9f560 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114624.737427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"272 0x7f840a999070 0x36fef0d9f560 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114624.737738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 377
[1:1:0712/114624.737962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7f840a999070 0x36fef0ec2de0 , 5:3_https://be.godaddy.com/, 0, , 321 0x7f840a999070 0x36fef0ec10e0 
[1:1:0712/114624.738270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114624.738752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114624.738962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114624.864729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114624.866667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , loadDeferredScripts, () {
  var el, els = [], numScriptsRequested = 5;
  function createScript(src) {
    var el = docume
[1:1:0712/114624.866898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114624.890896:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114625.352449:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114625.364252:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 377, 7f840d2de8db
[1:1:0712/114625.385628:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"321 0x7f840a999070 0x36fef0ec10e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114625.385923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"321 0x7f840a999070 0x36fef0ec10e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114625.386343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 410
[1:1:0712/114625.386572:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7f840a999070 0x36fef15eaa60 , 5:3_https://be.godaddy.com/, 0, , 377 0x7f840a999070 0x36fef0ec2de0 
[1:1:0712/114625.386909:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114625.387445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114625.387685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114625.646006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7f840c8c12e0 0x36fef1201660 , "https://be.godaddy.com/"
[1:1:0712/114625.650976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , (function(){var e=function(){function Xt(){var n=t[Nt](),r=e[et]||n[Rt]-Math.abs(n[qt]);return r<480
[1:1:0712/114625.651218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114625.810516:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 410, 7f840d2de8db
[1:1:0712/114625.829048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"377 0x7f840a999070 0x36fef0ec2de0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114625.829339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"377 0x7f840a999070 0x36fef0ec2de0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114625.829764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 429
[1:1:0712/114625.829990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 429 0x7f840a999070 0x36fef15ea060 , 5:3_https://be.godaddy.com/, 0, , 410 0x7f840a999070 0x36fef15eaa60 
[1:1:0712/114625.830284:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114625.830794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114625.831005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114625.852388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f840c8c12e0 0x36fef0ec29e0 , "https://be.godaddy.com/"
[1:1:0712/114625.886441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , !function e(t,n){"object"==typeof exports&&"object"==typeof module?module.exports=n():"function"==ty
[1:1:0712/114625.886740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114626.095103:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2328de3429c8, 0x36fef0b53198
[1:1:0712/114626.095382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 500
[1:1:0712/114626.095756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 436
[1:1:0712/114626.095987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f840a999070 0x36fef112d0e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 421 0x7f840c8c12e0 0x36fef0ec29e0 
		remove user.10_9a6c6f1e -> 0
[1:1:0712/114627.928543:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114627.928871:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114627.929098:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114627.929360:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114627.929742:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114628.034625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2328de3429c8, 0x36fef0b53198
[1:1:0712/114628.034930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 0
[1:1:0712/114628.035309:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 485
[1:1:0712/114628.035587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7f840a999070 0x36fef205fd60 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 421 0x7f840c8c12e0 0x36fef0ec29e0 
[1:1:0712/114628.066640:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114628.089537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f840c8c12e0 0x36fef0ef6de0 , "https://be.godaddy.com/"
[1:1:0712/114628.090415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , /* Disable minification (remove `.min` from URL path) for more info */


[1:1:0712/114628.090646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114628.091164:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114629.411019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 429, 7f840d2de8db
[1:1:0712/114629.432723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"410 0x7f840a999070 0x36fef15eaa60 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.433013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"410 0x7f840a999070 0x36fef15eaa60 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.433430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 506
[1:1:0712/114629.433661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7f840a999070 0x36fef0de5e60 , 5:3_https://be.godaddy.com/, 0, , 429 0x7f840a999070 0x36fef15ea060 
[1:1:0712/114629.433990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114629.434523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114629.434741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114629.448936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 436, 7f840d2de881
[1:1:0712/114629.470586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37f083c42860","ptid":"421 0x7f840c8c12e0 0x36fef0ec29e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.470892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://be.godaddy.com/","ptid":"421 0x7f840c8c12e0 0x36fef0ec29e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.471247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114629.471751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/114629.471989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114629.484251:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2328de3429c8, 0x36fef0b53150
[1:1:0712/114629.484540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 500
[1:1:0712/114629.484899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 510
[1:1:0712/114629.485126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 510 0x7f840a999070 0x36fef15f53e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 436 0x7f840a999070 0x36fef112d0e0 
[1:1:0712/114629.505406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 485, 7f840d2de881
[1:1:0712/114629.517463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37f083c42860","ptid":"421 0x7f840c8c12e0 0x36fef0ec29e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.517757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://be.godaddy.com/","ptid":"421 0x7f840c8c12e0 0x36fef0ec29e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.518113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114629.518674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , (){i.getWindow()._expDataLayer&&i.getWindow()._expDataLayer.push({schema:"add_perf",version:"v1",dat
[1:1:0712/114629.518890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114629.887152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 506, 7f840d2de8db
[1:1:0712/114629.909679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"429 0x7f840a999070 0x36fef15ea060 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.909966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"429 0x7f840a999070 0x36fef15ea060 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114629.910363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 536
[1:1:0712/114629.910606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f840a999070 0x36fef13479e0 , 5:3_https://be.godaddy.com/, 0, , 506 0x7f840a999070 0x36fef0de5e60 
[1:1:0712/114629.910890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114629.911425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114629.911660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114630.145047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 524 0x7f840c8c12e0 0x36fef15af6e0 , "https://be.godaddy.com/"
[1:1:0712/114630.204905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , !function(n){var r={};function o(e){if(r[e])return r[e].exports;var t=r[e]={i:e,l:!1,exports:{}};ret
[1:1:0712/114630.205204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114630.826233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114630.852066:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7f840c8c12e0 0x36fef0faa960 , "https://be.godaddy.com/"
[1:1:0712/114630.944751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , !function(e,t){if("object"==typeof exports&&"object"==typeof module)module.exports=t(require("react"
[1:1:0712/114630.945083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114631.262515:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3150:3150:0712/114643.435116:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3150:3150:0712/114643.439110:INFO:CONSOLE(1)] "The provided value 'ms-stream' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3150:3150:0712/114643.443607:INFO:CONSOLE(1)] "The provided value 'moz-chunked-arraybuffer' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3150:3150:0712/114643.448251:INFO:CONSOLE(1)] "The provided value 'moz-chunked-text' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3150:3150:0712/114643.452751:INFO:CONSOLE(1)] "The provided value 'moz-blob' is not a valid enum value of type XMLHttpRequestResponseType.", source: https://img1.wsimg.com/wrhs/251e75fec32f764d7b566fb589f7a9e0/uxcore2.min.js (1)
[3:3:0712/114643.515767:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/114643.628235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114643.671460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 526 0x7f840c8c12e0 0x36fef0eeade0 , "https://be.godaddy.com/"
[1:1:0712/114643.738228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t(require("@ux/compo
[1:1:0712/114643.738556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114644.228402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114644.259167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114644.259471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 0
[1:1:0712/114644.259917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 588
[1:1:0712/114644.260178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7f840a999070 0x36fef27a45e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[1:1:0712/114645.480414:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114651.391356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114651.393596:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114651.393903:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114659.874854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114659.875123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 100
[1:1:0712/114659.875538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 622
[1:1:0712/114659.875813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f840a999070 0x36fef6a235e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[1:1:0712/114659.876881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 400, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114659.877083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 400
[1:1:0712/114659.877482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 623
[1:1:0712/114659.877721:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f840a999070 0x36fef6e70360 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[1:1:0712/114702.251143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114702.251414:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 0
[1:1:0712/114702.251656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 674
[1:1:0712/114702.251819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7f840a999070 0x36fef6e435e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[1:1:0712/114703.067825:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114703.068032:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 30000
[1:1:0712/114703.068429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 694
[1:1:0712/114703.068557:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f840a999070 0x36fef0e731e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[3150:3150:0712/114705.363035:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/114709.615257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x2328de3429c8, 0x36fef0b53210
[1:1:0712/114709.615555:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 30000
[1:1:0712/114709.616018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 698
[1:1:0712/114709.616258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f840a999070 0x36fefa6ccf60 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 526 0x7f840c8c12e0 0x36fef0eeade0 
[1:1:0712/114711.235514:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114711.236264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , i.onload, (){}
[1:1:0712/114711.236528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114711.301535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114711.302299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , i.onload, (){}
[1:1:0712/114711.302549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114711.414363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114711.415237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , i.onload, (){}
[1:1:0712/114711.415521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114711.472324:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 510, 7f840d2de881
[1:1:0712/114711.508897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"37f083c42860","ptid":"436 0x7f840a999070 0x36fef112d0e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114711.509369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://be.godaddy.com/","ptid":"436 0x7f840a999070 0x36fef112d0e0 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114711.509906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114711.510602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , e, (){d.hasConsent()?P():d.hasConsentBeenAsked()||setTimeout(e,s.get("tcc.consentDelayMs"))}
[1:1:0712/114711.510881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114711.524824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2328de3429c8, 0x36fef0b53150
[1:1:0712/114711.525149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://be.godaddy.com/", 500
[1:1:0712/114711.525708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 728
[1:1:0712/114711.526016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f840a999070 0x36fef6e730e0 , 5:3_https://be.godaddy.com/, 1, -5:3_https://be.godaddy.com/, 510 0x7f840a999070 0x36fef15f53e0 
[1:1:0712/114711.528326:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 536, 7f840d2de8db
[1:1:0712/114711.567602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"506 0x7f840a999070 0x36fef0de5e60 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114711.568035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"506 0x7f840a999070 0x36fef0de5e60 ","rf":"5:3_https://be.godaddy.com/"}
[1:1:0712/114711.568556:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://be.godaddy.com/, 730
[1:1:0712/114711.568812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f840a999070 0x36fefb00dfe0 , 5:3_https://be.godaddy.com/, 0, , 536 0x7f840a999070 0x36fef13479e0 
[1:1:0712/114711.569170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://be.godaddy.com/"
[1:1:0712/114711.569802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , () { _checkPosition(true); }
[1:1:0712/114711.570033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114711.657500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/114711.657702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114713.109080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://be.godaddy.com/"
[1:1:0712/114713.110567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , m, (e){e.source!==a||"string"!=typeof e.data||e.data.indexOf(i)||p(+e.data.slice(i.length))}
[1:1:0712/114713.110757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
[1:1:0712/114716.307849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://be.godaddy.com/"
[1:1:0712/114716.308323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://be.godaddy.com/, 37f083c42860, , On, (e,t){if(_n){var n=He(t);if(null===(n=D(n))||"number"!=typeof n.tag||2===nn(n)||(n=null),kn.length){
[1:1:0712/114716.309094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://be.godaddy.com/", "be.godaddy.com", 3, 1, , , 0
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              [1:1:0100/000000.547857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://be.godaddy.com/, 603, 7f5b3e3a4881
