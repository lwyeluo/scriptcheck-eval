[0712/090906.242002:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090906.242361:INFO:switcher_clone.cc(787)] backtrace rip is 7fbb70989891
[0712/090907.322090:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090907.322454:INFO:switcher_clone.cc(787)] backtrace rip is 7f2e424db891
[1:1:0712/090907.335118:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/090907.335373:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/090907.343130:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[114158:114158:0712/090908.706855:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/93831f56-3dc2-4dbf-b6a7-c62f28c143be
[0712/090908.814663:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/090908.815143:INFO:switcher_clone.cc(787)] backtrace rip is 7f081fc7c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[114190:114190:0712/090909.059830:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=114190
[114202:114202:0712/090909.060223:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=114202
[114158:114158:0712/090909.176395:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[114158:114188:0712/090909.177149:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/090909.177399:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/090909.177694:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/090909.178452:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/090909.178671:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/090909.182089:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1201005d, 1
[1:1:0712/090909.182452:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x16ce1fda, 0
[1:1:0712/090909.182656:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1faa46b6, 3
[1:1:0712/090909.182860:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x27f4111b, 2
[1:1:0712/090909.183104:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffda1fffffffce16 5d000112 1b11fffffff427 ffffffb646ffffffaa1f , 10104, 4
[1:1:0712/090909.184105:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[114158:114188:0712/090909.184382:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��]
[114158:114188:0712/090909.184479:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��]
[1:1:0712/090909.184373:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e407160a0, 3
[1:1:0712/090909.184613:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e408a1080, 2
[114158:114188:0712/090909.184755:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/090909.184747:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e2a564d20, -2
[114158:114188:0712/090909.184819:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 114210, 4, da1fce16 5d000112 1b11f427 b646aa1f 
[1:1:0712/090909.197123:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/090909.197882:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27f4111b
[1:1:0712/090909.198739:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27f4111b
[1:1:0712/090909.200064:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27f4111b
[1:1:0712/090909.200879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.201029:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.201167:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.201313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.201688:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27f4111b
[1:1:0712/090909.201899:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e424db7ba
[1:1:0712/090909.202009:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e424d2def, 7f2e424db77a, 7f2e424dd0cf
[1:1:0712/090909.204373:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27f4111b
[1:1:0712/090909.204658:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27f4111b
[1:1:0712/090909.205067:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27f4111b
[1:1:0712/090909.206132:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.206284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.206444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.206597:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27f4111b
[1:1:0712/090909.207295:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27f4111b
[1:1:0712/090909.207549:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e424db7ba
[1:1:0712/090909.207666:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e424d2def, 7f2e424db77a, 7f2e424dd0cf
[1:1:0712/090909.211178:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/090909.211537:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/090909.211661:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0a530bd8, 0x7ffd0a530b58)
[1:1:0712/090909.229551:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/090909.236762:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[114158:114158:0712/090909.883736:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090909.884883:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114169:0712/090909.907270:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[114158:114169:0712/090909.907462:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090909.907508:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[114158:114158:0712/090909.907657:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[114158:114158:0712/090909.907800:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,114210, 4
[1:7:0712/090909.910007:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[114158:114182:0712/090909.952600:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/090910.039921:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2e634663a220
[1:1:0712/090910.040202:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/090910.520802:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[114158:114158:0712/090912.172708:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[114158:114158:0712/090912.172837:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/090912.187645:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090912.191501:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090913.080582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/090913.080783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090913.085732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/090913.085864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090913.099706:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090913.409813:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090913.410058:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090913.785189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090913.793238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/090913.793495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090913.814900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090913.825535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/090913.825786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090913.839273:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[114158:114158:0712/090913.841172:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[114158:114158:0712/090913.843589:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/090913.844287:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e6346638e20
[1:1:0712/090913.844540:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[114158:114158:0712/090913.877798:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[114158:114158:0712/090913.877957:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/090913.943967:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090914.940400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f2e2c13f2e0 0x2e634681c2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090914.941131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/090914.941263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090914.941812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[114158:114158:0712/090914.971785:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/090914.974096:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2e6346639820
[1:1:0712/090914.974305:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[114158:114158:0712/090914.982044:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/090914.993183:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090914.993385:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[114158:114158:0712/090915.001535:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[114158:114158:0712/090915.008929:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090915.009943:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114169:0712/090915.013042:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[114158:114158:0712/090915.013076:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[114158:114158:0712/090915.013126:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[114158:114169:0712/090915.013135:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090915.013191:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,114210, 4
[1:7:0712/090915.019062:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090915.649237:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/090916.204051:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f2e2c13f2e0 0x2e63469d0860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090916.205120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bc46bf41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/090916.205358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/090916.206139:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/090916.462707:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[114158:114158:0712/090916.466724:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[114158:114158:0712/090916.466819:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[114158:114158:0712/090916.658529:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[114158:114188:0712/090916.659005:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/090916.659207:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/090916.659448:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/090916.659869:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/090916.660178:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/090916.663638:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ecd5ef0, 1
[1:1:0712/090916.664070:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b3e3947, 0
[1:1:0712/090916.664276:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xe9b71f3, 3
[1:1:0712/090916.664434:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x18f9548e, 2
[1:1:0712/090916.664582:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 47393e3b fffffff05effffffcd1e ffffff8e54fffffff918 fffffff371ffffff9b0e , 10104, 5
[1:1:0712/090916.665573:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[114158:114188:0712/090916.665803:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGG9>;�^��T��q���
[114158:114188:0712/090916.665874:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is G9>;�^��T��q�謨�
[1:1:0712/090916.666019:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e407160a0, 3
[114158:114188:0712/090916.666181:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 114254, 5, 47393e3b f05ecd1e 8e54f918 f3719b0e 
[1:1:0712/090916.666221:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e408a1080, 2
[1:1:0712/090916.666404:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2e2a564d20, -2
[1:1:0712/090916.681426:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/090916.681853:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18f9548e
[1:1:0712/090916.682232:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18f9548e
[1:1:0712/090916.682952:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18f9548e
[1:1:0712/090916.683384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.683485:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.683572:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.683665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.683887:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18f9548e
[1:1:0712/090916.684194:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e424db7ba
[1:1:0712/090916.684402:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e424d2def, 7f2e424db77a, 7f2e424dd0cf
[1:1:0712/090916.690376:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 18f9548e
[1:1:0712/090916.690854:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 18f9548e
[1:1:0712/090916.691654:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 18f9548e
[1:1:0712/090916.693100:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090916.694254:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.694525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.694753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.695016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 18f9548e
[1:1:0712/090916.696387:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 18f9548e
[1:1:0712/090916.696814:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2e424db7ba
[1:1:0712/090916.697023:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2e424d2def, 7f2e424db77a, 7f2e424dd0cf
[1:1:0712/090916.704964:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/090916.705505:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/090916.705701:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0a530bd8, 0x7ffd0a530b58)
[1:1:0712/090916.718060:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/090916.722582:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/090916.919383:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e63465f0220
[1:1:0712/090916.919696:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/090917.219785:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090917.220122:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[114158:114158:0712/090917.302892:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090917.308778:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114169:0712/090917.325026:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[114158:114169:0712/090917.325152:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090917.325666:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[114158:114158:0712/090917.325746:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/publish/query/indexFirst.action, 1
[114158:114158:0712/090917.325879:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:09:17 GMT Content-Type: text/html; charset=GB2312 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: JSESSIONID=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180; path=/; HttpOnly Content-Language: zh-CN Content-Encoding: gzip X-Via-JSL: e543bdf,- Set-Cookie: __jsluid_h=3e926f37bd6e9612a41785c4d8ba2063; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,114254, 5
[1:7:0712/090917.334114:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090917.365825:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[114158:114158:0712/090917.490867:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[114158:114158:0712/090917.490998:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/090917.528770:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090917.589717:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090917.598761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/090917.601179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bc46c06e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/090917.601449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/090917.608806:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/090917.642154:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090917.642428:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/publish/query/indexFirst.action"
[1:1:0712/090917.650261:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2e6346203820
[1:1:0712/090917.650502:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/090917.677720:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090917.677993:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/090917.684287:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2e6346202e20
[1:1:0712/090917.684518:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/090917.706031:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090917.706325:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/090917.711155:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x2e6346202420
[1:1:0712/090917.711542:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/090917.730427:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090917.730706:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/090917.735472:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x2e6346204220
[1:1:0712/090917.735708:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[1:1:0712/090917.743516:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/090917.743774:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/090918.806973:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090918.807632:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090918.808099:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090918.811661:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090918.812047:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090938.057861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/090938.058180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090938.062551:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[114158:114158:0712/090938.392422:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[114158:114158:0712/090938.394761:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: TopMenu, 4, 4, 
[114158:114158:0712/090938.398108:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[114158:114158:0712/090938.410505:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[114158:114158:0712/090938.417552:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: LeftMenu, 5, 5, 
[114158:114158:0712/090938.430803:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[114158:114158:0712/090938.435902:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[114158:114158:0712/090938.443734:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: middleFrame, 6, 6, 
[114158:114158:0712/090938.455793:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[114158:114158:0712/090938.460769:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[114158:114158:0712/090938.462824:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: MainMenu, 7, 7, 
[114158:114158:0712/090938.474367:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[114158:114158:0712/090938.506910:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/090938.598380:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[114158:114158:0712/090938.668696:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090938.673065:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114169:0712/090938.686991:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[114158:114169:0712/090938.687126:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090938.687312:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[114158:114158:0712/090938.687434:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0, 4
[114158:114158:0712/090938.687616:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:09:38 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip X-Via-JSL: e543bdf,- X-Cache: bypass  ,114254, 5
[1:7:0712/090938.702524:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090938.921438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090938.921767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090939.020898:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://beian.miit.gov.cn/
[114158:114158:0712/090939.272817:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090939.275335:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114169:0712/090939.280256:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[114158:114169:0712/090939.280356:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090939.280403:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[114158:114158:0712/090939.280479:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/commons/middle.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180, 6
[114158:114158:0712/090939.280571:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:09:38 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip X-Via-JSL: e543bdf,- X-Cache: bypass  ,114254, 5
[114158:114158:0712/090939.281191:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[114158:114158:0712/090939.283395:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/090939.283748:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[114158:114169:0712/090939.288312:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[114158:114169:0712/090939.288419:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[114158:114158:0712/090939.288964:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[114158:114158:0712/090939.289020:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180, 5
[114158:114158:0712/090939.289102:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:09:38 GMT Content-Type: text/html; charset=GB2312 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip X-Via-JSL: e543bdf,- X-Cache: bypass  ,114254, 5
[114158:114158:0712/090939.289714:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/090939.291281:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[114158:114158:0712/090939.291861:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[114158:114158:0712/090939.295948:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[114158:114158:0712/090939.295987:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/commons/welcome.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180, 7
[114158:114169:0712/090939.296002:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[114158:114158:0712/090939.296041:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 16:09:38 GMT Content-Type: text/html; charset=GB2312 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip X-Via-JSL: e543bdf,- X-Cache: bypass  ,114254, 5
[114158:114169:0712/090939.296092:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/090939.296916:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/090939.321855:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[114158:114158:0712/090939.328670:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 4
[114158:114158:0712/090939.328778:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/090939.540320:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://beian.miit.gov.cn/
[1:1:0712/090939.577807:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://beian.miit.gov.cn/
[1:1:0712/090939.671783:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://beian.miit.gov.cn/
[1:1:0712/090939.767159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090939.767464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090939.833026:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090940.099807:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[114158:114158:0712/090940.104205:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 6
[114158:114158:0712/090940.104265:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/090940.170991:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[114158:114158:0712/090940.174371:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 5
[114158:114158:0712/090940.174477:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[114158:114158:0712/090940.227481:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 7
[114158:114158:0712/090940.227591:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/090940.228057:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/090940.327275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090940.327576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090940.426055:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090940.426334:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0"
[1:1:0712/090940.477634:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090940.651479:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090940.787064:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/090940.907615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090940.907991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090941.159421:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090941.159700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/commons/middle.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090941.166739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 345 0x7f2e2a217070 0x2e63466f8a60 , "http://beian.miit.gov.cn/commons/middle.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090941.201634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://beian.miit.gov.cn/, 1407bd088430, , , 
	//左右 
	function switchSysBarl() {
		var imgsrc;
		imgsrc = document.all("makeleft").src;
		if 
[1:1:0712/090941.202018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/middle.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180", "beian.miit.gov.cn", 6, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090941.449237:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090941.449548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090941.518442:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/090941.518667:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/commons/welcome.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090941.580448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090941.580652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090941.946174:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390, "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090941.951295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://beian.miit.gov.cn/, 1407bd083bb0, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/090941.951534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180", "beian.miit.gov.cn", 5, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090943.307766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090943.307980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090943.350657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 407, "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090943.352776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://beian.miit.gov.cn/, 1407bd083bb0, , ,        
	   
	   var json = {0:"gg"};  
		  
	   function changeShow(i,p1 ,p2) {
		   var cid =
[1:1:0712/090943.353139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180", "beian.miit.gov.cn", 5, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090944.099527:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 445, "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090944.109263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://beian.miit.gov.cn/, 1407bd083bb0, , , /*----------------------------------------------------------------------------\
|                  
[1:1:0712/090944.109635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180", "beian.miit.gov.cn", 5, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090944.345131:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7f2e2a217070 0x2e6346b2b7e0 , "http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0"
[1:1:0712/090944.359430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://beian.miit.gov.cn/, 1407bcf7c920, , , 
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Ar
[1:1:0712/090944.359680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0", "beian.miit.gov.cn", 4, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090944.469769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090944.470152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090945.913029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090945.913277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090946.214388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541 0x7f2e2a217070 0x2e6347465360 , "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180"
[1:1:0712/090946.215273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://beian.miit.gov.cn/, 1407bd083bb0, , , 
			var ispQuery = new WebFXTree("备案查询");
		
			new WebFXTreeItem("备案信息查询",
				
[1:1:0712/090946.215439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/left.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180", "beian.miit.gov.cn", 5, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090947.075089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090947.075815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090947.197803:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0"
[1:1:0712/090947.201119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://beian.miit.gov.cn/, 1407bcf7c920, , onload, MM_preloadImages('/images/new/denglu01.gif')
[1:1:0712/090947.201459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/commons/top.jsp;jsessionid=Ggzm9nJv9JG-H5n781j5CBTR_RG8a3SfuZqvfrm6QKv-RwGLPsf_!285674180?provinceSign=0", "beian.miit.gov.cn", 4, 1, http://beian.miit.gov.cn, beian.miit.gov.cn, 3
[1:1:0712/090947.726468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090947.726775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090949.283429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 1407bcf62860, , , document.readyState
[1:1:0712/090949.283750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/publish/query/indexFirst.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/090949.921305:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090949.921798:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/090949.968790:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/favicon.ico"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
