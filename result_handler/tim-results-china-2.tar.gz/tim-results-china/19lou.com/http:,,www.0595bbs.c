[0713/021655.357615:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/021655.357917:INFO:switcher_clone.cc(787)] backtrace rip is 7f42c4ad8891
[0713/021656.337108:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/021656.337604:INFO:switcher_clone.cc(787)] backtrace rip is 7f8afbcbb891
[1:1:0713/021656.351851:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/021656.352171:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/021656.357516:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[39109:39109:0713/021657.647736:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1c7e5a36-43d0-44b9-ad44-534855d8c9f9
[0713/021657.777998:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/021657.778399:INFO:switcher_clone.cc(787)] backtrace rip is 7f000550e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[39141:39141:0713/021658.028262:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39141
[39153:39153:0713/021658.028658:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=39153
[39109:39109:0713/021658.096669:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[39109:39139:0713/021658.097415:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/021658.097637:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/021658.097891:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/021658.098532:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/021658.098737:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/021658.102186:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31ab8655, 1
[1:1:0713/021658.102528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3714db06, 0
[1:1:0713/021658.102739:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x373306c2, 3
[1:1:0713/021658.102955:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd902ad6, 2
[1:1:0713/021658.103190:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 06ffffffdb1437 55ffffff86ffffffab31 ffffffd62affffff900d ffffffc2063337 , 10104, 4
[1:1:0713/021658.104278:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39109:39139:0713/021658.104578:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�7U��1�*��37I��$
[39109:39139:0713/021658.104651:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �7U��1�*��37h2I��$
[1:1:0713/021658.104572:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8af9ef60a0, 3
[39109:39139:0713/021658.104971:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0713/021658.104852:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8afa081080, 2
[39109:39139:0713/021658.105050:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39161, 4, 06db1437 5586ab31 d62a900d c2063337 
[1:1:0713/021658.105087:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ae3d44d20, -2
[1:1:0713/021658.120585:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/021658.121452:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d902ad6
[1:1:0713/021658.122371:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d902ad6
[1:1:0713/021658.123909:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d902ad6
[1:1:0713/021658.125408:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.125630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.125854:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.126081:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.126764:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d902ad6
[1:1:0713/021658.127149:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021658.127357:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021658.133176:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d902ad6
[1:1:0713/021658.133616:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d902ad6
[1:1:0713/021658.134386:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d902ad6
[1:1:0713/021658.136792:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.137078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.137332:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.137558:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d902ad6
[1:1:0713/021658.138829:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d902ad6
[1:1:0713/021658.139248:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021658.139442:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021658.147300:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/021658.147947:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/021658.148145:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe2cdcc1e8, 0x7ffe2cdcc168)
[1:1:0713/021658.164810:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/021658.171836:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[39109:39132:0713/021658.712709:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[39109:39109:0713/021658.714705:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39109:39109:0713/021658.716075:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39109:39120:0713/021658.736077:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[39109:39109:0713/021658.736484:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[39109:39120:0713/021658.736200:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[39109:39109:0713/021658.736602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[39109:39109:0713/021658.737009:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,39161, 4
[1:7:0713/021658.753157:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/021658.890575:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xd923f4e1220
[1:1:0713/021658.890869:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/021659.251841:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/021700.686333:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021700.690274:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[39109:39109:0713/021700.793982:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[39109:39109:0713/021700.794065:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/021701.486579:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/021701.626088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/021701.626401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021701.657106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/021701.657406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021701.783072:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021701.783352:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021702.205567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021702.213645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/021702.213911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021702.251945:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021702.262424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/021702.262690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021702.274846:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[39109:39109:0713/021702.277768:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/021702.278391:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd923f4dfe20
[1:1:0713/021702.278584:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[39109:39109:0713/021702.297434:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[39109:39109:0713/021702.346893:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[39109:39109:0713/021702.346994:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/021702.375119:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021703.092290:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f8ae591f2e0 0xd923f77c660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021703.093661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/021703.093959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021703.095417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[39109:39109:0713/021703.140179:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/021703.142069:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xd923f4e0820
[1:1:0713/021703.142406:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[39109:39109:0713/021703.147020:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/021703.163443:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/021703.163704:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[39109:39109:0713/021703.164962:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[39109:39109:0713/021703.175903:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39109:39109:0713/021703.176860:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[39109:39120:0713/021703.179102:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[39109:39109:0713/021703.179134:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[39109:39109:0713/021703.179186:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[39109:39120:0713/021703.179188:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[39109:39109:0713/021703.179246:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,39161, 4
[1:7:0713/021703.180431:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/021703.599621:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/021703.900183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f8ae591f2e0 0xd923f750fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021703.901269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/021703.901673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021703.902442:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[39109:39109:0713/021704.037344:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[39109:39109:0713/021704.037465:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/021704.067201:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/021704.275834:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/021704.496074:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021704.497268:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021704.698656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 533, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021704.703214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/021704.703508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021704.711215:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021704.805711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/021704.806172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17b26dc01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/021704.806285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/021704.944480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021704.945276:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/021704.945382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/021704.945499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021705.031930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021705.032796:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/021705.033008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/021705.033291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[39109:39109:0713/021705.132844:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[39109:39139:0713/021705.133302:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/021705.133441:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/021705.133697:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/021705.133992:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/021705.134136:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/021705.136614:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xff75738, 1
[1:1:0713/021705.137001:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33147e7, 0
[1:1:0713/021705.137187:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a8f210f, 3
[1:1:0713/021705.137338:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2593e35, 2
[1:1:0713/021705.137480:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe7473103 3857fffffff70f 353e5902 0f21ffffff8f3a , 10104, 5
[1:1:0713/021705.138438:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39109:39139:0713/021705.138663:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�G18W�5>Y!�:���$
[39109:39139:0713/021705.138733:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �G18W�5>Y!�:(d���$
[39109:39139:0713/021705.138956:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39209, 5, e7473103 3857f70f 353e5902 0f218f3a 
[1:1:0713/021705.139293:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8af9ef60a0, 3
[1:1:0713/021705.139475:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8afa081080, 2
[1:1:0713/021705.139669:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ae3d44d20, -2
[1:1:0713/021705.163033:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/021705.163375:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2593e35
[1:1:0713/021705.163789:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2593e35
[1:1:0713/021705.164569:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2593e35
[1:1:0713/021705.166312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.166551:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.166776:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.167001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.167855:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2593e35
[1:1:0713/021705.168228:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021705.168399:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021705.174029:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2593e35
[1:1:0713/021705.174250:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2593e35
[1:1:0713/021705.174543:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2593e35
[1:1:0713/021705.175255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.175370:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.175466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.175561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2593e35
[1:1:0713/021705.176003:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2593e35
[1:1:0713/021705.176190:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021705.176276:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021705.178471:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/021705.178813:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/021705.178906:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe2cdcc1e8, 0x7ffe2cdcc168)
[1:1:0713/021705.192507:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/021705.197662:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/021705.396569:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0713/021705.401808:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd923f4c2220
[1:1:0713/021705.401932:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/021705.613822:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0713/021705.840522:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mobile.zol.com.cn/"
[1:1:0713/021705.906609:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://qq.com/"
[1:1:0713/021705.963722:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0713/021706.029094:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0713/021706.087469:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0713/021706.153502:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://ikea.com/"
[1:1:0713/021706.438836:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.439801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021706.440056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021706.490685:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.491162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021706.491295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021706.560165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.561083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021706.561316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021706.681483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.682371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021706.682620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021706.774452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.775353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021706.775630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[39109:39109:0713/021706.837743:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[39109:39109:0713/021706.858947:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[39109:39139:0713/021706.859431:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0713/021706.859691:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/021706.859915:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/021706.860421:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/021706.860598:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0713/021706.864283:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe083355, 1
[1:1:0713/021706.864680:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22e10215, 0
[1:1:0713/021706.864952:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x19946f72, 3
[1:1:0713/021706.865611:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xbac9dbc, 2
[1:1:0713/021706.865813:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1502ffffffe122 5533080e ffffffbcffffff9dffffffac0b 726fffffff9419 , 10104, 6
[1:1:0713/021706.866758:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[39109:39139:0713/021706.867047:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�"U3���ro�Z��$
[39109:39139:0713/021706.867120:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �"U3���ro�hZ��$
[39109:39139:0713/021706.867401:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 39225, 6, 1502e122 5533080e bc9dac0b 726f9419 
[1:1:0713/021706.867227:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8af9ef60a0, 3
[1:1:0713/021706.867904:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8afa081080, 2
[1:1:0713/021706.868321:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ae3d44d20, -2
[39109:39109:0713/021706.890600:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/021706.894185:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/021706.894550:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bac9dbc
[1:1:0713/021706.894867:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bac9dbc
[1:1:0713/021706.895478:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bac9dbc
[1:1:0713/021706.896962:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.897193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.897420:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.897656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.898339:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bac9dbc
[1:1:0713/021706.898671:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021706.898845:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021706.901707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.902562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021706.902853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021706.904601:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bac9dbc
[1:1:0713/021706.905050:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bac9dbc
[39109:39120:0713/021706.905747:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[39109:39120:0713/021706.905833:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[39109:39109:0713/021706.905915:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.0595bbs.cn/
[39109:39109:0713/021706.905964:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.0595bbs.cn/, https://www.0595bbs.cn/, 1
[39109:39109:0713/021706.906023:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.0595bbs.cn/, HTTP/1.1 200 Date: Sat, 13 Jul 2019 09:17:06 GMT Content-Type: text/html;charset=GBK Transfer-Encoding: chunked Content-Encoding: gzip Set-Cookie: f9big=bbs127; path=/  ,0, 6
[1:1:0713/021706.905829:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bac9dbc
[1:1:0713/021706.908940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.909227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.909474:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[1:1:0713/021706.909741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bac9dbc
[3:3:0713/021706.910201:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/021706.911036:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bac9dbc
[1:1:0713/021706.911457:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8afbcbb7ba
[1:1:0713/021706.911663:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8afbcb2def, 7f8afbcbb77a, 7f8afbcbd0cf
[1:1:0713/021706.921178:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/021706.921962:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/021706.922150:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe2cdcc1e8, 0x7ffe2cdcc168)
[1:1:0713/021706.937117:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/021706.942779:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/021706.985608:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021706.986706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021706.987008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:7:0713/021706.997475:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/021707.032350:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.033322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021707.034248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.129240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.130174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021707.130454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.163920:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd923f4c8220
[1:1:0713/021707.164233:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/021707.246433:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.0595bbs.cn/
[1:1:0713/021707.248961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.249860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021707.250195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.306361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.307274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021707.307544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.397060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.398020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021707.398311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.470912:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.471880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021707.472168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.558589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.559535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021707.559825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[39109:39109:0713/021707.567629:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.0595bbs.cn/, https://www.0595bbs.cn/, 1
[39109:39109:0713/021707.567751:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.0595bbs.cn/, https://www.0595bbs.cn
[1:1:0713/021707.585933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.586831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0713/021707.587120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.590583:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/021707.697381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/021707.698317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17b26dd2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0713/021707.698587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/021707.710154:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/021707.773236:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/021707.874528:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021707.874839:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.0595bbs.cn/"
[1:1:0713/021708.468030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f8ae39f7070 0xd923f668460 , "https://www.0595bbs.cn/"
[1:1:0713/021708.470303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , 
        var AM_Config = {
            baseUrl: "//js2.citysbs.com/0.8.8.58/forum",
            base
[1:1:0713/021708.470547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021708.477148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f8ae39f7070 0xd923f668460 , "https://www.0595bbs.cn/"
[1:1:0713/021708.482639:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021708.712606:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.239347, 950, 1
[1:1:0713/021708.712875:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/021709.601986:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021709.602209:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.0595bbs.cn/"
[1:1:0713/021709.602963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f8ae39f7070 0xd923f715a60 , "https://www.0595bbs.cn/"
[1:1:0713/021709.603838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , 
    AM.ready(function () {
        AM('//img2.citysbs.com/css/0.8.8.58/forum/default/headevent.css'
[1:1:0713/021709.604019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021709.611055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f8ae39f7070 0xd923f715a60 , "https://www.0595bbs.cn/"
[1:1:0713/021709.617064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7f8ae39f7070 0xd923f715a60 , "https://www.0595bbs.cn/"
[1:1:0713/021709.637371:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.035125, 108, 1
[1:1:0713/021709.637668:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/021710.642268:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021710.642435:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.0595bbs.cn/"
[1:1:0713/021710.650176:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00770402, 67, 1
[1:1:0713/021710.650298:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/021711.706560:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/021711.706737:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.0595bbs.cn/"
[1:1:0713/021711.707192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7f8ae39f7070 0xd923f5bbfe0 , "https://www.0595bbs.cn/"
[1:1:0713/021711.707664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , AM.delay(2000,"//hm.baidu.com/h.js?a03872417ca649a75311ab124267976e");
[1:1:0713/021711.707770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021711.708529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x3b6fe49429c8, 0xd923f11b998
[1:1:0713/021711.708632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 2000
[1:1:0713/021711.708815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 368
[1:1:0713/021711.708920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 368 0x7f8ae39f7070 0xd923f51dce0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 353 0x7f8ae39f7070 0xd923f5bbfe0 
[1:1:0713/021711.709699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7f8ae39f7070 0xd923f5bbfe0 , "https://www.0595bbs.cn/"
[1:1:0713/021711.716217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7f8ae39f7070 0xd923f5bbfe0 , "https://www.0595bbs.cn/"
[1:1:0713/021712.118419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 381, "https://www.0595bbs.cn/"
[1:1:0713/021712.119335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.write('<script charset="utf-8" src="https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js"></scri
[1:1:0713/021712.119522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021712.184896:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f8ae591f2e0 0xd923f665560 , "https://www.0595bbs.cn/"
[1:1:0713/021712.186137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0713/021712.186321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021712.389260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 397, "https://www.0595bbs.cn/"
[1:1:0713/021712.390682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , (function(e){function t(e){var t=location.href,n=t.split("").reverse(),r=e.split(""),i=[];for(var s=
[1:1:0713/021712.390868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021712.404513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 397, "https://www.0595bbs.cn/"
[1:1:0713/021712.405957:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 397, "https://www.0595bbs.cn/"
[1:1:0713/021712.506539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410, "https://www.0595bbs.cn/"
[1:1:0713/021712.510826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , var __dw_ext_query;if(typeof __DM2011__=="undefined"){var __DM2011__={};(function(){!function(N){fun
[1:1:0713/021712.511049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021712.785484:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3b6fe49429c8, 0xd923f11ba38
[1:1:0713/021712.785660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 500
[1:1:0713/021712.785836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 431
[1:1:0713/021712.785944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 431 0x7f8ae39f7070 0xd923f5b63e0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 410
[1:1:0713/021712.797201:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3b6fe49429c8, 0xd923f11ba38
[1:1:0713/021712.797471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 500
[1:1:0713/021712.797792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 436
[1:1:0713/021712.797979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f8ae39f7070 0xd923f669d60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 410
[1:1:0713/021712.805719:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410, "https://www.0595bbs.cn/"
[1:1:0713/021712.810875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021712.815523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.0595bbs.cn/"
[1:1:0713/021716.304761:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021716.309173:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021716.309624:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021716.310068:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021716.310480:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021716.477060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 431, 7f8ae633c881
[1:1:0713/021716.502244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"410","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.502606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"410","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.502927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021716.503540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , pm_send, (){if(typeof jQuery=="function"){try{var g=jQuery("body").height();var c=$(window).height();var a=$(
[1:1:0713/021716.503773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021716.504441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021716.504648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 500
[1:1:0713/021716.505038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 493
[1:1:0713/021716.505291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 493 0x7f8ae39f7070 0xd923fe232e0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 431 0x7f8ae39f7070 0xd923f5b63e0 
[1:1:0713/021716.506766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 436, 7f8ae633c881
[1:1:0713/021716.531571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"410","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.531984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"410","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.532371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021716.533094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , h, (){if(typeof jQuery=="function"){try{var u=$("#nav").offset().top;var s=jQuery("body").height();var 
[1:1:0713/021716.533409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021716.534053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021716.534281:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 500
[1:1:0713/021716.534659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 494
[1:1:0713/021716.534901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 494 0x7f8ae39f7070 0xd923fe342e0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 436 0x7f8ae39f7070 0xd923f669d60 
[1:1:0713/021716.536260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 368, 7f8ae633c881
[1:1:0713/021716.557793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"353 0x7f8ae39f7070 0xd923f5bbfe0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.558191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"353 0x7f8ae39f7070 0xd923f5bbfe0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.558575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021716.559180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , () {
                fn.use.apply(this, args);
            }
[1:1:0713/021716.559413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021716.567815:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021716.568070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 1
[1:1:0713/021716.568472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 495
[1:1:0713/021716.568771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f8ae39f7070 0xd9240364de0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 368 0x7f8ae39f7070 0xd923f51dce0 
[1:1:0713/021716.923497:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 495, 7f8ae633c881
[1:1:0713/021716.944479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"368 0x7f8ae39f7070 0xd923f51dce0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.944917:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"368 0x7f8ae39f7070 0xd923f51dce0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021716.945288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021716.945979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , () {
                    fn.load(url, type, charset, cb, context);
                }
[1:1:0713/021716.946230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021716.947747:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021716.947983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 1
[1:1:0713/021716.948394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 508
[1:1:0713/021716.948631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7f8ae39f7070 0xd923fe21760 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 495 0x7f8ae39f7070 0xd9240364de0 
[1:1:0713/021717.079560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7f8ae591f2e0 0xd923fe18f60 , "https://www.0595bbs.cn/"
[1:1:0713/021717.089967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0713/021717.090224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.325163:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021717.387386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 508, 7f8ae633c881
[1:1:0713/021717.410555:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"495 0x7f8ae39f7070 0xd9240364de0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.410903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"495 0x7f8ae39f7070 0xd9240364de0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.411211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021717.411768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , () {
                    fn.load(url, type, charset, cb, context);
                }
[1:1:0713/021717.411980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.416468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021717.416720:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 1
[1:1:0713/021717.417168:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 521
[1:1:0713/021717.417401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7f8ae39f7070 0xd923f7520e0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 508 0x7f8ae39f7070 0xd923fe21760 
[1:1:0713/021717.463847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 493, 7f8ae633c881
[1:1:0713/021717.474334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"431 0x7f8ae39f7070 0xd923f5b63e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.474678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"431 0x7f8ae39f7070 0xd923f5b63e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.474973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021717.475574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , pm_send, (){if(typeof jQuery=="function"){try{var g=jQuery("body").height();var c=$(window).height();var a=$(
[1:1:0713/021717.475783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.525173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 494, 7f8ae633c881
[1:1:0713/021717.538197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"436 0x7f8ae39f7070 0xd923f669d60 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.538522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"436 0x7f8ae39f7070 0xd923f669d60 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.538853:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021717.539369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , h, (){if(typeof jQuery=="function"){try{var u=$("#nav").offset().top;var s=jQuery("body").height();var 
[1:1:0713/021717.539620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.650909:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 521, 7f8ae633c881
[1:1:0713/021717.663429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"508 0x7f8ae39f7070 0xd923fe21760 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.663770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"508 0x7f8ae39f7070 0xd923fe21760 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.664074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021717.664608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , () {
                    fn.load(url, type, charset, cb, context);
                }
[1:1:0713/021717.664845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.665975:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021717.666178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 1
[1:1:0713/021717.666530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 531
[1:1:0713/021717.666777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7f8ae39f7070 0xd923f73cd60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 521 0x7f8ae39f7070 0xd923f7520e0 
[1:1:0713/021717.733550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 527 0x7f8ae591f2e0 0xd923fdb7660 , "https://www.0595bbs.cn/"
[1:1:0713/021717.734940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , /*
 *@Description: App.component.js
 *@Version:	    v1.2
 *@Author:      GaoLi
 *@Update:      ghy(2
[1:1:0713/021717.735151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021717.742851:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021717.940865:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 531, 7f8ae633c881
[1:1:0713/021717.964070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"521 0x7f8ae39f7070 0xd923f7520e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.964367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"521 0x7f8ae39f7070 0xd923f7520e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021717.964690:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021717.965188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , () {
                    fn.load(url, type, charset, cb, context);
                }
[1:1:0713/021717.965363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021718.386092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553 0x7f8ae591f2e0 0xd923f5bb260 , "https://www.0595bbs.cn/"
[1:1:0713/021718.386944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , /*
 * From:sbsAjax
 */
	App.add({
		ajax:function(id,options){
			//clearWinTips
			if($.clearWinTip
[1:1:0713/021718.387066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021718.388207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021718.403681:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7f8ae591f2e0 0xd923f6fc5e0 , "https://www.0595bbs.cn/"
[1:1:0713/021718.429129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , (function(){var h={},mt={},c={id:"a03872417ca649a75311ab124267976e",dm:["0595bbs.cn"],js:"tongji.bai
[1:1:0713/021718.429390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021718.461752:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b990
[1:1:0713/021718.462000:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021718.462325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 569
[1:1:0713/021718.462510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f8ae39f7070 0xd923fe1e8e0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 554 0x7f8ae591f2e0 0xd923f6fc5e0 
[39109:39109:0713/021745.247993:INFO:CONSOLE(40)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/no/qz/2015/11/05/10/300x60-101115_v2_10871446689475100_a0ba039728a86568ccf4e9795db8b762.png'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (40)
[39109:39109:0713/021745.258284:INFO:CONSOLE(587)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/no/qz/2014/10/17/17/146x260-174218_v2_10241413538938154_a1bb4538087b6f5edc95dfd6733b8890.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (587)
[39109:39109:0713/021745.415748:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure script 'http://se.360.cn/common/qihoo_ie6_tips.js'. This request has been blocked; the content must be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021745.428190:INFO:CONSOLE(922)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://jspassport.ssl.qhimg.com/11.0.1.js?f9426bfd386d644af5919398e6911536, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.0595bbs.cn/ (922)
[39109:39109:0713/021745.432056:INFO:CONSOLE(922)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://jspassport.ssl.qhimg.com/11.0.1.js?f9426bfd386d644af5919398e6911536, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.0595bbs.cn/ (922)
[39109:39109:0713/021745.446650:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://jspassport.ssl.qhimg.com/11.0.1.js?f9426bfd386d644af5919398e6911536 (1)
[39109:39109:0713/021745.450320:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://jspassport.ssl.qhimg.com/11.0.1.js?f9426bfd386d644af5919398e6911536 (1)
[39109:39109:0713/021745.462301:INFO:CONSOLE(967)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://o2.19lou.com/dm2011_city.js?0.7.6.20180831, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.0595bbs.cn/ (967)
[39109:39109:0713/021745.466070:INFO:CONSOLE(967)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://o2.19lou.com/dm2011_city.js?0.7.6.20180831, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.0595bbs.cn/ (967)
[39109:39109:0713/021745.552461:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/021745.588460:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/021745.748705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 600000
[1:1:0713/021745.749194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.0595bbs.cn/, 609
[1:1:0713/021745.749493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f8ae39f7070 0xd923fdd9d60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 554 0x7f8ae591f2e0 0xd923f6fc5e0 
[1:1:0713/021745.755340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021746.092997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/021746.093253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021746.094144:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/021747.026914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 569, 7f8ae633c881
[1:1:0713/021747.034461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"554 0x7f8ae591f2e0 0xd923f6fc5e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021747.034592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"554 0x7f8ae591f2e0 0xd923f6fc5e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021747.034787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021747.035075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/021747.035183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021747.035534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b958
[1:1:0713/021747.035660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021747.035825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 635
[1:1:0713/021747.035925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f8ae39f7070 0xd923f6c0be0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 569 0x7f8ae39f7070 0xd923fe1e8e0 
[1:1:0713/021747.325865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 625 0x7f8ae591f2e0 0xd923fe40a60 , "https://www.0595bbs.cn/"
[1:1:0713/021747.327286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , (function($){
        var rotateLeft = function(lValue, iShiftBits) {
            return (lValue << 
[1:1:0713/021747.327401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021747.328250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021747.332027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3b6fe49429c8, 0xd923f11ba10
[1:1:0713/021747.332135:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 3000
[1:1:0713/021747.332323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 646
[1:1:0713/021747.332440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7f8ae39f7070 0xd923fe45c60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 625 0x7f8ae591f2e0 0xd923fe40a60 
[1:1:0713/021748.201383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.readyState
[1:1:0713/021748.201654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021748.326184:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 635, 7f8ae633c881
[1:1:0713/021748.358697:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"569 0x7f8ae39f7070 0xd923fe1e8e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021748.359051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"569 0x7f8ae39f7070 0xd923fe1e8e0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021748.359476:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021748.360068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/021748.360300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021748.360952:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b958
[1:1:0713/021748.361196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021748.361543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 686
[1:1:0713/021748.361767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f8ae39f7070 0xd9240855560 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 635 0x7f8ae39f7070 0xd923f6c0be0 
[1:1:0713/021748.463795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021748.464747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , f.onload, (){f.onload=v;f=window[d]=v;a&&a(b)}
[1:1:0713/021748.465016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021749.143521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.readyState
[1:1:0713/021749.143815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021749.530756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.0595bbs.cn/"
[1:1:0713/021749.531504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0713/021749.531749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021749.971281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 686, 7f8ae633c881
[1:1:0713/021750.005968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"635 0x7f8ae39f7070 0xd923f6c0be0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021750.006328:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"635 0x7f8ae39f7070 0xd923f6c0be0 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021750.006761:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021750.007386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/021750.007646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021750.008449:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021750.008662:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021750.009061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 785
[1:1:0713/021750.009380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f8ae39f7070 0xd9240f3ad60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 686 0x7f8ae39f7070 0xd9240855560 
[1:1:0713/021750.193538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 700 0x7f8ae591f2e0 0xd923f834860 , "https://www.0595bbs.cn/"
[1:1:0713/021750.195813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , jQuery17209832982209265018_1563009437275({"success":true,"code":0,"data":[{"bid":905000176,"bidStr":
[1:1:0713/021750.196201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021750.201330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[39109:39109:0713/021750.323426:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/160x160/hangzhou/2012/10/24/10/105648_10871351047408158_e22e5d616165472fa38c946c5b1d7a41.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.337787:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/no/hangzhou/2014/07/21/10/230x230-103012_13251405909812652_31c14d48c3ab9a1167eb9db635b5f2ba.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.346799:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/hangzhou/2013/05/29/21/215646_10121369835806108_861e2e1c1d6ac26c4b57b15926ed5d1f.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.352008:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/no/hangzhou/2014/07/21/10/230x230-102027_13991405909227054_573b658fc1b9998065367f7149adbc55.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.393874:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/home/2016/05/05/14/0ddd4582878f5d3e2661a39ecf2a865d_v2_.png'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.401144:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/hangzhou/2019/04/12/12/1200x1600-124510_v2_10731555044310785_f0728ae87fad436a872aa2f609d60e24.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.408493:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att2.citysbs.com/hangzhou/2016/03/04/16/thumb_427x320-161815_v2_14801457079495041_7977ae0111f050ea799289c1063ab67c.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[1:1:0713/021750.411709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 701 0x7f8ae591f2e0 0xd923f63e6e0 , "https://www.0595bbs.cn/"
[39109:39109:0713/021750.415658:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/home/2016/04/26/17/00ac4f4469e73e92328a1f7d0f95bd8a_v2_.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[1:1:0713/021750.415354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , /*
 json2.js
 2014-02-04

 Public Domain.

 NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

[1:1:0713/021750.415856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[39109:39109:0713/021750.427615:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/home/2016/05/30/10/fc7f38b4012a29bba2e39dde4040a945_v2_.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.434903:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/home/2018/11/13/16/3b4763671249fff0ca3fa6016d74dab2_v2_.png'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[39109:39109:0713/021750.442156:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.0595bbs.cn/' was loaded over HTTPS, but requested an insecure image 'http://att3.citysbs.com/120x120/home/2017/02/10/09/c072ade53f88ee87c63076e0236e6088_v2_.jpg'. This content should also be served over HTTPS.", source: https://www.0595bbs.cn/ (0)
[1:1:0713/021750.442792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021750.448882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021751.547284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.readyState
[1:1:0713/021751.547609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021753.527123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 785, 7f8ae633c881
[1:1:0713/021753.540437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"686 0x7f8ae39f7070 0xd9240855560 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021753.540608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"686 0x7f8ae39f7070 0xd9240855560 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021753.540822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021753.541125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/021753.541244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021753.541599:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021753.541698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021753.541857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 949
[1:1:0713/021753.541963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 949 0x7f8ae39f7070 0xd923f186de0 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 785 0x7f8ae39f7070 0xd9240f3ad60 
[1:1:0713/021755.145550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021755.146284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , xhr.onreadystatechange, (){
                if (xhr.readyState === 4) {
                    var status = xhr.status;
       
[1:1:0713/021755.146491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021755.147103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021755.149732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021755.159228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/021756.576138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.readyState
[1:1:0713/021756.576335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021800.541887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 949, 7f8ae633c881
[1:1:0713/021800.612152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"238252c42860","ptid":"785 0x7f8ae39f7070 0xd9240f3ad60 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021800.612549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.0595bbs.cn/","ptid":"785 0x7f8ae39f7070 0xd9240f3ad60 ","rf":"6:3_https://www.0595bbs.cn/"}
[1:1:0713/021800.613033:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.0595bbs.cn/"
[1:1:0713/021800.613717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);x&&(b=!document[x]);p="undefined"==typeof b?u
[1:1:0713/021800.613964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021800.614775:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3b6fe49429c8, 0xd923f11b950
[1:1:0713/021800.614991:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.0595bbs.cn/", 100
[1:1:0713/021800.615495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.0595bbs.cn/, 1278
[1:1:0713/021800.615740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1278 0x7f8ae39f7070 0xd92417a7e60 , 6:3_https://www.0595bbs.cn/, 1, -6:3_https://www.0595bbs.cn/, 949 0x7f8ae39f7070 0xd923f186de0 
context mismatch in svga_sampler_view_destroy
[1:1:0713/021805.407501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1054 0x7f8ae591f2e0 0xd9241065d60 , "https://www.0595bbs.cn/"
[1:1:0713/021805.409375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , /*
 * jQuery Cycle Plugin (with Transition Definitions)
 * Examples and documentation at: http://jqu
[1:1:0713/021805.409651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021805.416160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.0595bbs.cn/"
[1:1:0713/021806.592515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021806.592981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , xhr.onreadystatechange, (){
                if (xhr.readyState === 4) {
                    var status = xhr.status;
       
[1:1:0713/021806.593124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
[1:1:0713/021806.593365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[1:1:0713/021806.594746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.0595bbs.cn/"
[39109:39109:0713/021807.589898:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0713/021809.312127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.0595bbs.cn/, 238252c42860, , , document.readyState
[1:1:0713/021809.312401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.0595bbs.cn/", "www.0595bbs.cn", 3, 1, , , 0
