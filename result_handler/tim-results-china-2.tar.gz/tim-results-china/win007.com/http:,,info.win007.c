[0712/133019.066460:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/133019.067002:INFO:switcher_clone.cc(787)] backtrace rip is 7fcad943d891
[0712/133020.042219:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/133020.042652:INFO:switcher_clone.cc(787)] backtrace rip is 7f41a13dc891
[1:1:0712/133020.054679:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/133020.054942:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/133020.060660:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[16028:16028:0712/133021.183096:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/133021.233408:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/133021.233731:INFO:switcher_clone.cc(787)] backtrace rip is 7f988f864891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/cbb6f098-f5c4-4cfa-85e3-ce0960010368
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[16060:16060:0712/133021.481831:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16060
[16073:16073:0712/133021.482310:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16073
[16028:16028:0712/133021.765539:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[16028:16058:0712/133021.767164:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/133021.767403:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/133021.767638:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/133021.768275:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/133021.768454:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/133021.771416:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8f84dc8, 1
[1:1:0712/133021.771740:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd7294e0, 0
[1:1:0712/133021.772040:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf3013e8, 3
[1:1:0712/133021.772256:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x14a2b57, 2
[1:1:0712/133021.772504:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe0ffffff94720d ffffffc84dfffffff808 572b4a01 ffffffe813300f , 10104, 4
[1:1:0712/133021.773643:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16028:16058:0712/133021.773903:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��r�M�W+J�0$
[16028:16058:0712/133021.773975:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��r�M�W+J�080$
[1:1:0712/133021.773895:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f419f6170a0, 3
[1:1:0712/133021.774129:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f419f7a2080, 2
[16028:16058:0712/133021.774300:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/133021.774287:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4189465d20, -2
[16028:16058:0712/133021.774367:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16081, 4, e094720d c84df808 572b4a01 e813300f 
[1:1:0712/133021.795496:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/133021.796617:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14a2b57
[1:1:0712/133021.797580:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14a2b57
[1:1:0712/133021.798607:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14a2b57
[1:1:0712/133021.799137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.799238:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.799327:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.799484:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.799765:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14a2b57
[1:1:0712/133021.800029:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f41a13dc7ba
[1:1:0712/133021.800117:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f41a13d3def, 7f41a13dc77a, 7f41a13de0cf
[1:1:0712/133021.801578:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14a2b57
[1:1:0712/133021.801733:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14a2b57
[1:1:0712/133021.802009:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14a2b57
[1:1:0712/133021.802654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.802755:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.802899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.803035:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14a2b57
[1:1:0712/133021.803675:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14a2b57
[1:1:0712/133021.803917:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f41a13dc7ba
[1:1:0712/133021.804031:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f41a13d3def, 7f41a13dc77a, 7f41a13de0cf
[1:1:0712/133021.807245:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/133021.807641:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/133021.807737:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde2596848, 0x7ffde25967c8)
[1:1:0712/133021.822570:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/133021.828587:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[16028:16028:0712/133022.454012:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16028:16028:0712/133022.455351:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16028:16040:0712/133022.475922:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[16028:16040:0712/133022.476075:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[16028:16028:0712/133022.476267:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[16028:16028:0712/133022.476361:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[16028:16028:0712/133022.476536:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,16081, 4
[1:7:0712/133022.480578:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[16028:16052:0712/133022.528366:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/133022.536871:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2a45c64b2220
[1:1:0712/133022.537195:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/133022.911984:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/133024.580984:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/133024.585350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[16028:16028:0712/133024.666756:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[16028:16028:0712/133024.666901:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/133025.449866:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133025.709113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/133025.709415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133025.741823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/133025.742130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133025.880329:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133025.880655:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133026.081093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133026.087667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/133026.087957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133026.124004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133026.134417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/133026.134675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133026.141607:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/133026.145115:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a45c64b0e20
[1:1:0712/133026.145333:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16028:16028:0712/133026.155229:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[16028:16028:0712/133026.174329:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[16028:16028:0712/133026.209786:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[16028:16028:0712/133026.209947:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/133026.231895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[16028:16028:0712/133026.250609:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/133026.907098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f418b0402e0 0x2a45c66460e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133026.908601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/133026.908847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133026.910357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16028:16028:0712/133026.989011:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/133026.989480:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2a45c64b1820
[1:1:0712/133026.989694:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[16028:16028:0712/133026.999799:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/133027.008169:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/133027.008417:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[16028:16028:0712/133027.017762:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[16028:16028:0712/133027.029147:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16028:16028:0712/133027.030383:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16028:16040:0712/133027.037830:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[16028:16040:0712/133027.037924:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[16028:16028:0712/133027.038146:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[16028:16028:0712/133027.038260:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[16028:16028:0712/133027.038428:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,16081, 4
[1:7:0712/133027.042072:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/133027.539633:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/133027.982980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f418b0402e0 0x2a45c68697e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133027.984093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/133027.984363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133027.985129:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16028:16028:0712/133028.158678:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[16028:16028:0712/133028.158740:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/133028.178119:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133028.433899:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133028.674948:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133028.675229:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/133028.952903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/133028.957554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0d7304e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/133028.957885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/133028.960740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[16028:16028:0712/133029.061573:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[16028:16058:0712/133029.061967:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/133029.062135:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/133029.062383:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/133029.062692:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/133029.062874:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/133029.066117:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d20be90, 1
[1:1:0712/133029.066518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1ff61cbc, 0
[1:1:0712/133029.066701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x14fb3bbc, 3
[1:1:0712/133029.066914:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x5774bd, 2
[1:1:0712/133029.067097:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbc1cfffffff61f ffffff90ffffffbe202d ffffffbd745700 ffffffbc3bfffffffb14 , 10104, 5
[1:1:0712/133029.068287:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16028:16058:0712/133029.068642:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���� -�tW
[16028:16058:0712/133029.068753:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���� -�tW
[1:1:0712/133029.068624:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f419f6170a0, 3
[1:1:0712/133029.068903:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f419f7a2080, 2
[16028:16058:0712/133029.069090:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16127, 5, bc1cf61f 90be202d bd745700 bc3bfb14 
[1:1:0712/133029.069149:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4189465d20, -2
[1:1:0712/133029.090853:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/133029.091269:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5774bd
[1:1:0712/133029.091688:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5774bd
[1:1:0712/133029.092512:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5774bd
[1:1:0712/133029.093990:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.094217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.094466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.094697:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.095421:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5774bd
[1:1:0712/133029.095780:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f41a13dc7ba
[1:1:0712/133029.096005:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f41a13d3def, 7f41a13dc77a, 7f41a13de0cf
[1:1:0712/133029.100352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/133029.100770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0d72f21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/133029.100915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/133029.101874:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5774bd
[1:1:0712/133029.102261:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5774bd
[1:1:0712/133029.103035:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5774bd
[1:1:0712/133029.105136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.105412:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.105640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.105916:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5774bd
[1:1:0712/133029.107216:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5774bd
[1:1:0712/133029.107619:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f41a13dc7ba
[1:1:0712/133029.107884:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f41a13d3def, 7f41a13dc77a, 7f41a13de0cf
[1:1:0712/133029.115619:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/133029.116181:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/133029.116366:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde2596848, 0x7ffde25967c8)
[1:1:0712/133029.129993:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/133029.134343:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/133029.379782:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a45c648b220
[1:1:0712/133029.380128:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/133029.401948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/133029.404058:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/133029.404308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0d7304e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/133029.404594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/133029.532450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/133029.533154:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/133029.533311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0d7304e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/133029.533510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[16028:16028:0712/133029.973022:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[16028:16028:0712/133029.973196:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0712/133030.012518:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.012986:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.013443:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.013838:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.014210:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.014533:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.014846:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.015206:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.015566:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.015943:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.016315:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.016632:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.016959:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.017326:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.017643:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.017950:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.018299:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.018609:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.018942:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.019375:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.019788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.020218:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.020582:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.020902:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.021257:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.021603:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.021924:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.022259:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.022619:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.022928:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.023250:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.023591:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.023965:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.024311:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.024644:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.024996:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.025350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.025718:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.026076:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.026419:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.026766:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.027143:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133030.155438:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/133030.173626:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/133030.190459:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133030.305571:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/133030.450586:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.alibaba.com/"
[1:1:0712/133030.513341:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0712/133030.625177:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/133030.626962:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133030.627181:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/133030.677025:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0712/133030.677965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4189118070 0x2a45c6569fe0 , "chrome-error://chromewebdata/"
[1:1:0712/133030.681659:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4189118070 0x2a45c6569fe0 , "chrome-error://chromewebdata/"
[1:1:0712/133030.686155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4189118070 0x2a45c6569fe0 , "chrome-error://chromewebdata/"
[1:1:0712/133030.697334:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 171 0x7f4189118070 0x2a45c6569fe0 , "chrome-error://chromewebdata/"
[1:1:0712/133030.739328:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.112098, 81, 1
[1:1:0712/133030.739652:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133030.779533:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/133030.823475:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[3:3:0712/133031.058096:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/133031.553281:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133031.553447:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/133031.554286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f4189118070 0x2a45c64cda60 , "chrome-error://chromewebdata/"
[1:1:0712/133031.557620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f4189118070 0x2a45c64cda60 , "chrome-error://chromewebdata/"
[1:1:0712/133031.560201:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f4189118070 0x2a45c64cda60 , "chrome-error://chromewebdata/"
[1:1:0712/133031.573449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f4189118070 0x2a45c64cda60 , "chrome-error://chromewebdata/"
[1:1:0712/133031.575819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f4189118070 0x2a45c64cda60 , "chrome-error://chromewebdata/"
[1:1:0712/133031.676759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/133031.682215:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/133032.165096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/133032.190137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/133032.204144:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/133032.235625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0712/133032.291957:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/133032.292130:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[16028:16028:0712/133032.293650:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[16028:16028:0712/133032.434558:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16028:16028:0712/133032.435845:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16028:16040:0712/133032.458121:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[16028:16040:0712/133032.458226:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[16028:16028:0712/133032.459142:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://zq.win007.com/
[16028:16028:0712/133032.459221:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zq.win007.com/, http://zq.win007.com/analysis/1732839cn.htm, 1
[16028:16028:0712/133032.459361:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://zq.win007.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 20:30:32 GMT Content-Type: text/html Content-Length: 45386 Last-Modified: Wed, 10 Jul 2019 09:58:25 GMT Connection: keep-alive Vary: Accept-Encoding Server: Win007/DX63SV Content-Encoding: gzip Accept-Ranges: bytes  ,16127, 5
[1:7:0712/133032.461953:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/133032.599836:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://zq.win007.com/
[1:1:0712/133032.684566:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[16028:16028:0712/133032.697158:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://zq.win007.com/, http://zq.win007.com/, 1
[16028:16028:0712/133032.697249:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://zq.win007.com/, http://zq.win007.com
[1:1:0712/133032.716958:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133032.759861:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133032.813736:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133032.814038:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133032.991180:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/133033.624648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 371, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133033.628008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zq.win007.com/, 0c3edcbc2860, , , 
var ShowAd = false;
if (window.location.href.indexOf("my=ad") > 0) ShowAd = true;

//头部广�
[1:1:0712/133033.628319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zq.win007.com/analysis/1732839cn.htm", "zq.win007.com", 3, 1, , , 0
[1:1:0712/133033.682093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133033.684459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zq.win007.com/, 0c3edcbc2860, , , 
function changeCsDiv(cna)
{
    var items = document.getElementById(cna).getElementsByTagName("s
[1:1:0712/133033.684717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zq.win007.com/analysis/1732839cn.htm", "zq.win007.com", 3, 1, , , 0
[1:1:0712/133035.178439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f4189118070 0x2a45c6a3a560 , "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.179554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zq.win007.com/, 0c3edcbc2860, , , var soccer_scheduleid="1744525,1691187,1656704,1691194,1656703,1656702,1662664,1669898,1669407,16694
[1:1:0712/133035.179856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zq.win007.com/analysis/1732839cn.htm", "zq.win007.com", 3, 1, , , 0
[1:1:0712/133035.184585:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f4189118070 0x2a45c6a3a560 , "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.187759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f4189118070 0x2a45c6a3a560 , "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.495856:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.496991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zq.win007.com/, 0c3edcbc2860, , , var arrLeague=[-1,0,2,0,1];
[1:1:0712/133035.497229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zq.win007.com/analysis/1732839cn.htm", "zq.win007.com", 3, 1, , , 0
[1:1:0712/133035.505149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.509348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.553150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512, "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.577307:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0785091, 76, 1
[1:1:0712/133035.577620:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/133035.755110:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/133035.755460:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.758188:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531 0x7f4189118070 0x2a45c6524be0 , "http://zq.win007.com/analysis/1732839cn.htm"
[1:1:0712/133035.759114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://zq.win007.com/, 0c3edcbc2860, , ,  changeLangStatus();
[1:1:0712/133035.759344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://zq.win007.com/analysis/1732839cn.htm", "zq.win007.com", 3, 1, , , 0
[1:1:0712/133036.023147:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.265968, 3823, 1
[1:1:0712/133036.023455:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
