[0711/223521.202955:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223521.203371:INFO:switcher_clone.cc(787)] backtrace rip is 7f29e5be2891
[0711/223522.091620:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223522.091940:INFO:switcher_clone.cc(787)] backtrace rip is 7efce4002891
[1:1:0711/223522.095950:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/223522.096112:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/223522.100780:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26671:26671:0711/223523.269864:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bc2ce030-1b96-44f2-b4e3-48f25506a4d3
[0711/223523.481504:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223523.482025:INFO:switcher_clone.cc(787)] backtrace rip is 7fd6ce758891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26704:26704:0711/223523.705133:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26704
[26715:26715:0711/223523.705547:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26715
[26671:26671:0711/223523.745552:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26671:26700:0711/223523.746424:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/223523.746658:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223523.746893:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223523.747500:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223523.747696:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/223523.751459:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e0ceae, 1
[1:1:0711/223523.751843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xc5b1bab, 0
[1:1:0711/223523.752003:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39639af6, 3
[1:1:0711/223523.752245:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c49f95d, 2
[1:1:0711/223523.752448:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffab1b5b0c ffffffaeffffffceffffffe001 5dfffffff9493c fffffff6ffffff9a6339 , 10104, 4
[1:1:0711/223523.753605:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26671:26700:0711/223523.753873:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�[���]�I<��c9�C�6
[26671:26700:0711/223523.753966:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �[���]�I<��c9�ũC�6
[26671:26700:0711/223523.754325:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/223523.754187:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce223d0a0, 3
[26671:26700:0711/223523.754397:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26723, 4, ab1b5b0c aecee001 5df9493c f69a6339 
[1:1:0711/223523.754466:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce23c8080, 2
[1:1:0711/223523.754676:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efccc08bd20, -2
[1:1:0711/223523.772222:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223523.773288:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c49f95d
[1:1:0711/223523.774460:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c49f95d
[1:1:0711/223523.776412:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c49f95d
[1:1:0711/223523.778272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.778496:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.778728:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.778960:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.779750:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c49f95d
[1:1:0711/223523.780203:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223523.780372:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223523.787276:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c49f95d
[1:1:0711/223523.787715:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c49f95d
[1:1:0711/223523.788647:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c49f95d
[1:1:0711/223523.791152:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.791385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.791612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.791834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c49f95d
[1:1:0711/223523.793414:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c49f95d
[1:1:0711/223523.793852:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223523.794013:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223523.803486:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223523.803995:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223523.804191:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc0b072e48, 0x7ffc0b072dc8)
[1:1:0711/223523.818076:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223523.823864:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26671:26694:0711/223524.405215:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[26671:26671:0711/223524.411534:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26671:26671:0711/223524.411984:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26671:26682:0711/223524.433646:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26671:26671:0711/223524.433691:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26671:26682:0711/223524.433752:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26671:26671:0711/223524.433777:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26671:26671:0711/223524.433954:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26723, 4
[1:7:0711/223524.437543:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223524.516609:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe0304d23220
[1:1:0711/223524.516872:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/223524.870159:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[26671:26671:0711/223526.236287:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26671:26671:0711/223526.236409:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223526.239987:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223526.244497:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223526.932951:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223526.969698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223526.970007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223526.982210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223526.982498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223527.075449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223527.075722:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223527.302282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223527.310465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223527.310760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223527.326893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223527.334730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223527.334978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223527.347216:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26671:26671:0711/223527.350714:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/223527.351880:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe0304d21e20
[1:1:0711/223527.352122:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26671:26671:0711/223527.367112:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26671:26671:0711/223527.380474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26671:26671:0711/223527.380562:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223527.452554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223528.099487:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7efccdc662e0 0xe0304dbb5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223528.100954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/223528.101215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223528.102742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26671:26671:0711/223528.176698:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/223528.178808:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe0304d22820
[1:1:0711/223528.179560:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26671:26671:0711/223528.183315:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/223528.200522:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/223528.202181:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26671:26671:0711/223528.205964:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26671:26671:0711/223528.217483:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26671:26671:0711/223528.218533:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26671:26682:0711/223528.224820:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26671:26671:0711/223528.224918:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26671:26682:0711/223528.224914:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26671:26671:0711/223528.225028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26671:26671:0711/223528.225186:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26723, 4
[1:7:0711/223528.234341:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223528.873131:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/223529.089431:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7efccdc662e0 0xe0304fc5160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223529.090509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/223529.090748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223529.091520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26671:26671:0711/223529.255452:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26671:26671:0711/223529.255569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/223529.260943:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223529.570053:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223529.844243:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223529.844580:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223529.969823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223529.975319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/223529.975692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223529.983694:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223530.107085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223530.108089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/223530.108333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223530.252178:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223530.253878:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/223530.254119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/223530.254383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223530.380174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223530.381056:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/223530.381266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/223530.381518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223530.712462:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0711/223530.926375:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/223531.053559:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/223531.084504:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/223531.132189:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/223531.196071:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/223531.283915:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/223531.475357:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/223531.552521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.553026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223531.553167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.579133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.579631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223531.579771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.599200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.599693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223531.599830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.631651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.632166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223531.632303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.655508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.656036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223531.656175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.762620:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.763519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223531.763749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.906629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.907547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223531.907778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223531.997887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223531.998797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223531.999028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.087842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.088433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223532.088576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.147434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.148378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223532.148610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.209245:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.210385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223532.210684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.301016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.302006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223532.302277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.360585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.361720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223532.362017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.445396:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.446303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223532.446534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.566321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.567226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/223532.567456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223532.657889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223532.659005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20f875d6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/223532.659303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[26671:26671:0711/223532.779369:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26671:26700:0711/223532.779843:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/223532.780040:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223532.780291:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223532.780665:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223532.780804:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/223532.784013:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x109ad22b, 1
[1:1:0711/223532.784398:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa976a83, 0
[1:1:0711/223532.784582:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x29beb4dc, 3
[1:1:0711/223532.784761:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2644ae0c, 2
[1:1:0711/223532.784933:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff836affffff970a 2bffffffd2ffffff9a10 0cffffffae4426 ffffffdcffffffb4ffffffbe29 , 10104, 5
[1:1:0711/223532.785959:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26671:26700:0711/223532.786266:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�j�
+Қ�D&ܴ�)�E�6
[26671:26700:0711/223532.786345:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �j�
+Қ�D&ܴ�)x5�E�6
[1:1:0711/223532.786242:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce223d0a0, 3
[26671:26700:0711/223532.786701:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26768, 5, 836a970a 2bd29a10 0cae4426 dcb4be29 
[1:1:0711/223532.786641:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce23c8080, 2
[1:1:0711/223532.787166:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efccc08bd20, -2
[1:1:0711/223532.808990:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223532.809361:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2644ae0c
[1:1:0711/223532.809738:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2644ae0c
[1:1:0711/223532.810416:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2644ae0c
[1:1:0711/223532.811844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.812085:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.812321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.812565:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.813280:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2644ae0c
[1:1:0711/223532.813600:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223532.813788:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223532.820413:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2644ae0c
[1:1:0711/223532.820944:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2644ae0c
[1:1:0711/223532.821928:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2644ae0c
[1:1:0711/223532.824739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.825016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.825277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.825524:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2644ae0c
[1:1:0711/223532.826551:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2644ae0c
[1:1:0711/223532.826966:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223532.827141:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223532.834958:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223532.835638:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223532.835820:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc0b072e48, 0x7ffc0b072dc8)
[1:1:0711/223532.849655:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223532.853897:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/223532.915961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223532.917647:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0711/223532.920427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20f875c41f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0711/223532.920712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223533.132433:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe0304cfb220
[1:1:0711/223533.132740:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[26671:26671:0711/223534.848135:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26671:26671:0711/223534.888268:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[26671:26700:0711/223534.888781:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0711/223534.889050:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223534.889292:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223534.889720:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223534.889931:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0711/223534.892994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8637e3c, 1
[1:1:0711/223534.893390:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29b33c03, 0
[1:1:0711/223534.893624:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1feb557e, 3
[1:1:0711/223534.893832:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3615b4a3, 2
[1:1:0711/223534.894026:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 033cffffffb329 3c7e6308 ffffffa3ffffffb41536 7e55ffffffeb1f , 10104, 6
[1:1:0711/223534.895251:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26671:26700:0711/223534.895609:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING<�)<~c��6~U�
F�6
[26671:26700:0711/223534.895698:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is <�)<~c��6~U�h�
F�6
[1:1:0711/223534.895903:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce223d0a0, 3
[26671:26700:0711/223534.896084:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26783, 6, 033cb329 3c7e6308 a3b41536 7e55eb1f 
[1:1:0711/223534.896148:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efce23c8080, 2
[1:1:0711/223534.896398:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efccc08bd20, -2
[1:1:0711/223534.920583:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223534.920959:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3615b4a3
[1:1:0711/223534.921263:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3615b4a3
[26671:26671:0711/223534.921428:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/223534.921887:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3615b4a3
[1:1:0711/223534.924482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.924775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.925060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.925308:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.926144:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3615b4a3
[1:1:0711/223534.926482:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223534.926653:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223534.933623:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3615b4a3
[1:1:0711/223534.934074:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3615b4a3
[1:1:0711/223534.934870:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3615b4a3
[1:1:0711/223534.936979:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.937229:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.937457:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.937673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3615b4a3
[1:1:0711/223534.938971:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3615b4a3
[1:1:0711/223534.939369:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efce40027ba
[1:1:0711/223534.939537:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efce3ff9def, 7efce400277a, 7efce40040cf
[1:1:0711/223534.947840:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223534.948410:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223534.948588:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc0b072e48, 0x7ffc0b072dc8)
[26671:26682:0711/223534.954733:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[26671:26682:0711/223534.954859:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[26671:26671:0711/223534.955336:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.liansuo.com/
[26671:26671:0711/223534.955433:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.liansuo.com/, https://www.liansuo.com/, 1
[26671:26671:0711/223534.955595:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.liansuo.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=UTF-8 vary:Accept-Encoding x-powered-by:PHP/7.1.14 cache-control:max-age=600, public, s-maxage=600 date:Fri, 12 Jul 2019 05:35:34 GMT last-modified:Fri, 12 Jul 2019 05:35:34 GMT expires:Fri, 12 Jul 2019 05:45:34 GMT content-encoding:gzip ali-swift-global-savetime:1562909734 via:cache14.l2cm12[666,200-0,M], cache11.l2cm12[667,0], cache6.cn538[779,200-0,M], cache6.cn538[781,0] x-alicdn-da-ups-status:endInner,0,200 x-cache:MISS TCP_REFRESH_MISS dirn:5:5134155 x-swift-savetime:Fri, 12 Jul 2019 05:35:34 GMT x-swift-cachetime:180 timing-allow-origin:* eagleid:2be0b8ce15629097341003476e  ,0, 6
[3:3:0711/223534.960402:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/223534.964470:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223534.969324:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0711/223535.026942:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223535.214898:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe0304d31220
[1:1:0711/223535.215207:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/223535.275085:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.liansuo.com/
[1:1:0711/223535.523364:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26671:26671:0711/223535.561268:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.liansuo.com/, https://www.liansuo.com/, 1
[26671:26671:0711/223535.561373:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.liansuo.com/, https://www.liansuo.com
[1:1:0711/223535.662254:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223535.709868:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223535.796220:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223535.796482:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223536.045808:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223536.306477:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223536.518500:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223536.649971:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223536.890335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223536.897232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7efccbd3e070 0xe0304fd75e0 , "https://www.liansuo.com/"
[1:1:0711/223536.906274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , /*! 版权所有，翻版必究 */
/******/ (function(modules) { // webpackBootstrap
/******/ 	// in
[1:1:0711/223536.906541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223536.959929:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223537.017510:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223537.822405:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7efccc0a6bd0 0xe0304e25e58 , "https://www.liansuo.com/"
[1:1:0711/223537.861039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , /*! 版权所有，翻版必究 */
webpackJsonp([2],{

/***/ 0:
/***/ (function(module, exports, __w
[1:1:0711/223537.861350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223537.868997:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_a1874930 -> 0
[1:1:0711/223538.242775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7efccc0a6bd0 0xe0304e25e58 , "https://www.liansuo.com/"
[1:1:0711/223538.913483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 291 0x7efccc0a6bd0 0xe0304fd50d8 , "https://www.liansuo.com/"
[1:1:0711/223538.966567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , /*! 版权所有，翻版必究 */
webpackJsonp([0],[
/* 0 */,
/* 1 */
/***/ (function(module, expor
[1:1:0711/223538.966787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223540.253336:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223540.786176:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223540.786381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223541.004715:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.218179, 2104, 1
[1:1:0711/223541.004911:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223541.178079:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223541.180925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223541.181253:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223541.181587:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223541.182043:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223541.659538:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223541.659765:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223541.660335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7efccbd3e070 0xe03051a9de0 , "https://www.liansuo.com/"
[1:1:0711/223541.661028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , 
        var msgPath = "/gb/msg";
    
[1:1:0711/223541.661181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223541.662021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389 0x7efccbd3e070 0xe03051a9de0 , "https://www.liansuo.com/"
[1:1:0711/223541.672961:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0131512, 100, 1
[1:1:0711/223541.673134:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223542.715462:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223542.715730:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223542.716231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7efccbd3e070 0xe03053b8e60 , "https://www.liansuo.com/"
[1:1:0711/223542.716836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (function() {var _53code = document.createElement("script");_53code.src = "https://tb.53kf.com/code/
[1:1:0711/223542.716952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223542.729936:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0141261, 199, 1
[1:1:0711/223542.730089:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223543.952955:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223543.953221:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223543.954229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 506 0x7efccbd3e070 0xe0304e253e0 , "https://www.liansuo.com/"
[1:1:0711/223543.955494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , 
        var windowHeight = $(window).height();
        var $celPf = $(".celebrate-pf-b");
        $
[1:1:0711/223543.955720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[26671:26671:0711/223547.820708:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[26671:26671:0711/223547.821484:WARNING:one_google_bar_fetcher_impl.cc(315)] Request failed with error: -102: net::ERR_CONNECTION_REFUSED
[3:3:0711/223547.836108:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/223551.030762:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 7.07748, 0, 0
[1:1:0711/223551.031068:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223551.762868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/223551.763161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223552.269085:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223552.269364:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.liansuo.com/"
[1:1:0711/223552.270521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7efccbd3e070 0xe03051c8060 , "https://www.liansuo.com/"
[1:1:0711/223552.272079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , 
    /*推送代码*/
    (function(){
        var bp = document.createElement('script');
        va
[1:1:0711/223552.272302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223552.303724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.liansuo.com/"
[1:1:0711/223556.593404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f2868ca29c8, 0xe0304bb9c40
[1:1:0711/223556.593695:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 0
[1:1:0711/223556.594069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 605
[1:1:0711/223556.594266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7efccbd3e070 0xe0306652de0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223556.743246:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223556.743803:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223559.850976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3f2868ca29c8, 0xe0304bb9c40
[1:1:0711/223559.851147:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3000
[1:1:0711/223559.851316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 615
[1:1:0711/223559.851422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7efccbd3e070 0xe03072f7d60 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223600.047335:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3f2868ca29c8, 0xe0304bb9c40
[1:1:0711/223600.047510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3000
[1:1:0711/223600.047687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 616
[1:1:0711/223600.047797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7efccbd3e070 0xe03072e97e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223602.142869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 2500
[1:1:0711/223602.143126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 618
[1:1:0711/223602.143264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7efccbd3e070 0xe03071be060 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223602.177341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3500
[1:1:0711/223602.177608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 619
[1:1:0711/223602.177719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7efccbd3e070 0xe03062dc6e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223602.885463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3500
[1:1:0711/223602.885738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 620
[1:1:0711/223602.885855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7efccbd3e070 0xe03050adc60 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[1:1:0711/223604.914315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 13
[1:1:0711/223604.914612:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 621
[1:1:0711/223604.914727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7efccbd3e070 0xe0305239060 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 564 0x7efccbd3e070 0xe03051c8060 
[26671:26671:0711/223609.789341:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223610.367601:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.liansuo.com/"
[1:1:0711/223611.611592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , document.readyState
[1:1:0711/223611.611939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223622.436053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223622.436769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , onReady, () {
				if (typeof _this === 'undefined' || _this === null) return;
				if (_this.imagesLoaded !== 
[1:1:0711/223622.436945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223622.478657:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223622.479324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , onReady, () {
				if (typeof _this === 'undefined' || _this === null) return;
				if (_this.imagesLoaded !== 
[1:1:0711/223622.479498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223622.521378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223622.522022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , onReady, () {
				if (typeof _this === 'undefined' || _this === null) return;
				if (_this.imagesLoaded !== 
[1:1:0711/223622.522193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223622.605149:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223622.605839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , onReady, () {
				if (typeof _this === 'undefined' || _this === null) return;
				if (_this.imagesLoaded !== 
[1:1:0711/223622.606012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223623.676826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 605, 7efcce683881
[1:1:0711/223623.720472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.720806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.721161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223623.721697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , () {
		fxNow = undefined;
	}
[1:1:0711/223623.721873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223623.767681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 615, 7efcce683881
[1:1:0711/223623.811476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.811902:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.812339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223623.813022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , () {
            if (params.loop) {
                _this.fixLoop();
                _this.swipeNext
[1:1:0711/223623.813245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223623.896044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 616, 7efcce683881
[1:1:0711/223623.943762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.944070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223623.944422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223623.944981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , () {
            if (params.loop) {
                _this.fixLoop();
                _this.swipeNext
[1:1:0711/223623.945160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223624.008164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 618, 7efcce6838db
[1:1:0711/223624.057773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.058093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.058477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1013
[1:1:0711/223624.058690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7efccbd3e070 0xe03050ae760 , 6:3_https://www.liansuo.com/, 0, , 618 0x7efccbd3e070 0xe03071be060 
[1:1:0711/223624.059067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223624.059556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223624.059785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223624.198973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f2868ca29c8, 0xe0304bb9950
[1:1:0711/223624.199194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 0
[1:1:0711/223624.199526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1014
[1:1:0711/223624.199773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7efccbd3e070 0xe03070a77e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 618 0x7efccbd3e070 0xe03071be060 
[1:1:0711/223624.477373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 621, 7efcce6838db
[1:1:0711/223624.524989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.525292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.525674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1017
[1:1:0711/223624.525887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7efccbd3e070 0xe0308da3760 , 6:3_https://www.liansuo.com/, 0, , 621 0x7efccbd3e070 0xe0305239060 
[1:1:0711/223624.526250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223624.526759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , jQuery.fx.tick, () {
	var timer,
		timers = jQuery.timers,
		i = 0;

	fxNow = jQuery.now();

	for ( ; i < timers.len
[1:1:0711/223624.526954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223624.595960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 619, 7efcce6838db
[1:1:0711/223624.614324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.614522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.614745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1021
[1:1:0711/223624.614891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7efccbd3e070 0xe03046ddde0 , 6:3_https://www.liansuo.com/, 0, , 619 0x7efccbd3e070 0xe03062dc6e0 
[1:1:0711/223624.615088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223624.615371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223624.615481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223624.617900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 620, 7efcce6838db
[1:1:0711/223624.632236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.633113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"564 0x7efccbd3e070 0xe03051c8060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223624.633484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1022
[1:1:0711/223624.633669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7efccbd3e070 0xe03052fc8e0 , 6:3_https://www.liansuo.com/, 0, , 620 0x7efccbd3e070 0xe03050adc60 
[1:1:0711/223624.634004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223624.634466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223624.634635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223624.771272:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f2868ca29c8, 0xe0304bb9950
[1:1:0711/223624.771494:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 0
[1:1:0711/223624.771827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1023
[1:1:0711/223624.772171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7efccbd3e070 0xe0306e908e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 620 0x7efccbd3e070 0xe03050adc60 
[1:1:0711/223625.264358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , document.readyState
[1:1:0711/223625.264598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223627.902284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7efccdc662e0 0xe0307413de0 , "https://www.liansuo.com/"
[1:1:0711/223627.903472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0711/223627.903647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223627.956114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 942 0x7efccdc662e0 0xe03090e66e0 , "https://www.liansuo.com/"
[1:1:0711/223627.965779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (function(){var h={},mt={},c={id:"ad22dedacd4e37a27cc051a88ff821b7",dm:["liansuo.com"],js:"tongji.ba
[1:1:0711/223627.965984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223628.007944:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3f2868ca29c8, 0xe0304bb9948
[1:1:0711/223628.008162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 100
[1:1:0711/223628.008489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1055
[1:1:0711/223628.008678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1055 0x7efccbd3e070 0xe03090d6f60 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 942 0x7efccdc662e0 0xe03090e66e0 
[1:1:0711/223628.328281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7efccdc662e0 0xe03090e87e0 , "https://www.liansuo.com/"
[1:1:0711/223628.332358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , var acc_host='accwww7.53kf.com';var companyid='72200298';var hz6d_guest_ip='218.241.135.34';var ipst
[1:1:0711/223628.332492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
		remove user.10_fe3a1e7f -> 0
		remove user.11_e3203196 -> 0
		remove user.12_37027a0c -> 0
		remove user.13_670cf80c -> 0
		remove user.14_9322af88 -> 0
		remove user.11_387af151 -> 0
		remove user.12_419fd1f2 -> 0
[1:1:0711/223628.451573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 20000
[1:1:0711/223628.451977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1101
[1:1:0711/223628.452165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7efccbd3e070 0xe0306b18fe0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 945 0x7efccdc662e0 0xe03090e87e0 
[1:1:0711/223628.492214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3f2868ca29c8, 0xe0304bb9948
[1:1:0711/223628.492364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 200
[1:1:0711/223628.492541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1107
[1:1:0711/223628.492661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7efccbd3e070 0xe0305195be0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 945 0x7efccdc662e0 0xe03090e87e0 
[1:1:0711/223628.643029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223628.643709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223628.643935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223628.775572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223628.776021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223628.776132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.011982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.012691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.012869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.172811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.173564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.173743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.304416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.304982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.305153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.407241:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.407666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.407785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.481892:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.482494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.482683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.602273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.603138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.603384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223629.884100:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223629.884824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223629.885007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223630.050854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223630.051568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223630.051749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223630.211675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223630.212104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223630.212213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223630.349983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223630.350685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223630.350881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223630.597239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223630.597944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223630.598125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223630.818605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223630.819283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223630.819463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223631.045115:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223631.045814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223631.045994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223631.223909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.liansuo.com/"
[1:1:0711/223631.224812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223631.225047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223631.398028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.liansuo.com/"
[1:1:0711/223631.398491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , elemData.handle, ( e ) {

				// Discard the second event of a jQuery.event.trigger() and
				// when an event is cal
[1:1:0711/223631.398603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223632.752982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.liansuo.com/"
[1:1:0711/223632.778596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3f2868ca29c8, 0xe0304bb99f0
[1:1:0711/223632.778836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3000
[1:1:0711/223632.779218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1181
[1:1:0711/223632.779459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7efccbd3e070 0xe0305ac0ee0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 1006 0x7efcdb04f960 0xe030516dce0 0xe030516dcf0 
[1:1:0711/223632.780229:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.liansuo.com/"
[1:1:0711/223632.828164:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3f2868ca29c8, 0xe0304bb99f0
[1:1:0711/223632.828316:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 3000
[1:1:0711/223632.828490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1186
[1:1:0711/223632.828597:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7efccbd3e070 0xe03059fe5e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 1006 0x7efcdb04f960 0xe030516dce0 0xe030516dcf0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223633.277734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1014, 7efcce683881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223633.326236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"618 0x7efccbd3e070 0xe03071be060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.326526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"618 0x7efccbd3e070 0xe03071be060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.326918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223633.327529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , () {
		fxNow = undefined;
	}
[1:1:0711/223633.327793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223633.330045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1017, 7efcce6838db
[1:1:0711/223633.381231:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"621 0x7efccbd3e070 0xe0305239060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.381496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"621 0x7efccbd3e070 0xe0305239060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.381888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1197
[1:1:0711/223633.382075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1197 0x7efccbd3e070 0xe0305ac0560 , 6:3_https://www.liansuo.com/, 0, , 1017 0x7efccbd3e070 0xe0308da3760 
[1:1:0711/223633.382364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223633.382695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , jQuery.fx.tick, () {
	var timer,
		timers = jQuery.timers,
		i = 0;

	fxNow = jQuery.now();

	for ( ; i < timers.len
[1:1:0711/223633.382907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223633.417784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1013, 7efcce6838db
[1:1:0711/223633.465480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7efccbd3e070 0xe03071be060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.465748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7efccbd3e070 0xe03071be060 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.466135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1203
[1:1:0711/223633.466360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1203 0x7efccbd3e070 0xe03074123e0 , 6:3_https://www.liansuo.com/, 0, , 1013 0x7efccbd3e070 0xe03050ae760 
[1:1:0711/223633.466723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223633.467219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223633.467432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[26671:26671:0711/223633.574910:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223633.601905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f2868ca29c8, 0xe0304bb9950
[1:1:0711/223633.602121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 0
[1:1:0711/223633.602471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1208
[1:1:0711/223633.602663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1208 0x7efccbd3e070 0xe0305a3aa60 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 1013 0x7efccbd3e070 0xe03050ae760 
[1:1:0711/223633.777191:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 13
[1:1:0711/223633.777600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1209
[1:1:0711/223633.777792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7efccbd3e070 0xe0306b597e0 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 1013 0x7efccbd3e070 0xe03050ae760 
[1:1:0711/223633.874841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1023, 7efcce683881
[1:1:0711/223633.926120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ac40bf62860","ptid":"620 0x7efccbd3e070 0xe03050adc60 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.926448:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.liansuo.com/","ptid":"620 0x7efccbd3e070 0xe03050adc60 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223633.926803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223633.927296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , () {
		fxNow = undefined;
	}
[1:1:0711/223633.927495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223634.261273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , document.readyState
[1:1:0711/223634.261546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223634.599116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1021, 7efcce6838db
[1:1:0711/223634.650800:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"619 0x7efccbd3e070 0xe03062dc6e0 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223634.651065:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"619 0x7efccbd3e070 0xe03062dc6e0 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223634.651489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1225
[1:1:0711/223634.651739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1225 0x7efccbd3e070 0xe030896e960 , 6:3_https://www.liansuo.com/, 0, , 1021 0x7efccbd3e070 0xe03046ddde0 
[1:1:0711/223634.652070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223634.652542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223634.652731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223634.818391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1022, 7efcce6838db
[1:1:0711/223634.870206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"620 0x7efccbd3e070 0xe03050adc60 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223634.870471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"620 0x7efccbd3e070 0xe03050adc60 ","rf":"6:3_https://www.liansuo.com/"}
[1:1:0711/223634.870870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.liansuo.com/, 1230
[1:1:0711/223634.871062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7efccbd3e070 0xe0305a1a660 , 6:3_https://www.liansuo.com/, 0, , 1022 0x7efccbd3e070 0xe03052fc8e0 
[1:1:0711/223634.871386:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.liansuo.com/"
[1:1:0711/223634.871952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.liansuo.com/, 0ac40bf62860, , , (){w?p--:p++,ab()}
[1:1:0711/223634.872170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.liansuo.com/", "www.liansuo.com", 3, 1, , , 0
[1:1:0711/223634.895929:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223634.898397:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223634.898776:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223635.012986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3f2868ca29c8, 0xe0304bb9950
[1:1:0711/223635.013202:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.liansuo.com/", 0
[1:1:0711/223635.013533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.liansuo.com/, 1231
[1:1:0711/223635.013746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1231 0x7efccbd3e070 0xe0305952360 , 6:3_https://www.liansuo.com/, 1, -6:3_https://www.liansuo.com/, 1022 0x7efccbd3e070 0xe03052fc8e0 
