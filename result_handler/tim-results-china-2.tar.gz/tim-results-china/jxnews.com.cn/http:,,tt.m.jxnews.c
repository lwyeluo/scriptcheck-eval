[0712/041945.633913:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041945.634452:INFO:switcher_clone.cc(787)] backtrace rip is 7f80a6c1b891
[0712/041946.637662:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041946.638088:INFO:switcher_clone.cc(787)] backtrace rip is 7f21f8f17891
[1:1:0712/041946.649955:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/041946.650211:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/041946.655628:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[73476:73476:0712/041948.000039:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/a4a92658-fb4f-49ac-8880-190e3bd63290
[0712/041948.158107:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041948.158419:INFO:switcher_clone.cc(787)] backtrace rip is 7f29cf1c0891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[73507:73507:0712/041948.410155:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=73507
[73519:73519:0712/041948.410610:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=73519
[73476:73476:0712/041948.466762:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[73476:73505:0712/041948.467499:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/041948.467792:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/041948.468122:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/041948.468784:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/041948.469012:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/041948.472043:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11942e3f, 1
[1:1:0712/041948.472405:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2486fed0, 0
[1:1:0712/041948.472600:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3507828b, 3
[1:1:0712/041948.472807:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x309ea30a, 2
[1:1:0712/041948.473061:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd0fffffffeffffff8624 3f2effffff9411 0affffffa3ffffff9e30 ffffff8bffffff820735 , 10104, 4
[1:1:0712/041948.474078:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[73476:73505:0712/041948.474344:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���$?.�
��0��5C�G8
[73476:73505:0712/041948.474429:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���$?.�
��0��5X�C�G8
[1:1:0712/041948.474334:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21f71520a0, 3
[1:1:0712/041948.474584:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21f72dd080, 2
[73476:73505:0712/041948.474772:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/041948.474776:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21e0fa0d20, -2
[73476:73505:0712/041948.474852:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 73527, 4, d0fe8624 3f2e9411 0aa39e30 8b820735 
[1:1:0712/041948.488066:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/041948.489179:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 309ea30a
[1:1:0712/041948.490215:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 309ea30a
[1:1:0712/041948.491778:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 309ea30a
[1:1:0712/041948.493284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.493570:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.493802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.494097:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.494797:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 309ea30a
[1:1:0712/041948.495174:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21f8f177ba
[1:1:0712/041948.495350:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f21f8f0edef, 7f21f8f1777a, 7f21f8f190cf
[1:1:0712/041948.501109:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 309ea30a
[1:1:0712/041948.501504:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 309ea30a
[1:1:0712/041948.502289:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 309ea30a
[1:1:0712/041948.504704:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.504989:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.505223:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.505452:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 309ea30a
[1:1:0712/041948.506727:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 309ea30a
[1:1:0712/041948.507118:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21f8f177ba
[1:1:0712/041948.507277:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f21f8f0edef, 7f21f8f1777a, 7f21f8f190cf
[1:1:0712/041948.516913:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/041948.517456:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/041948.517632:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcf51b5208, 0x7ffcf51b5188)
[1:1:0712/041948.534677:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/041948.540897:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[73476:73476:0712/041949.063592:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73476:73476:0712/041949.064780:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73476:73486:0712/041949.089146:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[73476:73486:0712/041949.089244:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[73476:73476:0712/041949.089359:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[73476:73476:0712/041949.089441:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[73476:73476:0712/041949.089586:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,73527, 4
[1:7:0712/041949.093240:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[73476:73497:0712/041949.127332:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/041949.207130:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1d6abaaf0220
[1:1:0712/041949.207553:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/041949.604097:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[73476:73476:0712/041951.271766:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[73476:73476:0712/041951.271884:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/041951.312601:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041951.316641:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/041952.245755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/041952.246151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041952.262943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/041952.263235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041952.345004:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041952.642591:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041952.642890:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041953.073214:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041953.083162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/041953.083508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041953.118184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041953.128823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/041953.129122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041953.141655:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[73476:73476:0712/041953.143540:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/041953.145190:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1d6abaaeee20
[1:1:0712/041953.145476:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[73476:73476:0712/041953.153817:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[73476:73476:0712/041953.171702:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[73476:73476:0712/041953.171837:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/041953.189698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041954.152196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f21e2b7b2e0 0x1d6abad8a4e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041954.153625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/041954.153879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041954.155378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[73476:73476:0712/041954.225048:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/041954.227241:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1d6abaaef820
[1:1:0712/041954.227524:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[73476:73476:0712/041954.233032:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/041954.247063:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/041954.247337:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[73476:73476:0712/041954.248878:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[73476:73476:0712/041954.258008:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73476:73476:0712/041954.259037:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73476:73486:0712/041954.266031:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[73476:73486:0712/041954.266141:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[73476:73476:0712/041954.266398:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[73476:73476:0712/041954.266500:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[73476:73476:0712/041954.266681:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,73527, 4
[1:7:0712/041954.272326:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/041954.884749:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/041955.405400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f21e2b7b2e0 0x1d6abad99de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041955.406822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/041955.407152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041955.408385:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[73476:73476:0712/041955.572590:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[73476:73476:0712/041955.572776:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/041955.602596:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/041956.024618:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[73476:73476:0712/041956.228981:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[73476:73505:0712/041956.229452:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/041956.229641:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/041956.229885:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/041956.230337:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/041956.230501:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/041956.234064:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2762c3ca, 1
[1:1:0712/041956.234441:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x28548bf6, 0
[1:1:0712/041956.234629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x13a66e0a, 3
[1:1:0712/041956.234835:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x273e25e3, 2
[1:1:0712/041956.235014:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff6ffffff8b5428 ffffffcaffffffc36227 ffffffe3253e27 0a6effffffa613 , 10104, 5
[1:1:0712/041956.236129:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[73476:73505:0712/041956.236461:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��T(��b'�%>'
n���G8
[73476:73505:0712/041956.236542:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��T(��b'�%>'
n��M��G8
[1:1:0712/041956.236454:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21f71520a0, 3
[73476:73505:0712/041956.236864:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 73573, 5, f68b5428 cac36227 e3253e27 0a6ea613 
[1:1:0712/041956.236781:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21f72dd080, 2
[1:1:0712/041956.237025:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21e0fa0d20, -2
[1:1:0712/041956.260320:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/041956.260708:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 273e25e3
[1:1:0712/041956.261063:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 273e25e3
[1:1:0712/041956.261765:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 273e25e3
[1:1:0712/041956.263202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.263461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.263734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.263971:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.264839:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 273e25e3
[1:1:0712/041956.265225:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21f8f177ba
[1:1:0712/041956.265418:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f21f8f0edef, 7f21f8f1777a, 7f21f8f190cf
[1:1:0712/041956.271522:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 273e25e3
[1:1:0712/041956.271975:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 273e25e3
[1:1:0712/041956.272838:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 273e25e3
[1:1:0712/041956.275444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.276012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.276277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.276528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 273e25e3
[1:1:0712/041956.277994:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 273e25e3
[1:1:0712/041956.278442:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21f8f177ba
[1:1:0712/041956.278632:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f21f8f0edef, 7f21f8f1777a, 7f21f8f190cf
[1:1:0712/041956.286719:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/041956.287282:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/041956.287472:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcf51b5208, 0x7ffcf51b5188)
[1:1:0712/041956.301061:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/041956.306438:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/041956.426819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 535 0x7f21e2b7b2e0 0x1d6abb048be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041956.427939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2335fa441f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":2};
[1:1:0712/041956.428221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041956.428919:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041956.526638:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1d6abaac9220
[1:1:0712/041956.526933:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/041956.560413:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041956.560692:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[73476:73476:0712/041956.881271:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73476:73476:0712/041956.884629:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73476:73486:0712/041956.899769:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[73476:73476:0712/041956.899899:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tt.m.jxnews.com.cn/
[73476:73476:0712/041956.899965:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://tt.m.jxnews.com.cn/, http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN, 1
[73476:73486:0712/041956.899888:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[73476:73476:0712/041956.900029:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://tt.m.jxnews.com.cn/, HTTP/1.1 200 OK Server: nginx/1.12.2 Date: Fri, 12 Jul 2019 11:19:56 GMT Content-Type: text/html; charset=utf-8 Content-Length: 19288 Connection: keep-alive X-Powered-By: Express ETag: W/"4b58-NF7l3/0dtS3t7lRJrgGTI1lb5ys"  ,73573, 5
[1:7:0712/041956.903868:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/041956.938178:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://tt.m.jxnews.com.cn/
[1:1:0712/041957.040315:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[73476:73476:0712/041957.050840:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://tt.m.jxnews.com.cn/, http://tt.m.jxnews.com.cn/, 1
[73476:73476:0712/041957.050990:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://tt.m.jxnews.com.cn/, http://tt.m.jxnews.com.cn
[1:1:0712/041957.133588:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041957.170511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/041957.175310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2335fa56e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/041957.175726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/041957.183639:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/041957.262412:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041957.262686:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041957.476828:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/041958.009628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f21e0fbbbd0 0x1d6aba82bb58 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.019839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , /*! jQuery v2.1.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/041958.020105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041958.048517:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.316314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f21e0fbbbd0 0x1d6aba82bb58 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.334138:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.334624:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.334989:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.335412:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.335833:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041958.462393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f21e0fbbbd0 0x1d6aba82bb58 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.501403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f21e0fbbbd0 0x1d6aba82bb58 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.504386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f21e0fbbbd0 0x1d6aba82bb58 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.545993:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.2338, 504, 1
[1:1:0712/041958.546169:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041958.838417:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041958.838652:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.839784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f21e0c53070 0x1d6abad7bae0 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041958.842807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , setTimeout(function() {
    $("#news_content img").each(function () {
            var src = $(this).
[1:1:0712/041958.843082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041958.843916:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x37988ace29c8, 0x1d6aba8999c0
[1:1:0712/041958.844080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", 500
[1:1:0712/041958.844492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tt.m.jxnews.com.cn/, 217
[1:1:0712/041958.844691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 217 0x7f21e0c53070 0x1d6abace24e0 , 5:3_http://tt.m.jxnews.com.cn/, 1, -5:3_http://tt.m.jxnews.com.cn/, 204 0x7f21e0c53070 0x1d6abad7bae0 
[1:1:0712/041958.850578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f21e0c53070 0x1d6abad7bae0 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041959.211844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233, "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041959.216253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , (function(){function p(){this.c="1262849163";this.ca="q";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/041959.216487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041959.293001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233, "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041959.345423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233, "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/041959.357452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.144493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.145161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , (){b&&(delete Dc[g],b=f.onload=f.onerror=null,"abort"===a?f.abort():"error"===a?d(f.status,f.statusT
[1:1:0712/042000.145289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042000.173805:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.174449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , (){b&&(delete Dc[g],b=f.onload=f.onerror=null,"abort"===a?f.abort():"error"===a?d(f.status,f.statusT
[1:1:0712/042000.174637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042000.274740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://tt.m.jxnews.com.cn/, 217, 7f21e3598881
[1:1:0712/042000.287324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"17737c542860","ptid":"204 0x7f21e0c53070 0x1d6abad7bae0 ","rf":"5:3_http://tt.m.jxnews.com.cn/"}
[1:1:0712/042000.287626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://tt.m.jxnews.com.cn/","ptid":"204 0x7f21e0c53070 0x1d6abad7bae0 ","rf":"5:3_http://tt.m.jxnews.com.cn/"}
[1:1:0712/042000.287933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.288512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , () {
    $("#news_content img").each(function () {
            var src = $(this).attr('src');
      
[1:1:0712/042000.288680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042000.403761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7f21e2b7b2e0 0x1d6abb01b360 , "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.406193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/042000.406438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042000.482138:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.483148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042000.483409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042000.752490:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN"
[1:1:0712/042000.753091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , r.handle, (b){return typeof n!==U&&n.event.triggered!==b.type?n.event.dispatch.apply(a,arguments):void 0}
[1:1:0712/042000.753337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042014.702092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://tt.m.jxnews.com.cn/, 17737c542860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/042014.702530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN", "tt.m.jxnews.com.cn", 3, 1, , , 0
[73476:73476:0712/042015.154353:INFO:CONSOLE(185)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://w.cnzz.com/c.php?id=1262849163, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN (185)
[73476:73476:0712/042015.159351:INFO:CONSOLE(185)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://w.cnzz.com/c.php?id=1262849163, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://tt.m.jxnews.com.cn/recom/771629?app=JXTTN (185)
[73476:73476:0712/042015.350637:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/042015.359865:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
