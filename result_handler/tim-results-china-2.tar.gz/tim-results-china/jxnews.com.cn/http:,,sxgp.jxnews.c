[0712/041545.208076:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041545.208577:INFO:switcher_clone.cc(787)] backtrace rip is 7f20dc571891
[0712/041546.160341:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041546.160837:INFO:switcher_clone.cc(787)] backtrace rip is 7f27b7b46891
[1:1:0712/041546.169583:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/041546.169908:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/041546.182833:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[72846:72846:0712/041547.654980:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1f9cffa2-2380-4eb5-9107-ba35681e18bc
[0712/041547.912539:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/041547.912853:INFO:switcher_clone.cc(787)] backtrace rip is 7fbe4833e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[72878:72878:0712/041548.178757:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=72878
[72891:72891:0712/041548.179253:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=72891
[72846:72846:0712/041548.288916:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[72846:72876:0712/041548.289864:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/041548.290154:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/041548.290384:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/041548.291148:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/041548.291308:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/041548.294311:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26716afc, 1
[1:1:0712/041548.294649:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x24f18b3, 0
[1:1:0712/041548.294841:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3920973, 3
[1:1:0712/041548.295063:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x27e0b925, 2
[1:1:0712/041548.295329:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb3184f02 fffffffc6a7126 25ffffffb9ffffffe027 7309ffffff9203 , 10104, 4
[1:1:0712/041548.296576:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[72846:72876:0712/041548.296929:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�O�jq&%��'s	�˝�?
[72846:72876:0712/041548.297070:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �O�jq&%��'s	��@˝�?
[1:1:0712/041548.296908:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f27b5d810a0, 3
[72846:72876:0712/041548.297440:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/041548.297252:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f27b5f0c080, 2
[72846:72876:0712/041548.297519:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 72899, 4, b3184f02 fc6a7126 25b9e027 73099203 
[1:1:0712/041548.297581:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f279fbcfd20, -2
[1:1:0712/041548.317090:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/041548.318029:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27e0b925
[1:1:0712/041548.319179:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27e0b925
[1:1:0712/041548.320612:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27e0b925
[1:1:0712/041548.322213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.322463:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.322683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.322914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.323581:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27e0b925
[1:1:0712/041548.324014:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f27b7b467ba
[1:1:0712/041548.324195:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f27b7b3ddef, 7f27b7b4677a, 7f27b7b480cf
[1:1:0712/041548.330597:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27e0b925
[1:1:0712/041548.331007:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27e0b925
[1:1:0712/041548.331753:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27e0b925
[1:1:0712/041548.333764:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.334071:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.334357:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.334599:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27e0b925
[1:1:0712/041548.336104:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27e0b925
[1:1:0712/041548.336542:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f27b7b467ba
[1:1:0712/041548.336732:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f27b7b3ddef, 7f27b7b4677a, 7f27b7b480cf
[1:1:0712/041548.345589:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/041548.346120:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/041548.346304:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc717aa458, 0x7ffc717aa3d8)
[1:1:0712/041548.366369:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/041548.373911:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[72846:72846:0712/041548.984409:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[72846:72846:0712/041548.985540:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[72846:72858:0712/041549.004577:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[72846:72858:0712/041549.004675:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[72846:72846:0712/041549.004715:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[72846:72846:0712/041549.004776:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[72846:72846:0712/041549.004876:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,72899, 4
[1:7:0712/041549.006527:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[72846:72869:0712/041549.031723:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/041549.091322:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2e1170edb220
[1:1:0712/041549.091669:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/041549.561814:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/041551.425608:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041551.429550:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[72846:72846:0712/041551.442057:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[72846:72846:0712/041551.442122:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/041552.419353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041552.555940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/041552.556302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041552.572614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/041552.572904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041552.689730:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041552.689980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041553.058337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041553.066034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/041553.066268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041553.086440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041553.089616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/041553.089749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041553.093686:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/041553.097772:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e1170ed9e20
[1:1:0712/041553.097968:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[72846:72846:0712/041553.099048:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[72846:72846:0712/041553.114216:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[72846:72846:0712/041553.154020:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[72846:72846:0712/041553.154119:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/041553.202714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041553.980179:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f27a17aa2e0 0x2e1170f9cbe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041553.980990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/041553.981124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041553.981782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[72846:72846:0712/041554.055789:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/041554.056367:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2e1170eda820
[1:1:0712/041554.056598:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[72846:72846:0712/041554.070164:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/041554.075151:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/041554.075321:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[72846:72846:0712/041554.098140:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[72846:72846:0712/041554.118448:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[72846:72846:0712/041554.119727:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[72846:72858:0712/041554.127266:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[72846:72858:0712/041554.127391:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[72846:72846:0712/041554.133296:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[72846:72846:0712/041554.133444:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[72846:72846:0712/041554.133643:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,72899, 4
[1:7:0712/041554.140656:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/041554.568820:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/041554.923041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f27a17aa2e0 0x2e117105ece0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/041554.924097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1824a3a81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/041554.924337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/041554.925079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[72846:72846:0712/041555.110822:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[72846:72846:0712/041555.110943:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/041555.143207:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[72846:72846:0712/041555.503490:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[72846:72876:0712/041555.503928:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/041555.504159:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/041555.504421:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/041555.504865:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/041555.505030:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/041555.508244:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e6f03b6, 1
[1:1:0712/041555.508626:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf44fbb0, 0
[1:1:0712/041555.508864:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5018fbc, 3
[1:1:0712/041555.509072:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd69f00b, 2
[1:1:0712/041555.509259:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb0fffffffb440f ffffffb6036f2e 0bfffffff0690d ffffffbcffffff8f0105 , 10104, 5
[1:1:0712/041555.510274:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[72846:72876:0712/041555.510560:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��D�o.�i��ݟ�?
[72846:72876:0712/041555.510630:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��D�o.�i��x�ݟ�?
[1:1:0712/041555.510546:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f27b5d810a0, 3
[1:1:0712/041555.510835:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f27b5f0c080, 2
[72846:72876:0712/041555.510907:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 72945, 5, b0fb440f b6036f2e 0bf0690d bc8f0105 
[1:1:0712/041555.511018:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f279fbcfd20, -2
[1:1:0712/041555.527678:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/041555.528101:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d69f00b
[1:1:0712/041555.528407:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d69f00b
[1:1:0712/041555.529034:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d69f00b
[1:1:0712/041555.530746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.531012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.531263:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.531512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.532279:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d69f00b
[1:1:0712/041555.532567:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f27b7b467ba
[1:1:0712/041555.532714:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f27b7b3ddef, 7f27b7b4677a, 7f27b7b480cf
[1:1:0712/041555.536248:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d69f00b
[1:1:0712/041555.536433:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d69f00b
[1:1:0712/041555.536709:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d69f00b
[1:1:0712/041555.537407:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.537523:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.537625:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.537720:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d69f00b
[1:1:0712/041555.538202:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d69f00b
[1:1:0712/041555.538365:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f27b7b467ba
[1:1:0712/041555.538440:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f27b7b3ddef, 7f27b7b4677a, 7f27b7b480cf
[1:1:0712/041555.541330:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/041555.541902:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/041555.542008:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc717aa458, 0x7ffc717aa3d8)
[1:1:0712/041555.549297:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/041555.555036:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/041555.567371:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041555.749457:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2e1170eb6220
[1:1:0712/041555.749626:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/041556.287169:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041556.287442:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[72846:72846:0712/041556.365648:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[72846:72846:0712/041556.371431:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[72846:72858:0712/041556.402786:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[72846:72858:0712/041556.402886:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[72846:72846:0712/041556.403415:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://sxgp.jxnews.com.cn/
[72846:72846:0712/041556.403513:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sxgp.jxnews.com.cn/, http://sxgp.jxnews.com.cn/, 1
[72846:72846:0712/041556.403676:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://sxgp.jxnews.com.cn/, HTTP/1.1 200 OK Server: nginx/1.4.1 Date: Fri, 12 Jul 2019 11:15:07 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Set-Cookie: insert_cookie=81361354; path=/  ,72945, 5
[1:7:0712/041556.407860:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/041556.443319:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://sxgp.jxnews.com.cn/
[72846:72846:0712/041556.562484:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sxgp.jxnews.com.cn/, http://sxgp.jxnews.com.cn/, 1
[72846:72846:0712/041556.562605:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://sxgp.jxnews.com.cn/, http://sxgp.jxnews.com.cn
[1:1:0712/041556.589932:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/041556.648268:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041556.719038:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/041556.723620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1824a3bae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/041556.724072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/041556.733395:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/041556.739288:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041556.739576:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041557.269921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7f27b5f0c080 0x2e1171067ba0 1 0 0x2e1171067bb8 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041557.292787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , /*! jQuery v2.1.4 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/041557.292962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041557.302025:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/041557.563641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f27b5f0c080 0x2e11710672e0 1 0 0x2e11710672f8 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041557.571093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , /*
 *  jQuery OwlCarousel v1.3.3
 *
 *  Copyright (c) 2013 Bartosz Wojciechowski
 *  http://www.owlg
[1:1:0712/041557.571399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041557.582834:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f27b5f0c080 0x2e11710672e0 1 0 0x2e11710672f8 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041557.593579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177 0x7f27b5f0c080 0x2e11710672e0 1 0 0x2e11710672f8 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041557.671802:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.089921, 168, 1
[1:1:0712/041557.672123:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041558.142011:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041558.142285:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041558.145805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f279f882070 0x2e11710ae4e0 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041558.147180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , $(document).ready(function(){
//    nav-li hover e
    var num;
    $('.nav-main>li[id]').hover(f
[1:1:0712/041558.147434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041558.162900:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041558.163483:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041558.163901:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041558.164589:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041558.165057:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/041558.178873:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.036413, 204, 1
[1:1:0712/041558.179083:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041558.677396:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041558.677679:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041558.678626:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f279f882070 0x2e11713dd3e0 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041558.680103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , 
$(function(){
	$('.zzsc1 .content .nrk').width(600*$('.zzsc1 .content .nr').length+'px');
	$(".zzsc
[1:1:0712/041558.680342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041558.735759:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0579941, 231, 1
[1:1:0712/041558.736069:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041559.523822:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041559.524118:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041559.525159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f279f882070 0x2e11711a73e0 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041559.526530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , 
		var scrollPic_02 = new ScrollPic();
		scrollPic_02.scrollContId   = "scrollbox"; //内容容器ID
[1:1:0712/041559.526783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041559.600451:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.076153, 254, 1
[1:1:0712/041559.600655:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041600.621728:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041600.621945:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041600.622639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f279f882070 0x2e1171416be0 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041600.623396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , 
$(function(){
	$('.zzsc .content .nrk').width(600*$('.zzsc .content .nr').length+'px');
	$(".zzsc .
[1:1:0712/041600.623537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041600.665214:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.04319, 246, 1
[1:1:0712/041600.665403:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/041601.912726:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/041601.912902:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sxgp.jxnews.com.cn/"
[1:1:0712/041601.914805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7f279f882070 0x2e11713b88e0 , "http://sxgp.jxnews.com.cn/"
[1:1:0712/041601.915723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , var scrolltotop={
	setting:{
		startline:100, //璧峰琛�
		scrollto:0, //婊氬姩鍒版�
[1:1:0712/041601.915848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041601.920311:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://sxgp.jxnews.com.cn/"
[1:1:0712/041603.992575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 5000
[1:1:0712/041603.993098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 545
[1:1:0712/041603.993364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 545 0x7f279f882070 0x2e11716cce60 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 457 0x7f279f882070 0x2e11713b88e0 
[1:1:0712/041604.290850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 3000
[1:1:0712/041604.291366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 548
[1:1:0712/041604.291625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7f279f882070 0x2e11716dcfe0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 457 0x7f279f882070 0x2e11713b88e0 
[1:1:0712/041606.271143:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://sxgp.jxnews.com.cn/images/bg.jpg"
[1:1:0712/041607.894121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 548, 7f27a21c78db
[1:1:0712/041607.910667:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"457 0x7f279f882070 0x2e11713b88e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041607.911062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"457 0x7f279f882070 0x2e11713b88e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041607.911490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 637
[1:1:0712/041607.911779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f279f882070 0x2e11714c8ae0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 548 0x7f279f882070 0x2e11716dcfe0 
[1:1:0712/041607.912098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041607.912651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , autotab, (){
			number++;
			number == maxNumber? number = 0 : number;
			$('.zzsc .tab a:eq('+number+')').ad
[1:1:0712/041607.912871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041607.987074:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041607.987372:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 0
[1:1:0712/041607.987760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 638
[1:1:0712/041607.988136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f279f882070 0x2e1171683160 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 548 0x7f279f882070 0x2e11716dcfe0 
[1:1:0712/041608.047809:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 13
[1:1:0712/041608.048430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 641
[1:1:0712/041608.048695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f279f882070 0x2e11713cb560 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 548 0x7f279f882070 0x2e11716dcfe0 
[1:1:0712/041608.294351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 638, 7f27a21c7881
[1:1:0712/041608.328365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041608.328758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041608.329075:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041608.329622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , (){La=void 0}
[1:1:0712/041608.329838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041608.384763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 641, 7f27a21c78db
[1:1:0712/041608.412945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041608.413333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041608.413705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 656
[1:1:0712/041608.414019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f279f882070 0x2e117111e3e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 641 0x7f279f882070 0x2e11713cb560 
[1:1:0712/041608.414379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041608.414998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041608.415302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041609.073785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 545, 7f27a21c78db
[1:1:0712/041609.101995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"457 0x7f279f882070 0x2e11713b88e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041609.102425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"457 0x7f279f882070 0x2e11713b88e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041609.102798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 679
[1:1:0712/041609.103135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f279f882070 0x2e11716cb8e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 545 0x7f279f882070 0x2e11716cce60 
[1:1:0712/041609.103447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041609.104080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                base.next(true);
            }
[1:1:0712/041609.104304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041609.121181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041609.121457:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 800
[1:1:0712/041609.121843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 680
[1:1:0712/041609.122089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f279f882070 0x2e11710f6de0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 545 0x7f279f882070 0x2e11716cce60 
[1:1:0712/041609.149164:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 5000
[1:1:0712/041609.149746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 681
[1:1:0712/041609.149989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f279f882070 0x2e117189d5e0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 545 0x7f279f882070 0x2e11716cce60 
[1:1:0712/041609.943258:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 680, 7f27a21c7881
[1:1:0712/041609.976989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"545 0x7f279f882070 0x2e11716cce60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041609.977391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"545 0x7f279f882070 0x2e11716cce60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041609.977719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041609.978350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                        base.isCss3Finish = true;
                    }
[1:1:0712/041609.978574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.319773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 637, 7f27a21c78db
[1:1:0712/041610.350583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.350962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"548 0x7f279f882070 0x2e11716dcfe0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.351328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 711
[1:1:0712/041610.351629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f279f882070 0x2e117121e7e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 637 0x7f279f882070 0x2e11714c8ae0 
[1:1:0712/041610.351965:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.352547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , autotab, (){
			number++;
			number == maxNumber? number = 0 : number;
			$('.zzsc .tab a:eq('+number+')').ad
[1:1:0712/041610.352766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.428461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041610.428772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 0
[1:1:0712/041610.429231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 712
[1:1:0712/041610.429474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7f279f882070 0x2e11713734e0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 637 0x7f279f882070 0x2e11714c8ae0 
[1:1:0712/041610.461922:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 13
[1:1:0712/041610.462455:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 713
[1:1:0712/041610.462696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f279f882070 0x2e11716cbce0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 637 0x7f279f882070 0x2e11714c8ae0 
[1:1:0712/041610.473051:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 712, 7f27a21c7881
[1:1:0712/041610.501803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.502159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.502493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.503074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , (){La=void 0}
[1:1:0712/041610.503299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.504975:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 713, 7f27a21c78db
[1:1:0712/041610.535723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.536139:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.536559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 717
[1:1:0712/041610.536822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f279f882070 0x2e117136ac60 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 713 0x7f279f882070 0x2e11716cbce0 
[1:1:0712/041610.537181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.537753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.538009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.596970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 717, 7f27a21c78db
[1:1:0712/041610.632759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"713 0x7f279f882070 0x2e11716cbce0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.633211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"713 0x7f279f882070 0x2e11716cbce0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.633678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 720
[1:1:0712/041610.633945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7f279f882070 0x2e117189eee0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 717 0x7f279f882070 0x2e117136ac60 
[1:1:0712/041610.634297:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.634879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.635097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.684733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 720, 7f27a21c78db
[1:1:0712/041610.717301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"717 0x7f279f882070 0x2e117136ac60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.717666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"717 0x7f279f882070 0x2e117136ac60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.718029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 722
[1:1:0712/041610.718261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f279f882070 0x2e1170ac19e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 720 0x7f279f882070 0x2e117189eee0 
[1:1:0712/041610.718564:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.719118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.719343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.763744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 722, 7f27a21c78db
[1:1:0712/041610.786093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"720 0x7f279f882070 0x2e117189eee0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.786559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"720 0x7f279f882070 0x2e117189eee0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.786926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 725
[1:1:0712/041610.787166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f279f882070 0x2e1171371960 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 722 0x7f279f882070 0x2e1170ac19e0 
[1:1:0712/041610.787534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.788115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.788338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.791910:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 725, 7f27a21c78db
[1:1:0712/041610.808992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"722 0x7f279f882070 0x2e1170ac19e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.809313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"722 0x7f279f882070 0x2e1170ac19e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.809691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 727
[1:1:0712/041610.809927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f279f882070 0x2e117111c860 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 725 0x7f279f882070 0x2e1171371960 
[1:1:0712/041610.810260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.810834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.811052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041610.836807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 727, 7f27a21c78db
[1:1:0712/041610.870660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"725 0x7f279f882070 0x2e1171371960 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.871032:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"725 0x7f279f882070 0x2e1171371960 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041610.871400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 729
[1:1:0712/041610.871790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f279f882070 0x2e11716830e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 727 0x7f279f882070 0x2e117111c860 
[1:1:0712/041610.872140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041610.872779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041610.873013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.333885:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 711, 7f27a21c78db
[1:1:0712/041613.365676:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.366016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"637 0x7f279f882070 0x2e11714c8ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.366399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 731
[1:1:0712/041613.366651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f279f882070 0x2e11717bb7e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 711 0x7f279f882070 0x2e117121e7e0 
[1:1:0712/041613.366978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.367546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , autotab, (){
			number++;
			number == maxNumber? number = 0 : number;
			$('.zzsc .tab a:eq('+number+')').ad
[1:1:0712/041613.367811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.431513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041613.431776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 0
[1:1:0712/041613.432201:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 732
[1:1:0712/041613.432441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f279f882070 0x2e1170e88a60 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 711 0x7f279f882070 0x2e117121e7e0 
[1:1:0712/041613.457761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 13
[1:1:0712/041613.458266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 733
[1:1:0712/041613.458507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f279f882070 0x2e117189f060 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 711 0x7f279f882070 0x2e117121e7e0 
[1:1:0712/041613.474353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 732, 7f27a21c7881
[1:1:0712/041613.486616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.486955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.487287:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.487825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , (){La=void 0}
[1:1:0712/041613.488056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.489496:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 733, 7f27a21c78db
[1:1:0712/041613.511506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.511928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.512367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 737
[1:1:0712/041613.512664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f279f882070 0x2e1171ccfe60 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 733 0x7f279f882070 0x2e117189f060 
[1:1:0712/041613.513009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.513645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.513871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.544265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 737, 7f27a21c78db
[1:1:0712/041613.576775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7f279f882070 0x2e117189f060 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.577199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7f279f882070 0x2e117189f060 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.577589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 739
[1:1:0712/041613.577826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7f279f882070 0x2e11710e9a60 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 737 0x7f279f882070 0x2e1171ccfe60 
[1:1:0712/041613.578183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.578778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.579006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.623779:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 739, 7f27a21c78db
[1:1:0712/041613.656046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"737 0x7f279f882070 0x2e1171ccfe60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.656424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"737 0x7f279f882070 0x2e1171ccfe60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.656794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 741
[1:1:0712/041613.657029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f279f882070 0x2e1171369be0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 739 0x7f279f882070 0x2e11710e9a60 
[1:1:0712/041613.657373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.657973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.658217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.694833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 741, 7f27a21c78db
[1:1:0712/041613.725219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"739 0x7f279f882070 0x2e11710e9a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.725550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"739 0x7f279f882070 0x2e11710e9a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.725889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 743
[1:1:0712/041613.726114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7f279f882070 0x2e11716c7960 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 741 0x7f279f882070 0x2e1171369be0 
[1:1:0712/041613.726457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.727029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.727269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.748614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 743, 7f27a21c78db
[1:1:0712/041613.763859:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"741 0x7f279f882070 0x2e1171369be0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.764212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"741 0x7f279f882070 0x2e1171369be0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.764587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 745
[1:1:0712/041613.764821:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f279f882070 0x2e117121e660 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 743 0x7f279f882070 0x2e11716c7960 
[1:1:0712/041613.765233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.765783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.766022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.802659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 745, 7f27a21c78db
[1:1:0712/041613.823655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"743 0x7f279f882070 0x2e11716c7960 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.824029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"743 0x7f279f882070 0x2e11716c7960 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.824393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 747
[1:1:0712/041613.824633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f279f882070 0x2e1170fc4060 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 745 0x7f279f882070 0x2e117121e660 
[1:1:0712/041613.824965:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.825537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.825754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041613.871904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 747, 7f27a21c78db
[1:1:0712/041613.904894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"745 0x7f279f882070 0x2e117121e660 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.905261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"745 0x7f279f882070 0x2e117121e660 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041613.905645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 749
[1:1:0712/041613.905893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7f279f882070 0x2e11716d2b60 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 747 0x7f279f882070 0x2e1170fc4060 
[1:1:0712/041613.906246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041613.906825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041613.907042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041614.167291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 681, 7f27a21c78db
[1:1:0712/041614.203972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"545 0x7f279f882070 0x2e11716cce60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041614.204397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"545 0x7f279f882070 0x2e11716cce60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041614.204794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 751
[1:1:0712/041614.205050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f279f882070 0x2e11716cc160 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 681 0x7f279f882070 0x2e117189d5e0 
[1:1:0712/041614.205394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041614.205947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                base.next(true);
            }
[1:1:0712/041614.206171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041614.218075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041614.218344:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 800
[1:1:0712/041614.218754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 752
[1:1:0712/041614.218994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7f279f882070 0x2e1171369a60 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 681 0x7f279f882070 0x2e117189d5e0 
[1:1:0712/041614.256866:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 5000
[1:1:0712/041614.257433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 753
[1:1:0712/041614.257758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f279f882070 0x2e1170fc4460 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 681 0x7f279f882070 0x2e117189d5e0 
[1:1:0712/041615.052899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 752, 7f27a21c7881
[1:1:0712/041615.087468:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"681 0x7f279f882070 0x2e117189d5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041615.087883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"681 0x7f279f882070 0x2e117189d5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041615.088195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041615.088816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                        base.isCss3Finish = true;
                    }
[1:1:0712/041615.089161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041615.183820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/041615.184213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[72846:72846:0712/041615.848239:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/041616.314120:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 731, 7f27a21c78db
[1:1:0712/041616.335442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.335887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"711 0x7f279f882070 0x2e117121e7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.336247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 774
[1:1:0712/041616.336478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7f279f882070 0x2e11714c8a60 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 731 0x7f279f882070 0x2e11717bb7e0 
[1:1:0712/041616.336771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.337367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , autotab, (){
			number++;
			number == maxNumber? number = 0 : number;
			$('.zzsc .tab a:eq('+number+')').ad
[1:1:0712/041616.337592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.395328:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041616.395700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 0
[1:1:0712/041616.396125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 775
[1:1:0712/041616.396380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f279f882070 0x2e11716cbce0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 731 0x7f279f882070 0x2e11717bb7e0 
[1:1:0712/041616.431322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 13
[1:1:0712/041616.431914:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 776
[1:1:0712/041616.432157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f279f882070 0x2e11711161e0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 731 0x7f279f882070 0x2e11717bb7e0 
[1:1:0712/041616.440439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 775, 7f27a21c7881
[1:1:0712/041616.474574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.474998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.475352:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.475988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , (){La=void 0}
[1:1:0712/041616.476228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.477712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 776, 7f27a21c78db
[1:1:0712/041616.512430:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.512861:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.513226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 780
[1:1:0712/041616.513458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f279f882070 0x2e11717d7460 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 776 0x7f279f882070 0x2e11711161e0 
[1:1:0712/041616.513784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.514379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.514611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.558762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 780, 7f27a21c78db
[1:1:0712/041616.583811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"776 0x7f279f882070 0x2e11711161e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.584174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"776 0x7f279f882070 0x2e11711161e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.584526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 782
[1:1:0712/041616.584757:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 782 0x7f279f882070 0x2e11717145e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 780 0x7f279f882070 0x2e11717d7460 
[1:1:0712/041616.585100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.585647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.585875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.588634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 782, 7f27a21c78db
[1:1:0712/041616.607400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"780 0x7f279f882070 0x2e11717d7460 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.607790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"780 0x7f279f882070 0x2e11717d7460 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.608198:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 784
[1:1:0712/041616.608435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f279f882070 0x2e11713d0260 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 782 0x7f279f882070 0x2e11717145e0 
[1:1:0712/041616.608771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.609340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.609561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.614585:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 784, 7f27a21c78db
[1:1:0712/041616.654423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"782 0x7f279f882070 0x2e11717145e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.654782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"782 0x7f279f882070 0x2e11717145e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.655206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 786
[1:1:0712/041616.655454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7f279f882070 0x2e117189e5e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 784 0x7f279f882070 0x2e11713d0260 
[1:1:0712/041616.655810:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.656385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.656600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.695012:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 786, 7f27a21c78db
[1:1:0712/041616.724404:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"784 0x7f279f882070 0x2e11713d0260 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.724773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"784 0x7f279f882070 0x2e11713d0260 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.725186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 788
[1:1:0712/041616.725448:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7f279f882070 0x2e11713b4ae0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 786 0x7f279f882070 0x2e117189e5e0 
[1:1:0712/041616.725793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.726394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.726626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041616.753780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 788, 7f27a21c78db
[3:3:0712/041616.790273:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/041616.791464:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"786 0x7f279f882070 0x2e117189e5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.791799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"786 0x7f279f882070 0x2e117189e5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041616.792188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 792
[1:1:0712/041616.792436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f279f882070 0x2e1171cad3e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 788 0x7f279f882070 0x2e11713b4ae0 
[1:1:0712/041616.792762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041616.793348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041616.793593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041617.882601:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 792, 7f27a21c78db
[1:1:0712/041617.908319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"788 0x7f279f882070 0x2e11713b4ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041617.908686:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"788 0x7f279f882070 0x2e11713b4ae0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041617.909085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 840
[1:1:0712/041617.909345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f279f882070 0x2e117175cce0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 792 0x7f279f882070 0x2e1171cad3e0 
[1:1:0712/041617.909697:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041617.910322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041617.910571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041618.150883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://sxgp.jxnews.com.cn/"
[1:1:0712/041618.151630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , r.handle, (b){return typeof n!==U&&n.event.triggered!==b.type?n.event.dispatch.apply(a,arguments):void 0}
[1:1:0712/041618.151911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041619.415247:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://sxgp.jxnews.com.cn/favicon.ico"
[1:1:0712/041619.465971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 753, 7f27a21c78db
[1:1:0712/041619.502940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"681 0x7f279f882070 0x2e117189d5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.503348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"681 0x7f279f882070 0x2e117189d5e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.503784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 867
[1:1:0712/041619.504048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 867 0x7f279f882070 0x2e1171112ee0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 753 0x7f279f882070 0x2e1170fc4460 
[1:1:0712/041619.504365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041619.505039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                base.next(true);
            }
[1:1:0712/041619.505286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041619.515319:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041619.515563:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 800
[1:1:0712/041619.516023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 868
[1:1:0712/041619.516262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f279f882070 0x2e1170ebb760 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 753 0x7f279f882070 0x2e1170fc4460 
[1:1:0712/041619.551466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 5000
[1:1:0712/041619.551907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 870
[1:1:0712/041619.552154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f279f882070 0x2e11726c42e0 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 753 0x7f279f882070 0x2e1170fc4460 
[1:1:0712/041619.578337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 774, 7f27a21c78db
[1:1:0712/041619.593063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.593415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"731 0x7f279f882070 0x2e11717bb7e0 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.593823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 873
[1:1:0712/041619.594069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7f279f882070 0x2e11716d36e0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 774 0x7f279f882070 0x2e11714c8a60 
[1:1:0712/041619.594373:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041619.594943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , autotab, (){
			number++;
			number == maxNumber? number = 0 : number;
			$('.zzsc .tab a:eq('+number+')').ad
[1:1:0712/041619.595176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041619.651763:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x214232ba29c8, 0x2e1170d38950
[1:1:0712/041619.652041:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 0
[1:1:0712/041619.652423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 874
[1:1:0712/041619.652686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 874 0x7f279f882070 0x2e117175df60 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 774 0x7f279f882070 0x2e11714c8a60 
[1:1:0712/041619.668469:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sxgp.jxnews.com.cn/", 13
[1:1:0712/041619.668912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 875
[1:1:0712/041619.669149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f279f882070 0x2e11726bf060 , 5:3_http://sxgp.jxnews.com.cn/, 1, -5:3_http://sxgp.jxnews.com.cn/, 774 0x7f279f882070 0x2e11714c8a60 
[1:1:0712/041619.820924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 874, 7f27a21c7881
[1:1:0712/041619.851929:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"774 0x7f279f882070 0x2e11714c8a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.852287:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"774 0x7f279f882070 0x2e11714c8a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.852733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041619.853427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , (){La=void 0}
[1:1:0712/041619.853683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041619.855018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 875, 7f27a21c78db
[1:1:0712/041619.880833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"774 0x7f279f882070 0x2e11714c8a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.881200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"774 0x7f279f882070 0x2e11714c8a60 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041619.881564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 885
[1:1:0712/041619.881814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7f279f882070 0x2e11710f6de0 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 875 0x7f279f882070 0x2e11726bf060 
[1:1:0712/041619.882136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041619.882749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041619.883013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041620.193646:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 885, 7f27a21c78db
[1:1:0712/041620.233566:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"875 0x7f279f882070 0x2e11726bf060 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041620.233933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"875 0x7f279f882070 0x2e11726bf060 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041620.235114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sxgp.jxnews.com.cn/, 892
[1:1:0712/041620.235364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f279f882070 0x2e1170c25560 , 5:3_http://sxgp.jxnews.com.cn/, 0, , 885 0x7f279f882070 0x2e11710f6de0 
[1:1:0712/041620.235696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041620.236267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/041620.236487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/041620.721149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sxgp.jxnews.com.cn/, 868, 7f27a21c7881
[1:1:0712/041620.762644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"03a50af82860","ptid":"753 0x7f279f882070 0x2e1170fc4460 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041620.763134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sxgp.jxnews.com.cn/","ptid":"753 0x7f279f882070 0x2e1170fc4460 ","rf":"5:3_http://sxgp.jxnews.com.cn/"}
[1:1:0712/041620.763542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sxgp.jxnews.com.cn/"
[1:1:0712/041620.764313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sxgp.jxnews.com.cn/, 03a50af82860, , , () {
                        base.isCss3Finish = true;
                    }
[1:1:0712/041620.764605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sxgp.jxnews.com.cn/", "sxgp.jxnews.com.cn", 3, 1, , , 0
