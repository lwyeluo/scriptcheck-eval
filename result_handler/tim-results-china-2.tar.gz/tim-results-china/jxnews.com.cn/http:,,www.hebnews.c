[0712/040839.295754:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/040839.296126:INFO:switcher_clone.cc(787)] backtrace rip is 7f99c0f67891
[0712/040840.217545:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/040840.217864:INFO:switcher_clone.cc(787)] backtrace rip is 7f2368864891
[1:1:0712/040840.222104:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/040840.222343:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/040840.227920:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[71779:71779:0712/040841.499870:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/44e5fe24-7a51-4699-aff4-a3349dd2038d
[0712/040841.631242:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/040841.631543:INFO:switcher_clone.cc(787)] backtrace rip is 7fbf31eb3891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[71810:71810:0712/040841.865701:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71810
[71823:71823:0712/040841.866116:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=71823
[71779:71779:0712/040842.047132:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[71779:71808:0712/040842.048082:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/040842.048343:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/040842.048616:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/040842.049381:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/040842.049575:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/040842.053011:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32d2bbfd, 1
[1:1:0712/040842.053358:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d16c701, 0
[1:1:0712/040842.053522:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39b01252, 3
[1:1:0712/040842.053706:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x4450ef7, 2
[1:1:0712/040842.053900:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 01ffffffc7162d fffffffdffffffbbffffffd232 fffffff70e4504 5212ffffffb039 , 10104, 4
[1:1:0712/040842.054910:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71779:71808:0712/040842.055165:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�-���2�ER�9�,0(
[71779:71808:0712/040842.055269:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �-���2�ER�9X-�,0(
[71779:71808:0712/040842.055590:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[71779:71808:0712/040842.055747:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71831, 4, 01c7162d fdbbd232 f70e4504 5212b039 
[1:1:0712/040842.056062:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2366a9f0a0, 3
[1:1:0712/040842.056213:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2366c2a080, 2
[1:1:0712/040842.056304:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23508edd20, -2
[1:1:0712/040842.064733:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/040842.065350:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4450ef7
[1:1:0712/040842.066025:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4450ef7
[1:1:0712/040842.067060:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4450ef7
[1:1:0712/040842.067578:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.067723:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.067828:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.067931:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.068157:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4450ef7
[1:1:0712/040842.068300:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f23688647ba
[1:1:0712/040842.068372:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f236885bdef, 7f236886477a, 7f23688660cf
[1:1:0712/040842.069851:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 4450ef7
[1:1:0712/040842.070009:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 4450ef7
[1:1:0712/040842.070273:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 4450ef7
[1:1:0712/040842.070981:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.071102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.071195:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.071284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 4450ef7
[1:1:0712/040842.071749:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 4450ef7
[1:1:0712/040842.071909:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f23688647ba
[1:1:0712/040842.071982:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f236885bdef, 7f236886477a, 7f23688660cf
[1:1:0712/040842.074229:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/040842.074530:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/040842.074625:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd971d2778, 0x7ffd971d26f8)
[1:1:0712/040842.086126:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/040842.092255:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[71779:71779:0712/040842.701588:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71779:71779:0712/040842.702346:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71779:71790:0712/040842.715060:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[71779:71790:0712/040842.715208:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[71779:71779:0712/040842.715300:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[71779:71779:0712/040842.715402:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[71779:71779:0712/040842.715578:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,71831, 4
[1:7:0712/040842.718606:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[71779:71803:0712/040842.789585:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/040842.863730:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x37a83d7cb220
[1:1:0712/040842.864163:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/040843.357670:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[71779:71779:0712/040844.997777:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[71779:71779:0712/040844.997855:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/040845.058750:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040845.063524:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/040846.166161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/040846.166514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040846.186954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/040846.187320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040846.276811:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040846.586677:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040846.586956:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040847.018652:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040847.026789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/040847.027079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040847.062644:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040847.074545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/040847.074934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040847.087270:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[71779:71779:0712/040847.090517:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040847.090750:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37a83d7c9e20
[1:1:0712/040847.091023:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[71779:71779:0712/040847.098535:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[71779:71779:0712/040847.128752:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[71779:71779:0712/040847.128972:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/040847.173354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040847.964902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f23524c82e0 0x37a83d929960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040847.965859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/040847.966199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040847.967878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[71779:71779:0712/040848.039287:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040848.040532:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37a83d7ca820
[1:1:0712/040848.040742:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[71779:71779:0712/040848.053571:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/040848.060372:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/040848.060629:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[71779:71779:0712/040848.082327:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[71779:71779:0712/040848.100288:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71779:71779:0712/040848.101351:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71779:71790:0712/040848.107386:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[71779:71790:0712/040848.107470:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[71779:71779:0712/040848.110845:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[71779:71779:0712/040848.110930:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[71779:71779:0712/040848.111065:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,71831, 4
[1:7:0712/040848.114970:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/040848.637682:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/040849.185194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f23524c82e0 0x37a83da53660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040849.186323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/040849.186581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040849.187446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[71779:71779:0712/040849.424949:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[71779:71779:0712/040849.425101:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/040849.439445:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[71779:71779:0712/040849.808353:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[71779:71808:0712/040849.808808:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/040849.809037:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/040849.809314:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/040849.809751:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/040849.809933:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/040849.813264:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x12ce59bb, 1
[1:1:0712/040849.813763:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x97409a2, 0
[1:1:0712/040849.814023:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c5c5b4c, 3
[1:1:0712/040849.814672:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19ce2951, 2
[1:1:0712/040849.814863:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa2097409 ffffffbb59ffffffce12 5129ffffffce19 4c5b5c1c , 10104, 5
[1:1:0712/040849.815908:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[71779:71808:0712/040849.816178:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�	t	�Y�Q)�L[\/0(
[71779:71808:0712/040849.816270:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �	t	�Y�Q)�L[\x5/0(
[1:1:0712/040849.816172:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2366a9f0a0, 3
[1:1:0712/040849.816387:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2366c2a080, 2
[71779:71808:0712/040849.816586:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 71877, 5, a2097409 bb59ce12 5129ce19 4c5b5c1c 
[1:1:0712/040849.816639:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f23508edd20, -2
[1:1:0712/040849.832686:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/040849.832888:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ce2951
[1:1:0712/040849.833070:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ce2951
[1:1:0712/040849.833319:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ce2951
[1:1:0712/040849.833820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.833923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.834009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.834096:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.834321:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ce2951
[1:1:0712/040849.834443:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f23688647ba
[1:1:0712/040849.834549:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f236885bdef, 7f236886477a, 7f23688660cf
[1:1:0712/040849.835990:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ce2951
[1:1:0712/040849.836144:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ce2951
[1:1:0712/040849.836393:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ce2951
[1:1:0712/040849.837057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.837171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.837270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.837364:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ce2951
[1:1:0712/040849.838138:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ce2951
[1:1:0712/040849.838495:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f23688647ba
[1:1:0712/040849.838609:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f236885bdef, 7f236886477a, 7f23688660cf
[1:1:0712/040849.840802:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/040849.841155:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/040849.841248:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd971d2778, 0x7ffd971d26f8)
[1:1:0712/040849.856588:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/040849.860984:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/040849.861663:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040850.075034:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x37a83d795220
[1:1:0712/040850.075303:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/040850.545111:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040850.545356:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[71779:71779:0712/040850.766546:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71779:71779:0712/040850.768961:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71779:71790:0712/040850.779776:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[71779:71790:0712/040850.779901:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[71779:71779:0712/040850.784050:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.hebnews.cn/
[71779:71779:0712/040850.784126:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hebnews.cn/, http://www.hebnews.cn/, 1
[71779:71779:0712/040850.784972:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.hebnews.cn/, HTTP/1.1 200 OK Server: Tengine Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Date: Fri, 12 Jul 2019 11:08:50 GMT Vary: Accept-Encoding Ali-Swift-Global-Savetime: 1562929730 Via: cache10.l2et2-1[48,200-0,M], cache28.l2et2-1[50,0], cache4.cn143[226,200-0,M], cache5.cn143[227,0] X-Cache: MISS TCP_MISS dirn:-2:-2 X-Swift-SaveTime: Fri, 12 Jul 2019 11:08:50 GMT X-Swift-CacheTime: 0 Timing-Allow-Origin: * EagleId: 7cc1e29915629297305495446e Content-Encoding: gzip  ,71877, 5
[1:7:0712/040850.787137:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/040850.817665:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.hebnews.cn/
[1:1:0712/040850.913509:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/040850.914130:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/040850.918754:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/040850.923536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c531bd4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/040850.923946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/040850.932721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/040850.948353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[71779:71779:0712/040850.951572:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hebnews.cn/, http://www.hebnews.cn/, 1
[71779:71779:0712/040850.951630:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040851.028461:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/040851.092936:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040851.093114:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040851.335543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/040851.336375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c531bc21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/040851.336581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/040851.523640:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040851.931778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7f2350908bd0 0x37a83d9812d8 , "http://www.hebnews.cn/"
[1:1:0712/040851.945796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/040851.945972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040851.946601:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_f00c2798 -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/040852.196290:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7f2350908bd0 0x37a83d9812d8 , "http://www.hebnews.cn/"
[1:1:0712/040852.276194:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040852.276657:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040852.277001:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040852.277402:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040852.277799:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040852.419922:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040852.445732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/040852.446028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
		remove user.10_314bca55 -> 0
		remove user.11_a0d738de -> 0
		remove user.12_6bf0c2cf -> 0
		remove user.13_6d144c0b -> 0
		remove user.14_10c3732b -> 0
[1:1:0712/040853.814832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040853.883622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040853.888001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040853.936402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040853.950298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f2350908bd0 0x37a83d851ad8 , "http://www.hebnews.cn/"
[1:1:0712/040853.955092:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/040853.980710:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x37a83d793420
[1:1:0712/040853.981029:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/040853.997349:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/040853.997617:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.hebnews.cn
[1:1:0712/040854.065098:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.251699, 750, 1
[1:1:0712/040854.065400:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040855.422106:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040855.422368:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040855.423159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 294 0x7f23505a0070 0x37a83de19d60 , "http://www.hebnews.cn/"
[1:1:0712/040855.424348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/040855.424537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[71779:71779:0712/040909.564588:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[71779:71779:0712/040909.570613:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[71779:71779:0712/040909.583327:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.hebnews.cn/
[71779:71779:0712/040909.645959:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/040909.650738:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[71779:71779:0712/040909.798993:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1215x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929736&rw=424&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929736&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[71779:71779:0712/040909.806084:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1215x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929736&rw=424&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929736&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[71779:71779:0712/040909.820784:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[71779:71779:0712/040909.824105:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[71779:71790:0712/040909.833708:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[71779:71779:0712/040909.833759:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tianqi.2345.com/
[71779:71779:0712/040909.833804:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tianqi.2345.com/, http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left, 4
[71779:71790:0712/040909.833806:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[71779:71779:0712/040909.833867:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://tianqi.2345.com/, HTTP/1.1 200 OK Last-Modified: Tue, 22 Jan 2019 05:50:38 GMT Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:12:48 GMT Cache-Control: max-age=300 P3P: CP=CAO PSA OUR Accept-Ranges: bytes Date: Fri, 12 Jul 2019 11:09:09 GMT Age: 81 x-hits: 2 Content-Type: text/html ETag: W/"5c46af2e-92c" Content-Encoding: gzip Content-Length: 940  ,71877, 5
[1:7:0712/040909.838092:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/040911.407942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/040911.408253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040912.541088:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://tianqi.2345.com/
[1:1:0712/040912.766030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442 0x7f23524c82e0 0x37a83dd89360 , "http://www.hebnews.cn/"
[1:1:0712/040912.775700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (function(){var h={},mt={},c={id:"fc19c432c6dd37e78d6593b2756fb674",dm:["hebnews.cn"],js:"tongji.bai
[1:1:0712/040912.776015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040912.804248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df948
[1:1:0712/040912.804523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040912.804890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 510
[1:1:0712/040912.805159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 510 0x7f23505a0070 0x37a83dd92ee0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 442 0x7f23524c82e0 0x37a83dd89360 
[1:1:0712/040912.880868:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 600000
[1:1:0712/040912.881421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 523
[1:1:0712/040912.881746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7f23505a0070 0x37a83dd820e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 442 0x7f23524c82e0 0x37a83dd89360 
[1:1:0712/040912.882830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/040912.883256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 524
[1:1:0712/040912.883492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7f23505a0070 0x37a83db46360 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 442 0x7f23524c82e0 0x37a83dd89360 
[1:1:0712/040913.596977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040913.597360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040913.790450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481, "http://www.hebnews.cn/"
[1:1:0712/040913.791991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , ___adblockplus({"queryid" : "c6050be70f6d133c","tuid" : "3229865_0","placement" : {"basic" : {"sspId
[1:1:0712/040913.792251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[71779:71779:0712/040913.832183:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040913.832570:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x37a83d792a20
[1:1:0712/040913.832832:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[71779:71779:0712/040913.838941:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[71779:71779:0712/040913.877514:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.hebnews.cn/, http://www.hebnews.cn/, 5
[71779:71779:0712/040913.877645:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040913.906196:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040913.934736:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/040913.938924:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x37a83e1fe420
[1:1:0712/040913.939171:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[71779:71779:0712/040913.972641:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[71779:71779:0712/040913.980194:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229865_0, 6, 6, 
[1:1:0712/040913.985825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/040914.006584:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 252f3382d6f8, 5:3_http://www.hebnews.cn/, 5:6_http://www.hebnews.cn/, about:blank
[1:1:0712/040914.006877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/, 252f3382d6f8, 252f33742860, open, 
[1:1:0712/040914.007156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 6, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040914.009666:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:471:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1215x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929736&rw=424&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929736&exps=110011:1:1

[71779:71779:0712/040914.010526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://www.hebnews.cn/, http://www.hebnews.cn/, 6
[71779:71779:0712/040914.010664:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040914.012986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481, "http://www.hebnews.cn/"
[1:1:0712/040914.025104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/040914.025602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 628
[1:1:0712/040914.025838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7f23505a0070 0x37a83d115260 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/, 481
[1:1:0712/040914.029955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 252f33742860, 252f3382d6f8, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/040914.030213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/040914.031151:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229865&dri=0&dis=0&dai=0&ps=229x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1215x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929736&rw=424&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929736&exps=110011:1:1

[1:1:0712/040914.039965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 500
[1:1:0712/040914.040388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 631
[1:1:0712/040914.040624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f23505a0070 0x37a83e894a60 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 481
[1:1:0712/040914.044214:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 50
[1:1:0712/040914.044665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 632
[1:1:0712/040914.044907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7f23505a0070 0x37a83e895360 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 481
[71779:71779:0712/040914.047377:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/040914.097827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481, "http://www.hebnews.cn/"
[1:1:0712/040914.517505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df998
[1:1:0712/040914.517771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040914.518149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 646
[1:1:0712/040914.518408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7f23505a0070 0x37a83e8d9e60 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 481
[1:1:0712/040914.576170:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 50
[1:1:0712/040914.576622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 647
[1:1:0712/040914.576889:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7f23505a0070 0x37a83e979ce0 , 5:3_http://www.hebnews.cn/, 3, -5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 481
[1:1:0712/040914.606658:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.513855, 40, 0
[1:1:0712/040914.606921:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040915.111618:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[71779:71779:0712/040915.116467:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tianqi.2345.com/, http://tianqi.2345.com/, 4
[71779:71779:0712/040915.116584:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://tianqi.2345.com/, http://tianqi.2345.com
[1:1:0712/040915.774953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 510, 7f2352ee5881
[1:1:0712/040915.803221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"442 0x7f23524c82e0 0x37a83dd89360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040915.803521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"442 0x7f23524c82e0 0x37a83dd89360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040915.803947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040915.804462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040915.804638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040915.805356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040915.805525:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040915.805861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 695
[1:1:0712/040915.806058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f23505a0070 0x37a83eaf1760 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 510 0x7f23505a0070 0x37a83dd92ee0 
[1:1:0712/040916.410279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040916.410525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040918.239320:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040918.239483:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040918.240208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7f23505a0070 0x37a83e97cf60 , "http://www.hebnews.cn/"
[1:1:0712/040918.240875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/040918.240999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[71779:71779:0712/040918.333193:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1215x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929758&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929758&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[71779:71779:0712/040918.346018:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1215x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929758&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929758&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/040919.048351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 632, 7f2352ee58db
[1:1:0712/040919.058484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f3382d6f8252f33742860","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.058674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.058900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 752
[1:1:0712/040919.059026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7f23505a0070 0x37a83eb327e0 , 5:3_http://www.hebnews.cn/, 0, , 632 0x7f23505a0070 0x37a83e895360 
[1:1:0712/040919.059173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040919.059464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040919.059572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.060683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 646, 7f2352ee5881
[1:1:0712/040919.070253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f3382d6f8252f33742860","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.070405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.070614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040919.070868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040919.070971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.135992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 631, 7f2352ee58db
[1:1:0712/040919.169554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f3382d6f8252f33742860","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.169993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.170563:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 755
[1:1:0712/040919.170816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f23505a0070 0x37a83df41ee0 , 5:3_http://www.hebnews.cn/, 0, , 631 0x7f23505a0070 0x37a83e894a60 
[1:1:0712/040919.171193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040919.171818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040919.172045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.229855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 647, 7f2352ee58db
[1:1:0712/040919.262437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f3382d6f8252f33742860","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.262810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.263204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 757
[1:1:0712/040919.263395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f23505a0070 0x37a83eaf3c60 , 5:3_http://www.hebnews.cn/, 0, , 647 0x7f23505a0070 0x37a83e979ce0 
[1:1:0712/040919.263707:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040919.264272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040919.264446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.296979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040919.297197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040919.297538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 758
[1:1:0712/040919.297732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 758 0x7f23505a0070 0x37a83ecb2ee0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 647 0x7f23505a0070 0x37a83e979ce0 
[1:1:0712/040919.351174:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040919.688984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/040919.689651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , g.onload, (){g.onload=w;g=window[d]=w;a&&a(b)}
[1:1:0712/040919.689825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.697317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 695, 7f2352ee5881
[1:1:0712/040919.716000:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"510 0x7f23505a0070 0x37a83dd92ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.716183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"510 0x7f23505a0070 0x37a83dd92ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040919.716382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040919.716707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040919.716815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040919.717113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040919.717210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040919.717377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 772
[1:1:0712/040919.717485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f23505a0070 0x37a83eb32460 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 695 0x7f23505a0070 0x37a83eaf1760 
[1:1:0712/040920.142996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040920.143177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040920.590401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 524, 7f2352ee58db
[1:1:0712/040920.600945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"442 0x7f23524c82e0 0x37a83dd89360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040920.601123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"442 0x7f23524c82e0 0x37a83dd89360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040920.601352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 797
[1:1:0712/040920.601465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f23505a0070 0x37a83e28ece0 , 5:3_http://www.hebnews.cn/, 0, , 524 0x7f23505a0070 0x37a83db46360 
[1:1:0712/040920.601609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040920.601909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/040920.602017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040920.863380:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744, "http://www.hebnews.cn/"
[1:1:0712/040920.864944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , ___adblockplus({"queryid" : "2d550c8b05b7f390","tuid" : "5854320_0","placement" : {"basic" : {"sspId
[1:1:0712/040920.865191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040920.888629:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[71779:71779:0712/040920.890726:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040920.892970:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x37a83e8e8820
[1:1:0712/040920.893535:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[71779:71779:0712/040920.898142:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe5854320_0, 7, 7, 
[71779:71779:0712/040920.934092:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://www.hebnews.cn/, http://www.hebnews.cn/, 7
[71779:71779:0712/040920.934238:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040920.940260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/040920.990806:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 252f338034b0, 5:3_http://www.hebnews.cn/, 5:7_http://www.hebnews.cn/, about:blank
[1:1:0712/040920.991054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/, 252f338034b0, 252f33742860, open, 
[1:1:0712/040920.991199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 7, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040920.992009:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:498:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1215x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929758&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929758&exps=110011:1:1

[1:1:0712/040920.994485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744, "http://www.hebnews.cn/"
[1:1:0712/040921.001174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/040921.001587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 833
[1:1:0712/040921.001779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f23505a0070 0x37a83e982760 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/, 744
[1:1:0712/040921.007288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 252f33742860, 252f338034b0, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/040921.007521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/040921.008401:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=5854320&dri=0&dis=0&dai=0&ps=289x795&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1040x502&pss=1215x502&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929758&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929758&exps=110011:1:1

[1:1:0712/040921.101120:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0505061, 162, 1
[1:1:0712/040921.101409:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040921.333947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 628, 7f2352ee58db
[1:1:0712/040921.377804:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f3382d6f8","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.378143:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:6_http://www.hebnews.cn/","ptid":"481","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.378569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 864
[1:1:0712/040921.378763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f23505a0070 0x37a83ef8d3e0 , 5:3_http://www.hebnews.cn/, 0, , 628 0x7f23505a0070 0x37a83d115260 
[1:1:0712/040921.379081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040921.379561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040921.379784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040921.441131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 752, 7f2352ee58db
[1:1:0712/040921.452085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"632 0x7f23505a0070 0x37a83e895360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.452262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"632 0x7f23505a0070 0x37a83e895360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.452481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 865
[1:1:0712/040921.452590:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f23505a0070 0x37a83e893860 , 5:3_http://www.hebnews.cn/, 0, , 752 0x7f23505a0070 0x37a83eb327e0 
[1:1:0712/040921.452745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040921.453051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040921.453168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040921.465260:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040921.465392:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040921.513811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 757, 7f2352ee58db
[1:1:0712/040921.544356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"647 0x7f23505a0070 0x37a83e979ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.544538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"647 0x7f23505a0070 0x37a83e979ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.544741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 875
[1:1:0712/040921.544851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f23505a0070 0x37a83eb322e0 , 5:3_http://www.hebnews.cn/, 0, , 757 0x7f23505a0070 0x37a83eaf3c60 
[1:1:0712/040921.545007:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040921.545339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040921.545445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040921.957320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 758, 7f2352ee5881
[1:1:0712/040921.994499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"647 0x7f23505a0070 0x37a83e979ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.994856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"647 0x7f23505a0070 0x37a83e979ce0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040921.995269:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040921.995797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040921.996043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040922.119320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 755, 7f2352ee58db
[1:1:0712/040922.155972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"631 0x7f23505a0070 0x37a83e894a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040922.156390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"631 0x7f23505a0070 0x37a83e894a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040922.156852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 888
[1:1:0712/040922.157083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f23505a0070 0x37a83ef9c8e0 , 5:3_http://www.hebnews.cn/, 0, , 755 0x7f23505a0070 0x37a83df41ee0 
[1:1:0712/040922.157398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040922.157913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040922.158125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040922.459991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 772, 7f2352ee5881
[1:1:0712/040922.496916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"695 0x7f23505a0070 0x37a83eaf1760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040922.497295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"695 0x7f23505a0070 0x37a83eaf1760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040922.497699:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040922.498322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040922.498537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040922.499343:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040922.499540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040922.499922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 893
[1:1:0712/040922.500148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7f23505a0070 0x37a83f0eb3e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 772 0x7f23505a0070 0x37a83eb32460 
[1:1:0712/040923.104081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040923.104378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/040925.274742:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040925.275014:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040925.275840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 854 0x7f23505a0070 0x37a83e9d1be0 , "http://www.hebnews.cn/"
[1:1:0712/040925.276809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , jQuery(".activityBox").slide({ mainCell:".contentInner ul", effect:"top",delayTime:400});
[1:1:0712/040925.277106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040925.473615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df998
[1:1:0712/040925.473917:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040925.474298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 985
[1:1:0712/040925.474527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f23505a0070 0x37a83f0ee2e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 854 0x7f23505a0070 0x37a83e9d1be0 
[1:1:0712/040925.504833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/040925.505269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 986
[1:1:0712/040925.505518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f23505a0070 0x37a83df3c660 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 854 0x7f23505a0070 0x37a83e9d1be0 
[1:1:0712/040925.547014:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.271932, 55, 1
[1:1:0712/040925.547288:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040926.279699:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 865, 7f2352ee58db
[1:1:0712/040926.321146:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"752 0x7f23505a0070 0x37a83eb327e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.321491:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"752 0x7f23505a0070 0x37a83eb327e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.321920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1013
[1:1:0712/040926.322151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7f23505a0070 0x37a83eaf8ae0 , 5:3_http://www.hebnews.cn/, 0, , 865 0x7f23505a0070 0x37a83e893860 
[1:1:0712/040926.322576:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040926.323091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040926.323344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040926.508370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 875, 7f2352ee58db
[1:1:0712/040926.542938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"757 0x7f23505a0070 0x37a83eaf3c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.543389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"757 0x7f23505a0070 0x37a83eaf3c60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.543940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1019
[1:1:0712/040926.544188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1019 0x7f23505a0070 0x37a83df4d4e0 , 5:3_http://www.hebnews.cn/, 0, , 875 0x7f23505a0070 0x37a83eb322e0 
[1:1:0712/040926.544629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040926.545303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040926.545554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040926.935878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 888, 7f2352ee58db
[1:1:0712/040926.978379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"755 0x7f23505a0070 0x37a83df41ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.978785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"755 0x7f23505a0070 0x37a83df41ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040926.979258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1027
[1:1:0712/040926.979541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7f23505a0070 0x37a83e8949e0 , 5:3_http://www.hebnews.cn/, 0, , 888 0x7f23505a0070 0x37a83ef9c8e0 
[1:1:0712/040926.979986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040926.980769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040926.981033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040927.084647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 893, 7f2352ee5881
[1:1:0712/040927.128886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"772 0x7f23505a0070 0x37a83eb32460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.129405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"772 0x7f23505a0070 0x37a83eb32460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.129891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040927.130555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040927.130811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040927.131517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040927.131711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040927.132072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1033
[1:1:0712/040927.132341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7f23505a0070 0x37a83de637e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 893 0x7f23505a0070 0x37a83f0eb3e0 
[1:1:0712/040927.264820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 797, 7f2352ee58db
[1:1:0712/040927.300844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"524 0x7f23505a0070 0x37a83db46360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.301253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"524 0x7f23505a0070 0x37a83db46360 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.301834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1037
[1:1:0712/040927.302077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7f23505a0070 0x37a83de65960 , 5:3_http://www.hebnews.cn/, 0, , 797 0x7f23505a0070 0x37a83e28ece0 
[1:1:0712/040927.302487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040927.303009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/040927.303222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040927.515299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040927.515686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040927.933595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 864, 7f2352ee58db
[1:1:0712/040927.978601:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"628 0x7f23505a0070 0x37a83d115260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.978989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"628 0x7f23505a0070 0x37a83d115260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040927.979490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1044
[1:1:0712/040927.979810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7f23505a0070 0x37a83f4de460 , 5:3_http://www.hebnews.cn/, 0, , 864 0x7f23505a0070 0x37a83ef8d3e0 
[1:1:0712/040927.980200:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040927.980704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040927.980998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/040930.672173:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040930.672484:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040930.676639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 992 0x7f23505a0070 0x37a83ebedc60 , "http://www.hebnews.cn/"
[1:1:0712/040930.679009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (function($) {
    $.fn.extend({
        yx_rotaion: function(options) {
            var defaults
[1:1:0712/040930.679281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040930.689532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 992 0x7f23505a0070 0x37a83ebedc60 , "http://www.hebnews.cn/"
[1:1:0712/040930.806720:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 3000
[1:1:0712/040930.807176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1103
[1:1:0712/040930.807443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f23505a0070 0x37a83f692160 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 992 0x7f23505a0070 0x37a83ebedc60 
[1:1:0712/040931.027225:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.354587, 98, 1
[1:1:0712/040931.027507:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040931.030121:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 985, 7f2352ee5881
[1:1:0712/040931.080977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"854 0x7f23505a0070 0x37a83e9d1be0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.081358:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"854 0x7f23505a0070 0x37a83e9d1be0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.081794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040931.082349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040931.082568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040931.134700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 986, 7f2352ee58db
[1:1:0712/040931.176536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"854 0x7f23505a0070 0x37a83e9d1be0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.176902:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"854 0x7f23505a0070 0x37a83e9d1be0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.177403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1113
[1:1:0712/040931.177664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7f23505a0070 0x37a83ee749e0 , 5:3_http://www.hebnews.cn/, 0, , 986 0x7f23505a0070 0x37a83df3c660 
[1:1:0712/040931.178064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040931.178650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/040931.178888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040931.423631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 833, 7f2352ee58db
[1:1:0712/040931.460519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860252f338034b0","ptid":"744","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.460925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/-5:7_http://www.hebnews.cn/","ptid":"744","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040931.461555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1119
[1:1:0712/040931.461861:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7f23505a0070 0x37a83f692560 , 5:3_http://www.hebnews.cn/, 0, , 833 0x7f23505a0070 0x37a83e982760 
[1:1:0712/040931.462249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040931.462812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 252f338034b0, , , () { roll(); }
[1:1:0712/040931.463079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[71779:71779:0712/040931.596690:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/040931.831939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012 0x7f2366c2a080 0x37a83efa72e0 1 0 0x37a83efa72f8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040931.881579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 252f33855a18, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/040931.881943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040932.078637:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012 0x7f2366c2a080 0x37a83efa72e0 1 0 0x37a83efa72f8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040932.091154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1013, 7f2352ee58db
[1:1:0712/040932.132133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"865 0x7f23505a0070 0x37a83e893860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.132502:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"865 0x7f23505a0070 0x37a83e893860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.132978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1135
[1:1:0712/040932.133229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7f23505a0070 0x37a83dd89ee0 , 5:3_http://www.hebnews.cn/, 0, , 1013 0x7f23505a0070 0x37a83eaf8ae0 
[1:1:0712/040932.133642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040932.134210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040932.134438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040932.288215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1019, 7f2352ee58db
[1:1:0712/040932.318809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"875 0x7f23505a0070 0x37a83eb322e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.319157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"875 0x7f23505a0070 0x37a83eb322e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.319687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1137
[1:1:0712/040932.319989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7f23505a0070 0x37a83eb2e860 , 5:3_http://www.hebnews.cn/, 0, , 1019 0x7f23505a0070 0x37a83df4d4e0 
[1:1:0712/040932.320385:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040932.321189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040932.321470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040932.557824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040932.558100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040932.558469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1140
[1:1:0712/040932.558727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7f23505a0070 0x37a83f5422e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1019 0x7f23505a0070 0x37a83df4d4e0 
[1:1:0712/040932.819233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1027, 7f2352ee58db
[1:1:0712/040932.872091:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"888 0x7f23505a0070 0x37a83ef9c8e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.872425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"888 0x7f23505a0070 0x37a83ef9c8e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040932.872931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1147
[1:1:0712/040932.873199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7f23505a0070 0x37a83f699660 , 5:3_http://www.hebnews.cn/, 0, , 1027 0x7f23505a0070 0x37a83e8949e0 
[1:1:0712/040932.873600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040932.874350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040932.874621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040933.166929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1033, 7f2352ee5881
[1:1:0712/040933.211584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"893 0x7f23505a0070 0x37a83f0eb3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.211965:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"893 0x7f23505a0070 0x37a83f0eb3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.212365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040933.212926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040933.213144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040933.213788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040933.214002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040933.214367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1156
[1:1:0712/040933.214615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1156 0x7f23505a0070 0x37a83f6a73e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1033 0x7f23505a0070 0x37a83de637e0 
[1:1:0712/040933.432206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040933.432499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040933.541156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1037, 7f2352ee58db
[1:1:0712/040933.592949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"797 0x7f23505a0070 0x37a83e28ece0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.593312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"797 0x7f23505a0070 0x37a83e28ece0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.593759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1166
[1:1:0712/040933.594077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7f23505a0070 0x37a83f6aa3e0 , 5:3_http://www.hebnews.cn/, 0, , 1037 0x7f23505a0070 0x37a83de65960 
[1:1:0712/040933.594589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040933.595328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/040933.595585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040933.632064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1044, 7f2352ee58db
[1:1:0712/040933.651759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"864 0x7f23505a0070 0x37a83ef8d3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.652173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"864 0x7f23505a0070 0x37a83ef8d3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040933.652631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1168
[1:1:0712/040933.652882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7f23505a0070 0x37a83f6305e0 , 5:3_http://www.hebnews.cn/, 0, , 1044 0x7f23505a0070 0x37a83f4de460 
[1:1:0712/040933.653275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040933.653798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040933.654090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040935.139073:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040935.139258:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040935.139920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1107 0x7f23505a0070 0x37a83ee745e0 , "http://www.hebnews.cn/"
[1:1:0712/040935.140508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , 
			/*
				多行/多列的滚动解决思路在于：把每次滚动的n个li放到1个ul里面，�
[1:1:0712/040935.140652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040935.404581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/040935.404971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1206
[1:1:0712/040935.405166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7f23505a0070 0x37a83f693f60 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1107 0x7f23505a0070 0x37a83ee745e0 
[1:1:0712/040935.418545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/040935.418796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1207
[1:1:0712/040935.418929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7f23505a0070 0x37a83f5227e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1107 0x7f23505a0070 0x37a83ee745e0 
[1:1:0712/040935.466849:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.32756, 246, 1
[1:1:0712/040935.467032:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040936.365060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1135, 7f2352ee58db
[1:1:0712/040936.386935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1013 0x7f23505a0070 0x37a83eaf8ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040936.387220:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1013 0x7f23505a0070 0x37a83eaf8ae0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040936.387687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1235
[1:1:0712/040936.387951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1235 0x7f23505a0070 0x37a83e981e60 , 5:3_http://www.hebnews.cn/, 0, , 1135 0x7f23505a0070 0x37a83dd89ee0 
[1:1:0712/040936.388408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040936.389027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040936.389261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040936.567981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1137, 7f2352ee58db
[1:1:0712/040936.595751:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1019 0x7f23505a0070 0x37a83df4d4e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040936.596024:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1019 0x7f23505a0070 0x37a83df4d4e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040936.596380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1240
[1:1:0712/040936.596558:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7f23505a0070 0x37a83f4d5460 , 5:3_http://www.hebnews.cn/, 0, , 1137 0x7f23505a0070 0x37a83eb2e860 
[1:1:0712/040936.596874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040936.597371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040936.597535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.086469:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1140, 7f2352ee5881
[1:1:0712/040937.114987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1019 0x7f23505a0070 0x37a83df4d4e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.115351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1019 0x7f23505a0070 0x37a83df4d4e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.115797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040937.116316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040937.116529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.356695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1147, 7f2352ee58db
[1:1:0712/040937.402028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1027 0x7f23505a0070 0x37a83e8949e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.402363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1027 0x7f23505a0070 0x37a83e8949e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.402779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1251
[1:1:0712/040937.403049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f23505a0070 0x37a83de678e0 , 5:3_http://www.hebnews.cn/, 0, , 1147 0x7f23505a0070 0x37a83f699660 
[1:1:0712/040937.403454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040937.404024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040937.404245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.437798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1156, 7f2352ee5881
[1:1:0712/040937.491346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1033 0x7f23505a0070 0x37a83de637e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.491784:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1033 0x7f23505a0070 0x37a83de637e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.492326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040937.492967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040937.493259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.494432:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040937.494688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040937.495119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1253
[1:1:0712/040937.495410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7f23505a0070 0x37a83de63ee0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1156 0x7f23505a0070 0x37a83f6a73e0 
[1:1:0712/040937.548540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040937.548919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.822647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1103, 7f2352ee58db
[1:1:0712/040937.851306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"992 0x7f23505a0070 0x37a83ebedc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.851693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"992 0x7f23505a0070 0x37a83ebedc60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040937.852245:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1268
[1:1:0712/040937.852567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7f23505a0070 0x37a83f9aaee0 , 5:3_http://www.hebnews.cn/, 0, , 1103 0x7f23505a0070 0x37a83f692160 
[1:1:0712/040937.852980:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040937.853509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , () {
                    $btn.last().click()
                }
[1:1:0712/040937.853726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040937.890747:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040937.891056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040937.891479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1270
[1:1:0712/040937.891799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7f23505a0070 0x37a83f58b7e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1103 0x7f23505a0070 0x37a83f692160 
[1:1:0712/040938.101919:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/040938.213024:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1168, 7f2352ee58db
[1:1:0712/040938.251565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1044 0x7f23505a0070 0x37a83f4de460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040938.251959:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1044 0x7f23505a0070 0x37a83f4de460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040938.252703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1281
[1:1:0712/040938.252968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1281 0x7f23505a0070 0x37a83d474ee0 , 5:3_http://www.hebnews.cn/, 0, , 1168 0x7f23505a0070 0x37a83f6305e0 
[1:1:0712/040938.253387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040938.253917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040938.254234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/040939.890838:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/040939.891130:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hebnews.cn/"
[1:1:0712/040939.892362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1215 0x7f23505a0070 0x37a83dda3360 , "http://www.hebnews.cn/"
[1:1:0712/040939.894182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , 
			function g(o){return document.getElementById(o);}
			function HoverLi31(n){
			for(var i=31;i<=3
[1:1:0712/040939.894455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040939.897831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1215 0x7f23505a0070 0x37a83dda3360 , "http://www.hebnews.cn/"
[71779:71779:0712/040939.968675:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929779&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929780&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[71779:71779:0712/040939.979665:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929779&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929780&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/040940.011154:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1206, 7f2352ee58db
[1:1:0712/040940.035867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1107 0x7f23505a0070 0x37a83ee745e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.036246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1107 0x7f23505a0070 0x37a83ee745e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.036764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1317
[1:1:0712/040940.037010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1317 0x7f23505a0070 0x37a83f6909e0 , 5:3_http://www.hebnews.cn/, 0, , 1206 0x7f23505a0070 0x37a83f693f60 
[1:1:0712/040940.037397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040940.037954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/040940.038201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040940.206243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1228 0x7f2366c2a080 0x37a83f9ed7e0 1 0 0x37a83f9ed7f8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040940.215965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 252f33855a18, , , var prov=new Array();
prov[12] = '12-B 北京-12';
prov[37] = '37-T 天津-37';
prov[34] = '34-S 上
[1:1:0712/040940.216317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040940.228643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1119, 7f2352ee58db
[1:1:0712/040940.257202:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7f23505a0070 0x37a83e982760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.257528:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7f23505a0070 0x37a83e982760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.257988:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1329
[1:1:0712/040940.258220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f23505a0070 0x37a83f693a60 , 5:3_http://www.hebnews.cn/, 0, , 1119 0x7f23505a0070 0x37a83f692560 
[1:1:0712/040940.258642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040940.259214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 252f338034b0, , , () { roll(); }
[1:1:0712/040940.259599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040940.361610:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1235, 7f2352ee58db
[1:1:0712/040940.425154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1135 0x7f23505a0070 0x37a83dd89ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.425507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1135 0x7f23505a0070 0x37a83dd89ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.426067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1332
[1:1:0712/040940.426313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1332 0x7f23505a0070 0x37a83f62a660 , 5:3_http://www.hebnews.cn/, 0, , 1235 0x7f23505a0070 0x37a83e981e60 
[1:1:0712/040940.426693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040940.427252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040940.427470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040940.489142:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1240, 7f2352ee58db
[1:1:0712/040940.522824:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1137 0x7f23505a0070 0x37a83eb2e860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.523156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1137 0x7f23505a0070 0x37a83eb2e860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.523650:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1337
[1:1:0712/040940.523898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f23505a0070 0x37a83f9ac2e0 , 5:3_http://www.hebnews.cn/, 0, , 1240 0x7f23505a0070 0x37a83f4d5460 
[1:1:0712/040940.524294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040940.525169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040940.525399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040940.549757:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040940.550026:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040940.550391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1338
[1:1:0712/040940.550663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f23505a0070 0x37a83f61e960 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1240 0x7f23505a0070 0x37a83f4d5460 
[1:1:0712/040940.938082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1251, 7f2352ee58db
[1:1:0712/040940.978874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1147 0x7f23505a0070 0x37a83f699660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.979292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1147 0x7f23505a0070 0x37a83f699660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040940.979797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1345
[1:1:0712/040940.979999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7f23505a0070 0x37a83f689860 , 5:3_http://www.hebnews.cn/, 0, , 1251 0x7f23505a0070 0x37a83de678e0 
[1:1:0712/040940.980338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040940.980970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040940.981178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040941.067731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040941.067909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040941.209153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1253, 7f2352ee5881
[1:1:0712/040941.257967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1156 0x7f23505a0070 0x37a83f6a73e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.258179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1156 0x7f23505a0070 0x37a83f6a73e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.258419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040941.258816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040941.259042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040941.259353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040941.259455:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040941.259622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1352
[1:1:0712/040941.259847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1352 0x7f23505a0070 0x37a83f6a6760 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1253 0x7f23505a0070 0x37a83de63ee0 
[1:1:0712/040941.590826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1166, 7f2352ee58db
[1:1:0712/040941.649889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1037 0x7f23505a0070 0x37a83de65960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.650198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1037 0x7f23505a0070 0x37a83de65960 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.650575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1355
[1:1:0712/040941.650779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1355 0x7f23505a0070 0x37a83e97a160 , 5:3_http://www.hebnews.cn/, 0, , 1166 0x7f23505a0070 0x37a83f6aa3e0 
[1:1:0712/040941.651155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040941.651632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/040941.651861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040941.652773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1270, 7f2352ee5881
[1:1:0712/040941.698219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1103 0x7f23505a0070 0x37a83f692160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.698645:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1103 0x7f23505a0070 0x37a83f692160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040941.699142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040941.699770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040941.700025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040942.111193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1281, 7f2352ee58db
[1:1:0712/040942.162317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1168 0x7f23505a0070 0x37a83f6305e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040942.162523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1168 0x7f23505a0070 0x37a83f6305e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040942.162778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1362
[1:1:0712/040942.162896:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7f23505a0070 0x37a83fdcdfe0 , 5:3_http://www.hebnews.cn/, 0, , 1281 0x7f23505a0070 0x37a83d474ee0 
[1:1:0712/040942.163126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040942.163409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040942.163543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040942.413892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1268, 7f2352ee58db
[1:1:0712/040942.432948:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1103 0x7f23505a0070 0x37a83f692160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040942.433193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1103 0x7f23505a0070 0x37a83f692160 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040942.433469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1366
[1:1:0712/040942.433601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1366 0x7f23505a0070 0x37a83fe04260 , 5:3_http://www.hebnews.cn/, 0, , 1268 0x7f23505a0070 0x37a83f9aaee0 
[1:1:0712/040942.433801:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040942.434188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , () {
                    $btn.last().click()
                }
[1:1:0712/040942.434309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040942.451315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040942.451488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040942.451698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1367
[1:1:0712/040942.451805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7f23505a0070 0x37a83fdc42e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1268 0x7f23505a0070 0x37a83f9aaee0 
[1:1:0712/040942.459860:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/040942.460142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1368
[1:1:0712/040942.460256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7f23505a0070 0x37a83e8c6c60 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1268 0x7f23505a0070 0x37a83f9aaee0 
[1:1:0712/040942.474786:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/040942.653915:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/040943.121955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1319, "http://www.hebnews.cn/"
[1:1:0712/040943.122733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , ___adblockplus({"queryid" : "696bb3792b5177ca","tuid" : "3229894_0","placement" : {"basic" : {"sspId
[1:1:0712/040943.122863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040943.142131:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[71779:71779:0712/040943.145249:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040943.148593:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x37a83f933820
[1:1:0712/040943.148882:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[71779:71779:0712/040943.153077:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229894_0, 8, 8, 
[71779:71779:0712/040943.189718:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://www.hebnews.cn/, http://www.hebnews.cn/, 8
[71779:71779:0712/040943.189851:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040943.192369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/040943.246441:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 252f337f4d80, 5:3_http://www.hebnews.cn/, 5:8_http://www.hebnews.cn/, about:blank
[1:1:0712/040943.246780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/, 252f337f4d80, 252f33742860, open, 
[1:1:0712/040943.247094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 8, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040943.249824:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:727:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929779&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929780&exps=110011:1:1

[1:1:0712/040943.255581:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1319, "http://www.hebnews.cn/"
[1:1:0712/040943.266660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 5000
[1:1:0712/040943.267244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1413
[1:1:0712/040943.267504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7f23505a0070 0x37a83fdb1160 , 5:3_http://www.hebnews.cn/, 2, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/, 1319
[1:1:0712/040943.274517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:8_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 252f33742860, 252f337f4d80, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/040943.274886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/040943.275843:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229894&dri=0&dis=0&dai=0&ps=1878x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929779&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929780&exps=110011:1:1

[1:1:0712/040943.334860:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1319, "http://www.hebnews.cn/"
[71779:71779:0712/040943.441555:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929783&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929783&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[71779:71779:0712/040943.454828:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929783&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929783&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/040943.964010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1330 0x7f2366c2a080 0x37a83fc2cba0 1 0 0x37a83fc2cbb8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040943.982790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 252f33855a18, , , var country = [];
country['africa']="algeria-A 阿尔及利亚-algeria|angola-A 安哥拉-angola|egy
[1:1:0712/040943.983157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040943.994307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1330 0x7f2366c2a080 0x37a83fc2cba0 1 0 0x37a83fc2cbb8 , "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040944.003220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1207, 7f2352ee58db
[1:1:0712/040944.033740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1107 0x7f23505a0070 0x37a83ee745e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.033941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1107 0x7f23505a0070 0x37a83ee745e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.034149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1447
[1:1:0712/040944.034267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1447 0x7f23505a0070 0x37a83ffca2e0 , 5:3_http://www.hebnews.cn/, 0, , 1207 0x7f23505a0070 0x37a83f5227e0 
[1:1:0712/040944.034544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.034833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){w?p--:p++,ab()}
[1:1:0712/040944.034936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.104879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1332, 7f2352ee58db
[1:1:0712/040944.169328:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1235 0x7f23505a0070 0x37a83e981e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.169716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1235 0x7f23505a0070 0x37a83e981e60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.170300:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1451
[1:1:0712/040944.170595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1451 0x7f23505a0070 0x37a83f690760 , 5:3_http://www.hebnews.cn/, 0, , 1332 0x7f23505a0070 0x37a83f62a660 
[1:1:0712/040944.171081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.171814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040944.172103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.221488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1337, 7f2352ee58db
[1:1:0712/040944.252760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1240 0x7f23505a0070 0x37a83f4d5460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.252951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1240 0x7f23505a0070 0x37a83f4d5460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.253197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1456
[1:1:0712/040944.253315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1456 0x7f23505a0070 0x37a83e8cf4e0 , 5:3_http://www.hebnews.cn/, 0, , 1337 0x7f23505a0070 0x37a83f9ac2e0 
[1:1:0712/040944.253537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.253850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040944.253959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.527905:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1338, 7f2352ee5881
[1:1:0712/040944.587059:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1240 0x7f23505a0070 0x37a83f4d5460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.587438:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1240 0x7f23505a0070 0x37a83f4d5460 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.587937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.588455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040944.588735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.717155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1329, 7f2352ee58db
[1:1:0712/040944.781245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1119 0x7f23505a0070 0x37a83f692560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.781658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1119 0x7f23505a0070 0x37a83f692560 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.782209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1469
[1:1:0712/040944.782484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1469 0x7f23505a0070 0x37a83ffcabe0 , 5:3_http://www.hebnews.cn/, 0, , 1329 0x7f23505a0070 0x37a83f693a60 
[1:1:0712/040944.782935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.783411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 252f338034b0, , , () { roll(); }
[1:1:0712/040944.783746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040944.787143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1345, 7f2352ee58db
[1:1:0712/040944.844398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1251 0x7f23505a0070 0x37a83de678e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.844621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1251 0x7f23505a0070 0x37a83de678e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040944.844933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1471
[1:1:0712/040944.845096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1471 0x7f23505a0070 0x37a83dd66160 , 5:3_http://www.hebnews.cn/, 0, , 1345 0x7f23505a0070 0x37a83f689860 
[1:1:0712/040944.845370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040944.845791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040944.845919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.920485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040944.920691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040944.996091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1352, 7f2352ee5881
[1:1:0712/040945.060309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1253 0x7f23505a0070 0x37a83de63ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.060740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1253 0x7f23505a0070 0x37a83de63ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.061131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040945.061660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040945.061842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040945.062618:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040945.062818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040945.063137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1474
[1:1:0712/040945.063328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1474 0x7f23505a0070 0x37a83fe83160 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1352 0x7f23505a0070 0x37a83f6a6760 
[1:1:0712/040945.146573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1367, 7f2352ee5881
[1:1:0712/040945.199105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.199309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.199517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040945.200027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040945.200274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040945.236135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1368, 7f2352ee58db
[1:1:0712/040945.263049:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.263266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.263533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1480
[1:1:0712/040945.263650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1480 0x7f23505a0070 0x37a83f77a6e0 , 5:3_http://www.hebnews.cn/, 0, , 1368 0x7f23505a0070 0x37a83e8c6c60 
[1:1:0712/040945.263900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040945.264190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/040945.264297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040945.399364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1366, 7f2352ee58db
[1:1:0712/040945.445197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.445400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1268 0x7f23505a0070 0x37a83f9aaee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.445639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1483
[1:1:0712/040945.445812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7f23505a0070 0x37a83ef8d160 , 5:3_http://www.hebnews.cn/, 0, , 1366 0x7f23505a0070 0x37a83fe04260 
[1:1:0712/040945.446023:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040945.446321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , () {
                    $btn.last().click()
                }
[1:1:0712/040945.446433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040945.462538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040945.462710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040945.462960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1484
[1:1:0712/040945.463079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1484 0x7f23505a0070 0x37a83f6c2460 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1366 0x7f23505a0070 0x37a83fe04260 
[1:1:0712/040945.482264:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/040945.482670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1485
[1:1:0712/040945.482946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1485 0x7f23505a0070 0x37a83e9654e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1366 0x7f23505a0070 0x37a83fe04260 
[1:1:0712/040945.681733:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/040945.756766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1355, 7f2352ee58db
[1:1:0712/040945.828534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1166 0x7f23505a0070 0x37a83f6aa3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.828743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1166 0x7f23505a0070 0x37a83f6aa3e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040945.829053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1492
[1:1:0712/040945.829179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1492 0x7f23505a0070 0x37a83eb719e0 , 5:3_http://www.hebnews.cn/, 0, , 1355 0x7f23505a0070 0x37a83e97a160 
[1:1:0712/040945.829367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040945.829673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/040945.829781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040948.360537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432, "http://www.hebnews.cn/"
[1:1:0712/040948.361283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , ___adblockplus({"queryid" : "c997f9ff21928c20","tuid" : "3229899_0","placement" : {"basic" : {"sspId
[1:1:0712/040948.361504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040948.383345:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[71779:71779:0712/040948.387037:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/040948.388553:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x37a83e8e6a20
[1:1:0712/040948.389336:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[71779:71779:0712/040948.398972:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe3229899_0, 9, 9, 
[71779:71779:0712/040948.439066:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://www.hebnews.cn/, http://www.hebnews.cn/, 9
[71779:71779:0712/040948.439235:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://www.hebnews.cn/, http://www.hebnews.cn
[1:1:0712/040948.451249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hebnews.cn/"
[1:1:0712/040948.501848:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 252f337d0100, 5:3_http://www.hebnews.cn/, 5:9_http://www.hebnews.cn/, about:blank
[1:1:0712/040948.502138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.hebnews.cn/-5:9_http://www.hebnews.cn/, 252f337d0100, 252f33742860, open, 
[1:1:0712/040948.502439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.hebnews.cn", 9, 2, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040948.505753:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.renderFrame (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	HTMLIFrameElement.onload (http://www.hebnews.cn/:741:10)
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929783&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929783&exps=110011:1:1

[1:1:0712/040948.522290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.hebnews.cn/-5:9_http://www.hebnews.cn/-5:3_http://www.hebnews.cn/, 252f33742860, 252f337d0100, regisetViewWatch, (t){this.isEventInited||(this.initializeEvent(),this.isEventInited=!0),this.watchingList=this.watchi
[1:1:0712/040948.523143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 3, , , 0
[1:1:0712/040948.524104:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.render (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.painterLoadedCallback (http://dup.baidustatic.com/js/ds.js:1:1)
	Object.callback (http://dup.baidustatic.com/js/ds.js:1:1)
	http://dup.baidustatic.com/js/ds.js:1:1
	http://pos.baidu.com/rclm?psi=927aea032fb639106c87a02f4d4bd49a&di=3229899&dri=0&dis=0&dai=0&ps=1878x930&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562929733726&ti=%E6%B2%B3%E5%8C%97%E6%96%B0%E9%97%BB%E7%BD%91_%E6%B2%B3%E5%8C%97%E6%9C%80%E5%A4%A7%E7%9A%84%E7%BD%91%E7%BB%9C%E5%AA%92%E4%BD%93_%E6%B2%B3%E5%8C%97%E7%AC%AC%E4%B8%80%E6%96%B0%E9%97%BB%E9%97%A8%E6%88%B7%E7%BD%91%E7%AB%99_%E6%B2%B3%E5%8C%97%E6%97%A5%E6%8A%A5%E6%8A%A5%E4%B8%9A%E9%9B%86%E5%9B%A2%E4%B8%BB%E5%8A%9E&ari=2&dbv=2&drs=1&pcs=1025x502&pss=1215x1983&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562929783&rw=517&ltu=http%3A%2F%2Fwww.hebnews.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562929783&exps=110011:1:1

[1:1:0712/040948.586966:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0189741, 117, 1
[1:1:0712/040948.587305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/040948.855789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1438, "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040948.861246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 252f33855a18, , , function reflow(){var a=document.body;a.style.zoom=a.style.zoom=="1"?"100%":"1"}function handleAqi()
[1:1:0712/040948.861589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040949.143480:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1441, "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040949.145163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tianqi.2345.com/, 252f33855a18, , , var urlref = encodeURIComponent(document.referrer);var oLO="";if(window.oldurl)oLO="&oLO="+encodeURI
[1:1:0712/040949.145446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left", "tianqi.2345.com", 4, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040949.153174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tianqi.2345.com/plugin/widget/index.htm?s=3&z=3&t=0&v=0&d=2&bd=0&k=&f=&q=1&e=1&a=1&c=53698&w=180&h=36&align=left"
[1:1:0712/040949.421161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1362, 7f2352ee58db
[1:1:0712/040949.497899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1281 0x7f23505a0070 0x37a83d474ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040949.498187:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1281 0x7f23505a0070 0x37a83d474ee0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040949.498670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1640
[1:1:0712/040949.498940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1640 0x7f23505a0070 0x37a83e97a760 , 5:3_http://www.hebnews.cn/, 0, , 1362 0x7f23505a0070 0x37a83fdcdfe0 
[1:1:0712/040949.499364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040949.500024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://www.hebnews.cn/, 252f3382d6f8, , , () { roll(); }
[1:1:0712/040949.500316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 6, 1, http://www.hebnews.cn, www.hebnews.cn, 3
[1:1:0712/040949.738978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1451, 7f2352ee58db
[1:1:0712/040949.816687:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1332 0x7f23505a0070 0x37a83f62a660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040949.817013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1332 0x7f23505a0070 0x37a83f62a660 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040949.817439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1648
[1:1:0712/040949.817650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1648 0x7f23505a0070 0x37a83fdb1a60 , 5:3_http://www.hebnews.cn/, 0, , 1451 0x7f23505a0070 0x37a83f690760 
[1:1:0712/040949.818023:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040949.818540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040949.818711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040950.109308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1456, 7f2352ee58db
[1:1:0712/040950.183614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1337 0x7f23505a0070 0x37a83f9ac2e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.184013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1337 0x7f23505a0070 0x37a83f9ac2e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.184481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1660
[1:1:0712/040950.184684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1660 0x7f23505a0070 0x37a8403a67e0 , 5:3_http://www.hebnews.cn/, 0, , 1456 0x7f23505a0070 0x37a83e8cf4e0 
[1:1:0712/040950.185001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040950.185371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , ab, (a){if(!A||M!=p||a||R){if(R?p>=1?p=1:0>=p&&(p=0):(O=p,p>=k?p=0:0>p&&(p=k-1)),S(),null!=n&&_(l.childr
[1:1:0712/040950.185498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040950.659171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , document.readyState
[1:1:0712/040950.659396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040950.662062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1471, 7f2352ee58db
[1:1:0712/040950.736736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1345 0x7f23505a0070 0x37a83f689860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.736929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1345 0x7f23505a0070 0x37a83f689860 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.737303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1677
[1:1:0712/040950.737509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1677 0x7f23505a0070 0x37a8404773e0 , 5:3_http://www.hebnews.cn/, 0, , 1471 0x7f23505a0070 0x37a83dd66160 
[1:1:0712/040950.737855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040950.738223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/040950.738334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040950.839322:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1474, 7f2352ee5881
[1:1:0712/040950.881802:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1352 0x7f23505a0070 0x37a83f6a6760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.882213:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1352 0x7f23505a0070 0x37a83f6a6760 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040950.882653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040950.883343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/040950.883595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040950.884650:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040950.884958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 100
[1:1:0712/040950.885422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1680
[1:1:0712/040950.885713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1680 0x7f23505a0070 0x37a8403ae7e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1474 0x7f23505a0070 0x37a83fe83160 
[1:1:0712/040951.052239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1447, 7f2352ee58db
[1:1:0712/040951.100607:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1207 0x7f23505a0070 0x37a83f5227e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.100794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1207 0x7f23505a0070 0x37a83f5227e0 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.101044:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1688
[1:1:0712/040951.101189:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1688 0x7f23505a0070 0x37a840479ce0 , 5:3_http://www.hebnews.cn/, 0, , 1447 0x7f23505a0070 0x37a83ffca2e0 
[1:1:0712/040951.101382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040951.101693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){w?p--:p++,ab()}
[1:1:0712/040951.101828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040951.150390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1484, 7f2352ee5881
[1:1:0712/040951.176803:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.177039:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.177467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040951.177975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , (){qn=t}
[1:1:0712/040951.178211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040951.179282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1485, 7f2352ee58db
[1:1:0712/040951.240287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"252f33742860","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.240527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hebnews.cn/","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.240769:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1691
[1:1:0712/040951.240887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1691 0x7f23505a0070 0x37a83fdb43e0 , 5:3_http://www.hebnews.cn/, 0, , 1485 0x7f23505a0070 0x37a83e9654e0 
[1:1:0712/040951.241089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040951.241423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , v.fx.tick, (){var e,n=v.timers,r=0;qn=v.now();for(;r<n.length;r++)e=n[r],!e()&&n[r]===e&&n.splice(r--,1);n.leng
[1:1:0712/040951.241549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040951.452533:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1483, 7f2352ee58db
[1:1:0712/040951.520463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.520901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1366 0x7f23505a0070 0x37a83fe04260 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.521421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1697
[1:1:0712/040951.521631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1697 0x7f23505a0070 0x37a84046ece0 , 5:3_http://www.hebnews.cn/, 0, , 1483 0x7f23505a0070 0x37a83ef8d160 
[1:1:0712/040951.521989:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040951.522527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hebnews.cn/, 252f33742860, , , () {
                    $btn.last().click()
                }
[1:1:0712/040951.522710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 3, 1, , , 0
[1:1:0712/040951.558514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1d1bdcd429c8, 0x37a83d2df950
[1:1:0712/040951.558829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 0
[1:1:0712/040951.559266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hebnews.cn/, 1698
[1:1:0712/040951.559524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1698 0x7f23505a0070 0x37a840385ce0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1483 0x7f23505a0070 0x37a83ef8d160 
[1:1:0712/040951.587223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hebnews.cn/", 13
[1:1:0712/040951.587608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1699
[1:1:0712/040951.587804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1699 0x7f23505a0070 0x37a83efad8e0 , 5:3_http://www.hebnews.cn/, 1, -5:3_http://www.hebnews.cn/, 1483 0x7f23505a0070 0x37a83ef8d160 
[1:1:0712/040951.745902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://www.hebnews.cn/"
[1:1:0712/040951.748654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1469, 7f2352ee58db
[1:1:0712/040951.799349:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1329 0x7f23505a0070 0x37a83f693a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.799680:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1329 0x7f23505a0070 0x37a83f693a60 ","rf":"5:3_http://www.hebnews.cn/"}
[1:1:0712/040951.800161:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hebnews.cn/, 1704
[1:1:0712/040951.800474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1704 0x7f23505a0070 0x37a840282860 , 5:3_http://www.hebnews.cn/, 0, , 1469 0x7f23505a0070 0x37a83ffcabe0 
[1:1:0712/040951.800895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hebnews.cn/"
[1:1:0712/040951.801482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://www.hebnews.cn/, 252f338034b0, , , () { roll(); }
[1:1:0712/040951.801750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hebnews.cn/", "www.hebnews.cn", 7, 1, http://www.hebnews.cn, www.hebnews.cn, 3
