[0712/042136.495561:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042136.496006:INFO:switcher_clone.cc(787)] backtrace rip is 7f5d5660e891
[0712/042137.443232:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042137.443646:INFO:switcher_clone.cc(787)] backtrace rip is 7f147d951891
[1:1:0712/042137.455934:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/042137.456185:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/042137.462492:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[73723:73723:0712/042138.768279:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4b4356c7-6a93-42ce-a739-a3fe415fadf7
[0712/042139.104770:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042139.105192:INFO:switcher_clone.cc(787)] backtrace rip is 7f93ad2c3891
[73723:73723:0712/042139.140854:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[73723:73754:0712/042139.141597:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/042139.141806:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042139.142046:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042139.142629:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042139.142792:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/042139.146094:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d2f94a8, 1
[1:1:0712/042139.146433:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2be2442d, 0
[1:1:0712/042139.146634:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xfc2f82b, 3
[1:1:0712/042139.146832:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26d9bacf, 2
[1:1:0712/042139.147095:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2d44ffffffe22b ffffffa8ffffff942f2d ffffffcfffffffbaffffffd926 2bfffffff8ffffffc20f , 10104, 4
[1:1:0712/042139.148128:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[73723:73754:0712/042139.148394:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING-D�+��/-Ϻ�&+��!k'
[73723:73754:0712/042139.148462:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is -D�+��/-Ϻ�&+����!k'
[1:1:0712/042139.148388:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f147bb8c0a0, 3
[1:1:0712/042139.148640:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f147bd17080, 2
[73723:73754:0712/042139.148752:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[73723:73754:0712/042139.148835:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 73769, 4, 2d44e22b a8942f2d cfbad926 2bf8c20f 
[1:1:0712/042139.148805:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f14659dad20, -2
[1:1:0712/042139.168197:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042139.169062:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26d9bacf
[1:1:0712/042139.170018:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26d9bacf
[1:1:0712/042139.171604:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26d9bacf
[1:1:0712/042139.173110:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.173325:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.173508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.173688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.174198:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26d9bacf
[1:1:0712/042139.174411:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f147d9517ba
[1:1:0712/042139.174537:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f147d948def, 7f147d95177a, 7f147d9530cf
[1:1:0712/042139.176810:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26d9bacf
[1:1:0712/042139.177058:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26d9bacf
[1:1:0712/042139.177458:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26d9bacf
[1:1:0712/042139.178503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.178660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.178793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.178924:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d9bacf
[1:1:0712/042139.179634:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26d9bacf
[1:1:0712/042139.179857:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f147d9517ba
[1:1:0712/042139.179967:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f147d948def, 7f147d95177a, 7f147d9530cf
[1:1:0712/042139.183327:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042139.183658:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042139.183771:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd65deb858, 0x7ffd65deb7d8)
[1:1:0712/042139.197457:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042139.203200:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[73756:73756:0712/042139.323460:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=73756
[73783:73783:0712/042139.323881:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=73783
[73723:73723:0712/042139.629863:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73723:73723:0712/042139.630702:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73723:73723:0712/042139.645919:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[73723:73723:0712/042139.646016:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[73723:73723:0712/042139.646175:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,73769, 4
[73723:73735:0712/042139.646968:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[73723:73735:0712/042139.647054:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/042139.648809:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[73723:73748:0712/042139.686045:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/042139.737660:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x36aeaff4b220
[1:1:0712/042139.737923:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/042139.956328:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[73723:73723:0712/042141.450454:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[73723:73723:0712/042141.450602:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042141.469799:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042141.473964:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042142.608331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042142.608661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042142.624999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042142.625235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042142.641575:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042143.074757:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042143.075033:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042143.489980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042143.498106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042143.498346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042143.533325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042143.543686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042143.543951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042143.555661:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[73723:73723:0712/042143.558119:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042143.559031:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36aeaff49e20
[1:1:0712/042143.559248:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[73723:73723:0712/042143.564659:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[73723:73723:0712/042143.598259:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[73723:73723:0712/042143.598415:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042143.677762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042144.629622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f14675b52e0 0x36aeb01e4d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042144.630283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/042144.630420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042144.630934:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[73723:73723:0712/042144.701548:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042144.704261:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x36aeaff4a820
[1:1:0712/042144.704517:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[73723:73723:0712/042144.708717:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/042144.719268:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042144.719425:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[73723:73723:0712/042144.727321:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[73723:73723:0712/042144.739205:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73723:73723:0712/042144.740512:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73723:73735:0712/042144.748217:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[73723:73735:0712/042144.748301:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[73723:73723:0712/042144.748580:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[73723:73723:0712/042144.748677:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[73723:73723:0712/042144.748852:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,73769, 4
[1:7:0712/042144.752383:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042145.272557:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/042145.886325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f14675b52e0 0x36aeb02f04e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042145.887343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06a630cc1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/042145.887587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042145.888437:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[73723:73723:0712/042145.980023:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[73723:73723:0712/042145.980139:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/042146.000497:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042146.482493:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[73723:73723:0712/042146.739327:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[73723:73754:0712/042146.739989:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/042146.740236:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042146.740457:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042146.740867:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042146.741025:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/042146.744380:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11bee15b, 1
[1:1:0712/042146.744932:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2bbbd55, 0
[1:1:0712/042146.745201:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x245fe55b, 3
[1:1:0712/042146.745469:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x140b202a, 2
[1:1:0712/042146.745721:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 55ffffffbdffffffbb02 5bffffffe1ffffffbe11 2a200b14 5bffffffe55f24 , 10104, 5
[1:1:0712/042146.747308:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[73723:73754:0712/042146.747747:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGU��[�* [�_$�!k'
[73723:73754:0712/042146.747841:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is U��[�* [�_$Hz�!k'
[1:1:0712/042146.747733:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f147bb8c0a0, 3
[73723:73754:0712/042146.748125:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 73819, 5, 55bdbb02 5be1be11 2a200b14 5be55f24 
[1:1:0712/042146.748117:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f147bd17080, 2
[1:1:0712/042146.748436:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f14659dad20, -2
[1:1:0712/042146.772640:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042146.773140:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 140b202a
[1:1:0712/042146.773532:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 140b202a
[1:1:0712/042146.774263:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 140b202a
[1:1:0712/042146.775810:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.776186:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.776438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.776669:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.777411:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 140b202a
[1:1:0712/042146.777763:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f147d9517ba
[1:1:0712/042146.777934:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f147d948def, 7f147d95177a, 7f147d9530cf
[1:1:0712/042146.784010:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 140b202a
[1:1:0712/042146.784381:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 140b202a
[1:1:0712/042146.785152:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 140b202a
[1:1:0712/042146.786328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.786460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.786558:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.786656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 140b202a
[1:1:0712/042146.787149:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 140b202a
[1:1:0712/042146.787319:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f147d9517ba
[1:1:0712/042146.787403:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f147d948def, 7f147d95177a, 7f147d9530cf
[1:1:0712/042146.789708:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042146.790080:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042146.790174:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd65deb858, 0x7ffd65deb7d8)
[1:1:0712/042146.805183:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042146.809771:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/042147.042858:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x36aeaff1a220
[1:1:0712/042147.043161:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/042147.135844:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042147.136126:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[73723:73723:0712/042147.332404:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73723:73723:0712/042147.340149:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73723:73735:0712/042147.369817:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[73723:73735:0712/042147.369924:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[73723:73723:0712/042147.369981:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://jxja.jxnews.com.cn/
[73723:73723:0712/042147.370095:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jxja.jxnews.com.cn/, http://jxja.jxnews.com.cn/thx/, 1
[73723:73723:0712/042147.370263:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://jxja.jxnews.com.cn/, HTTP/1.1 200 OK Server: nginx/1.5.7 Date: Fri, 12 Jul 2019 11:06:44 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Set-Cookie: insert_cookie=92835365; path=/  ,73819, 5
[1:7:0712/042147.376508:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042147.406547:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://jxja.jxnews.com.cn/
[73723:73723:0712/042147.506367:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jxja.jxnews.com.cn/, http://jxja.jxnews.com.cn/, 1
[73723:73723:0712/042147.506481:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://jxja.jxnews.com.cn/, http://jxja.jxnews.com.cn
[1:1:0712/042147.537449:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042147.548150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042147.553262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06a630dee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/042147.553690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/042147.561650:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042147.621337:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042147.718259:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042147.718547:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042148.040948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 152, "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042148.046553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , /**
 * SWFObject v1.5: Flash Player detection and embed - http://blog.deconcept.com/swfobject/
 *
 *
[1:1:0712/042148.046807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042148.112163:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0603082, 240, 1
[1:1:0712/042148.112497:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042148.385591:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042148.385840:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042148.389292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 183 0x7f146568d070 0x36aeb00cb1e0 , "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042148.393875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , if(typeof sas=="undefined")var sas=new Object();if(typeof sas.ued=="undefined")sas.ued=new Object();
[1:1:0712/042148.394167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042148.400193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 183 0x7f146568d070 0x36aeb00cb1e0 , "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042148.405775:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042148.554907:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042148.558648:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x36aeafb2e820
[1:1:0712/042148.558853:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/042148.569924:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042148.570138:INFO:render_frame_impl.cc(7019)] 	 [url] = http://jxja.jxnews.com.cn
[1:1:0712/042148.590202:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204255, 1718, 1
[1:1:0712/042148.590459:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042148.889894:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042148.890336:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042148.893499:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042148.893893:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042148.894231:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042149.142025:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042149.142309:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042149.143153:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f146568d070 0x36aeaff5f4e0 , "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042149.144346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , ,  
  var speed=50//速度数值越大速度越慢 
  demo2.innerHTML=demo1.innerHTML 
  function Marq
[1:1:0712/042149.144600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042149.179384:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jxja.jxnews.com.cn/thx/", 50
[1:1:0712/042149.179845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 276
[1:1:0712/042149.180074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 276 0x7f146568d070 0x36aeb002dfe0 , 5:3_http://jxja.jxnews.com.cn/, 1, -5:3_http://jxja.jxnews.com.cn/, 233 0x7f146568d070 0x36aeaff5f4e0 
[1:1:0712/042149.966335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 276, 7f1467fd28db
[1:1:0712/042149.981539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2e9cb38a2860","ptid":"233 0x7f146568d070 0x36aeaff5f4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042149.981903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jxja.jxnews.com.cn/","ptid":"233 0x7f146568d070 0x36aeaff5f4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042149.982250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 315
[1:1:0712/042149.982476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 315 0x7f146568d070 0x36aeafb47ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 276 0x7f146568d070 0x36aeb002dfe0 
[1:1:0712/042149.982817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042149.983393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042149.983664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.098547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 315, 7f1467fd28db
[1:1:0712/042151.107109:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"276 0x7f146568d070 0x36aeb002dfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.107395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"276 0x7f146568d070 0x36aeb002dfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.107741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 326
[1:1:0712/042151.107988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f146568d070 0x36aeb0186160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 315 0x7f146568d070 0x36aeafb47ce0 
[1:1:0712/042151.108309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.108837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.109055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.144152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 326, 7f1467fd28db
[1:1:0712/042151.158066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"315 0x7f146568d070 0x36aeafb47ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.158349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"315 0x7f146568d070 0x36aeafb47ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.158676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 329
[1:1:0712/042151.158903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 329 0x7f146568d070 0x36aeb0189060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 326 0x7f146568d070 0x36aeb0186160 
[1:1:0712/042151.159216:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.159741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.159983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.185627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 329, 7f1467fd28db
[1:1:0712/042151.194197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"326 0x7f146568d070 0x36aeb0186160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.194460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"326 0x7f146568d070 0x36aeb0186160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.194787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 331
[1:1:0712/042151.195047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f146568d070 0x36aeb0193e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 329 0x7f146568d070 0x36aeb0189060 
[1:1:0712/042151.195376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.195889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.196167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.235341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 331, 7f1467fd28db
[1:1:0712/042151.240400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"329 0x7f146568d070 0x36aeb0189060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.240655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"329 0x7f146568d070 0x36aeb0189060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.241008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 333
[1:1:0712/042151.241245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f146568d070 0x36aeb0200260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 331 0x7f146568d070 0x36aeb0193e60 
[1:1:0712/042151.241558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.242109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.242326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.287740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 333, 7f1467fd28db
[1:1:0712/042151.301028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"331 0x7f146568d070 0x36aeb0193e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.301313:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"331 0x7f146568d070 0x36aeb0193e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.301653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 335
[1:1:0712/042151.301879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 335 0x7f146568d070 0x36aeb01c6460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 333 0x7f146568d070 0x36aeb0200260 
[1:1:0712/042151.302137:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.302668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.302905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.341725:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 335, 7f1467fd28db
[1:1:0712/042151.348198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"333 0x7f146568d070 0x36aeb0200260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.348463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"333 0x7f146568d070 0x36aeb0200260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.348794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 337
[1:1:0712/042151.349034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 337 0x7f146568d070 0x36aeb00cac60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 335 0x7f146568d070 0x36aeb01c6460 
[1:1:0712/042151.349347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.349871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.350145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.394284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 337, 7f1467fd28db
[1:1:0712/042151.401031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"335 0x7f146568d070 0x36aeb01c6460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.401301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"335 0x7f146568d070 0x36aeb01c6460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.401633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 339
[1:1:0712/042151.401858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 339 0x7f146568d070 0x36aeb002ace0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 337 0x7f146568d070 0x36aeb00cac60 
[1:1:0712/042151.402199:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.402762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.402973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.435220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 339, 7f1467fd28db
[1:1:0712/042151.444756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"337 0x7f146568d070 0x36aeb00cac60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.445055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"337 0x7f146568d070 0x36aeb00cac60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.445396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 341
[1:1:0712/042151.445638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 341 0x7f146568d070 0x36aeb023cae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 339 0x7f146568d070 0x36aeb002ace0 
[1:1:0712/042151.445954:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.446503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.446714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.495014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 341, 7f1467fd28db
[1:1:0712/042151.509327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"339 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.509623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"339 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.509963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 343
[1:1:0712/042151.510231:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 343 0x7f146568d070 0x36aeafb2bfe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 341 0x7f146568d070 0x36aeb023cae0 
[1:1:0712/042151.510561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.511134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.511348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.545707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 343, 7f1467fd28db
[1:1:0712/042151.555971:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"341 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.556281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"341 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.556620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 345
[1:1:0712/042151.556858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 345 0x7f146568d070 0x36aeb0187ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 343 0x7f146568d070 0x36aeafb2bfe0 
[1:1:0712/042151.557176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.557716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.557933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.596243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 345, 7f1467fd28db
[1:1:0712/042151.613386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"343 0x7f146568d070 0x36aeafb2bfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.613702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"343 0x7f146568d070 0x36aeafb2bfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.614066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 348
[1:1:0712/042151.614299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 348 0x7f146568d070 0x36aeafb2bfe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 345 0x7f146568d070 0x36aeb0187ae0 
[1:1:0712/042151.614623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.615189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.615412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.645336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 348, 7f1467fd28db
[1:1:0712/042151.651423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"345 0x7f146568d070 0x36aeb0187ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.651697:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"345 0x7f146568d070 0x36aeb0187ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.652029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 350
[1:1:0712/042151.652290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 350 0x7f146568d070 0x36aeb0175960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 348 0x7f146568d070 0x36aeafb2bfe0 
[1:1:0712/042151.652611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.653170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.653407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.695444:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 350, 7f1467fd28db
[1:1:0712/042151.710203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"348 0x7f146568d070 0x36aeafb2bfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.710489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"348 0x7f146568d070 0x36aeafb2bfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.710838:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 352
[1:1:0712/042151.711065:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 352 0x7f146568d070 0x36aeb0250460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 350 0x7f146568d070 0x36aeb0175960 
[1:1:0712/042151.711418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.711977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.712219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.738382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 352, 7f1467fd28db
[1:1:0712/042151.744876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"350 0x7f146568d070 0x36aeb0175960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.745191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"350 0x7f146568d070 0x36aeb0175960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.745537:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 354
[1:1:0712/042151.745764:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 354 0x7f146568d070 0x36aeb00cb1e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 352 0x7f146568d070 0x36aeb0250460 
[1:1:0712/042151.746102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.746645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.746857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.792923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 354, 7f1467fd28db
[1:1:0712/042151.810268:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"352 0x7f146568d070 0x36aeb0250460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.810561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"352 0x7f146568d070 0x36aeb0250460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.810895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 356
[1:1:0712/042151.811142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7f146568d070 0x36aeb023ce60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 354 0x7f146568d070 0x36aeb00cb1e0 
[1:1:0712/042151.811468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.812028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.812272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.839042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 356, 7f1467fd28db
[1:1:0712/042151.854712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"354 0x7f146568d070 0x36aeb00cb1e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.855032:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"354 0x7f146568d070 0x36aeb00cb1e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.855407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 358
[1:1:0712/042151.855656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 358 0x7f146568d070 0x36aeb01914e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 356 0x7f146568d070 0x36aeb023ce60 
[1:1:0712/042151.855977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.856451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.856671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.892798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 358, 7f1467fd28db
[1:1:0712/042151.911215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"356 0x7f146568d070 0x36aeb023ce60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.911501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"356 0x7f146568d070 0x36aeb023ce60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.911840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 360
[1:1:0712/042151.912066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 360 0x7f146568d070 0x36aeb02001e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 358 0x7f146568d070 0x36aeb01914e0 
[1:1:0712/042151.912408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.912961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.913196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.936671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 360, 7f1467fd28db
[1:1:0712/042151.945427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"358 0x7f146568d070 0x36aeb01914e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.945688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"358 0x7f146568d070 0x36aeb01914e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042151.946014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 362
[1:1:0712/042151.946255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7f146568d070 0x36aeb00b2ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 360 0x7f146568d070 0x36aeb02001e0 
[1:1:0712/042151.946563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042151.947067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042151.947299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042151.995086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 362, 7f1467fd28db
[1:1:0712/042152.011429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"360 0x7f146568d070 0x36aeb02001e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.011719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"360 0x7f146568d070 0x36aeb02001e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.012054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 364
[1:1:0712/042152.012281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7f146568d070 0x36aeb012b3e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 362 0x7f146568d070 0x36aeb00b2ae0 
[1:1:0712/042152.012597:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.013129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.013362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.035439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 364, 7f1467fd28db
[1:1:0712/042152.045878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"362 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.046163:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"362 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.046491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 366
[1:1:0712/042152.046714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 366 0x7f146568d070 0x36aeb024e9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 364 0x7f146568d070 0x36aeb012b3e0 
[1:1:0712/042152.047008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.047518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.047736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.088218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 366, 7f1467fd28db
[1:1:0712/042152.103296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"364 0x7f146568d070 0x36aeb012b3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.103571:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"364 0x7f146568d070 0x36aeb012b3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.103925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 369
[1:1:0712/042152.104151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f146568d070 0x36aeb002dfe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 366 0x7f146568d070 0x36aeb024e9e0 
[1:1:0712/042152.104490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.104998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.105224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.137518:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 369, 7f1467fd28db
[1:1:0712/042152.151978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"366 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.152254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"366 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.152573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 371
[1:1:0712/042152.152788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 371 0x7f146568d070 0x36aeb02418e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 369 0x7f146568d070 0x36aeb002dfe0 
[1:1:0712/042152.153092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.153589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.153794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.195965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 371, 7f1467fd28db
[1:1:0712/042152.204788:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"369 0x7f146568d070 0x36aeb002dfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.205052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"369 0x7f146568d070 0x36aeb002dfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.205405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 373
[1:1:0712/042152.205633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 373 0x7f146568d070 0x36aeb00bcae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 371 0x7f146568d070 0x36aeb02418e0 
[1:1:0712/042152.205937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.206469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.206681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.246147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 373, 7f1467fd28db
[1:1:0712/042152.255258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"371 0x7f146568d070 0x36aeb02418e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.255519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"371 0x7f146568d070 0x36aeb02418e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.255845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 375
[1:1:0712/042152.256069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7f146568d070 0x36aeb0184f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 373 0x7f146568d070 0x36aeb00bcae0 
[1:1:0712/042152.256433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.256940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.257153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.289048:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 375, 7f1467fd28db
[1:1:0712/042152.297776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"373 0x7f146568d070 0x36aeb00bcae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.298050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"373 0x7f146568d070 0x36aeb00bcae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.298387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 377
[1:1:0712/042152.298621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7f146568d070 0x36aeb00fa0e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 375 0x7f146568d070 0x36aeb0184f60 
[1:1:0712/042152.298928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.299447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.299668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.341451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 377, 7f1467fd28db
[1:1:0712/042152.364105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"375 0x7f146568d070 0x36aeb0184f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.364471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"375 0x7f146568d070 0x36aeb0184f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.364854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 379
[1:1:0712/042152.365132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 379 0x7f146568d070 0x36aeb01b49e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 377 0x7f146568d070 0x36aeb00fa0e0 
[1:1:0712/042152.365530:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.366095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.366498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.387468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 379, 7f1467fd28db
[1:1:0712/042152.404598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"377 0x7f146568d070 0x36aeb00fa0e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.404928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"377 0x7f146568d070 0x36aeb00fa0e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.405287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 381
[1:1:0712/042152.405531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 381 0x7f146568d070 0x36aeb01bdd60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 379 0x7f146568d070 0x36aeb01b49e0 
[1:1:0712/042152.405841:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.406421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.406648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.446445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 381, 7f1467fd28db
[1:1:0712/042152.462103:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"379 0x7f146568d070 0x36aeb01b49e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.462408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"379 0x7f146568d070 0x36aeb01b49e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.462750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 383
[1:1:0712/042152.462977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 383 0x7f146568d070 0x36aeb01c66e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 381 0x7f146568d070 0x36aeb01bdd60 
[1:1:0712/042152.463303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.463825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.464054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.495584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 383, 7f1467fd28db
[1:1:0712/042152.514694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"381 0x7f146568d070 0x36aeb01bdd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.514967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"381 0x7f146568d070 0x36aeb01bdd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.515313:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 385
[1:1:0712/042152.515542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 385 0x7f146568d070 0x36aeb00b2ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 383 0x7f146568d070 0x36aeb01c66e0 
[1:1:0712/042152.515855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.516421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.516655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.544005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 385, 7f1467fd28db
[1:1:0712/042152.551011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"383 0x7f146568d070 0x36aeb01c66e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.551296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"383 0x7f146568d070 0x36aeb01c66e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.551702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 387
[1:1:0712/042152.551982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 387 0x7f146568d070 0x36aeb0241760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 385 0x7f146568d070 0x36aeb00b2ae0 
[1:1:0712/042152.552353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.552901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.553159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.589881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 387, 7f1467fd28db
[1:1:0712/042152.594718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"385 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.594982:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"385 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.595315:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 389
[1:1:0712/042152.595537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 389 0x7f146568d070 0x36aeb00c9ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 387 0x7f146568d070 0x36aeb0241760 
[1:1:0712/042152.595856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.596418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.596647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.660748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 389, 7f1467fd28db
[1:1:0712/042152.672691:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"387 0x7f146568d070 0x36aeb0241760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.673184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"387 0x7f146568d070 0x36aeb0241760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.673838:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 391
[1:1:0712/042152.674267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7f146568d070 0x36aeb01b4e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 389 0x7f146568d070 0x36aeb00c9ce0 
[1:1:0712/042152.674863:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.675870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.676385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.690064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 391, 7f1467fd28db
[1:1:0712/042152.720391:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"389 0x7f146568d070 0x36aeb00c9ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.720721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"389 0x7f146568d070 0x36aeb00c9ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.721096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 393
[1:1:0712/042152.721394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 393 0x7f146568d070 0x36aeb023e8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 391 0x7f146568d070 0x36aeb01b4e60 
[1:1:0712/042152.721757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.722310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.722766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.746971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 393, 7f1467fd28db
[1:1:0712/042152.764072:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"391 0x7f146568d070 0x36aeb01b4e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.764552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"391 0x7f146568d070 0x36aeb01b4e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.765127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 395
[1:1:0712/042152.765541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f146568d070 0x36aeb002ac60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 393 0x7f146568d070 0x36aeb023e8e0 
[1:1:0712/042152.766084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.767046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.767410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.785881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 395, 7f1467fd28db
[1:1:0712/042152.802218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"393 0x7f146568d070 0x36aeb023e8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.802506:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"393 0x7f146568d070 0x36aeb023e8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.802825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 397
[1:1:0712/042152.803045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 397 0x7f146568d070 0x36aeb01d3260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 395 0x7f146568d070 0x36aeb002ac60 
[1:1:0712/042152.803368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.803987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.804272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.849923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 397, 7f1467fd28db
[1:1:0712/042152.866211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"395 0x7f146568d070 0x36aeb002ac60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.866785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"395 0x7f146568d070 0x36aeb002ac60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.867346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 399
[1:1:0712/042152.867768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 399 0x7f146568d070 0x36aeb017aa60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 397 0x7f146568d070 0x36aeb01d3260 
[1:1:0712/042152.868292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.869183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.869585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.901795:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 399, 7f1467fd28db
[1:1:0712/042152.918148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"397 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.918481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"397 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.918855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 401
[1:1:0712/042152.919126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 401 0x7f146568d070 0x36aeaf998ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 399 0x7f146568d070 0x36aeb017aa60 
[1:1:0712/042152.919518:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.920058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.920426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042152.954252:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 401, 7f1467fd28db
[1:1:0712/042152.964179:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"399 0x7f146568d070 0x36aeb017aa60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.964621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"399 0x7f146568d070 0x36aeb017aa60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042152.965174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 403
[1:1:0712/042152.965568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 403 0x7f146568d070 0x36aeb00cb3e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 401 0x7f146568d070 0x36aeaf998ce0 
[1:1:0712/042152.966088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042152.967026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042152.967360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.002090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 403, 7f1467fd28db
[1:1:0712/042153.024960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"401 0x7f146568d070 0x36aeaf998ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.025391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"401 0x7f146568d070 0x36aeaf998ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.026029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 405
[1:1:0712/042153.026431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 405 0x7f146568d070 0x36aeb024ef60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 403 0x7f146568d070 0x36aeb00cb3e0 
[1:1:0712/042153.026985:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.027931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.028287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.031384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 405, 7f1467fd28db
[1:1:0712/042153.050227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"403 0x7f146568d070 0x36aeb00cb3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.050716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"403 0x7f146568d070 0x36aeb00cb3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.051311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 407
[1:1:0712/042153.051924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7f146568d070 0x36aeb00fa960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 405 0x7f146568d070 0x36aeb024ef60 
[1:1:0712/042153.052529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.053440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.053782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.098561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 407, 7f1467fd28db
[1:1:0712/042153.109242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"405 0x7f146568d070 0x36aeb024ef60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.109731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"405 0x7f146568d070 0x36aeb024ef60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.110322:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 409
[1:1:0712/042153.110765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 409 0x7f146568d070 0x36aeb0034be0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 407 0x7f146568d070 0x36aeb00fa960 
[1:1:0712/042153.111299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.112335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.112734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.138600:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 409, 7f1467fd28db
[1:1:0712/042153.153718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"407 0x7f146568d070 0x36aeb00fa960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.154131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"407 0x7f146568d070 0x36aeb00fa960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.154713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 411
[1:1:0712/042153.155094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 411 0x7f146568d070 0x36aeb024c160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 409 0x7f146568d070 0x36aeb0034be0 
[1:1:0712/042153.155602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.156250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.156545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.197689:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 411, 7f1467fd28db
[1:1:0712/042153.216076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"409 0x7f146568d070 0x36aeb0034be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.216365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"409 0x7f146568d070 0x36aeb0034be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.216729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 413
[1:1:0712/042153.216962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 413 0x7f146568d070 0x36aeb02515e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 411 0x7f146568d070 0x36aeb024c160 
[1:1:0712/042153.217284:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.217833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.218052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.242841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 413, 7f1467fd28db
[1:1:0712/042153.260655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"411 0x7f146568d070 0x36aeb024c160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.260927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"411 0x7f146568d070 0x36aeb024c160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.261260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 415
[1:1:0712/042153.261528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f146568d070 0x36aeb00ba8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 413 0x7f146568d070 0x36aeb02515e0 
[1:1:0712/042153.261850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.262379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.262611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.302766:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 415, 7f1467fd28db
[1:1:0712/042153.310517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"413 0x7f146568d070 0x36aeb02515e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.310787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"413 0x7f146568d070 0x36aeb02515e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.311125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 417
[1:1:0712/042153.311358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 417 0x7f146568d070 0x36aeb01d3260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 415 0x7f146568d070 0x36aeb00ba8e0 
[1:1:0712/042153.311711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.312239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.312455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.349030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 417, 7f1467fd28db
[1:1:0712/042153.354995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"415 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.355262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"415 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.355615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 419
[1:1:0712/042153.355871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 419 0x7f146568d070 0x36aeb0184860 , 5:3_http://jxja.jxnews.com.cn/, 0, , 417 0x7f146568d070 0x36aeb01d3260 
[1:1:0712/042153.356202:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.356762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.357021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.389614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 419, 7f1467fd28db
[1:1:0712/042153.400050:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"417 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.400334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"417 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.400718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 421
[1:1:0712/042153.400966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7f146568d070 0x36aeb00bafe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 419 0x7f146568d070 0x36aeb0184860 
[1:1:0712/042153.401295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.401864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.402083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.452993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 421, 7f1467fd28db
[1:1:0712/042153.477694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"419 0x7f146568d070 0x36aeb0184860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.478036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"419 0x7f146568d070 0x36aeb0184860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.478429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 423
[1:1:0712/042153.478742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 423 0x7f146568d070 0x36aeb00ffe60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 421 0x7f146568d070 0x36aeb00bafe0 
[1:1:0712/042153.479113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.479752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.480022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.481859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 423, 7f1467fd28db
[1:1:0712/042153.499663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"421 0x7f146568d070 0x36aeb00bafe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.500110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"421 0x7f146568d070 0x36aeb00bafe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.500729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 425
[1:1:0712/042153.501113:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 425 0x7f146568d070 0x36aeafb47260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 423 0x7f146568d070 0x36aeb00ffe60 
[1:1:0712/042153.501685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.502655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.503023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.550567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 425, 7f1467fd28db
[1:1:0712/042153.558588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"423 0x7f146568d070 0x36aeb00ffe60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.558860:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"423 0x7f146568d070 0x36aeb00ffe60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.559195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 427
[1:1:0712/042153.559425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7f146568d070 0x36aeb0242160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 425 0x7f146568d070 0x36aeafb47260 
[1:1:0712/042153.559801:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.560326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.560591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.613628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 427, 7f1467fd28db
[1:1:0712/042153.622253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"425 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.622520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"425 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.622900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 429
[1:1:0712/042153.623137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 429 0x7f146568d070 0x36aeaffcf7e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 427 0x7f146568d070 0x36aeb0242160 
[1:1:0712/042153.623460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.624044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.624270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.639439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 429, 7f1467fd28db
[1:1:0712/042153.648358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"427 0x7f146568d070 0x36aeb0242160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.648657:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"427 0x7f146568d070 0x36aeb0242160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.649004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 431
[1:1:0712/042153.649238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 431 0x7f146568d070 0x36aeb024e3e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 429 0x7f146568d070 0x36aeaffcf7e0 
[1:1:0712/042153.649576:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.650100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.650319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.700878:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 431, 7f1467fd28db
[1:1:0712/042153.711944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"429 0x7f146568d070 0x36aeaffcf7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.712232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"429 0x7f146568d070 0x36aeaffcf7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.712600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 433
[1:1:0712/042153.712900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 433 0x7f146568d070 0x36aeb01fcfe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 431 0x7f146568d070 0x36aeb024e3e0 
[1:1:0712/042153.713221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.713793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.714013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.747876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 433, 7f1467fd28db
[1:1:0712/042153.769233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"431 0x7f146568d070 0x36aeb024e3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.769531:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"431 0x7f146568d070 0x36aeb024e3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.769918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 435
[1:1:0712/042153.770153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 435 0x7f146568d070 0x36aeafc75f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 433 0x7f146568d070 0x36aeb01fcfe0 
[1:1:0712/042153.770497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.771143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.771373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.806408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 435, 7f1467fd28db
[1:1:0712/042153.825734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"433 0x7f146568d070 0x36aeb01fcfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.826014:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"433 0x7f146568d070 0x36aeb01fcfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.826349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 437
[1:1:0712/042153.826579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 437 0x7f146568d070 0x36aeb0191960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 435 0x7f146568d070 0x36aeafc75f60 
[1:1:0712/042153.826932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.827473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.827721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.852105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 437, 7f1467fd28db
[1:1:0712/042153.870319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"435 0x7f146568d070 0x36aeafc75f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.870622:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"435 0x7f146568d070 0x36aeafc75f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.870993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 439
[1:1:0712/042153.871233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7f146568d070 0x36aeb023d9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 437 0x7f146568d070 0x36aeb0191960 
[1:1:0712/042153.871575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.872159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.872377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.889081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 439, 7f1467fd28db
[1:1:0712/042153.894556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"437 0x7f146568d070 0x36aeb0191960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.894825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"437 0x7f146568d070 0x36aeb0191960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.895162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 441
[1:1:0712/042153.895394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7f146568d070 0x36aeaffcf7e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 439 0x7f146568d070 0x36aeb023d9e0 
[1:1:0712/042153.895701:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.896229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.896448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.948987:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 441, 7f1467fd28db
[1:1:0712/042153.970113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"439 0x7f146568d070 0x36aeb023d9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.970394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"439 0x7f146568d070 0x36aeb023d9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042153.970780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 443
[1:1:0712/042153.971015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7f146568d070 0x36aeb00353e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 441 0x7f146568d070 0x36aeaffcf7e0 
[1:1:0712/042153.971331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042153.971894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042153.972133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042153.998943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 443, 7f1467fd28db
[1:1:0712/042154.016940:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"441 0x7f146568d070 0x36aeaffcf7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.017229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"441 0x7f146568d070 0x36aeaffcf7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.017569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 445
[1:1:0712/042154.017825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 445 0x7f146568d070 0x36aeb018a5e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 443 0x7f146568d070 0x36aeb00353e0 
[1:1:0712/042154.018189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.018770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.018992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.048444:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 445, 7f1467fd28db
[1:1:0712/042154.070407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"443 0x7f146568d070 0x36aeb00353e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.070749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"443 0x7f146568d070 0x36aeb00353e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.071096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 447
[1:1:0712/042154.071330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 447 0x7f146568d070 0x36aeb023e8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 445 0x7f146568d070 0x36aeb018a5e0 
[1:1:0712/042154.071714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.072247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.072464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.103360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 447, 7f1467fd28db
[1:1:0712/042154.124984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"445 0x7f146568d070 0x36aeb018a5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.125265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"445 0x7f146568d070 0x36aeb018a5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.125606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 449
[1:1:0712/042154.125891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 449 0x7f146568d070 0x36aeb024e9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 447 0x7f146568d070 0x36aeb023e8e0 
[1:1:0712/042154.126227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.126788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.127010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.149263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 449, 7f1467fd28db
[1:1:0712/042154.155372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"447 0x7f146568d070 0x36aeb023e8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.155635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"447 0x7f146568d070 0x36aeb023e8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.155969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 451
[1:1:0712/042154.156202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 451 0x7f146568d070 0x36aeb0192f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 449 0x7f146568d070 0x36aeb024e9e0 
[1:1:0712/042154.156519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.157053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.157284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.203275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 451, 7f1467fd28db
[1:1:0712/042154.209431:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"449 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.209713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"449 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.210049:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 453
[1:1:0712/042154.210280:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7f146568d070 0x36aeaf998ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 451 0x7f146568d070 0x36aeb0192f60 
[1:1:0712/042154.210596:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.211108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.211332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.253269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 453, 7f1467fd28db
[1:1:0712/042154.275197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"451 0x7f146568d070 0x36aeb0192f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.275474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"451 0x7f146568d070 0x36aeb0192f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.275876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 455
[1:1:0712/042154.276112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7f146568d070 0x36aeb0200260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 453 0x7f146568d070 0x36aeaf998ce0 
[1:1:0712/042154.276433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.277000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.277216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.289031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 455, 7f1467fd28db
[1:1:0712/042154.309809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"453 0x7f146568d070 0x36aeaf998ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.310099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"453 0x7f146568d070 0x36aeaf998ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.310421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 457
[1:1:0712/042154.310646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 457 0x7f146568d070 0x36aeafb47260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 455 0x7f146568d070 0x36aeb0200260 
[1:1:0712/042154.310981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.311473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.311688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.350909:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 457, 7f1467fd28db
[1:1:0712/042154.369406:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"455 0x7f146568d070 0x36aeb0200260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.369687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"455 0x7f146568d070 0x36aeb0200260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.370111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 459
[1:1:0712/042154.370349:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 459 0x7f146568d070 0x36aeb017d460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 457 0x7f146568d070 0x36aeafb47260 
[1:1:0712/042154.370679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.371232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.371481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.399715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 459, 7f1467fd28db
[1:1:0712/042154.415599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"457 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.415926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"457 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.416262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 461
[1:1:0712/042154.416491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 461 0x7f146568d070 0x36aeb0183e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 459 0x7f146568d070 0x36aeb017d460 
[1:1:0712/042154.416828:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.417334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.417547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.452873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 461, 7f1467fd28db
[1:1:0712/042154.464535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"459 0x7f146568d070 0x36aeb017d460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.464843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"459 0x7f146568d070 0x36aeb017d460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.465175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 463
[1:1:0712/042154.465399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7f146568d070 0x36aeb00c68e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 461 0x7f146568d070 0x36aeb0183e60 
[1:1:0712/042154.465705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.466229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.466439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.505157:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 463, 7f1467fd28db
[1:1:0712/042154.511132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"461 0x7f146568d070 0x36aeb0183e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.511405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"461 0x7f146568d070 0x36aeb0183e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.511754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 465
[1:1:0712/042154.512005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f146568d070 0x36aeb00374e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 463 0x7f146568d070 0x36aeb00c68e0 
[1:1:0712/042154.512330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.512878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.513103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.537083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 465, 7f1467fd28db
[1:1:0712/042154.553142:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"463 0x7f146568d070 0x36aeb00c68e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.553422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"463 0x7f146568d070 0x36aeb00c68e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.553759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 467
[1:1:0712/042154.554009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 467 0x7f146568d070 0x36aeb017a9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 465 0x7f146568d070 0x36aeb00374e0 
[1:1:0712/042154.554318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.554835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.555061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.599950:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 467, 7f1467fd28db
[1:1:0712/042154.605905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"465 0x7f146568d070 0x36aeb00374e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.606165:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"465 0x7f146568d070 0x36aeb00374e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.606488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 469
[1:1:0712/042154.606711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f146568d070 0x36aeb0023360 , 5:3_http://jxja.jxnews.com.cn/, 0, , 467 0x7f146568d070 0x36aeb017a9e0 
[1:1:0712/042154.607140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.607661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.607866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.650572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 469, 7f1467fd28db
[1:1:0712/042154.669510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"467 0x7f146568d070 0x36aeb017a9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.669783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"467 0x7f146568d070 0x36aeb017a9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.670158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 471
[1:1:0712/042154.670400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f146568d070 0x36aeb00ba8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 469 0x7f146568d070 0x36aeb0023360 
[1:1:0712/042154.670739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.671315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.671530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.701667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 471, 7f1467fd28db
[1:1:0712/042154.719832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"469 0x7f146568d070 0x36aeb0023360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.720106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"469 0x7f146568d070 0x36aeb0023360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.720433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 473
[1:1:0712/042154.720658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7f146568d070 0x36aeb00c9de0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 471 0x7f146568d070 0x36aeb00ba8e0 
[1:1:0712/042154.721009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.721533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.721748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.749669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 473, 7f1467fd28db
[1:1:0712/042154.772946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"471 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.773227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"471 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.773555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 475
[1:1:0712/042154.773778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 475 0x7f146568d070 0x36aeb00f2560 , 5:3_http://jxja.jxnews.com.cn/, 0, , 473 0x7f146568d070 0x36aeb00c9de0 
[1:1:0712/042154.774107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.774612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.774866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.800377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 475, 7f1467fd28db
[1:1:0712/042154.807422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"473 0x7f146568d070 0x36aeb00c9de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.807686:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"473 0x7f146568d070 0x36aeb00c9de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.808020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 477
[1:1:0712/042154.808241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7f146568d070 0x36aeb002ace0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 475 0x7f146568d070 0x36aeb00f2560 
[1:1:0712/042154.808534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.809053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.809260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.837684:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 477, 7f1467fd28db
[1:1:0712/042154.858871:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"475 0x7f146568d070 0x36aeb00f2560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.859153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"475 0x7f146568d070 0x36aeb00f2560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.859490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 479
[1:1:0712/042154.859731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7f146568d070 0x36aeb01be2e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 477 0x7f146568d070 0x36aeb002ace0 
[1:1:0712/042154.860070:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.860615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.860824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.900221:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 479, 7f1467fd28db
[1:1:0712/042154.908448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"477 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.908713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"477 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.909058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 481
[1:1:0712/042154.909284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7f146568d070 0x36aeb00c3ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 479 0x7f146568d070 0x36aeb01be2e0 
[1:1:0712/042154.909609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.910148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.910362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.950668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 481, 7f1467fd28db
[1:1:0712/042154.958565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"479 0x7f146568d070 0x36aeb01be2e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.958826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"479 0x7f146568d070 0x36aeb01be2e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042154.959164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 483
[1:1:0712/042154.959399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7f146568d070 0x36aeb01eaae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 481 0x7f146568d070 0x36aeb00c3ae0 
[1:1:0712/042154.959725:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042154.960261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042154.960501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042154.985938:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 483, 7f1467fd28db
[1:1:0712/042155.008242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"481 0x7f146568d070 0x36aeb00c3ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.008521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"481 0x7f146568d070 0x36aeb00c3ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.008864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 485
[1:1:0712/042155.009109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7f146568d070 0x36aeb0141c60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 483 0x7f146568d070 0x36aeb01eaae0 
[1:1:0712/042155.009426:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.009969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.010181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.038178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 485, 7f1467fd28db
[1:1:0712/042155.044255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"483 0x7f146568d070 0x36aeb01eaae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.044519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"483 0x7f146568d070 0x36aeb01eaae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.044855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 487
[1:1:0712/042155.045088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 487 0x7f146568d070 0x36aeb01410e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 485 0x7f146568d070 0x36aeb0141c60 
[1:1:0712/042155.045406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.045942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.046166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.100735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 487, 7f1467fd28db
[1:1:0712/042155.107713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"485 0x7f146568d070 0x36aeb0141c60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.107997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"485 0x7f146568d070 0x36aeb0141c60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.108332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 489
[1:1:0712/042155.108567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 489 0x7f146568d070 0x36aeb0023960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 487 0x7f146568d070 0x36aeb01410e0 
[1:1:0712/042155.108897:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.109457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.109669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.140172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 489, 7f1467fd28db
[1:1:0712/042155.146211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"487 0x7f146568d070 0x36aeb01410e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.146458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"487 0x7f146568d070 0x36aeb01410e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.146775:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 491
[1:1:0712/042155.147015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f146568d070 0x36aeb00c31e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 489 0x7f146568d070 0x36aeb0023960 
[1:1:0712/042155.147321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.147814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.148043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.213882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 491, 7f1467fd28db
[1:1:0712/042155.230664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"489 0x7f146568d070 0x36aeb0023960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.231138:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"489 0x7f146568d070 0x36aeb0023960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.231737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 493
[1:1:0712/042155.232157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 493 0x7f146568d070 0x36aeb0184be0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 491 0x7f146568d070 0x36aeb00c31e0 
[1:1:0712/042155.232708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.233661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.234060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.293579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 493, 7f1467fd28db
[1:1:0712/042155.314679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"491 0x7f146568d070 0x36aeb00c31e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.314904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"491 0x7f146568d070 0x36aeb00c31e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.315212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 495
[1:1:0712/042155.315405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f146568d070 0x36aeb0234f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 493 0x7f146568d070 0x36aeb0184be0 
[1:1:0712/042155.315672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.316189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.316368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.350204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 495, 7f1467fd28db
[1:1:0712/042155.368459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"493 0x7f146568d070 0x36aeb0184be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.368703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"493 0x7f146568d070 0x36aeb0184be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.369017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 497
[1:1:0712/042155.369209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7f146568d070 0x36aeafffbfe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 495 0x7f146568d070 0x36aeb0234f60 
[1:1:0712/042155.369493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.369990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.370199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.411782:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 497, 7f1467fd28db
[1:1:0712/042155.431561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"495 0x7f146568d070 0x36aeb0234f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.431796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"495 0x7f146568d070 0x36aeb0234f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.432122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 499
[1:1:0712/042155.432311:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7f146568d070 0x36aeb01914e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 497 0x7f146568d070 0x36aeafffbfe0 
[1:1:0712/042155.432576:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.433057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.433257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.514893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 499, 7f1467fd28db
[1:1:0712/042155.535935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"497 0x7f146568d070 0x36aeafffbfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.536208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"497 0x7f146568d070 0x36aeafffbfe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.536511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 501
[1:1:0712/042155.536711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f146568d070 0x36aeb00cb5e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 499 0x7f146568d070 0x36aeb01914e0 
[1:1:0712/042155.536990:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.537532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.537711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.587802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 501, 7f1467fd28db
[1:1:0712/042155.593775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"499 0x7f146568d070 0x36aeb01914e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.593918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"499 0x7f146568d070 0x36aeb01914e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.594095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 503
[1:1:0712/042155.594207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7f146568d070 0x36aeb0037f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 501 0x7f146568d070 0x36aeb00cb5e0 
[1:1:0712/042155.594347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.594600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.594705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.649629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 503, 7f1467fd28db
[1:1:0712/042155.668677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"501 0x7f146568d070 0x36aeb00cb5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.668895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"501 0x7f146568d070 0x36aeb00cb5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.669197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 505
[1:1:0712/042155.669380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 505 0x7f146568d070 0x36aeb0187e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 503 0x7f146568d070 0x36aeb0037f60 
[1:1:0712/042155.669648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.670133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.670326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.689344:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 505, 7f1467fd28db
[1:1:0712/042155.697367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"503 0x7f146568d070 0x36aeb0037f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.697523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"503 0x7f146568d070 0x36aeb0037f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.697713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 507
[1:1:0712/042155.697845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7f146568d070 0x36aeb0248760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 505 0x7f146568d070 0x36aeb0187e60 
[1:1:0712/042155.698028:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.698409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.698547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.754427:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 507, 7f1467fd28db
[1:1:0712/042155.760818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"505 0x7f146568d070 0x36aeb0187e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.760966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"505 0x7f146568d070 0x36aeb0187e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.761155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 509
[1:1:0712/042155.761268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7f146568d070 0x36aeb0248e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 507 0x7f146568d070 0x36aeb0248760 
[1:1:0712/042155.761420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.761700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.761802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.810501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 509, 7f1467fd28db
[1:1:0712/042155.835488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"507 0x7f146568d070 0x36aeb0248760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.835772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"507 0x7f146568d070 0x36aeb0248760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.836185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 511
[1:1:0712/042155.836436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7f146568d070 0x36aeb00c31e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 509 0x7f146568d070 0x36aeb0248e60 
[1:1:0712/042155.836802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.837431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.837645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042155.921447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 511, 7f1467fd28db
[1:1:0712/042155.944912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"509 0x7f146568d070 0x36aeb0248e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.945516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"509 0x7f146568d070 0x36aeb0248e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042155.946372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 513
[1:1:0712/042155.947080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7f146568d070 0x36aeb0237e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 511 0x7f146568d070 0x36aeb00c31e0 
[1:1:0712/042155.947851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042155.948641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042155.949094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.009028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 513, 7f1467fd28db
[1:1:0712/042156.040620:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"511 0x7f146568d070 0x36aeb00c31e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.041047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"511 0x7f146568d070 0x36aeb00c31e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.041580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 515
[1:1:0712/042156.041904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7f146568d070 0x36aeb01870e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 513 0x7f146568d070 0x36aeb0237e60 
[1:1:0712/042156.042390:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.043176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.043520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.107760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 515, 7f1467fd28db
[1:1:0712/042156.132549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"513 0x7f146568d070 0x36aeb0237e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.132867:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"513 0x7f146568d070 0x36aeb0237e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.133241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 518
[1:1:0712/042156.133484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f146568d070 0x36aeb02417e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 515 0x7f146568d070 0x36aeb01870e0 
[1:1:0712/042156.133809:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.134387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.134612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.192192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 518, 7f1467fd28db
[1:1:0712/042156.213665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"515 0x7f146568d070 0x36aeb01870e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.213990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"515 0x7f146568d070 0x36aeb01870e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.214402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 520
[1:1:0712/042156.214657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f146568d070 0x36aeb0187ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 518 0x7f146568d070 0x36aeb02417e0 
[1:1:0712/042156.215008:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.215651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.215913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.240211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 520, 7f1467fd28db
[1:1:0712/042156.256925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"518 0x7f146568d070 0x36aeb02417e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.257310:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"518 0x7f146568d070 0x36aeb02417e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.257757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 522
[1:1:0712/042156.258048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7f146568d070 0x36aeb00b2fe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 520 0x7f146568d070 0x36aeb0187ae0 
[1:1:0712/042156.258492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.259239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.259523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.304123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 522, 7f1467fd28db
[1:1:0712/042156.326360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"520 0x7f146568d070 0x36aeb0187ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.326698:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"520 0x7f146568d070 0x36aeb0187ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.327081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 524
[1:1:0712/042156.327375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7f146568d070 0x36aeb02002e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 522 0x7f146568d070 0x36aeb00b2fe0 
[1:1:0712/042156.327751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.328358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.328600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.330683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 524, 7f1467fd28db
[1:1:0712/042156.357755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"522 0x7f146568d070 0x36aeb00b2fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.358121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"522 0x7f146568d070 0x36aeb00b2fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.358538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 526
[1:1:0712/042156.358797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7f146568d070 0x36aeb0034560 , 5:3_http://jxja.jxnews.com.cn/, 0, , 524 0x7f146568d070 0x36aeb02002e0 
[1:1:0712/042156.359152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.359773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.360039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.401773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 526, 7f1467fd28db
[1:1:0712/042156.422081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"524 0x7f146568d070 0x36aeb02002e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.422390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"524 0x7f146568d070 0x36aeb02002e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.422745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 528
[1:1:0712/042156.422941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7f146568d070 0x36aeb002dd60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 526 0x7f146568d070 0x36aeb0034560 
[1:1:0712/042156.423259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.423799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.423988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.453914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 528, 7f1467fd28db
[1:1:0712/042156.479979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"526 0x7f146568d070 0x36aeb0034560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.480359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"526 0x7f146568d070 0x36aeb0034560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.480742:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 530
[1:1:0712/042156.480974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7f146568d070 0x36aeafb296e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 528 0x7f146568d070 0x36aeb002dd60 
[1:1:0712/042156.481334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.481975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.482193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.553794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 530, 7f1467fd28db
[1:1:0712/042156.572988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"528 0x7f146568d070 0x36aeb002dd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.573176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"528 0x7f146568d070 0x36aeb002dd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.573388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 532
[1:1:0712/042156.573508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f146568d070 0x36aeb00c9de0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 530 0x7f146568d070 0x36aeafb296e0 
[1:1:0712/042156.573667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.573959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.574073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.596166:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 532, 7f1467fd28db
[1:1:0712/042156.603937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"530 0x7f146568d070 0x36aeafb296e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.604071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"530 0x7f146568d070 0x36aeafb296e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.604223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 534
[1:1:0712/042156.604361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f146568d070 0x36aeb01870e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 532 0x7f146568d070 0x36aeb00c9de0 
[1:1:0712/042156.604508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.604774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.604874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.653115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 534, 7f1467fd28db
[1:1:0712/042156.675732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"532 0x7f146568d070 0x36aeb00c9de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.675992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"532 0x7f146568d070 0x36aeb00c9de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.676353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 536
[1:1:0712/042156.676601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f146568d070 0x36aeb01bdd60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 534 0x7f146568d070 0x36aeb01870e0 
[1:1:0712/042156.676957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.677616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.677846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.706738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 536, 7f1467fd28db
[1:1:0712/042156.733050:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"534 0x7f146568d070 0x36aeb01870e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.733393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"534 0x7f146568d070 0x36aeb01870e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.733771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 538
[1:1:0712/042156.734001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7f146568d070 0x36aeb01d3260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 536 0x7f146568d070 0x36aeb01bdd60 
[1:1:0712/042156.734612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.735248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.735481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.805821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 538, 7f1467fd28db
[1:1:0712/042156.824092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"536 0x7f146568d070 0x36aeb01bdd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.824257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"536 0x7f146568d070 0x36aeb01bdd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.824486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 540
[1:1:0712/042156.824631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7f146568d070 0x36aeb01c6160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 538 0x7f146568d070 0x36aeb01d3260 
[1:1:0712/042156.824778:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.825103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.825205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.856970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 540, 7f1467fd28db
[1:1:0712/042156.883514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"538 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.883791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"538 0x7f146568d070 0x36aeb01d3260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.884109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 542
[1:1:0712/042156.884299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7f146568d070 0x36aeb00c68e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 540 0x7f146568d070 0x36aeb01c6160 
[1:1:0712/042156.884644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.885153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.885328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042156.957574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 542, 7f1467fd28db
[1:1:0712/042156.981047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"540 0x7f146568d070 0x36aeb01c6160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.981347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"540 0x7f146568d070 0x36aeb01c6160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042156.981691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 544
[1:1:0712/042156.981880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 544 0x7f146568d070 0x36aeb023a260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 542 0x7f146568d070 0x36aeb00c68e0 
[1:1:0712/042156.982171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042156.982699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042156.982875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.044819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 544, 7f1467fd28db
[1:1:0712/042157.051379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"542 0x7f146568d070 0x36aeb00c68e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.051532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"542 0x7f146568d070 0x36aeb00c68e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.051692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 547
[1:1:0712/042157.051799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 547 0x7f146568d070 0x36aeb0189060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 544 0x7f146568d070 0x36aeb023a260 
[1:1:0712/042157.051949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.052253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.052368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.099268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 547, 7f1467fd28db
[1:1:0712/042157.109498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"544 0x7f146568d070 0x36aeb023a260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.109640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"544 0x7f146568d070 0x36aeb023a260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.109800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 549
[1:1:0712/042157.109904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 549 0x7f146568d070 0x36aeb00a63e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 547 0x7f146568d070 0x36aeb0189060 
[1:1:0712/042157.110062:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.110351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.110498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.142203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 549, 7f1467fd28db
[1:1:0712/042157.157487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"547 0x7f146568d070 0x36aeb0189060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.157773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"547 0x7f146568d070 0x36aeb0189060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.158117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 551
[1:1:0712/042157.158342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7f146568d070 0x36aeb0234f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 549 0x7f146568d070 0x36aeb00a63e0 
[1:1:0712/042157.158687:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.159252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.159479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.205312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 551, 7f1467fd28db
[1:1:0712/042157.227085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"549 0x7f146568d070 0x36aeb00a63e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.227317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"549 0x7f146568d070 0x36aeb00a63e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.227632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 553
[1:1:0712/042157.227831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 553 0x7f146568d070 0x36aeb02347e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 551 0x7f146568d070 0x36aeb0234f60 
[1:1:0712/042157.228114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.228634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.228813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.230409:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 553, 7f1467fd28db
[1:1:0712/042157.252357:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"551 0x7f146568d070 0x36aeb0234f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.252607:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"551 0x7f146568d070 0x36aeb0234f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.252895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 555
[1:1:0712/042157.253080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7f146568d070 0x36aeb01bc7e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 553 0x7f146568d070 0x36aeb02347e0 
[1:1:0712/042157.253344:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.253835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.254009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.303222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 555, 7f1467fd28db
[1:1:0712/042157.325069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"553 0x7f146568d070 0x36aeb02347e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.325317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"553 0x7f146568d070 0x36aeb02347e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.325629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 557
[1:1:0712/042157.325832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f146568d070 0x36aeb01d3de0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 555 0x7f146568d070 0x36aeb01bc7e0 
[1:1:0712/042157.326104:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.326605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.326782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.343847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 557, 7f1467fd28db
[1:1:0712/042157.362754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"555 0x7f146568d070 0x36aeb01bc7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.362891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"555 0x7f146568d070 0x36aeb01bc7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.363046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 559
[1:1:0712/042157.363157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 559 0x7f146568d070 0x36aeb02388e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 557 0x7f146568d070 0x36aeb01d3de0 
[1:1:0712/042157.363300:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.363584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.363690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.403039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 559, 7f1467fd28db
[1:1:0712/042157.423915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"557 0x7f146568d070 0x36aeb01d3de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.424128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"557 0x7f146568d070 0x36aeb01d3de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.424400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 561
[1:1:0712/042157.424619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f146568d070 0x36aeb01858e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 559 0x7f146568d070 0x36aeb02388e0 
[1:1:0712/042157.424879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.425338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.425530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.445784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 561, 7f1467fd28db
[1:1:0712/042157.452066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"559 0x7f146568d070 0x36aeb02388e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.452187:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"559 0x7f146568d070 0x36aeb02388e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.452336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 563
[1:1:0712/042157.452438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f146568d070 0x36aeb017aa60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 561 0x7f146568d070 0x36aeb01858e0 
[1:1:0712/042157.452607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.452857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.452963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.519827:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 563, 7f1467fd28db
[1:1:0712/042157.534547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"561 0x7f146568d070 0x36aeb01858e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.534678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"561 0x7f146568d070 0x36aeb01858e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.534830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 565
[1:1:0712/042157.534933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f146568d070 0x36aeb0141ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 563 0x7f146568d070 0x36aeb017aa60 
[1:1:0712/042157.535078:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.535319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.535418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.617355:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 565, 7f1467fd28db
[1:1:0712/042157.640796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"563 0x7f146568d070 0x36aeb017aa60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.641039:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"563 0x7f146568d070 0x36aeb017aa60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.641342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 567
[1:1:0712/042157.641576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f146568d070 0x36aeb0179d60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 565 0x7f146568d070 0x36aeb0141ce0 
[1:1:0712/042157.641868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.642377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.642751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.703570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 567, 7f1467fd28db
[1:1:0712/042157.725843:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"565 0x7f146568d070 0x36aeb0141ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.726079:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"565 0x7f146568d070 0x36aeb0141ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.726381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 569
[1:1:0712/042157.726588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f146568d070 0x36aeb00ca7e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 567 0x7f146568d070 0x36aeb0179d60 
[1:1:0712/042157.726865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.727344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.727516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.754036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 569, 7f1467fd28db
[1:1:0712/042157.760833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"567 0x7f146568d070 0x36aeb0179d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.760972:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"567 0x7f146568d070 0x36aeb0179d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.761121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 571
[1:1:0712/042157.761222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f146568d070 0x36aeaff219e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 569 0x7f146568d070 0x36aeb00ca7e0 
[1:1:0712/042157.761358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.761637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.761743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.796670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 571, 7f1467fd28db
[1:1:0712/042157.809907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"569 0x7f146568d070 0x36aeb00ca7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.810144:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"569 0x7f146568d070 0x36aeb00ca7e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.810421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 573
[1:1:0712/042157.810657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f146568d070 0x36aeb00f2560 , 5:3_http://jxja.jxnews.com.cn/, 0, , 571 0x7f146568d070 0x36aeaff219e0 
[1:1:0712/042157.810927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.811420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.811681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.844686:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 573, 7f1467fd28db
[1:1:0712/042157.860252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"571 0x7f146568d070 0x36aeaff219e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.860526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"571 0x7f146568d070 0x36aeaff219e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.860864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 575
[1:1:0712/042157.861055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f146568d070 0x36aeb02487e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 573 0x7f146568d070 0x36aeb00f2560 
[1:1:0712/042157.861341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.861872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.862047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.893935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 575, 7f1467fd28db
[1:1:0712/042157.900780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"573 0x7f146568d070 0x36aeb00f2560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.900921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"573 0x7f146568d070 0x36aeb00f2560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.901081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 577
[1:1:0712/042157.901184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 577 0x7f146568d070 0x36aeb01916e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 575 0x7f146568d070 0x36aeb02487e0 
[1:1:0712/042157.901344:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.901647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.901763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042157.959803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 577, 7f1467fd28db
[1:1:0712/042157.987724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"575 0x7f146568d070 0x36aeb02487e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.988064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"575 0x7f146568d070 0x36aeb02487e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042157.988454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 579
[1:1:0712/042157.988719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f146568d070 0x36aeb02007e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 577 0x7f146568d070 0x36aeb01916e0 
[1:1:0712/042157.989084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042157.989761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042157.989987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.054883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 579, 7f1467fd28db
[1:1:0712/042158.073794:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"577 0x7f146568d070 0x36aeb01916e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.073971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"577 0x7f146568d070 0x36aeb01916e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.074159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 581
[1:1:0712/042158.074266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 581 0x7f146568d070 0x36aeb01bc360 , 5:3_http://jxja.jxnews.com.cn/, 0, , 579 0x7f146568d070 0x36aeb02007e0 
[1:1:0712/042158.074420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.074727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.074832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.104699:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 581, 7f1467fd28db
[1:1:0712/042158.127599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"579 0x7f146568d070 0x36aeb02007e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.127883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"579 0x7f146568d070 0x36aeb02007e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.128180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 583
[1:1:0712/042158.128364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f146568d070 0x36aeb0183e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 581 0x7f146568d070 0x36aeb01bc360 
[1:1:0712/042158.128664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.129165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.129336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.130979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 583, 7f1467fd28db
[1:1:0712/042158.154771:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"581 0x7f146568d070 0x36aeb01bc360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.155070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"581 0x7f146568d070 0x36aeb01bc360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.155428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 585
[1:1:0712/042158.155696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7f146568d070 0x36aeb002d0e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 583 0x7f146568d070 0x36aeb0183e60 
[1:1:0712/042158.156038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.156627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.156856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.206758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 585, 7f1467fd28db
[1:1:0712/042158.229739:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"583 0x7f146568d070 0x36aeb0183e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.229965:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"583 0x7f146568d070 0x36aeb0183e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.230255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 587
[1:1:0712/042158.230452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7f146568d070 0x36aeb01877e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 585 0x7f146568d070 0x36aeb002d0e0 
[1:1:0712/042158.230751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.231261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.231434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.310127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 587, 7f1467fd28db
[1:1:0712/042158.338458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"585 0x7f146568d070 0x36aeb002d0e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.338755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"585 0x7f146568d070 0x36aeb002d0e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.339116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 589
[1:1:0712/042158.339342:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f146568d070 0x36aeb01b4460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 587 0x7f146568d070 0x36aeb01877e0 
[1:1:0712/042158.339680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.340325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.340536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.403501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 589, 7f1467fd28db
[1:1:0712/042158.427908:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"587 0x7f146568d070 0x36aeb01877e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.428200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"587 0x7f146568d070 0x36aeb01877e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.428562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 591
[1:1:0712/042158.428818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7f146568d070 0x36aeb02417e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 589 0x7f146568d070 0x36aeb01b4460 
[1:1:0712/042158.429188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.429813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.430026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.432094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 591, 7f1467fd28db
[1:1:0712/042158.460772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"589 0x7f146568d070 0x36aeb01b4460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.461049:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"589 0x7f146568d070 0x36aeb01b4460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.461399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 593
[1:1:0712/042158.461637:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 593 0x7f146568d070 0x36aeb0023060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 591 0x7f146568d070 0x36aeb02417e0 
[1:1:0712/042158.461982:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.462554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.462782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.504918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 593, 7f1467fd28db
[1:1:0712/042158.527385:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"591 0x7f146568d070 0x36aeb02417e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.527614:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"591 0x7f146568d070 0x36aeb02417e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.527934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 595
[1:1:0712/042158.528119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 595 0x7f146568d070 0x36aeafb296e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 593 0x7f146568d070 0x36aeb0023060 
[1:1:0712/042158.528382:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.528896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.529066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.530600:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 595, 7f1467fd28db
[1:1:0712/042158.551414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"593 0x7f146568d070 0x36aeb0023060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.551552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"593 0x7f146568d070 0x36aeb0023060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.551720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 597
[1:1:0712/042158.551983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7f146568d070 0x36aeafb47260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 595 0x7f146568d070 0x36aeafb296e0 
[1:1:0712/042158.552123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.552368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.552477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.598991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 597, 7f1467fd28db
[1:1:0712/042158.605684:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"595 0x7f146568d070 0x36aeafb296e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.605842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"595 0x7f146568d070 0x36aeafb296e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.606007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 600
[1:1:0712/042158.606109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f146568d070 0x36aeafb2b660 , 5:3_http://jxja.jxnews.com.cn/, 0, , 597 0x7f146568d070 0x36aeafb47260 
[1:1:0712/042158.606248:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.606507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.606607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.651310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 600, 7f1467fd28db
[1:1:0712/042158.658183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"597 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.658311:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"597 0x7f146568d070 0x36aeafb47260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.658464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 602
[1:1:0712/042158.658566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f146568d070 0x36aeb018e160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 600 0x7f146568d070 0x36aeafb2b660 
[1:1:0712/042158.658717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.659002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.659117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.705222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 602, 7f1467fd28db
[1:1:0712/042158.718655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"600 0x7f146568d070 0x36aeafb2b660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.718785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"600 0x7f146568d070 0x36aeafb2b660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.718981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 604
[1:1:0712/042158.719083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f146568d070 0x36aeb0177d60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 602 0x7f146568d070 0x36aeb018e160 
[1:1:0712/042158.719223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.719479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.719577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.753706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 604, 7f1467fd28db
[1:1:0712/042158.776302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"602 0x7f146568d070 0x36aeb018e160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.776522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"602 0x7f146568d070 0x36aeb018e160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.776820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 606
[1:1:0712/042158.777005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 606 0x7f146568d070 0x36aeb017e660 , 5:3_http://jxja.jxnews.com.cn/, 0, , 604 0x7f146568d070 0x36aeb0177d60 
[1:1:0712/042158.777269:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.777734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.777940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.806110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 606, 7f1467fd28db
[1:1:0712/042158.833817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"604 0x7f146568d070 0x36aeb0177d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.834198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"604 0x7f146568d070 0x36aeb0177d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.834601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 608
[1:1:0712/042158.834867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f146568d070 0x36aeb00295e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 606 0x7f146568d070 0x36aeb017e660 
[1:1:0712/042158.835231:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.835930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.836166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042158.906680:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 608, 7f1467fd28db
[1:1:0712/042158.930688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"606 0x7f146568d070 0x36aeb017e660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.930957:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"606 0x7f146568d070 0x36aeb017e660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042158.931266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 610
[1:1:0712/042158.931452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f146568d070 0x36aeafb33060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 608 0x7f146568d070 0x36aeb00295e0 
[1:1:0712/042158.931735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042158.932302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042158.932482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.005773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 610, 7f1467fd28db
[1:1:0712/042159.029924:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"608 0x7f146568d070 0x36aeb00295e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.030185:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"608 0x7f146568d070 0x36aeb00295e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.030497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 612
[1:1:0712/042159.030685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f146568d070 0x36aeafb33ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 610 0x7f146568d070 0x36aeafb33060 
[1:1:0712/042159.031004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.031520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.031693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.095547:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 612, 7f1467fd28db
[1:1:0712/042159.102488:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"610 0x7f146568d070 0x36aeafb33060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.102662:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"610 0x7f146568d070 0x36aeafb33060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.102911:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 614
[1:1:0712/042159.103169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f146568d070 0x36aeb00cb5e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 612 0x7f146568d070 0x36aeafb33ce0 
[1:1:0712/042159.103516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.104140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.104318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.141196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 614, 7f1467fd28db
[1:1:0712/042159.147784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7f146568d070 0x36aeafb33ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.147928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7f146568d070 0x36aeafb33ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.148089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 616
[1:1:0712/042159.148187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f146568d070 0x36aeafb47fe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 614 0x7f146568d070 0x36aeb00cb5e0 
[1:1:0712/042159.148330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.148601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.148700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.205087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 616, 7f1467fd28db
[1:1:0712/042159.230034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"614 0x7f146568d070 0x36aeb00cb5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.230296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"614 0x7f146568d070 0x36aeb00cb5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.230611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 618
[1:1:0712/042159.230799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f146568d070 0x36aeb0250460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 616 0x7f146568d070 0x36aeafb47fe0 
[1:1:0712/042159.231108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.231619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.231792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.305278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 618, 7f1467fd28db
[1:1:0712/042159.329567:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"616 0x7f146568d070 0x36aeafb47fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.329818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"616 0x7f146568d070 0x36aeafb47fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.330145:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 620
[1:1:0712/042159.330337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f146568d070 0x36aeb0141ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 618 0x7f146568d070 0x36aeb0250460 
[1:1:0712/042159.330620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.331190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.331368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.406294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 620, 7f1467fd28db
[1:1:0712/042159.435334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7f146568d070 0x36aeb0250460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.435617:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7f146568d070 0x36aeb0250460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.435937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 622
[1:1:0712/042159.436250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f146568d070 0x36aeb01d9fe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 620 0x7f146568d070 0x36aeb0141ce0 
[1:1:0712/042159.436562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.437128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.437311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.507659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 622, 7f1467fd28db
[1:1:0712/042159.524299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"620 0x7f146568d070 0x36aeb0141ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.524636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"620 0x7f146568d070 0x36aeb0141ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.524966:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 625
[1:1:0712/042159.525253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7f146568d070 0x36aeafb2be60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 622 0x7f146568d070 0x36aeb01d9fe0 
[1:1:0712/042159.525662:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.526451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.526641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.549789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 625, 7f1467fd28db
[1:1:0712/042159.559196:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"622 0x7f146568d070 0x36aeb01d9fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.559453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"622 0x7f146568d070 0x36aeb01d9fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.559699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 627
[1:1:0712/042159.559848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f146568d070 0x36aeb01fce60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 625 0x7f146568d070 0x36aeafb2be60 
[1:1:0712/042159.560088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.560499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.560649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.606540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 627, 7f1467fd28db
[1:1:0712/042159.633710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"625 0x7f146568d070 0x36aeafb2be60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.634121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"625 0x7f146568d070 0x36aeafb2be60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.634574:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 629
[1:1:0712/042159.634849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f146568d070 0x36aeb01b4e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 627 0x7f146568d070 0x36aeb01fce60 
[1:1:0712/042159.635273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.635932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.636207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.707977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 629, 7f1467fd28db
[1:1:0712/042159.734960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7f146568d070 0x36aeb01fce60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.735208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7f146568d070 0x36aeb01fce60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.735411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 631
[1:1:0712/042159.735526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f146568d070 0x36aeb018dd60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 629 0x7f146568d070 0x36aeb01b4e60 
[1:1:0712/042159.735695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.735991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.736164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.814460:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 631, 7f1467fd28db
[1:1:0712/042159.848572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"629 0x7f146568d070 0x36aeb01b4e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.848971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"629 0x7f146568d070 0x36aeb01b4e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.849441:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 633
[1:1:0712/042159.849768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f146568d070 0x36aeb002ace0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 631 0x7f146568d070 0x36aeb018dd60 
[1:1:0712/042159.850178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.850888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.851206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042159.911314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 633, 7f1467fd28db
[1:1:0712/042159.933438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"631 0x7f146568d070 0x36aeb018dd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.933736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"631 0x7f146568d070 0x36aeb018dd60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042159.934035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 635
[1:1:0712/042159.934216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f146568d070 0x36aeb02487e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 633 0x7f146568d070 0x36aeb002ace0 
[1:1:0712/042159.934439:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042159.934834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042159.934989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.008772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 635, 7f1467fd28db
[1:1:0712/042200.034850:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"633 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.035058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"633 0x7f146568d070 0x36aeb002ace0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.035278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 637
[1:1:0712/042200.035395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f146568d070 0x36aeb00ba8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 635 0x7f146568d070 0x36aeb02487e0 
[1:1:0712/042200.035556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.035865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.035980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.107079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 637, 7f1467fd28db
[1:1:0712/042200.122941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"635 0x7f146568d070 0x36aeb02487e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.123203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"635 0x7f146568d070 0x36aeb02487e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.123445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 639
[1:1:0712/042200.123560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7f146568d070 0x36aeb024e9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 637 0x7f146568d070 0x36aeb00ba8e0 
[1:1:0712/042200.123723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.124024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.124131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.145842:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 639, 7f1467fd28db
[1:1:0712/042200.157811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"637 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.158008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"637 0x7f146568d070 0x36aeb00ba8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.158220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 641
[1:1:0712/042200.158338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f146568d070 0x36aeb0236060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 639 0x7f146568d070 0x36aeb024e9e0 
[1:1:0712/042200.158492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.158774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.158874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.197115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 641, 7f1467fd28db
[1:1:0712/042200.212919:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"639 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.213238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"639 0x7f146568d070 0x36aeb024e9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.213463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 643
[1:1:0712/042200.213661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f146568d070 0x36aeb01410e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 641 0x7f146568d070 0x36aeb0236060 
[1:1:0712/042200.213852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.214182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.214304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.260328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 643, 7f1467fd28db
[1:1:0712/042200.292352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"641 0x7f146568d070 0x36aeb0236060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.292709:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"641 0x7f146568d070 0x36aeb0236060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.293108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 645
[1:1:0712/042200.293396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f146568d070 0x36aeb0192be0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 643 0x7f146568d070 0x36aeb01410e0 
[1:1:0712/042200.293794:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.294484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.294707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.340812:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 645, 7f1467fd28db
[1:1:0712/042200.365738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"643 0x7f146568d070 0x36aeb01410e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.366063:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"643 0x7f146568d070 0x36aeb01410e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.366483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 647
[1:1:0712/042200.366674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7f146568d070 0x36aeb018a5e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 645 0x7f146568d070 0x36aeb0192be0 
[1:1:0712/042200.366965:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.367516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.367688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.403386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 647, 7f1467fd28db
[1:1:0712/042200.433563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"645 0x7f146568d070 0x36aeb0192be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.433887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"645 0x7f146568d070 0x36aeb0192be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.434234:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 649
[1:1:0712/042200.434434:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f146568d070 0x36aeb00b25e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 647 0x7f146568d070 0x36aeb018a5e0 
[1:1:0712/042200.434719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.435273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.435506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.508426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 649, 7f1467fd28db
[1:1:0712/042200.535102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"647 0x7f146568d070 0x36aeb018a5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.535405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"647 0x7f146568d070 0x36aeb018a5e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.535735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 651
[1:1:0712/042200.535927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 651 0x7f146568d070 0x36aeafc754e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 649 0x7f146568d070 0x36aeb00b25e0 
[1:1:0712/042200.536214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.536814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.536991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.592020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 651, 7f1467fd28db
[1:1:0712/042200.606884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"649 0x7f146568d070 0x36aeb00b25e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.607266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"649 0x7f146568d070 0x36aeb00b25e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.607680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 653
[1:1:0712/042200.607923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7f146568d070 0x36aeb00a6ee0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 651 0x7f146568d070 0x36aeafc754e0 
[1:1:0712/042200.608329:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.608982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.609202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.642473:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 653, 7f1467fd28db
[1:1:0712/042200.658447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"651 0x7f146568d070 0x36aeafc754e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.658806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"651 0x7f146568d070 0x36aeafc754e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.659207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 655
[1:1:0712/042200.659471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f146568d070 0x36aeb0177d60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 653 0x7f146568d070 0x36aeb00a6ee0 
[1:1:0712/042200.659829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.660513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.660741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.696755:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 655, 7f1467fd28db
[1:1:0712/042200.705314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"653 0x7f146568d070 0x36aeb00a6ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.705451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"653 0x7f146568d070 0x36aeb00a6ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.705614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 657
[1:1:0712/042200.705719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7f146568d070 0x36aeb023df60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 655 0x7f146568d070 0x36aeb0177d60 
[1:1:0712/042200.705871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.706139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.706241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.756844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 657, 7f1467fd28db
[1:1:0712/042200.782622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"655 0x7f146568d070 0x36aeb0177d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.782859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"655 0x7f146568d070 0x36aeb0177d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.783158:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 659
[1:1:0712/042200.783370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7f146568d070 0x36aeb002da60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 657 0x7f146568d070 0x36aeb023df60 
[1:1:0712/042200.783651:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.784155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.784377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.859969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 659, 7f1467fd28db
[1:1:0712/042200.885407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"657 0x7f146568d070 0x36aeb023df60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.885588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"657 0x7f146568d070 0x36aeb023df60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.885773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 661
[1:1:0712/042200.885876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f146568d070 0x36aeb017ab60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 659 0x7f146568d070 0x36aeb002da60 
[1:1:0712/042200.886027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.886304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.886427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042200.957756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 661, 7f1467fd28db
[1:1:0712/042200.983768:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"659 0x7f146568d070 0x36aeb002da60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.984087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"659 0x7f146568d070 0x36aeb002da60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042200.984454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 663
[1:1:0712/042200.984667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f146568d070 0x36aeafb29be0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 661 0x7f146568d070 0x36aeb017ab60 
[1:1:0712/042200.984954:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042200.985517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042200.985698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.040195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 663, 7f1467fd28db
[1:1:0712/042201.047693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"661 0x7f146568d070 0x36aeb017ab60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.047842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"661 0x7f146568d070 0x36aeb017ab60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.048016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 665
[1:1:0712/042201.048123:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f146568d070 0x36aeb0022ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 663 0x7f146568d070 0x36aeafb29be0 
[1:1:0712/042201.048275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.048601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.048707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.105420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 665, 7f1467fd28db
[1:1:0712/042201.113643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"663 0x7f146568d070 0x36aeafb29be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.113792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"663 0x7f146568d070 0x36aeafb29be0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.113958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 667
[1:1:0712/042201.114070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f146568d070 0x36aeb00218e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 665 0x7f146568d070 0x36aeb0022ce0 
[1:1:0712/042201.114217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.114528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.114636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.160380:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 667, 7f1467fd28db
[1:1:0712/042201.192673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"665 0x7f146568d070 0x36aeb0022ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.192998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"665 0x7f146568d070 0x36aeb0022ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.193375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 669
[1:1:0712/042201.193627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f146568d070 0x36aeb01b44e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 667 0x7f146568d070 0x36aeb00218e0 
[1:1:0712/042201.193974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.194620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.194843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.257928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 669, 7f1467fd28db
[1:1:0712/042201.290253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"667 0x7f146568d070 0x36aeb00218e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.290613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"667 0x7f146568d070 0x36aeb00218e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.291015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 671
[1:1:0712/042201.291263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f146568d070 0x36aeb0241760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 669 0x7f146568d070 0x36aeb01b44e0 
[1:1:0712/042201.291674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.292321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.292608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.357775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 671, 7f1467fd28db
[1:1:0712/042201.386924:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"669 0x7f146568d070 0x36aeb01b44e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.387280:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"669 0x7f146568d070 0x36aeb01b44e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.387719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 673
[1:1:0712/042201.387972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f146568d070 0x36aeafb2b4e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 671 0x7f146568d070 0x36aeb0241760 
[1:1:0712/042201.388339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.389030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.389257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.459018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 673, 7f1467fd28db
[1:1:0712/042201.489323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"671 0x7f146568d070 0x36aeb0241760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.489637:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"671 0x7f146568d070 0x36aeb0241760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.489967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 675
[1:1:0712/042201.490160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f146568d070 0x36aeb00b2fe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 673 0x7f146568d070 0x36aeafb2b4e0 
[1:1:0712/042201.490446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.490992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.491169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.553750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 675, 7f1467fd28db
[1:1:0712/042201.571373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"673 0x7f146568d070 0x36aeafb2b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.571711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"673 0x7f146568d070 0x36aeafb2b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.572035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 677
[1:1:0712/042201.572226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f146568d070 0x36aeb01b4160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 675 0x7f146568d070 0x36aeb00b2fe0 
[1:1:0712/042201.572530:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.573050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.573233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.600176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 677, 7f1467fd28db
[1:1:0712/042201.611564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"675 0x7f146568d070 0x36aeb00b2fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.611845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"675 0x7f146568d070 0x36aeb00b2fe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.612144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 679
[1:1:0712/042201.612329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f146568d070 0x36aeb00371e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 677 0x7f146568d070 0x36aeb01b4160 
[1:1:0712/042201.612588:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.612894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.612993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.642485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 679, 7f1467fd28db
[1:1:0712/042201.650696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"677 0x7f146568d070 0x36aeb01b4160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.650915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"677 0x7f146568d070 0x36aeb01b4160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.651171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 681
[1:1:0712/042201.651335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f146568d070 0x36aeb017d460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 679 0x7f146568d070 0x36aeb00371e0 
[1:1:0712/042201.651590:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.652024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.652176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.716027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 681, 7f1467fd28db
[1:1:0712/042201.741838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"679 0x7f146568d070 0x36aeb00371e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.742051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"679 0x7f146568d070 0x36aeb00371e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.742259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 683
[1:1:0712/042201.742375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f146568d070 0x36aeb0037360 , 5:3_http://jxja.jxnews.com.cn/, 0, , 681 0x7f146568d070 0x36aeb017d460 
[1:1:0712/042201.742549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.742845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.742968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.806240:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 683, 7f1467fd28db
[1:1:0712/042201.824459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"681 0x7f146568d070 0x36aeb017d460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.824794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"681 0x7f146568d070 0x36aeb017d460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.825113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 685
[1:1:0712/042201.825318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f146568d070 0x36aeb01e2460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 683 0x7f146568d070 0x36aeb0037360 
[1:1:0712/042201.825609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.826114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.826282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.847733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 685, 7f1467fd28db
[1:1:0712/042201.863652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"683 0x7f146568d070 0x36aeb0037360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.863849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"683 0x7f146568d070 0x36aeb0037360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.864043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 687
[1:1:0712/042201.864154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f146568d070 0x36aeb018e160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 685 0x7f146568d070 0x36aeb01e2460 
[1:1:0712/042201.864368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.864700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.864820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.894696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 687, 7f1467fd28db
[1:1:0712/042201.911434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"685 0x7f146568d070 0x36aeb01e2460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.911746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"685 0x7f146568d070 0x36aeb01e2460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.912057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 689
[1:1:0712/042201.912242:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f146568d070 0x36aeb01412e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 687 0x7f146568d070 0x36aeb018e160 
[1:1:0712/042201.912513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.913220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.913453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042201.940988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 689, 7f1467fd28db
[1:1:0712/042201.949809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7f146568d070 0x36aeb018e160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.950021:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7f146568d070 0x36aeb018e160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042201.950211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 691
[1:1:0712/042201.950343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f146568d070 0x36aeb02414e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 689 0x7f146568d070 0x36aeb01412e0 
[1:1:0712/042201.950511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042201.950921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042201.951030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.011973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 691, 7f1467fd28db
[1:1:0712/042202.041884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"689 0x7f146568d070 0x36aeb01412e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.042297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"689 0x7f146568d070 0x36aeb01412e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.042760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 693
[1:1:0712/042202.043002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f146568d070 0x36aeb02482e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 691 0x7f146568d070 0x36aeb02414e0 
[1:1:0712/042202.043353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.044053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.044272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.106567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 693, 7f1467fd28db
[1:1:0712/042202.141267:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"691 0x7f146568d070 0x36aeb02414e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.141664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"691 0x7f146568d070 0x36aeb02414e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.142065:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 695
[1:1:0712/042202.142305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f146568d070 0x36aeaffb5a60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 693 0x7f146568d070 0x36aeb02482e0 
[1:1:0712/042202.142668:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.143298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.143514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.193386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 695, 7f1467fd28db
[1:1:0712/042202.225015:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"693 0x7f146568d070 0x36aeb02482e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.225365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"693 0x7f146568d070 0x36aeb02482e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.225898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 697
[1:1:0712/042202.226153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f146568d070 0x36aeafc753e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 695 0x7f146568d070 0x36aeaffb5a60 
[1:1:0712/042202.226496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.227130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.227348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.252315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 697, 7f1467fd28db
[1:1:0712/042202.286264:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"695 0x7f146568d070 0x36aeaffb5a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.286632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"695 0x7f146568d070 0x36aeaffb5a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.287049:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 699
[1:1:0712/042202.287285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f146568d070 0x36aeb00b24e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 697 0x7f146568d070 0x36aeafc753e0 
[1:1:0712/042202.287633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.288324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.288539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.361338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 699, 7f1467fd28db
[1:1:0712/042202.377331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"697 0x7f146568d070 0x36aeafc753e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.377538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"697 0x7f146568d070 0x36aeafc753e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.377770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 701
[1:1:0712/042202.377905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f146568d070 0x36aeafb33760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 699 0x7f146568d070 0x36aeb00b24e0 
[1:1:0712/042202.378064:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.378369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.378474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.390325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 701, 7f1467fd28db
[1:1:0712/042202.398893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"699 0x7f146568d070 0x36aeb00b24e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.399077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"699 0x7f146568d070 0x36aeb00b24e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.399259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 703
[1:1:0712/042202.399386:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f146568d070 0x36aeafd74ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 701 0x7f146568d070 0x36aeafb33760 
[1:1:0712/042202.399555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.399915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.400039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.449086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 703, 7f1467fd28db
[1:1:0712/042202.479755:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7f146568d070 0x36aeafb33760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.480169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7f146568d070 0x36aeafb33760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.480562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 705
[1:1:0712/042202.480823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f146568d070 0x36aeafbeef60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 703 0x7f146568d070 0x36aeafd74ce0 
[1:1:0712/042202.481175:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.481817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.482048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.547454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 705, 7f1467fd28db
[1:1:0712/042202.557535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"703 0x7f146568d070 0x36aeafd74ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.557886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"703 0x7f146568d070 0x36aeafd74ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.558618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 707
[1:1:0712/042202.558907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f146568d070 0x36aeafb295e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 705 0x7f146568d070 0x36aeafbeef60 
[1:1:0712/042202.559214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.559709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.559973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.612688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 707, 7f1467fd28db
[1:1:0712/042202.626760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"705 0x7f146568d070 0x36aeafbeef60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.627043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"705 0x7f146568d070 0x36aeafbeef60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.627337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 709
[1:1:0712/042202.627499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f146568d070 0x36aeb023a060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 707 0x7f146568d070 0x36aeafb295e0 
[1:1:0712/042202.627728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.628371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.628619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.630863:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 709, 7f1467fd28db
[1:1:0712/042202.648939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7f146568d070 0x36aeafb295e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.649315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7f146568d070 0x36aeafb295e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.649716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 711
[1:1:0712/042202.650002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f146568d070 0x36aeafb2b4e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 709 0x7f146568d070 0x36aeb023a060 
[1:1:0712/042202.650347:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.651022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.651251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.705109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 711, 7f1467fd28db
[1:1:0712/042202.740230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7f146568d070 0x36aeb023a060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.740593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7f146568d070 0x36aeb023a060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.741046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 713
[1:1:0712/042202.741290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f146568d070 0x36aeb00ffe60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 711 0x7f146568d070 0x36aeafb2b4e0 
[1:1:0712/042202.741654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.742368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.742598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.812708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 713, 7f1467fd28db
[1:1:0712/042202.849380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"711 0x7f146568d070 0x36aeafb2b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.849750:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"711 0x7f146568d070 0x36aeafb2b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.850169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 715
[1:1:0712/042202.850402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f146568d070 0x36aeb0192260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 713 0x7f146568d070 0x36aeb00ffe60 
[1:1:0712/042202.850738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.851164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.851282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042202.917395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 715, 7f1467fd28db
[1:1:0712/042202.952685:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"713 0x7f146568d070 0x36aeb00ffe60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.953086:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"713 0x7f146568d070 0x36aeb00ffe60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042202.953494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 717
[1:1:0712/042202.953731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f146568d070 0x36aeb0034560 , 5:3_http://jxja.jxnews.com.cn/, 0, , 715 0x7f146568d070 0x36aeb0192260 
[1:1:0712/042202.954099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042202.954749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042202.954984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.007994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 717, 7f1467fd28db
[1:1:0712/042203.026329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"715 0x7f146568d070 0x36aeb0192260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.026632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"715 0x7f146568d070 0x36aeb0192260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.026962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 719
[1:1:0712/042203.027153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f146568d070 0x36aeb023d260 , 5:3_http://jxja.jxnews.com.cn/, 0, , 717 0x7f146568d070 0x36aeb0034560 
[1:1:0712/042203.027438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.027961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.028124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.052813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 719, 7f1467fd28db
[1:1:0712/042203.073017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"717 0x7f146568d070 0x36aeb0034560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.073315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"717 0x7f146568d070 0x36aeb0034560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.073641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 721
[1:1:0712/042203.073836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f146568d070 0x36aeb023cae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 719 0x7f146568d070 0x36aeb023d260 
[1:1:0712/042203.074155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.074671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.074958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.106202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 721, 7f1467fd28db
[1:1:0712/042203.122079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"719 0x7f146568d070 0x36aeb023d260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.122467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"719 0x7f146568d070 0x36aeb023d260 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.122899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 723
[1:1:0712/042203.123157:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f146568d070 0x36aeb00b2ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 721 0x7f146568d070 0x36aeb023cae0 
[1:1:0712/042203.123522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.124259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.124501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.156018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 723, 7f1467fd28db
[1:1:0712/042203.181246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"721 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.181451:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"721 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.181647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 725
[1:1:0712/042203.181758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f146568d070 0x36aeb0192560 , 5:3_http://jxja.jxnews.com.cn/, 0, , 723 0x7f146568d070 0x36aeb00b2ae0 
[1:1:0712/042203.181961:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.182283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.182440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.256733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 725, 7f1467fd28db
[1:1:0712/042203.266017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"723 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.266207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"723 0x7f146568d070 0x36aeb00b2ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.266398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 727
[1:1:0712/042203.266508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f146568d070 0x36aeb0183de0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 725 0x7f146568d070 0x36aeb0192560 
[1:1:0712/042203.266665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.267028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.267139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.312393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 727, 7f1467fd28db
[1:1:0712/042203.328595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"725 0x7f146568d070 0x36aeb0192560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.328899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"725 0x7f146568d070 0x36aeb0192560 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.329318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 729
[1:1:0712/042203.329524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f146568d070 0x36aeb0250960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 727 0x7f146568d070 0x36aeb0183de0 
[1:1:0712/042203.329807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.330556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.330820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.332864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 729, 7f1467fd28db
[1:1:0712/042203.353106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"727 0x7f146568d070 0x36aeb0183de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.353463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"727 0x7f146568d070 0x36aeb0183de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.353864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 731
[1:1:0712/042203.354129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f146568d070 0x36aeb017b4e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 729 0x7f146568d070 0x36aeb0250960 
[1:1:0712/042203.354419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.354977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.355155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.390522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 731, 7f1467fd28db
[1:1:0712/042203.403344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"729 0x7f146568d070 0x36aeb0250960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.403624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"729 0x7f146568d070 0x36aeb0250960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.403891:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 733
[1:1:0712/042203.404098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f146568d070 0x36aeb00cb3e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 731 0x7f146568d070 0x36aeb017b4e0 
[1:1:0712/042203.404321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.404725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.404865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.460081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 733, 7f1467fd28db
[1:1:0712/042203.490466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"731 0x7f146568d070 0x36aeb017b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.490761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"731 0x7f146568d070 0x36aeb017b4e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.491107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 735
[1:1:0712/042203.491316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f146568d070 0x36aeaffa7b60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 733 0x7f146568d070 0x36aeb00cb3e0 
[1:1:0712/042203.491602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.492204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.492393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.555646:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 735, 7f1467fd28db
[1:1:0712/042203.579629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7f146568d070 0x36aeb00cb3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.579848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7f146568d070 0x36aeb00cb3e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.580198:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 737
[1:1:0712/042203.580508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f146568d070 0x36aeb01bd9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 735 0x7f146568d070 0x36aeaffa7b60 
[1:1:0712/042203.580908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.581645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.581900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.665755:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 737, 7f1467fd28db
[1:1:0712/042203.689673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"735 0x7f146568d070 0x36aeaffa7b60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.689891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"735 0x7f146568d070 0x36aeaffa7b60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.690107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 739
[1:1:0712/042203.690223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7f146568d070 0x36aeb0187e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 737 0x7f146568d070 0x36aeb01bd9e0 
[1:1:0712/042203.690384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.690685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.690796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.762377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 739, 7f1467fd28db
[1:1:0712/042203.798826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"737 0x7f146568d070 0x36aeb01bd9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.799173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"737 0x7f146568d070 0x36aeb01bd9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.799517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 741
[1:1:0712/042203.799710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f146568d070 0x36aeb0191960 , 5:3_http://jxja.jxnews.com.cn/, 0, , 739 0x7f146568d070 0x36aeb0187e60 
[1:1:0712/042203.799997:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.800803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.801103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.844436:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 741, 7f1467fd28db
[1:1:0712/042203.856609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"739 0x7f146568d070 0x36aeb0187e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.856811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"739 0x7f146568d070 0x36aeb0187e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.856999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 743
[1:1:0712/042203.857222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7f146568d070 0x36aeb01ea9e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 741 0x7f146568d070 0x36aeb0191960 
[1:1:0712/042203.857577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.858232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.858455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042203.903210:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 743, 7f1467fd28db
[1:1:0712/042203.932730:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"741 0x7f146568d070 0x36aeb0191960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.933041:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"741 0x7f146568d070 0x36aeb0191960 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042203.933387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 745
[1:1:0712/042203.933573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f146568d070 0x36aeb00bafe0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 743 0x7f146568d070 0x36aeb01ea9e0 
[1:1:0712/042203.933848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042203.934394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042203.934575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042204.040491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/042204.040733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042204.066540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 745, 7f1467fd28db
[1:1:0712/042204.098696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"743 0x7f146568d070 0x36aeb01ea9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.099063:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"743 0x7f146568d070 0x36aeb01ea9e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.099497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 753
[1:1:0712/042204.099745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f146568d070 0x36aeb0187060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 745 0x7f146568d070 0x36aeb00bafe0 
[1:1:0712/042204.100107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042204.100794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042204.101017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042204.222955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 753, 7f1467fd28db
[1:1:0712/042204.258480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"745 0x7f146568d070 0x36aeb00bafe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.258849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"745 0x7f146568d070 0x36aeb00bafe0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.259280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 756
[1:1:0712/042204.259549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f146568d070 0x36aeb023cae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 753 0x7f146568d070 0x36aeb0187060 
[1:1:0712/042204.259910:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042204.260706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042204.260940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042204.313158:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 756, 7f1467fd28db
[1:1:0712/042204.332642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"753 0x7f146568d070 0x36aeb0187060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.332836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"753 0x7f146568d070 0x36aeb0187060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.333036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 759
[1:1:0712/042204.333152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7f146568d070 0x36aeb0189ae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 756 0x7f146568d070 0x36aeb023cae0 
[1:1:0712/042204.333745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042204.334742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042204.334993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[73723:73723:0712/042204.438997:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[73723:73723:0712/042204.441141:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[73723:73723:0712/042204.457633:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://jxja.jxnews.com.cn/
[1:1:0712/042204.490616:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 759, 7f1467fd28db
[1:1:0712/042204.516040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"756 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.516427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"756 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.516768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 773
[1:1:0712/042204.516962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 773 0x7f146568d070 0x36aeb023cae0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 759 0x7f146568d070 0x36aeb0189ae0 
[1:1:0712/042204.517279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042204.517807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042204.517983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[73723:73723:0712/042204.590796:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/042204.597130:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/042204.795858:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 773, 7f1467fd28db
[1:1:0712/042204.819199:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"759 0x7f146568d070 0x36aeb0189ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.819711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"759 0x7f146568d070 0x36aeb0189ae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042204.820188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 789
[1:1:0712/042204.820517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f146568d070 0x36aeb018c8e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 773 0x7f146568d070 0x36aeb023cae0 
[1:1:0712/042204.820924:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042204.821553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042204.821791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042205.457584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042205.457907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[73723:73723:0712/042205.651312:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[73723:73723:0712/042205.657215:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[73723:73735:0712/042205.690403:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[73723:73735:0712/042205.690533:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[73723:73723:0712/042205.690781:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[73723:73723:0712/042205.690883:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2, 4
[73723:73723:0712/042205.691075:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 11:22:05 GMT Content-Type: text/html Content-Length: 6530 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.efa13c4c.5d286d5c.71452673; path=/; expires=Mon, 09-Jul-29 11:22:04 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.efb13c4c.5d286d5c.eba98208; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=60, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 11:27:04 GMT Last-Modified: Fri, 12 Jul 2019 11:22:04 GMT DPOOL_HEADER: qubele36 Content-Encoding: gzip LB_HEADER: venus244 Strict-Transport-Security: max-age=31536000; preload  ,73819, 5
[1:7:0712/042205.693431:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042205.760345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 789, 7f1467fd28db
[1:1:0712/042205.777185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"773 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042205.777388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"773 0x7f146568d070 0x36aeb023cae0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042205.777640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 829
[1:1:0712/042205.777864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f146568d070 0x36aeb01794e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 789 0x7f146568d070 0x36aeb018c8e0 
[1:1:0712/042205.778140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042205.778656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042205.778844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042206.480671:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://widget.weibo.com/
[1:1:0712/042206.861399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042206.861710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042207.096034:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 829, 7f1467fd28db
[1:1:0712/042207.107363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"789 0x7f146568d070 0x36aeb018c8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042207.107561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"789 0x7f146568d070 0x36aeb018c8e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042207.107750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 852
[1:1:0712/042207.107909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f146568d070 0x36aeb02423e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 829 0x7f146568d070 0x36aeb01794e0 
[1:1:0712/042207.108071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042207.108375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042207.108483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042207.397567:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[73723:73723:0712/042207.412706:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/, 4
[73723:73723:0712/042207.412907:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0712/042207.436100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042207.436406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042207.778754:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 852, 7f1467fd28db
[1:1:0712/042207.815012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"829 0x7f146568d070 0x36aeb01794e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042207.815320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"829 0x7f146568d070 0x36aeb01794e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042207.815645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 878
[1:1:0712/042207.815838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7f146568d070 0x36aeb0cf80e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 852 0x7f146568d070 0x36aeb02423e0 
[1:1:0712/042207.816188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042207.816713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042207.816888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042207.846711:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042208.152300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042208.152499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042208.502984:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042208.503283:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042208.520933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 880 0x7f146568d070 0x36aeb0549d60 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042208.557484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , , 
            var $CONFIG = {
                $lang: "zh",
                $oid: "",
                
[1:1:0712/042208.557699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042208.569138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 878, 7f1467fd28db
[1:1:0712/042208.608251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"852 0x7f146568d070 0x36aeb02423e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042208.608621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"852 0x7f146568d070 0x36aeb02423e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042208.609050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 901
[1:1:0712/042208.609348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7f146568d070 0x36aeb0190ee0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 878 0x7f146568d070 0x36aeb0cf80e0 
[1:1:0712/042208.609704:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042208.610343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042208.610604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042208.669566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042208.669879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042209.247426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 901, 7f1467fd28db
[1:1:0712/042209.274909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"878 0x7f146568d070 0x36aeb0cf80e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042209.275257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"878 0x7f146568d070 0x36aeb0cf80e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042209.275726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 920
[1:1:0712/042209.275960:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7f146568d070 0x36aeb0192460 , 5:3_http://jxja.jxnews.com.cn/, 0, , 901 0x7f146568d070 0x36aeb0190ee0 
[1:1:0712/042209.276285:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042209.276861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042209.277086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042209.325683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042209.326111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042209.579928:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042209.834212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 920, 7f1467fd28db
[1:1:0712/042209.871834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"901 0x7f146568d070 0x36aeb0190ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042209.872162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"901 0x7f146568d070 0x36aeb0190ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042209.872627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 938
[1:1:0712/042209.872912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f146568d070 0x36aeb0e816e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 920 0x7f146568d070 0x36aeb0192460 
[1:1:0712/042209.873269:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042209.874018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042209.874329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042209.948111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042209.948510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042210.446309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 938, 7f1467fd28db
[1:1:0712/042210.467192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"920 0x7f146568d070 0x36aeb0192460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042210.467515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"920 0x7f146568d070 0x36aeb0192460 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042210.468049:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 956
[1:1:0712/042210.468301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f146568d070 0x36aeb0e26ce0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 938 0x7f146568d070 0x36aeb0e816e0 
[1:1:0712/042210.468638:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042210.469329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042210.469559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042210.506512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042210.506872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042210.610363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 944 0x7f14659f5bd0 0x36aeb018d358 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042210.617973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , , var STK=function(){var a={};var b=[];a.inc=function(a,b){return true};a.register=function(c,d){var e
[1:1:0712/042210.618343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042210.688769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x19ddffd3dba0, 0x36aeafb34160
[1:1:0712/042210.689080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", 25
[1:1:0712/042210.690034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 961
[1:1:0712/042210.690316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7f146568d070 0x36aeafaf42e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 944 0x7f14659f5bd0 0x36aeb018d358 
[1:1:0712/042210.855851:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0447459, 471, 1
[1:1:0712/042210.856157:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042211.223929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 956, 7f1467fd28db
[1:1:0712/042211.252458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"938 0x7f146568d070 0x36aeb0e816e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042211.252781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"938 0x7f146568d070 0x36aeb0e816e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042211.253241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 975
[1:1:0712/042211.253496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 975 0x7f146568d070 0x36aeb0e81160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 956 0x7f146568d070 0x36aeb0e26ce0 
[1:1:0712/042211.253821:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042211.254393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042211.254608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042211.301323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042211.301620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042211.471834:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042211.472330:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042211.482645:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 966 0x7f146568d070 0x36aeb0e7b960 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042211.502604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , , STK.register("kit.extra.language", function($) {
    window.$LANG || (window.$LANG = {});
    return
[1:1:0712/042211.503009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
		remove user.10_89973e8f -> 0
		remove user.11_14d9d97d -> 0
		remove user.12_72af6638 -> 0
		remove user.13_e2f676b6 -> 0
		remove user.14_6fb5f9b7 -> 0
		remove user.10_793a5f18 -> 0
[1:1:0712/042212.869092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x19ddffd3dba0, 0x36aeafb34298
[1:1:0712/042212.869409:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", 25
[1:1:0712/042212.870238:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 995
[1:1:0712/042212.870590:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f146568d070 0x36aeb018b160 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 966 0x7f146568d070 0x36aeb0e7b960 
[1:1:0712/042212.875560:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.40258, 0, 0
[1:1:0712/042212.875810:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042212.931687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 961, 7f1467fd2881
[1:1:0712/042212.971553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2e9cb39cf670","ptid":"944 0x7f14659f5bd0 0x36aeb018d358 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042212.971924:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"944 0x7f14659f5bd0 0x36aeb018d358 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042212.972370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042212.973377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/042212.973669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042212.974864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x19ddffd3dba0, 0x36aeafb34150
[1:1:0712/042212.975088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", 25
[1:1:0712/042212.975926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1002
[1:1:0712/042212.976205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7f146568d070 0x36aeb1081160 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 961 0x7f146568d070 0x36aeafaf42e0 
[1:1:0712/042213.211242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042213.211555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042213.214903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 975, 7f1467fd28db
[1:1:0712/042213.238878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"956 0x7f146568d070 0x36aeb0e26ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042213.239218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"956 0x7f146568d070 0x36aeb0e26ce0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042213.239668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1010
[1:1:0712/042213.239957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f146568d070 0x36aeb012b860 , 5:3_http://jxja.jxnews.com.cn/, 0, , 975 0x7f146568d070 0x36aeb0e81160 
[1:1:0712/042213.240399:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042213.240982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042213.241200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042213.916779:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042213.917062:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042213.922041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 996 0x7f146568d070 0x36aeb1035360 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042213.925429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , , (function(){var ac=window,A=document,r=navigator,Q=r.userAgent,ah=ac.screen,j;try{j=ac.location.href
[1:1:0712/042213.925757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042213.956393:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042213.978236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042214.008630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 995, 7f1467fd2881
[1:1:0712/042214.041961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2e9cb39cf670","ptid":"966 0x7f146568d070 0x36aeb0e7b960 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042214.042351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"966 0x7f146568d070 0x36aeb0e7b960 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042214.042823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042214.043898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , h, (){var a=+(new Date);do{f.process.call(f.context,e.shift())}while(e.length>0&&+(new Date)-a<f.execTi
[1:1:0712/042214.044188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042214.407691:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1002, 7f1467fd2881
[1:1:0712/042214.453538:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2e9cb39cf670","ptid":"961 0x7f146568d070 0x36aeafaf42e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042214.453951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"961 0x7f146568d070 0x36aeafaf42e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/042214.454368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2"
[1:1:0712/042214.455368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 2e9cb39cf670, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/042214.455639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=240&fansRow=2&ptype=0&speed=0&skin=5&isTitle=0&noborder=0&isWeibo=1&isFans=0&uid=1767961804&verifier=c2b9a5b2", "widget.weibo.com", 4, 1, http://jxja.jxnews.com.cn, jxja.jxnews.com.cn, 3
[1:1:0712/042214.576774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , , document.readyState
[1:1:0712/042214.577061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042214.711814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1010, 7f1467fd28db
[1:1:0712/042214.745469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"975 0x7f146568d070 0x36aeb0e81160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042214.745839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"975 0x7f146568d070 0x36aeb0e81160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042214.746301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1054
[1:1:0712/042214.746530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7f146568d070 0x36aeb0fd4de0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1010 0x7f146568d070 0x36aeb012b860 
[1:1:0712/042214.746956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042214.747549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042214.747869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042215.690831:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1054, 7f1467fd28db
[1:1:0712/042215.720564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1010 0x7f146568d070 0x36aeb012b860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042215.720929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1010 0x7f146568d070 0x36aeb012b860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042215.721478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1073
[1:1:0712/042215.721740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7f146568d070 0x36aeb11ba760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1054 0x7f146568d070 0x36aeb0fd4de0 
[1:1:0712/042215.722188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042215.722765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042215.723062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042216.197160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1073, 7f1467fd28db
[1:1:0712/042216.241355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1054 0x7f146568d070 0x36aeb0fd4de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042216.241732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1054 0x7f146568d070 0x36aeb0fd4de0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042216.242218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1086
[1:1:0712/042216.242483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f146568d070 0x36aeaff98160 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1073 0x7f146568d070 0x36aeb11ba760 
[1:1:0712/042216.242895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042216.243498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042216.243753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042216.316997:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://jxja.jxnews.com.cn/favicon.ico"
[1:1:0712/042216.809364:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1086, 7f1467fd28db
[1:1:0712/042216.857766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1073 0x7f146568d070 0x36aeb11ba760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042216.858309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1073 0x7f146568d070 0x36aeb11ba760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042216.858764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1100
[1:1:0712/042216.859013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f146568d070 0x36aeb11e7860 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1086 0x7f146568d070 0x36aeaff98160 
[1:1:0712/042216.859463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042216.860096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042216.860375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042217.136711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1100, 7f1467fd28db
[1:1:0712/042217.164665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1086 0x7f146568d070 0x36aeaff98160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.165022:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1086 0x7f146568d070 0x36aeaff98160 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.165465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1117
[1:1:0712/042217.165773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1117 0x7f146568d070 0x36aeb11ecb60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1100 0x7f146568d070 0x36aeb11e7860 
[1:1:0712/042217.166389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042217.167191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042217.167451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042217.362056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1117, 7f1467fd28db
[1:1:0712/042217.403617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1100 0x7f146568d070 0x36aeb11e7860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.403979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1100 0x7f146568d070 0x36aeb11e7860 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.404480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1125
[1:1:0712/042217.404811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1125 0x7f146568d070 0x36aeb01991e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1117 0x7f146568d070 0x36aeb11ecb60 
[1:1:0712/042217.405413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042217.406166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042217.406458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042217.599943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1125, 7f1467fd28db
[1:1:0712/042217.616349:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1117 0x7f146568d070 0x36aeb11ecb60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.616764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1117 0x7f146568d070 0x36aeb11ecb60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.617144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1132
[1:1:0712/042217.617369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1132 0x7f146568d070 0x36aeb11f8f60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1125 0x7f146568d070 0x36aeb01991e0 
[1:1:0712/042217.617764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042217.618296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042217.618541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042217.896645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1132, 7f1467fd28db
[1:1:0712/042217.943265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1125 0x7f146568d070 0x36aeb01991e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.943824:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1125 0x7f146568d070 0x36aeb01991e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042217.944261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1141
[1:1:0712/042217.944497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7f146568d070 0x36aeb1073060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1132 0x7f146568d070 0x36aeb11f8f60 
[1:1:0712/042217.944959:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042217.945591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042217.945807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.173650:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1141, 7f1467fd28db
[1:1:0712/042218.225971:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1132 0x7f146568d070 0x36aeb11f8f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.226184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1132 0x7f146568d070 0x36aeb11f8f60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.226397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1148
[1:1:0712/042218.226507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1148 0x7f146568d070 0x36aeb0fe4a60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1141 0x7f146568d070 0x36aeb1073060 
[1:1:0712/042218.226729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.227025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.227129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.275186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1148, 7f1467fd28db
[1:1:0712/042218.317285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1141 0x7f146568d070 0x36aeb1073060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.317592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1141 0x7f146568d070 0x36aeb1073060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.318089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1151
[1:1:0712/042218.318333:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1151 0x7f146568d070 0x36aeb1073e60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1148 0x7f146568d070 0x36aeb0fe4a60 
[1:1:0712/042218.318793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.319428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.319695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.358018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1151, 7f1467fd28db
[1:1:0712/042218.385093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1148 0x7f146568d070 0x36aeb0fe4a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.385483:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1148 0x7f146568d070 0x36aeb0fe4a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.385952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1153
[1:1:0712/042218.386202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7f146568d070 0x36aeb0fd8760 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1151 0x7f146568d070 0x36aeb1073e60 
[1:1:0712/042218.386659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.387313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.387554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.439671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1153, 7f1467fd28db
[1:1:0712/042218.475150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1151 0x7f146568d070 0x36aeb1073e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.475355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1151 0x7f146568d070 0x36aeb1073e60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.475565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1157
[1:1:0712/042218.475712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7f146568d070 0x36aeb0fd8360 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1153 0x7f146568d070 0x36aeb0fd8760 
[1:1:0712/042218.475920:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.476216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.476324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.509395:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1157, 7f1467fd28db
[1:1:0712/042218.530295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1153 0x7f146568d070 0x36aeb0fd8760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.530705:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1153 0x7f146568d070 0x36aeb0fd8760 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.531154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1159
[1:1:0712/042218.531396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1159 0x7f146568d070 0x36aeb1163660 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1157 0x7f146568d070 0x36aeb0fd8360 
[1:1:0712/042218.531912:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.532581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.532828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.618868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1159, 7f1467fd28db
[1:1:0712/042218.643527:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1157 0x7f146568d070 0x36aeb0fd8360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.643792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1157 0x7f146568d070 0x36aeb0fd8360 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.644025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1161
[1:1:0712/042218.644152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1161 0x7f146568d070 0x36aeb11b5ee0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1159 0x7f146568d070 0x36aeb1163660 
[1:1:0712/042218.644358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.644657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.644786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.701314:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1161, 7f1467fd28db
[1:1:0712/042218.729034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1159 0x7f146568d070 0x36aeb1163660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.729245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1159 0x7f146568d070 0x36aeb1163660 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.729451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1163
[1:1:0712/042218.729563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7f146568d070 0x36aeb0fa5060 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1161 0x7f146568d070 0x36aeb11b5ee0 
[1:1:0712/042218.729786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.730089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.730194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.748199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1163, 7f1467fd28db
[1:1:0712/042218.779785:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1161 0x7f146568d070 0x36aeb11b5ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.780001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1161 0x7f146568d070 0x36aeb11b5ee0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.780224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1166
[1:1:0712/042218.780340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7f146568d070 0x36aeb0fdab60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1163 0x7f146568d070 0x36aeb0fa5060 
[1:1:0712/042218.780563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.780886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.781003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.854403:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1166, 7f1467fd28db
[1:1:0712/042218.886384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1163 0x7f146568d070 0x36aeb0fa5060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.886597:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1163 0x7f146568d070 0x36aeb0fa5060 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.886812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1168
[1:1:0712/042218.886937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7f146568d070 0x36aeb00c89e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1166 0x7f146568d070 0x36aeb0fdab60 
[1:1:0712/042218.887167:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.887465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.887571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042218.969643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1168, 7f1467fd28db
[1:1:0712/042218.986211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1166 0x7f146568d070 0x36aeb0fdab60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.986423:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1166 0x7f146568d070 0x36aeb0fdab60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042218.986628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1170
[1:1:0712/042218.986756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7f146568d070 0x36aeb0fe10e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1168 0x7f146568d070 0x36aeb00c89e0 
[1:1:0712/042218.987023:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042218.987328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042218.987434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.056205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1170, 7f1467fd28db
[1:1:0712/042219.081644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1168 0x7f146568d070 0x36aeb00c89e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.081882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1168 0x7f146568d070 0x36aeb00c89e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.082100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1172
[1:1:0712/042219.082213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7f146568d070 0x36aeb10745e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1170 0x7f146568d070 0x36aeb0fe10e0 
[1:1:0712/042219.082422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.083084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.083329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.155508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1172, 7f1467fd28db
[1:1:0712/042219.170876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1170 0x7f146568d070 0x36aeb0fe10e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.171087:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1170 0x7f146568d070 0x36aeb0fe10e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.171287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1174
[1:1:0712/042219.171397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f146568d070 0x36aeb1162a60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1172 0x7f146568d070 0x36aeb10745e0 
[1:1:0712/042219.171598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.171935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.172061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.227057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1174, 7f1467fd28db
[1:1:0712/042219.277924:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1172 0x7f146568d070 0x36aeb10745e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.278240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1172 0x7f146568d070 0x36aeb10745e0 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.278600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1176
[1:1:0712/042219.278805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f146568d070 0x36aeb0190c60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1174 0x7f146568d070 0x36aeb1162a60 
[1:1:0712/042219.279197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.279719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.279951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.281877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1176, 7f1467fd28db
[1:1:0712/042219.332404:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1174 0x7f146568d070 0x36aeb1162a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.332718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1174 0x7f146568d070 0x36aeb1162a60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.333101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1179
[1:1:0712/042219.333305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1179 0x7f146568d070 0x36aeb0fe4d60 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1176 0x7f146568d070 0x36aeb0190c60 
[1:1:0712/042219.333677:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.334221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.334400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.441115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1179, 7f1467fd28db
[1:1:0712/042219.465083:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1176 0x7f146568d070 0x36aeb0190c60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.465331:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1176 0x7f146568d070 0x36aeb0190c60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.465551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1182
[1:1:0712/042219.465669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1182 0x7f146568d070 0x36aeb0fe52e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1179 0x7f146568d070 0x36aeb0fe4d60 
[1:1:0712/042219.465870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.466195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.466306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0712/042219.512109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1182, 7f1467fd28db
[1:1:0712/042219.558810:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1179 0x7f146568d070 0x36aeb0fe4d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.559103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1179 0x7f146568d070 0x36aeb0fe4d60 ","rf":"5:3_http://jxja.jxnews.com.cn/"}
[1:1:0712/042219.559377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1184
[1:1:0712/042219.559531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7f146568d070 0x36aeb11645e0 , 5:3_http://jxja.jxnews.com.cn/, 0, , 1182 0x7f146568d070 0x36aeb0fe52e0 
[1:1:0712/042219.559816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jxja.jxnews.com.cn/thx/"
[1:1:0712/042219.560247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jxja.jxnews.com.cn/, 2e9cb38a2860, , Marquee, (){ 
  if(demo.scrollLeft<=0) 
  demo.scrollLeft+=demo2.offsetWidth 
  else{ 
  demo.scrollLeft-- 
 
[1:1:0712/042219.560390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jxja.jxnews.com.cn/thx/", "jxja.jxnews.com.cn", 3, 1, , , 0
[1:1:0100/000000.636557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jxja.jxnews.com.cn/, 1184, 7f1467fd28db
