[0711/202858.436789:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202858.437098:INFO:switcher_clone.cc(787)] backtrace rip is 7f43b9ab5891
[0711/202859.450751:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202859.451318:INFO:switcher_clone.cc(787)] backtrace rip is 7fa2b8b27891
[1:1:0711/202859.464019:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/202859.464286:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/202859.469724:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[9354:9354:0711/202900.627579:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/68a96a0d-e696-469b-b22e-e134412e005a
[0711/202901.097783:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/202901.098086:INFO:switcher_clone.cc(787)] backtrace rip is 7f3ff56b2891
[9354:9354:0711/202901.195064:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9354:9385:0711/202901.195957:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/202901.196188:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/202901.196410:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/202901.196969:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/202901.197126:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/202901.199971:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5fb310f, 1
[1:1:0711/202901.200465:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1cbea56c, 0
[1:1:0711/202901.200699:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x11889042, 3
[1:1:0711/202901.200929:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b6daf2a, 2
[1:1:0711/202901.201183:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6cffffffa5ffffffbe1c 0f31fffffffb05 2affffffaf6d1b 42ffffff90ffffff8811 , 10104, 4
[1:1:0711/202901.202507:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9354:9385:0711/202901.202775:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGl��1�*�mB���+
[9354:9385:0711/202901.202863:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is l��1�*�mB���"�+
[9354:9385:0711/202901.203203:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/202901.203022:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2b6d620a0, 3
[9354:9385:0711/202901.203319:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9400, 4, 6ca5be1c 0f31fb05 2aaf6d1b 42908811 
[1:1:0711/202901.203364:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2b6eed080, 2
[1:1:0711/202901.203641:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2a0bb0d20, -2
[1:1:0711/202901.228634:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/202901.229788:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b6daf2a
[1:1:0711/202901.231366:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b6daf2a
[1:1:0711/202901.232493:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b6daf2a
[1:1:0711/202901.233026:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.233131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.233221:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.233370:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.233594:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b6daf2a
[1:1:0711/202901.233726:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa2b8b277ba
[1:1:0711/202901.233798:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa2b8b1edef, 7fa2b8b2777a, 7fa2b8b290cf
[1:1:0711/202901.235361:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b6daf2a
[1:1:0711/202901.235792:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b6daf2a
[1:1:0711/202901.236735:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b6daf2a
[1:1:0711/202901.239286:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.239542:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.239795:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.240027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b6daf2a
[1:1:0711/202901.241644:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b6daf2a
[1:1:0711/202901.242124:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa2b8b277ba
[1:1:0711/202901.242318:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa2b8b1edef, 7fa2b8b2777a, 7fa2b8b290cf
[1:1:0711/202901.250834:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/202901.251377:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/202901.251555:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe80591b78, 0x7ffe80591af8)
[1:1:0711/202901.269621:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/202901.275432:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9389:9389:0711/202901.366908:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9389
[9414:9414:0711/202901.368217:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9414
[9354:9354:0711/202901.668877:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9354:9354:0711/202901.670301:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9354:9366:0711/202901.694088:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9354:9366:0711/202901.694193:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[9354:9354:0711/202901.694451:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9354:9354:0711/202901.694555:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9354:9354:0711/202901.694758:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9400, 4
[1:7:0711/202901.696835:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9354:9378:0711/202901.734758:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/202901.838545:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x43b24175220
[1:1:0711/202901.838872:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/202902.221330:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[9354:9354:0711/202903.931840:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9354:9354:0711/202903.932057:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/202903.978399:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202903.982589:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/202905.074926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/202905.075236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202905.096222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/202905.096435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202905.122276:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202905.332384:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202905.332553:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202905.779959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202905.788023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/202905.788277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202905.821144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202905.831846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/202905.832094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202905.844191:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/202905.847838:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x43b24173e20
[1:1:0711/202905.848042:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9354:9354:0711/202905.849889:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9354:9354:0711/202905.869837:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9354:9354:0711/202905.901131:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9354:9354:0711/202905.901228:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[9354:9354:0711/202905.907867:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/202905.937524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202906.899365:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fa2a278b2e0 0x43b2443c9e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202906.900890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/202906.901154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202906.902615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9354:9354:0711/202906.973921:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/202906.976268:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x43b24174820
[1:1:0711/202906.976505:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9354:9354:0711/202906.980951:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/202906.999150:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/202906.999423:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9354:9354:0711/202907.000791:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9354:9354:0711/202907.012438:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9354:9354:0711/202907.013446:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9354:9366:0711/202907.019465:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9354:9366:0711/202907.019557:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9354:9354:0711/202907.019699:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9354:9354:0711/202907.019822:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9354:9354:0711/202907.019955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9400, 4
[1:7:0711/202907.023477:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/202907.535440:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/202908.037119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fa2a278b2e0 0x43b2417c260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202908.038141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/202908.038384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202908.039168:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202908.197423:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9354:9354:0711/202908.204400:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9354:9354:0711/202908.204530:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/202908.697462:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[9354:9354:0711/202908.949813:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9354:9385:0711/202908.950374:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/202908.950576:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/202908.950809:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/202908.951314:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/202908.951590:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/202908.954397:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1a324392, 1
[1:1:0711/202908.954736:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x17929a61, 0
[1:1:0711/202908.954847:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a0875ae, 3
[1:1:0711/202908.954948:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x229d6ee, 2
[1:1:0711/202908.955049:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 61ffffff9affffff9217 ffffff9243321a ffffffeeffffffd62902 ffffffae75082a , 10104, 5
[1:1:0711/202908.955985:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9354:9385:0711/202908.956161:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGa���C2��)�u*r�+
[9354:9385:0711/202908.956277:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is a���C2��)�u*(r�+
[9354:9385:0711/202908.956468:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9452, 5, 619a9217 9243321a eed62902 ae75082a 
[1:1:0711/202908.956722:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2b6d620a0, 3
[1:1:0711/202908.956868:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2b6eed080, 2
[1:1:0711/202908.956992:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2a0bb0d20, -2
[1:1:0711/202908.972657:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/202908.972874:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 229d6ee
[1:1:0711/202908.973048:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 229d6ee
[1:1:0711/202908.973350:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 229d6ee
[1:1:0711/202908.973789:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.973890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.973980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.974069:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.974367:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 229d6ee
[1:1:0711/202908.974499:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa2b8b277ba
[1:1:0711/202908.974572:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa2b8b1edef, 7fa2b8b2777a, 7fa2b8b290cf
[1:1:0711/202908.976032:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 229d6ee
[1:1:0711/202908.976199:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 229d6ee
[1:1:0711/202908.976522:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 229d6ee
[1:1:0711/202908.977196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.977349:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.977443:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.977538:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 229d6ee
[1:1:0711/202908.977973:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 229d6ee
[1:1:0711/202908.978130:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa2b8b277ba
[1:1:0711/202908.978201:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa2b8b1edef, 7fa2b8b2777a, 7fa2b8b290cf
[1:1:0711/202908.980532:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/202908.980875:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/202908.980969:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe80591b78, 0x7ffe80591af8)
[1:1:0711/202908.993148:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/202908.995493:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/202909.155555:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202909.155837:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202909.191185:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x43b24137220
[1:1:0711/202909.191470:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/202909.804319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202909.809013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 048ac88ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/202909.809317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/202909.811759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9354:9354:0711/202910.068383:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9354:9354:0711/202910.075590:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9354:9366:0711/202910.103990:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9354:9366:0711/202910.104093:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[9354:9354:0711/202910.104638:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zt.ipr.zbj.com/
[9354:9354:0711/202910.104733:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zt.ipr.zbj.com/, https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382, 1
[9354:9354:0711/202910.104897:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://zt.ipr.zbj.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 03:29:10 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip Strict-Transport-Security: max-age=0  ,9452, 5
[1:7:0711/202910.109837:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/202910.122471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/202910.123548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 048ac87c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/202910.123774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/202910.161370:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://zt.ipr.zbj.com/
[9354:9354:0711/202910.334120:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zt.ipr.zbj.com/, https://zt.ipr.zbj.com/, 1
[9354:9354:0711/202910.334248:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://zt.ipr.zbj.com/, https://zt.ipr.zbj.com
[1:1:0711/202910.357957:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/202910.404348:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202910.461686:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202910.461905:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202910.542458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7fa2a0863070 0x43b2427e7e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202910.545047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , 
                    (function(w,d,m){
                        w[m]=w[m]||function(){(w[m].q=w[m].q|
[1:1:0711/202910.545280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202910.549454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7fa2a0863070 0x43b2427e7e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202910.553494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7fa2a0863070 0x43b2427e7e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202910.677368:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202910.679569:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/202910.679949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 048ac88ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/202910.680306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/202910.691569:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.229514, 541, 1
[1:1:0711/202910.691929:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202910.772755:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/202910.776648:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/202910.776974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 048ac88ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/202910.777328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/202911.244425:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202911.244744:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/202912.514072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 277 0x7fa2a0863070 0x43b244170e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202912.515411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , 
	// 缓存对象，页面加载完成后供删除使用
	var load = document.getElementById("J-load
[1:1:0711/202912.515734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202912.517541:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202912.579485:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0526528, 672, 1
[1:1:0711/202912.579818:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202913.395415:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202913.395720:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.401872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.403197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , 
    window.ZBJInfo = {
        pageDomain: "zbj.com",
        baseURI: "zbj.com",
        newStatic
[1:1:0711/202913.403506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202913.406819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.415041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.426561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.660384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202913.740224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7fa2a0863070 0x43b24414960 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202916.459429:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.06344, 0, 0
[1:1:0711/202916.459719:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202917.079432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.081832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , img.onload.img.onerror, () {
                window.ZBJInfo.sWebP = (img.width > 0) && (img.height > 0);
            }
[1:1:0711/202917.082058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202917.272032:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202917.272308:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.274271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.277325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , 
seajs.config({"map":[["as-ipr-zt:static/common/common.js","//as.zbjimg.com/static/as-ipr-zt/common/
[1:1:0711/202917.277582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202917.283949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.287473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.293367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.298169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.420860:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.480310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fa2a0863070 0x43b241f7de0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202917.795189:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202917.796048:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202918.496150:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202918.500060:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202918.500522:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202918.501017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202918.501357:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/202920.250188:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.97761, 0, 0
[1:1:0711/202920.250391:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/202920.871971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202920.872660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , img.onload.img.onerror, () {
                window.ZBJInfo.sWebP = (img.width > 0) && (img.height > 0);
            }
[1:1:0711/202920.872810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202920.990788:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202920.990939:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202920.992226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fa2a0863070 0x43b252207e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202920.992895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , 
seajs.config({"map":[["as-ipr-zt:static/common/common.js","//as.zbjimg.com/static/as-ipr-zt/common/
[1:1:0711/202920.993010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202920.999988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fa2a0863070 0x43b252207e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202921.007237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fa2a0863070 0x43b252207e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202921.017383:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fa2a0863070 0x43b252207e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202921.150760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fa2a0863070 0x43b252207e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202921.828624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202921.830176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/202921.830365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202921.851421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.086261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.087546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/202922.087869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202922.125211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.132913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , (function(){function p(){this.c="1272223850";this.ca="z";this.Y="pic1";this.V="";this.X="";this.D="1
[1:1:0711/202922.133250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202922.339589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/202922.339950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[9354:9354:0711/202922.661786:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1272223535&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s13.cnzz.com/z_stat.php?id=1272223535&web_id=1272223535 (17)
[9354:9354:0711/202922.662615:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1272223535&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s13.cnzz.com/z_stat.php?id=1272223535&web_id=1272223535 (17)
[9354:9354:0711/202922.665592:INFO:CONSOLE(1476)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s22.cnzz.com/z_stat.php?id=1272223850&show=pic1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382 (1476)
[9354:9354:0711/202922.666383:INFO:CONSOLE(1476)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://s22.cnzz.com/z_stat.php?id=1272223850&show=pic1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382 (1476)
[9354:9354:0711/202922.673044:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1272223850&show=pic1&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s22.cnzz.com/z_stat.php?id=1272223850&show=pic1 (17)
[9354:9354:0711/202922.673841:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1272223850&show=pic1&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s22.cnzz.com/z_stat.php?id=1272223850&show=pic1 (17)
[3:3:0711/202922.675584:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/202922.872514:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.874842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0711/202922.875096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202922.892086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.898980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202922.970109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202923.007177:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202923.011386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515, "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202923.579338:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.688128, 2, 0
[1:1:0711/202923.579580:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[9354:9354:0711/202923.794505:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/202928.278226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/202928.278486:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202928.283309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202928.284232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , B, (){c.removeEventListener("DOMContentLoaded",B,!1),e.ready()}
[1:1:0711/202928.284469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202929.426729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202929.758358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , document.readyState
[1:1:0711/202929.758643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202929.999471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202930.000503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0711/202930.000817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202932.773543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 656 0x7fa2a278b2e0 0x43b26f33060 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202932.777635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , function addScript(a,b,c){var d=document.createElement("script"),e=document.getElementsByTagName("sc
[1:1:0711/202932.777914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202933.492902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 657 0x7fa2a278b2e0 0x43b272b5ce0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202933.495462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , define("as-ipr-zt:static/common/common.js",["as-ipr-www:widget/common/global/global","as-ipr-www:wid
[1:1:0711/202933.495688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202933.517965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202934.236378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 661 0x7fa2a278b2e0 0x43b2673b3e0 , "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202934.238072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , define("as-common:components/sai/seer/seer.js",[],function(){!function(e){if(!e.Sai){var r=e.Sai={};
[1:1:0711/202934.238231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
[1:1:0711/202934.242691:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382"
[1:1:0711/202940.108113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zt.ipr.zbj.com/, 0c8e0cf22860, , , document.readyState
[1:1:0711/202940.108403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zt.ipr.zbj.com/trademark/sbcx/?_union_identify=29&_union_uid=17802635&_union_itemid=1614382", "zt.ipr.zbj.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[9354:9354:0711/202945.697806:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/202947.790859:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[9354:9354:0711/203009.669113:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
