[0712/024942.540192:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024942.540621:INFO:switcher_clone.cc(787)] backtrace rip is 7f9d6b4ef891
[0712/024943.572676:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024943.573112:INFO:switcher_clone.cc(787)] backtrace rip is 7f9c8309b891
[1:1:0712/024943.584924:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/024943.585196:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/024943.590648:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/024944.851508:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/024944.851774:INFO:switcher_clone.cc(787)] backtrace rip is 7fdd1aedb891
[60796:60796:0712/024944.986602:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/895eb3be-d597-4b65-9d04-2d291035e560
[60828:60828:0712/024945.073468:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=60828
[60841:60841:0712/024945.074081:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=60841
[60796:60796:0712/024945.517384:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[60796:60826:0712/024945.518184:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/024945.518477:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/024945.518737:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/024945.519462:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/024945.519685:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/024945.523144:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2b0d35ee, 1
[1:1:0712/024945.523538:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3cf069ef, 0
[1:1:0712/024945.523812:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a9bb318, 3
[1:1:0712/024945.524047:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a1fad9a, 2
[1:1:0712/024945.524366:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffef69fffffff03c ffffffee350d2b ffffff9affffffad1f2a 18ffffffb3ffffff9b2a , 10104, 4
[1:1:0712/024945.525529:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[60796:60826:0712/024945.525868:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�i�<�5+��*��*ڀ6
[60796:60826:0712/024945.525955:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �i�<�5+��*��*hYڀ6
[1:1:0712/024945.525844:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c812d60a0, 3
[1:1:0712/024945.526201:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c81461080, 2
[60796:60826:0712/024945.526385:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[60796:60826:0712/024945.526486:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 60849, 4, ef69f03c ee350d2b 9aad1f2a 18b39b2a 
[1:1:0712/024945.526403:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c6b124d20, -2
[1:1:0712/024945.545901:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/024945.546807:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1fad9a
[1:1:0712/024945.547736:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1fad9a
[1:1:0712/024945.549375:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1fad9a
[1:1:0712/024945.550835:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.551059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.551371:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.551614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.552304:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1fad9a
[1:1:0712/024945.552665:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9c8309b7ba
[1:1:0712/024945.552837:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9c83092def, 7f9c8309b77a, 7f9c8309d0cf
[1:1:0712/024945.559247:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1fad9a
[1:1:0712/024945.559671:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1fad9a
[1:1:0712/024945.560510:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1fad9a
[1:1:0712/024945.562722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.562978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.563207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.563442:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1fad9a
[1:1:0712/024945.564722:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1fad9a
[1:1:0712/024945.565120:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9c8309b7ba
[1:1:0712/024945.565320:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9c83092def, 7f9c8309b77a, 7f9c8309d0cf
[1:1:0712/024945.573148:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/024945.573635:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/024945.573869:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce309a8c8, 0x7ffce309a848)
[1:1:0712/024945.707296:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/024945.713208:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[60796:60796:0712/024946.192770:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/024946.194328:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/024946.219279:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[60796:60808:0712/024946.219428:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/024946.219525:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[60796:60796:0712/024946.219623:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[60796:60796:0712/024946.219806:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,60849, 4
[1:7:0712/024946.229863:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[60796:60821:0712/024946.287224:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/024946.390632:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x205fded6a220
[1:1:0712/024946.391052:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/024946.891326:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[60796:60796:0712/024948.211421:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[60796:60796:0712/024948.211541:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/024948.254450:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024948.257598:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024949.354361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/024949.354718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024949.370996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/024949.371335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024949.451574:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024949.853760:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024949.854063:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024950.245045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024950.255316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/024950.255590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024950.270804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024950.281839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/024950.282106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024950.286232:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/024950.289787:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x205fded68e20
[1:1:0712/024950.290017:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[60796:60796:0712/024950.290154:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[60796:60796:0712/024950.297265:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[60796:60796:0712/024950.330088:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[60796:60796:0712/024950.330253:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/024950.338812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024950.908187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f9c6ccff2e0 0x205fdeff8560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024950.909729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/024950.910019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024950.911725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[60796:60796:0712/024950.954120:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/024950.956444:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x205fded69820
[1:1:0712/024950.956700:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[60796:60796:0712/024950.961012:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/024950.976711:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/024950.976964:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[60796:60796:0712/024950.978064:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[60796:60796:0712/024950.988784:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/024950.989774:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/024950.995831:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[60796:60808:0712/024950.995920:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/024950.996074:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[60796:60796:0712/024950.996148:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[60796:60796:0712/024950.996286:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,60849, 4
[1:7:0712/024951.001038:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/024951.611445:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/024952.113894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f9c6ccff2e0 0x205fdefea0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024952.115001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/024952.115274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024952.116130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[60796:60796:0712/024952.189508:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[60796:60796:0712/024952.189582:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/024952.211648:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024952.733648:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[60796:60796:0712/024953.019237:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[60796:60826:0712/024953.019750:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/024953.020034:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/024953.020387:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/024953.021145:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/024953.021354:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/024953.024751:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6f6f87c, 1
[1:1:0712/024953.025428:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x9e16860, 0
[1:1:0712/024953.025710:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15507c34, 3
[1:1:0712/024953.025923:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ce90b81, 2
[1:1:0712/024953.026134:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6068ffffffe109 7cfffffff8fffffff606 ffffff810bffffffe92c 347c5015 , 10104, 5
[1:1:0712/024953.027211:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[60796:60826:0712/024953.027580:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING`h�	|����,4|P��6
[1:1:0712/024953.027495:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c812d60a0, 3
[60796:60826:0712/024953.027673:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is `h�	|����,4|P�琂6
[1:1:0712/024953.027741:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c81461080, 2
[1:1:0712/024953.027976:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9c6b124d20, -2
[60796:60826:0712/024953.028057:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 60894, 5, 6068e109 7cf8f606 810be92c 347c5015 
[1:1:0712/024953.053620:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/024953.054062:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ce90b81
[1:1:0712/024953.054448:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ce90b81
[1:1:0712/024953.055108:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ce90b81
[1:1:0712/024953.056635:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.056861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.057078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.057312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.058002:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ce90b81
[1:1:0712/024953.058349:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9c8309b7ba
[1:1:0712/024953.058522:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9c83092def, 7f9c8309b77a, 7f9c8309d0cf
[1:1:0712/024953.064533:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ce90b81
[1:1:0712/024953.064940:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ce90b81
[1:1:0712/024953.065708:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ce90b81
[1:1:0712/024953.067799:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.068098:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.068362:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.068594:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce90b81
[1:1:0712/024953.069870:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ce90b81
[1:1:0712/024953.070295:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9c8309b7ba
[1:1:0712/024953.070474:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9c83092def, 7f9c8309b77a, 7f9c8309d0cf
[1:1:0712/024953.078243:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/024953.078882:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/024953.079074:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce309a8c8, 0x7ffce309a848)
[1:1:0712/024953.210978:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/024953.215481:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/024953.269276:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024953.269510:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/024953.425256:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x205fded29220
[1:1:0712/024953.425560:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[60796:60796:0712/024953.539436:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/024953.541307:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60796:0712/024953.547189:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.techweb.com.cn/
[60796:60796:0712/024953.547273:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.techweb.com.cn/, http://www.techweb.com.cn/it/2019-07-04/2743070.shtml, 1
[60796:60796:0712/024953.547358:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.techweb.com.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 09:51:25 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Keep-Alive: timeout=120 X-Powered-By: PHP/5.5.7 on-server: tw_web_1 Content-Encoding: gzip  ,60894, 5
[60796:60808:0712/024953.552911:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[60796:60808:0712/024953.553032:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/024953.555157:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/024953.644069:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.techweb.com.cn/
[1:1:0712/024953.674191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/024953.679351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 15f7fe9ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/024953.679742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/024953.685849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[60796:60796:0712/024953.764762:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.techweb.com.cn/, http://www.techweb.com.cn/, 1
[60796:60796:0712/024953.764902:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.techweb.com.cn/, http://www.techweb.com.cn
[1:1:0712/024953.791939:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024953.885184:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024953.920269:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/024953.964468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024953.964808:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024954.019871:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/024954.020634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 15f7fe8a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/024954.020862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/024954.050864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 116 0x7f9c6add7070 0x205fdebae5e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024954.052304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
w
[1:1:0712/024954.052635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/024954.359769:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/024954.628280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f9c81461080 0x205fdec31240 1 0 0x205fdec31258 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024954.630599:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024954.643848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , /*! jQuery v3.2.1 | (c) JS Foundation and other contributors | jquery.org/license */
!function(a,b){
[1:1:0712/024954.644111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/024954.849384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 162 0x7f9c81461080 0x205fdec31240 1 0 0x205fdec31258 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024954.927981:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.082207, 110, 1
[1:1:0712/024954.928269:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/024955.559836:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/024955.560114:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024955.561013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 223 0x7f9c6add7070 0x205fdf0d76e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024955.562327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/024955.562542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/024955.572556:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024955.573072:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024955.573439:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024955.573854:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024955.574233:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/024955.602742:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f9c81461080 0x205fdf0ad7e0 1 0 0x205fdf0ad7f8 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/024955.607686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/024955.607989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
		remove user.10_9b5a06ac -> 0
		remove user.11_afe91eab -> 0
		remove user.12_f9b944bc -> 0
		remove user.13_89fd86a0 -> 0
		remove user.14_ec91a2cb -> 0
[60796:60796:0712/025008.636080:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/025008.642249:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[60796:60796:0712/025008.753483:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5341599&dri=0&dis=0&dai=0&ps=120x264&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562924997&rw=424&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562924997&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[60796:60796:0712/025008.757744:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5341599&dri=0&dis=0&dai=0&ps=120x264&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562924997&rw=424&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562924997&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[1:1:0712/025011.298031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/025011.298388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025012.173683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025012.176522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "9553b7fbd9b2d546","tuid" : "5341599_0","placement" : {"basic" : {"sspId
[1:1:0712/025012.176767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025012.216897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025012.226819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025012.232003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", 3500
[1:1:0712/025012.232568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 469
[1:1:0712/025012.232820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f9c6add7070 0x205fdef09960 , 5:3_http://www.techweb.com.cn/, 1, -5:3_http://www.techweb.com.cn/, 375
[1:1:0712/025012.239975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", 500
[1:1:0712/025012.240699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 470
[1:1:0712/025012.240957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7f9c6add7070 0x205fdf06dae0 , 5:3_http://www.techweb.com.cn/, 1, -5:3_http://www.techweb.com.cn/, 375
[1:1:0712/025012.244172:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", 50
[1:1:0712/025012.244774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 471
[1:1:0712/025012.245041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f9c6add7070 0x205fdf2204e0 , 5:3_http://www.techweb.com.cn/, 1, -5:3_http://www.techweb.com.cn/, 375
[1:1:0712/025012.429034:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[60796:60796:0712/025012.530013:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5345045&dri=0&dis=0&dai=0&ps=226x20&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925012&rw=424&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925013&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[60796:60796:0712/025012.539394:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5345045&dri=0&dis=0&dai=0&ps=226x20&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925012&rw=424&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925013&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[1:1:0712/025013.744974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025013.745291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025014.806609:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 471, 7f9c6d71c8db
[1:1:0712/025014.831033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ce49cde2860","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025014.831402:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.techweb.com.cn/","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025014.831799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 531
[1:1:0712/025014.832030:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7f9c6add7070 0x205fdfcba6e0 , 5:3_http://www.techweb.com.cn/, 0, , 471 0x7f9c6add7070 0x205fdf2204e0 
[1:1:0712/025014.832394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025014.833028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025014.833276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025014.890172:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 493, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025014.891590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "27aeb972766faf36","tuid" : "5345045_0","placement" : {"basic" : {"sspId
[1:1:0712/025014.891889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[60796:60796:0712/025014.928199:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025014.930444:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x205fded26020
[1:1:0712/025014.930718:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[60796:60796:0712/025014.934893:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[60796:60796:0712/025014.973733:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://www.techweb.com.cn/, http://www.techweb.com.cn/, 4
[60796:60796:0712/025014.973880:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://www.techweb.com.cn/, http://www.techweb.com.cn
[1:1:0712/025015.064843:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025015.069487:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025015.069406:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x205fded26020
[1:1:0712/025015.069614:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[60796:60796:0712/025015.075988:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe5345045_0, 5, 5, 
[60796:60796:0712/025015.106721:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.techweb.com.cn/, http://www.techweb.com.cn/, 5
[60796:60796:0712/025015.106866:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.techweb.com.cn/, http://www.techweb.com.cn
[1:1:0712/025015.117146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025015.159575:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 493, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025015.421289:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025015.421802:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025016.421236:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.26446, 0, 0
[1:1:0712/025016.421554:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025016.476693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 470, 7f9c6d71c8db
[1:1:0712/025016.502032:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ce49cde2860","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025016.502366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.techweb.com.cn/","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025016.502811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 585
[1:1:0712/025016.503052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7f9c6add7070 0x205fdfbd8560 , 5:3_http://www.techweb.com.cn/, 0, , 470 0x7f9c6add7070 0x205fdf06dae0 
[1:1:0712/025016.503381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025016.504086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025016.504301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025016.583075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025016.583386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025017.333179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 531, 7f9c6d71c8db
[1:1:0712/025017.359868:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"471 0x7f9c6add7070 0x205fdf2204e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025017.360198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"471 0x7f9c6add7070 0x205fdf2204e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025017.360635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 607
[1:1:0712/025017.360910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 607 0x7f9c6add7070 0x205fe07ae360 , 5:3_http://www.techweb.com.cn/, 0, , 531 0x7f9c6add7070 0x205fdfcba6e0 
[1:1:0712/025017.361240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025017.361881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025017.362097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025018.209881:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025018.210190:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.211424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f9c6add7070 0x205fe0762d60 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.212661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
   var a= $(window.frames["iframe5345045_0"].document).find("body").html();
if(a==""||a=="undefined
[1:1:0712/025018.212886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025018.245238:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3ce49ced7420, 5:3_http://www.techweb.com.cn/, 5:5_http://www.techweb.com.cn/, about:blank
[1:1:0712/025018.245560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, addEventListener, 
[1:1:0712/025018.245896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 2, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.248016:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.249957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.250245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 3, , , 0
[1:1:0712/025018.251541:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.251977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.252292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 4, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.253552:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.254494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){return a.className="i",!a.getAttribute("className")}
[1:1:0712/025018.254771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 5, , , 0
[1:1:0712/025018.256207:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.256864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, getAttribute, 
[1:1:0712/025018.257208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 6, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.258551:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.259104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.259424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 7, , , 0
[1:1:0712/025018.260750:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.261131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.261489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 8, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.262926:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.263588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){return a.appendChild(n.createComment("")),!a.getElementsByTagName("*").length}
[1:1:0712/025018.263992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 9, , , 0
[1:1:0712/025018.265555:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.266062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createComment, 
[1:1:0712/025018.266447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 10, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.267836:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.275572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, test, 
[1:1:0712/025018.276074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 11, , , 0
[1:1:0712/025018.277488:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.277918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, toString, 
[1:1:0712/025018.278377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 12, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.279624:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.280118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.280508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 13, , , 0
[1:1:0712/025018.281854:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.282216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.282669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 14, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.284036:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.284447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){return o.appendChild(a).id=u,!n.getElementsByName||!n.getElementsByName(u).length}
[1:1:0712/025018.284874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 15, , , 0
[1:1:0712/025018.286337:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.286698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, appendChild, 
[1:1:0712/025018.287205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 16, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.288721:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.291050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, test, 
[1:1:0712/025018.291530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 17, , , 0
[1:1:0712/025018.292924:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.293376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, toString, 
[1:1:0712/025018.293932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 18, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.295204:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.295681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.296246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 19, , , 0
[1:1:0712/025018.297674:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.298029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.298582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 20, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.299909:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.300397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){o.appendChild(a).innerHTML="<a id='"+u+"'></a><select id='"+u+"-\r\\' msallowcapture=''><option 
[1:1:0712/025018.300916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 21, , , 0
[1:1:0712/025018.302408:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.302805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, appendChild, 
[1:1:0712/025018.303398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 22, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.304854:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.308375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.308953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 23, , , 0
[1:1:0712/025018.310402:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.310782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.311430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 24, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.312824:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.313314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){a.innerHTML="<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
[1:1:0712/025018.313914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 25, , , 0
[1:1:0712/025018.315368:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.317081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.317778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 26, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.319218:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.322791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, push, 
[1:1:0712/025018.323464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 27, , , 0
[1:1:0712/025018.325099:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.325496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, appendChild, 
[1:1:0712/025018.326217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 28, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.327604:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.335284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, test, 
[1:1:0712/025018.336044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 29, , , 0
[1:1:0712/025018.337438:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.337791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, toString, 
[1:1:0712/025018.338504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 30, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.339757:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.340287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, ja, (a){var b=n.createElement("fieldset");try{return!!a(b)}catch(c){return!1}finally{b.parentNode&&b.par
[1:1:0712/025018.340962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 31, , , 0
[1:1:0712/025018.342321:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.342658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, createElement, 
[1:1:0712/025018.343433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 32, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.344835:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.345305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, , (a){c.disconnectedMatch=s.call(a,"*"),s.call(a,"[s!='']:x"),r.push("!=",N)}
[1:1:0712/025018.346060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 33, , , 0
[1:1:0712/025018.347498:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.347913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, call, 
[1:1:0712/025018.348736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 34, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.350159:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1
	ja (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.351538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, join, (w){
var l=(%_ToObject(this));
var m=(%_ToLength(l.length));
return InnerArrayJoin(w,l,m);
}
[1:1:0712/025018.352331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 35, , , 0
[1:1:0712/025018.353787:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.355968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, toString, 
[1:1:0712/025018.357156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 36, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.358452:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ga.setDocument (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.358837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, exec, 
[1:1:0712/025018.359636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 37, , , 0
[1:1:0712/025018.360908:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.361702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/, 3ce49ced7420, 3ce49cde2860, getElementsByTagName, 
[1:1:0712/025018.362522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.techweb.com.cn", 5, 38, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025018.363684:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.364228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/-5:5_http://www.techweb.com.cn/-5:3_http://www.techweb.com.cn/, 3ce49cde2860, 3ce49ced7420, apply, 
[1:1:0712/025018.365140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 39, , , 0
[1:1:0712/025018.366412:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Function.ga [as find] (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	r.fn.init.find (http://s1.techweb.com.cn/static/newtwhome/js/basejq312.js?201907111222:1:1)
	http://www.techweb.com.cn/it/2019-07-04/2743070.shtml:118:32

[1:1:0712/025018.405782:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f9c6add7070 0x205fe0762d60 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.428424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f9c6add7070 0x205fe0762d60 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.455168:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.244813, 130, 1
[1:1:0712/025018.455443:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025018.632140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025018.632472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025018.697397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 469, 7f9c6d71c8db
[1:1:0712/025018.727153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ce49cde2860","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025018.727500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.techweb.com.cn/","ptid":"375","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025018.727959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 656
[1:1:0712/025018.728195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f9c6add7070 0x205fdf08c360 , 5:3_http://www.techweb.com.cn/, 0, , 469 0x7f9c6add7070 0x205fdef09960 
[1:1:0712/025018.728515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.729299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025018.729522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025018.851132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 585, 7f9c6d71c8db
[1:1:0712/025018.872983:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"470 0x7f9c6add7070 0x205fdf06dae0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025018.873362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"470 0x7f9c6add7070 0x205fdf06dae0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025018.873813:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 658
[1:1:0712/025018.874071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7f9c6add7070 0x205fe05dfd60 , 5:3_http://www.techweb.com.cn/, 0, , 585 0x7f9c6add7070 0x205fdfbd8560 
[1:1:0712/025018.874395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025018.875026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025018.875312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025019.924715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 607, 7f9c6d71c8db
[1:1:0712/025019.950226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"531 0x7f9c6add7070 0x205fdfcba6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025019.950441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"531 0x7f9c6add7070 0x205fdfcba6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025019.950696:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 673
[1:1:0712/025019.950815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f9c6add7070 0x205fe07fba60 , 5:3_http://www.techweb.com.cn/, 0, , 607 0x7f9c6add7070 0x205fe07ae360 
[1:1:0712/025019.950983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025019.951320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025019.951471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025020.929064:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025020.929231:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025020.929807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 651 0x7f9c6add7070 0x205fe069c760 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025020.930444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
  var w = $(".product_item").width();
  var n = 1;
  for(n=1;n<=4;n++){
    if( w < 380 ){ 
      $
[1:1:0712/025020.930584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025020.982615:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0534101, 64, 1
[1:1:0712/025020.982863:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025021.047757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025021.047928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025021.308526:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 656, 7f9c6d71c8db
[1:1:0712/025021.339549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"469 0x7f9c6add7070 0x205fdef09960 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.339896:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"469 0x7f9c6add7070 0x205fdef09960 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.340336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 721
[1:1:0712/025021.340537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f9c6add7070 0x205fe0798e60 , 5:3_http://www.techweb.com.cn/, 0, , 656 0x7f9c6add7070 0x205fdf08c360 
[1:1:0712/025021.340830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025021.341412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025021.341599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025021.343809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 658, 7f9c6d71c8db
[1:1:0712/025021.356506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"585 0x7f9c6add7070 0x205fdfbd8560 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.356665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"585 0x7f9c6add7070 0x205fdfbd8560 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.356924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 722
[1:1:0712/025021.357052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f9c6add7070 0x205fe0814960 , 5:3_http://www.techweb.com.cn/, 0, , 658 0x7f9c6add7070 0x205fe05dfd60 
[1:1:0712/025021.357203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025021.357511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025021.357628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025021.726674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 673, 7f9c6d71c8db
[1:1:0712/025021.740154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"607 0x7f9c6add7070 0x205fe07ae360 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.740456:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"607 0x7f9c6add7070 0x205fe07ae360 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025021.740933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 726
[1:1:0712/025021.741159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f9c6add7070 0x205fe077e660 , 5:3_http://www.techweb.com.cn/, 0, , 673 0x7f9c6add7070 0x205fe07fba60 
[1:1:0712/025021.741443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025021.742069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025021.742280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025022.316668:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025022.316836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025022.317385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 715 0x7f9c6add7070 0x205fdeaa5ce0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025022.317997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
var w = $(".select_img").width();
if( w < 150 ){
$(".imgg2").hide();
$(".imgg1").show();
}else{
$("
[1:1:0712/025022.318145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025022.331800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 715 0x7f9c6add7070 0x205fdeaa5ce0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[60796:60796:0712/025022.403168:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5840223&dri=0&dis=0&dai=0&ps=2037x12&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2037&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925022&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925022&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[60796:60796:0712/025022.410156:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/pcim?psi=a58513900761660fe5fa969c51b6b8f8&di=5840223&dri=0&dis=0&dai=0&ps=2037x12&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2037&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925022&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925022&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/om.js (3)
[1:1:0712/025022.413877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025022.414093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025022.485744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 722, 7f9c6d71c8db
[1:1:0712/025022.525430:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"658 0x7f9c6add7070 0x205fe05dfd60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025022.525717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"658 0x7f9c6add7070 0x205fe05dfd60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025022.526163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 753
[1:1:0712/025022.526364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f9c6add7070 0x205fe08051e0 , 5:3_http://www.techweb.com.cn/, 0, , 722 0x7f9c6add7070 0x205fe0814960 
[1:1:0712/025022.526620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025022.527213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025022.527394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025022.604606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 726, 7f9c6d71c8db
[1:1:0712/025022.638322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"673 0x7f9c6add7070 0x205fe07fba60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025022.638604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"673 0x7f9c6add7070 0x205fe07fba60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025022.639017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 755
[1:1:0712/025022.639242:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f9c6add7070 0x205fe0788060 , 5:3_http://www.techweb.com.cn/, 0, , 726 0x7f9c6add7070 0x205fe077e660 
[1:1:0712/025022.639548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025022.640159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025022.640342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025023.431098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025023.431431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025023.461808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025023.462568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "debd268610f28649","tuid" : "5840223_0","placement" : {"basic" : {"sspId
[1:1:0712/025023.462688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025023.472686:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025023.473918:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025023.476276:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x205fe09f0420
[1:1:0712/025023.476544:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[60796:60796:0712/025023.482475:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/025023.499701:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025023.499904:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.techweb.com.cn
[60796:60796:0712/025023.503091:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.techweb.com.cn/
[1:1:0712/025023.504955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025023.509247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752, "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[60796:60796:0712/025023.545256:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/025023.551441:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/025023.578907:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[60796:60808:0712/025023.579030:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/025023.579254:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[60796:60796:0712/025023.579366:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://widget.weibo.com/, https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn, 6
[60796:60796:0712/025023.579554:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 09:49:11 GMT Content-Type: text/html Content-Length: 900 Vary: Host,Accept-Encoding Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=300, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 09:54:11 GMT Last-Modified: Fri, 12 Jul 2019 09:49:11 GMT DPOOL_HEADER: qubele36 Content-Encoding: gzip LB_HEADER: venus50  ,60894, 5
[1:7:0712/025023.583772:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025023.999166:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.528074, 39, 0
[1:1:0712/025023.999435:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025024.041580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 755, 7f9c6d71c8db
[1:1:0712/025024.076029:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"726 0x7f9c6add7070 0x205fe077e660 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.076352:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"726 0x7f9c6add7070 0x205fe077e660 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.076806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 804
[1:1:0712/025024.077040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f9c6add7070 0x205fe123bc60 , 5:3_http://www.techweb.com.cn/, 0, , 755 0x7f9c6add7070 0x205fe0788060 
[1:1:0712/025024.077370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025024.078055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025024.078279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025024.104360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 721, 7f9c6d71c8db
[1:1:0712/025024.140786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"656 0x7f9c6add7070 0x205fdf08c360 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.141122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"656 0x7f9c6add7070 0x205fdf08c360 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.141570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 808
[1:1:0712/025024.141799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f9c6add7070 0x205fe11df0e0 , 5:3_http://www.techweb.com.cn/, 0, , 721 0x7f9c6add7070 0x205fe0798e60 
[1:1:0712/025024.142111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025024.142741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025024.142989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025024.181869:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 753, 7f9c6d71c8db
[1:1:0712/025024.216359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"722 0x7f9c6add7070 0x205fe0814960 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.216701:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"722 0x7f9c6add7070 0x205fe0814960 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025024.217144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 809
[1:1:0712/025024.218840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f9c6add7070 0x205fe14ee160 , 5:3_http://www.techweb.com.cn/, 0, , 753 0x7f9c6add7070 0x205fe08051e0 
[1:1:0712/025024.219348:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025024.219972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025024.220206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025024.501687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025024.501984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025024.961324:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://widget.weibo.com/
[1:1:0712/025025.175956:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025025.176216:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025025.207090:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0306859, 137, 1
[1:1:0712/025025.207376:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025025.260305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 804, 7f9c6d71c8db
[1:1:0712/025025.297367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"755 0x7f9c6add7070 0x205fe0788060 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025025.297694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"755 0x7f9c6add7070 0x205fe0788060 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025025.298123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 850
[1:1:0712/025025.298365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f9c6add7070 0x205fe10f26e0 , 5:3_http://www.techweb.com.cn/, 0, , 804 0x7f9c6add7070 0x205fe123bc60 
[1:1:0712/025025.298686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025025.299322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025025.299565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025025.347715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 809, 7f9c6d71c8db
[1:1:0712/025025.381188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"753 0x7f9c6add7070 0x205fe08051e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025025.381524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"753 0x7f9c6add7070 0x205fe08051e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025025.381978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 852
[1:1:0712/025025.382211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f9c6add7070 0x205fe153dfe0 , 5:3_http://www.techweb.com.cn/, 0, , 809 0x7f9c6add7070 0x205fe14ee160 
[1:1:0712/025025.382519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025025.383151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025025.383367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025025.853986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025025.854309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[60796:60796:0712/025026.134664:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://widget.weibo.com/, https://widget.weibo.com/, 6
[60796:60796:0712/025026.134774:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0712/025026.138198:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025026.698648:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025026.698905:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025026.700489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 844 0x7f9c6add7070 0x205fe0bc9ee0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025026.701986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/025026.702425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025026.722445:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0234759, 110, 1
[1:1:0712/025026.722769:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025026.797801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 848 0x7f9c6ccff2e0 0x205fe15c0860 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025026.799528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "ce1159bcb003169f","tuid" : "u1768590_0","placement" : {"basic" : {"sspI
[1:1:0712/025026.799773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025026.859435:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025026.861231:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025026.863468:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x205fe09f2220
[1:1:0712/025026.863699:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[60796:60796:0712/025026.869643:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu1768590_0, 7, 7, 
[1:1:0712/025026.885489:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025026.885711:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.techweb.com.cn
[60796:60796:0712/025026.889702:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.techweb.com.cn/
[1:1:0712/025027.012429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 850, 7f9c6d71c8db
[1:1:0712/025027.034382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"804 0x7f9c6add7070 0x205fe123bc60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.034588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"804 0x7f9c6add7070 0x205fe123bc60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.034836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 916
[1:1:0712/025027.034957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f9c6add7070 0x205fe004f6e0 , 5:3_http://www.techweb.com.cn/, 0, , 850 0x7f9c6add7070 0x205fe10f26e0 
[1:1:0712/025027.035118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025027.035459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025027.035571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[60796:60796:0712/025027.037368:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/025027.042267:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/025027.048930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 852, 7f9c6d71c8db
[60796:60808:0712/025027.072468:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[60796:60808:0712/025027.072571:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/025027.072719:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[60796:60796:0712/025027.072799:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://pos.baidu.com/, http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222, 7
[60796:60796:0712/025027.072957:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12250 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 09:50:27 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 17:50:27 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,60894, 5
[1:1:0712/025027.087308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"809 0x7f9c6add7070 0x205fe14ee160 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.087613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"809 0x7f9c6add7070 0x205fe14ee160 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.088050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 920
[1:1:0712/025027.088270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7f9c6add7070 0x205fdfdb3b60 , 5:3_http://www.techweb.com.cn/, 0, , 852 0x7f9c6add7070 0x205fe153dfe0 
[1:1:0712/025027.088545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025027.089173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025027.089421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:7:0712/025027.091993:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025027.236107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025027.236377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025027.341031:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025027.582732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 808, 7f9c6d71c8db
[1:1:0712/025027.622222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"721 0x7f9c6add7070 0x205fe0798e60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.622590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"721 0x7f9c6add7070 0x205fe0798e60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025027.623071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 931
[1:1:0712/025027.623314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7f9c6add7070 0x205fdfbfbce0 , 5:3_http://www.techweb.com.cn/, 0, , 808 0x7f9c6add7070 0x205fe11df0e0 
[1:1:0712/025027.624827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025027.625497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025027.625730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025028.378454:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025028.378744:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025028.382048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 895 0x7f9c6add7070 0x205fe156b2e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025028.383400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/025028.383684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025028.400371:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.021456, 54, 1
[1:1:0712/025028.400641:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025029.162990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 916, 7f9c6d71c8db
[1:1:0712/025029.206867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"850 0x7f9c6add7070 0x205fe10f26e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025029.207202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"850 0x7f9c6add7070 0x205fe10f26e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025029.207694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 974
[1:1:0712/025029.207968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f9c6add7070 0x205fe07ae3e0 , 5:3_http://www.techweb.com.cn/, 0, , 916 0x7f9c6add7070 0x205fe004f6e0 
[1:1:0712/025029.208305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025029.208974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025029.209246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025029.436657:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://pos.baidu.com/
[1:1:0712/025029.553864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025029.554152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025029.648649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 920, 7f9c6d71c8db
[1:1:0712/025029.690090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"852 0x7f9c6add7070 0x205fe153dfe0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025029.690425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"852 0x7f9c6add7070 0x205fe153dfe0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025029.690926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 982
[1:1:0712/025029.691155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7f9c6add7070 0x205fe14f47e0 , 5:3_http://www.techweb.com.cn/, 0, , 920 0x7f9c6add7070 0x205fdfdb3b60 
[1:1:0712/025029.691447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025029.692075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025029.692300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025029.984518:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025029.984772:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[60796:60796:0712/025030.574160:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025031.049321:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025031.049575:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.050618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 958 0x7f9c6add7070 0x205fe0ae2fe0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.052195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
(function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="'
[1:1:0712/025031.052471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025031.152632:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.102886, 118, 1
[1:1:0712/025031.152889:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025031.295351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 961 0x7f9c6ccff2e0 0x205fe1662ce0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.296825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , window.__baidu_dup_jobruner = {};
try {
    var storage = window.localStorage;
    if (storage &&
[1:1:0712/025031.297051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025031.298674:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.299833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.343725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 962 0x7f9c6ccff2e0 0x205fde6afc60 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025031.350105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , try{!function(t){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_ds_||(win
[1:1:0712/025031.350350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025032.088930:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025032.091091:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025032.093610:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x205fe0a48420
[1:1:0712/025032.096073:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[60796:60796:0712/025032.097843:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[1:1:0712/025032.108463:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025032.108730:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.techweb.com.cn
[60796:60796:0712/025032.116672:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.techweb.com.cn/
[60796:60796:0712/025032.224069:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/025032.230314:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/025032.258326:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[60796:60808:0712/025032.258433:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/025032.258599:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[60796:60796:0712/025032.258677:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://pos.baidu.com/, http://pos.baidu.com/s?hei=200&wid=640&di=u3440745&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&psi=a58513900761660fe5fa969c51b6b8f8&par=1211x623&tcn=1562925032&cec=UTF-8&dtm=HTML_POST&dri=0&drs=1&cja=false&pcs=1025x471&dai=6&tlm=1562925032&cfv=0&ant=0&dc=3&tpr=1562925031903&ps=3348x12&dis=0&chi=2&cdo=-1&pss=1025x4407&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&exps=111000,115008,110011&col=en-US&ari=2&ccd=24&cpl=2&cmi=2&psr=1276x647&pis=-1x-1&cce=true, 8
[60796:60796:0712/025032.258832:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7499 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 09:50:32 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 17:50:32 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,60894, 5
[1:7:0712/025032.263713:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025032.345231:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025032.347285:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025032.349459:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x205fe0973220
[1:1:0712/025032.351731:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[60796:60796:0712/025032.354167:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0712/025032.373828:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025032.374077:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.techweb.com.cn
[60796:60796:0712/025032.377137:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.techweb.com.cn/
[60796:60796:0712/025032.545551:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/025032.550545:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/025032.577973:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[60796:60808:0712/025032.578077:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/025032.578229:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[60796:60796:0712/025032.578319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://pos.baidu.com/, http://pos.baidu.com/s?hei=200&wid=640&di=u3441443&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&psi=a58513900761660fe5fa969c51b6b8f8&ant=0&exps=111000,110011&dai=7&tcn=1562925032&dc=3&cdo=-1&psr=1276x647&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&par=1211x623&cce=true&drs=1&ari=2&cmi=2&col=en-US&cec=UTF-8&dri=0&cpl=2&cja=false&dis=0&ccd=24&tlm=1562925032&dtm=HTML_POST&tpr=1562925031903&chi=2&cfv=0&pss=1025x4611&pis=-1x-1&pcs=1025x471&ps=4207x12, 9
[60796:60796:0712/025032.578476:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 7550 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 09:50:32 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 17:50:32 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,60894, 5
[1:7:0712/025032.580919:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025032.697168:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 974, 7f9c6d71c8db
[1:1:0712/025032.735460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"916 0x7f9c6add7070 0x205fe004f6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025032.735854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"916 0x7f9c6add7070 0x205fe004f6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025032.736327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1060
[1:1:0712/025032.736567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f9c6add7070 0x205fe1213ee0 , 5:3_http://www.techweb.com.cn/, 0, , 974 0x7f9c6add7070 0x205fe07ae3e0 
[1:1:0712/025032.736953:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025032.737569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025032.737852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025032.841807:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[60796:60796:0712/025032.846677:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://pos.baidu.com/, http://pos.baidu.com/, 7
[60796:60796:0712/025032.846760:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/025032.950217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025032.950508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025033.004035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 931, 7f9c6d71c8db
[1:1:0712/025033.035379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"808 0x7f9c6add7070 0x205fe11df0e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025033.035742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"808 0x7f9c6add7070 0x205fe11df0e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025033.036180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1077
[1:1:0712/025033.036409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f9c6add7070 0x205fe1cef0e0 , 5:3_http://www.techweb.com.cn/, 0, , 931 0x7f9c6add7070 0x205fdfbfbce0 
[1:1:0712/025033.036811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025033.037425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025033.037637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025033.039800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 982, 7f9c6d71c8db
[1:1:0712/025033.067379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"920 0x7f9c6add7070 0x205fdfdb3b60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025033.067729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"920 0x7f9c6add7070 0x205fdfdb3b60 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025033.068154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1078
[1:1:0712/025033.068383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7f9c6add7070 0x205fe17ef4e0 , 5:3_http://www.techweb.com.cn/, 0, , 982 0x7f9c6add7070 0x205fe14f47e0 
[1:1:0712/025033.068758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025033.069372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025033.069586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025034.348402:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025034.348649:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025034.349682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1017 0x7f9c6add7070 0x205fe0afd760 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025034.350945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
var cpro_id="u1782028";
(window["cproStyleApi"] = window["cproStyleApi"] || {})[cpro_id]={at:"3",rs
[1:1:0712/025034.351253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025034.356597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1017 0x7f9c6add7070 0x205fe0afd760 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025035.071333:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.722585, 0, 0
[1:1:0712/025035.071688:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025035.892594:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_http://pos.baidu.com/
[1:1:0712/025036.592867:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_http://pos.baidu.com/
[1:1:0712/025036.875687:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025037.172789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1060, 7f9c6d71c8db
[1:1:0712/025037.221914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"974 0x7f9c6add7070 0x205fe07ae3e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.222198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"974 0x7f9c6add7070 0x205fe07ae3e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.222610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1162
[1:1:0712/025037.222825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1162 0x7f9c6add7070 0x205fe1a82de0 , 5:3_http://www.techweb.com.cn/, 0, , 1060 0x7f9c6add7070 0x205fe1213ee0 
[1:1:0712/025037.223173:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025037.223811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025037.223993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025037.387979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025037.388220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025037.392175:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1077, 7f9c6d71c8db
[1:1:0712/025037.429553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"931 0x7f9c6add7070 0x205fdfbfbce0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.429862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"931 0x7f9c6add7070 0x205fdfbfbce0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.430287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1167
[1:1:0712/025037.430495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f9c6add7070 0x205fe22ad5e0 , 5:3_http://www.techweb.com.cn/, 0, , 1077 0x7f9c6add7070 0x205fe1cef0e0 
[1:1:0712/025037.430839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025037.431419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025037.431595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025037.434470:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1078, 7f9c6d71c8db
[1:1:0712/025037.454037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"982 0x7f9c6add7070 0x205fe14f47e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.454233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"982 0x7f9c6add7070 0x205fe14f47e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025037.454497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1168
[1:1:0712/025037.454614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7f9c6add7070 0x205fe22bc6e0 , 5:3_http://www.techweb.com.cn/, 0, , 1078 0x7f9c6add7070 0x205fe17ef4e0 
[1:1:0712/025037.454829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025037.455154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025037.455273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025037.662926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1087 0x7f9c6add7070 0x205fe17fade0 , "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025037.674446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://widget.weibo.com/, 3ce49ceb11c8, , , 

var scope = {};
scope.uid = '1642471052';
scope.btn = 'red';
scope.write = '0';
scope.refer = 'ai.
[1:1:0712/025037.674655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", "widget.weibo.com", 6, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025037.677646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1087 0x7f9c6add7070 0x205fe17fade0 , "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025037.695957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", 10000
[1:1:0712/025037.696345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:6_https://widget.weibo.com/, 1172
[1:1:0712/025037.696467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7f9c6add7070 0x205fe0f1a5e0 , 5:6_https://widget.weibo.com/, 1, -5:6_https://widget.weibo.com/, 1087 0x7f9c6add7070 0x205fe17fade0 
[1:1:0712/025037.766831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1089, "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025037.770669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://widget.weibo.com/, 3ce49ceb11c8, , , !function($win,$doc){var STK=(function(){var that={};var errorList=[];that.inc=function(ns,undepende
[1:1:0712/025037.771041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", "widget.weibo.com", 6, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025037.836825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1089, "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025037.988509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1093, "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025037.991610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://widget.weibo.com/, 3ce49ceb11c8, , , (function(){var ac=window,A=document,r=navigator,Q=r.userAgent,ah=ac.screen,j;try{j=ac.location.href
[1:1:0712/025037.991870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", "widget.weibo.com", 6, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025039.396943:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025039.397221:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025039.427801:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0304089, 136, 1
[1:1:0712/025039.428083:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025039.669876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1132 0x7f9c6ccff2e0 0x205fe17e3960 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025039.671257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "579cc37012ebe661","tuid" : "5345229_0","placement" : {"basic" : {"sspId
[1:1:0712/025039.671498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025040.045542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1133 0x7f9c6ccff2e0 0x205fe1d2dee0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025040.047314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , ___adblockplus({"queryid" : "060dfb7216f40585","tuid" : "u1782028_0","placement" : {"basic" : {"sspI
[1:1:0712/025040.047572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025040.109285:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[60796:60796:0712/025040.111656:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/025040.113886:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x205fe0a02a20
[1:1:0712/025040.114114:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[60796:60796:0712/025040.119496:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu1782028_0, 10, 10, 
[1:1:0712/025040.133109:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/025040.133366:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.techweb.com.cn
[60796:60796:0712/025040.135283:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.techweb.com.cn/
[60796:60796:0712/025040.240570:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[60796:60796:0712/025040.245469:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[60796:60808:0712/025040.265450:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[60796:60796:0712/025040.265490:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[60796:60796:0712/025040.265578:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://pos.baidu.com/, http://pos.baidu.com/pcim?conwid=300&conhei=300&rdid=1782028&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1782028&dri=0&dis=0&dai=8&ps=888x712&coa=at%3D3%26rsi0%3D300%26rsi1%3D300%26pat%3D17%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x4815&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925035&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925035&qn=060dfb7216f40585&tt=1562924995619.39414.44434.44464, 10
[60796:60808:0712/025040.265573:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[60796:60796:0712/025040.265663:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 18104 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 09:50:40 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 17:50:40 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,60894, 5
[1:7:0712/025040.273934:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/025040.400468:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[60796:60796:0712/025040.405740:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://pos.baidu.com/, http://pos.baidu.com/, 8
[60796:60796:0712/025040.405860:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/025040.740033:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[60796:60796:0712/025040.746962:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://pos.baidu.com/, http://pos.baidu.com/, 9
[60796:60796:0712/025040.747015:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/025041.052585:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025041.052878:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025041.126556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1162, 7f9c6d71c8db
[1:1:0712/025041.146279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1060 0x7f9c6add7070 0x205fe1213ee0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025041.146474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1060 0x7f9c6add7070 0x205fe1213ee0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025041.146688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1329
[1:1:0712/025041.146939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f9c6add7070 0x205fe26279e0 , 5:3_http://www.techweb.com.cn/, 0, , 1162 0x7f9c6add7070 0x205fe1a82de0 
[1:1:0712/025041.147366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025041.148137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025041.148291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025041.210636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025041.210915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025041.887981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1168, 7f9c6d71c8db
[1:1:0712/025041.939744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1078 0x7f9c6add7070 0x205fe17ef4e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025041.939969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1078 0x7f9c6add7070 0x205fe17ef4e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025041.940251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1342
[1:1:0712/025041.940373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1342 0x7f9c6add7070 0x205fe2457260 , 5:3_http://www.techweb.com.cn/, 0, , 1168 0x7f9c6add7070 0x205fe22bc6e0 
[1:1:0712/025041.940568:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025041.940890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025041.941030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025044.699489:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025044.699704:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025044.700319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1255 0x7f9c6add7070 0x205fe233c7e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025044.700980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , 
	var w = $(".picture").width();
	for(n=0;n<=10;n++){
		if( w < 150 ){ 
			$("#y"+n+"1").hide();
			
[1:1:0712/025044.701116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025044.759344:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0596101, 52, 1
[1:1:0712/025044.759530:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025045.324793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1167, 7f9c6d71c8db
[1:1:0712/025045.376187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1077 0x7f9c6add7070 0x205fe1cef0e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025045.376470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1077 0x7f9c6add7070 0x205fe1cef0e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025045.376889:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1409
[1:1:0712/025045.377103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1409 0x7f9c6add7070 0x205fe271c960 , 5:3_http://www.techweb.com.cn/, 0, , 1167 0x7f9c6add7070 0x205fe22ad5e0 
[1:1:0712/025045.377429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025045.378029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025045.378224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025045.682233:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:10_http://pos.baidu.com/
[1:1:0712/025045.843609:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025046.537223:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025047.789857:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025047.794177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://pos.baidu.com/, 3ce49ce83df0, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0712/025047.794461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222", "pos.baidu.com", 7, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025047.814167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025047.826224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025047.838279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025047.854028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025047.892797:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025047.893187:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025047.893382:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025047.893765:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025047.893972:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/025048.088971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025048.091774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025048.101858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1327, "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025048.759085:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.959483, 10, 0
[1:1:0712/025048.759355:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025048.829809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1329, 7f9c6d71c8db
[1:1:0712/025048.893958:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1162 0x7f9c6add7070 0x205fe1a82de0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025048.894311:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1162 0x7f9c6add7070 0x205fe1a82de0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025048.894740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1519
[1:1:0712/025048.895013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1519 0x7f9c6add7070 0x205fde9c3ee0 , 5:3_http://www.techweb.com.cn/, 0, , 1329 0x7f9c6add7070 0x205fe26279e0 
[1:1:0712/025048.895411:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025048.896262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025048.896504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025049.030114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , document.readyState
[1:1:0712/025049.030434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025049.212277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1342, 7f9c6d71c8db
[1:1:0712/025049.277051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1168 0x7f9c6add7070 0x205fe22bc6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025049.277383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1168 0x7f9c6add7070 0x205fe22bc6e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025049.277817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1528
[1:1:0712/025049.278052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1528 0x7f9c6add7070 0x205fde9c13e0 , 5:3_http://www.techweb.com.cn/, 0, , 1342 0x7f9c6add7070 0x205fe2457260 
[1:1:0712/025049.278433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025049.279079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025049.279309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/025050.799750:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025050.800016:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025050.806683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1401 0x7f9c6add7070 0x205fe26489e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025050.814093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , /*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig
 * Du
[1:1:0712/025050.814375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025050.837914:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1401 0x7f9c6add7070 0x205fe26489e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025050.962068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1401 0x7f9c6add7070 0x205fe26489e0 , "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025050.991668:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.191522, 61, 1
[1:1:0712/025050.991992:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/025051.462418:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[60796:60796:0712/025051.466550:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://pos.baidu.com/, http://pos.baidu.com/, 10
[60796:60796:0712/025051.466630:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/025051.783124:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025051.783418:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=200&wid=640&di=u3440745&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&psi=a58513900761660fe5fa969c51b6b8f8&par=1211x623&tcn=1562925032&cec=UTF-8&dtm=HTML_POST&dri=0&drs=1&cja=false&pcs=1025x471&dai=6&tlm=1562925032&cfv=0&ant=0&dc=3&tpr=1562925031903&ps=3348x12&dis=0&chi=2&cdo=-1&pss=1025x4407&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&exps=111000,115008,110011&col=en-US&ari=2&ccd=24&cpl=2&cmi=2&psr=1276x647&pis=-1x-1&cce=true"
[1:1:0712/025051.974897:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025051.975166:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=200&wid=640&di=u3441443&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&psi=a58513900761660fe5fa969c51b6b8f8&ant=0&exps=111000,110011&dai=7&tcn=1562925032&dc=3&cdo=-1&psr=1276x647&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&par=1211x623&cce=true&drs=1&ari=2&cmi=2&col=en-US&cec=UTF-8&dri=0&cpl=2&cja=false&dis=0&ccd=24&tlm=1562925032&dtm=HTML_POST&tpr=1562925031903&chi=2&cfv=0&pss=1025x4611&pis=-1x-1&pcs=1025x471&ps=4207x12"
[1:1:0712/025052.279622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1409, 7f9c6d71c8db
[1:1:0712/025052.349855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1167 0x7f9c6add7070 0x205fe22ad5e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025052.350192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1167 0x7f9c6add7070 0x205fe22ad5e0 ","rf":"5:3_http://www.techweb.com.cn/"}
[1:1:0712/025052.350634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.techweb.com.cn/, 1616
[1:1:0712/025052.350890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1616 0x7f9c6add7070 0x205fe2fecc60 , 5:3_http://www.techweb.com.cn/, 0, , 1409 0x7f9c6add7070 0x205fe271c960 
[1:1:0712/025052.351257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025052.351946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , () {
            e = e + 1 >= d ? e + 1 - d : e + 1;
            g()
        }
[1:1:0712/025052.352165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025052.828106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:6_https://widget.weibo.com/, 1172, 7f9c6d71c881
[1:1:0712/025052.875658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ce49ceb11c8","ptid":"1087 0x7f9c6add7070 0x205fe17fade0 ","rf":"5:6_https://widget.weibo.com/"}
[1:1:0712/025052.876044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:6_https://widget.weibo.com/","ptid":"1087 0x7f9c6add7070 0x205fe17fade0 ","rf":"5:6_https://widget.weibo.com/"}
[1:1:0712/025052.876460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn"
[1:1:0712/025052.877613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://widget.weibo.com/, 3ce49ceb11c8, , , sinaSSOController.updateCookie()
[1:1:0712/025052.877906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", "widget.weibo.com", 6, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025052.879581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/relationship/followbutton.php?btn=red&style=1&uid=1642471052&width=67&height=24&language=zh_cn", 1800000
[1:1:0712/025052.880269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:6_https://widget.weibo.com/, 1632
[1:1:0712/025052.880500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1632 0x7f9c6add7070 0x205fe26ca060 , 5:6_https://widget.weibo.com/, 1, -5:6_https://widget.weibo.com/, 1172 0x7f9c6add7070 0x205fe0f1a5e0 
[1:1:0712/025054.093581:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[1:1:0712/025054.095304:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://www.techweb.com.cn/, 5:7_http://pos.baidu.com/
[1:1:0712/025054.095578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.techweb.com.cn/, 3ce49cde2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/025054.095826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml", "www.techweb.com.cn", 3, 1, , , 0
[1:1:0712/025054.106146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://www.techweb.com.cn/it/2019-07-04/2743070.shtml"
[60796:60796:0712/025054.434116:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/025055.873185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/025055.873484:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025055.877483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1509 0x7f9c6add7070 0x205fe27e58e0 , "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
[1:1:0712/025055.881661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_http://pos.baidu.com/, 3ce49ce83df0, , , 
    function addFliterForImg(){var a=config.saturate;var e=config.contrast;var f=document.querySele
[1:1:0712/025055.881956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222", "pos.baidu.com", 7, 1, http://www.techweb.com.cn, www.techweb.com.cn, 3
[1:1:0712/025055.887234:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1509 0x7f9c6add7070 0x205fe27e58e0 , "http://pos.baidu.com/pcim?conwid=640&conhei=125&rdid=1768590&dc=3&exps=110011&psi=a58513900761660fe5fa969c51b6b8f8&di=u1768590&dri=0&dis=0&dai=4&ps=2235x12&coa=at%3D3%26rsi0%3D640%26rsi1%3D125%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D70%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562924997133&ti=%E5%BC%A0%E6%9C%9D%E9%98%B3%E5%86%8D%E8%B0%885G%E5%8D%B1%E5%AE%B3%20%E5%85%B3%E4%BA%8E5G%E5%8D%B1%E5%AE%B3%E5%BC%A0%E6%9C%9D%E9%98%B3%E8%AF%B4%E4%BA%86%E4%BB%80%E4%B9%88_TechWeb&ari=2&dbv=2&drs=1&pcs=1025x471&pss=1025x2235&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562925023&rw=471&ltu=http%3A%2F%2Fwww.techweb.com.cn%2Fit%2F2019-07-04%2F2743070.shtml&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562925024&qn=ce1159bcb003169f&tt=1562924995619.28368.31188.31222"
