[0713/032019.695526:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032019.695800:INFO:switcher_clone.cc(787)] backtrace rip is 7f1ed95fc891
[0713/032020.701944:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032020.702276:INFO:switcher_clone.cc(787)] backtrace rip is 7f8576c98891
[1:1:0713/032020.724690:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/032020.725113:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/032020.734377:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/032022.240294:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/032022.240552:INFO:switcher_clone.cc(787)] backtrace rip is 7fd1965bd891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[46691:46691:0713/032022.480308:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46691
[46701:46701:0713/032022.480675:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46701
[46659:46659:0713/032022.532794:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f16c5097-64c6-40d1-be58-46b00e0a57e6
[46659:46659:0713/032023.153098:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[46659:46689:0713/032023.153841:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/032023.154071:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/032023.154293:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/032023.154648:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/032023.154746:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/032023.156830:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd865dcd, 1
[1:1:0713/032023.157081:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1fb72691, 0
[1:1:0713/032023.157173:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3fcbf674, 3
[1:1:0713/032023.157339:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x239f12ea, 2
[1:1:0713/032023.157446:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9126ffffffb71f ffffffcd5dffffff860d ffffffea12ffffff9f23 74fffffff6ffffffcb3f , 10104, 4
[1:1:0713/032023.158052:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46659:46689:0713/032023.158203:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�&��]���#t��?܆�9
[1:1:0713/032023.158180:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8574ed30a0, 3
[46659:46689:0713/032023.158280:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �&��]���#t��?8�܆�9
[1:1:0713/032023.158297:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f857505e080, 2
[1:1:0713/032023.158378:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f855ed21d20, -2
[46659:46689:0713/032023.158538:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[46659:46689:0713/032023.158608:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46711, 4, 9126b71f cd5d860d ea129f23 74f6cb3f 
[1:1:0713/032023.166462:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/032023.167281:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 239f12ea
[1:1:0713/032023.168183:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 239f12ea
[1:1:0713/032023.169711:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 239f12ea
[1:1:0713/032023.171142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.171344:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.171518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.171700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.172342:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 239f12ea
[1:1:0713/032023.172658:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8576c987ba
[1:1:0713/032023.172790:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8576c8fdef, 7f8576c9877a, 7f8576c9a0cf
[1:1:0713/032023.178197:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 239f12ea
[1:1:0713/032023.178550:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 239f12ea
[1:1:0713/032023.179302:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 239f12ea
[1:1:0713/032023.181644:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.181916:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.182133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.182344:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 239f12ea
[1:1:0713/032023.183588:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 239f12ea
[1:1:0713/032023.183943:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8576c987ba
[1:1:0713/032023.184076:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8576c8fdef, 7f8576c9877a, 7f8576c9a0cf
[1:1:0713/032023.191835:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/032023.192264:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/032023.192410:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdcb5a8758, 0x7ffdcb5a86d8)
[1:1:0713/032023.208447:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/032023.214305:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[46659:46659:0713/032023.837801:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46659:46659:0713/032023.839170:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46659:46670:0713/032023.860059:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[46659:46670:0713/032023.860181:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[46659:46659:0713/032023.860279:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[46659:46659:0713/032023.860362:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[46659:46659:0713/032023.860544:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,46711, 4
[1:7:0713/032023.875280:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[46659:46683:0713/032023.931578:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/032024.031100:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1b0609fe5220
[1:1:0713/032024.031402:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/032024.407520:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[46659:46659:0713/032026.202069:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[46659:46659:0713/032026.202220:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/032026.251749:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032026.254887:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/032027.336615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/032027.336929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032027.366441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/032027.366668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032027.445243:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032027.622116:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032027.622361:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032028.090623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032028.098648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/032028.098958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032028.133521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032028.143860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/032028.144128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032028.155698:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[46659:46659:0713/032028.159535:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032028.160894:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b0609fe3e20
[1:1:0713/032028.161239:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[46659:46659:0713/032028.171946:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[46659:46659:0713/032028.232111:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[46659:46659:0713/032028.232267:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/032028.271710:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032029.204768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f85608fc2e0 0x1b060a201060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032029.206231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/032029.206507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032029.208086:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[46659:46659:0713/032029.286144:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/032029.286957:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1b0609fe4820
[1:1:0713/032029.287619:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0713/032029.298151:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/032029.298370:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[46659:46659:0713/032029.302963:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[46659:46659:0713/032029.326329:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[46659:46659:0713/032029.351848:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46659:46659:0713/032029.355831:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46659:46670:0713/032029.363485:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[46659:46670:0713/032029.363571:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[46659:46659:0713/032029.363850:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[46659:46659:0713/032029.363964:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[46659:46659:0713/032029.364136:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,46711, 4
[1:7:0713/032029.367219:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032029.898331:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[46659:46659:0713/032029.945545:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[46659:46689:0713/032029.945942:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/032029.946119:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/032029.946362:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/032029.946769:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/032029.946919:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/032029.950060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ca9de0b, 1
[1:1:0713/032029.950425:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x257a0d24, 0
[1:1:0713/032029.950619:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x143dcca9, 3
[1:1:0713/032029.950920:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x13c67ced, 2
[1:1:0713/032029.951105:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 240d7a25 0bffffffdeffffffa91c ffffffed7cffffffc613 ffffffa9ffffffcc3d14 , 10104, 5
[1:1:0713/032029.952136:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46659:46689:0713/032029.952415:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING$z%ީ�|���=Ή�9
[46659:46689:0713/032029.952486:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is $z%ީ�|���=�GΉ�9
[1:1:0713/032029.952404:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8574ed30a0, 3
[1:1:0713/032029.952646:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f857505e080, 2
[46659:46689:0713/032029.952782:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46755, 5, 240d7a25 0bdea91c ed7cc613 a9cc3d14 
[1:1:0713/032029.952890:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f855ed21d20, -2
[1:1:0713/032029.974959:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/032029.975372:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13c67ced
[1:1:0713/032029.975722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13c67ced
[1:1:0713/032029.976178:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13c67ced
[1:1:0713/032029.977645:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.977869:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.978107:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.978330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.979008:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13c67ced
[1:1:0713/032029.979343:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8576c987ba
[1:1:0713/032029.979516:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8576c8fdef, 7f8576c9877a, 7f8576c9a0cf
[1:1:0713/032029.985253:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13c67ced
[1:1:0713/032029.985639:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13c67ced
[1:1:0713/032029.986409:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13c67ced
[1:1:0713/032029.988450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.988700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.988958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.989213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13c67ced
[1:1:0713/032029.990477:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13c67ced
[1:1:0713/032029.990880:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8576c987ba
[1:1:0713/032029.991074:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8576c8fdef, 7f8576c9877a, 7f8576c9a0cf
[1:1:0713/032029.998811:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/032029.999343:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/032029.999544:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdcb5a8758, 0x7ffdcb5a86d8)
[1:1:0713/032030.013792:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/032030.018030:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/032030.197952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 493 0x7f85608fc2e0 0x1b060a277d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032030.198912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0974f5b81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/032030.199170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/032030.199895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/032030.227383:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b0609fa7220
[1:1:0713/032030.227647:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[46659:46659:0713/032030.282853:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[46659:46659:0713/032030.282957:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/032030.313723:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[46659:46659:0713/032030.617967:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46659:46659:0713/032030.623585:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46659:46670:0713/032030.676475:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[46659:46670:0713/032030.676577:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[46659:46659:0713/032030.677033:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.stdaily.com/
[46659:46659:0713/032030.677135:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.stdaily.com/, http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml, 1
[46659:46659:0713/032030.677320:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.stdaily.com/, HTTP/1.1 200 OK DrivedBy: SrvEng/1.5.0 Date: Sat, 13 Jul 2019 10:19:52 GMT Content-Type: text/html; charset=UTF-8 Content-Length: 14958 Connection: keep-alive X-Frame-Options: allow-from http://www.kjcg123.com/, allow-from http://yun.kjcg123.com:8080/ Set-Cookie: gkyh_cookie=10.10.0.14.1563013230609614; path=/; max-age=31536000; domain=.stdaily.com Accept-Ranges: bytes Vary: Accept-Encoding,User-Agent Content-Encoding: gzip  ,46755, 5
[1:7:0713/032030.680605:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/032030.698404:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.stdaily.com/
[1:1:0713/032030.731092:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[46659:46659:0713/032030.854671:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.stdaily.com/, http://www.stdaily.com/, 1
[46659:46659:0713/032030.854791:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.stdaily.com/, http://www.stdaily.com
[1:1:0713/032030.900146:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/032031.021998:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032031.131220:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032031.131478:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032031.430709:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032031.430976:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032031.919667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7f855e9d4070 0x1b060a195060 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032031.921933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.write("<link rel='stylesheet' type='text/css' href='/index/xhtml/css/f_header.css?time=" + 
[1:1:0713/032031.922175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032032.155203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.202450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , /*!jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL=jquery.min.map
*/
(function(
[1:1:0713/032032.202744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032032.205042:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.464507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.587949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.593810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.602560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.620685:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.621130:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.621498:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.621902:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.622244:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032032.702985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f855e9d4070 0x1b060a193fe0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032032.766268:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.303453, 282, 1
[1:1:0713/032032.766513:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032033.138088:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032033.522352:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032033.523476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f855e9d4070 0x1b060a189a60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032033.524743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , 

var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm
[1:1:0713/032033.524981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032033.545366:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.022754, 63, 1
[1:1:0713/032033.545603:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032033.673508:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032033.673729:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032033.750727:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0767629, 773, 1
[1:1:0713/032033.750974:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/032033.812845:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 257 0x7f85608fc2e0 0x1b060a1668e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032033.821223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0713/032033.821463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032034.046503:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/032034.046790:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032034.050492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7f855e9d4070 0x1b060a115be0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032034.057129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , !function(e,n){"function"==typeof define&&(define.amd||define.cmd)?define(function(){return n(e)}):n
[1:1:0713/032034.057358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032034.082205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032034.085534:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7f855e9d4070 0x1b060a115be0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032034.192809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 278 0x7f855e9d4070 0x1b060a115be0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032034.202391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032035.482949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1000
[1:1:0713/032035.483562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 324
[1:1:0713/032035.483797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 324 0x7f855e9d4070 0x1b060a4b21e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.561882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/032035.562447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 325
[1:1:0713/032035.562678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 325 0x7f855e9d4070 0x1b060a4b2360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.579789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032035.606260:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e309e0
[1:1:0713/032035.606519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032035.607018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 326
[1:1:0713/032035.607243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f855e9d4070 0x1b060a4cf760 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.619540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e309e0
[1:1:0713/032035.619776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032035.620258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 328
[1:1:0713/032035.620510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 328 0x7f855e9d4070 0x1b060a4ad9e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.632372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e309e0
[1:1:0713/032035.632631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032035.633127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 331
[1:1:0713/032035.633363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7f855e9d4070 0x1b060a4a7be0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.644091:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e309e0
[1:1:0713/032035.644357:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032035.644878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 333
[1:1:0713/032035.645125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7f855e9d4070 0x1b060a4b2160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.649902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x16c763dc29c8, 0x1b0609e309e0
[1:1:0713/032035.650112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 3000
[1:1:0713/032035.650714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 335
[1:1:0713/032035.651243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 335 0x7f855e9d4070 0x1b060a17dae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 278 0x7f855e9d4070 0x1b060a115be0 
[1:1:0713/032035.756779:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032035.757647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/032035.757934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032035.816270:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032036.560870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032036.561689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/032036.561927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032036.595120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354 0x7f85608fc2e0 0x1b060a4cf8e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032036.604581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (function(){var h={},mt={},c={id:"d11e62e2e2c8d774bb326bab95dd0a4d",dm:["114.55.19.24","stdaily.com"
[1:1:0713/032036.604855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032036.636301:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30948
[1:1:0713/032036.636557:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032036.637116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 395
[1:1:0713/032036.637369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f855e9d4070 0x1b060a4ada60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 354 0x7f85608fc2e0 0x1b060a4cf8e0 
[46659:46659:0713/032111.895013:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/032111.907631:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/032112.015503:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032112.079767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.114247:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7f85608fc2e0 0x1b0609d1f4e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.114975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/032112.115123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.117457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.207600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f85608fc2e0 0x1b060a0cf0e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.212514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (function(){var h={},mt={},c={id:"d11e62e2e2c8d774bb326bab95dd0a4d",dm:["114.55.19.24","stdaily.com"
[1:1:0713/032112.212664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.226504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30940
[1:1:0713/032112.226719:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032112.227012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 460
[1:1:0713/032112.227179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 460 0x7f855e9d4070 0x1b060a49efe0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 358 0x7f85608fc2e0 0x1b060a0cf0e0 
[1:1:0713/032112.237842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.253154:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359 0x7f85608fc2e0 0x1b060a49df60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.253939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/032112.254131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.273322:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30988
[1:1:0713/032112.273510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032112.273721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 463
[1:1:0713/032112.273830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7f855e9d4070 0x1b060a0d69e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 359 0x7f85608fc2e0 0x1b060a49df60 
[1:1:0713/032112.299187:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30988
[1:1:0713/032112.299445:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032112.299924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 465
[1:1:0713/032112.300134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f855e9d4070 0x1b060a4ad560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 359 0x7f85608fc2e0 0x1b060a49df60 
[1:1:0713/032112.304042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.304555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.347057:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7f85608fc2e0 0x1b060a4ca0e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.347637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/032112.347746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.382435:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30988
[1:1:0713/032112.382727:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032112.383342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 471
[1:1:0713/032112.383589:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f855e9d4070 0x1b060a188260 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 362 0x7f85608fc2e0 0x1b060a4ca0e0 
[1:1:0713/032112.390112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.391105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.420561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363 0x7f85608fc2e0 0x1b060a189860 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.422337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("share/image_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/032112.422562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.451629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.452487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.521994:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.522741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){t&&(delete yn[o],t=s.onload=s.onerror=null,"abort"===e?s.abort():"error"===e?r(s.status||404,s.st
[1:1:0713/032112.522859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.679725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377 0x7f85608fc2e0 0x1b060a4b3260 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.680969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("view/image_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0713/032112.681195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032112.703069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.703700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.842864:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 324, 7f8561319881
[1:1:0713/032112.860717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032112.861020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032112.861398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032112.862400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , $('.ccH5playerBox').width('100%').height('auto')
[1:1:0713/032112.862579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032113.008833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/032113.009130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032113.889243:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 395, 7f8561319881
[1:1:0713/032113.907623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"354 0x7f85608fc2e0 0x1b060a4cf8e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.907848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"354 0x7f85608fc2e0 0x1b060a4cf8e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.908094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032113.908435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032113.908578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032113.908962:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032113.909070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032113.909270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 498
[1:1:0713/032113.909376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7f855e9d4070 0x1b060ac53760 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 395 0x7f855e9d4070 0x1b060a4ada60 
[1:1:0713/032113.909924:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 335, 7f8561319881
[1:1:0713/032113.916930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.917109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.917341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032113.917746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0713/032113.917854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032113.921625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032113.921845:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032113.922403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 499
[1:1:0713/032113.922664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7f855e9d4070 0x1b060a49dd60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 335 0x7f855e9d4070 0x1b060a17dae0 
[1:1:0713/032113.946684:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 325, 7f85613198db
[1:1:0713/032113.957233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.957505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"278 0x7f855e9d4070 0x1b060a115be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032113.957825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 502
[1:1:0713/032113.957982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7f855e9d4070 0x1b060a1945e0 , 5:3_http://www.stdaily.com/, 0, , 325 0x7f855e9d4070 0x1b060a4b2360 
[1:1:0713/032113.958178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032113.958631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , i, (){return e.apply(t||this,r.concat(d.call(arguments)))}
[1:1:0713/032113.958787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032114.088669:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032114.088908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 600
[1:1:0713/032114.089376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 503
[1:1:0713/032114.089618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 503 0x7f855e9d4070 0x1b060a124ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 325 0x7f855e9d4070 0x1b060a4b2360 
[1:1:0713/032114.091331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/032114.091790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 504
[1:1:0713/032114.092002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7f855e9d4070 0x1b0609ce5be0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 325 0x7f855e9d4070 0x1b060a4b2360 
[1:1:0713/032114.485947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 460, 7f8561319881
[1:1:0713/032114.513113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"358 0x7f85608fc2e0 0x1b060a0cf0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032114.513454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"358 0x7f85608fc2e0 0x1b060a0cf0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032114.513887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032114.514570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032114.514828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032114.515790:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032114.516003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032114.516490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 516
[1:1:0713/032114.516802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7f855e9d4070 0x1b060ac738e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 460 0x7f855e9d4070 0x1b060a49efe0 
[1:1:0713/032114.679455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032114.680357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/032114.680586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032114.706407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.readyState
[1:1:0713/032114.706769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.374945:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 498, 7f8561319881
[1:1:0713/032115.403200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"395 0x7f855e9d4070 0x1b060a4ada60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032115.403577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"395 0x7f855e9d4070 0x1b060a4ada60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032115.403978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.404723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032115.405054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.406181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032115.406402:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032115.406911:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 554
[1:1:0713/032115.407141:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7f855e9d4070 0x1b060a4986e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 498 0x7f855e9d4070 0x1b060ac53760 
[1:1:0713/032115.455075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.455922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/032115.456140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.607725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7f85608fc2e0 0x1b060acde8e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.608861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0713/032115.609139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.622855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.623764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.704093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 515 0x7f85608fc2e0 0x1b060a1900e0 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.705261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0713/032115.705493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.726819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.727799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.773248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f85608fc2e0 0x1b060acded60 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.774417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0713/032115.774661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032115.790611:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.791602:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.832441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 521 0x7f85608fc2e0 0x1b0609ce5360 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032115.843053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0713/032115.843462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
		remove user.10_e212586a -> 0
		remove user.11_f1707838 -> 0
[1:1:0713/032116.495158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30948
[1:1:0713/032116.495456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032116.496824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 566
[1:1:0713/032116.497131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7f855e9d4070 0x1b060a4b2e60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 521 0x7f85608fc2e0 0x1b0609ce5360 
[1:1:0713/032116.535800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x16c763dc29c8, 0x1b0609e30948
[1:1:0713/032116.536101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/032116.536711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 569
[1:1:0713/032116.536979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f855e9d4070 0x1b060a4973e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 521 0x7f85608fc2e0 0x1b0609ce5360 
[1:1:0713/032116.537539:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x16c763dc29c8, 0x1b0609e30948
[1:1:0713/032116.537736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 15000
[1:1:0713/032116.538265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 570
[1:1:0713/032116.538502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7f855e9d4070 0x1b060ad94be0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 521 0x7f85608fc2e0 0x1b0609ce5360 
[1:1:0713/032116.903630:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1000
[1:1:0713/032116.904279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 573
[1:1:0713/032116.904553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f855e9d4070 0x1b060a17dae0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 521 0x7f85608fc2e0 0x1b0609ce5360 
[1:1:0713/032116.924288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032116.925152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032116.939343:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 516, 7f8561319881
[1:1:0713/032116.966323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"460 0x7f855e9d4070 0x1b060a49efe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032116.966716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"460 0x7f855e9d4070 0x1b060a49efe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032116.967118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032116.967828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032116.968043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032116.969018:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032116.969341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032116.969961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 583
[1:1:0713/032116.970323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7f855e9d4070 0x1b060b5fd360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 516 0x7f855e9d4070 0x1b060ac738e0 
[1:1:0713/032116.972173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 503, 7f8561319881
[1:1:0713/032117.000264:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"325 0x7f855e9d4070 0x1b060a4b2360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032117.000858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"325 0x7f855e9d4070 0x1b060a4b2360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032117.001395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032117.002199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , e, (){c||a(d).trigger(a.support.transition.end)}
[1:1:0713/032117.002434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032117.036753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032117.037060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/032117.037585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 584
[1:1:0713/032117.037823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f855e9d4070 0x1b060a4ad5e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 503 0x7f855e9d4070 0x1b060a124ce0 
[1:1:0713/032117.083786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.readyState
[1:1:0713/032117.084091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032117.968707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 554, 7f8561319881
[1:1:0713/032117.990821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"498 0x7f855e9d4070 0x1b060ac53760 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032117.991217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"498 0x7f855e9d4070 0x1b060ac53760 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032117.991658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032117.992360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032117.992593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032117.993599:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032117.993795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032117.994279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 600
[1:1:0713/032117.994506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f855e9d4070 0x1b060b6e7a60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 554 0x7f855e9d4070 0x1b060a4986e0 
[1:1:0713/032118.240899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 569, 7f8561319881
[1:1:0713/032118.269084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"521 0x7f85608fc2e0 0x1b0609ce5360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.269487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"521 0x7f85608fc2e0 0x1b0609ce5360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.269991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.270709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){l(e,t)}
[1:1:0713/032118.270928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.274018:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032118.274228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 1
[1:1:0713/032118.274742:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 610
[1:1:0713/032118.274984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f855e9d4070 0x1b060b76a0e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 569 0x7f855e9d4070 0x1b060a4973e0 
[1:1:0713/032118.413245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 584, 7f8561319881
[1:1:0713/032118.440589:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"503 0x7f855e9d4070 0x1b060a124ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.441031:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"503 0x7f855e9d4070 0x1b060a124ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.441572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.442365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){i.$element.trigger(m)}
[1:1:0713/032118.442594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.487900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.readyState
[1:1:0713/032118.488250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.519405:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 583, 7f8561319881
[1:1:0713/032118.538756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"516 0x7f855e9d4070 0x1b060ac738e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.539115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"516 0x7f855e9d4070 0x1b060ac738e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.539529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.540232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032118.540471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.541128:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032118.541332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032118.541838:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 619
[1:1:0713/032118.542069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f855e9d4070 0x1b060b771b60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 583 0x7f855e9d4070 0x1b060b5fd360 
[1:1:0713/032118.756551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 573, 7f85613198db
[1:1:0713/032118.773192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"521 0x7f85608fc2e0 0x1b0609ce5360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.773537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"521 0x7f85608fc2e0 0x1b0609ce5360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.774010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 635
[1:1:0713/032118.774264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f855e9d4070 0x1b060ad94de0 , 5:3_http://www.stdaily.com/, 0, , 573 0x7f855e9d4070 0x1b060a17dae0 
[1:1:0713/032118.774592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.775261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032118.775471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.840592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 603 0x7f85608fc2e0 0x1b060a187860 , "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.842562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0713/032118.842830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.861587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.862526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.901012:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 600, 7f8561319881
[1:1:0713/032118.915067:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"554 0x7f855e9d4070 0x1b060a4986e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.915426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"554 0x7f855e9d4070 0x1b060a4986e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032118.915832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.916621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032118.916959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.917760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032118.918013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032118.918644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 637
[1:1:0713/032118.918982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f855e9d4070 0x1b0609f80360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 600 0x7f855e9d4070 0x1b060b6e7a60 
[1:1:0713/032118.991974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032118.992879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (e){if(!M){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0713/032118.993099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032118.994861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 610, 7f8561319881
[1:1:0713/032119.007512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"569 0x7f855e9d4070 0x1b060a4973e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.007882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"569 0x7f855e9d4070 0x1b060a4973e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.008295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.009019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){n?t&&t():l(e,t)}
[1:1:0713/032119.009254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.088748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.089597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/032119.089808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.119766:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.120627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0713/032119.120927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.151495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.readyState
[1:1:0713/032119.151776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.229576:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.230463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , y.handle, (e){return typeof x===r||e&&x.event.triggered===e.type?undefined:x.event.dispatch.apply(a.elem,argum
[1:1:0713/032119.230699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.263142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.264309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.265359:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.287745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.289321:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30af0
[1:1:0713/032119.289529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032119.290021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 648
[1:1:0713/032119.290245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f855e9d4070 0x1b0609ce5ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 625
[1:1:0713/032119.290639:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.291736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e309f0
[1:1:0713/032119.292019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032119.292584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 649
[1:1:0713/032119.292959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f855e9d4070 0x1b060b7778e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 625
[1:1:0713/032119.421291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 635, 7f85613198db
[1:1:0713/032119.448782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"573 0x7f855e9d4070 0x1b060a17dae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.449153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"573 0x7f855e9d4070 0x1b060a17dae0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.449605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 662
[1:1:0713/032119.449846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7f855e9d4070 0x1b060a49b7e0 , 5:3_http://www.stdaily.com/, 0, , 635 0x7f855e9d4070 0x1b060ad94de0 
[1:1:0713/032119.450180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.450837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032119.451067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.462866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , document.readyState
[1:1:0713/032119.463129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.466535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 504, 7f85613198db
[1:1:0713/032119.495976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"325 0x7f855e9d4070 0x1b060a4b2360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.496354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"325 0x7f855e9d4070 0x1b060a4b2360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.496821:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 666
[1:1:0713/032119.497115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7f855e9d4070 0x1b060b6e1d60 , 5:3_http://www.stdaily.com/, 0, , 504 0x7f855e9d4070 0x1b0609ce5be0 
[1:1:0713/032119.497409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.498145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , i, (){return e.apply(t||this,r.concat(d.call(arguments)))}
[1:1:0713/032119.498395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.597112:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032119.597389:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 600
[1:1:0713/032119.597878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 668
[1:1:0713/032119.598138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f855e9d4070 0x1b060b548960 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 504 0x7f855e9d4070 0x1b0609ce5be0 
[1:1:0713/032119.599740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 5000
[1:1:0713/032119.600394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 669
[1:1:0713/032119.600624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f855e9d4070 0x1b060a4b3560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 504 0x7f855e9d4070 0x1b0609ce5be0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/032119.907850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 648, 7f8561319881
[1:1:0713/032119.936956:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"625","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.937345:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"625","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.937748:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.938420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032119.938600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.939397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032119.939558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032119.940009:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 686
[1:1:0713/032119.940222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f855e9d4070 0x1b060b67c760 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 648 0x7f855e9d4070 0x1b0609ce5ce0 
[1:1:0713/032119.941604:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 649, 7f8561319881
[1:1:0713/032119.970009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"625","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.970321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"625","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032119.970703:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032119.971364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032119.971541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032119.972324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032119.972485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032119.972933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 687
[1:1:0713/032119.973165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f855e9d4070 0x1b060b6f70e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 649 0x7f855e9d4070 0x1b060b7778e0 
[1:1:0713/032120.453611:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 662, 7f85613198db
[1:1:0713/032120.482424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"635 0x7f855e9d4070 0x1b060ad94de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.482684:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"635 0x7f855e9d4070 0x1b060ad94de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.483092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 699
[1:1:0713/032120.483302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f855e9d4070 0x1b060b89ace0 , 5:3_http://www.stdaily.com/, 0, , 662 0x7f855e9d4070 0x1b060a49b7e0 
[1:1:0713/032120.483594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032120.484249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032120.484449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032120.486014:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 686, 7f8561319881
[1:1:0713/032120.514501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"648 0x7f855e9d4070 0x1b0609ce5ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.514820:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"648 0x7f855e9d4070 0x1b0609ce5ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.515229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032120.515874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032120.516061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032120.516843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032120.517003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032120.517497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 700
[1:1:0713/032120.517702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f855e9d4070 0x1b0609bcc7e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 686 0x7f855e9d4070 0x1b060b67c760 
[1:1:0713/032120.518970:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 687, 7f8561319881
[1:1:0713/032120.549094:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"649 0x7f855e9d4070 0x1b060b7778e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.549517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"649 0x7f855e9d4070 0x1b060b7778e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.549917:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032120.550602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032120.550806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032120.551596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032120.551757:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032120.552221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 701
[1:1:0713/032120.552420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f855e9d4070 0x1b060a495ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 687 0x7f855e9d4070 0x1b060b6f70e0 
[1:1:0713/032120.583201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "webkitTransitionEnd", "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032120.584703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , y.handle, (e){return typeof x===r||e&&x.event.triggered===e.type?undefined:x.event.dispatch.apply(a.elem,argum
[1:1:0713/032120.584942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032120.605396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x16c763dc29c8, 0x1b0609e30b00
[1:1:0713/032120.605613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 0
[1:1:0713/032120.606064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 702
[1:1:0713/032120.606288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f855e9d4070 0x1b060a0c3860 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 693 0x7f856dce5960 0x1b060ae9a600 0x1b060ae9a610 
[1:1:0713/032120.763778:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 668, 7f8561319881
[1:1:0713/032120.792659:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"504 0x7f855e9d4070 0x1b0609ce5be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.792962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"504 0x7f855e9d4070 0x1b0609ce5be0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032120.793368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032120.794063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , e, (){c||a(d).trigger(a.support.transition.end)}
[1:1:0713/032120.794238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.100839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 702, 7f8561319881
[1:1:0713/032121.130049:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"693 0x7f856dce5960 0x1b060ae9a600 0x1b060ae9a610 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.130395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"693 0x7f856dce5960 0x1b060ae9a600 0x1b060ae9a610 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.130753:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.131403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){i.$element.trigger(m)}
[1:1:0713/032121.131580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.146296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 700, 7f8561319881
[1:1:0713/032121.175529:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"686 0x7f855e9d4070 0x1b060b67c760 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.175865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"686 0x7f855e9d4070 0x1b060b67c760 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.176230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.176882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.177060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.177859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.178019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.178507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 719
[1:1:0713/032121.178699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f855e9d4070 0x1b060b89b0e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 700 0x7f855e9d4070 0x1b0609bcc7e0 
[1:1:0713/032121.209092:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 701, 7f8561319881
[1:1:0713/032121.238147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"687 0x7f855e9d4070 0x1b060b6f70e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.238489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"687 0x7f855e9d4070 0x1b060b6f70e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.238847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.239509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.239688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.240461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.240621:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.241073:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 720
[1:1:0713/032121.241260:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7f855e9d4070 0x1b060b738ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 701 0x7f855e9d4070 0x1b060a495ce0 
[1:1:0713/032121.314020:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 699, 7f85613198db
[1:1:0713/032121.343496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"662 0x7f855e9d4070 0x1b060a49b7e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.343865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"662 0x7f855e9d4070 0x1b060a49b7e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.344376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 726
[1:1:0713/032121.344640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7f855e9d4070 0x1b060ac4c0e0 , 5:3_http://www.stdaily.com/, 0, , 699 0x7f855e9d4070 0x1b060b89ace0 
[1:1:0713/032121.344958:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.345772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032121.345997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.476025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 719, 7f8561319881
[1:1:0713/032121.485215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"700 0x7f855e9d4070 0x1b0609bcc7e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.485387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"700 0x7f855e9d4070 0x1b0609bcc7e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.485620:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.485958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.486062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.486386:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.486504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.486708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 730
[1:1:0713/032121.486814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f855e9d4070 0x1b060ac5f2e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 719 0x7f855e9d4070 0x1b060b89b0e0 
[1:1:0713/032121.502348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 720, 7f8561319881
[1:1:0713/032121.532643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"701 0x7f855e9d4070 0x1b060a495ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.532854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"701 0x7f855e9d4070 0x1b060a495ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.533056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.533393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.533611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.533937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.534032:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.534225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 734
[1:1:0713/032121.534336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7f855e9d4070 0x1b060b67c460 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 720 0x7f855e9d4070 0x1b060b738ce0 
[1:1:0713/032121.699468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 730, 7f8561319881
[1:1:0713/032121.732482:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"719 0x7f855e9d4070 0x1b060b89b0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.732883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"719 0x7f855e9d4070 0x1b060b89b0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.733317:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.734153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.734373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.735341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.735568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.736141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 745
[1:1:0713/032121.736384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f855e9d4070 0x1b060a18ace0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 730 0x7f855e9d4070 0x1b060ac5f2e0 
[1:1:0713/032121.839339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 734, 7f8561319881
[1:1:0713/032121.853398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"720 0x7f855e9d4070 0x1b060b738ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.853632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"720 0x7f855e9d4070 0x1b060b738ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.853849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.854183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.854290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.854652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.854754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.855004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 749
[1:1:0713/032121.855111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7f855e9d4070 0x1b060b89aa60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 734 0x7f855e9d4070 0x1b060b67c460 
[1:1:0713/032121.855931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 745, 7f8561319881
[1:1:0713/032121.866166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"730 0x7f855e9d4070 0x1b060ac5f2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.866332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"730 0x7f855e9d4070 0x1b060ac5f2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.866521:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.866863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032121.866966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032121.867282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032121.867380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032121.867588:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 751
[1:1:0713/032121.867698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7f855e9d4070 0x1b060a4a30e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 745 0x7f855e9d4070 0x1b060a18ace0 
[1:1:0713/032121.981350:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 726, 7f85613198db
[1:1:0713/032121.991204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"699 0x7f855e9d4070 0x1b060b89ace0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.991374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"699 0x7f855e9d4070 0x1b060b89ace0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032121.991606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 760
[1:1:0713/032121.991719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7f855e9d4070 0x1b060b8ef4e0 , 5:3_http://www.stdaily.com/, 0, , 726 0x7f855e9d4070 0x1b060ac4c0e0 
[1:1:0713/032121.991867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032121.992182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032121.992290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.002283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 749, 7f8561319881
[1:1:0713/032122.011882:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"734 0x7f855e9d4070 0x1b060b67c460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.012052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"734 0x7f855e9d4070 0x1b060b67c460 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.012238:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.012551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.012697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.014303:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.014411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.014636:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 763
[1:1:0713/032122.014751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7f855e9d4070 0x1b060b6f7e60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 749 0x7f855e9d4070 0x1b060b89aa60 
[1:1:0713/032122.027074:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 751, 7f8561319881
[1:1:0713/032122.036372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"745 0x7f855e9d4070 0x1b060a18ace0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.036507:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"745 0x7f855e9d4070 0x1b060a18ace0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.036726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.037060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.037164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.037486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.037600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.038163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 764
[1:1:0713/032122.038384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f855e9d4070 0x1b060b8875e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 751 0x7f855e9d4070 0x1b060a4a30e0 
[1:1:0713/032122.160922:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032122.161494:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/032122.235540:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 763, 7f8561319881
[1:1:0713/032122.266393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"749 0x7f855e9d4070 0x1b060b89aa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.266748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"749 0x7f855e9d4070 0x1b060b89aa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.267184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.267982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.268199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.269009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.269156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.269445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 773
[1:1:0713/032122.269596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 773 0x7f855e9d4070 0x1b060b82a5e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 763 0x7f855e9d4070 0x1b060b6f7e60 
[1:1:0713/032122.270338:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 764, 7f8561319881
[1:1:0713/032122.285221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"751 0x7f855e9d4070 0x1b060a4a30e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.285456:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"751 0x7f855e9d4070 0x1b060a4a30e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.285751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.286200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.286343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.286833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.286969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.287247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 774
[1:1:0713/032122.287390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7f855e9d4070 0x1b0609b64360 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 764 0x7f855e9d4070 0x1b060b8875e0 
[1:1:0713/032122.401397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 773, 7f8561319881
[1:1:0713/032122.433930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"763 0x7f855e9d4070 0x1b060b6f7e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.434252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"763 0x7f855e9d4070 0x1b060b6f7e60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.434611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.435272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.435448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.436238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.436398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.436899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 779
[1:1:0713/032122.437090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7f855e9d4070 0x1b060af9be60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 773 0x7f855e9d4070 0x1b060b82a5e0 
[1:1:0713/032122.438429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 774, 7f8561319881
[1:1:0713/032122.471668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"764 0x7f855e9d4070 0x1b060b8875e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.472005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"764 0x7f855e9d4070 0x1b060b8875e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.472362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.473121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.473320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.474129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.474293:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.474774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 780
[1:1:0713/032122.474971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f855e9d4070 0x1b060b8b5ce0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 774 0x7f855e9d4070 0x1b0609b64360 
[1:1:0713/032122.578203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 779, 7f8561319881
[1:1:0713/032122.617567:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"773 0x7f855e9d4070 0x1b060b82a5e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.617989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"773 0x7f855e9d4070 0x1b060b82a5e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.618437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.619253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.619477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.620454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.620653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.621273:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 785
[1:1:0713/032122.621519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f855e9d4070 0x1b060a0276e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 779 0x7f855e9d4070 0x1b060af9be60 
[1:1:0713/032122.623286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 780, 7f8561319881
[1:1:0713/032122.660732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"774 0x7f855e9d4070 0x1b0609b64360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.661071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"774 0x7f855e9d4070 0x1b0609b64360 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.661434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.662094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.662282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.663064:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.663224:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.663674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 786
[1:1:0713/032122.663887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7f855e9d4070 0x1b060a49a1e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 780 0x7f855e9d4070 0x1b060b8b5ce0 
[1:1:0713/032122.733919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 785, 7f8561319881
[1:1:0713/032122.744092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"779 0x7f855e9d4070 0x1b060af9be60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.744272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"779 0x7f855e9d4070 0x1b060af9be60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.744472:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.744828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.744941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.745265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.745364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.745558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 788
[1:1:0713/032122.745664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 788 0x7f855e9d4070 0x1b060b73c560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 785 0x7f855e9d4070 0x1b060a0276e0 
[1:1:0713/032122.802556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 786, 7f8561319881
[1:1:0713/032122.821475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"780 0x7f855e9d4070 0x1b060b8b5ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.821682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"780 0x7f855e9d4070 0x1b060b8b5ce0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.821908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.822251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.822370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.822699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.822821:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.823029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 790
[1:1:0713/032122.823143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7f855e9d4070 0x1b060a189a60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 786 0x7f855e9d4070 0x1b060a49a1e0 
[1:1:0713/032122.859591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 788, 7f8561319881
[1:1:0713/032122.868896:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"785 0x7f855e9d4070 0x1b060a0276e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.869072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"785 0x7f855e9d4070 0x1b060a0276e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.869266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.869595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032122.869705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.870063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032122.870163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032122.870359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 792
[1:1:0713/032122.870480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f855e9d4070 0x1b060a0c3fe0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 788 0x7f855e9d4070 0x1b060b73c560 
[1:1:0713/032122.936524:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 760, 7f85613198db
[1:1:0713/032122.967992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"726 0x7f855e9d4070 0x1b060ac4c0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.968274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"726 0x7f855e9d4070 0x1b060ac4c0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032122.968672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 795
[1:1:0713/032122.968922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7f855e9d4070 0x1b060a06ca60 , 5:3_http://www.stdaily.com/, 0, , 760 0x7f855e9d4070 0x1b060b8ef4e0 
[1:1:0713/032122.969180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032122.969791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032122.969987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032122.971611:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 790, 7f8561319881
[1:1:0713/032123.002686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"786 0x7f855e9d4070 0x1b060a49a1e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.003011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"786 0x7f855e9d4070 0x1b060a49a1e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.003357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.003994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.004169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.004968:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.005154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.005713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 797
[1:1:0713/032123.005920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7f855e9d4070 0x1b060b89b0e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 790 0x7f855e9d4070 0x1b060a189a60 
[1:1:0713/032123.007169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 792, 7f8561319881
[1:1:0713/032123.037272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"788 0x7f855e9d4070 0x1b060b73c560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.037579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"788 0x7f855e9d4070 0x1b060b73c560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.037941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.038556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.038735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.039483:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.039639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.040090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 798
[1:1:0713/032123.040275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7f855e9d4070 0x1b060b89aa60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 792 0x7f855e9d4070 0x1b060a0c3fe0 
[1:1:0713/032123.138326:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 797, 7f8561319881
[1:1:0713/032123.175945:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"790 0x7f855e9d4070 0x1b060a189a60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.176261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"790 0x7f855e9d4070 0x1b060a189a60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.176618:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.177302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.177478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.178340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.178540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.179056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 800
[1:1:0713/032123.179251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f855e9d4070 0x1b060b89b2e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 797 0x7f855e9d4070 0x1b060b89b0e0 
[1:1:0713/032123.180600:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 798, 7f8561319881
[1:1:0713/032123.212121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"792 0x7f855e9d4070 0x1b060a0c3fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.212435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"792 0x7f855e9d4070 0x1b060a0c3fe0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.212788:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.213473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.213663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.214461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.214622:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.215091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 802
[1:1:0713/032123.215283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f855e9d4070 0x1b060b832d60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 798 0x7f855e9d4070 0x1b060b89aa60 
[1:1:0713/032123.339093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 800, 7f8561319881
[1:1:0713/032123.370714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"797 0x7f855e9d4070 0x1b060b89b0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.371051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"797 0x7f855e9d4070 0x1b060b89b0e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.371419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.372079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.372257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.373056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.373216:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.373664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 806
[1:1:0713/032123.373864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 806 0x7f855e9d4070 0x1b060b763d60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 800 0x7f855e9d4070 0x1b060b89b2e0 
[1:1:0713/032123.375186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 802, 7f8561319881
[1:1:0713/032123.406792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"798 0x7f855e9d4070 0x1b060b89aa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.407120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"798 0x7f855e9d4070 0x1b060b89aa60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.407474:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.408141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.408317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.409114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.409278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.409728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 807
[1:1:0713/032123.409918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f855e9d4070 0x1b060b784560 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 802 0x7f855e9d4070 0x1b060b832d60 
[1:1:0713/032123.500632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 806, 7f8561319881
[1:1:0713/032123.510887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"800 0x7f855e9d4070 0x1b060b89b2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.511102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"800 0x7f855e9d4070 0x1b060b89b2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.511304:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.511636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.511741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.512106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.512207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.512415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 809
[1:1:0713/032123.512523:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f855e9d4070 0x1b060b89bd60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 806 0x7f855e9d4070 0x1b060b763d60 
[1:1:0713/032123.523557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 807, 7f8561319881
[1:1:0713/032123.534287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"802 0x7f855e9d4070 0x1b060b832d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.534457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"802 0x7f855e9d4070 0x1b060b832d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.534656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.535004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.535111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.535432:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.535527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.535720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 812
[1:1:0713/032123.535826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7f855e9d4070 0x1b060b78f160 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 807 0x7f855e9d4070 0x1b060b784560 
[1:1:0713/032123.637503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 809, 7f8561319881
[1:1:0713/032123.657934:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"806 0x7f855e9d4070 0x1b060b763d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.658263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"806 0x7f855e9d4070 0x1b060b763d60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.658619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.659277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.659454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.660234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.660404:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.660854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 815
[1:1:0713/032123.661085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f855e9d4070 0x1b060b8a7a60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 809 0x7f855e9d4070 0x1b060b89bd60 
[1:1:0713/032123.662360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 812, 7f8561319881
[1:1:0713/032123.694340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"807 0x7f855e9d4070 0x1b060b784560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.694664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"807 0x7f855e9d4070 0x1b060b784560 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.695040:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.695684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.695860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.696641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.696801:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.697294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 816
[1:1:0713/032123.697487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 816 0x7f855e9d4070 0x1b0609fb43e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 812 0x7f855e9d4070 0x1b060b78f160 
[1:1:0713/032123.793984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 815, 7f8561319881
[1:1:0713/032123.826007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"809 0x7f855e9d4070 0x1b060b89bd60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.826366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"809 0x7f855e9d4070 0x1b060b89bd60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.826737:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.827403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.827582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.828382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.828545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.828998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 818
[1:1:0713/032123.829250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 818 0x7f855e9d4070 0x1b060b89b2e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 815 0x7f855e9d4070 0x1b060b8a7a60 
[1:1:0713/032123.830585:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 816, 7f8561319881
[1:1:0713/032123.844637:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"812 0x7f855e9d4070 0x1b060b78f160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.844838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"812 0x7f855e9d4070 0x1b060b78f160 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.845129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.845458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032123.845557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.845876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032123.845969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032123.846356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 820
[1:1:0713/032123.846541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 820 0x7f855e9d4070 0x1b060a06cc60 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 816 0x7f855e9d4070 0x1b0609fb43e0 
[1:1:0713/032123.938851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 795, 7f85613198db
[1:1:0713/032123.971422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"760 0x7f855e9d4070 0x1b060b8ef4e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.971710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"760 0x7f855e9d4070 0x1b060b8ef4e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032123.972121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.stdaily.com/, 823
[1:1:0713/032123.972316:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7f855e9d4070 0x1b060b8ef060 , 5:3_http://www.stdaily.com/, 0, , 795 0x7f855e9d4070 0x1b060a06ca60 
[1:1:0713/032123.972567:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032123.973242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , , (){document.hasFocus()&&s++}
[1:1:0713/032123.973429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032123.975078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 818, 7f8561319881
[1:1:0713/032124.008007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"815 0x7f855e9d4070 0x1b060b8a7a60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.008347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"815 0x7f855e9d4070 0x1b060b8a7a60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.008717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.009400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.009580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.010372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.010535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.010985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 825
[1:1:0713/032124.011190:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7f855e9d4070 0x1b0609fb8de0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 818 0x7f855e9d4070 0x1b060b89b2e0 
[1:1:0713/032124.012526:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 820, 7f8561319881
[1:1:0713/032124.044691:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"816 0x7f855e9d4070 0x1b0609fb43e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.044983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"816 0x7f855e9d4070 0x1b0609fb43e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.045370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.045995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.046189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.046945:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.047134:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.047587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 826
[1:1:0713/032124.047778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 826 0x7f855e9d4070 0x1b060b89a6e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 820 0x7f855e9d4070 0x1b060a06cc60 
[1:1:0713/032124.152115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 825, 7f8561319881
[1:1:0713/032124.179474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"818 0x7f855e9d4070 0x1b060b89b2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.179690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"818 0x7f855e9d4070 0x1b060b89b2e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.179895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.180259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.180366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.180693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.180788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.180984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 829
[1:1:0713/032124.181093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f855e9d4070 0x1b060b6e74e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 825 0x7f855e9d4070 0x1b0609fb8de0 
[1:1:0713/032124.181576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 826, 7f8561319881
[1:1:0713/032124.201227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"820 0x7f855e9d4070 0x1b060a06cc60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.201429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"820 0x7f855e9d4070 0x1b060a06cc60 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.201635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.201965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.202070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.202438:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.202538:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.202770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 830
[1:1:0713/032124.202878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7f855e9d4070 0x1b060ac5a8e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 826 0x7f855e9d4070 0x1b060b89a6e0 
[1:1:0713/032124.314367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 829, 7f8561319881
[1:1:0713/032124.342446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"825 0x7f855e9d4070 0x1b0609fb8de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.342707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"825 0x7f855e9d4070 0x1b0609fb8de0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.342977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.343444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.343587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.345738:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.345875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.346142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 836
[1:1:0713/032124.346303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f855e9d4070 0x1b0609b64260 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 829 0x7f855e9d4070 0x1b060b6e74e0 
[1:1:0713/032124.378065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 830, 7f8561319881
[1:1:0713/032124.395491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2a2fb5602860","ptid":"826 0x7f855e9d4070 0x1b060b89a6e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.395883:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.stdaily.com/","ptid":"826 0x7f855e9d4070 0x1b060b89a6e0 ","rf":"5:3_http://www.stdaily.com/"}
[1:1:0713/032124.396247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml"
[1:1:0713/032124.396889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.stdaily.com/, 2a2fb5602860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/032124.397077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", "www.stdaily.com", 3, 1, , , 0
[1:1:0713/032124.397882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x16c763dc29c8, 0x1b0609e30950
[1:1:0713/032124.398040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.stdaily.com/index/kejixinwen/2018-01/26/content_629726.shtml", 100
[1:1:0713/032124.398514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.stdaily.com/, 838
[1:1:0713/032124.398705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f855e9d4070 0x1b060b73c4e0 , 5:3_http://www.stdaily.com/, 1, -5:3_http://www.stdaily.com/, 830 0x7f855e9d4070 0x1b060ac5a8e0 
