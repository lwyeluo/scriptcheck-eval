[0712/094753.586962:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094753.587506:INFO:switcher_clone.cc(787)] backtrace rip is 7fbc9733d891
[0712/094754.667524:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094754.667926:INFO:switcher_clone.cc(787)] backtrace rip is 7fe54af8c891
[1:1:0712/094754.679857:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/094754.680155:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/094754.685765:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[119008:119008:0712/094755.940973:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ad7f1a1e-b606-40f6-b1f4-e8c93d76e785
[0712/094756.158416:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094756.158936:INFO:switcher_clone.cc(787)] backtrace rip is 7fd76adf9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[119041:119041:0712/094756.369921:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119041
[119053:119053:0712/094756.370383:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119053
[119008:119008:0712/094756.380949:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[119008:119038:0712/094756.381830:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/094756.382065:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/094756.382289:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/094756.382915:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/094756.383233:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/094756.386546:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3261c2f6, 1
[1:1:0712/094756.386895:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37a47690, 0
[1:1:0712/094756.387005:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x11fc53b4, 3
[1:1:0712/094756.387103:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3ccaed3f, 2
[1:1:0712/094756.387229:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9076ffffffa437 fffffff6ffffffc26132 3fffffffedffffffca3c ffffffb453fffffffc11 , 10104, 4
[1:1:0712/094756.387965:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119008:119038:0712/094756.388138:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�v�7��a2?��<�S�/Gb
[1:1:0712/094756.388117:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe5491c70a0, 3
[119008:119038:0712/094756.388206:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �v�7��a2?��<�S�L/Gb
[1:1:0712/094756.388232:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe549352080, 2
[1:1:0712/094756.388323:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe533015d20, -2
[119008:119038:0712/094756.388466:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[119008:119038:0712/094756.388536:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119055, 4, 9076a437 f6c26132 3fedca3c b453fc11 
[1:1:0712/094756.401119:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/094756.402034:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3ccaed3f
[1:1:0712/094756.403212:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3ccaed3f
[1:1:0712/094756.405047:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3ccaed3f
[1:1:0712/094756.406914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.407148:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.407378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.407621:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.408490:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3ccaed3f
[1:1:0712/094756.408943:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe54af8c7ba
[1:1:0712/094756.409122:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe54af83def, 7fe54af8c77a, 7fe54af8e0cf
[1:1:0712/094756.416044:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3ccaed3f
[1:1:0712/094756.416495:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3ccaed3f
[1:1:0712/094756.417417:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3ccaed3f
[1:1:0712/094756.419912:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.420052:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.420175:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.420279:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3ccaed3f
[1:1:0712/094756.420749:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3ccaed3f
[1:1:0712/094756.420959:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe54af8c7ba
[1:1:0712/094756.421053:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe54af83def, 7fe54af8c77a, 7fe54af8e0cf
[1:1:0712/094756.423297:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/094756.423578:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/094756.423676:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd826b0468, 0x7ffd826b03e8)
[1:1:0712/094756.438776:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/094756.444714:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[119008:119033:0712/094757.061137:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[119008:119008:0712/094757.081526:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119008:119008:0712/094757.082956:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119008:119020:0712/094757.104864:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[119008:119020:0712/094757.104984:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[119008:119008:0712/094757.105197:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[119008:119008:0712/094757.105287:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[119008:119008:0712/094757.105435:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,119055, 4
[1:7:0712/094757.113773:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/094757.157491:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xfd3d53d0220
[1:1:0712/094757.157863:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/094757.607435:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[119008:119008:0712/094759.130394:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[119008:119008:0712/094759.130526:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/094759.133968:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094759.138441:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094759.829224:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094759.942820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/094759.943116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094759.964444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/094759.964751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094800.216250:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094800.216522:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094800.665336:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094800.673448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/094800.673735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094800.708597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094800.719118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/094800.719406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094800.731653:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/094800.735162:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xfd3d53cee20
[1:1:0712/094800.735378:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[119008:119008:0712/094800.735994:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[119008:119008:0712/094800.752069:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[119008:119008:0712/094800.770594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[119008:119008:0712/094800.770688:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/094800.820597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094801.492870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe534bf02e0 0xfd3d54e38e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094801.494313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/094801.494518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094801.495983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119008:119008:0712/094801.567182:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/094801.568339:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xfd3d53cf820
[1:1:0712/094801.568551:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119008:119008:0712/094801.575967:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/094801.579170:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/094801.579321:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[119008:119008:0712/094801.601857:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[119008:119008:0712/094801.621607:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119008:119008:0712/094801.622643:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119008:119020:0712/094801.629658:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[119008:119020:0712/094801.629754:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[119008:119008:0712/094801.633026:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[119008:119008:0712/094801.633126:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[119008:119008:0712/094801.633266:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,119055, 4
[1:7:0712/094801.634553:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/094801.984964:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/094802.222816:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7fe534bf02e0 0xfd3d5689360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094802.223506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/094802.224189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094802.224975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119008:119008:0712/094802.368113:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[119008:119008:0712/094802.368270:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/094802.394418:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094802.752130:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094803.136602:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094803.136777:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094803.391596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094803.393271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/094803.393422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094803.395766:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[119008:119008:0712/094803.432994:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[119008:119038:0712/094803.433421:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/094803.433633:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/094803.433860:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/094803.434250:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/094803.434396:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/094803.437508:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3dbe9c41, 1
[1:1:0712/094803.437898:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x291c55c1, 0
[1:1:0712/094803.438051:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3686a666, 3
[1:1:0712/094803.438194:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x24abffe3, 2
[1:1:0712/094803.438336:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc1551c29 41ffffff9cffffffbe3d ffffffe3ffffffffffffffab24 66ffffffa6ffffff8636 , 10104, 5
[1:1:0712/094803.439450:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119008:119038:0712/094803.439766:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�U)A��=���$f��6�Ib
[119008:119038:0712/094803.439895:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �U)A��=���$f��6� �Ib
[1:1:0712/094803.439758:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe5491c70a0, 3
[1:1:0712/094803.439983:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe549352080, 2
[119008:119038:0712/094803.440153:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119107, 5, c1551c29 419cbe3d e3ffab24 66a68636 
[1:1:0712/094803.440180:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe533015d20, -2
[1:1:0712/094803.454981:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/094803.455200:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 24abffe3
[1:1:0712/094803.455385:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 24abffe3
[1:1:0712/094803.455696:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 24abffe3
[1:1:0712/094803.456128:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.456246:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.456344:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.456434:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.456706:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 24abffe3
[1:1:0712/094803.456837:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe54af8c7ba
[1:1:0712/094803.456911:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe54af83def, 7fe54af8c77a, 7fe54af8e0cf
[1:1:0712/094803.458423:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 24abffe3
[1:1:0712/094803.458713:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 24abffe3
[1:1:0712/094803.459460:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 24abffe3
[1:1:0712/094803.461503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.461753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.461951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.462135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 24abffe3
[1:1:0712/094803.463376:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 24abffe3
[1:1:0712/094803.463810:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe54af8c7ba
[1:1:0712/094803.463957:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe54af83def, 7fe54af8c77a, 7fe54af8e0cf
[1:1:0712/094803.471723:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/094803.472259:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/094803.472410:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd826b0468, 0x7ffd826b03e8)
[1:1:0712/094803.487387:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/094803.492277:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/094803.560430:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094803.561324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ce53801f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/094803.561642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094803.702772:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xfd3d53b8220
[1:1:0712/094803.703083:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/094803.712198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094803.713933:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/094803.714190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/094803.714486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094803.912870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094803.913756:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/094803.913968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/094803.914241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094804.207274:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/094804.274087:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[119008:119008:0712/094804.334976:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119008:119008:0712/094804.341421:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119008:119020:0712/094804.360592:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[119008:119020:0712/094804.360695:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[119008:119008:0712/094804.361432:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://baqiu.zxart.cn/
[119008:119008:0712/094804.361473:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://baqiu.zxart.cn/, http://baqiu.zxart.cn/en, 1
[119008:119008:0712/094804.361530:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://baqiu.zxart.cn/, HTTP/1.1 200 OK Cache-Control: private Content-Type: text/html; charset=utf-8 Content-Encoding: gzip Vary: Accept-Encoding Server: Microsoft-IIS/7.5 X-AspNet-Version: 4.0.30319 Set-Cookie: BlogAntiForgeryToken=lI77DuwdhRLd9Ifexwza9+GgR9WQNAyIyJivtlnxCAPtrQOu9ApWEmH4YgLEdFvb; domain=.zxart.cn; path=/; HttpOnly X-Powered-By: ASP.NET Date: Fri, 12 Jul 2019 16:47:04 GMT Content-Length: 26828  ,119107, 5
[1:7:0712/094804.365840:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/094804.409471:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://baqiu.zxart.cn/
[1:1:0712/094804.532312:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/094804.541351:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094804.541914:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[119008:119008:0712/094804.554166:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://baqiu.zxart.cn/, http://baqiu.zxart.cn/, 1
[119008:119008:0712/094804.554285:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://baqiu.zxart.cn/, http://baqiu.zxart.cn
[1:1:0712/094804.568892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094804.584995:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094804.602266:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094804.602427:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094804.670891:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/094804.746714:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/094804.825199:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/094804.915526:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094804.928423:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/094804.972495:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/094805.054903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094805.055812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/094805.056106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094805.087404:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094805.088454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/094805.088746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094805.189030:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094805.189961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/094805.190253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094805.192410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 166 0x7fe533030bd0 0xfd3d54d52d8 , "http://baqiu.zxart.cn/en"
[1:1:0712/094805.204821:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094805.213830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , /*v1.9.1*/(function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="
[1:1:0712/094805.214096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094805.281485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094805.282309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/094805.282583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094805.536935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 166 0x7fe533030bd0 0xfd3d54d52d8 , "http://baqiu.zxart.cn/en"
[1:1:0712/094805.697050:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094805.697960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ce5392e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/094805.698254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/094806.278610:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.76959, 1, 0
[1:1:0712/094806.278794:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094806.385790:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094806.386271:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094806.386695:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094806.387214:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094806.387657:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094806.404869:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094806.405071:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094806.406147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fe532cc8070 0xfd3d554a560 , "http://baqiu.zxart.cn/en"
[1:1:0712/094806.407528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 
        $ = jQuery;
        function AddFriend(fn) {
            $.post("../../blog/Ajax/YSJFriend/
[1:1:0712/094806.407714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094806.410090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fe532cc8070 0xfd3d554a560 , "http://baqiu.zxart.cn/en"
[1:1:0712/094806.469317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fe532cc8070 0xfd3d554a560 , "http://baqiu.zxart.cn/en"
[1:1:0712/094806.483821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fe532cc8070 0xfd3d554a560 , "http://baqiu.zxart.cn/en"
[1:1:0712/094806.508896:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.103757, 209, 1
[1:1:0712/094806.509190:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094807.406739:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094807.406961:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094807.407796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7fe532cc8070 0xfd3d591d660 , "http://baqiu.zxart.cn/en"
[1:1:0712/094807.408712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 
                    function display() {
                        document.getElementById("box").sty
[1:1:0712/094807.408896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094807.417570:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0104902, 61, 1
[1:1:0712/094807.417753:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094808.261316:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094808.261601:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094808.262573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7fe532cc8070 0xfd3d591b6e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094808.263784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 
                jQuery(document).ready(function () {
                    jQuery(".x_title ul li").h
[1:1:0712/094808.264019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094808.274246:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7fe532cc8070 0xfd3d591b6e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094808.549584:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x6eb9c4c29c8, 0xfd3d4d76198
[1:1:0712/094808.549925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 800
[1:1:0712/094808.550296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 363
[1:1:0712/094808.550525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 363 0x7fe532cc8070 0xfd3d54bec60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 286 0x7fe532cc8070 0xfd3d591b6e0 
[1:1:0712/094808.557484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 286 0x7fe532cc8070 0xfd3d591b6e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094808.580423:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.31871, 131, 1
[1:1:0712/094808.580699:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094809.805489:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094809.805770:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094809.806544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7fe532cc8070 0xfd3d591ff60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094809.807752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , ,                             window._bd_share_config = { "common": { "bdSnsKey": {}, "bdText": "", "b
[1:1:0712/094809.808011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094809.860879:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.055059, 212, 1
[1:1:0712/094809.861200:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094810.263346:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 363, 7fe53560d881
[1:1:0712/094810.287168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"286 0x7fe532cc8070 0xfd3d591b6e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094810.287599:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"286 0x7fe532cc8070 0xfd3d591b6e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094810.288035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094810.288792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , e, (){k.y=(t*2||M[ai])/2;if(o==0&&k.y<=w+k.Step&&!an){if(ab){var j=M.getAttribute("fixnum")/1+1||1;M.se
[1:1:0712/094810.289124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094810.861823:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76158
[1:1:0712/094810.862113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094810.862495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 434
[1:1:0712/094810.862742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7fe532cc8070 0xfd3d5badb60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 363 0x7fe532cc8070 0xfd3d54bec60 
[1:1:0712/094811.357468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094811.357759:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094811.358664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fe532cc8070 0xfd3d58b5a60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094811.359641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 
                        function ShowVideoCss(num) {
                            jQuery("#v_" + num
[1:1:0712/094811.359862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094811.441678:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0838401, 451, 1
[1:1:0712/094811.442004:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094811.643250:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 434, 7fe53560d881
[1:1:0712/094811.666060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"363 0x7fe532cc8070 0xfd3d54bec60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094811.666417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"363 0x7fe532cc8070 0xfd3d54bec60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094811.666888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094811.667497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , e, (){k.y=(t*2||M[ai])/2;if(o==0&&k.y<=w+k.Step&&!an){if(ab){var j=M.getAttribute("fixnum")/1+1||1;M.se
[1:1:0712/094811.667804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094812.223225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76158
[1:1:0712/094812.223505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094812.223917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 481
[1:1:0712/094812.224151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7fe532cc8070 0xfd3d5479be0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 434 0x7fe532cc8070 0xfd3d5badb60 
[1:1:0712/094812.269654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7fe534bf02e0 0xfd3d58cf760 , "http://baqiu.zxart.cn/en"
[1:1:0712/094812.272684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/094812.272944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094813.158559:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094813.158848:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094813.159943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.161547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 

                //$("#login_btn").attr("href", "http://www.zxart.cn/Login.html?ToUrl=" + window.lo
[1:1:0712/094813.161774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094813.170096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.187457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
		remove user.10_5d25a2d -> 0
		remove user.11_385810b2 -> 0
		remove user.12_f7797d83 -> 0
		remove user.13_e29eb2a6 -> 0
		remove user.14_1a5a53c8 -> 0
[1:1:0712/094813.277712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.289022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.302271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.311036:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fe532cc8070 0xfd3d5b24d60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.340156:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.181217, 98, 1
[1:1:0712/094813.340435:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094813.441776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 481, 7fe53560d881
[1:1:0712/094813.448774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"434 0x7fe532cc8070 0xfd3d5badb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094813.449124:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"434 0x7fe532cc8070 0xfd3d5badb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094813.449509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094813.450056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){if((k.ScrollStep>=0&&k.l)||(P==0&&k.ScrollStep==-2&&k.l)){k.l()}p()}
[1:1:0712/094813.450291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094813.454771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 20
[1:1:0712/094813.455225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 506
[1:1:0712/094813.455471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7fe532cc8070 0xfd3d5a2fc60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 481 0x7fe532cc8070 0xfd3d5479be0 
[1:1:0712/094813.935684:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094813.935960:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://baqiu.zxart.cn/en"
[1:1:0712/094813.940058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504 0x7fe532cc8070 0xfd3d555a4e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.941195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , 
var KX_cfg_data = { cnnic_dn : '', cnnic_lang : 'zh_cn' };

KX_cfg_data.cnnic_sn = "e14031835020
[1:1:0712/094813.941420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094813.947528:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 504 0x7fe532cc8070 0xfd3d555a4e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094813.953802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baqiu.zxart.cn/en"
[1:1:0712/094814.480706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 5000
[1:1:0712/094814.481186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 525
[1:1:0712/094814.481442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7fe532cc8070 0xfd3d50e45e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094814.506936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 5000
[1:1:0712/094814.507432:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 526
[1:1:0712/094814.507684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7fe532cc8070 0xfd3d587ff60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094814.889477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d76440
[1:1:0712/094814.889985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094814.890520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 528
[1:1:0712/094814.890816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7fe532cc8070 0xfd3d58dfb60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094814.948634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://baqiu.zxart.cn/en"
[1:1:0712/094814.973722:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094814.974075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094814.974553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 529
[1:1:0712/094814.974805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7fe532cc8070 0xfd3d4fcb0e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094814.987660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094814.988040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094814.988525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 531
[1:1:0712/094814.988816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7fe532cc8070 0xfd3d590ef60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.009219:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094815.009569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094815.010039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 534
[1:1:0712/094815.010336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7fe532cc8070 0xfd3d5bacde0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.023173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094815.023558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094815.024108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 537
[1:1:0712/094815.024466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7fe532cc8070 0xfd3d5e81660 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.037764:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094815.038050:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094815.038475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 540
[1:1:0712/094815.038732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7fe532cc8070 0xfd3d4fcb6e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.050298:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094815.050620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094815.051021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 543
[1:1:0712/094815.051275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7fe532cc8070 0xfd3d50e35e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.058169:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d761e0
[1:1:0712/094815.058439:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094815.058887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 545
[1:1:0712/094815.059139:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 545 0x7fe532cc8070 0xfd3d555a6e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 504 0x7fe532cc8070 0xfd3d555a4e0 
[1:1:0712/094815.106923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 506, 7fe53560d8db
[1:1:0712/094815.127365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"481 0x7fe532cc8070 0xfd3d5479be0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094815.127886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"481 0x7fe532cc8070 0xfd3d5479be0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094815.128378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 554
[1:1:0712/094815.128659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7fe532cc8070 0xfd3d58aee60 , 5:3_http://baqiu.zxart.cn/, 0, , 506 0x7fe532cc8070 0xfd3d5a2fc60 
[1:1:0712/094815.129002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094815.129607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094815.129830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094815.407342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baqiu.zxart.cn/en"
[1:1:0712/094815.408209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0712/094815.408467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094815.409709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baqiu.zxart.cn/en"
[1:1:0712/094815.412488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://baqiu.zxart.cn/en"
[1:1:0712/094815.413227:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1ee0027fb860
[1:1:0712/094815.947301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 554, 7fe53560d8db
[1:1:0712/094815.976023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"506 0x7fe532cc8070 0xfd3d5a2fc60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094815.976369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"506 0x7fe532cc8070 0xfd3d5a2fc60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094815.976845:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 594
[1:1:0712/094815.977091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7fe532cc8070 0xfd3d53e06e0 , 5:3_http://baqiu.zxart.cn/, 0, , 554 0x7fe532cc8070 0xfd3d58aee60 
[1:1:0712/094815.977447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094815.977997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094815.978236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.154929:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561 0x7fe534bf02e0 0xfd3d5890a60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.156255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/094816.156477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.175689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562 0x7fe534bf02e0 0xfd3d5e7a460 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.177140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094816.177446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.201935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76190
[1:1:0712/094816.202269:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094816.202666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 597
[1:1:0712/094816.202964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7fe532cc8070 0xfd3d5983960 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 562 0x7fe534bf02e0 0xfd3d5e7a460 
[1:1:0712/094816.238721:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76190
[1:1:0712/094816.239051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094816.239446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 601
[1:1:0712/094816.239720:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7fe532cc8070 0xfd3d58cf660 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 562 0x7fe534bf02e0 0xfd3d5e7a460 
[1:1:0712/094816.242858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.540373:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573 0x7fe534bf02e0 0xfd3d547c4e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.541422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094816.541659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.572656:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76190
[1:1:0712/094816.572949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094816.573327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 610
[1:1:0712/094816.573623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7fe532cc8070 0xfd3d5899ae0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 573 0x7fe534bf02e0 0xfd3d547c4e0 
[1:1:0712/094816.578622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.607515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7fe534bf02e0 0xfd3d5b2ffe0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.608784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("share/select_api",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/094816.609050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.635429:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.739955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7fe534bf02e0 0xfd3d5b294e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.741176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("view/select_view",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/094816.741404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.765085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.824796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 578 0x7fe534bf02e0 0xfd3d55965e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.826118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("share/image_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094816.826343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.853387:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.900076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7fe534bf02e0 0xfd3d547a760 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.901221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("view/image_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094816.901445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.917879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094816.953995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7fe534bf02e0 0xfd3d52ae4e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094816.959742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (function(){var h={},mt={},c={id:"06ffa85f4154e2ae01fa772a613d3d58",dm:["zxart.cn"],js:"tongji.baidu
[1:1:0712/094816.960026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094816.993635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76190
[1:1:0712/094816.994006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094816.994422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 623
[1:1:0712/094816.994671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7fe532cc8070 0xfd3d5e7d0e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 581 0x7fe534bf02e0 0xfd3d52ae4e0 
[119008:119008:0712/094829.335348:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/094829.345730:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/094829.433453:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094829.434104:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094829.715068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 594, 7fe53560d8db
[1:1:0712/094829.743215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"554 0x7fe532cc8070 0xfd3d58aee60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094829.743562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"554 0x7fe532cc8070 0xfd3d58aee60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094829.744039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 687
[1:1:0712/094829.744310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7fe532cc8070 0xfd3d5b25de0 , 5:3_http://baqiu.zxart.cn/, 0, , 594 0x7fe532cc8070 0xfd3d53e06e0 
[1:1:0712/094829.744642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094829.745193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094829.745416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094829.945309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 608 0x7fe534bf02e0 0xfd3d547c0e0 , "http://baqiu.zxart.cn/en"
[1:1:0712/094829.946364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0712/094829.946595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094829.963754:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094830.409122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/094830.409412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094831.394227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 623, 7fe53560d881
[1:1:0712/094831.407194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"581 0x7fe534bf02e0 0xfd3d52ae4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.407401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"581 0x7fe534bf02e0 0xfd3d52ae4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.407679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094831.408016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094831.408125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094831.408488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094831.408624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094831.408803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 715
[1:1:0712/094831.408925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7fe532cc8070 0xfd3d547afe0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 623 0x7fe532cc8070 0xfd3d5e7d0e0 
[1:1:0712/094831.409425:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 528, 7fe53560d881
[1:1:0712/094831.420072:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.420261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.420490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094831.420814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){f.next();}
[1:1:0712/094831.420933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094831.474423:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094831.474714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094831.475060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 720
[1:1:0712/094831.475255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7fe532cc8070 0xfd3d5b2f060 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 528 0x7fe532cc8070 0xfd3d58dfb60 
[1:1:0712/094831.550582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094831.551109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 722
[1:1:0712/094831.551359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7fe532cc8070 0xfd3d58c4fe0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 528 0x7fe532cc8070 0xfd3d58dfb60 
[1:1:0712/094831.573590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 545, 7fe53560d881
[1:1:0712/094831.601851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.602053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.602292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094831.602619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/094831.602730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094831.605444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094831.605585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094831.605774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 728
[1:1:0712/094831.605885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7fe532cc8070 0xfd3d50e3a60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 545 0x7fe532cc8070 0xfd3d555a6e0 
[1:1:0712/094831.630459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 525, 7fe53560d8db
[1:1:0712/094831.640447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.640763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.641167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 733
[1:1:0712/094831.641350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7fe532cc8070 0xfd3d54790e0 , 5:3_http://baqiu.zxart.cn/, 0, , 525 0x7fe532cc8070 0xfd3d50e45e0 
[1:1:0712/094831.641623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094831.642147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094831.642317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094831.702319:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 526, 7fe53560d8db
[1:1:0712/094831.712765:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.712960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"504 0x7fe532cc8070 0xfd3d555a4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094831.713175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 735
[1:1:0712/094831.713287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7fe532cc8070 0xfd3d591bf60 , 5:3_http://baqiu.zxart.cn/, 0, , 526 0x7fe532cc8070 0xfd3d587ff60 
[1:1:0712/094831.713430:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094831.713736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094831.713846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094832.024771:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 687, 7fe53560d8db
[1:1:0712/094832.065004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"594 0x7fe532cc8070 0xfd3d53e06e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094832.065360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"594 0x7fe532cc8070 0xfd3d53e06e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094832.065892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 739
[1:1:0712/094832.066146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7fe532cc8070 0xfd3d65465e0 , 5:3_http://baqiu.zxart.cn/, 0, , 687 0x7fe532cc8070 0xfd3d5b25de0 
[1:1:0712/094832.066542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094832.067171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094832.067413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094832.287980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 694 0x7fe534bf02e0 0xfd3d50e4160 , "http://baqiu.zxart.cn/en"
[1:1:0712/094832.288940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0712/094832.289139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094832.298953:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094832.327943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 695 0x7fe534bf02e0 0xfd3d58c4460 , "http://baqiu.zxart.cn/en"
[1:1:0712/094832.330821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0712/094832.331014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
		remove user.11_84707c0f -> 0
		remove user.12_d83549b8 -> 0
[1:1:0712/094833.012529:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76188
[1:1:0712/094833.012764:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094833.013128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 749
[1:1:0712/094833.013326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7fe532cc8070 0xfd3d6546b60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 695 0x7fe534bf02e0 0xfd3d58c4460 
[1:1:0712/094833.054488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76188
[1:1:0712/094833.054663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094833.054847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 752
[1:1:0712/094833.054990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7fe532cc8070 0xfd3d66cd860 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 695 0x7fe534bf02e0 0xfd3d58c4460 
[1:1:0712/094833.055258:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x6eb9c4c29c8, 0xfd3d4d76188
[1:1:0712/094833.055356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 15000
[1:1:0712/094833.055507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 753
[1:1:0712/094833.055616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7fe532cc8070 0xfd3d4fca2e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 695 0x7fe534bf02e0 0xfd3d58c4460 
[1:1:0712/094833.077490:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[119008:119008:0712/094833.080075:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/094833.082346:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xfd3d5d3be20
[1:1:0712/094833.082573:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119008:119008:0712/094833.086787:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[119008:119008:0712/094833.128580:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://baqiu.zxart.cn/, http://baqiu.zxart.cn/, 4
[119008:119008:0712/094833.128752:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://baqiu.zxart.cn/, http://baqiu.zxart.cn
[1:1:0712/094833.702181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094833.765954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , document.readyState
[1:1:0712/094833.766158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.216423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 720, 7fe53560d881
[1:1:0712/094834.255951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"528 0x7fe532cc8070 0xfd3d58dfb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.256374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"528 0x7fe532cc8070 0xfd3d58dfb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.256825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094834.257456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094834.257687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.259888:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 715, 7fe53560d881
[1:1:0712/094834.302699:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"623 0x7fe532cc8070 0xfd3d5e7d0e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.303102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"623 0x7fe532cc8070 0xfd3d5e7d0e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.303559:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094834.304195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094834.304472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.305455:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094834.305669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094834.306090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 812
[1:1:0712/094834.306358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7fe532cc8070 0xfd3d65540e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 715 0x7fe532cc8070 0xfd3d547afe0 
[1:1:0712/094834.308192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 722, 7fe53560d8db
[1:1:0712/094834.335699:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"528 0x7fe532cc8070 0xfd3d58dfb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.335903:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"528 0x7fe532cc8070 0xfd3d58dfb60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.336130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 813
[1:1:0712/094834.336245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 813 0x7fe532cc8070 0xfd3d4fc81e0 , 5:3_http://baqiu.zxart.cn/, 0, , 722 0x7fe532cc8070 0xfd3d58c4fe0 
[1:1:0712/094834.336466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094834.336750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094834.336856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.360400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094834.360661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094834.361069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 815
[1:1:0712/094834.361334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7fe532cc8070 0xfd3d54bac60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 722 0x7fe532cc8070 0xfd3d58c4fe0 
[1:1:0712/094834.715373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 739, 7fe53560d8db
[1:1:0712/094834.748674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7fe532cc8070 0xfd3d5b25de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.748961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7fe532cc8070 0xfd3d5b25de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094834.749389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 825
[1:1:0712/094834.749587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 825 0x7fe532cc8070 0xfd3d58c9f60 , 5:3_http://baqiu.zxart.cn/, 0, , 739 0x7fe532cc8070 0xfd3d65465e0 
[1:1:0712/094834.749883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094834.750380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094834.750559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.869836:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7fe534bf02e0 0xfd3d6554260 , "http://baqiu.zxart.cn/en"
[1:1:0712/094834.870793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0712/094834.870976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094834.921048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 1000
[1:1:0712/094834.921457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 828
[1:1:0712/094834.921649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7fe532cc8070 0xfd3d69fb4e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 744 0x7fe534bf02e0 0xfd3d6554260 
[1:1:0712/094834.948165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094835.469937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 752, 7fe53560d881
[1:1:0712/094835.480512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"695 0x7fe534bf02e0 0xfd3d58c4460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094835.480691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"695 0x7fe534bf02e0 0xfd3d58c4460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094835.480906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094835.481224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){l(e,t)}
[1:1:0712/094835.481359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094835.482772:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094835.482887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 1
[1:1:0712/094835.483058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 846
[1:1:0712/094835.483171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7fe532cc8070 0xfd3d55941e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 752 0x7fe532cc8070 0xfd3d66cd860 
[1:1:0712/094835.602710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , document.readyState
[1:1:0712/094835.602969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.520226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094836.520917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/094836.521106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.610201:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 812, 7fe53560d881
[1:1:0712/094836.650678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"715 0x7fe532cc8070 0xfd3d547afe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.651101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"715 0x7fe532cc8070 0xfd3d547afe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.651591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094836.652316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094836.652565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.653382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094836.653592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094836.654018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 868
[1:1:0712/094836.654267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7fe532cc8070 0xfd3d6ed3660 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 812 0x7fe532cc8070 0xfd3d65540e0 
[1:1:0712/094836.656118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 733, 7fe53560d8db
[1:1:0712/094836.672366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"525 0x7fe532cc8070 0xfd3d50e45e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.672615:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"525 0x7fe532cc8070 0xfd3d50e45e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.672959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 870
[1:1:0712/094836.673131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7fe532cc8070 0xfd3d6ad2ae0 , 5:3_http://baqiu.zxart.cn/, 0, , 733 0x7fe532cc8070 0xfd3d54790e0 
[1:1:0712/094836.673336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094836.673793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094836.674028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.697513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094836.697742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094836.698020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 873
[1:1:0712/094836.698191:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7fe532cc8070 0xfd3d6ee48e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 733 0x7fe532cc8070 0xfd3d54790e0 
[1:1:0712/094836.708737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094836.709053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 876
[1:1:0712/094836.709230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 876 0x7fe532cc8070 0xfd3d6b93e60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 733 0x7fe532cc8070 0xfd3d54790e0 
[1:1:0712/094836.758471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7fe534bf02e0 0xfd3d4fc8e60 , "http://baqiu.zxart.cn/en"
[1:1:0712/094836.759232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0712/094836.759360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.768675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094836.783403:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 735, 7fe53560d8db
[1:1:0712/094836.794226:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"526 0x7fe532cc8070 0xfd3d587ff60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.794391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"526 0x7fe532cc8070 0xfd3d587ff60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.794602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 882
[1:1:0712/094836.794712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7fe532cc8070 0xfd3d5c3ac60 , 5:3_http://baqiu.zxart.cn/, 0, , 735 0x7fe532cc8070 0xfd3d591bf60 
[1:1:0712/094836.794851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094836.795224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094836.795334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094836.812602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 825, 7fe53560d8db
[1:1:0712/094836.826080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"739 0x7fe532cc8070 0xfd3d65465e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.826344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"739 0x7fe532cc8070 0xfd3d65465e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094836.826695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 883
[1:1:0712/094836.826865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7fe532cc8070 0xfd3d4fca660 , 5:3_http://baqiu.zxart.cn/, 0, , 825 0x7fe532cc8070 0xfd3d58c9f60 
[1:1:0712/094836.827113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094836.827503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094836.827652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.211008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 846, 7fe53560d881
[1:1:0712/094837.247870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"752 0x7fe532cc8070 0xfd3d66cd860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.248233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"752 0x7fe532cc8070 0xfd3d66cd860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.248613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094837.249132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){n?t&&t():l(e,t)}
[1:1:0712/094837.249312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.291711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , document.readyState
[1:1:0712/094837.291968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.401290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 828, 7fe53560d8db
[1:1:0712/094837.413623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"744 0x7fe534bf02e0 0xfd3d6554260 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.413826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"744 0x7fe534bf02e0 0xfd3d6554260 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.414072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 900
[1:1:0712/094837.414202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7fe532cc8070 0xfd3d6f1a860 , 5:3_http://baqiu.zxart.cn/, 0, , 828 0x7fe532cc8070 0xfd3d69fb4e0 
[1:1:0712/094837.414351:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094837.414627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094837.414735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.896921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 873, 7fe53560d881
[1:1:0712/094837.919140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.919366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.919616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094837.919950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094837.920088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.934810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 876, 7fe53560d8db
[1:1:0712/094837.946822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.947007:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.947236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 911
[1:1:0712/094837.947359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7fe532cc8070 0xfd3d6ec6fe0 , 5:3_http://baqiu.zxart.cn/, 0, , 876 0x7fe532cc8070 0xfd3d6b93e60 
[1:1:0712/094837.947514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094837.947839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094837.947949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094837.960652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 868, 7fe53560d881
[1:1:0712/094837.998800:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"812 0x7fe532cc8070 0xfd3d65540e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.999114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"812 0x7fe532cc8070 0xfd3d65540e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094837.999530:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094838.000109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094838.000341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.000966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094838.001125:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094838.001484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 913
[1:1:0712/094838.001672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7fe532cc8070 0xfd3d6ad7060 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 868 0x7fe532cc8070 0xfd3d6ed3660 
[1:1:0712/094838.041813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 883, 7fe53560d8db
[1:1:0712/094838.079241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"825 0x7fe532cc8070 0xfd3d58c9f60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.079523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"825 0x7fe532cc8070 0xfd3d58c9f60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.079929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 914
[1:1:0712/094838.080127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7fe532cc8070 0xfd3d5badfe0 , 5:3_http://baqiu.zxart.cn/, 0, , 883 0x7fe532cc8070 0xfd3d4fca660 
[1:1:0712/094838.080434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094838.080927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094838.081165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.168496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baqiu.zxart.cn/en"
[1:1:0712/094838.169180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/094838.169404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.248344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://baqiu.zxart.cn/en"
[1:1:0712/094838.249021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/094838.249215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.252626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094838.253520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://baqiu.zxart.cn/en"
[1:1:0712/094838.295146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://baqiu.zxart.cn/en"
[1:1:0712/094838.296641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d762f0
[1:1:0712/094838.296823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094838.297143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 918
[1:1:0712/094838.297357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7fe532cc8070 0xfd3d5c3ae60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 892 0x7fe532cc8070 0xfd3d6eca2e0 
[1:1:0712/094838.438344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , document.readyState
[1:1:0712/094838.438601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.441854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 815, 7fe53560d881
[1:1:0712/094838.479408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"722 0x7fe532cc8070 0xfd3d58c4fe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.479706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"722 0x7fe532cc8070 0xfd3d58c4fe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.480042:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094838.480545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){f.next();}
[1:1:0712/094838.480725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094838.537464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094838.537651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094838.537978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 925
[1:1:0712/094838.538166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7fe532cc8070 0xfd3d66cd5e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 815 0x7fe532cc8070 0xfd3d54bac60 
[1:1:0712/094838.591824:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094838.592207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 926
[1:1:0712/094838.592446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7fe532cc8070 0xfd3d6fdd9e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 815 0x7fe532cc8070 0xfd3d54bac60 
[1:1:0712/094838.909836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 900, 7fe53560d8db
[1:1:0712/094838.949312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"828 0x7fe532cc8070 0xfd3d69fb4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.949613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"828 0x7fe532cc8070 0xfd3d69fb4e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094838.950010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 933
[1:1:0712/094838.950205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7fe532cc8070 0xfd3d6ed3960 , 5:3_http://baqiu.zxart.cn/, 0, , 900 0x7fe532cc8070 0xfd3d6f1a860 
[1:1:0712/094838.950502:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094838.951112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094838.951330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.085883:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 914, 7fe53560d8db
[1:1:0712/094839.113040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"883 0x7fe532cc8070 0xfd3d4fca660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.113349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"883 0x7fe532cc8070 0xfd3d4fca660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.113871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 937
[1:1:0712/094839.114130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7fe532cc8070 0xfd3d7027460 , 5:3_http://baqiu.zxart.cn/, 0, , 914 0x7fe532cc8070 0xfd3d5badfe0 
[1:1:0712/094839.114489:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.115075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094839.115290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.203178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 918, 7fe53560d881
[1:1:0712/094839.240808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"892 0x7fe532cc8070 0xfd3d6eca2e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.241138:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"892 0x7fe532cc8070 0xfd3d6eca2e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.241526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.242093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094839.242312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.242994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094839.243193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094839.243582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 942
[1:1:0712/094839.243813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7fe532cc8070 0xfd3d5c3a1e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 918 0x7fe532cc8070 0xfd3d5c3ae60 
[1:1:0712/094839.245219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 925, 7fe53560d881
[1:1:0712/094839.282958:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"815 0x7fe532cc8070 0xfd3d54bac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.283308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"815 0x7fe532cc8070 0xfd3d54bac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.283741:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.284253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094839.284467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.363161:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 926, 7fe53560d8db
[1:1:0712/094839.401124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"815 0x7fe532cc8070 0xfd3d54bac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.401458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"815 0x7fe532cc8070 0xfd3d54bac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.401917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 945
[1:1:0712/094839.402149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7fe532cc8070 0xfd3d58a9860 , 5:3_http://baqiu.zxart.cn/, 0, , 926 0x7fe532cc8070 0xfd3d6fdd9e0 
[1:1:0712/094839.402466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.403000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094839.403215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.423091:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094839.423311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094839.423741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 946
[1:1:0712/094839.423971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7fe532cc8070 0xfd3d6b268e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 926 0x7fe532cc8070 0xfd3d6fdd9e0 
[1:1:0712/094839.521189:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 937, 7fe53560d8db
[1:1:0712/094839.534117:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"914 0x7fe532cc8070 0xfd3d5badfe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.534399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"914 0x7fe532cc8070 0xfd3d5badfe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.534816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 951
[1:1:0712/094839.535047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7fe532cc8070 0xfd3d65510e0 , 5:3_http://baqiu.zxart.cn/, 0, , 937 0x7fe532cc8070 0xfd3d7027460 
[1:1:0712/094839.535357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.535925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094839.536141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.669236:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 942, 7fe53560d881
[1:1:0712/094839.707577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"918 0x7fe532cc8070 0xfd3d5c3ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.707956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"918 0x7fe532cc8070 0xfd3d5c3ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.708346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.708977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094839.709212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.709894:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094839.710112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094839.710469:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 954
[1:1:0712/094839.710715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7fe532cc8070 0xfd3d70466e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 942 0x7fe532cc8070 0xfd3d5c3a1e0 
[1:1:0712/094839.712149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 870, 7fe53560d8db
[1:1:0712/094839.757084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.757380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7fe532cc8070 0xfd3d54790e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.757810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 955
[1:1:0712/094839.758048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 955 0x7fe532cc8070 0xfd3d55962e0 , 5:3_http://baqiu.zxart.cn/, 0, , 870 0x7fe532cc8070 0xfd3d6ad2ae0 
[1:1:0712/094839.758323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.758854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094839.759082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.795460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094839.795683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094839.796053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 956
[1:1:0712/094839.796281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7fe532cc8070 0xfd3d6b265e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 870 0x7fe532cc8070 0xfd3d6ad2ae0 
[1:1:0712/094839.809533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094839.809942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 957
[1:1:0712/094839.810183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7fe532cc8070 0xfd3d7039ae0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 870 0x7fe532cc8070 0xfd3d6ad2ae0 
[1:1:0712/094839.827334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 882, 7fe53560d8db
[1:1:0712/094839.868371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"735 0x7fe532cc8070 0xfd3d591bf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.868699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"735 0x7fe532cc8070 0xfd3d591bf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.869117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 962
[1:1:0712/094839.869347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7fe532cc8070 0xfd3d7027460 , 5:3_http://baqiu.zxart.cn/, 0, , 882 0x7fe532cc8070 0xfd3d5c3ac60 
[1:1:0712/094839.869652:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.870173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094839.870388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.909286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 951, 7fe53560d8db
[1:1:0712/094839.953917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"937 0x7fe532cc8070 0xfd3d7027460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.954258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"937 0x7fe532cc8070 0xfd3d7027460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094839.954694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 964
[1:1:0712/094839.954921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 964 0x7fe532cc8070 0xfd3d5e9bf60 , 5:3_http://baqiu.zxart.cn/, 0, , 951 0x7fe532cc8070 0xfd3d65510e0 
[1:1:0712/094839.955198:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094839.955759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094839.955971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094839.964565:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 956, 7fe53560d881
[1:1:0712/094840.001679:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.001993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.002361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.002859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094840.003066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.004575:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 954, 7fe53560d881
[1:1:0712/094840.043174:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"942 0x7fe532cc8070 0xfd3d5c3a1e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.043496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"942 0x7fe532cc8070 0xfd3d5c3a1e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.043931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.044429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094840.044645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.045307:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094840.045503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094840.045901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 968
[1:1:0712/094840.046134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 968 0x7fe532cc8070 0xfd3d7046c60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 954 0x7fe532cc8070 0xfd3d70466e0 
[1:1:0712/094840.047578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 957, 7fe53560d8db
[1:1:0712/094840.086020:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.086333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.086754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 969
[1:1:0712/094840.086985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7fe532cc8070 0xfd3d6b262e0 , 5:3_http://baqiu.zxart.cn/, 0, , 957 0x7fe532cc8070 0xfd3d7039ae0 
[1:1:0712/094840.087288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.087832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.088082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.131738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 933, 7fe53560d8db
[1:1:0712/094840.170265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"900 0x7fe532cc8070 0xfd3d6f1a860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.170516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"900 0x7fe532cc8070 0xfd3d6f1a860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.170920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 971
[1:1:0712/094840.171116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7fe532cc8070 0xfd3d697aae0 , 5:3_http://baqiu.zxart.cn/, 0, , 933 0x7fe532cc8070 0xfd3d6ed3960 
[1:1:0712/094840.171370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.171884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094840.172065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.173673:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 964, 7fe53560d8db
[1:1:0712/094840.212200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"951 0x7fe532cc8070 0xfd3d65510e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.212434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"951 0x7fe532cc8070 0xfd3d65510e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.212811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 973
[1:1:0712/094840.213005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7fe532cc8070 0xfd3d6ad76e0 , 5:3_http://baqiu.zxart.cn/, 0, , 964 0x7fe532cc8070 0xfd3d5e9bf60 
[1:1:0712/094840.213253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.213697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.213894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.224284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 969, 7fe53560d8db
[1:1:0712/094840.262997:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"957 0x7fe532cc8070 0xfd3d7039ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.263242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"957 0x7fe532cc8070 0xfd3d7039ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.263602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 976
[1:1:0712/094840.263836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 976 0x7fe532cc8070 0xfd3d7027ee0 , 5:3_http://baqiu.zxart.cn/, 0, , 969 0x7fe532cc8070 0xfd3d6b262e0 
[1:1:0712/094840.264120:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.264582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.264780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.268660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 968, 7fe53560d881
[1:1:0712/094840.307348:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"954 0x7fe532cc8070 0xfd3d70466e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.307625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"954 0x7fe532cc8070 0xfd3d70466e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.308001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.308470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094840.308644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.309277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094840.309437:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094840.309780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 978
[1:1:0712/094840.309973:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7fe532cc8070 0xfd3d66cd860 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 968 0x7fe532cc8070 0xfd3d7046c60 
[1:1:0712/094840.400660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 973, 7fe53560d8db
[1:1:0712/094840.443266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"964 0x7fe532cc8070 0xfd3d5e9bf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.443592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"964 0x7fe532cc8070 0xfd3d5e9bf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.444102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 980
[1:1:0712/094840.444356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 980 0x7fe532cc8070 0xfd3d69fbde0 , 5:3_http://baqiu.zxart.cn/, 0, , 973 0x7fe532cc8070 0xfd3d6ad76e0 
[1:1:0712/094840.444660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.445266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.445504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.458905:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 976, 7fe53560d8db
[1:1:0712/094840.500366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"969 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.500619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"969 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.501008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 984
[1:1:0712/094840.501202:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7fe532cc8070 0xfd3d70391e0 , 5:3_http://baqiu.zxart.cn/, 0, , 976 0x7fe532cc8070 0xfd3d7027ee0 
[1:1:0712/094840.501483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.502020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.502200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.506066:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 978, 7fe53560d881
[1:1:0712/094840.541023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"968 0x7fe532cc8070 0xfd3d7046c60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.541183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"968 0x7fe532cc8070 0xfd3d7046c60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.541358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.541608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094840.541712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.542038:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094840.542141:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094840.542306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 985
[1:1:0712/094840.542416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7fe532cc8070 0xfd3d6ee1360 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 978 0x7fe532cc8070 0xfd3d66cd860 
[1:1:0712/094840.554762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 980, 7fe53560d8db
[1:1:0712/094840.566170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"973 0x7fe532cc8070 0xfd3d6ad76e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.566298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"973 0x7fe532cc8070 0xfd3d6ad76e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.566476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 987
[1:1:0712/094840.566584:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7fe532cc8070 0xfd3d6eb88e0 , 5:3_http://baqiu.zxart.cn/, 0, , 980 0x7fe532cc8070 0xfd3d69fbde0 
[1:1:0712/094840.566718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.566996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.567110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.570177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 984, 7fe53560d8db
[1:1:0712/094840.582219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"976 0x7fe532cc8070 0xfd3d7027ee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.582355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"976 0x7fe532cc8070 0xfd3d7027ee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.582541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 988
[1:1:0712/094840.582649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7fe532cc8070 0xfd3d70d6e60 , 5:3_http://baqiu.zxart.cn/, 0, , 984 0x7fe532cc8070 0xfd3d70391e0 
[1:1:0712/094840.582780:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.583071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.583176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.584659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 987, 7fe53560d8db
[1:1:0712/094840.596354:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"980 0x7fe532cc8070 0xfd3d69fbde0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.596481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"980 0x7fe532cc8070 0xfd3d69fbde0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.596661:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 990
[1:1:0712/094840.596769:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7fe532cc8070 0xfd3d5b2f060 , 5:3_http://baqiu.zxart.cn/, 0, , 987 0x7fe532cc8070 0xfd3d6eb88e0 
[1:1:0712/094840.596955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.597213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.597321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.600136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 988, 7fe53560d8db
[1:1:0712/094840.611975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"984 0x7fe532cc8070 0xfd3d70391e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.612101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"984 0x7fe532cc8070 0xfd3d70391e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.612295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 992
[1:1:0712/094840.612402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7fe532cc8070 0xfd3d6ee44e0 , 5:3_http://baqiu.zxart.cn/, 0, , 988 0x7fe532cc8070 0xfd3d70d6e60 
[1:1:0712/094840.612526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.612749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.612877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.634976:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 990, 7fe53560d8db
[1:1:0712/094840.662277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"987 0x7fe532cc8070 0xfd3d6eb88e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.662419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"987 0x7fe532cc8070 0xfd3d6eb88e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.662605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 995
[1:1:0712/094840.662716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7fe532cc8070 0xfd3d70359e0 , 5:3_http://baqiu.zxart.cn/, 0, , 990 0x7fe532cc8070 0xfd3d5b2f060 
[1:1:0712/094840.662864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.663119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.663227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.666058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 992, 7fe53560d8db
[1:1:0712/094840.690532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"988 0x7fe532cc8070 0xfd3d70d6e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.690790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"988 0x7fe532cc8070 0xfd3d70d6e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.691181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 997
[1:1:0712/094840.691372:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 997 0x7fe532cc8070 0xfd3d7037b60 , 5:3_http://baqiu.zxart.cn/, 0, , 992 0x7fe532cc8070 0xfd3d6ee44e0 
[1:1:0712/094840.691608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.692102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.692287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.696176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 985, 7fe53560d881
[1:1:0712/094840.735536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"978 0x7fe532cc8070 0xfd3d66cd860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.735802:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"978 0x7fe532cc8070 0xfd3d66cd860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.736182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.736644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094840.736819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.737451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094840.737609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094840.737947:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1000
[1:1:0712/094840.738140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7fe532cc8070 0xfd3d7035160 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 985 0x7fe532cc8070 0xfd3d6ee1360 
[1:1:0712/094840.739519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 995, 7fe53560d8db
[1:1:0712/094840.778749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"990 0x7fe532cc8070 0xfd3d5b2f060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.779006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"990 0x7fe532cc8070 0xfd3d5b2f060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.779368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1001
[1:1:0712/094840.779556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7fe532cc8070 0xfd3d6af7de0 , 5:3_http://baqiu.zxart.cn/, 0, , 995 0x7fe532cc8070 0xfd3d70359e0 
[1:1:0712/094840.779932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.780383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.780559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.831025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 997, 7fe53560d8db
[1:1:0712/094840.870366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"992 0x7fe532cc8070 0xfd3d6ee44e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.870629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"992 0x7fe532cc8070 0xfd3d6ee44e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.871027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1004
[1:1:0712/094840.871223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1004 0x7fe532cc8070 0xfd3d6ecc3e0 , 5:3_http://baqiu.zxart.cn/, 0, , 997 0x7fe532cc8070 0xfd3d7037b60 
[1:1:0712/094840.871527:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.872048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094840.872229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.883137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1001, 7fe53560d8db
[1:1:0712/094840.923080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"995 0x7fe532cc8070 0xfd3d70359e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.923323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"995 0x7fe532cc8070 0xfd3d70359e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.923686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1007
[1:1:0712/094840.923872:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7fe532cc8070 0xfd3d6fddce0 , 5:3_http://baqiu.zxart.cn/, 0, , 1001 0x7fe532cc8070 0xfd3d6af7de0 
[1:1:0712/094840.924230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.924672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094840.924846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.935261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1000, 7fe53560d881
[1:1:0712/094840.975235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"985 0x7fe532cc8070 0xfd3d6ee1360 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.975514:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"985 0x7fe532cc8070 0xfd3d6ee1360 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094840.975837:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094840.976418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094840.976595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094840.977232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094840.977396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094840.977713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1010
[1:1:0712/094840.977918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7fe532cc8070 0xfd3d7027660 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1000 0x7fe532cc8070 0xfd3d7035160 
[1:1:0712/094840.979356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 971, 7fe53560d8db
[1:1:0712/094841.019056:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"933 0x7fe532cc8070 0xfd3d6ed3960 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.019295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"933 0x7fe532cc8070 0xfd3d6ed3960 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.019654:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1012
[1:1:0712/094841.019841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7fe532cc8070 0xfd3d5e81660 , 5:3_http://baqiu.zxart.cn/, 0, , 971 0x7fe532cc8070 0xfd3d697aae0 
[1:1:0712/094841.020181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.020624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094841.020797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.062712:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1007, 7fe53560d8db
[1:1:0712/094841.102704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1001 0x7fe532cc8070 0xfd3d6af7de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.102969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1001 0x7fe532cc8070 0xfd3d6af7de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.103343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1013
[1:1:0712/094841.103544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7fe532cc8070 0xfd3d7040460 , 5:3_http://baqiu.zxart.cn/, 0, , 1007 0x7fe532cc8070 0xfd3d6fddce0 
[1:1:0712/094841.103850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.104373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.104551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.106419:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1010, 7fe53560d881
[1:1:0712/094841.146204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1000 0x7fe532cc8070 0xfd3d7035160 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.146469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1000 0x7fe532cc8070 0xfd3d7035160 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.146786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.147269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094841.147445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.148119:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094841.148296:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094841.148749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1015
[1:1:0712/094841.148936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7fe532cc8070 0xfd3d50e3e60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1010 0x7fe532cc8070 0xfd3d7027660 
[1:1:0712/094841.150408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1013, 7fe53560d8db
[1:1:0712/094841.190276:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1007 0x7fe532cc8070 0xfd3d6fddce0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.190524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1007 0x7fe532cc8070 0xfd3d6fddce0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.190887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1017
[1:1:0712/094841.191095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7fe532cc8070 0xfd3d6eb8be0 , 5:3_http://baqiu.zxart.cn/, 0, , 1013 0x7fe532cc8070 0xfd3d7040460 
[1:1:0712/094841.191432:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.191886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.192114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.236599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1017, 7fe53560d8db
[1:1:0712/094841.276459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1013 0x7fe532cc8070 0xfd3d7040460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.276706:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1013 0x7fe532cc8070 0xfd3d7040460 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.277084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1019
[1:1:0712/094841.277289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1019 0x7fe532cc8070 0xfd3d7040660 , 5:3_http://baqiu.zxart.cn/, 0, , 1017 0x7fe532cc8070 0xfd3d6eb8be0 
[1:1:0712/094841.277589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.278068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.278247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.280061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1015, 7fe53560d881
[1:1:0712/094841.322524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1010 0x7fe532cc8070 0xfd3d7027660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.322803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1010 0x7fe532cc8070 0xfd3d7027660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.323162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.323646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094841.323821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.324500:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094841.324660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094841.324978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1021
[1:1:0712/094841.325204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7fe532cc8070 0xfd3d6adb3e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1015 0x7fe532cc8070 0xfd3d50e3e60 
[1:1:0712/094841.326708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1019, 7fe53560d8db
[1:1:0712/094841.367501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1017 0x7fe532cc8070 0xfd3d6eb8be0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.367776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1017 0x7fe532cc8070 0xfd3d6eb8be0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.368233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1023
[1:1:0712/094841.368429:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7fe532cc8070 0xfd3d5e9b660 , 5:3_http://baqiu.zxart.cn/, 0, , 1019 0x7fe532cc8070 0xfd3d7040660 
[1:1:0712/094841.368768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.369274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.369461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.417058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1023, 7fe53560d8db
[1:1:0712/094841.456944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1019 0x7fe532cc8070 0xfd3d7040660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.457229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1019 0x7fe532cc8070 0xfd3d7040660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.457601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1026
[1:1:0712/094841.457790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7fe532cc8070 0xfd3d70409e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1023 0x7fe532cc8070 0xfd3d5e9b660 
[1:1:0712/094841.458123:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.458599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.458774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.502009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1021, 7fe53560d881
[1:1:0712/094841.542321:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1015 0x7fe532cc8070 0xfd3d50e3e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.542608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1015 0x7fe532cc8070 0xfd3d50e3e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.542937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.543528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094841.543717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.544375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094841.544540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094841.544865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1029
[1:1:0712/094841.545074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7fe532cc8070 0xfd3d6d142e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1021 0x7fe532cc8070 0xfd3d6adb3e0 
[1:1:0712/094841.546423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1026, 7fe53560d8db
[1:1:0712/094841.587554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1023 0x7fe532cc8070 0xfd3d5e9b660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.587889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1023 0x7fe532cc8070 0xfd3d5e9b660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.588337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1030
[1:1:0712/094841.588552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7fe532cc8070 0xfd3d6ad8b60 , 5:3_http://baqiu.zxart.cn/, 0, , 1026 0x7fe532cc8070 0xfd3d70409e0 
[1:1:0712/094841.589617:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.590158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.590314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.604960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1030, 7fe53560d8db
[1:1:0712/094841.625610:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1026 0x7fe532cc8070 0xfd3d70409e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.625838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1026 0x7fe532cc8070 0xfd3d70409e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.626211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1032
[1:1:0712/094841.626405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1032 0x7fe532cc8070 0xfd3d58b55e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1030 0x7fe532cc8070 0xfd3d6ad8b60 
[1:1:0712/094841.626733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.627208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.627385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.651870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1032, 7fe53560d8db
[1:1:0712/094841.663650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1030 0x7fe532cc8070 0xfd3d6ad8b60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.663792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1030 0x7fe532cc8070 0xfd3d6ad8b60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.663981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1035
[1:1:0712/094841.664129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7fe532cc8070 0xfd3d6fe1060 , 5:3_http://baqiu.zxart.cn/, 0, , 1032 0x7fe532cc8070 0xfd3d58b55e0 
[1:1:0712/094841.664333:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.664595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.664699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.665350:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1029, 7fe53560d881
[1:1:0712/094841.677466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1021 0x7fe532cc8070 0xfd3d6adb3e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.677613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1021 0x7fe532cc8070 0xfd3d6adb3e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.677786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.678035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094841.678167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.678466:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094841.678567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094841.678734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1036
[1:1:0712/094841.678842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7fe532cc8070 0xfd3d70405e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1029 0x7fe532cc8070 0xfd3d6d142e0 
[1:1:0712/094841.679348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1035, 7fe53560d8db
[1:1:0712/094841.691408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1032 0x7fe532cc8070 0xfd3d58b55e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.691539:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1032 0x7fe532cc8070 0xfd3d58b55e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.691759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1038
[1:1:0712/094841.691878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1038 0x7fe532cc8070 0xfd3d70277e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1035 0x7fe532cc8070 0xfd3d6fe1060 
[1:1:0712/094841.692049:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.692295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.692400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.730581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1038, 7fe53560d8db
[1:1:0712/094841.767795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1035 0x7fe532cc8070 0xfd3d6fe1060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.767958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1035 0x7fe532cc8070 0xfd3d6fe1060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.768210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1040
[1:1:0712/094841.768332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7fe532cc8070 0xfd3d70278e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1038 0x7fe532cc8070 0xfd3d70277e0 
[1:1:0712/094841.768522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.768792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.768897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.800567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1040, 7fe53560d8db
[1:1:0712/094841.812388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1038 0x7fe532cc8070 0xfd3d70277e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.812524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1038 0x7fe532cc8070 0xfd3d70277e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.812709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1043
[1:1:0712/094841.812817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1043 0x7fe532cc8070 0xfd3d70d6ee0 , 5:3_http://baqiu.zxart.cn/, 0, , 1040 0x7fe532cc8070 0xfd3d70278e0 
[1:1:0712/094841.812996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.813264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.813384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.814002:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1036, 7fe53560d881
[1:1:0712/094841.825857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1029 0x7fe532cc8070 0xfd3d6d142e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.825991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1029 0x7fe532cc8070 0xfd3d6d142e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.826180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.826514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094841.826670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.827102:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094841.827260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094841.827489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1044
[1:1:0712/094841.827641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7fe532cc8070 0xfd3d70462e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1036 0x7fe532cc8070 0xfd3d70405e0 
[1:1:0712/094841.828403:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1043, 7fe53560d8db
[1:1:0712/094841.843278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1040 0x7fe532cc8070 0xfd3d70278e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.843416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1040 0x7fe532cc8070 0xfd3d70278e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.843599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1046
[1:1:0712/094841.843706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7fe532cc8070 0xfd3d7037b60 , 5:3_http://baqiu.zxart.cn/, 0, , 1043 0x7fe532cc8070 0xfd3d70d6ee0 
[1:1:0712/094841.843879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.844106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.844286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.881876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1046, 7fe53560d8db
[1:1:0712/094841.903693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1043 0x7fe532cc8070 0xfd3d70d6ee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.903927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1043 0x7fe532cc8070 0xfd3d70d6ee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094841.904308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1048
[1:1:0712/094841.904494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7fe532cc8070 0xfd3d70d6860 , 5:3_http://baqiu.zxart.cn/, 0, , 1046 0x7fe532cc8070 0xfd3d7037b60 
[1:1:0712/094841.904811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094841.905297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094841.905479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094841.958185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1048, 7fe53560d8db
[1:1:0712/094842.001988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1046 0x7fe532cc8070 0xfd3d7037b60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.002276:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1046 0x7fe532cc8070 0xfd3d7037b60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.002656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1052
[1:1:0712/094842.002847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7fe532cc8070 0xfd3d6fe1de0 , 5:3_http://baqiu.zxart.cn/, 0, , 1048 0x7fe532cc8070 0xfd3d70d6860 
[1:1:0712/094842.003208:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.003697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.003873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.005598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1012, 7fe53560d8db
[1:1:0712/094842.046489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"971 0x7fe532cc8070 0xfd3d697aae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.046734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"971 0x7fe532cc8070 0xfd3d697aae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.047097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1053
[1:1:0712/094842.047304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1053 0x7fe532cc8070 0xfd3d6fdd7e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1012 0x7fe532cc8070 0xfd3d5e81660 
[1:1:0712/094842.047610:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.048060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094842.048301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.049792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1044, 7fe53560d881
[1:1:0712/094842.090613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1036 0x7fe532cc8070 0xfd3d70405e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.090884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1036 0x7fe532cc8070 0xfd3d70405e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.091222:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.091772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094842.091946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.092652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094842.092815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094842.093137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1055
[1:1:0712/094842.093347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1055 0x7fe532cc8070 0xfd3d5e7b560 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1044 0x7fe532cc8070 0xfd3d70462e0 
[1:1:0712/094842.094703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1052, 7fe53560d8db
[1:1:0712/094842.135528:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1048 0x7fe532cc8070 0xfd3d70d6860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.135766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1048 0x7fe532cc8070 0xfd3d70d6860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.136130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1056
[1:1:0712/094842.136360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7fe532cc8070 0xfd3d6b260e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1052 0x7fe532cc8070 0xfd3d6fe1de0 
[1:1:0712/094842.136691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.137133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.137332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.195870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1056, 7fe53560d8db
[1:1:0712/094842.215514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1052 0x7fe532cc8070 0xfd3d6fe1de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.215659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1052 0x7fe532cc8070 0xfd3d6fe1de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.215846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1059
[1:1:0712/094842.215952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7fe532cc8070 0xfd3d65330e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1056 0x7fe532cc8070 0xfd3d6b260e0 
[1:1:0712/094842.216133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.216440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.216555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.217177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1055, 7fe53560d881
[1:1:0712/094842.228886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1044 0x7fe532cc8070 0xfd3d70462e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.229023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1044 0x7fe532cc8070 0xfd3d70462e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.229183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.229434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094842.229537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.229813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094842.229907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094842.230060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1060
[1:1:0712/094842.230164:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7fe532cc8070 0xfd3d599c760 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1055 0x7fe532cc8070 0xfd3d5e7b560 
[1:1:0712/094842.274721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1059, 7fe53560d8db
[1:1:0712/094842.313959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1056 0x7fe532cc8070 0xfd3d6b260e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.314256:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1056 0x7fe532cc8070 0xfd3d6b260e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.314640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1062
[1:1:0712/094842.314837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7fe532cc8070 0xfd3d58bf5e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1059 0x7fe532cc8070 0xfd3d65330e0 
[1:1:0712/094842.315168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.315652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.315821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.317549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1062, 7fe53560d8db
[1:1:0712/094842.356867:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1059 0x7fe532cc8070 0xfd3d65330e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.357089:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1059 0x7fe532cc8070 0xfd3d65330e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.357543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1064
[1:1:0712/094842.357812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1064 0x7fe532cc8070 0xfd3d5c3a9e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1062 0x7fe532cc8070 0xfd3d58bf5e0 
[1:1:0712/094842.358203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.358792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.359020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.361270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1060, 7fe53560d881
[1:1:0712/094842.413830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1055 0x7fe532cc8070 0xfd3d5e7b560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.414183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1055 0x7fe532cc8070 0xfd3d5e7b560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.414619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.415221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094842.415468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.416254:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094842.416505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094842.416917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1066
[1:1:0712/094842.417172:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1066 0x7fe532cc8070 0xfd3d6b265e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1060 0x7fe532cc8070 0xfd3d599c760 
[1:1:0712/094842.419299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1064, 7fe53560d8db
[1:1:0712/094842.470962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1062 0x7fe532cc8070 0xfd3d58bf5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.471274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1062 0x7fe532cc8070 0xfd3d58bf5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.471759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1069
[1:1:0712/094842.472014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1069 0x7fe532cc8070 0xfd3d5c3ae60 , 5:3_http://baqiu.zxart.cn/, 0, , 1064 0x7fe532cc8070 0xfd3d5c3a9e0 
[1:1:0712/094842.472442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.473019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.473245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.529116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 946, 7fe53560d881
[1:1:0712/094842.570353:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"926 0x7fe532cc8070 0xfd3d6fdd9e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.570628:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"926 0x7fe532cc8070 0xfd3d6fdd9e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.570950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.571495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){f.next();}
[1:1:0712/094842.571672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.627148:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094842.627393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094842.627745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1074
[1:1:0712/094842.627934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7fe532cc8070 0xfd3d6b93e60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 946 0x7fe532cc8070 0xfd3d6b268e0 
[1:1:0712/094842.681409:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094842.681825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1075
[1:1:0712/094842.682038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7fe532cc8070 0xfd3d6ad26e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 946 0x7fe532cc8070 0xfd3d6b268e0 
[1:1:0712/094842.699120:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1069, 7fe53560d8db
[1:1:0712/094842.742001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1064 0x7fe532cc8070 0xfd3d5c3a9e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.742257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1064 0x7fe532cc8070 0xfd3d5c3a9e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.742651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1079
[1:1:0712/094842.742857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7fe532cc8070 0xfd3d6ad0860 , 5:3_http://baqiu.zxart.cn/, 0, , 1069 0x7fe532cc8070 0xfd3d5c3ae60 
[1:1:0712/094842.743193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.743678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.743856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.757030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1066, 7fe53560d881
[1:1:0712/094842.799744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1060 0x7fe532cc8070 0xfd3d599c760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.800051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1060 0x7fe532cc8070 0xfd3d599c760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.800429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.800941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094842.801119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.801762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094842.801923:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094842.802247:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1083
[1:1:0712/094842.802453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fe532cc8070 0xfd3d70d9ae0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1066 0x7fe532cc8070 0xfd3d6b265e0 
[1:1:0712/094842.804261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1074, 7fe53560d881
[1:1:0712/094842.846057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"946 0x7fe532cc8070 0xfd3d6b268e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.846333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"946 0x7fe532cc8070 0xfd3d6b268e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.846680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.847125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094842.847297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.890348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1075, 7fe53560d8db
[1:1:0712/094842.931753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"946 0x7fe532cc8070 0xfd3d6b268e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.932026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"946 0x7fe532cc8070 0xfd3d6b268e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.932428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1085
[1:1:0712/094842.932629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7fe532cc8070 0xfd3d70354e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1075 0x7fe532cc8070 0xfd3d6ad26e0 
[1:1:0712/094842.932933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.933421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094842.933600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094842.940274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1079, 7fe53560d8db
[1:1:0712/094842.981994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1069 0x7fe532cc8070 0xfd3d5c3ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.982237:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1069 0x7fe532cc8070 0xfd3d5c3ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094842.982620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1088
[1:1:0712/094842.982816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7fe532cc8070 0xfd3d7027560 , 5:3_http://baqiu.zxart.cn/, 0, , 1079 0x7fe532cc8070 0xfd3d6ad0860 
[1:1:0712/094842.983114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094842.983589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094842.983776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.042913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1083, 7fe53560d881
[1:1:0712/094843.087376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1066 0x7fe532cc8070 0xfd3d6b265e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.087704:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1066 0x7fe532cc8070 0xfd3d6b265e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.088044:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.088663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094843.088864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.089509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094843.089676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094843.090008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1092
[1:1:0712/094843.090198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1092 0x7fe532cc8070 0xfd3d6ce6560 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1083 0x7fe532cc8070 0xfd3d70d9ae0 
[1:1:0712/094843.138931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1053, 7fe53560d8db
[1:1:0712/094843.180502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1012 0x7fe532cc8070 0xfd3d5e81660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.180750:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1012 0x7fe532cc8070 0xfd3d5e81660 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.181117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1095
[1:1:0712/094843.181307:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7fe532cc8070 0xfd3d6554de0 , 5:3_http://baqiu.zxart.cn/, 0, , 1053 0x7fe532cc8070 0xfd3d6fdd7e0 
[1:1:0712/094843.181634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.182100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094843.182272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.183714:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1085, 7fe53560d8db
[1:1:0712/094843.226001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1075 0x7fe532cc8070 0xfd3d6ad26e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.226307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1075 0x7fe532cc8070 0xfd3d6ad26e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.226771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1096
[1:1:0712/094843.227008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7fe532cc8070 0xfd3d6cba8e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1085 0x7fe532cc8070 0xfd3d70354e0 
[1:1:0712/094843.227383:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.227958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094843.228183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.251563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094843.251771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094843.252161:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1097
[1:1:0712/094843.252394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7fe532cc8070 0xfd3d6eccf60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1085 0x7fe532cc8070 0xfd3d70354e0 
[1:1:0712/094843.271566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1088, 7fe53560d8db
[1:1:0712/094843.314457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1079 0x7fe532cc8070 0xfd3d6ad0860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.314754:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1079 0x7fe532cc8070 0xfd3d6ad0860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.315137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1100
[1:1:0712/094843.315327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7fe532cc8070 0xfd3d6adabe0 , 5:3_http://baqiu.zxart.cn/, 0, , 1088 0x7fe532cc8070 0xfd3d7027560 
[1:1:0712/094843.315708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.316195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.316370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.459926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1092, 7fe53560d881
[1:1:0712/094843.501873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1083 0x7fe532cc8070 0xfd3d70d9ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.502172:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1083 0x7fe532cc8070 0xfd3d70d9ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.502518:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.503053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094843.503230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.503896:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094843.504060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094843.504527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1103
[1:1:0712/094843.504736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7fe532cc8070 0xfd3d547afe0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1092 0x7fe532cc8070 0xfd3d6ce6560 
[1:1:0712/094843.506123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1100, 7fe53560d8db
[1:1:0712/094843.548397:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1088 0x7fe532cc8070 0xfd3d7027560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.548656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1088 0x7fe532cc8070 0xfd3d7027560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.549028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1104
[1:1:0712/094843.549215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7fe532cc8070 0xfd3d6eca2e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1100 0x7fe532cc8070 0xfd3d6adabe0 
[1:1:0712/094843.549544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.550011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.550188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.571709:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1104, 7fe53560d8db
[1:1:0712/094843.584409:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1100 0x7fe532cc8070 0xfd3d6adabe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.584573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1100 0x7fe532cc8070 0xfd3d6adabe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.584782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1106
[1:1:0712/094843.584893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7fe532cc8070 0xfd3d6ed56e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1104 0x7fe532cc8070 0xfd3d6eca2e0 
[1:1:0712/094843.585082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.585345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.585448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.637209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1106, 7fe53560d8db
[1:1:0712/094843.684825:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1104 0x7fe532cc8070 0xfd3d6eca2e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.685099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1104 0x7fe532cc8070 0xfd3d6eca2e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.685488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1109
[1:1:0712/094843.685700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7fe532cc8070 0xfd3d6ad2d60 , 5:3_http://baqiu.zxart.cn/, 0, , 1106 0x7fe532cc8070 0xfd3d6ed56e0 
[1:1:0712/094843.686054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.686533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.686768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.689224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1103, 7fe53560d881
[1:1:0712/094843.743544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1092 0x7fe532cc8070 0xfd3d6ce6560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.743956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1092 0x7fe532cc8070 0xfd3d6ce6560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.744377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.745088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094843.745315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.746117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094843.746321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094843.746751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1111
[1:1:0712/094843.747002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7fe532cc8070 0xfd3d58d4a60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1103 0x7fe532cc8070 0xfd3d547afe0 
[1:1:0712/094843.749119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1109, 7fe53560d8db
[1:1:0712/094843.803585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1106 0x7fe532cc8070 0xfd3d6ed56e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.803935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1106 0x7fe532cc8070 0xfd3d6ed56e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.804402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1114
[1:1:0712/094843.804666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7fe532cc8070 0xfd3d6ee44e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1109 0x7fe532cc8070 0xfd3d6ad2d60 
[1:1:0712/094843.805113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.805708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.805939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.859115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1114, 7fe53560d8db
[1:1:0712/094843.901586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1109 0x7fe532cc8070 0xfd3d6ad2d60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.901888:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1109 0x7fe532cc8070 0xfd3d6ad2d60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.902266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1118
[1:1:0712/094843.902461:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1118 0x7fe532cc8070 0xfd3d6ad7060 , 5:3_http://baqiu.zxart.cn/, 0, , 1114 0x7fe532cc8070 0xfd3d6ee44e0 
[1:1:0712/094843.902820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.903306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.903483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.905209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1111, 7fe53560d881
[1:1:0712/094843.947936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1103 0x7fe532cc8070 0xfd3d547afe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.948205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1103 0x7fe532cc8070 0xfd3d547afe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.948528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.949023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094843.949212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.949853:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094843.950016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094843.950336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1119
[1:1:0712/094843.950522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7fe532cc8070 0xfd3d7037760 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1111 0x7fe532cc8070 0xfd3d58d4a60 
[1:1:0712/094843.951982:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1118, 7fe53560d8db
[1:1:0712/094843.993325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1114 0x7fe532cc8070 0xfd3d6ee44e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.993517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1114 0x7fe532cc8070 0xfd3d6ee44e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094843.993756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1122
[1:1:0712/094843.993879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1122 0x7fe532cc8070 0xfd3d6ed3a60 , 5:3_http://baqiu.zxart.cn/, 0, , 1118 0x7fe532cc8070 0xfd3d6ad7060 
[1:1:0712/094843.994074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094843.994361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094843.994469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094843.995167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1095, 7fe53560d8db
[1:1:0712/094844.008608:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1053 0x7fe532cc8070 0xfd3d6fdd7e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.008774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1053 0x7fe532cc8070 0xfd3d6fdd7e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.008977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1123
[1:1:0712/094844.009087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7fe532cc8070 0xfd3d6aeb5e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1095 0x7fe532cc8070 0xfd3d6554de0 
[1:1:0712/094844.009258:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.009496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094844.009609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.023289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1122, 7fe53560d8db
[1:1:0712/094844.035912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1118 0x7fe532cc8070 0xfd3d6ad7060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.036052:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1118 0x7fe532cc8070 0xfd3d6ad7060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.036243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1125
[1:1:0712/094844.036351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1125 0x7fe532cc8070 0xfd3d6a2ae60 , 5:3_http://baqiu.zxart.cn/, 0, , 1122 0x7fe532cc8070 0xfd3d6ed3a60 
[1:1:0712/094844.036529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.036806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.036914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.071221:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1119, 7fe53560d881
[1:1:0712/094844.083835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1111 0x7fe532cc8070 0xfd3d58d4a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.083995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1111 0x7fe532cc8070 0xfd3d58d4a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.084174:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.084458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094844.084563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.084884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094844.084988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094844.085175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1128
[1:1:0712/094844.085283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1128 0x7fe532cc8070 0xfd3d70d65e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1119 0x7fe532cc8070 0xfd3d7037760 
[1:1:0712/094844.085791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1125, 7fe53560d8db
[1:1:0712/094844.098532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1122 0x7fe532cc8070 0xfd3d6ed3a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.098672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1122 0x7fe532cc8070 0xfd3d6ed3a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.098876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1129
[1:1:0712/094844.098984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7fe532cc8070 0xfd3d63811e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1125 0x7fe532cc8070 0xfd3d6a2ae60 
[1:1:0712/094844.099156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.099375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.099485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/094844.135137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1129, 7fe53560d8db
[1:1:0712/094844.147789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1125 0x7fe532cc8070 0xfd3d6a2ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.147930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1125 0x7fe532cc8070 0xfd3d6a2ae60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.148120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1131
[1:1:0712/094844.148227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7fe532cc8070 0xfd3d6ed3a60 , 5:3_http://baqiu.zxart.cn/, 0, , 1129 0x7fe532cc8070 0xfd3d63811e0 
[1:1:0712/094844.148412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.148677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.148811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.199373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1131, 7fe53560d8db
[1:1:0712/094844.242202:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1129 0x7fe532cc8070 0xfd3d63811e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.242457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1129 0x7fe532cc8070 0xfd3d63811e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.242838:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1134
[1:1:0712/094844.243034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1134 0x7fe532cc8070 0xfd3d6f1a560 , 5:3_http://baqiu.zxart.cn/, 0, , 1131 0x7fe532cc8070 0xfd3d6ed3a60 
[1:1:0712/094844.243381:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.243898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.244078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.245761:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1128, 7fe53560d881
[1:1:0712/094844.277592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1119 0x7fe532cc8070 0xfd3d7037760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.277895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1119 0x7fe532cc8070 0xfd3d7037760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.278226:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.278794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094844.278976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.279597:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094844.279827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094844.280155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1135
[1:1:0712/094844.280343:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7fe532cc8070 0xfd3d6ecc060 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1128 0x7fe532cc8070 0xfd3d70d65e0 
[1:1:0712/094844.281745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1134, 7fe53560d8db
[1:1:0712/094844.317071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1131 0x7fe532cc8070 0xfd3d6ed3a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.317215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1131 0x7fe532cc8070 0xfd3d6ed3a60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.317403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1137
[1:1:0712/094844.317511:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1137 0x7fe532cc8070 0xfd3d6b262e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1134 0x7fe532cc8070 0xfd3d6f1a560 
[1:1:0712/094844.317683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.317939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.318043:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.380173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1137, 7fe53560d8db
[1:1:0712/094844.421669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1134 0x7fe532cc8070 0xfd3d6f1a560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.421937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1134 0x7fe532cc8070 0xfd3d6f1a560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.422296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1139
[1:1:0712/094844.422480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1139 0x7fe532cc8070 0xfd3d6fe19e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1137 0x7fe532cc8070 0xfd3d6b262e0 
[1:1:0712/094844.422792:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.423254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.423460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.425195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1135, 7fe53560d881
[1:1:0712/094844.467441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1128 0x7fe532cc8070 0xfd3d70d65e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.467733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1128 0x7fe532cc8070 0xfd3d70d65e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.468126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.468664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094844.468881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.470276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094844.470456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094844.470831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1143
[1:1:0712/094844.471035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1143 0x7fe532cc8070 0xfd3d6b262e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1135 0x7fe532cc8070 0xfd3d6ecc060 
[1:1:0712/094844.682307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1139, 7fe53560d8db
[1:1:0712/094844.732868:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1137 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.733151:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1137 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.733553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1165
[1:1:0712/094844.733748:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7fe532cc8070 0xfd3d6fe1860 , 5:3_http://baqiu.zxart.cn/, 0, , 1139 0x7fe532cc8070 0xfd3d6fe19e0 
[1:1:0712/094844.734131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.734626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094844.734803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.903991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 955, 7fe53560d8db
[1:1:0712/094844.948778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.949066:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"870 0x7fe532cc8070 0xfd3d6ad2ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094844.949462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1171
[1:1:0712/094844.949669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1171 0x7fe532cc8070 0xfd3d72fb560 , 5:3_http://baqiu.zxart.cn/, 0, , 955 0x7fe532cc8070 0xfd3d55962e0 
[1:1:0712/094844.950000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094844.950500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094844.950675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094844.986716:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094844.986934:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094844.987268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1172
[1:1:0712/094844.987460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7fe532cc8070 0xfd3d7040360 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 955 0x7fe532cc8070 0xfd3d55962e0 
[1:1:0712/094845.000795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094845.001156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1173
[1:1:0712/094845.001351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7fe532cc8070 0xfd3d6d69ee0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 955 0x7fe532cc8070 0xfd3d55962e0 
[1:1:0712/094845.018185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 962, 7fe53560d8db
[1:1:0712/094845.064016:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"882 0x7fe532cc8070 0xfd3d5c3ac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.064296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"882 0x7fe532cc8070 0xfd3d5c3ac60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.064694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1178
[1:1:0712/094845.064890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7fe532cc8070 0xfd3d73146e0 , 5:3_http://baqiu.zxart.cn/, 0, , 962 0x7fe532cc8070 0xfd3d7027460 
[1:1:0712/094845.065233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094845.065734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094845.065920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094845.395112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1143, 7fe53560d881
[1:1:0712/094845.439664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1135 0x7fe532cc8070 0xfd3d6ecc060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.439951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1135 0x7fe532cc8070 0xfd3d6ecc060 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.440363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094845.440871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094845.441071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094845.441691:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094845.441850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094845.442189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1180
[1:1:0712/094845.442382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1180 0x7fe532cc8070 0xfd3d733e6e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1143 0x7fe532cc8070 0xfd3d6b262e0 
[1:1:0712/094845.640991:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1165, 7fe53560d8db
[1:1:0712/094845.687420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1139 0x7fe532cc8070 0xfd3d6fe19e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.687694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1139 0x7fe532cc8070 0xfd3d6fe19e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.688136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1184
[1:1:0712/094845.688344:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7fe532cc8070 0xfd3d734c5e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1165 0x7fe532cc8070 0xfd3d6fe1860 
[1:1:0712/094845.688670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094845.689168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094845.689347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094845.858535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1123, 7fe53560d8db
[1:1:0712/094845.904574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1095 0x7fe532cc8070 0xfd3d6554de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.904852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1095 0x7fe532cc8070 0xfd3d6554de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.905287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1198
[1:1:0712/094845.905483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1198 0x7fe532cc8070 0xfd3d73673e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1123 0x7fe532cc8070 0xfd3d6aeb5e0 
[1:1:0712/094845.905823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094845.906320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094845.906499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094845.953465:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1172, 7fe53560d881
[1:1:0712/094845.998386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"955 0x7fe532cc8070 0xfd3d55962e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.998699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"955 0x7fe532cc8070 0xfd3d55962e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094845.999045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094845.999546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094845.999724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.001018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1173, 7fe53560d8db
[1:1:0712/094846.046435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"955 0x7fe532cc8070 0xfd3d55962e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.046713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"955 0x7fe532cc8070 0xfd3d55962e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.047086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1200
[1:1:0712/094846.047293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1200 0x7fe532cc8070 0xfd3d72f2a60 , 5:3_http://baqiu.zxart.cn/, 0, , 1173 0x7fe532cc8070 0xfd3d6d69ee0 
[1:1:0712/094846.047635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.048095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094846.048320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.098867:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1180, 7fe53560d881
[1:1:0712/094846.128156:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1143 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.128572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1143 0x7fe532cc8070 0xfd3d6b262e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.128964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.129623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094846.129825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.130491:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094846.130660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094846.130992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1203
[1:1:0712/094846.131188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1203 0x7fe532cc8070 0xfd3d7344e60 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1180 0x7fe532cc8070 0xfd3d733e6e0 
[1:1:0712/094846.239483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1184, 7fe53560d8db
[1:1:0712/094846.309858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1165 0x7fe532cc8070 0xfd3d6fe1860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.310036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1165 0x7fe532cc8070 0xfd3d6fe1860 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.310301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1206
[1:1:0712/094846.310437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7fe532cc8070 0xfd3d7392ae0 , 5:3_http://baqiu.zxart.cn/, 0, , 1184 0x7fe532cc8070 0xfd3d734c5e0 
[1:1:0712/094846.310618:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.310899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094846.311004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.544989:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1198, 7fe53560d8db
[1:1:0712/094846.591681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1123 0x7fe532cc8070 0xfd3d6aeb5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.591976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1123 0x7fe532cc8070 0xfd3d6aeb5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.592418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1216
[1:1:0712/094846.592617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1216 0x7fe532cc8070 0xfd3d73a3fe0 , 5:3_http://baqiu.zxart.cn/, 0, , 1198 0x7fe532cc8070 0xfd3d73673e0 
[1:1:0712/094846.592957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.593452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094846.593629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.765017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1203, 7fe53560d881
[1:1:0712/094846.818057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1180 0x7fe532cc8070 0xfd3d733e6e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.818397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1180 0x7fe532cc8070 0xfd3d733e6e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.818793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.819339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094846.819579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.820214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094846.820392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094846.820802:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1224
[1:1:0712/094846.821019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1224 0x7fe532cc8070 0xfd3d738b560 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1203 0x7fe532cc8070 0xfd3d7344e60 
[1:1:0712/094846.822684:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1097, 7fe53560d881
[1:1:0712/094846.870476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1085 0x7fe532cc8070 0xfd3d70354e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.870803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1085 0x7fe532cc8070 0xfd3d70354e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094846.871182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094846.871700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){f.next();}
[1:1:0712/094846.871890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094846.931412:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094846.931713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 0
[1:1:0712/094846.932128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1228
[1:1:0712/094846.932375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1228 0x7fe532cc8070 0xfd3d738b2e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1097 0x7fe532cc8070 0xfd3d6eccf60 
[1:1:0712/094846.970082:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 13
[1:1:0712/094846.970481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1229
[1:1:0712/094846.970614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1229 0x7fe532cc8070 0xfd3d731b9e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1097 0x7fe532cc8070 0xfd3d6eccf60 
[1:1:0712/094846.977378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1206, 7fe53560d8db
[1:1:0712/094847.016220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1184 0x7fe532cc8070 0xfd3d734c5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.016618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1184 0x7fe532cc8070 0xfd3d734c5e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.017017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1234
[1:1:0712/094847.017223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1234 0x7fe532cc8070 0xfd3d73a8e60 , 5:3_http://baqiu.zxart.cn/, 0, , 1206 0x7fe532cc8070 0xfd3d7392ae0 
[1:1:0712/094847.017529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.017839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094847.018004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094847.466504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1224, 7fe53560d881
[1:1:0712/094847.503380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1203 0x7fe532cc8070 0xfd3d7344e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.503682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1203 0x7fe532cc8070 0xfd3d7344e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.503908:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.504221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094847.504344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094847.504690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094847.504796:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094847.504972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1249
[1:1:0712/094847.505086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7fe532cc8070 0xfd3d73aaee0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1224 0x7fe532cc8070 0xfd3d738b560 
[1:1:0712/094847.505611:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1216, 7fe53560d8db
[1:1:0712/094847.527438:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1198 0x7fe532cc8070 0xfd3d73673e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.527831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1198 0x7fe532cc8070 0xfd3d73673e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.528236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1251
[1:1:0712/094847.528431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7fe532cc8070 0xfd3d73a1760 , 5:3_http://baqiu.zxart.cn/, 0, , 1216 0x7fe532cc8070 0xfd3d73a3fe0 
[1:1:0712/094847.528825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.529434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094847.529690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094847.560634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1228, 7fe53560d881
[1:1:0712/094847.599217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1097 0x7fe532cc8070 0xfd3d6eccf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.599487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1097 0x7fe532cc8070 0xfd3d6eccf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.599829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.600129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){Xn=t}
[1:1:0712/094847.600233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094847.600906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1229, 7fe53560d8db
[1:1:0712/094847.619544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1097 0x7fe532cc8070 0xfd3d6eccf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.619863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1097 0x7fe532cc8070 0xfd3d6eccf60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.620118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1252
[1:1:0712/094847.620232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7fe532cc8070 0xfd3d734cf60 , 5:3_http://baqiu.zxart.cn/, 0, , 1229 0x7fe532cc8070 0xfd3d731b9e0 
[1:1:0712/094847.620417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.620726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094847.620837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094847.638713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094847.639016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 3000
[1:1:0712/094847.639431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1254
[1:1:0712/094847.639709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7fe532cc8070 0xfd3d73a16e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1229 0x7fe532cc8070 0xfd3d731b9e0 
[1:1:0712/094847.693579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1234, 7fe53560d8db
[1:1:0712/094847.716766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1206 0x7fe532cc8070 0xfd3d7392ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.717018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1206 0x7fe532cc8070 0xfd3d7392ae0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094847.717336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1257
[1:1:0712/094847.717512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1257 0x7fe532cc8070 0xfd3d73ab1e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1234 0x7fe532cc8070 0xfd3d73a8e60 
[1:1:0712/094847.717826:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094847.718209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094847.718354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.036651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1249, 7fe53560d881
[1:1:0712/094848.094814:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1224 0x7fe532cc8070 0xfd3d738b560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.095239:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1224 0x7fe532cc8070 0xfd3d738b560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.095726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.096481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094848.096721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.097487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094848.097708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094848.098119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1268
[1:1:0712/094848.098362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7fe532cc8070 0xfd3d7466de0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1249 0x7fe532cc8070 0xfd3d73aaee0 
[1:1:0712/094848.160566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1257, 7fe53560d8db
[1:1:0712/094848.201880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1234 0x7fe532cc8070 0xfd3d73a8e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.202100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1234 0x7fe532cc8070 0xfd3d73a8e60 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.202329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1270
[1:1:0712/094848.202446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7fe532cc8070 0xfd3d72f2960 , 5:3_http://baqiu.zxart.cn/, 0, , 1257 0x7fe532cc8070 0xfd3d73ab1e0 
[1:1:0712/094848.202633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.202937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094848.203056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.203869:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1251, 7fe53560d8db
[1:1:0712/094848.219435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1216 0x7fe532cc8070 0xfd3d73a3fe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.219590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1216 0x7fe532cc8070 0xfd3d73a3fe0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.219849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1273
[1:1:0712/094848.219966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7fe532cc8070 0xfd3d73af4e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1251 0x7fe532cc8070 0xfd3d73a1760 
[1:1:0712/094848.220146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.220400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094848.220520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.473926:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1268, 7fe53560d881
[1:1:0712/094848.524360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1249 0x7fe532cc8070 0xfd3d73aaee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.524676:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1249 0x7fe532cc8070 0xfd3d73aaee0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.525079:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.525600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094848.525776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.526419:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094848.526576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094848.526931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1278
[1:1:0712/094848.527125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1278 0x7fe532cc8070 0xfd3d7392560 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1268 0x7fe532cc8070 0xfd3d7466de0 
[1:1:0712/094848.689103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1270, 7fe53560d8db
[1:1:0712/094848.729381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1257 0x7fe532cc8070 0xfd3d73ab1e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.729751:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1257 0x7fe532cc8070 0xfd3d73ab1e0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.730288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1289
[1:1:0712/094848.730542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7fe532cc8070 0xfd3d74685e0 , 5:3_http://baqiu.zxart.cn/, 0, , 1270 0x7fe532cc8070 0xfd3d72f2960 
[1:1:0712/094848.730921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.731448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094848.731642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.766993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1278, 7fe53560d881
[1:1:0712/094848.812534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1268 0x7fe532cc8070 0xfd3d7466de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.812857:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1268 0x7fe532cc8070 0xfd3d7466de0 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094848.813258:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094848.813775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094848.813976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094848.814595:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094848.814754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094848.815095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1292
[1:1:0712/094848.815289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1292 0x7fe532cc8070 0xfd3d7463be0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1278 0x7fe532cc8070 0xfd3d7392560 
[1:1:0712/094849.223668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1289, 7fe53560d8db
[1:1:0712/094849.253842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1270 0x7fe532cc8070 0xfd3d72f2960 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.254115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1270 0x7fe532cc8070 0xfd3d72f2960 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.254434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1302
[1:1:0712/094849.254619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1302 0x7fe532cc8070 0xfd3d74b4de0 , 5:3_http://baqiu.zxart.cn/, 0, , 1289 0x7fe532cc8070 0xfd3d74685e0 
[1:1:0712/094849.254903:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094849.255350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094849.255501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094849.295476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1292, 7fe53560d881
[1:1:0712/094849.311765:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"030a77262860","ptid":"1278 0x7fe532cc8070 0xfd3d7392560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.312027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://baqiu.zxart.cn/","ptid":"1278 0x7fe532cc8070 0xfd3d7392560 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.312302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094849.312634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094849.312742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0712/094849.313067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6eb9c4c29c8, 0xfd3d4d76150
[1:1:0712/094849.313171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://baqiu.zxart.cn/en", 100
[1:1:0712/094849.313341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://baqiu.zxart.cn/, 1306
[1:1:0712/094849.313451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7fe532cc8070 0xfd3d74928e0 , 5:3_http://baqiu.zxart.cn/, 1, -5:3_http://baqiu.zxart.cn/, 1292 0x7fe532cc8070 0xfd3d7463be0 
[1:1:0712/094849.313910:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1273, 7fe53560d8db
[1:1:0712/094849.336520:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1251 0x7fe532cc8070 0xfd3d73a1760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.336734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1251 0x7fe532cc8070 0xfd3d73a1760 ","rf":"5:3_http://baqiu.zxart.cn/"}
[1:1:0712/094849.337071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1307
[1:1:0712/094849.337293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7fe532cc8070 0xfd3d74c5ae0 , 5:3_http://baqiu.zxart.cn/, 0, , 1273 0x7fe532cc8070 0xfd3d73af4e0 
[1:1:0712/094849.337615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://baqiu.zxart.cn/en"
[1:1:0712/094849.338182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://baqiu.zxart.cn/, 030a77262860, , , (){document.hasFocus()&&s++}
[1:1:0712/094849.338405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://baqiu.zxart.cn/en", "baqiu.zxart.cn", 3, 1, , , 0
[1:1:0100/000000.483527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://baqiu.zxart.cn/, 1302, 7fe53560d8db
