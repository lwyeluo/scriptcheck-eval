[0712/094850.517599:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094850.517938:INFO:switcher_clone.cc(787)] backtrace rip is 7fb796b23891
[0712/094851.462116:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094851.462433:INFO:switcher_clone.cc(787)] backtrace rip is 7fdfddd32891
[1:1:0712/094851.466810:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/094851.466997:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/094851.472298:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[119137:119137:0712/094852.813537:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f7c4713d-b7ff-4889-a201-7daa7d3c1967
[0712/094852.929879:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/094852.930422:INFO:switcher_clone.cc(787)] backtrace rip is 7faa464fd891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[119170:119170:0712/094853.196272:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119170
[119181:119181:0712/094853.196688:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119181
[119137:119137:0712/094853.382368:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[119137:119166:0712/094853.382844:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/094853.382978:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/094853.383249:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/094853.383802:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/094853.383955:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/094853.387076:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1cb3f7f, 1
[1:1:0712/094853.387459:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf6050a4, 0
[1:1:0712/094853.387647:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x27bfb67d, 3
[1:1:0712/094853.387852:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2cecb886, 2
[1:1:0712/094853.388118:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa450600f 7f3fffffffcb01 ffffff86ffffffb8ffffffec2c 7dffffffb6ffffffbf27 , 10104, 4
[1:1:0712/094853.389291:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119137:119166:0712/094853.389514:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�P`?����,}��'<k&
[119137:119166:0712/094853.389590:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �P`?����,}��'�<k&
[1:1:0712/094853.389710:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfdbf6d0a0, 3
[119137:119166:0712/094853.389861:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[119137:119166:0712/094853.389927:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119189, 4, a450600f 7f3fcb01 86b8ec2c 7db6bf27 
[1:1:0712/094853.389924:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfdc0f8080, 2
[1:1:0712/094853.390148:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfc5dbbd20, -2
[1:1:0712/094853.412851:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/094853.413941:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2cecb886
[1:1:0712/094853.415152:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2cecb886
[1:1:0712/094853.417107:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2cecb886
[1:1:0712/094853.418958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.419208:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.419433:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.419689:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.420506:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2cecb886
[1:1:0712/094853.420902:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdfddd327ba
[1:1:0712/094853.421089:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdfddd29def, 7fdfddd3277a, 7fdfddd340cf
[1:1:0712/094853.428296:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2cecb886
[1:1:0712/094853.428530:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2cecb886
[1:1:0712/094853.428827:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2cecb886
[1:1:0712/094853.429575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.429696:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.429794:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.429890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2cecb886
[1:1:0712/094853.430372:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2cecb886
[1:1:0712/094853.430539:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdfddd327ba
[1:1:0712/094853.430616:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdfddd29def, 7fdfddd3277a, 7fdfddd340cf
[1:1:0712/094853.432861:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/094853.433162:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/094853.433258:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd81071b48, 0x7ffd81071ac8)
[1:1:0712/094853.447939:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/094853.454124:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[119137:119137:0712/094854.031119:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119137:119137:0712/094854.032585:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119137:119148:0712/094854.050137:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[119137:119148:0712/094854.050284:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[119137:119137:0712/094854.052144:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[119137:119137:0712/094854.052323:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[119137:119137:0712/094854.052504:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,119189, 4
[1:7:0712/094854.057283:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[119137:119160:0712/094854.125254:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/094854.164847:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x24f79fcc3220
[1:1:0712/094854.165170:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/094854.592484:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[119137:119137:0712/094856.348927:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[119137:119137:0712/094856.349077:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/094856.387302:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094856.389027:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094857.050306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/094857.050513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094857.059900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/094857.060108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094857.095874:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094857.364580:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094857.364840:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094857.681405:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094857.684035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/094857.684339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094857.719160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094857.729699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/094857.729959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094857.742627:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/094857.746506:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x24f79fcc1e20
[1:1:0712/094857.746699:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[119137:119137:0712/094857.747081:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[119137:119137:0712/094857.761433:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/094857.802609:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[119137:119137:0712/094857.803574:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[119137:119137:0712/094857.803710:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[119137:119137:0712/094857.821625:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/094858.313478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fdfc79962e0 0x24f79fdeb060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094858.314797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/094858.315006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094858.316547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119137:119137:0712/094858.362390:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/094858.364656:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x24f79fcc2820
[1:1:0712/094858.364905:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119137:119137:0712/094858.369395:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/094858.372665:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/094858.372834:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[119137:119137:0712/094858.379266:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[119137:119137:0712/094858.393662:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119137:119137:0712/094858.394961:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119137:119148:0712/094858.401686:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[119137:119148:0712/094858.401781:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[119137:119137:0712/094858.401914:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[119137:119137:0712/094858.401991:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[119137:119137:0712/094858.402127:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,119189, 4
[1:7:0712/094858.405114:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/094858.835347:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/094859.070806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7fdfc79962e0 0x24f7a008a5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094859.071968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/094859.072230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094859.073005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119137:119137:0712/094859.240941:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[119137:119137:0712/094859.241008:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/094859.261536:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094859.572479:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094859.974080:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094859.974366:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094900.209072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094900.213520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34be3364e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/094900.213843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094900.221581:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[119137:119137:0712/094900.283978:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[119137:119166:0712/094900.284528:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/094900.284733:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/094900.285062:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/094900.286009:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/094900.286225:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/094900.289852:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c1fcd7a, 1
[1:1:0712/094900.290297:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12024f81, 0
[1:1:0712/094900.290509:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1746b21a, 3
[1:1:0712/094900.290717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6ccb1c9, 2
[1:1:0712/094900.290955:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff814f0212 7affffffcd1f3c ffffffc9ffffffb1ffffffcc06 1affffffb24617 , 10104, 5
[1:1:0712/094900.292065:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119137:119166:0712/094900.292371:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Oz�<ɱ��F�k&
[119137:119166:0712/094900.292459:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Oz�<ɱ��FX��k&
[1:1:0712/094900.292364:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfdbf6d0a0, 3
[1:1:0712/094900.292613:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfdc0f8080, 2
[119137:119166:0712/094900.292773:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119233, 5, 814f0212 7acd1f3c c9b1cc06 1ab24617 
[1:1:0712/094900.292856:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdfc5dbbd20, -2
[1:1:0712/094900.313055:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/094900.313446:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6ccb1c9
[1:1:0712/094900.313795:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6ccb1c9
[1:1:0712/094900.314419:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6ccb1c9
[1:1:0712/094900.315841:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.316059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.316272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.316484:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.317163:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6ccb1c9
[1:1:0712/094900.317475:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdfddd327ba
[1:1:0712/094900.317663:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdfddd29def, 7fdfddd3277a, 7fdfddd340cf
[1:1:0712/094900.321124:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6ccb1c9
[1:1:0712/094900.321515:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6ccb1c9
[1:1:0712/094900.322431:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6ccb1c9
[1:1:0712/094900.324427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.324673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.324919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.325177:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6ccb1c9
[1:1:0712/094900.326286:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/094900.326667:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6ccb1c9
[1:1:0712/094900.326998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 34be33521f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/094900.327109:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdfddd327ba
[1:1:0712/094900.327292:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdfddd29def, 7fdfddd3277a, 7fdfddd340cf
[1:1:0712/094900.327225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/094900.336678:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/094900.337355:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/094900.337551:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd81071b48, 0x7ffd81071ac8)
[1:1:0712/094900.354142:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/094900.359436:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/094900.514247:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x24f79fc83220
[1:1:0712/094900.514410:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/094900.707146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094900.708949:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/094900.709200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34be3364e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/094900.709596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094900.840044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094900.840974:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/094900.856208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34be3364e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/094900.856518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[119137:119137:0712/094901.160669:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119137:119137:0712/094901.165482:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119137:119148:0712/094901.197116:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[119137:119148:0712/094901.197177:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[119137:119137:0712/094901.199371:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://wzwei.zxart.cn/
[119137:119137:0712/094901.199409:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://wzwei.zxart.cn/, http://wzwei.zxart.cn/, 1
[119137:119137:0712/094901.199458:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://wzwei.zxart.cn/, HTTP/1.1 200 OK Cache-Control: private Content-Type: text/html; charset=utf-8 Content-Encoding: gzip Vary: Accept-Encoding Server: Microsoft-IIS/7.5 X-AspNet-Version: 4.0.30319 Set-Cookie: BlogAntiForgeryToken=lI77DuwdhRLd9Ifexwza9+GgR9WQNAyIyJivtlnxCANi8eTsDPwoA9RBpBoR4wMy; domain=.zxart.cn; path=/; HttpOnly X-Powered-By: ASP.NET Date: Fri, 12 Jul 2019 16:48:02 GMT Content-Length: 22733  ,119233, 5
[1:7:0712/094901.201592:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/094901.217131:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://wzwei.zxart.cn/
[119137:119137:0712/094901.329776:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://wzwei.zxart.cn/, http://wzwei.zxart.cn/, 1
[119137:119137:0712/094901.329890:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://wzwei.zxart.cn/, http://wzwei.zxart.cn
[1:1:0712/094901.380386:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094901.381273:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094901.501764:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094901.548799:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/094901.577620:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094901.577800:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094901.588483:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/094901.813683:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/094901.939346:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/094902.081299:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094902.107221:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/094902.250034:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/094902.313068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fdfc5dd6bd0 0x24f79fddf8d8 , "http://wzwei.zxart.cn/"
[1:1:0712/094902.324431:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094902.333401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , /*v1.9.1*/(function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="
[1:1:0712/094902.333674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
		remove user.f_dd7dea7f -> 0
[1:1:0712/094902.377374:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/094902.420312:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/094902.523743:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/094902.596823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fdfc5dd6bd0 0x24f79fddf8d8 , "http://wzwei.zxart.cn/"
[1:1:0712/094902.655473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fdfc5dd6bd0 0x24f79fddf8d8 , "http://wzwei.zxart.cn/"
[1:1:0712/094902.697784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fdfc5dd6bd0 0x24f79fddf8d8 , "http://wzwei.zxart.cn/"
[1:1:0712/094902.759162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7fdfc5dd6bd0 0x24f79fddf8d8 , "http://wzwei.zxart.cn/"
[1:1:0712/094902.769815:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/094902.770744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 34be3364e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/094902.771046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/094903.307707:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.716558, 3, 0
[1:1:0712/094903.307974:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094903.511771:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094903.512041:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094903.513157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7fdfc5a6e070 0x24f79f8a9360 , "http://wzwei.zxart.cn/"
[1:1:0712/094903.514559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 
        $ = jQuery;
        function AddFriend(fn) {
            $.post("blog/Ajax/YSJFriend/Friend
[1:1:0712/094903.514789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094903.517246:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7fdfc5a6e070 0x24f79f8a9360 , "http://wzwei.zxart.cn/"
[1:1:0712/094903.561085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7fdfc5a6e070 0x24f79f8a9360 , "http://wzwei.zxart.cn/"
[1:1:0712/094903.568069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7fdfc5a6e070 0x24f79f8a9360 , "http://wzwei.zxart.cn/"
[1:1:0712/094903.596630:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0845289, 209, 1
[1:1:0712/094903.596916:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/094904.145289:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094904.145568:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094904.146389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fdfc5a6e070 0x24f7a0111a60 , "http://wzwei.zxart.cn/"
[1:1:0712/094904.147295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 
                    function display() {
                        document.getElementById("box").sty
[1:1:0712/094904.147524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094904.156217:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0105381, 61, 1
[1:1:0712/094904.156450:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094904.537573:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094904.537857:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094904.538749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7fdfc5a6e070 0x24f79fdafde0 , "http://wzwei.zxart.cn/"
[1:1:0712/094904.539753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 
                jQuery(document).ready(function () {
                    jQuery(".x_title ul li").h
[1:1:0712/094904.540025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094904.544025:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094904.544513:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094904.545134:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094904.546371:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094904.546782:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094904.548326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7fdfc5a6e070 0x24f79fdafde0 , "http://wzwei.zxart.cn/"
[1:1:0712/094904.883210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2d43e22429c8, 0x24f79faff998
[1:1:0712/094904.883502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 800
[1:1:0712/094904.883938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 368
[1:1:0712/094904.884196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 368 0x7fdfc5a6e070 0x24f7a02421e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 299 0x7fdfc5a6e070 0x24f79fdafde0 
[1:1:0712/094904.889273:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7fdfc5a6e070 0x24f79fdafde0 , "http://wzwei.zxart.cn/"
[1:1:0712/094904.908584:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.370679, 130, 1
[1:1:0712/094904.908909:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094905.567466:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094905.567730:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094905.568800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 374 0x7fdfc5a6e070 0x24f7a02415e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094905.570026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , ,                             window._bd_share_config = { "common": { "bdSnsKey": {}, "bdText": "", "b
[1:1:0712/094905.570270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094905.627360:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0596299, 170, 1
[1:1:0712/094905.627686:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094906.428490:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094906.428781:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094906.429724:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fdfc5a6e070 0x24f7a024aee0 , "http://wzwei.zxart.cn/"
[1:1:0712/094906.430692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 
                        function ShowVideoCss(num) {
                            jQuery("#v_" + num
[1:1:0712/094906.430919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094906.452884:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0240331, 342, 1
[1:1:0712/094906.453174:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094906.466038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 368, 7fdfc83b3881
[1:1:0712/094906.485694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"299 0x7fdfc5a6e070 0x24f79fdafde0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094906.486057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"299 0x7fdfc5a6e070 0x24f79fdafde0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094906.486477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094906.487091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , e, (){k.y=(t*2||M[ai])/2;if(o==0&&k.y<=w+k.Step&&!an){if(ab){var j=M.getAttribute("fixnum")/1+1||1;M.se
[1:1:0712/094906.487350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094907.647466:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff958
[1:1:0712/094907.647770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094907.648126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 463
[1:1:0712/094907.648359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7fdfc5a6e070 0x24f7a02e8260 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 368 0x7fdfc5a6e070 0x24f7a02421e0 
[1:1:0712/094907.719500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7fdfc79962e0 0x24f7a0111360 , "http://wzwei.zxart.cn/"
[1:1:0712/094907.722414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/094907.722680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094908.280627:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094908.280933:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094908.282250:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.283827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 

                //$("#login_btn").attr("href", "http://www.zxart.cn/Login.html?ToUrl=" + window.lo
[1:1:0712/094908.284071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094908.292375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.312375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.383272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.396629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.403879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.415205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.466356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.475485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 452 0x7fdfc5a6e070 0x24f79ffdaa60 , "http://wzwei.zxart.cn/"
[1:1:0712/094908.501714:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.220761, 103, 1
[1:1:0712/094908.502034:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/094908.739063:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://www.zxart.cn/"
[1:1:0712/094908.908256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 463, 7fdfc83b3881
[1:1:0712/094908.930560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"368 0x7fdfc5a6e070 0x24f7a02421e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094908.930932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"368 0x7fdfc5a6e070 0x24f7a02421e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094908.931320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094908.931935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , e, (){k.y=(t*2||M[ai])/2;if(o==0&&k.y<=w+k.Step&&!an){if(ab){var j=M.getAttribute("fixnum")/1+1||1;M.se
[1:1:0712/094908.932164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094909.131078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff958
[1:1:0712/094909.131386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094909.131788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 508
[1:1:0712/094909.132039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7fdfc5a6e070 0x24f7a02e0060 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 463 0x7fdfc5a6e070 0x24f7a02e8260 
[1:1:0712/094909.703396:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/094909.703673:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://wzwei.zxart.cn/"
[1:1:0712/094909.707704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fdfc5a6e070 0x24f79f9ba7e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094909.709312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , 
var KX_cfg_data = { cnnic_dn : '', cnnic_lang : 'zh_cn' };

KX_cfg_data.cnnic_sn = "e14031835020
[1:1:0712/094909.709538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094909.722389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fdfc5a6e070 0x24f79f9ba7e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094909.738898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://wzwei.zxart.cn/"
[1:1:0712/094910.170783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 5000
[1:1:0712/094910.171269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 525
[1:1:0712/094910.171506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7fdfc5a6e070 0x24f79ffe8b60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.224254:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 5000
[1:1:0712/094910.224719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 526
[1:1:0712/094910.224952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7fdfc5a6e070 0x24f7a0811de0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.554244:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d43e22429c8, 0x24f79faffa38
[1:1:0712/094910.554588:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 3000
[1:1:0712/094910.555004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 528
[1:1:0712/094910.555239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7fdfc5a6e070 0x24f7a08113e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.626570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://wzwei.zxart.cn/"
[1:1:0712/094910.653333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.653607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.653975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 529
[1:1:0712/094910.654214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7fdfc5a6e070 0x24f79fda11e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.665667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.665915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.666397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 531
[1:1:0712/094910.666631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7fdfc5a6e070 0x24f7a08117e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.678210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.678505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.678860:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 535
[1:1:0712/094910.679089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 535 0x7fdfc5a6e070 0x24f7a0309260 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.690054:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.690375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.690749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 537
[1:1:0712/094910.690983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7fdfc5a6e070 0x24f7a03076e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.696665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.696892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.697242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 539
[1:1:0712/094910.697524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 539 0x7fdfc5a6e070 0x24f7a02e89e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.707718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.708012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094910.708843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 542
[1:1:0712/094910.709220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7fdfc5a6e070 0x24f79ffd39e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.714174:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d43e22429c8, 0x24f79faff9e0
[1:1:0712/094910.714422:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 3000
[1:1:0712/094910.714773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 544
[1:1:0712/094910.715036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 544 0x7fdfc5a6e070 0x24f7a023eee0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 496 0x7fdfc5a6e070 0x24f79f9ba7e0 
[1:1:0712/094910.947815:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 508, 7fdfc83b3881
[1:1:0712/094910.971069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"463 0x7fdfc5a6e070 0x24f7a02e8260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094910.971385:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"463 0x7fdfc5a6e070 0x24f7a02e8260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094910.971812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094910.972371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , e, (){k.y=(t*2||M[ai])/2;if(o==0&&k.y<=w+k.Step&&!an){if(ab){var j=M.getAttribute("fixnum")/1+1||1;M.se
[1:1:0712/094910.972606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094910.973611:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff958
[1:1:0712/094910.973810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094910.974166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 558
[1:1:0712/094910.974410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7fdfc5a6e070 0x24f7a0251260 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 508 0x7fdfc5a6e070 0x24f7a02e0060 
[1:1:0712/094911.269325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wzwei.zxart.cn/"
[1:1:0712/094911.270097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0712/094911.270319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094911.271486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wzwei.zxart.cn/"
[1:1:0712/094911.273808:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://wzwei.zxart.cn/"
[1:1:0712/094911.274447:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x26a76671cb50
[1:1:0712/094911.708872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 558, 7fdfc83b3881
[1:1:0712/094911.728192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"508 0x7fdfc5a6e070 0x24f7a02e0060 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094911.728543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"508 0x7fdfc5a6e070 0x24f7a02e0060 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094911.728928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094911.729446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){if((k.ScrollStep>=0&&k.l)||(P==0&&k.ScrollStep==-2&&k.l)){k.l()}p()}
[1:1:0712/094911.729680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094911.733782:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 20
[1:1:0712/094911.734152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 591
[1:1:0712/094911.734383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7fdfc5a6e070 0x24f7a0103b60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 558 0x7fdfc5a6e070 0x24f7a0251260 
[1:1:0712/094911.874713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563 0x7fdfc79962e0 0x24f79f9ba760 , "http://wzwei.zxart.cn/"
[1:1:0712/094911.876040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/094911.876268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094911.907844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7fdfc79962e0 0x24f7a02df460 , "http://wzwei.zxart.cn/"
[1:1:0712/094911.909253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094911.909479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094911.928706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff990
[1:1:0712/094911.928935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094911.929303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 594
[1:1:0712/094911.929544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7fdfc5a6e070 0x24f7a02420e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 564 0x7fdfc79962e0 0x24f7a02df460 
[1:1:0712/094911.957266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff990
[1:1:0712/094911.957523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094911.957929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 597
[1:1:0712/094911.958170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7fdfc5a6e070 0x24f7a0523360 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 564 0x7fdfc79962e0 0x24f7a02df460 
[1:1:0712/094911.963099:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.103879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 570 0x7fdfc79962e0 0x24f7a02e3f60 , "http://wzwei.zxart.cn/"
[1:1:0712/094912.104834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094912.105053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094912.131725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff990
[1:1:0712/094912.131980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094912.132328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 602
[1:1:0712/094912.132550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7fdfc5a6e070 0x24f79fffe6e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 570 0x7fdfc79962e0 0x24f7a02e3f60 
[1:1:0712/094912.137344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.145678:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094912.146194:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/094912.186090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571 0x7fdfc79962e0 0x24f7a03016e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094912.187362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("share/select_api",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/094912.187591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094912.209883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.239775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573 0x7fdfc79962e0 0x24f79fe730e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094912.240891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("view/select_view",function(e,t,n){var r=e("base/tangram").T,i=e("bas
[1:1:0712/094912.241114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094912.267479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.301422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7fdfc79962e0 0x24f79fffe4e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094912.302737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("share/image_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094912.302963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094912.324937:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.411292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 576 0x7fdfc79962e0 0x24f7a02e8260 , "http://wzwei.zxart.cn/"
[1:1:0712/094912.412450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("view/image_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/094912.412673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094912.434820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094912.726632:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 591, 7fdfc83b38db
[1:1:0712/094912.752565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"558 0x7fdfc5a6e070 0x24f7a0251260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094912.752921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"558 0x7fdfc5a6e070 0x24f7a0251260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094912.753344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 617
[1:1:0712/094912.753571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7fdfc5a6e070 0x24f79f9bbe60 , 5:3_http://wzwei.zxart.cn/, 0, , 591 0x7fdfc5a6e070 0x24f7a0103b60 
[1:1:0712/094912.753914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094912.754422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094912.754635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094913.287461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 617, 7fdfc83b38db
[1:1:0712/094913.314454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"591 0x7fdfc5a6e070 0x24f7a0103b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094913.314806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"591 0x7fdfc5a6e070 0x24f7a0103b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094913.315260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 639
[1:1:0712/094913.315493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7fdfc5a6e070 0x24f7a02e87e0 , 5:3_http://wzwei.zxart.cn/, 0, , 617 0x7fdfc5a6e070 0x24f79f9bbe60 
[1:1:0712/094913.315861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094913.316393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094913.316608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094913.534339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 623 0x7fdfc79962e0 0x24f79fe73ee0 , "http://wzwei.zxart.cn/"
[1:1:0712/094913.535353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0712/094913.535579:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094913.548416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094913.582627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 624 0x7fdfc79962e0 0x24f7a080c860 , "http://wzwei.zxart.cn/"
[1:1:0712/094913.583540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0712/094913.583781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094913.600816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094913.699612:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 628 0x7fdfc79962e0 0x24f79ffe2860 , "http://wzwei.zxart.cn/"
[1:1:0712/094913.704465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (function(){var h={},mt={},c={id:"06ffa85f4154e2ae01fa772a613d3d58",dm:["zxart.cn"],js:"tongji.baidu
[1:1:0712/094913.704697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094913.733680:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff990
[1:1:0712/094913.733969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094913.734368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 655
[1:1:0712/094913.734601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7fdfc5a6e070 0x24f7a024c460 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 628 0x7fdfc79962e0 0x24f79ffe2860 
[119137:119137:0712/094924.477230:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/094924.483328:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/094924.674461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 629 0x7fdfc79962e0 0x24f7a03094e0 , "http://wzwei.zxart.cn/"
[1:1:0712/094924.677466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0712/094924.677610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
		remove user.11_be733f47 -> 0
		remove user.12_3c8f4b28 -> 0
[1:1:0712/094925.251881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff988
[1:1:0712/094925.252104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094925.252302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 718
[1:1:0712/094925.252414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7fdfc5a6e070 0x24f7a0c8bbe0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 629 0x7fdfc79962e0 0x24f7a03094e0 
[1:1:0712/094925.288315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff988
[1:1:0712/094925.288573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094925.288887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 721
[1:1:0712/094925.289107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7fdfc5a6e070 0x24f7a0ccb1e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 629 0x7fdfc79962e0 0x24f7a03094e0 
[1:1:0712/094925.289588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff988
[1:1:0712/094925.289738:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094925.290193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 722
[1:1:0712/094925.290389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7fdfc5a6e070 0x24f7a02ebe60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 629 0x7fdfc79962e0 0x24f7a03094e0 
[1:1:0712/094925.354846:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[119137:119137:0712/094925.360477:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/094925.363007:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x24f7a05d7220
[1:1:0712/094925.364211:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119137:119137:0712/094925.364745:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[119137:119137:0712/094925.424023:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://wzwei.zxart.cn/, http://wzwei.zxart.cn/, 4
[119137:119137:0712/094925.424228:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://wzwei.zxart.cn/, http://wzwei.zxart.cn
[1:1:0712/094926.056976:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094926.304531:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 639, 7fdfc83b38db
[1:1:0712/094926.344030:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"617 0x7fdfc5a6e070 0x24f79f9bbe60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094926.344415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"617 0x7fdfc5a6e070 0x24f79f9bbe60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094926.344914:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 750
[1:1:0712/094926.345163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7fdfc5a6e070 0x24f7a02e50e0 , 5:3_http://wzwei.zxart.cn/, 0, , 639 0x7fdfc5a6e070 0x24f7a02e87e0 
[1:1:0712/094926.345547:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094926.346158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094926.346403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094926.528228:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 528, 7fdfc83b3881
[1:1:0712/094926.564937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094926.565257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094926.565628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094926.566106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){f.next();}
[1:1:0712/094926.566283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094926.611796:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094926.611989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094926.612184:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 753
[1:1:0712/094926.612298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7fdfc5a6e070 0x24f7a0e2d560 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 528 0x7fdfc5a6e070 0x24f7a08113e0 
[1:1:0712/094926.643537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 13
[1:1:0712/094926.643816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 755
[1:1:0712/094926.643933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7fdfc5a6e070 0x24f7a0d57360 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 528 0x7fdfc5a6e070 0x24f7a08113e0 
[1:1:0712/094926.859567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/094926.859770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.210050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 544, 7fdfc83b3881
[1:1:0712/094928.220720:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.221043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.221420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094928.221935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/094928.222054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.224900:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094928.225016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 15000
[1:1:0712/094928.225178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 781
[1:1:0712/094928.225290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7fdfc5a6e070 0x24f7a0fccbe0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 544 0x7fdfc5a6e070 0x24f7a023eee0 
[1:1:0712/094928.239144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 655, 7fdfc83b3881
[1:1:0712/094928.250165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"628 0x7fdfc79962e0 0x24f79ffe2860 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.250372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"628 0x7fdfc79962e0 0x24f79ffe2860 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.250616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094928.250946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094928.251073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.251435:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094928.251541:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094928.251712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 784
[1:1:0712/094928.251883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7fdfc5a6e070 0x24f7a0fb7060 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 655 0x7fdfc5a6e070 0x24f7a024c460 
[1:1:0712/094928.252359:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 525, 7fdfc83b38db
[1:1:0712/094928.281920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.282131:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.282399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 785
[1:1:0712/094928.282519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7fdfc5a6e070 0x24f7a0fc7a60 , 5:3_http://wzwei.zxart.cn/, 0, , 525 0x7fdfc5a6e070 0x24f79ffe8b60 
[1:1:0712/094928.282666:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094928.282998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094928.283117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.361573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 526, 7fdfc83b38db
[1:1:0712/094928.394649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.394971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"496 0x7fdfc5a6e070 0x24f79f9ba7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.395495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 791
[1:1:0712/094928.395749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7fdfc5a6e070 0x24f7a0fccb60 , 5:3_http://wzwei.zxart.cn/, 0, , 526 0x7fdfc5a6e070 0x24f7a0811de0 
[1:1:0712/094928.396107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094928.396451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094928.396572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.938328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 721, 7fdfc83b3881
[1:1:0712/094928.959248:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"629 0x7fdfc79962e0 0x24f7a03094e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.959577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"629 0x7fdfc79962e0 0x24f7a03094e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094928.960132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094928.960728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){l(e,t)}
[1:1:0712/094928.960957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094928.964416:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094928.964624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 1
[1:1:0712/094928.965031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 799
[1:1:0712/094928.965239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7fdfc5a6e070 0x24f7a1066e60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 721 0x7fdfc5a6e070 0x24f7a0ccb1e0 
[1:1:0712/094929.127440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 750, 7fdfc83b38db
[1:1:0712/094929.150427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"639 0x7fdfc5a6e070 0x24f7a02e87e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.150619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"639 0x7fdfc5a6e070 0x24f7a02e87e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.150894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 802
[1:1:0712/094929.151044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7fdfc5a6e070 0x24f7a1062e60 , 5:3_http://wzwei.zxart.cn/, 0, , 750 0x7fdfc5a6e070 0x24f7a02e50e0 
[1:1:0712/094929.151214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094929.151498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094929.151617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094929.204685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , document.readyState
[1:1:0712/094929.204995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094929.252381:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 753, 7fdfc83b3881
[1:1:0712/094929.294747:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"528 0x7fdfc5a6e070 0x24f7a08113e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.295158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"528 0x7fdfc5a6e070 0x24f7a08113e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.295650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094929.296268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){Xn=t}
[1:1:0712/094929.296515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094929.322998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 755, 7fdfc83b38db
[1:1:0712/094929.334065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"528 0x7fdfc5a6e070 0x24f7a08113e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.334260:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"528 0x7fdfc5a6e070 0x24f7a08113e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094929.334504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 808
[1:1:0712/094929.334621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7fdfc5a6e070 0x24f7a109cb60 , 5:3_http://wzwei.zxart.cn/, 0, , 755 0x7fdfc5a6e070 0x24f7a0d57360 
[1:1:0712/094929.334772:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094929.335089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094929.335201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094929.347169:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094929.347346:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 3000
[1:1:0712/094929.347526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 809
[1:1:0712/094929.347641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7fdfc5a6e070 0x24f7a0f91de0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 755 0x7fdfc5a6e070 0x24f7a0d57360 
[1:1:0712/094930.561262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7fdfc79962e0 0x24f7a0fe8ce0 , "http://wzwei.zxart.cn/"
[1:1:0712/094930.562067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0712/094930.562209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094930.586216:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094930.643679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 789 0x7fdfc79962e0 0x24f7a0d13e60 , "http://wzwei.zxart.cn/"
[1:1:0712/094930.644227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0712/094930.644354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094930.666171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 1000
[1:1:0712/094930.666470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 857
[1:1:0712/094930.666595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 857 0x7fdfc5a6e070 0x24f7a0f5a7e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 789 0x7fdfc79962e0 0x24f7a0d13e60 
[1:1:0712/094930.677443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094930.685591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 784, 7fdfc83b3881
[1:1:0712/094930.698266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"655 0x7fdfc5a6e070 0x24f7a024c460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.698480:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"655 0x7fdfc5a6e070 0x24f7a024c460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.698766:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094930.699081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094930.699189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094930.699524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094930.699629:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094930.699797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 863
[1:1:0712/094930.699936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7fdfc5a6e070 0x24f7a0feec60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 784 0x7fdfc5a6e070 0x24f7a0fb7060 
[1:1:0712/094930.821148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 799, 7fdfc83b3881
[1:1:0712/094930.859203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"721 0x7fdfc5a6e070 0x24f7a0ccb1e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.859525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"721 0x7fdfc5a6e070 0x24f7a0ccb1e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.859901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094930.860370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){n?t&&t():l(e,t)}
[1:1:0712/094930.860575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094930.924102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 802, 7fdfc83b38db
[1:1:0712/094930.952474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"750 0x7fdfc5a6e070 0x24f7a02e50e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.952668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"750 0x7fdfc5a6e070 0x24f7a02e50e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094930.952923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 872
[1:1:0712/094930.953046:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 872 0x7fdfc5a6e070 0x24f7a0304c60 , 5:3_http://wzwei.zxart.cn/, 0, , 802 0x7fdfc5a6e070 0x24f7a1062e60 
[1:1:0712/094930.953203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094930.953514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094930.953632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094930.968479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , document.readyState
[1:1:0712/094930.968666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094932.166810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 785, 7fdfc83b38db
[1:1:0712/094932.204921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"525 0x7fdfc5a6e070 0x24f79ffe8b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094932.205205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"525 0x7fdfc5a6e070 0x24f79ffe8b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094932.205607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 885
[1:1:0712/094932.205824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 885 0x7fdfc5a6e070 0x24f7a1471260 , 5:3_http://wzwei.zxart.cn/, 0, , 785 0x7fdfc5a6e070 0x24f7a0fc7a60 
[1:1:0712/094932.206081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094932.206589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094932.206784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094932.243302:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094932.243538:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094932.243998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 886
[1:1:0712/094932.244209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 886 0x7fdfc5a6e070 0x24f79f609b60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 785 0x7fdfc5a6e070 0x24f7a0fc7a60 
[1:1:0712/094932.258886:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 13
[1:1:0712/094932.259252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 887
[1:1:0712/094932.259442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7fdfc5a6e070 0x24f7a15dfd60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 785 0x7fdfc5a6e070 0x24f7a0fc7a60 
[1:1:0712/094932.352947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 791, 7fdfc83b38db
[1:1:0712/094932.389738:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"526 0x7fdfc5a6e070 0x24f7a0811de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094932.390036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"526 0x7fdfc5a6e070 0x24f7a0811de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094932.390451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 895
[1:1:0712/094932.390646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7fdfc5a6e070 0x24f7a0f95de0 , 5:3_http://wzwei.zxart.cn/, 0, , 791 0x7fdfc5a6e070 0x24f7a0fccb60 
[1:1:0712/094932.390922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094932.391425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094932.391601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094932.551045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094932.551502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/094932.551650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.046192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 863, 7fdfc83b3881
[1:1:0712/094933.059824:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"784 0x7fdfc5a6e070 0x24f7a0fb7060 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.060058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"784 0x7fdfc5a6e070 0x24f7a0fb7060 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.060299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.060719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094933.060837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.061164:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094933.061270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094933.061440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 922
[1:1:0712/094933.061552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7fdfc5a6e070 0x24f7a0eb6560 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 863 0x7fdfc5a6e070 0x24f7a0feec60 
[1:1:0712/094933.124501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 872, 7fdfc83b38db
[1:1:0712/094933.162522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"802 0x7fdfc5a6e070 0x24f7a1062e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.162811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"802 0x7fdfc5a6e070 0x24f7a1062e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.163221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 923
[1:1:0712/094933.163420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7fdfc5a6e070 0x24f79ffd3ee0 , 5:3_http://wzwei.zxart.cn/, 0, , 872 0x7fdfc5a6e070 0x24f7a0304c60 
[1:1:0712/094933.163671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.164244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094933.164495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.216398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , document.readyState
[1:1:0712/094933.216715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.317797:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 857, 7fdfc83b38db
[1:1:0712/094933.355030:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"789 0x7fdfc79962e0 0x24f7a0d13e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.355279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"789 0x7fdfc79962e0 0x24f7a0d13e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.355526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 931
[1:1:0712/094933.355646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7fdfc5a6e070 0x24f79ffd3260 , 5:3_http://wzwei.zxart.cn/, 0, , 857 0x7fdfc5a6e070 0x24f7a0f5a7e0 
[1:1:0712/094933.355808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.356180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094933.356378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.440190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 886, 7fdfc83b3881
[1:1:0712/094933.454342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.454537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.454756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.455044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){Xn=t}
[1:1:0712/094933.455183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.500112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 887, 7fdfc83b38db
[1:1:0712/094933.543068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.543481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.543992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 932
[1:1:0712/094933.544263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7fdfc5a6e070 0x24f7a109c560 , 5:3_http://wzwei.zxart.cn/, 0, , 887 0x7fdfc5a6e070 0x24f7a15dfd60 
[1:1:0712/094933.544601:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.545225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094933.545466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.559198:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 809, 7fdfc83b3881
[1:1:0712/094933.584215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"755 0x7fdfc5a6e070 0x24f7a0d57360 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.584413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"755 0x7fdfc5a6e070 0x24f7a0d57360 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094933.584639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094933.584967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){f.next();}
[1:1:0712/094933.585074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094933.636236:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094933.636516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094933.636910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 935
[1:1:0712/094933.637169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7fdfc5a6e070 0x24f7a16390e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 809 0x7fdfc5a6e070 0x24f7a0f91de0 
[1:1:0712/094933.684254:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 13
[1:1:0712/094933.684537:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 936
[1:1:0712/094933.684659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7fdfc5a6e070 0x24f7a0fb2b60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 809 0x7fdfc5a6e070 0x24f7a0f91de0 
[1:1:0712/094934.102541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://wzwei.zxart.cn/"
[1:1:0712/094934.102977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/094934.103090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.132923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://wzwei.zxart.cn/"
[1:1:0712/094934.133419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/094934.133561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.134590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094934.135095:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://wzwei.zxart.cn/"
[1:1:0712/094934.152034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://wzwei.zxart.cn/"
[1:1:0712/094934.152758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faffaf0
[1:1:0712/094934.152869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094934.153046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 947
[1:1:0712/094934.153161:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7fdfc5a6e070 0x24f7a10703e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 918 0x7fdfc5a6e070 0x24f79f611e60 
[1:1:0712/094934.351483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 923, 7fdfc83b38db
[1:1:0712/094934.391161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"872 0x7fdfc5a6e070 0x24f7a0304c60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.391483:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"872 0x7fdfc5a6e070 0x24f7a0304c60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.391914:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 963
[1:1:0712/094934.392115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 963 0x7fdfc5a6e070 0x24f7a1639160 , 5:3_http://wzwei.zxart.cn/, 0, , 923 0x7fdfc5a6e070 0x24f79ffd3ee0 
[1:1:0712/094934.392420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094934.392905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094934.393088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.434427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , document.readyState
[1:1:0712/094934.434679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.554329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 935, 7fdfc83b3881
[1:1:0712/094934.567364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"809 0x7fdfc5a6e070 0x24f7a0f91de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.567568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"809 0x7fdfc5a6e070 0x24f7a0f91de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.567792:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094934.568087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){Xn=t}
[1:1:0712/094934.568202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.568660:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 931, 7fdfc83b38db
[1:1:0712/094934.608645:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"857 0x7fdfc5a6e070 0x24f7a0f5a7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.609009:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"857 0x7fdfc5a6e070 0x24f7a0f5a7e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.609561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 969
[1:1:0712/094934.609826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7fdfc5a6e070 0x24f79fd733e0 , 5:3_http://wzwei.zxart.cn/, 0, , 931 0x7fdfc5a6e070 0x24f79ffd3260 
[1:1:0712/094934.610183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094934.610801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094934.611027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.664977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 936, 7fdfc83b38db
[1:1:0712/094934.706705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"809 0x7fdfc5a6e070 0x24f7a0f91de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.707027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"809 0x7fdfc5a6e070 0x24f7a0f91de0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.707460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 971
[1:1:0712/094934.707657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7fdfc5a6e070 0x24f7a0fa39e0 , 5:3_http://wzwei.zxart.cn/, 0, , 936 0x7fdfc5a6e070 0x24f7a0fb2b60 
[1:1:0712/094934.707905:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094934.708418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094934.708601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.728152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094934.728376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 3000
[1:1:0712/094934.728732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 972
[1:1:0712/094934.728924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7fdfc5a6e070 0x24f7a02502e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 936 0x7fdfc5a6e070 0x24f7a0fb2b60 
[1:1:0712/094934.949149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 947, 7fdfc83b3881
[1:1:0712/094934.988546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"918 0x7fdfc5a6e070 0x24f79f611e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.988862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"918 0x7fdfc5a6e070 0x24f79f611e60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094934.989233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094934.989861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094934.990057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094934.990690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094934.990862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094934.991175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 978
[1:1:0712/094934.991364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7fdfc5a6e070 0x24f7a15fbbe0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 947 0x7fdfc5a6e070 0x24f7a10703e0 
[1:1:0712/094935.194796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 963, 7fdfc83b38db
[1:1:0712/094935.234431:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"923 0x7fdfc5a6e070 0x24f79ffd3ee0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.234698:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"923 0x7fdfc5a6e070 0x24f79ffd3ee0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.235100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 984
[1:1:0712/094935.235295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7fdfc5a6e070 0x24f7a0fb26e0 , 5:3_http://wzwei.zxart.cn/, 0, , 963 0x7fdfc5a6e070 0x24f7a1639160 
[1:1:0712/094935.235575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094935.236057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094935.236232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094935.495459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 969, 7fdfc83b38db
[1:1:0712/094935.511822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"931 0x7fdfc5a6e070 0x24f79ffd3260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.511983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"931 0x7fdfc5a6e070 0x24f79ffd3260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.512203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 998
[1:1:0712/094935.512314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7fdfc5a6e070 0x24f79fc70560 , 5:3_http://wzwei.zxart.cn/, 0, , 969 0x7fdfc5a6e070 0x24f79fd733e0 
[1:1:0712/094935.512466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094935.512756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094935.512867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094935.562715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 978, 7fdfc83b3881
[1:1:0712/094935.621244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"947 0x7fdfc5a6e070 0x24f7a10703e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.621548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"947 0x7fdfc5a6e070 0x24f7a10703e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.621956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094935.622449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094935.622643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094935.623247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094935.623404:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094935.623766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1000
[1:1:0712/094935.623959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7fdfc5a6e070 0x24f7a02415e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 978 0x7fdfc5a6e070 0x24f7a15fbbe0 
[1:1:0712/094935.742280:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 885, 7fdfc83b38db
[1:1:0712/094935.784365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.784627:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"785 0x7fdfc5a6e070 0x24f7a0fc7a60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.785036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1005
[1:1:0712/094935.785235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7fdfc5a6e070 0x24f7a15fb9e0 , 5:3_http://wzwei.zxart.cn/, 0, , 885 0x7fdfc5a6e070 0x24f7a1471260 
[1:1:0712/094935.785571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094935.786098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094935.786284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094935.822530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094935.822740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094935.823096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1006
[1:1:0712/094935.823293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7fdfc5a6e070 0x24f7a1629360 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 885 0x7fdfc5a6e070 0x24f7a1471260 
[1:1:0712/094935.836788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 13
[1:1:0712/094935.837129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1007
[1:1:0712/094935.837326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7fdfc5a6e070 0x24f7a162b2e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 885 0x7fdfc5a6e070 0x24f7a1471260 
[1:1:0712/094935.854534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 895, 7fdfc83b38db
[1:1:0712/094935.897570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"791 0x7fdfc5a6e070 0x24f7a0fccb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.897840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"791 0x7fdfc5a6e070 0x24f7a0fccb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094935.898251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1012
[1:1:0712/094935.898452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7fdfc5a6e070 0x24f79fddf0e0 , 5:3_http://wzwei.zxart.cn/, 0, , 895 0x7fdfc5a6e070 0x24f7a0f95de0 
[1:1:0712/094935.898761:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094935.899226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , time, (){
		currentNum = $(el).find('.select').html();
		if(currentNum == num){
			move.animate({left:'
[1:1:0712/094935.899395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094935.979164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 984, 7fdfc83b38db
[1:1:0712/094936.023463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"963 0x7fdfc5a6e070 0x24f7a1639160 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.023826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"963 0x7fdfc5a6e070 0x24f7a1639160 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.024227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1015
[1:1:0712/094936.024417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7fdfc5a6e070 0x24f7a0107ce0 , 5:3_http://wzwei.zxart.cn/, 0, , 984 0x7fdfc5a6e070 0x24f7a0fb26e0 
[1:1:0712/094936.024756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.025206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094936.025373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094936.426506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 998, 7fdfc83b38db
[1:1:0712/094936.467740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"969 0x7fdfc5a6e070 0x24f79fd733e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.468047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"969 0x7fdfc5a6e070 0x24f79fd733e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.468449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1025
[1:1:0712/094936.468648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7fdfc5a6e070 0x24f7a16a6ae0 , 5:3_http://wzwei.zxart.cn/, 0, , 998 0x7fdfc5a6e070 0x24f79fc70560 
[1:1:0712/094936.469009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.469533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094936.469747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094936.471686:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1000, 7fdfc83b3881
[1:1:0712/094936.512395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"978 0x7fdfc5a6e070 0x24f7a15fbbe0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.512663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"978 0x7fdfc5a6e070 0x24f7a15fbbe0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.513066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.513544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094936.513718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094936.514329:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094936.514502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094936.514809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1026
[1:1:0712/094936.515022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7fdfc5a6e070 0x24f7a16ade60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1000 0x7fdfc5a6e070 0x24f7a02415e0 
[1:1:0712/094936.667330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1006, 7fdfc83b3881
[1:1:0712/094936.710876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"885 0x7fdfc5a6e070 0x24f7a1471260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.711323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"885 0x7fdfc5a6e070 0x24f7a1471260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.711776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.712340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){Xn=t}
[1:1:0712/094936.712537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094936.713816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1007, 7fdfc83b38db
[1:1:0712/094936.742290:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"885 0x7fdfc5a6e070 0x24f7a1471260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.742433:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"885 0x7fdfc5a6e070 0x24f7a1471260 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.742631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1037
[1:1:0712/094936.742744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7fdfc5a6e070 0x24f7a16ba360 , 5:3_http://wzwei.zxart.cn/, 0, , 1007 0x7fdfc5a6e070 0x24f7a162b2e0 
[1:1:0712/094936.743002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.743288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094936.743402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094936.788974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1015, 7fdfc83b38db
[1:1:0712/094936.802074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"984 0x7fdfc5a6e070 0x24f7a0fb26e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.802223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"984 0x7fdfc5a6e070 0x24f7a0fb26e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094936.802451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1044
[1:1:0712/094936.802581:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7fdfc5a6e070 0x24f7a16a1360 , 5:3_http://wzwei.zxart.cn/, 0, , 1015 0x7fdfc5a6e070 0x24f7a0107ce0 
[1:1:0712/094936.802761:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094936.803045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094936.803160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.071999:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1026, 7fdfc83b3881
[1:1:0712/094937.115589:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"1000 0x7fdfc5a6e070 0x24f7a02415e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.115887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"1000 0x7fdfc5a6e070 0x24f7a02415e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.116332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.116856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094937.117066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.117702:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094937.117874:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094937.118223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1048
[1:1:0712/094937.118453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7fdfc5a6e070 0x24f7a16c1460 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1026 0x7fdfc5a6e070 0x24f7a16ade60 
[1:1:0712/094937.163921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1025, 7fdfc83b38db
[1:1:0712/094937.207618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"998 0x7fdfc5a6e070 0x24f79fc70560 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.207911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"998 0x7fdfc5a6e070 0x24f79fc70560 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.208390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1049
[1:1:0712/094937.208598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1049 0x7fdfc5a6e070 0x24f7a16ad5e0 , 5:3_http://wzwei.zxart.cn/, 0, , 1025 0x7fdfc5a6e070 0x24f7a16a6ae0 
[1:1:0712/094937.208928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.209468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094937.209697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.344327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1037, 7fdfc83b38db
[1:1:0712/094937.400234:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1007 0x7fdfc5a6e070 0x24f7a162b2e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.400593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1007 0x7fdfc5a6e070 0x24f7a162b2e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.401148:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1058
[1:1:0712/094937.401409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7fdfc5a6e070 0x24f7a16a28e0 , 5:3_http://wzwei.zxart.cn/, 0, , 1037 0x7fdfc5a6e070 0x24f7a16ba360 
[1:1:0712/094937.401851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.402470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094937.402698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.464265:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1044, 7fdfc83b38db
[1:1:0712/094937.477404:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1015 0x7fdfc5a6e070 0x24f7a0107ce0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.477550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1015 0x7fdfc5a6e070 0x24f7a0107ce0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.477776:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1061
[1:1:0712/094937.477895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7fdfc5a6e070 0x24f7a10624e0 , 5:3_http://wzwei.zxart.cn/, 0, , 1044 0x7fdfc5a6e070 0x24f7a16a1360 
[1:1:0712/094937.478098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.478370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094937.478479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.481297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1048, 7fdfc83b3881
[1:1:0712/094937.494713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"1026 0x7fdfc5a6e070 0x24f7a16ade60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.494856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"1026 0x7fdfc5a6e070 0x24f7a16ade60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.495086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.495370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094937.495478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.495773:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094937.495875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094937.496045:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1062
[1:1:0712/094937.496216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7fdfc5a6e070 0x24f7a023bb60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1048 0x7fdfc5a6e070 0x24f7a16c1460 
[1:1:0712/094937.691413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1061, 7fdfc83b38db
[1:1:0712/094937.741459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1044 0x7fdfc5a6e070 0x24f7a16a1360 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.741761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1044 0x7fdfc5a6e070 0x24f7a16a1360 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.742233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1073
[1:1:0712/094937.742440:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7fdfc5a6e070 0x24f7a024bb60 , 5:3_http://wzwei.zxart.cn/, 0, , 1061 0x7fdfc5a6e070 0x24f7a10624e0 
[1:1:0712/094937.742768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.743287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094937.743476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.745649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1062, 7fdfc83b3881
[1:1:0712/094937.790834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"1048 0x7fdfc5a6e070 0x24f7a16c1460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.791112:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"1048 0x7fdfc5a6e070 0x24f7a16c1460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.791524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.792015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094937.792262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.792896:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094937.793058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094937.793405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1077
[1:1:0712/094937.793605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7fdfc5a6e070 0x24f7a023b460 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1062 0x7fdfc5a6e070 0x24f7a023bb60 
[1:1:0712/094937.840369:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1049, 7fdfc83b38db
[1:1:0712/094937.885088:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1025 0x7fdfc5a6e070 0x24f7a16a6ae0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.885365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1025 0x7fdfc5a6e070 0x24f7a16a6ae0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.885795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1080
[1:1:0712/094937.885998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7fdfc5a6e070 0x24f7a16a6ce0 , 5:3_http://wzwei.zxart.cn/, 0, , 1049 0x7fdfc5a6e070 0x24f7a16ad5e0 
[1:1:0712/094937.886334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.886802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094937.887019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094937.963751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 972, 7fdfc83b3881
[1:1:0712/094937.977475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"936 0x7fdfc5a6e070 0x24f7a0fb2b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.977639:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"936 0x7fdfc5a6e070 0x24f7a0fb2b60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094937.977829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094937.978104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){f.next();}
[1:1:0712/094937.978243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.002070:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094938.002283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 0
[1:1:0712/094938.002623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1083
[1:1:0712/094938.002831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7fdfc5a6e070 0x24f7a16f3de0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 972 0x7fdfc5a6e070 0x24f7a02502e0 
[1:1:0712/094938.062303:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 13
[1:1:0712/094938.062781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1084
[1:1:0712/094938.063037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7fdfc5a6e070 0x24f7a05b0660 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 972 0x7fdfc5a6e070 0x24f7a02502e0 
[1:1:0712/094938.124980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1073, 7fdfc83b38db
[1:1:0712/094938.183752:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1061 0x7fdfc5a6e070 0x24f7a10624e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.184107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1061 0x7fdfc5a6e070 0x24f7a10624e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.184803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1095
[1:1:0712/094938.185053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7fdfc5a6e070 0x24f7a169c6e0 , 5:3_http://wzwei.zxart.cn/, 0, , 1073 0x7fdfc5a6e070 0x24f7a024bb60 
[1:1:0712/094938.185553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.186184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094938.186430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.226682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1077, 7fdfc83b3881
[1:1:0712/094938.240195:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"1062 0x7fdfc5a6e070 0x24f7a023bb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.240381:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"1062 0x7fdfc5a6e070 0x24f7a023bb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.240608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.240911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094938.241017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.241398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094938.241600:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094938.241980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1101
[1:1:0712/094938.242230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7fdfc5a6e070 0x24f7a176b460 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1077 0x7fdfc5a6e070 0x24f7a023b460 
[1:1:0712/094938.242891:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1083, 7fdfc83b3881
[1:1:0712/094938.255987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"972 0x7fdfc5a6e070 0x24f7a02502e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.256123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"972 0x7fdfc5a6e070 0x24f7a02502e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.256354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.256587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){Xn=t}
[1:1:0712/094938.256690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.329194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1084, 7fdfc83b38db
[1:1:0712/094938.371976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"972 0x7fdfc5a6e070 0x24f7a02502e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.372255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"972 0x7fdfc5a6e070 0x24f7a02502e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.372755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1102
[1:1:0712/094938.372950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7fdfc5a6e070 0x24f7a16f3060 , 5:3_http://wzwei.zxart.cn/, 0, , 1084 0x7fdfc5a6e070 0x24f7a05b0660 
[1:1:0712/094938.373255:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.373851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094938.374075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.821424:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1095, 7fdfc83b38db
[1:1:0712/094938.867846:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1073 0x7fdfc5a6e070 0x24f7a024bb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.868133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1073 0x7fdfc5a6e070 0x24f7a024bb60 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.868556:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1118
[1:1:0712/094938.868765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1118 0x7fdfc5a6e070 0x24f7a16a80e0 , 5:3_http://wzwei.zxart.cn/, 0, , 1095 0x7fdfc5a6e070 0x24f7a169c6e0 
[1:1:0712/094938.869135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.869665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , D, (){T>0?k.Step=Math.ceil((k.ScrollStep-d)*T):0;y[L]()}
[1:1:0712/094938.869852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.912700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1101, 7fdfc83b3881
[1:1:0712/094938.935239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"31cb513e2860","ptid":"1077 0x7fdfc5a6e070 0x24f7a023b460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.935400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://wzwei.zxart.cn/","ptid":"1077 0x7fdfc5a6e070 0x24f7a023b460 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.935659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.935975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/094938.936084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.936394:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094938.936532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 100
[1:1:0712/094938.936707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1121
[1:1:0712/094938.936819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7fdfc5a6e070 0x24f7a16bad60 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1101 0x7fdfc5a6e070 0x24f7a176b460 
[1:1:0712/094938.937267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1102, 7fdfc83b38db
[1:1:0712/094938.965539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1084 0x7fdfc5a6e070 0x24f7a05b0660 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.965787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1084 0x7fdfc5a6e070 0x24f7a05b0660 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094938.966204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1122
[1:1:0712/094938.966408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1122 0x7fdfc5a6e070 0x24f7a16a8ae0 , 5:3_http://wzwei.zxart.cn/, 0, , 1102 0x7fdfc5a6e070 0x24f7a16f3060 
[1:1:0712/094938.966776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094938.967230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/094938.967425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094938.986622:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2d43e22429c8, 0x24f79faff950
[1:1:0712/094938.986804:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://wzwei.zxart.cn/", 3000
[1:1:0712/094938.987129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://wzwei.zxart.cn/, 1123
[1:1:0712/094938.987326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7fdfc5a6e070 0x24f7a16f34e0 , 5:3_http://wzwei.zxart.cn/, 1, -5:3_http://wzwei.zxart.cn/, 1102 0x7fdfc5a6e070 0x24f7a16f3060 
[1:1:0712/094939.054071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1080, 7fdfc83b38db
[1:1:0712/094939.100515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1049 0x7fdfc5a6e070 0x24f7a16ad5e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094939.100774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1049 0x7fdfc5a6e070 0x24f7a16ad5e0 ","rf":"5:3_http://wzwei.zxart.cn/"}
[1:1:0712/094939.101195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1126
[1:1:0712/094939.101400:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7fdfc5a6e070 0x24f7a05f4fe0 , 5:3_http://wzwei.zxart.cn/, 0, , 1080 0x7fdfc5a6e070 0x24f7a16a6ce0 
[1:1:0712/094939.101783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://wzwei.zxart.cn/"
[1:1:0712/094939.102253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://wzwei.zxart.cn/, 31cb513e2860, , , (){document.hasFocus()&&s++}
[1:1:0712/094939.102452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://wzwei.zxart.cn/", "wzwei.zxart.cn", 3, 1, , , 0
[1:1:0712/094939.430828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://wzwei.zxart.cn/, 1118, 7fdfc83b38db
