[0712/095124.301346:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095124.301791:INFO:switcher_clone.cc(787)] backtrace rip is 7f6475b0b891
[0712/095125.092320:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095125.092570:INFO:switcher_clone.cc(787)] backtrace rip is 7f9e34c93891
[1:1:0712/095125.096625:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/095125.096810:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/095125.102018:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[119522:119522:0712/095126.604337:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/095126.625015:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095126.625293:INFO:switcher_clone.cc(787)] backtrace rip is 7f67dc6b1891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f6d8e4b4-e5e8-40af-b54e-8c2607fcbc65
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[119555:119555:0712/095126.804922:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119555
[119567:119567:0712/095126.805331:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=119567
[119522:119522:0712/095126.998365:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[119522:119553:0712/095126.999131:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/095126.999381:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095126.999626:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095127.000247:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095127.000488:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/095127.003396:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e6e4913, 1
[1:1:0712/095127.003734:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xdfc8dd5, 0
[1:1:0712/095127.003900:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x266aef7, 3
[1:1:0712/095127.004062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x120bd90f, 2
[1:1:0712/095127.004256:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd5ffffff8dfffffffc0d 13496e2e 0fffffffd90b12 fffffff7ffffffae6602 , 10104, 4
[1:1:0712/095127.005226:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119522:119553:0712/095127.005506:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGՍ�In.���fK'�<
[119522:119553:0712/095127.005576:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ս�In.���fHsK'�<
[1:1:0712/095127.005498:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e32ece0a0, 3
[1:1:0712/095127.005718:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e33059080, 2
[119522:119553:0712/095127.005900:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/095127.005883:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e1cd1cd20, -2
[119522:119553:0712/095127.005996:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119575, 4, d58dfc0d 13496e2e 0fd90b12 f7ae6602 
[1:1:0712/095127.020914:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095127.021536:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 120bd90f
[1:1:0712/095127.022192:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 120bd90f
[1:1:0712/095127.023227:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 120bd90f
[1:1:0712/095127.023783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.023893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.023984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.024084:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.024314:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 120bd90f
[1:1:0712/095127.024523:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e34c937ba
[1:1:0712/095127.024613:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e34c8adef, 7f9e34c9377a, 7f9e34c950cf
[1:1:0712/095127.026053:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 120bd90f
[1:1:0712/095127.026214:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 120bd90f
[1:1:0712/095127.026510:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 120bd90f
[1:1:0712/095127.027180:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.027289:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.027386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.027508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 120bd90f
[1:1:0712/095127.027949:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 120bd90f
[1:1:0712/095127.028106:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e34c937ba
[1:1:0712/095127.028184:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e34c8adef, 7f9e34c9377a, 7f9e34c950cf
[1:1:0712/095127.030362:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095127.030655:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095127.030754:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd4421e628, 0x7ffd4421e5a8)
[1:1:0712/095127.048347:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095127.055663:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[119522:119522:0712/095127.618760:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095127.620047:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095127.629725:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[119522:119534:0712/095127.629822:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095127.630031:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[119522:119522:0712/095127.630129:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[119522:119522:0712/095127.630306:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,119575, 4
[1:7:0712/095127.636118:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095127.720750:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1827996f2220
[1:1:0712/095127.721027:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[119522:119547:0712/095127.818243:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/095128.078825:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/095129.437675:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095129.442346:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[119522:119522:0712/095129.818163:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[119522:119522:0712/095129.818224:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095130.473476:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095130.763084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095130.763433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095130.770233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095130.770373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095130.852588:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095130.852797:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095131.161759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095131.169887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095131.170208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095131.204509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095131.217558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095131.217981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095131.231532:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[119522:119522:0712/095131.234297:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/095131.237342:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1827996f0e20
[1:1:0712/095131.237754:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[119522:119522:0712/095131.241553:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[119522:119522:0712/095131.272630:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[119522:119522:0712/095131.272780:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095131.314769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095131.992761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f9e1e8f72e0 0x182799980860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095131.994378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/095131.994627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095131.996281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119522:119522:0712/095132.065942:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/095132.068542:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1827996f1820
[1:1:0712/095132.068886:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[119522:119522:0712/095132.072797:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/095132.091106:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/095132.091362:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[119522:119522:0712/095132.092484:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[119522:119522:0712/095132.104546:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095132.105829:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095132.113347:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[119522:119534:0712/095132.113438:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095132.113694:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[119522:119522:0712/095132.113794:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[119522:119522:0712/095132.113964:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,119575, 4
[1:7:0712/095132.116589:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095132.656404:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/095132.931523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f9e1e8f72e0 0x182799877060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095132.932357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/095132.932605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095132.933394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[119522:119522:0712/095132.988190:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[119522:119522:0712/095132.988308:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/095132.992719:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095133.185481:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095133.474919:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095133.475224:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095133.717577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095133.723372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/095133.723839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095133.732418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095133.899564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095133.900524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/095133.900761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[119522:119522:0712/095133.987806:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[119522:119553:0712/095133.988260:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/095133.988453:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095133.988711:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095133.989115:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095133.989304:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/095133.992464:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1c675eb8, 1
[1:1:0712/095133.992856:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x39cc3567, 0
[1:1:0712/095133.993056:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c1a00c0, 3
[1:1:0712/095133.993254:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3777fba, 2
[1:1:0712/095133.993431:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6735ffffffcc39 ffffffb85e671c ffffffba7f7703 ffffffc0001a3c , 10104, 5
[1:1:0712/095133.994830:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[119522:119553:0712/095133.995141:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGg5�9�^g�w�
[119522:119553:0712/095133.995244:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is g5�9�^g�w�
[1:1:0712/095133.995162:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e32ece0a0, 3
[119522:119553:0712/095133.995529:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 119619, 5, 6735cc39 b85e671c ba7f7703 c0001a3c 
[1:1:0712/095133.995439:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e33059080, 2
[1:1:0712/095133.995681:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e1cd1cd20, -2
[1:1:0712/095133.996637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095133.998361:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/095133.998603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/095133.998883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095134.019504:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095134.019910:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3777fba
[1:1:0712/095134.020300:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3777fba
[1:1:0712/095134.020950:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3777fba
[1:1:0712/095134.022401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.022627:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.022846:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.023064:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.023758:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3777fba
[1:1:0712/095134.024101:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e34c937ba
[1:1:0712/095134.024314:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e34c8adef, 7f9e34c9377a, 7f9e34c950cf
[1:1:0712/095134.030111:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3777fba
[1:1:0712/095134.030552:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3777fba
[1:1:0712/095134.031324:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3777fba
[1:1:0712/095134.033461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.033756:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.034007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.034296:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3777fba
[1:1:0712/095134.035590:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3777fba
[1:1:0712/095134.036034:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e34c937ba
[1:1:0712/095134.036289:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e34c8adef, 7f9e34c9377a, 7f9e34c950cf
[1:1:0712/095134.042059:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095134.042583:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095134.042773:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd4421e628, 0x7ffd4421e5a8)
[1:1:0712/095134.057158:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095134.061499:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/095134.167887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095134.168870:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/095134.169091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/095134.169375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095134.345223:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1827996c1220
[1:1:0712/095134.345518:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/095134.785309:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/095134.908972:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/095135.029858:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/095135.123113:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/095135.176332:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/095135.255793:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/095135.336719:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/095135.441736:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/095135.496994:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.497987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095135.498288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.533444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.534420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095135.534727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.595297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.596670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095135.597004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.680533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.681509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095135.681805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.743462:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.744467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095135.744756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.869471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.870443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095135.870768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095135.986747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095135.987789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095135.988082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.009355:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.010284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095136.010555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.059324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.060298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095136.060573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.120405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.121364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095136.121639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.163641:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.164559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095136.164851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.241702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.242784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095136.243077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.293179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.294103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095136.294377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.314163:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.315084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095136.315348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.373177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.374125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/095136.374430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.396457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095136.397402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 06b648f6e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/095136.397698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095136.533357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095136.534744:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0712/095136.534960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 06b648e41f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0712/095136.535175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[119522:119522:0712/095140.909592:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[119522:119522:0712/095140.914752:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[119522:119534:0712/095140.956208:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[119522:119534:0712/095140.956342:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[119522:119522:0712/095140.956702:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://video.zxart.cn/
[119522:119522:0712/095140.956800:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://video.zxart.cn/, http://video.zxart.cn/VideoPlay/239/88106.html, 1
[119522:119522:0712/095140.956987:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://video.zxart.cn/, HTTP/1.1 200 OK Cache-Control: private Content-Type: text/html; charset=utf-8 Content-Encoding: gzip Vary: Accept-Encoding Server: Microsoft-IIS/7.5 X-AspNetMvc-Version: 3.0 X-AspNet-Version: 4.0.30319 Set-Cookie: __RequestVerificationToken_Lw__=oqKobctbzhGfoDl2BUfqmOX9BqRAw/ACYEF8+Z0/An3gF2XrrzBAh7nmvTU59LZm3grYHzaJ3xUEUPcjGsN6ikf/d0s4AOW5Az+Km84RYvxVOlK3qBjEs1qXmeGJe4zRICmjH5P13Te2U2hsd1DEp9hi/VlCcI8V1HWfoFKjLjQ=; path=/; HttpOnly X-Powered-By: ASP.NET Date: Fri, 12 Jul 2019 16:50:41 GMT Content-Length: 22783  ,119619, 5
[1:7:0712/095140.962410:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095140.982414:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://video.zxart.cn/
[1:1:0712/095141.125720:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095141.126581:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[119522:119522:0712/095141.128441:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://video.zxart.cn/, http://video.zxart.cn/, 1
[119522:119522:0712/095141.128544:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://video.zxart.cn/, http://video.zxart.cn
[1:1:0712/095141.185684:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095141.219226:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095141.255603:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095141.255910:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095141.670391:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095142.141558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f9e1cd37bd0 0x18279992d258 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.153102:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095142.161566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , (function(e,t){var n,r,i=typeof t,o=e.document,a=e.location,s=e.jQuery,u=e.$,l={},c=[],p="1.9.1",f=c
[1:1:0712/095142.161742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
		remove user.f_1ec1cd44 -> 0
[1:1:0712/095142.284734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f9e1cd37bd0 0x18279992d258 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.294037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f9e1cd37bd0 0x18279992d258 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.297354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f9e1cd37bd0 0x18279992d258 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.524418:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f9e1c9cf070 0x1827999f1a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.531988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , /* jquery.nicescroll 3.0.0 InuYaksa*2012 MIT http://areaaperta.com/nicescroll */(function(d){var s=f
[1:1:0712/095142.532168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095142.545517:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f9e1c9cf070 0x1827999f1a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.571251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f9e1c9cf070 0x1827999f1a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095142.648618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f9e1c9cf070 0x1827999f1a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095143.642819:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.10438, 2, 0
[1:1:0712/095143.643006:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095144.776557:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095144.779269:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095144.779690:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095144.780162:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095144.780561:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095145.053018:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095145.053179:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.055012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7f9e1c9cf070 0x182799f4a860 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.057498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , /*!
 * jQuery Form Plugin
 * version: 2.84 (12-AUG-2011)
 * @requires jQuery v1.3.2 or later
 *
[1:1:0712/095145.057638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095145.063455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7f9e1c9cf070 0x182799f4a860 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.072328:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7f9e1c9cf070 0x182799f4a860 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.096316:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.043205, 185, 1
[1:1:0712/095145.096607:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095145.789548:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095145.789709:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.790215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 386 0x7f9e1c9cf070 0x182799f3da60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095145.790808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
        function display() {
            document.getElementById("box").style.display = "block";
  
[1:1:0712/095145.790923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095145.796952:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00720787, 65, 1
[1:1:0712/095145.797090:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095146.489253:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095146.489548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095146.490766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f9e1c9cf070 0x182799b874e0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095146.492957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
    $(document).ready(function () {
        
        $(".menu ul li").hover(function () {
         
[1:1:0712/095146.493266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095146.573831:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0841401, 322, 1
[1:1:0712/095146.574151:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095147.728179:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095147.728354:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095147.730615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f9e1c9cf070 0x182799bd58e0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095147.737276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , /*
-------------------------------------------------------------------------
  说明:
  正式�
[1:1:0712/095147.737458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095147.748187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f9e1c9cf070 0x182799bd58e0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095147.893125:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.164774, 338, 1
[1:1:0712/095147.893317:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095148.887108:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095149.180698:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095149.180999:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095149.182232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542 0x7f9e1c9cf070 0x18279991cfe0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095149.185987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
<!--    //--><![CDaTa[//>
    //图片滚动列表 mengjia 070816
    var Speed = 10; //速度(毫�
[1:1:0712/095149.186227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095150.271640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 5000
[1:1:0712/095150.271894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 668
[1:1:0712/095150.272006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f9e1c9cf070 0x18279a474be0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 542 0x7f9e1c9cf070 0x18279991cfe0 
[1:1:0712/095150.272497:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.09117, 0, 0
[1:1:0712/095150.272616:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095151.145886:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095152.631768:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095152.631968:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095152.636079:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0040319, 52, 1
[1:1:0712/095152.636200:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095155.324905:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095155.325068:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095155.325584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 763 0x7f9e1c9cf070 0x18279a3e0f60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095155.326154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
            var xx = window.location.href;
            var sss = create_qrcode(xx, 4, 'L', 4)
     
[1:1:0712/095155.326270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
		remove user.10_70c593ee -> 0
		remove user.11_23627d44 -> 0
		remove user.12_1cfbf0a -> 0
		remove user.13_ebad2194 -> 0
		remove user.14_83f35c25 -> 0
		remove user.11_4e870dce -> 0
[1:1:0712/095203.261519:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095203.262366:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095203.441458:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 8.11644, 0, 0
[1:1:0712/095203.441723:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095206.407147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 668, 7f9e1f3148db
[1:1:0712/095206.453372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"542 0x7f9e1c9cf070 0x18279991cfe0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095206.453787:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"542 0x7f9e1c9cf070 0x18279991cfe0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095206.454348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 993
[1:1:0712/095206.454602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f9e1c9cf070 0x18279a484460 , 5:3_http://video.zxart.cn/, 0, , 668 0x7f9e1c9cf070 0x18279a474be0 
[1:1:0712/095206.454944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095206.455949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , ISL_GoDown();ISL_StopDown();
[1:1:0712/095206.456135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[119522:119522:0712/095206.979716:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[119522:119522:0712/095207.002783:WARNING:one_google_bar_fetcher_impl.cc(315)] Request failed with error: -102: net::ERR_CONNECTION_REFUSED
[3:3:0712/095207.189167:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/095207.906386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095207.906953:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1016
[1:1:0712/095207.907195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f9e1c9cf070 0x18279d157fe0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 668 0x7f9e1c9cf070 0x18279a474be0 
[1:1:0712/095207.911103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095207.911577:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1017
[1:1:0712/095207.911893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f9e1c9cf070 0x18279c49c2e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 668 0x7f9e1c9cf070 0x18279a474be0 
[1:1:0712/095207.912709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 5000
[1:1:0712/095207.913132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1018
[1:1:0712/095207.913363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7f9e1c9cf070 0x18279c8c81e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 668 0x7f9e1c9cf070 0x18279a474be0 
[1:1:0712/095208.302628:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095208.302932:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095208.307926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 883 0x7f9e1c9cf070 0x182799ad4be0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095208.309180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , ,                 window._bd_share_config = { "common": { "bdSnsKey": {}, "bdText": "", "bdMini": "2",
[1:1:0712/095208.309403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095208.331979:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.028863, 70, 1
[1:1:0712/095208.332260:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095211.890162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/095211.890493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095213.058275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1017, 7f9e1f314881
[1:1:0712/095213.104773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"668 0x7f9e1c9cf070 0x18279a474be0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095213.105204:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"668 0x7f9e1c9cf070 0x18279a474be0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095213.105650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095213.106559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095213.106775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095213.313355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095213.313839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1120
[1:1:0712/095213.314092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f9e1c9cf070 0x18279992d2e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1017 0x7f9e1c9cf070 0x18279c49c2e0 
[1:1:0712/095214.145631:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095214.145919:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095214.147619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1038 0x7f9e1c9cf070 0x182799b91ae0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095214.148837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
                    $(".log").attr("href", "http://www.zxart.cn/Login.html?ToUrl=" + window.locatio
[1:1:0712/095214.149081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095214.309569:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.163449, 299, 1
[1:1:0712/095214.309879:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095216.028574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , document.readyState
[1:1:0712/095216.028896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095217.429436:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1018, 7f9e1f3148db
[1:1:0712/095217.483102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"668 0x7f9e1c9cf070 0x18279a474be0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095217.483470:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"668 0x7f9e1c9cf070 0x18279a474be0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095217.484146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1229
[1:1:0712/095217.484399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1229 0x7f9e1c9cf070 0x18279dbd49e0 , 5:3_http://video.zxart.cn/, 0, , 1018 0x7f9e1c9cf070 0x18279c8c81e0 
[1:1:0712/095217.484898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095217.485621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , ISL_GoDown();ISL_StopDown();
[1:1:0712/095217.485835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095217.501058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095217.501564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1230
[1:1:0712/095217.501805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7f9e1c9cf070 0x18279a60a1e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1018 0x7f9e1c9cf070 0x18279c8c81e0 
[1:1:0712/095217.502708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 5000
[1:1:0712/095217.503133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1231
[1:1:0712/095217.503360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1231 0x7f9e1c9cf070 0x18279a46ebe0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1018 0x7f9e1c9cf070 0x18279c8c81e0 
[1:1:0712/095217.982624:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1120, 7f9e1f314881
[1:1:0712/095218.035424:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1017 0x7f9e1c9cf070 0x18279c49c2e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095218.035781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1017 0x7f9e1c9cf070 0x18279c49c2e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095218.036229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095218.036896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095218.037107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095218.050737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095218.051242:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1244
[1:1:0712/095218.051478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1244 0x7f9e1c9cf070 0x182799b038e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1120 0x7f9e1c9cf070 0x18279992d2e0 
[1:1:0712/095218.240561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "progress", "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:2:0712/095218.273419:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095218.381511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143 0x7f9e1e8f72e0 0x18279d2429e0 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095218.384528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/095218.384782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095219.463764:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095219.464027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095219.465081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1161 0x7f9e1c9cf070 0x18279d583a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095219.466241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
    $(function () {
        var slideHeight = 95; // px
        var defHeight = $('#wrap').height()
[1:1:0712/095219.466471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095219.476106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1161 0x7f9e1c9cf070 0x18279d583a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095219.526851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1161 0x7f9e1c9cf070 0x18279d583a60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095219.574007:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.109872, 86, 1
[1:1:0712/095219.574307:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095220.632428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , document.readyState
[1:1:0712/095220.632777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095222.579596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1230, 7f9e1f314881
[1:1:0712/095222.601338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1018 0x7f9e1c9cf070 0x18279c8c81e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095222.601694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1018 0x7f9e1c9cf070 0x18279c8c81e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095222.602086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095222.602924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095222.603204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095222.615076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095222.615477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1361
[1:1:0712/095222.615650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1361 0x7f9e1c9cf070 0x18279e0d31e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1230 0x7f9e1c9cf070 0x18279a60a1e0 
[1:1:0712/095222.844263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1244, 7f9e1f314881
[1:1:0712/095222.877053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1120 0x7f9e1c9cf070 0x18279992d2e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095222.877487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1120 0x7f9e1c9cf070 0x18279992d2e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095222.878006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095222.878858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095222.879110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095222.901661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095222.902264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1377
[1:1:0712/095222.902545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1377 0x7f9e1c9cf070 0x18279e0df060 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1244 0x7f9e1c9cf070 0x182799b038e0 
[1:1:0712/095223.922225:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095223.922452:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095223.926986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1278 0x7f9e1c9cf070 0x18279d5a1e60 , "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095223.928463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , 
var KX_cfg_data = { cnnic_dn : '', cnnic_lang : 'zh_cn' };

KX_cfg_data.cnnic_sn = "e14031835020
[1:1:0712/095223.928752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095223.948600:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095224.117218:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1b8e0ef629c8, 0x182799215440
[1:1:0712/095224.117474:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 3000
[1:1:0712/095224.117897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1442
[1:1:0712/095224.118105:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1442 0x7f9e1c9cf070 0x18279a3e2c60 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095224.293584:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10000
[1:1:0712/095224.294203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1450
[1:1:0712/095224.294464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1450 0x7f9e1c9cf070 0x18279e114c60 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095224.615116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b8e0ef629c8, 0x182799215440
[1:1:0712/095224.615415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 0
[1:1:0712/095224.615952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1460
[1:1:0712/095224.616215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1460 0x7f9e1c9cf070 0x18279a60a960 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095224.968548:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b8e0ef629c8, 0x182799215440
[1:1:0712/095224.968790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 0
[1:1:0712/095224.969211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1472
[1:1:0712/095224.969430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1472 0x7f9e1c9cf070 0x18279e19aae0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.639771:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095225.672778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.673094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.673599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1496
[1:1:0712/095225.673851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1496 0x7f9e1c9cf070 0x182799af38e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.690227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.690496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.690991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1497
[1:1:0712/095225.691264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1497 0x7f9e1c9cf070 0x18279e0103e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.698161:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.698333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.698529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1500
[1:1:0712/095225.698656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1500 0x7f9e1c9cf070 0x18279a68ca60 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.705106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.705254:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.705438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1503
[1:1:0712/095225.705556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1503 0x7f9e1c9cf070 0x18279d257860 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.710662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.710806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.710984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1506
[1:1:0712/095225.711159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1506 0x7f9e1c9cf070 0x18279d3294e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.716127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.716271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 15000
[1:1:0712/095225.716456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1508
[1:1:0712/095225.716570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1508 0x7f9e1c9cf070 0x18279d5a08e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095225.719162:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1b8e0ef629c8, 0x1827992151e0
[1:1:0712/095225.719309:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 3000
[1:1:0712/095225.719492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1510
[1:1:0712/095225.719617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1510 0x7f9e1c9cf070 0x18279d169760 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1278 0x7f9e1c9cf070 0x18279d5a1e60 
[1:1:0712/095226.630926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , document.readyState
[1:1:0712/095226.631249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095227.900319:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "animationend", "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095227.902758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , (){b.onsync=false;for(f in b.synclist){var c=b.synclist[f];c&&c.call(b);b.synclist[f]=false}}
[1:1:0712/095227.903027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095227.911819:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b8e0ef629c8, 0x1827992153b8
[1:1:0712/095227.912093:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 0
[1:1:0712/095227.912543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1619
[1:1:0712/095227.912886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1619 0x7f9e1c9cf070 0x18279e0b7be0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1334 0x7f9e2bce0960 0x18279b4b9e20 0x18279b4b9e30 
[1:1:0712/095227.917538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b8e0ef629c8, 0x182799215288
[1:1:0712/095227.917816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 0
[1:1:0712/095227.918269:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1620
[1:1:0712/095227.918512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1620 0x7f9e1c9cf070 0x18279e0e7de0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1334 0x7f9e2bce0960 0x18279b4b9e20 0x18279b4b9e30 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[119522:119522:0712/095229.205267:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/095229.790759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1231, 7f9e1f3148db
[1:1:0712/095229.881531:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1018 0x7f9e1c9cf070 0x18279c8c81e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095229.881950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1018 0x7f9e1c9cf070 0x18279c8c81e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095229.882466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1707
[1:1:0712/095229.882733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1707 0x7f9e1c9cf070 0x18279a68c260 , 5:3_http://video.zxart.cn/, 0, , 1231 0x7f9e1c9cf070 0x18279a46ebe0 
[1:1:0712/095229.883135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095229.883896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , ISL_GoDown();ISL_StopDown();
[1:1:0712/095229.884227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095229.906353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095229.906935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1709
[1:1:0712/095229.907254:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1709 0x7f9e1c9cf070 0x182799b038e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1231 0x7f9e1c9cf070 0x18279a46ebe0 
[1:1:0712/095229.908073:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 5000
[1:1:0712/095229.908549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://video.zxart.cn/, 1710
[1:1:0712/095229.908824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1710 0x7f9e1c9cf070 0x18279e0e26e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1231 0x7f9e1c9cf070 0x18279a46ebe0 
[1:1:0712/095230.108109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1361, 7f9e1f314881
[1:1:0712/095230.183214:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1230 0x7f9e1c9cf070 0x18279a60a1e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095230.183618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1230 0x7f9e1c9cf070 0x18279a60a1e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095230.184100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095230.184867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095230.185137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095230.199347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095230.199857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1722
[1:1:0712/095230.200092:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1722 0x7f9e1c9cf070 0x18279e0c98e0 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1361 0x7f9e1c9cf070 0x18279e0d31e0 
[1:1:0712/095231.334053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1377, 7f9e1f314881
[1:1:0712/095231.427642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2dcfc3fe2860","ptid":"1244 0x7f9e1c9cf070 0x182799b038e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095231.428023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.zxart.cn/","ptid":"1244 0x7f9e1c9cf070 0x182799b038e0 ","rf":"5:3_http://video.zxart.cn/"}
[1:1:0712/095231.428469:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.zxart.cn/VideoPlay/239/88106.html"
[1:1:0712/095231.429185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.zxart.cn/, 2dcfc3fe2860, , , CompScr()
[1:1:0712/095231.429425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.zxart.cn/VideoPlay/239/88106.html", "video.zxart.cn", 3, 1, , , 0
[1:1:0712/095231.453981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.zxart.cn/VideoPlay/239/88106.html", 10
[1:1:0712/095231.454548:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.zxart.cn/, 1769
[1:1:0712/095231.454823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1769 0x7f9e1c9cf070 0x18279db91d60 , 5:3_http://video.zxart.cn/, 1, -5:3_http://video.zxart.cn/, 1377 0x7f9e1c9cf070 0x18279e0df060 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
