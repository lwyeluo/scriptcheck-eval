[0712/233539.652442:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233539.652878:INFO:switcher_clone.cc(787)] backtrace rip is 7fb159770891
[0712/233540.492801:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233540.493111:INFO:switcher_clone.cc(787)] backtrace rip is 7fe8c8b4e891
[1:1:0712/233540.504609:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/233540.504871:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/233540.509793:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/233541.763812:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233541.764103:INFO:switcher_clone.cc(787)] backtrace rip is 7f2b30a15891
[18701:18701:0712/233541.876099:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/909ea06d-077a-4940-a6a9-c1e26c33111e
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18734:18734:0712/233541.991358:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18734
[18746:18746:0712/233541.991755:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18746
[18701:18701:0712/233542.484780:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18701:18732:0712/233542.485575:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/233542.485798:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233542.486018:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233542.486608:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233542.486764:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/233542.489581:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x462c544, 1
[1:1:0712/233542.489907:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2a90203a, 0
[1:1:0712/233542.490096:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2324755a, 3
[1:1:0712/233542.490306:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x994328b, 2
[1:1:0712/233542.490523:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3a20ffffff902a 44ffffffc56204 ffffff8b32ffffff9409 5a752423 , 10104, 4
[1:1:0712/233542.491484:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18701:18732:0712/233542.491722:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING: �*D�b�2�	Zu$#`�,
[18701:18732:0712/233542.491787:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is : �*D�b�2�	Zu$#��`�,
[1:1:0712/233542.491907:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8c6d890a0, 3
[18701:18732:0712/233542.492056:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[18701:18732:0712/233542.492123:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18754, 4, 3a20902a 44c56204 8b329409 5a752423 
[1:1:0712/233542.492115:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8c6f14080, 2
[1:1:0712/233542.492298:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8b0bd7d20, -2
[1:1:0712/233542.510665:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233542.511497:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 994328b
[1:1:0712/233542.512416:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 994328b
[1:1:0712/233542.513983:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 994328b
[1:1:0712/233542.515475:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.515681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.515858:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.516043:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.516699:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 994328b
[1:1:0712/233542.517003:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8c8b4e7ba
[1:1:0712/233542.517132:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8c8b45def, 7fe8c8b4e77a, 7fe8c8b500cf
[1:1:0712/233542.522862:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 994328b
[1:1:0712/233542.523198:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 994328b
[1:1:0712/233542.523928:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 994328b
[1:1:0712/233542.525975:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.526164:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.526366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.526553:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 994328b
[1:1:0712/233542.527774:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 994328b
[1:1:0712/233542.528126:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8c8b4e7ba
[1:1:0712/233542.528296:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8c8b45def, 7fe8c8b4e77a, 7fe8c8b500cf
[1:1:0712/233542.535990:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233542.536451:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233542.536591:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0d02b418, 0x7ffd0d02b398)
[1:1:0712/233542.553279:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233542.558982:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18701:18701:0712/233543.182541:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18701:18701:0712/233543.184066:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18701:18713:0712/233543.202976:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18701:18713:0712/233543.203101:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[18701:18701:0712/233543.203162:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18701:18701:0712/233543.203258:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18701:18701:0712/233543.203401:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18754, 4
[1:7:0712/233543.205673:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[18701:18724:0712/233543.265765:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/233543.314178:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3ec577a60220
[1:1:0712/233543.314429:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/233543.613894:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/233544.874402:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233544.878355:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18701:18701:0712/233545.406089:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18701:18701:0712/233545.406229:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233545.776657:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233546.092885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233546.093169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233546.109187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233546.109471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233546.189111:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233546.189383:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233546.522921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233546.532027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233546.532299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233546.587787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233546.598495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233546.598833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233546.610550:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18701:18701:0712/233546.613320:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233546.613952:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ec577a5ee20
[1:1:0712/233546.614146:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18701:18701:0712/233546.621301:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18701:18701:0712/233546.653989:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18701:18701:0712/233546.654191:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233546.666830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233547.595990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fe8b27b22e0 0x3ec577a2f5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233547.598832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/233547.599268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233547.602712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18701:18701:0712/233547.661137:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233547.663522:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3ec577a5f820
[1:1:0712/233547.663772:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18701:18701:0712/233547.667802:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/233547.691934:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/233547.692159:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18701:18701:0712/233547.693303:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18701:18701:0712/233547.704273:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18701:18701:0712/233547.705275:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18701:18713:0712/233547.711188:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18701:18713:0712/233547.711274:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18701:18701:0712/233547.711420:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18701:18701:0712/233547.711495:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18701:18701:0712/233547.711626:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18754, 4
[1:7:0712/233547.720936:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233548.356081:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/233548.775377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fe8b27b22e0 0x3ec577e40160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233548.776439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1de65a681f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/233548.776777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233548.777615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233548.926932:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18701:18701:0712/233548.941450:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18701:18701:0712/233548.941555:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/233549.345029:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233550.062537:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233550.062984:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[18701:18701:0712/233550.231444:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18701:18732:0712/233550.232044:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/233550.232223:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233550.232718:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233550.233739:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233550.234021:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/233550.237233:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x16a418c7, 1
[1:1:0712/233550.237659:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f19ad5b, 0
[1:1:0712/233550.237860:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x28dc6a37, 3
[1:1:0712/233550.238057:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x37a4157c, 2
[1:1:0712/233550.238246:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5bffffffad191f ffffffc718ffffffa416 7c15ffffffa437 376affffffdc28 , 10104, 5
[1:1:0712/233550.239237:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18701:18732:0712/233550.239534:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING[���|�77j�(C�,
[18701:18732:0712/233550.239608:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is [���|�77j�(8
[1:1:0712/233550.239720:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8c6d890a0, 3
[18701:18732:0712/233550.239914:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18797, 5, 5bad191f c718a416 7c15a437 376adc28 
[1:1:0712/233550.239961:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8c6f14080, 2
[1:1:0712/233550.240220:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe8b0bd7d20, -2
[1:1:0712/233550.261267:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233550.261971:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37a4157c
[1:1:0712/233550.262490:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37a4157c
[1:1:0712/233550.263551:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37a4157c
[1:1:0712/233550.265817:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.266131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.266457:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.266698:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.267420:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37a4157c
[1:1:0712/233550.267756:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8c8b4e7ba
[1:1:0712/233550.267944:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8c8b45def, 7fe8c8b4e77a, 7fe8c8b500cf
[1:1:0712/233550.273703:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37a4157c
[1:1:0712/233550.274108:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37a4157c
[1:1:0712/233550.274886:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37a4157c
[1:1:0712/233550.276950:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.277218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.277481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.277731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37a4157c
[1:1:0712/233550.278999:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37a4157c
[1:1:0712/233550.279445:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe8c8b4e7ba
[1:1:0712/233550.279660:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe8c8b45def, 7fe8c8b4e77a, 7fe8c8b500cf
[1:1:0712/233550.287444:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233550.287999:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233550.288201:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0d02b418, 0x7ffd0d02b398)
[1:1:0712/233550.302747:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233550.307221:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/233550.355751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233550.360232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1de65a7ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/233550.360526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/233550.369231:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233550.544393:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ec577a37220
[1:1:0712/233550.544657:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18701:18701:0712/233550.634916:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18701:18701:0712/233550.640414:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18701:18713:0712/233550.681490:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18701:18713:0712/233550.681618:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18701:18701:0712/233550.681832:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.dogwood.com.cn/
[18701:18701:0712/233550.681887:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.dogwood.com.cn/, http://www.dogwood.com.cn/, 1
[18701:18701:0712/233550.681993:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.dogwood.com.cn/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 06:35:50 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,18797, 5
[1:7:0712/233550.686026:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233550.751263:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.dogwood.com.cn/
[1:1:0712/233550.908638:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18701:18701:0712/233550.921849:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.dogwood.com.cn/, http://www.dogwood.com.cn/, 1
[18701:18701:0712/233550.921942:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.dogwood.com.cn/, http://www.dogwood.com.cn
[1:1:0712/233551.008945:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233551.186395:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233551.186682:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dogwood.com.cn/"
[1:1:0712/233551.393585:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233551.613242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7fe8c6f14080 0x3ec577a7a420 1 0 0x3ec577a7a438 , "http://www.dogwood.com.cn/"
[1:1:0712/233551.615497:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233551.624687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindo
[1:1:0712/233551.624956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233551.756933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7fe8c6f14080 0x3ec577a7a420 1 0 0x3ec577a7a438 , "http://www.dogwood.com.cn/"
[1:1:0712/233551.783728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151, "http://www.dogwood.com.cn/"
[1:1:0712/233551.785439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (function($) {
    $.fn.xdfhover = function(option) {
        var s = $.extend({
            dela
[1:1:0712/233551.785658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233551.793404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151, "http://www.dogwood.com.cn/"
[1:1:0712/233551.796990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 151, "http://www.dogwood.com.cn/"
[1:1:0712/233551.927564:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.137619, 327, 1
[1:1:0712/233551.927826:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233552.593464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233552.596970:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233552.597417:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233552.597784:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233552.598240:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233552.606138:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233552.606336:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dogwood.com.cn/"
[1:1:0712/233552.607249:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fe8b088a070 0x3ec577d4cb60 , "http://www.dogwood.com.cn/"
[1:1:0712/233552.608785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , 
             $(".close").click(function () {
                 $("#notification").hide();
          
[1:1:0712/233552.609019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233552.816924:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.210514, 1193, 1
[1:1:0712/233552.817197:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233553.093468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233553.093703:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dogwood.com.cn/"
[1:1:0712/233553.094495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7fe8b088a070 0x3ec577dde4e0 , "http://www.dogwood.com.cn/"
[1:1:0712/233553.095435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , ,  
jQuery(function($) {
$('#xdfpos_7 a').click(
	function(){
		var t = $(this).text();
		_gaq.push(['
[1:1:0712/233553.095648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233553.100122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7fe8b088a070 0x3ec577dde4e0 , "http://www.dogwood.com.cn/"
[1:1:0712/233553.109812:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7fe8b088a070 0x3ec577dde4e0 , "http://www.dogwood.com.cn/"
[1:1:0712/233555.199954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 , "http://www.dogwood.com.cn/"
[1:1:0712/233555.209591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (function(){var h={},mt={},c={id:"6f8e3450a1d093ce2911c448001a6538",dm:["dogwood.com.cn"],js:"tongji
[1:1:0712/233555.209836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233555.243514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad160
[1:1:0712/233555.243756:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233555.244135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 388
[1:1:0712/233555.244362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7fe8b088a070 0x3ec577bc7060 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 
[18701:18701:0712/233629.624855:INFO:CONSOLE(1141)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?6f8e3450a1d093ce2911c448001a6538, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.dogwood.com.cn/ (1141)
[18701:18701:0712/233629.629045:INFO:CONSOLE(1141)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?6f8e3450a1d093ce2911c448001a6538, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.dogwood.com.cn/ (1141)
[18701:18701:0712/233629.681623:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/233629.749844:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/233629.801751:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233631.125837:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 600000
[1:1:0712/233631.126267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 483
[1:1:0712/233631.126502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7fe8b088a070 0x3ec5783cef60 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 
[1:1:0712/233631.127388:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 5000
[1:1:0712/233631.127828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 484
[1:1:0712/233631.128111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7fe8b088a070 0x3ec578092a60 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 
[1:1:0712/233631.173849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 , "http://www.dogwood.com.cn/"
[1:1:0712/233631.191532:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18701:18701:0712/233631.193594:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233631.196059:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3ec577643820
[1:1:0712/233631.196325:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18701:18701:0712/233631.200204:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/233631.230730:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/233631.230954:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.dogwood.com.cn
[18701:18701:0712/233631.232938:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.dogwood.com.cn/
[1:1:0712/233631.235239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.dogwood.com.cn/"
[18701:18701:0712/233631.319534:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18701:18701:0712/233631.324552:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18701:18713:0712/233631.372042:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[18701:18713:0712/233631.372141:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[18701:18701:0712/233631.372397:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://count32.51yes.com/
[18701:18701:0712/233631.372498:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://count32.51yes.com/, http://count32.51yes.com/sa.htm?id=329612541&refe=&location=http%3A//www.dogwood.com.cn/&color=24x&resolution=1276x647&returning=0&language=undefined&ua=Mozilla/5.0%20%28X11%3B%20Linux%20x86_64%29%20AppleWebKit/537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome/67.0.3391.0%20Safari/537.36, 4
[18701:18701:0712/233631.372682:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://count32.51yes.com/, HTTP/1.1 200 OK Date: Sat, 13 Jul 2019 06:36:55 GMT Server: Microsoft-IIS/6.0 X-Powered-By: ASP.NET X-AspNet-Version: 1.1.4322 Cache-Control: private Content-Length: 0  ,18797, 5
[1:7:0712/233631.375052:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233631.479792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 4000
[1:1:0712/233631.480318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 515
[1:1:0712/233631.480587:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7fe8b088a070 0x3ec5782700e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 380 0x7fe8b0bf2bd0 0x3ec577fbeb58 
[1:1:0712/233632.220948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.dogwood.com.cn/"
[1:1:0712/233633.074282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/233633.074650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233635.081318:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://count32.51yes.com/
[1:1:0712/233635.137661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 388, 7fe8b31cf881
[1:1:0712/233635.145959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233635.146200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233635.146484:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233635.146894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233635.147072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233635.147589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233635.147731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233635.148034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 600
[1:1:0712/233635.148192:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7fe8b088a070 0x3ec5780924e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 388 0x7fe8b088a070 0x3ec577bc7060 
[1:1:0712/233635.799653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233635.799889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[18701:18701:0712/233637.382924:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://count32.51yes.com/, http://count32.51yes.com/, 4
[18701:18701:0712/233637.383033:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://count32.51yes.com/, http://count32.51yes.com
[1:1:0712/233637.396188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 600, 7fe8b31cf881
[1:1:0712/233637.431361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"388 0x7fe8b088a070 0x3ec577bc7060 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233637.431755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"388 0x7fe8b088a070 0x3ec577bc7060 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233637.432189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233637.432837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233637.433133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233637.433926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233637.434139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233637.434516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 731
[1:1:0712/233637.434765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7fe8b088a070 0x3ec578c2d4e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 600 0x7fe8b088a070 0x3ec5780924e0 
[1:1:0712/233637.707317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 515, 7fe8b31cf8db
[1:1:0712/233637.723931:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233637.724270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233637.724787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 741
[1:1:0712/233637.725037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7fe8b088a070 0x3ec5782a9fe0 , 5:3_http://www.dogwood.com.cn/, 0, , 515 0x7fe8b088a070 0x3ec5782700e0 
[1:1:0712/233637.725349:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233637.725898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233637.726118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233637.777577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233637.777864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233637.778233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 742
[1:1:0712/233637.778460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7fe8b088a070 0x3ec577d15560 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 515 0x7fe8b088a070 0x3ec5782700e0 
[1:1:0712/233637.783759:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 13
[1:1:0712/233637.784130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 743
[1:1:0712/233637.784358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7fe8b088a070 0x3ec57a15fae0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 515 0x7fe8b088a070 0x3ec5782700e0 
[1:1:0712/233638.346189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233638.346475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233638.980178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 484, 7fe8b31cf8db
[1:1:0712/233639.012944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233639.013316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"380 0x7fe8b0bf2bd0 0x3ec577fbeb58 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233639.013760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 790
[1:1:0712/233639.014003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7fe8b088a070 0x3ec5782437e0 , 5:3_http://www.dogwood.com.cn/, 0, , 484 0x7fe8b088a070 0x3ec578092a60 
[1:1:0712/233639.014315:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233639.014909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/233639.015141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233640.343461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dogwood.com.cn/"
[1:1:0712/233640.344165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0712/233640.344380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233640.712653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 731, 7fe8b31cf881
[1:1:0712/233640.746909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"600 0x7fe8b088a070 0x3ec5780924e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233640.747207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"600 0x7fe8b088a070 0x3ec5780924e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233640.747593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233640.748179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233640.748352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233640.749026:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233640.749187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233640.749542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 828
[1:1:0712/233640.749734:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7fe8b088a070 0x3ec57a184660 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 731 0x7fe8b088a070 0x3ec578c2d4e0 
[1:1:0712/233640.973523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 742, 7fe8b31cf881
[1:1:0712/233641.008121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233641.008418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233641.008815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233641.009311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , cs, (){cq=b}
[1:1:0712/233641.009489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233641.045736:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 743, 7fe8b31cf8db
[1:1:0712/233641.080119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233641.080430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233641.080864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 836
[1:1:0712/233641.081057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7fe8b088a070 0x3ec57a15f460 , 5:3_http://www.dogwood.com.cn/, 0, , 743 0x7fe8b088a070 0x3ec57a15fae0 
[1:1:0712/233641.081334:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233641.081853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/233641.082028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233641.083431:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233641.083611:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233641.083929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 837
[1:1:0712/233641.084112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7fe8b088a070 0x3ec578c26460 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 743 0x7fe8b088a070 0x3ec57a15fae0 
[1:1:0712/233641.612787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233641.613025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233642.111701:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 741, 7fe8b31cf8db
[1:1:0712/233642.123152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.123325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"515 0x7fe8b088a070 0x3ec5782700e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.123527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 893
[1:1:0712/233642.123634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7fe8b088a070 0x3ec579d96460 , 5:3_http://www.dogwood.com.cn/, 0, , 741 0x7fe8b088a070 0x3ec5782a9fe0 
[1:1:0712/233642.123787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233642.124090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233642.124195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233642.137629:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 13
[1:1:0712/233642.137848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 894
[1:1:0712/233642.137981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7fe8b088a070 0x3ec579f61ee0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 741 0x7fe8b088a070 0x3ec5782a9fe0 
[1:1:0712/233642.740214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 828, 7fe8b31cf881
[1:1:0712/233642.760212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"731 0x7fe8b088a070 0x3ec578c2d4e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.760503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"731 0x7fe8b088a070 0x3ec578c2d4e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.760841:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233642.761466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233642.761648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233642.762319:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233642.762478:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233642.762802:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 906
[1:1:0712/233642.762986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7fe8b088a070 0x3ec5778c5860 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 828 0x7fe8b088a070 0x3ec57a184660 
[1:1:0712/233642.879740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 837, 7fe8b31cf881
[1:1:0712/233642.917221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"743 0x7fe8b088a070 0x3ec57a15fae0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.917534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"743 0x7fe8b088a070 0x3ec57a15fae0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.917880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233642.918395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , cs, (){cq=b}
[1:1:0712/233642.918581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233642.919972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 790, 7fe8b31cf8db
[1:1:0712/233642.958080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"484 0x7fe8b088a070 0x3ec578092a60 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.958366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"484 0x7fe8b088a070 0x3ec578092a60 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233642.958752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 911
[1:1:0712/233642.958941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7fe8b088a070 0x3ec5791c14e0 , 5:3_http://www.dogwood.com.cn/, 0, , 790 0x7fe8b088a070 0x3ec5782437e0 
[1:1:0712/233642.959212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233642.959706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/233642.959879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233644.090959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233644.091257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233644.653461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7fe8b27b22e0 0x3ec577d48160 , "http://www.dogwood.com.cn/"
[1:1:0712/233644.661913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (function(){var aa=encodeURIComponent,ba=Infinity,ca=setTimeout,da=isNaN,m=Math,ea=decodeURIComponen
[1:1:0712/233644.662174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
		remove user.10_3118ee3c -> 0
		remove user.11_82756855 -> 0
		remove user.12_e4bd8035 -> 0
		remove user.13_4a6eba71 -> 0
		remove user.14_e09aaaf1 -> 0
		remove user.11_fef3736c -> 0
[1:1:0712/233645.325427:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 894, 7fe8b31cf8db
[1:1:0712/233645.375704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"741 0x7fe8b088a070 0x3ec5782a9fe0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233645.376049:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"741 0x7fe8b088a070 0x3ec5782a9fe0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233645.376461:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 985
[1:1:0712/233645.376656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7fe8b088a070 0x3ec577aefc60 , 5:3_http://www.dogwood.com.cn/, 0, , 894 0x7fe8b088a070 0x3ec579f61ee0 
[1:1:0712/233645.377002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233645.377507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/233645.377684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233645.378672:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233645.378847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233645.379171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 986
[1:1:0712/233645.379364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7fe8b088a070 0x3ec579f648e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 894 0x7fe8b088a070 0x3ec579f61ee0 
[1:1:0712/233645.816021:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 906, 7fe8b31cf881
[1:1:0712/233645.829302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"828 0x7fe8b088a070 0x3ec57a184660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233645.829493:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"828 0x7fe8b088a070 0x3ec57a184660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233645.829691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233645.830019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233645.830147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233645.830458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233645.830553:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233645.830728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 996
[1:1:0712/233645.830836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7fe8b088a070 0x3ec579d9b660 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 906 0x7fe8b088a070 0x3ec5778c5860 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233646.297884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 893, 7fe8b31cf8db
[1:1:0712/233646.311761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"741 0x7fe8b088a070 0x3ec5782a9fe0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233646.311937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"741 0x7fe8b088a070 0x3ec5782a9fe0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233646.312203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1017
[1:1:0712/233646.312317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7fe8b088a070 0x3ec577b505e0 , 5:3_http://www.dogwood.com.cn/, 0, , 893 0x7fe8b088a070 0x3ec579d96460 
[1:1:0712/233646.312498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233646.312811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233646.312939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233646.326743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 13
[1:1:0712/233646.326992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1018
[1:1:0712/233646.327137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7fe8b088a070 0x3ec57b68f660 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 893 0x7fe8b088a070 0x3ec579d96460 
[1:1:0712/233646.801893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233646.802189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233647.844768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 986, 7fe8b31cf881
[1:1:0712/233647.858320:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"894 0x7fe8b088a070 0x3ec579f61ee0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233647.858524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"894 0x7fe8b088a070 0x3ec579f61ee0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233647.858727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233647.859024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , cs, (){cq=b}
[1:1:0712/233647.859139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233648.051931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 996, 7fe8b31cf881
[1:1:0712/233648.067113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"906 0x7fe8b088a070 0x3ec5778c5860 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.067299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"906 0x7fe8b088a070 0x3ec5778c5860 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.067498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233648.067833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233648.067949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233648.068259:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233648.068363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233648.068557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1051
[1:1:0712/233648.068684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1051 0x7fe8b088a070 0x3ec57b8b04e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 996 0x7fe8b088a070 0x3ec579d9b660 
[1:1:0712/233648.134370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 911, 7fe8b31cf8db
[1:1:0712/233648.185127:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"790 0x7fe8b088a070 0x3ec5782437e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.185418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"790 0x7fe8b088a070 0x3ec5782437e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.185855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1056
[1:1:0712/233648.186050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7fe8b088a070 0x3ec57b9665e0 , 5:3_http://www.dogwood.com.cn/, 0, , 911 0x7fe8b088a070 0x3ec5791c14e0 
[1:1:0712/233648.186358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233648.186881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/233648.187056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233648.518913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1018, 7fe8b31cf8db
[1:1:0712/233648.564765:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"893 0x7fe8b088a070 0x3ec579d96460 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.565090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"893 0x7fe8b088a070 0x3ec579d96460 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233648.565557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1065
[1:1:0712/233648.566184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7fe8b088a070 0x3ec57b6849e0 , 5:3_http://www.dogwood.com.cn/, 0, , 1018 0x7fe8b088a070 0x3ec57b68f660 
[1:1:0712/233648.566592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233648.567159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/233648.567371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233648.568354:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233648.568513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233648.568888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1068
[1:1:0712/233648.569078:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7fe8b088a070 0x3ec578c26060 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1018 0x7fe8b088a070 0x3ec57b68f660 
[1:1:0712/233648.983468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , document.readyState
[1:1:0712/233648.983636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233649.210296:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1017, 7fe8b31cf8db
[1:1:0712/233649.258192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"893 0x7fe8b088a070 0x3ec579d96460 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233649.258468:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"893 0x7fe8b088a070 0x3ec579d96460 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233649.258874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1095
[1:1:0712/233649.259071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7fe8b088a070 0x3ec577d15de0 , 5:3_http://www.dogwood.com.cn/, 0, , 1017 0x7fe8b088a070 0x3ec577b505e0 
[1:1:0712/233649.259377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233649.259920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233649.260132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233649.285095:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 13
[1:1:0712/233649.285346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1096
[1:1:0712/233649.285457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7fe8b088a070 0x3ec579d64f60 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1017 0x7fe8b088a070 0x3ec577b505e0 
[1:1:0712/233649.411553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dogwood.com.cn/"
[1:1:0712/233649.412260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){Ie(d,null);Je(d,null);b()}
[1:1:0712/233649.412440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233649.815025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1051, 7fe8b31cf881
[1:1:0712/233649.829852:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"996 0x7fe8b088a070 0x3ec579d9b660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233649.830061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"996 0x7fe8b088a070 0x3ec579d9b660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233649.830294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233649.830620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233649.830726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233649.831077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233649.831182:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233649.831346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1112
[1:1:0712/233649.831455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7fe8b088a070 0x3ec57b69d560 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1051 0x7fe8b088a070 0x3ec57b8b04e0 
[1:1:0712/233650.112757:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1068, 7fe8b31cf881
[1:1:0712/233650.162218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"1018 0x7fe8b088a070 0x3ec57b68f660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233650.162631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"1018 0x7fe8b088a070 0x3ec57b68f660 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233650.163094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233650.163739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , cs, (){cq=b}
[1:1:0712/233650.164027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233651.152763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1096, 7fe8b31cf8db
[1:1:0712/233651.200261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"1017 0x7fe8b088a070 0x3ec577b505e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233651.200583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"1017 0x7fe8b088a070 0x3ec577b505e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233651.201034:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1150
[1:1:0712/233651.201230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1150 0x7fe8b088a070 0x3ec57b976d60 , 5:3_http://www.dogwood.com.cn/, 0, , 1096 0x7fe8b088a070 0x3ec579d64f60 
[1:1:0712/233651.201589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233651.202092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/233651.202265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233651.203221:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233651.203377:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233651.203715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1151
[1:1:0712/233651.203901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1151 0x7fe8b088a070 0x3ec57b6999e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1096 0x7fe8b088a070 0x3ec579d64f60 
[1:1:0712/233651.458122:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dogwood.com.cn/"
[1:1:0712/233651.458803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){Ie(d,null);Je(d,null);b()}
[1:1:0712/233651.458982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[18701:18701:0712/233651.612501:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/233651.700654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1112, 7fe8b31cf881
[1:1:0712/233651.716692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"1051 0x7fe8b088a070 0x3ec57b8b04e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233651.716871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"1051 0x7fe8b088a070 0x3ec57b8b04e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233651.717090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233651.717392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233651.717493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233651.717840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233651.717949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233651.718110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1167
[1:1:0712/233651.718214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7fe8b088a070 0x3ec579f58560 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1112 0x7fe8b088a070 0x3ec57b69d560 
[1:1:0712/233652.701574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1056, 7fe8b31cf8db
[1:1:0712/233652.718210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"911 0x7fe8b088a070 0x3ec5791c14e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233652.718391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"911 0x7fe8b088a070 0x3ec5791c14e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233652.718623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1195
[1:1:0712/233652.718738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7fe8b088a070 0x3ec57b67fbe0 , 5:3_http://www.dogwood.com.cn/, 0, , 1056 0x7fe8b088a070 0x3ec57b9665e0 
[1:1:0712/233652.718937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233652.719245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/233652.719369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233652.720130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1151, 7fe8b31cf881
[1:1:0712/233652.745731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"1096 0x7fe8b088a070 0x3ec579d64f60 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233652.746119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"1096 0x7fe8b088a070 0x3ec579d64f60 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233652.746569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233652.747202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , cs, (){cq=b}
[1:1:0712/233652.747435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233653.086811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1095, 7fe8b31cf8db
[1:1:0712/233653.136373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1017 0x7fe8b088a070 0x3ec577b505e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233653.136652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1017 0x7fe8b088a070 0x3ec577b505e0 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233653.137098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1202
[1:1:0712/233653.137297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1202 0x7fe8b088a070 0x3ec5794fafe0 , 5:3_http://www.dogwood.com.cn/, 0, , 1095 0x7fe8b088a070 0x3ec577d15de0 
[1:1:0712/233653.137624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233653.138144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233653.138321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233653.168908:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233653.169153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 0
[1:1:0712/233653.169490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1203
[1:1:0712/233653.169681:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1203 0x7fe8b088a070 0x3ec57b96a8e0 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1095 0x7fe8b088a070 0x3ec577d15de0 
[1:1:0712/233653.171687:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 13
[1:1:0712/233653.172028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.dogwood.com.cn/, 1204
[1:1:0712/233653.172221:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1204 0x7fe8b088a070 0x3ec579356260 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1095 0x7fe8b088a070 0x3ec577d15de0 
[1:1:0712/233653.295224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1167, 7fe8b31cf881
[1:1:0712/233653.311269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"01d9e9322860","ptid":"1112 0x7fe8b088a070 0x3ec57b69d560 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233653.311455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dogwood.com.cn/","ptid":"1112 0x7fe8b088a070 0x3ec57b69d560 ","rf":"5:3_http://www.dogwood.com.cn/"}
[1:1:0712/233653.311660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dogwood.com.cn/"
[1:1:0712/233653.311960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dogwood.com.cn/, 01d9e9322860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0712/233653.312093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dogwood.com.cn/", "www.dogwood.com.cn", 3, 1, , , 0
[1:1:0712/233653.312399:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeeae04a29c8, 0x3ec5778ad150
[1:1:0712/233653.312497:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dogwood.com.cn/", 100
[1:1:0712/233653.312670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.dogwood.com.cn/, 1212
[1:1:0712/233653.312787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1212 0x7fe8b088a070 0x3ec578a3b160 , 5:3_http://www.dogwood.com.cn/, 1, -5:3_http://www.dogwood.com.cn/, 1167 0x7fe8b088a070 0x3ec579f58560 
