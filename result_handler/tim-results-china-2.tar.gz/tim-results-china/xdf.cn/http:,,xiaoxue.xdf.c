[0712/233654.789768:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233654.790110:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f398e4891
[0712/233655.905314:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233655.905642:INFO:switcher_clone.cc(787)] backtrace rip is 7fd26c677891
[1:1:0712/233655.917220:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/233655.917461:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/233655.924070:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/233657.322918:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/233657.323175:INFO:switcher_clone.cc(787)] backtrace rip is 7f23278c7891
[18828:18828:0712/233657.429638:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f5f01bd2-f50a-416a-bc8d-54cba08cd582
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18863:18863:0712/233657.534038:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18863
[18876:18876:0712/233657.534430:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18876
[18828:18828:0712/233658.040125:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18828:18861:0712/233658.041535:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/233658.041933:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233658.042368:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233658.043669:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233658.044010:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/233658.049293:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3e8fb21, 1
[1:1:0712/233658.049995:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x167a48e4, 0
[1:1:0712/233658.050368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x30ac49d8, 3
[1:1:0712/233658.050705:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x9318933, 2
[1:1:0712/233658.051140:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe4487a16 21fffffffbffffffe803 33ffffff893109 ffffffd849ffffffac30 , 10104, 4
[1:1:0712/233658.053071:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18828:18861:0712/233658.053542:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Hz!��3�1	�I�0�� 
[18828:18861:0712/233658.053687:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Hz!��3�1	�I�0�]�� 
[18828:18861:0712/233658.054218:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[18828:18861:0712/233658.054383:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18884, 4, e4487a16 21fbe803 33893109 d849ac30 
[1:1:0712/233658.055217:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd26a8b20a0, 3
[1:1:0712/233658.055729:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd26aa3d080, 2
[1:1:0712/233658.056169:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd254700d20, -2
[1:1:0712/233658.083457:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233658.084455:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9318933
[1:1:0712/233658.085596:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9318933
[1:1:0712/233658.087500:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9318933
[1:1:0712/233658.089307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.089577:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.089793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.090023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.090803:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9318933
[1:1:0712/233658.091192:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd26c6777ba
[1:1:0712/233658.091373:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd26c66edef, 7fd26c67777a, 7fd26c6790cf
[1:1:0712/233658.097565:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9318933
[1:1:0712/233658.097722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9318933
[1:1:0712/233658.097983:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9318933
[1:1:0712/233658.098677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.098794:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.098885:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.098972:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9318933
[1:1:0712/233658.099428:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9318933
[1:1:0712/233658.099584:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd26c6777ba
[1:1:0712/233658.099653:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd26c66edef, 7fd26c67777a, 7fd26c6790cf
[1:1:0712/233658.101809:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233658.102061:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233658.102154:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe40985058, 0x7ffe40984fd8)
[1:1:0712/233658.116345:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233658.121973:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18828:18828:0712/233658.687714:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18828:18828:0712/233658.689076:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18828:18841:0712/233658.707571:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18828:18841:0712/233658.707673:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[18828:18828:0712/233658.707822:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18828:18828:0712/233658.707905:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18828:18828:0712/233658.708053:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18884, 4
[1:7:0712/233658.709782:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[18828:18856:0712/233658.751614:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/233658.837444:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x30c97c1c9220
[1:1:0712/233658.837772:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/233659.170558:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/233700.598059:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233700.601509:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18828:18828:0712/233700.836030:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18828:18828:0712/233700.836154:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233701.302439:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233701.539352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233701.539626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233701.570263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/233701.570521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233701.662846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233701.663103:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233701.898022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233701.900597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233701.900723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233701.919133:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233701.929335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/233701.929578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233701.941532:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18828:18828:0712/233701.943354:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233701.944707:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30c97c1c7e20
[1:1:0712/233701.944864:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18828:18828:0712/233701.955017:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18828:18828:0712/233701.979091:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18828:18828:0712/233701.979241:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/233702.035643:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233702.656395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7fd2562db2e0 0x30c97c427de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233702.657689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/233702.657881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233702.659314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18828:18828:0712/233702.729971:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/233702.732377:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x30c97c1c8820
[1:1:0712/233702.732562:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18828:18828:0712/233702.749646:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/233702.750503:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/233702.750692:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18828:18828:0712/233702.757847:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18828:18828:0712/233702.769332:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18828:18828:0712/233702.771370:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18828:18841:0712/233702.781249:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18828:18841:0712/233702.781332:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18828:18828:0712/233702.781490:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18828:18828:0712/233702.781565:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18828:18828:0712/233702.781719:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18884, 4
[1:7:0712/233702.784448:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233703.320347:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/233703.928531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fd2562db2e0 0x30c97c1d56e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/233703.929578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d6671f01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/233703.929907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/233703.930745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18828:18828:0712/233704.066543:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18828:18828:0712/233704.066661:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/233704.096767:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/233704.505604:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233704.971158:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233704.971441:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[18828:18828:0712/233705.116391:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18828:18861:0712/233705.117168:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/233705.117631:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/233705.118046:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/233705.118899:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/233705.119205:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/233705.124882:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x370faa2e, 1
[1:1:0712/233705.125821:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22bdce32, 0
[1:1:0712/233705.126150:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3bedfdc9, 3
[1:1:0712/233705.126520:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3f20a6b5, 2
[1:1:0712/233705.126832:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 32ffffffceffffffbd22 2effffffaa0f37 ffffffb5ffffffa6203f ffffffc9fffffffdffffffed3b , 10104, 5
[1:1:0712/233705.128905:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18828:18861:0712/233705.129489:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING2ν".�7�� ?���;�� 
[18828:18861:0712/233705.129691:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 2ν".�7�� ?���;�s�� 
[1:1:0712/233705.129478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd26a8b20a0, 3
[1:1:0712/233705.129979:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd26aa3d080, 2
[18828:18861:0712/233705.130340:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18928, 5, 32cebd22 2eaa0f37 b5a6203f c9fded3b 
[1:1:0712/233705.130494:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fd254700d20, -2
[1:1:0712/233705.157984:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/233705.158367:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f20a6b5
[1:1:0712/233705.158763:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f20a6b5
[1:1:0712/233705.159511:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f20a6b5
[1:1:0712/233705.161193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.161476:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.161707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.161921:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.162728:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f20a6b5
[1:1:0712/233705.163070:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd26c6777ba
[1:1:0712/233705.163229:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd26c66edef, 7fd26c67777a, 7fd26c6790cf
[1:1:0712/233705.170099:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f20a6b5
[1:1:0712/233705.170545:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f20a6b5
[1:1:0712/233705.171440:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f20a6b5
[1:1:0712/233705.173923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.174184:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.174496:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.174720:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f20a6b5
[1:1:0712/233705.176229:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f20a6b5
[1:1:0712/233705.176682:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fd26c6777ba
[1:1:0712/233705.176840:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fd26c66edef, 7fd26c67777a, 7fd26c6790cf
[1:1:0712/233705.186259:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/233705.186957:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/233705.187126:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe40985058, 0x7ffe40984fd8)
[1:1:0712/233705.201118:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/233705.205390:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/233705.470898:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30c97c193220
[1:1:0712/233705.471114:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/233705.505871:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/233705.510359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d667202e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/233705.510633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/233705.518265:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[18828:18828:0712/233705.784810:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18828:18828:0712/233705.790677:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18828:18841:0712/233705.808240:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18828:18841:0712/233705.808330:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18828:18828:0712/233705.808791:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://xiaoxue.xdf.cn/
[18828:18828:0712/233705.808910:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://xiaoxue.xdf.cn/, http://xiaoxue.xdf.cn/201905/10921646.html, 1
[18828:18828:0712/233705.809042:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://xiaoxue.xdf.cn/, HTTP/1.1 200 OK Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Server: nginx Date: Sat, 13 Jul 2019 06:37:05 GMT Vary: Accept-Encoding Content-Encoding: gzip  ,18928, 5
[1:7:0712/233705.815593:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/233705.861379:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://xiaoxue.xdf.cn/
[18828:18828:0712/233705.986701:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://xiaoxue.xdf.cn/, http://xiaoxue.xdf.cn/, 1
[18828:18828:0712/233705.986780:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://xiaoxue.xdf.cn/, http://xiaoxue.xdf.cn
[1:1:0712/233706.046025:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/233706.190979:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233706.281315:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233706.281506:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233706.333695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 121 0x7fd2543b3070 0x30c97c2bb760 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233706.334659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
function parseURL(url) {
    var a =  document.createElement('a');
    a.href = url;
    return {
 
[1:1:0712/233706.334789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233706.336302:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233706.571309:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233706.923443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233706.933708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindo
[1:1:0712/233706.933919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233707.244669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.253776:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.328269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.334161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.341093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.356717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.365609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.373683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 192 0x7fd26aa3d080 0x30c97c36a420 1 0 0x30c97c36a438 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233707.765939:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233707.769268:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233707.769661:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233707.770118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233707.770495:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233708.218832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fd26aa3d080 0x30c97c1622e0 1 0 0x30c97c1622f8 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233708.232929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/233708.233059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
		remove user.10_8186f20b -> 0
		remove user.11_77049aa3 -> 0
		remove user.12_a3596070 -> 0
		remove user.13_645325c9 -> 0
		remove user.14_31c0e342 -> 0
[1:1:0712/233709.544071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fd26aa3d080 0x30c97c1622e0 1 0 0x30c97c1622f8 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233709.545982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 252 0x7fd26aa3d080 0x30c97c1622e0 1 0 0x30c97c1622f8 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[18828:18828:0712/233743.162916:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/233743.199346:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[18828:18828:0712/233743.356199:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/bcqm?psi=a3f5e714a61c9f5eb22b0a437c158436&di=1171188&dri=0&dis=0&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562999829453&ti=%E6%95%99%E8%82%B2%E9%83%A8%EF%BC%9A%E4%B8%A5%E6%A0%BC%E8%A7%84%E8%8C%83%E5%A4%A7%E4%B8%AD%E5%B0%8F%E5%AD%A6%E6%8B%9B%E7%94%9F%E7%A7%A9%E5%BA%8F-%E6%96%B0%E4%B8%9C%E6%96%B9%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562999829&rw=424&ltu=http%3A%2F%2Fxiaoxue.xdf.cn%2F201905%2F10921646.html&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562999830&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://cbjs.baidu.com/js/m.js (3)
[18828:18828:0712/233743.357842:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/bcqm?psi=a3f5e714a61c9f5eb22b0a437c158436&di=1171188&dri=0&dis=0&dai=0&ps=0x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562999829453&ti=%E6%95%99%E8%82%B2%E9%83%A8%EF%BC%9A%E4%B8%A5%E6%A0%BC%E8%A7%84%E8%8C%83%E5%A4%A7%E4%B8%AD%E5%B0%8F%E5%AD%A6%E6%8B%9B%E7%94%9F%E7%A7%A9%E5%BA%8F-%E6%96%B0%E4%B8%9C%E6%96%B9%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562999829&rw=424&ltu=http%3A%2F%2Fxiaoxue.xdf.cn%2F201905%2F10921646.html&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562999830&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://cbjs.baidu.com/js/m.js (3)
[1:1:0712/233743.664029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/233743.664353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233744.242471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.243737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , ___adblockplus({"queryid" : "70a3b6fabfb21f82","tuid" : "1171188_0","placement" : {"basic" : {"sspId
[1:1:0712/233744.243964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233744.270836:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.273616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.282113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.309789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.465789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 310, "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233744.536293:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.2668, 167, 1
[1:1:0712/233744.536568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233745.275778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233745.276083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233745.538804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233745.539035:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233745.539847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7fd2543b3070 0x30c97ca0d4e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233745.540834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic"
[1:1:0712/233745.541041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233745.554760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357 0x7fd2543b3070 0x30c97ca0d4e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233745.561081:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0219021, 52, 1
[1:1:0712/233745.561306:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233746.702595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233746.702854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233746.814301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 391 0x7fd2562db2e0 0x30c97ca1f760 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233746.815085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , if (typeof leyujs == 'undefined' || !leyujs) {
    var beijingZixun = {
    // <script src="http://b
[1:1:0712/233746.815198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233746.844984:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7fd2562db2e0 0x30c97bf89160 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233746.845817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
[1:1:0712/233746.846034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233746.893406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394 0x7fd2562db2e0 0x30c97cc41860 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233746.894883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827100({"status":1,"message":"<div  id=\"adMod_363\">\r\n    <a t
[1:1:0712/233746.895134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233746.896597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233746.936331:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233747.103332:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233747.103530:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.104185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 405 0x7fd2543b3070 0x30c97bd7a1e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.104871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
           var dom = $('#adModel_364');
           showAdv(dom,364,0);
        
[1:1:0712/233747.105061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.151829:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.048342, 174, 1
[1:1:0712/233747.152146:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233747.219436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 408 0x7fd2562db2e0 0x30c97ca1e160 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.222784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/233747.222971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.278164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7fd2562db2e0 0x30c97cc412e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.278757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/233747.278869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.315196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.315625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , articleImg, (){
        var h = $(d.body).width();
        var $atImg = null;
        var $atTB = null;
        
[1:1:0712/233747.315732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233747.620019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233747.620327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.824766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 432 0x7fd2562db2e0 0x30c97ccacce0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.827787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , /**
 * 目标：根据script配置，动态加载模板、css、js、图片
 * 
 * 核心问题�
[1:1:0712/233747.828042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.899669:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233747.899908:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.902006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7fd2543b3070 0x30c97d0dfa60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233747.902964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
    getClass(40,9,5,"#myTable1");
    getClass(40,10,5,"#myTable2","Upcoming");
    getClass(40,11,
[1:1:0712/233747.903141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233747.940796:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233747.941245:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/233748.210304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7fd2543b3070 0x30c97d0dfa60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233748.266194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7fd2543b3070 0x30c97d0dfa60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233748.282464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7fd2543b3070 0x30c97d0dfa60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233748.291791:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.391061, 75, 1
[1:1:0712/233748.291995:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233748.552892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233748.553135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233748.625611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7fd2562db2e0 0x30c97d0e05e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233748.626882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827101({"status":1,"message":"<div id=\"adMod_364\" >\r\n    <a t
[1:1:0712/233748.627086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233748.628112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233749.763576:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233749.763848:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233749.764863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fd2543b3070 0x30c97d5ffc60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233749.766005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
           var dom = $('#adModel_365');
           showAdv(dom,365,0);
        
[1:1:0712/233749.766275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233749.825156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fd2543b3070 0x30c97d5ffc60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233749.900294:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.136319, 131, 1
[1:1:0712/233749.900557:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233749.977993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7fd2562db2e0 0x30c97cced7e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233749.978990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window.xcs_temp="<div class=\"xcs-tmpl1\">\r\n  <!-- 替换样式参数 -->\r\n  <style>\r\n    .xcs
[1:1:0712/233749.979211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233749.979921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.031428:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fd2562db2e0 0x30c97c2bdc60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.032286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , ;(function() {
  var protocol = 'https:' == document.location.protocol ? 'https:': 'http:';  // 除
[1:1:0712/233750.032523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.128160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233750.128461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.579616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519 0x7fd2562db2e0 0x30c97d4e63e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.580679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827102({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233750.580944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.581780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.657424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7fd2562db2e0 0x30c97d634060 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.658539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827103({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233750.658757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.659494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.767494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7fd2562db2e0 0x30c97d117960 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.768464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827104({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233750.768678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.769444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.829505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fd2562db2e0 0x30c97d669760 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.830536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827105({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233750.830774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.831665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.949148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 525 0x7fd2562db2e0 0x30c97bca0fe0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233750.950181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827106({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233750.950399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233750.951156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233751.003050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 526 0x7fd2562db2e0 0x30c97cce9c60 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233751.004052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827107({"ip":"218.241.135.34","schoolid":"1","school":"\u5317\u4e
[1:1:0712/233751.004327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233751.005080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233751.107621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fd2562db2e0 0x30c97d638be0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233751.110772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827108({"status":1,"message":"<ul style=\"width: 100%;\" id=\"res
[1:1:0712/233751.111010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233751.112266:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233752.318737:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233752.318945:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233752.319913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558 0x7fd2543b3070 0x30c97cef4260 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233752.320837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , 
           var dom = $('#adModel_367');
           showAdv(dom,367,0);
        
[1:1:0712/233752.321039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233752.384241:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0651839, 66, 1
[1:1:0712/233752.384531:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/233752.483655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561 0x7fd2562db2e0 0x30c97d6fe5e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233752.485058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827109({"status":1,"message":"<div style=\" width: 320px; height:
[1:1:0712/233752.485299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233752.486369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233752.543604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562 0x7fd2562db2e0 0x30c97d66a660 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233752.545063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827110({"status":1,"message":"<div style=\"width: 320px; height: 
[1:1:0712/233752.545247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233752.546096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233753.058863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233753.059172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233753.979536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 633 0x7fd2562db2e0 0x30c97ca61fe0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233753.981168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827111({"Status":1,"ResponseData":{"TopRegClassList":[{"Id":42120
[1:1:0712/233753.981355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233753.984091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
		remove user.11_9535a653 -> 0
		remove user.12_4c4a8263 -> 0
		remove user.13_d6ab4c2b -> 0
[1:1:0712/233754.274885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7fd2562db2e0 0x30c97daefae0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233754.276552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827112({"Status":1,"ResponseData":{"UpcomingClassList":[{"Id":445
[1:1:0712/233754.276742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233754.279147:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233754.586572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 636 0x7fd2562db2e0 0x30c97d0a20e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233754.588316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827113({"Status":1,"ResponseData":{"UpcomingClassList":[{"Id":445
[1:1:0712/233754.588500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233754.590662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233754.708952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 637 0x7fd2562db2e0 0x30c97d6673e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233754.710779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827114({"Status":1,"ResponseData":{"UpcomingClassList":[{"Id":445
[1:1:0712/233754.710976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233754.713207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233755.771550:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/233755.771711:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.773756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7fd2543b3070 0x30c97dae6de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.775055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var instal
[1:1:0712/233755.775174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233755.798671:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7fd2543b3070 0x30c97dae6de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.801006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7fd2543b3070 0x30c97dae6de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.802639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7fd2543b3070 0x30c97dae6de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.806848:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233755.810852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233756.073217:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 4000
[1:1:0712/233756.073707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 738
[1:1:0712/233756.073962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7fd2543b3070 0x30c97d0a20e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233756.270969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 4000
[1:1:0712/233756.271568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 741
[1:1:0712/233756.271854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7fd2543b3070 0x30c97de8fce0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233756.609070:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d010
[1:1:0712/233756.637370:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d148
[1:1:0712/233756.666528:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d280
[1:1:0712/233756.696139:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d3b8
[1:1:0712/233756.724095:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d4f0
[1:1:0712/233756.741276:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d628
[1:1:0712/233756.755430:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d760
[1:1:0712/233756.777582:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d898
[1:1:0712/233756.793486:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21d9d0
[1:1:0712/233756.825980:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21db08
[1:1:0712/233756.857262:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21dc40
[1:1:0712/233756.884873:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21dd78
[1:1:0712/233756.912939:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21deb0
[1:1:0712/233756.937436:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21dfe8
[1:1:0712/233756.967343:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e120
[1:1:0712/233756.994850:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e258
[1:1:0712/233757.022453:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e390
[1:1:0712/233757.049994:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e4c8
[1:1:0712/233757.077705:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e600
[1:1:0712/233757.105349:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e738
[1:1:0712/233757.133024:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e870
[1:1:0712/233757.160603:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21e9a8
[1:1:0712/233757.187990:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21eae0
[1:1:0712/233757.216232:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21ec18
[1:1:0712/233757.243888:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21ed50
[1:1:0712/233757.271461:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d21ee88
[1:1:0712/233757.304738:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1840
[1:1:0712/233757.332628:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1978
[1:1:0712/233757.360243:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1ab0
[1:1:0712/233757.386228:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1be8
[1:1:0712/233757.395624:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1d20
[1:1:0712/233757.430727:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1e58
[1:1:0712/233757.462512:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e1f90
[1:1:0712/233757.490681:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e20c8
[1:1:0712/233757.520025:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2200
[1:1:0712/233757.547571:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2338
[1:1:0712/233757.575159:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2470
[1:1:0712/233757.602639:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e25a8
[1:1:0712/233757.630397:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e26e0
[1:1:0712/233757.658017:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2818
[1:1:0712/233757.685897:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2950
[1:1:0712/233757.714340:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2a88
[1:1:0712/233757.742703:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2bc0
[1:1:0712/233757.770443:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2cf8
[1:1:0712/233757.797988:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2e30
[1:1:0712/233757.825484:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e2f68
[1:1:0712/233757.853268:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e30a0
[1:1:0712/233757.881161:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e31d8
[1:1:0712/233757.908832:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3310
[1:1:0712/233757.936392:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3448
[1:1:0712/233757.963902:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3580
[1:1:0712/233757.991594:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e36b8
[1:1:0712/233758.019066:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e37f0
[1:1:0712/233758.047068:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3928
[1:1:0712/233758.075363:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3a60
[1:1:0712/233758.102884:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3b98
[1:1:0712/233758.130477:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3cd0
[1:1:0712/233758.158071:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3e08
[1:1:0712/233758.190520:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e3f40
[1:1:0712/233758.218116:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e4078
[1:1:0712/233758.250723:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e41b0
[1:1:0712/233758.278346:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1dd28d1e42e8
[1:1:0712/233758.510195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x21f220ee29c8, 0x30c97c003210
[1:1:0712/233758.510423:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 1000
[1:1:0712/233758.510801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 750
[1:1:0712/233758.510990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7fd2543b3070 0x30c97e2fe660 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233759.051010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 8000, 0x21f220ee29c8, 0x30c97c003210
[1:1:0712/233759.051173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 8000
[1:1:0712/233759.051355:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 751
[1:1:0712/233759.051482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7fd2543b3070 0x30c97e4908e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233759.078273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233759.091225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c0031e0
[1:1:0712/233759.091444:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233759.091699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 759
[1:1:0712/233759.091850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7fd2543b3070 0x30c97e5e7ae0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233759.099248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c0031e0
[1:1:0712/233759.099415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233759.099653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 760
[1:1:0712/233759.099800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7fd2543b3070 0x30c97de6d2e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233759.103070:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x21f220ee29c8, 0x30c97c0031e0
[1:1:0712/233759.103211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 3000
[1:1:0712/233759.103509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 761
[1:1:0712/233759.103660:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7fd2543b3070 0x30c97e6f84e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 648 0x7fd2543b3070 0x30c97dae6de0 
[1:1:0712/233759.610728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233759.610959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233759.767077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7fd2562db2e0 0x30c97d666860 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233759.769811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827115({"Status":1,"ResponseData":{"UpcomingClassList":[{"Id":445
[1:1:0712/233759.770038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233759.772184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233759.985988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 672 0x7fd2562db2e0 0x30c97daf3060 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233759.987727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827116({"Status":1,"ResponseData":{"UpcomingClassList":[{"Id":445
[1:1:0712/233759.987915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233759.990089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233800.145220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7fd2562db2e0 0x30c97caa3de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233800.145858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827117({"status":1,"message":"<div style=\" width: 320px; height:
[1:1:0712/233800.145970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233800.146398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233802.141102:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7fd2562db2e0 0x30c97e722de0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233802.142374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , <!-- 新版统计代码标识 -->
  dataLayer = [{
     'stats_code_version': '2019.2'
  }];


[1:1:0712/233802.142500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233802.170220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7fd2562db2e0 0x30c97e71b1e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233802.171339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , ___baidu_union_callback_("auto","a3f5e714a61c9f5eb22b0a437c158436",[])
[1:1:0712/233802.171521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233802.750363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 750, 7fd256cf8881
[1:1:0712/233802.761301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233802.761479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233802.761690:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233802.761991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , (){$('#lee2').animate({opacity: 'toggle',left:0,bottom:0}, { duration: "slow" });
			leeT2 = setTime
[1:1:0712/233802.762092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233802.837009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21f220ee29c8, 0x30c97c003150
[1:1:0712/233802.837236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 0
[1:1:0712/233802.837639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 889
[1:1:0712/233802.837831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7fd2543b3070 0x30c97e7d0660 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 750 0x7fd2543b3070 0x30c97e2fe660 
[1:1:0712/233802.843861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 13
[1:1:0712/233802.844257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 890
[1:1:0712/233802.844462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7fd2543b3070 0x30c97c94bd60 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 750 0x7fd2543b3070 0x30c97e2fe660 
[1:1:0712/233802.892282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x21f220ee29c8, 0x30c97c003150
[1:1:0712/233802.892517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 5000
[1:1:0712/233802.892888:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 895
[1:1:0712/233802.893077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7fd2543b3070 0x30c97e41ce60 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 750 0x7fd2543b3070 0x30c97e2fe660 
[1:1:0712/233802.945258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233802.945435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233802.991642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 738, 7fd256cf88db
[1:1:0712/233803.002923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233803.003071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233803.003284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 902
[1:1:0712/233803.003394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7fd2543b3070 0x30c97cce96e0 , 5:3_http://xiaoxue.xdf.cn/, 0, , 738 0x7fd2543b3070 0x30c97d0a20e0 
[1:1:0712/233803.003552:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233803.003836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233803.003937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233803.052535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 741, 7fd256cf88db
[1:1:0712/233803.067282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233803.067566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233803.067961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 904
[1:1:0712/233803.068150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7fd2543b3070 0x30c97e7bae60 , 5:3_http://xiaoxue.xdf.cn/, 0, , 741 0x7fd2543b3070 0x30c97de8fce0 
[1:1:0712/233803.068390:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233803.068947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , () {
        showImg(index);
        index++;
        if (index == len) {
            index = 0;
   
[1:1:0712/233803.069120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233803.997778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 826 0x7fd2562db2e0 0x30c97e8155e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233803.999308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827118({"data":{"flag":1,"list":[{"cover":"http:\/\/weike.xdf.cn\
[1:1:0712/233803.999537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233804.001455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.153552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 827 0x7fd2562db2e0 0x30c97e7f94e0 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.155625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , //By Robin_TYUT 2010/08/19
//Thank U 4 sharing!
jQuery.fn.extend(
{
    OpenDiv: function() {

[1:1:0712/233804.155829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233804.157492:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.241043:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 829 0x7fd2562db2e0 0x30c97e71c060 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.242610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , jQuery172005855175249468103_1562999827119([{"typeid":"1266","aid":"10937516","text_custom":"","stitl
[1:1:0712/233804.242804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233804.244615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.462437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 830 0x7fd2562db2e0 0x30c97dae8860 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.463914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/233804.464143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233804.485381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c003190
[1:1:0712/233804.485609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233804.486038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 947
[1:1:0712/233804.486268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7fd2543b3070 0x30c97e7cd260 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 830 0x7fd2562db2e0 0x30c97dae8860 
[1:1:0712/233804.508341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c003190
[1:1:0712/233804.508599:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233804.509068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 950
[1:1:0712/233804.509299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7fd2543b3070 0x30c97dae84e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 830 0x7fd2562db2e0 0x30c97dae8860 
[1:1:0712/233804.516640:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.609686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 832 0x7fd2562db2e0 0x30c97bec7360 , "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233804.610709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/233804.610946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233804.637240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c003190
[1:1:0712/233804.637473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233804.637879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 954
[1:1:0712/233804.638124:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7fd2543b3070 0x30c97e5e78e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 832 0x7fd2562db2e0 0x30c97bec7360 
[1:1:0712/233804.643598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233805.115503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 761, 7fd256cf8881
[1:1:0712/233805.155736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233805.156113:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"648 0x7fd2543b3070 0x30c97dae6de0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233805.156506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233805.157137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/233805.157350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233805.164315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x21f220ee29c8, 0x30c97c003150
[1:1:0712/233805.164529:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 15000
[1:1:0712/233805.164972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 960
[1:1:0712/233805.165207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7fd2543b3070 0x30c97ec4a260 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 761 0x7fd2543b3070 0x30c97e6f84e0 
[18828:18828:0712/233805.205038:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/233806.912537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 889, 7fd256cf8881
[1:1:0712/233806.953337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"750 0x7fd2543b3070 0x30c97e2fe660 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233806.953714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"750 0x7fd2543b3070 0x30c97e2fe660 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233806.954135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233806.954727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , cs, (){cq=b}
[1:1:0712/233806.954939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233806.956715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 890, 7fd256cf88db
[1:1:0712/233806.994874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1dd28d142860","ptid":"750 0x7fd2543b3070 0x30c97e2fe660 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233806.995235:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xiaoxue.xdf.cn/","ptid":"750 0x7fd2543b3070 0x30c97e2fe660 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233806.995712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 982
[1:1:0712/233806.995958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7fd2543b3070 0x30c97ec4d560 , 5:3_http://xiaoxue.xdf.cn/, 0, , 890 0x7fd2543b3070 0x30c97c94bd60 
[1:1:0712/233806.996271:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233806.996922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , tick, (){var a,b=f.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||f.fx.st
[1:1:0712/233806.997139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
[1:1:0712/233806.998490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x21f220ee29c8, 0x30c97c003150
[1:1:0712/233806.998701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xiaoxue.xdf.cn/201905/10921646.html", 0
[1:1:0712/233806.999104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xiaoxue.xdf.cn/, 983
[1:1:0712/233806.999327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7fd2543b3070 0x30c97ea3b8e0 , 5:3_http://xiaoxue.xdf.cn/, 1, -5:3_http://xiaoxue.xdf.cn/, 890 0x7fd2543b3070 0x30c97c94bd60 
[1:1:0712/233807.146119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , document.readyState
[1:1:0712/233807.146421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/233808.237148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 902, 7fd256cf88db
[1:1:0712/233808.278524:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"738 0x7fd2543b3070 0x30c97d0a20e0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233808.278845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"738 0x7fd2543b3070 0x30c97d0a20e0 ","rf":"5:3_http://xiaoxue.xdf.cn/"}
[1:1:0712/233808.279286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xiaoxue.xdf.cn/, 1003
[1:1:0712/233808.279514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7fd2543b3070 0x30c97ed3b360 , 5:3_http://xiaoxue.xdf.cn/, 0, , 902 0x7fd2543b3070 0x30c97cce96e0 
[1:1:0712/233808.279856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xiaoxue.xdf.cn/201905/10921646.html"
[1:1:0712/233808.280574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xiaoxue.xdf.cn/, 1dd28d142860, , , (){
   showImg(index)
   index++;
   if(index==len){index=0;}
}
[1:1:0712/233808.280814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xiaoxue.xdf.cn/201905/10921646.html", "xiaoxue.xdf.cn", 3, 1, , , 0
