[0711/072943.448671:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/072943.449179:INFO:switcher_clone.cc(787)] backtrace rip is 7fd51f187891
[0711/072944.468979:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/072944.469487:INFO:switcher_clone.cc(787)] backtrace rip is 7fc9e545c891
[1:1:0711/072944.475602:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/072944.475781:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/072944.481425:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[11177:11177:0711/072945.439173:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/696ae10b-738d-4ef7-9008-40bdb9207a4c
[0711/072945.978386:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/072945.978690:INFO:switcher_clone.cc(787)] backtrace rip is 7fe587969891
[11177:11177:0711/072945.979777:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[11177:11206:0711/072945.980808:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/072945.981042:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/072945.981338:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/072945.982099:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/072945.982403:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/072945.986452:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x237c0aaa, 1
[1:1:0711/072945.986701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x16441686, 0
[1:1:0711/072945.986809:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x32676fad, 3
[1:1:0711/072945.986902:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x110ba641, 2
[1:1:0711/072945.987002:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff86164416 ffffffaa0a7c23 41ffffffa60b11 ffffffad6f6732 , 10104, 4
[1:1:0711/072945.987697:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11177:11206:0711/072945.987859:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�D�
|#A��og2b�&
[1:1:0711/072945.987836:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e36970a0, 3
[11177:11206:0711/072945.987941:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �D�
|#A��og28�b�&
[1:1:0711/072945.987936:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e3822080, 2
[1:1:0711/072945.988016:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9cd4e5d20, -2
[11177:11206:0711/072945.988258:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[11177:11206:0711/072945.988351:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11222, 4, 86164416 aa0a7c23 41a60b11 ad6f6732 
[1:1:0711/072945.996853:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/072945.997479:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 110ba641
[1:1:0711/072945.998103:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 110ba641
[1:1:0711/072945.999120:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 110ba641
[1:1:0711/072945.999746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072945.999861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072945.999999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.000097:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.000357:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 110ba641
[1:1:0711/072946.000498:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e545c7ba
[1:1:0711/072946.000569:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e5453def, 7fc9e545c77a, 7fc9e545e0cf
[1:1:0711/072946.001980:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 110ba641
[1:1:0711/072946.002131:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 110ba641
[1:1:0711/072946.002433:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 110ba641
[1:1:0711/072946.003071:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.003232:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.003500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.003733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 110ba641
[1:1:0711/072946.005423:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 110ba641
[1:1:0711/072946.005817:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e545c7ba
[1:1:0711/072946.005957:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e5453def, 7fc9e545c77a, 7fc9e545e0cf
[1:1:0711/072946.015619:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/072946.016246:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/072946.016423:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfa5d6d58, 0x7ffdfa5d6cd8)
[1:1:0711/072946.034825:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/072946.042368:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[11209:11209:0711/072946.225980:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11209
[11234:11234:0711/072946.226438:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11234
[11177:11177:0711/072946.575851:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11177:11177:0711/072946.576967:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11177:11188:0711/072946.601995:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[11177:11188:0711/072946.602124:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[11177:11177:0711/072946.602255:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[11177:11177:0711/072946.602386:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[11177:11177:0711/072946.602581:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,11222, 4
[1:7:0711/072946.608906:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[11177:11199:0711/072946.646563:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/072946.719224:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3997ce3ef220
[1:1:0711/072946.720068:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/072947.021898:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[11177:11177:0711/072948.376406:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[11177:11177:0711/072948.376476:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/072948.423439:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/072948.427794:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/072949.481370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/072949.481681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072949.493508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/072949.493701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072949.539216:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[11177:11177:0711/072949.846760:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[11177:11206:0711/072949.847036:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/072949.847249:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/072949.847505:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/072949.847918:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/072949.848118:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/072949.857649:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3e9926e9, 1
[1:1:0711/072949.858621:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10e95e23, 0
[1:1:0711/072949.861272:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x7ff3b9b, 3
[1:1:0711/072949.865556:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x198fc26c, 2
[1:1:0711/072949.865742:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 235effffffe910 ffffffe926ffffff993e 6cffffffc2ffffff8f19 ffffff9b3bffffffff07 , 10104, 5
[1:1:0711/072949.866815:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11177:11206:0711/072949.867062:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING#^��&�>l�;���&
[11177:11206:0711/072949.867145:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is #^��&�>l�;��5��&
[1:1:0711/072949.867283:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e36970a0, 3
[11177:11206:0711/072949.867453:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11270, 5, 235ee910 e926993e 6cc28f19 9b3bff07 
[1:1:0711/072949.867494:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9e3822080, 2
[1:1:0711/072949.867737:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc9cd4e5d20, -2
[1:1:0711/072949.882498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/072949.882765:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072949.887848:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/072949.888643:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 198fc26c
[1:1:0711/072949.888998:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 198fc26c
[1:1:0711/072949.889744:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 198fc26c
[1:1:0711/072949.891172:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.891402:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.891890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.892126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.892830:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 198fc26c
[1:1:0711/072949.893201:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e545c7ba
[1:1:0711/072949.893418:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e5453def, 7fc9e545c77a, 7fc9e545e0cf
[1:1:0711/072949.895343:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 198fc26c
[1:1:0711/072949.895771:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 198fc26c
[1:1:0711/072949.896526:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 198fc26c
[1:1:0711/072949.897620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.897866:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.898089:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.898378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 198fc26c
[1:1:0711/072949.899667:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 198fc26c
[1:1:0711/072949.900078:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc9e545c7ba
[1:1:0711/072949.900311:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc9e5453def, 7fc9e545c77a, 7fc9e545e0cf
[1:1:0711/072949.909130:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/072949.909722:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/072949.909918:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfa5d6d58, 0x7ffdfa5d6cd8)
[1:1:0711/072949.929710:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/072949.934972:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/072950.121411:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3997ce3b8220
[1:1:0711/072950.121636:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/072950.320098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072950.330110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/072950.330427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072950.390775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 369, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072950.402036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/072950.402348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072950.416818:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[11177:11177:0711/072950.419789:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/072950.424322:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3997ce3ede20
[1:1:0711/072950.424551:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[11177:11177:0711/072950.432463:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[11177:11177:0711/072950.466785:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[11177:11177:0711/072950.466867:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/072950.520386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072951.323307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 431 0x7fc9cf0c02e0 0x3997ce6b7660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072951.324757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/072951.325035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072951.326638:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11177:11177:0711/072951.362902:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/072951.364356:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3997ce3ee820
[1:1:0711/072951.364603:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[11177:11177:0711/072951.372299:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/072951.387016:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/072951.387252:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[11177:11177:0711/072951.405618:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[11177:11177:0711/072951.420433:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11177:11177:0711/072951.423079:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11177:11188:0711/072951.426328:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[11177:11177:0711/072951.426363:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[11177:11177:0711/072951.426470:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[11177:11188:0711/072951.426475:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[11177:11177:0711/072951.426565:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,11222, 4
[1:7:0711/072951.428252:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/072951.955048:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/072952.350374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fc9cf0c02e0 0x3997ce689de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072952.351399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/072952.351645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072952.352425:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11177:11177:0711/072952.479109:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[11177:11177:0711/072952.479251:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/072952.481520:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/072952.733042:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/072953.315214:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/072953.315499:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072953.664635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072953.669338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/072953.669650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072953.677131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072953.813403:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/072953.814222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 144dc9b21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/072953.814504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/072953.962872:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072953.964928:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/072953.965287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/072953.965679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072954.080692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072954.098228:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/072954.098450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/072954.098716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072954.604938:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/072954.697855:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gmx.net/"
[1:1:0711/072954.811028:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/072954.872396:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/072954.972338:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/072955.057536:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/072955.109075:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/072955.217623:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/072955.252669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.253668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.253955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.298931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.300101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.300442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.358760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.359699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.360022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.436507:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.437435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.437746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.528031:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.528957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.529246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.587311:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.588267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.588568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.662889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.663946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.664278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.710840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.711768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.712009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.780409:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.780935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.781106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.825584:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.826128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.826446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.898435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.898939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.899086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.931773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.932251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072955.932387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072955.977091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072955.978192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072955.978478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072956.011146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072956.012306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072956.012696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072956.081402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072956.082123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/072956.082420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/072956.115267:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/072956.115772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 144dc9c4fc38, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/072956.115910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[11177:11177:0711/072956.364805:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('http://h5.cyol.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[11177:11177:0711/073001.201274:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11177:11177:0711/073001.204599:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11177:11188:0711/073001.235400:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[11177:11188:0711/073001.235498:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[11177:11177:0711/073001.237272:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://h5.cyol.com/
[11177:11177:0711/073001.237338:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://h5.cyol.com/, http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php, 1
[11177:11177:0711/073001.237439:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://h5.cyol.com/, HTTP/1.1 200 OK Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Date: Thu, 11 Jul 2019 14:30:00 GMT Powered-By-ChinaCache: MISS from CHN-DU-f-3H7 CACHE: TCP_MISS Vary: Accept-Encoding Vary: Accept-Encoding Content-Encoding: gzip Server: cyol Powered-By-ChinaCache: MISS from GWB-FS-2-3WX CC_CACHE: TCP_MISS  ,11270, 5
[1:7:0711/073001.246394:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/073001.291733:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://h5.cyol.com/
[11177:11177:0711/073001.416476:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://h5.cyol.com/, http://h5.cyol.com/, 1
[11177:11177:0711/073001.416565:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://h5.cyol.com/, http://h5.cyol.com
[1:1:0711/073001.455097:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/073001.603435:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/073001.688445:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/073001.688691:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073002.062741:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/073002.301626:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 218 0x7fc9cf0c02e0 0x3997ce6cab60 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073002.311356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , /*!2019-06-15 16:18 */function tanxssp_show(a){var b=document;a.i||(a.i=a.pid);var c="tanx-a-"+a.i||
[1:1:0711/073002.311562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073002.313749:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/073002.779711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fc9e3822080 0x3997ce6aace0 1 0 0x3997ce6aacf8 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073002.818630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , /*!
 * jQuery JavaScript Library v1.10.2
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://si
[1:1:0711/073002.818883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073003.042492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fc9e3822080 0x3997ce6aace0 1 0 0x3997ce6aacf8 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.045087:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "h5.cyol.com", "h5.cyol.com"
[1:1:0711/073003.049392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fc9e3822080 0x3997ce6aace0 1 0 0x3997ce6aacf8 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.072093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fc9e3822080 0x3997ce6aace0 1 0 0x3997ce6aacf8 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.100196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fc9e3822080 0x3997ce6aace0 1 0 0x3997ce6aacf8 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.140568:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/073003.144228:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x3997ce3b6420
[1:1:0711/073003.144423:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0711/073003.180830:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/073003.180981:INFO:render_frame_impl.cc(7019)] 	 [url] = http://h5.cyol.com
[1:1:0711/073003.182075:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.140641, 54, 1
[1:1:0711/073003.182187:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/073003.506106:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/073003.506388:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.508404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc9cd198070 0x3997ce817ae0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.508942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.write("<style type=\"text/css\">*{margin:0;padding:0}a:link{text-decoration:none}a:visited{
[1:1:0711/073003.509062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073003.521294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc9cd198070 0x3997ce817ae0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.532390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc9cd198070 0x3997ce817ae0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.537191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc9cd198070 0x3997ce817ae0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.765687:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/073003.835139:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/073003.835278:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.835771:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7fc9cd198070 0x3997ce39d960 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.836860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , ,  wd_paramtracker('_wdxid=000000000000000000000000000000000000000000');
[1:1:0711/073003.837086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073003.848731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7fc9cd198070 0x3997ce39d960 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.857170:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7fc9cd198070 0x3997ce39d960 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.869447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073003.878529:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/073004.729997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346 0x7fc9cf0c02e0 0x3997ce871160 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.733796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , var _wdVersion = _wdVersion || {};
_wdVersion.WD = _wdVersion.WD || '0';
_wdVersion.CN = '1'; 
va
[1:1:0711/073004.733992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073004.754331:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.783176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 347 0x7fc9cf0c02e0 0x3997cdfeb860 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.785273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , var _wdVersion = _wdVersion || {};
_wdVersion.WD = _wdVersion.WD || '0';
_wdVersion.CN = '1'; 
va
[1:1:0711/073004.785489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073004.790478:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x13e973ae8e8
[1:1:0711/073004.791553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.918535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359 0x7fc9cf0c02e0 0x3997ce845ce0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.920192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , //21
//var _webdigObj = {};
_webdigObj.pro = function() {
	if(document.getElementById("webdig_sou
[1:1:0711/073004.920444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073004.924582:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.957620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360 0x7fc9cf0c02e0 0x3997ce87a7e0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073004.958538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , //21
//var _webdigObj = {};
_webdigObj.pro = function() {
	if(document.getElementById("webdig_sou
[1:1:0711/073004.958810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073004.959525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.037740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366 0x7fc9cf0c02e0 0x3997ce0e76e0 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.039010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , function _wdRST(articles) {
       var d = document.getElementById("_wdrecdiv"); 
       if (d) {
  
[1:1:0711/073005.039196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073005.040545:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.199993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367 0x7fc9cf0c02e0 0x3997ce8d6660 , "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.201296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , function _wdRST(articles) {
       var d = document.getElementById("_wdrecdiv"); 
       if (d) {
  
[1:1:0711/073005.201562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073005.203061:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.458294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.459119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , Aimg.onload, () {
        _wdGidT= Aimg.height;
        if (Aimg.height == 1) {
            _wd_ruid(_wdDU);  
[1:1:0711/073005.459401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073005.477737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php"
[1:1:0711/073005.478429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , Aimg.onload, () {
        _wdGidT= Aimg.height;
        if (Aimg.height == 1) {
            _wd_ruid(_wdDU);  
[1:1:0711/073005.478638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073006.785363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/073006.787778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[11177:11177:0711/073007.094988:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[11177:11177:0711/073007.103214:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 4, 
[11177:11177:0711/073007.125954:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://h5.cyol.com/
[11177:11177:0711/073007.156659:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cl2.webterren.com/webdig.js?z=21, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.cyol.com/2015011815183252.js (1)
[11177:11177:0711/073007.157930:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cl2.webterren.com/webdig.js?z=21, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.cyol.com/2015011815183252.js (1)
[3:3:0711/073007.246173:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/073007.499979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073007.500283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[11177:11177:0711/073008.076891:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11177:11177:0711/073008.083210:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11177:11177:0711/073008.094972:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://news.cyol.com/
[11177:11177:0711/073008.095086:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://news.cyol.com/, http://news.cyol.com/node_55922.htm, 4
[11177:11177:0711/073008.095265:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://news.cyol.com/, HTTP/1.1 200 OK Content-Type: text/html Connection: keep-alive Date: Thu, 11 Jul 2019 14:30:07 GMT Powered-By-ChinaCache: MISS from BGP-GZ-d-3WB Content-Length: 1320 CACHE: TCP_MISS Vary: Accept-Encoding Last-Modified: Wed, 13 Mar 2019 07:13:56 GMT Content-Encoding: gzip Server: cyol Powered-By-ChinaCache: MISS from GWB-FS-2-3WY CC_CACHE: TCP_MISS Accept-Ranges: bytes  ,11270, 5
[11177:11177:0711/073008.098784:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[11177:11188:0711/073008.099393:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[11177:11188:0711/073008.099445:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/073008.099965:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/073008.350636:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://news.cyol.com/
[1:1:0711/073008.386005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073008.386347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073008.623034:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[11177:11177:0711/073008.625552:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://news.cyol.com/, http://news.cyol.com/, 4
[11177:11177:0711/073008.625614:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 6, http://news.cyol.com/, http://news.cyol.com
[1:1:0711/073008.643322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073008.643608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073008.772377:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/073008.933194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073008.934039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073008.981296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/073008.981564:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.cyol.com/node_55922.htm"
[1:1:0711/073008.995336:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.013643, 82, 1
[1:1:0711/073008.995602:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/073009.054605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073009.054892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073009.201761:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/073009.202052:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.202882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7fc9cd198070 0x3997cec963e0 , "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.217851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , , document.write(unescape("%3Cscript src='http://cl2.webterren.com/webdig.js?z=21' type='text/javascri
[1:1:0711/073009.218174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073009.271095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073009.271448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073009.399752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522, "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.400779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , , var ROOTDM=[".cien.com.cn",".chinajilin.com.cn",".jilin.cn",".cyd.com.cn",".cyol.com",".cyol.net",".
[1:1:0711/073009.401110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073009.404655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522, "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.474820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073009.475272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073009.633873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073009.634280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073009.687258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543 0x7fc9cf0c02e0 0x3997cdfa88e0 , "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.690687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , , var _wdVersion = _wdVersion || {};
_wdVersion.WD = _wdVersion.WD || '0';
_wdVersion.CN = '1'; 
va
[1:1:0711/073009.690997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073009.706103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.cyol.com/node_55922.htm"
[1:1:0711/073009.861247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073009.861532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.019731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.020036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.055847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558 0x7fc9cf0c02e0 0x3997cef49a60 , "http://news.cyol.com/node_55922.htm"
[1:1:0711/073010.056604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , , //21
//var _webdigObj = {};
_webdigObj.pro = function() {
	if(document.getElementById("webdig_sou
[1:1:0711/073010.056863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073010.057519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.cyol.com/node_55922.htm"
[1:1:0711/073010.135795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.136095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.176209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.176473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.223870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 572 0x7fc9cf0c02e0 0x3997cef54160 , "http://news.cyol.com/node_55922.htm"
[1:1:0711/073010.224887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , , function _wdRST(articles) {
       var d = document.getElementById("_wdrecdiv"); 
       if (d) {
  
[1:1:0711/073010.225236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073010.226470:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.cyol.com/node_55922.htm"
[1:1:0711/073010.381818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.382100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.722999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.723266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073010.784504:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://news.cyol.com/node_55922.htm"
[1:1:0711/073010.785221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://news.cyol.com/, 030f723b3a78, , Aimg.onload, () {
        _wdGidT= Aimg.height;
        if (Aimg.height == 1) {
            _wd_ruid(_wdDU);  
[1:1:0711/073010.785560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://news.cyol.com/node_55922.htm", "news.cyol.com", 6, 1, http://h5.cyol.com, h5.cyol.com, 3
[1:1:0711/073010.959485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073010.960178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.057848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.058140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.141713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.141985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.199967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.200151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.272840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.273007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.298514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.298685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.343135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.343301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.394203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.394367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.431817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.431988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.482522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.482690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.521410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.521619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.557050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.822312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.906941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.907118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.969289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.969658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073011.997703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073011.997958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.027989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.028254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.069011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.069342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.123588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.123913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.173814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.174081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.209070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.209407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.255921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.256200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.295944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.296227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.348443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.348615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.406175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.406335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.434214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.434392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.480138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.480417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.517979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.518151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.555667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.555871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.622763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.623024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.686439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.686684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.730507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.730681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.781510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.781686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.836000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.836177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.899335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.899646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073012.971821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073012.972062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.024997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.025173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/073013.102065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.102239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.148476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.148658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.175095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.175269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.234485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.234782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.316208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.316453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
[1:1:0711/073013.447231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://h5.cyol.com/, 030f72282860, , , document.readyState
[1:1:0711/073013.447392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://h5.cyol.com/special/daxuexi/daxuexi4e3/index.php", "h5.cyol.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
