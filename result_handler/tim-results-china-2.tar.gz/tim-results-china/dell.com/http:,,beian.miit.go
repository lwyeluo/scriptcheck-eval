[0712/065051.999124:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/065051.999508:INFO:switcher_clone.cc(787)] backtrace rip is 7f17fe5bc891
[0712/065053.090732:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/065053.090983:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f816d7891
[1:1:0712/065053.094992:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/065053.095178:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/065053.106906:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[94404:94404:0712/065054.179600:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/673784f8-2c06-4138-8ec7-572d7aa62edb
[0712/065054.645060:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/065054.645533:INFO:switcher_clone.cc(787)] backtrace rip is 7f2c084a9891
[94404:94404:0712/065054.657133:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[94404:94434:0712/065054.658056:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/065054.658253:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/065054.658465:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/065054.659067:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/065054.659219:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/065054.662083:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x306366c8, 1
[1:1:0712/065054.662421:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x249073af, 0
[1:1:0712/065054.662634:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x322c497b, 3
[1:1:0712/065054.662889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2821c732, 2
[1:1:0712/065054.663148:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffaf73ffffff9024 ffffffc8666330 32ffffffc72128 7b492c32 , 10104, 4
[1:1:0712/065054.664137:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[94404:94434:0712/065054.664407:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�s�$�fc02�!({I,2�
[94404:94434:0712/065054.664475:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �s�$�fc02�!({I,21�
[1:1:0712/065054.664401:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f7f9120a0, 3
[1:1:0712/065054.664725:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f7fa9d080, 2
[94404:94434:0712/065054.664900:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[94404:94434:0712/065054.664980:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 94449, 4, af739024 c8666330 32c72128 7b492c32 
[1:1:0712/065054.664961:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f69760d20, -2
[1:1:0712/065054.682932:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/065054.684092:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2821c732
[1:1:0712/065054.685039:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2821c732
[1:1:0712/065054.686732:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2821c732
[1:1:0712/065054.688478:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.688717:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.688962:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.689200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.689864:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2821c732
[1:1:0712/065054.690254:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f816d77ba
[1:1:0712/065054.690432:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f816cedef, 7f7f816d777a, 7f7f816d90cf
[1:1:0712/065054.696215:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2821c732
[1:1:0712/065054.696596:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2821c732
[1:1:0712/065054.697382:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2821c732
[1:1:0712/065054.699432:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.699688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.699921:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.700160:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2821c732
[1:1:0712/065054.701208:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2821c732
[1:1:0712/065054.701610:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f816d77ba
[1:1:0712/065054.701788:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f816cedef, 7f7f816d777a, 7f7f816d90cf
[1:1:0712/065054.706318:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/065054.706757:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/065054.706935:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0a191668, 0x7ffd0a1915e8)
[1:1:0712/065054.723783:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/065054.729868:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[94438:94438:0712/065054.996153:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=94438
[94474:94474:0712/065054.996583:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=94474
[94404:94404:0712/065055.094900:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[94404:94404:0712/065055.097433:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[94404:94404:0712/065055.108623:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[94404:94415:0712/065055.108603:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[94404:94404:0712/065055.108689:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[94404:94415:0712/065055.108722:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[94404:94404:0712/065055.108758:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,94449, 4
[1:7:0712/065055.110564:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[94404:94427:0712/065055.182454:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/065055.189865:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x5340465f220
[1:1:0712/065055.190572:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/065055.447104:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/065056.816142:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065056.820092:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[94404:94404:0712/065056.968657:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[94404:94404:0712/065056.968797:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/065057.875012:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/065058.050270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/065058.050599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065058.067842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/065058.068208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065058.386261:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/065058.386549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065058.849153:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065058.857347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/065058.857625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065058.908597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065058.919135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/065058.919382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065058.931048:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[94404:94404:0712/065058.933642:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/065058.934392:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5340465de20
[1:1:0712/065058.934562:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[94404:94404:0712/065058.941721:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[94404:94404:0712/065058.995388:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[94404:94404:0712/065058.995543:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/065059.046811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065059.937290:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f7f6b33b2e0 0x53404829e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065059.938624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/065059.938834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065059.940280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[94404:94404:0712/065100.018063:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/065100.022984:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x5340465e820
[1:1:0712/065100.023263:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[94404:94404:0712/065100.025225:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/065100.036183:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/065100.036606:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[94404:94404:0712/065100.042910:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[94404:94404:0712/065100.047664:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[94404:94404:0712/065100.048770:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[94404:94404:0712/065100.054982:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[94404:94404:0712/065100.055082:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[94404:94404:0712/065100.055225:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,94449, 4
[94404:94415:0712/065100.056629:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[94404:94415:0712/065100.056717:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/065100.057686:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/065100.782079:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/065101.176378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f7f6b33b2e0 0x534049e22e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065101.177408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/065101.177644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065101.178412:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[94404:94404:0712/065101.321143:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[94404:94404:0712/065101.321223:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/065101.349319:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/065101.865546:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[94404:94404:0712/065102.210795:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[94404:94434:0712/065102.211609:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/065102.212058:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/065102.212465:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/065102.213192:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/065102.213409:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/065102.217518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe73f1c5, 1
[1:1:0712/065102.218470:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x4ffd4fd, 0
[1:1:0712/065102.218871:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3015ffd8, 3
[1:1:0712/065102.219272:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x117cc126, 2
[1:1:0712/065102.219644:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffdffffffd4ffffffff04 ffffffc5fffffff1730e 26ffffffc17c11 ffffffd8ffffffff1530 , 10104, 5
[1:1:0712/065102.221792:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[94404:94434:0712/065102.222510:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�����s&�|��0m�
[94404:94434:0712/065102.223154:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �����s&�|��0Ȇm�
[1:1:0712/065102.222515:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f7f9120a0, 3
[94404:94434:0712/065102.223848:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 94500, 5, fdd4ff04 c5f1730e 26c17c11 d8ff1530 
[1:1:0712/065102.223736:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f7fa9d080, 2
[1:1:0712/065102.224926:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f69760d20, -2
[1:1:0712/065102.260534:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/065102.260965:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 117cc126
[1:1:0712/065102.261379:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 117cc126
[1:1:0712/065102.262115:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 117cc126
[1:1:0712/065102.263644:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.263959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.264213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.264459:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.265215:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 117cc126
[1:1:0712/065102.265579:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f816d77ba
[1:1:0712/065102.265777:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f816cedef, 7f7f816d777a, 7f7f816d90cf
[1:1:0712/065102.271855:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 117cc126
[1:1:0712/065102.272337:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 117cc126
[1:1:0712/065102.273172:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 117cc126
[1:1:0712/065102.275350:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.275637:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.275901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.276172:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 117cc126
[1:1:0712/065102.277529:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 117cc126
[1:1:0712/065102.277971:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f816d77ba
[1:1:0712/065102.278189:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f816cedef, 7f7f816d777a, 7f7f816d90cf
[1:1:0712/065102.286386:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/065102.286859:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/065102.287106:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd0a191668, 0x7ffd0a1915e8)
[1:1:0712/065102.301649:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/065102.306074:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/065102.316413:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/065102.316651:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/065102.537429:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x5340462c220
[1:1:0712/065102.537682:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/065102.561714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/065102.566144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2211f1c0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/065102.566513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/065102.572739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[94404:94404:0712/065102.588701:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[94404:94404:0712/065102.594671:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[94404:94415:0712/065102.634254:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[94404:94415:0712/065102.634353:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[94404:94404:0712/065102.635611:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[94404:94404:0712/065102.635695:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[94404:94404:0712/065102.635819:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:51:02 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: JSESSIONID=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682; path=/; HttpOnly Content-Encoding: gzip X-Via-JSL: 0b3d685,- Set-Cookie: __jsluid_h=9a1d6f8aef1927e16b61ba1cc5e408cc; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,94500, 5
[1:7:0712/065102.642086:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/065102.752418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/065102.753224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2211f1ae1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/065102.753452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/065102.754950:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0712/065102.902763:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[94404:94404:0712/065102.910176:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[94404:94404:0712/065102.910270:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/065102.949778:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/065102.965220:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/065102.966843:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/065102.967059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2211f1c0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/065102.967352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/065103.037633:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/065103.037910:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/"
[1:1:0712/065103.132256:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/065103.133122:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/065103.133489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2211f1c0e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/065103.133906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/065103.211710:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/styles/styles.css"
[1:1:0712/065103.426163:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7f7f7fa9d080 0x53404774560 1 0 0x53404774578 , "http://beian.miit.gov.cn/"
[1:1:0712/065103.432069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/065103.432332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/065103.696524:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/065104.032653:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065104.033187:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065104.033573:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065104.033965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065104.034294:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065104.509641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7f7f7fa9d080 0x53404774560 1 0 0x53404774578 , "http://beian.miit.gov.cn/"
[1:1:0712/065104.514829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3db703b229c8, 0x534043f01a0
[1:1:0712/065104.515062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://beian.miit.gov.cn/", 0
[1:1:0712/065104.515474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146
[1:1:0712/065104.515802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 146 0x7f7f69413070 0x534047233e0 , 5:3_http://beian.miit.gov.cn/, 1, -5:3_http://beian.miit.gov.cn/, 139 0x7f7f7fa9d080 0x53404774560 1 0 0x53404774578 
[1:1:0712/065104.525844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://beian.miit.gov.cn/"
[1:1:0712/065104.611679:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/065104.611991:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/065104.635062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146, 7f7f6bd58881
[1:1:0712/065104.642261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35b672b42860","ptid":"139 0x7f7f7fa9d080 0x53404774560 1 0 0x53404774578 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/065104.642641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://beian.miit.gov.cn/","ptid":"139 0x7f7f7fa9d080 0x53404774560 1 0 0x53404774578 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/065104.642941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://beian.miit.gov.cn/"
[1:1:0712/065104.643675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , (){if(D.isReady)return;if(document.readyState!="loaded"&&document.readyState!="complete"){setTimeout
[1:1:0712/065104.643907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/065122.992582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/065122.992845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[94404:94404:0712/065123.460985:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[94404:94404:0712/065123.516680:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/065123.527622:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[94404:94404:0712/065123.773404:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[94404:94404:0712/065123.774370:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[94404:94415:0712/065123.781964:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[94404:94404:0712/065123.782022:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[94404:94404:0712/065123.782069:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682, 1
[94404:94415:0712/065123.782068:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[94404:94404:0712/065123.782115:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:51:23 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: en-US Content-Encoding: gzip X-Via-JSL: 0b3d685,- X-Cache: bypass  ,94500, 5
[1:7:0712/065123.785206:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/065124.075209:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0712/065124.154325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "unload", "http://beian.miit.gov.cn/"
[1:1:0712/065124.155113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , (){if(typeof D!="undefined"&&!D.event.triggered)return D.event.handle.apply(arguments.callee.elem,ar
[1:1:0712/065124.155361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/065124.299053:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[94404:94404:0712/065124.305623:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[94404:94404:0712/065124.305722:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/065124.502887:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/065124.523493:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/065124.641073:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/065124.641355:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065125.075656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065125.081277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/065125.081504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/065126.163521:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065126.164039:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/065126.182455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065126.190171:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065126.198486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065126.253287:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 302, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065126.255856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 35b672b42860, , , function maskDialog1(w,h)
{
    // public properties start
    this.mainForm;
    this.mainFormW
[1:1:0712/065126.256037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/065126.267092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 302, "http://beian.miit.gov.cn/state/outPortal/loginPortal.action;jsessionid=QEHmfYCZeLMGGtMTSq2FRX5KiJdNT8z5GFbBGTIXeLpKh42IKiwS!1412419682"
[1:1:0712/065126.633367:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.375472, 1427, 1
[1:1:0712/065126.633573:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
