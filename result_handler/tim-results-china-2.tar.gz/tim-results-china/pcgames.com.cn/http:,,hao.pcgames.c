[0712/043504.679217:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043504.679478:INFO:switcher_clone.cc(787)] backtrace rip is 7fafa9f34891
[0712/043505.735215:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043505.735750:INFO:switcher_clone.cc(787)] backtrace rip is 7fc3a1e61891
[1:1:0712/043505.750204:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043505.750547:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043505.756787:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[75625:75625:0712/043507.035920:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/cc125d95-e65f-4974-abaa-393f87cc2353
[0712/043507.287753:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043507.288176:INFO:switcher_clone.cc(787)] backtrace rip is 7fb6b18f4891
[75625:75625:0712/043507.435435:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[75625:75654:0712/043507.436262:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043507.436511:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043507.436785:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043507.437381:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043507.437541:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043507.440519:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c1120a, 1
[1:1:0712/043507.440927:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33536fb4, 0
[1:1:0712/043507.441132:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c9653cd, 3
[1:1:0712/043507.441325:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd2a06c8, 2
[1:1:0712/043507.441571:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb46f5333 0a12ffffffc103 ffffffc8062a0d ffffffcd53ffffff961c , 10104, 4
[1:1:0712/043507.442819:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75625:75654:0712/043507.443131:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�oS3
��*�S�%�&
[75625:75654:0712/043507.443207:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �oS3
��*�S�8�%�&
[1:1:0712/043507.443120:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc3a009c0a0, 3
[1:1:0712/043507.443399:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc3a0227080, 2
[75625:75654:0712/043507.443542:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[75625:75654:0712/043507.443616:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75670, 4, b46f5333 0a12c103 c8062a0d cd53961c 
[1:1:0712/043507.443597:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc389eead20, -2
[1:1:0712/043507.460981:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043507.462082:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d2a06c8
[1:1:0712/043507.463283:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d2a06c8
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/043507.465340:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d2a06c8
[1:1:0712/043507.467279:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.467524:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.467821:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.468053:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.468921:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d2a06c8
[1:1:0712/043507.469322:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc3a1e617ba
[1:1:0712/043507.469501:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc3a1e58def, 7fc3a1e6177a, 7fc3a1e630cf
[1:1:0712/043507.475155:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d2a06c8
[1:1:0712/043507.475534:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d2a06c8
[1:1:0712/043507.476290:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d2a06c8
[1:1:0712/043507.478733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.478987:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.479244:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.479517:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2a06c8
[1:1:0712/043507.481116:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d2a06c8
[1:1:0712/043507.481567:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc3a1e617ba
[1:1:0712/043507.481761:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc3a1e58def, 7fc3a1e6177a, 7fc3a1e630cf
[1:1:0712/043507.491454:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043507.492118:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043507.492301:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe28f8db18, 0x7ffe28f8da98)
[1:1:0712/043507.510477:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043507.518401:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[75656:75656:0712/043507.540994:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75656
[75678:75678:0712/043507.541553:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75678
[75625:75625:0712/043507.921752:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75625:75625:0712/043507.922904:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75625:75636:0712/043507.942065:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[75625:75636:0712/043507.942169:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[75625:75625:0712/043507.942401:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[75625:75625:0712/043507.942499:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[75625:75625:0712/043507.942676:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,75670, 4
[1:7:0712/043507.944882:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[75625:75647:0712/043507.957615:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/043508.014013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2a9faf44c220
[1:1:0712/043508.014309:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043508.325176:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/043509.777329:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043509.781909:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[75625:75625:0712/043509.820893:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[75625:75625:0712/043509.820983:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043510.520547:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043510.635843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043510.636137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043510.652056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043510.652312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043510.877002:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043510.877260:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043511.197819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043511.205892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043511.206150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043511.240601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043511.251100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043511.251358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043511.263150:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[75625:75625:0712/043511.264751:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043511.266507:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a9faf44ae20
[1:1:0712/043511.266722:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[75625:75625:0712/043511.278901:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[75625:75625:0712/043511.293599:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[75625:75625:0712/043511.293704:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[75625:75625:0712/043511.299563:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/043511.323737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043511.847417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7fc38bac52e0 0x2a9faf63d160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043511.848757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043511.849004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043511.850440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75625:75625:0712/043511.886246:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043511.888070:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2a9faf44b820
[1:1:0712/043511.888305:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[75625:75625:0712/043511.890650:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043511.903356:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043511.903629:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[75625:75625:0712/043511.907325:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[75625:75625:0712/043511.914384:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75625:75625:0712/043511.915411:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75625:75636:0712/043511.921720:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[75625:75636:0712/043511.921821:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[75625:75625:0712/043511.922085:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[75625:75625:0712/043511.922180:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[75625:75625:0712/043511.922353:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,75670, 4
[1:7:0712/043511.927030:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043512.406509:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043513.011733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7fc38bac52e0 0x2a9faf7dd7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043513.014186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043513.014425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043513.015207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75625:75625:0712/043513.078959:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[75625:75625:0712/043513.079066:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043513.108230:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043513.411244:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043513.923392:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043513.923687:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043514.298682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 534, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043514.303288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3fb7abaae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043514.303929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043514.314257:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043514.455505:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043514.456224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3fb7ab981f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043514.456506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[75625:75625:0712/043514.683698:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[75625:75654:0712/043514.684419:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043514.684849:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043514.685220:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043514.685708:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043514.685950:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043514.689545:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5aa6f7b, 1
[1:1:0712/043514.690288:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xb2b9bff, 0
[1:1:0712/043514.690655:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x394241a1, 3
[1:1:0712/043514.690973:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6b446aa, 2
[1:1:0712/043514.691300:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffffffffff9b2b0b 7b6fffffffaa05 ffffffaa46ffffffb406 ffffffa1414239 , 10104, 5
[1:1:0712/043514.693389:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75625:75654:0712/043514.693886:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��+{o��F��AB9|�&
[75625:75654:0712/043514.694057:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��+{o��F��AB9�t|�&
[75625:75654:0712/043514.694394:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75722, 5, ff9b2b0b 7b6faa05 aa46b406 a1414239 
[1:1:0712/043514.694286:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc3a009c0a0, 3
[1:1:0712/043514.694790:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc3a0227080, 2
[1:1:0712/043514.695189:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc389eead20, -2
[1:1:0712/043514.707699:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043514.707903:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6b446aa
[1:1:0712/043514.708076:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6b446aa
[1:1:0712/043514.708342:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6b446aa
[1:1:0712/043514.708894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.708994:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.709084:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.708748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043514.709174:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.709403:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6b446aa
[1:1:0712/043514.709564:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc3a1e617ba
[1:1:0712/043514.709652:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc3a1e58def, 7fc3a1e6177a, 7fc3a1e630cf
[1:1:0712/043514.710302:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043514.710523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3fb7abaae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043514.710790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043514.711373:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6b446aa
[1:1:0712/043514.711569:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6b446aa
[1:1:0712/043514.711872:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6b446aa
[1:1:0712/043514.712725:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.712946:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.713146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.713336:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6b446aa
[1:1:0712/043514.714583:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6b446aa
[1:1:0712/043514.714942:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc3a1e617ba
[1:1:0712/043514.715074:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc3a1e58def, 7fc3a1e6177a, 7fc3a1e630cf
[1:1:0712/043514.722768:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043514.723264:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043514.723428:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe28f8db18, 0x7ffe28f8da98)
[1:1:0712/043514.739784:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043514.745332:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043514.833818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043514.834667:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043514.834864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3fb7abaae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043514.835118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043515.029514:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2a9faf417220
[1:1:0712/043515.029747:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[75625:75625:0712/043515.188351:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75625:75625:0712/043515.192808:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/043515.201462:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[75625:75636:0712/043515.218504:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[75625:75636:0712/043515.218598:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[75625:75625:0712/043515.220470:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://hao.pcgames.com.cn/
[75625:75625:0712/043515.220554:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn/item-20573.html, 1
[75625:75625:0712/043515.220718:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://hao.pcgames.com.cn/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 11:35:15 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,75722, 5
[1:7:0712/043515.222840:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043515.294811:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://hao.pcgames.com.cn/
[75625:75625:0712/043515.446293:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn/, 1
[75625:75625:0712/043515.446400:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn
[1:1:0712/043515.464080:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043515.577915:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043515.671567:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043515.671830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043515.760205:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/043515.814679:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/043515.894655:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/043516.000057:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/043516.043307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 135, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043516.045291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||
[1:1:0712/043516.045537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043516.066254:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043516.086165:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/043516.206724:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/043516.295072:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/043516.344467:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043516.345432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3fb7abaae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/043516.345731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043516.413741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043516.414671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3fb7abaae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/043516.414963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043516.684837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043516.685696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043516.685914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043516.688254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043516.700543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 179, "http://hao.pcgames.com.cn/item-20573.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043517.832361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043517.833233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043517.833473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043517.988499:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043517.990944:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043517.991270:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043517.991700:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043517.992027:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043518.133740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 277 0x7fc38bac52e0 0x2a9faf5dcee0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043518.134705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043518.136554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043518.242205:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043518.404226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7fc38bac52e0 0x2a9faf62ee60 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043518.409438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (function(){var h={},mt={},c={id:"5284a74a6d44c732746f8d7e14a4d920",dm:["pcgames.com.cn"],js:"tongji
[1:1:0712/043518.409680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043518.441289:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd190
[1:1:0712/043518.441558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043518.442012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 302
[1:1:0712/043518.442246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 302 0x7fc389b9d070 0x2a9faf52d760 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 295 0x7fc38bac52e0 0x2a9faf62ee60 
[75625:75625:0712/043534.133963:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043534.140364:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043534.330024:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043534.330294:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.333700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fc389b9d070 0x2a9faf5240e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.334513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043534.334732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043534.340565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fc389b9d070 0x2a9faf5240e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.343166:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fc389b9d070 0x2a9faf5240e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.344304:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 999, 0x3979827229c8, 0x2a9faedcd2b0
[1:1:0712/043534.344628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 999
[1:1:0712/043534.345061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 364
[1:1:0712/043534.345295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 364 0x7fc389b9d070 0x2a9faf488ee0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 297 0x7fc389b9d070 0x2a9faf5240e0 
[1:1:0712/043534.410001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fc389b9d070 0x2a9faf5240e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.413447:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7fc389b9d070 0x2a9faf5240e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043534.622605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043534.622916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043535.193560:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 302, 7fc38c4e2881
[1:1:0712/043535.206519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"295 0x7fc38bac52e0 0x2a9faf62ee60 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043535.206887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"295 0x7fc38bac52e0 0x2a9faf62ee60 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043535.207227:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043535.207888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043535.208115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043535.208964:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043535.209180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043535.209631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 388
[1:1:0712/043535.209867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7fc389b9d070 0x2a9faf4d3260 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 302 0x7fc389b9d070 0x2a9faf52d760 
[75625:75625:0712/043535.267510:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[75625:75625:0712/043535.271961:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[1:1:0712/043535.499193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 369, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043535.501666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (function(){function p(){this.c="1261263986";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/043535.501908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[75625:75625:0712/043535.568542:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[75625:75625:0712/043535.577207:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[1:1:0712/043536.051990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043536.052307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043536.056061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 388, 7fc38c4e2881
[1:1:0712/043536.080960:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"302 0x7fc389b9d070 0x2a9faf52d760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043536.081348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"302 0x7fc389b9d070 0x2a9faf52d760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043536.081721:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043536.082395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043536.082650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043536.083414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043536.083658:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043536.084191:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 436
[1:1:0712/043536.084481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7fc389b9d070 0x2a9faf8f44e0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 388 0x7fc389b9d070 0x2a9faf4d3260 
[1:1:0712/043536.086339:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 364, 7fc38c4e2881
[1:1:0712/043536.108063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"297 0x7fc389b9d070 0x2a9faf5240e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043536.108415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"297 0x7fc389b9d070 0x2a9faf5240e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043536.108771:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043536.109414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var js=document.createElement("script"); js.src="http://tga.pcgames.com.cn/adpuba/show?id=pcgames
[1:1:0712/043536.109633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043536.406767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043536.408776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/043536.409082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043536.511230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423, "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043536.515412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043536.515774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043536.700360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043536.700742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.007856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 436, 7fc38c4e2881
[1:1:0712/043537.029974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"388 0x7fc389b9d070 0x2a9faf4d3260 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043537.030384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"388 0x7fc389b9d070 0x2a9faf4d3260 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043537.030729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043537.031383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043537.031657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.032489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043537.032705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043537.033146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 474
[1:1:0712/043537.033482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7fc389b9d070 0x2a9faf5285e0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 436 0x7fc389b9d070 0x2a9faf8f44e0 
[1:1:0712/043537.109206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043537.110013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043537.110390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.195302:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043537.320942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043537.321324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.451547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fc38bac52e0 0x2a9faf5909e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043537.452463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043537.452682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.546229:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 474, 7fc38c4e2881
[1:1:0712/043537.567811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"436 0x7fc389b9d070 0x2a9faf8f44e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043537.568248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"436 0x7fc389b9d070 0x2a9faf8f44e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043537.568584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043537.569214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043537.569440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043537.570237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043537.570468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043537.570883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 488
[1:1:0712/043537.571109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 488 0x7fc389b9d070 0x2a9faf988fe0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 474 0x7fc389b9d070 0x2a9faf5285e0 
[1:1:0712/043537.595591:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043537.595880:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043537.611595:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0155759, 88, 1
[1:1:0712/043537.611898:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043537.637135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043537.637451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043538.024805:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043538.025142:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043538.028414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7fc389b9d070 0x2a9faf7d73e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043538.029313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , 
[1:1:0712/043538.029528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043538.046085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7fc389b9d070 0x2a9faf7d73e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043538.064691:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[75625:75625:0712/043538.066445:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043538.068788:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2a9fafa15020
[1:1:0712/043538.069546:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[75625:75625:0712/043538.078023:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/043538.086999:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043538.087255:INFO:render_frame_impl.cc(7019)] 	 [url] = http://hao.pcgames.com.cn
[75625:75625:0712/043538.093740:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://hao.pcgames.com.cn/
[1:1:0712/043538.171724:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.146474, 718, 1
[1:1:0712/043538.172037:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043538.191567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043538.191885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043538.204899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 488, 7fc38c4e2881
[1:1:0712/043538.235560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"474 0x7fc389b9d070 0x2a9faf5285e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043538.235969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"474 0x7fc389b9d070 0x2a9faf5285e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043538.236472:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043538.237140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043538.237394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043538.238536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043538.238749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043538.239243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 560
[1:1:0712/043538.239478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 560 0x7fc389b9d070 0x2a9faf525e60 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 488 0x7fc389b9d070 0x2a9faf988fe0 
[75625:75625:0712/043538.240931:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75625:75625:0712/043538.248438:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75625:75636:0712/043538.270933:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[75625:75625:0712/043538.270998:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[75625:75625:0712/043538.271042:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1, 4
[75625:75636:0712/043538.271034:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[75625:75625:0712/043538.271105:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 11:35:38 GMT Content-Type: text/html Content-Length: 9427 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.b635acd.5d28708a.2100ebb6; path=/; expires=Mon, 09-Jul-29 11:35:38 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.b745acd.5d28708a.30b9a811; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=60, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 11:40:38 GMT Last-Modified: Fri, 12 Jul 2019 11:35:38 GMT DPOOL_HEADER: qubele36 Content-Encoding: gzip LB_HEADER: venus240 Strict-Transport-Security: max-age=31536000; preload  ,75722, 5
[1:7:0712/043538.274168:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043540.369381:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043540.369663:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043540.373933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7fc389b9d070 0x2a9faf6996e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043540.375679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , /*@update 20120427 增加pos参数选择浮窗左右位置*/
(function(){
	if(!document.getElement
[1:1:0712/043540.376001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043540.396158:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7fc389b9d070 0x2a9faf6996e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043540.399210:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0293751, 51, 1
[1:1:0712/043540.399458:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043540.436579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043540.436929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043540.507461:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://widget.weibo.com/
[1:1:0712/043540.608073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 560, 7fc38c4e2881
[1:1:0712/043540.636439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"488 0x7fc389b9d070 0x2a9faf988fe0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043540.636811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"488 0x7fc389b9d070 0x2a9faf988fe0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043540.637186:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043540.637803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043540.638035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043540.638775:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043540.639006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043540.639433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 604
[1:1:0712/043540.639675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7fc389b9d070 0x2a9fafc5bfe0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 560 0x7fc389b9d070 0x2a9faf525e60 
[1:1:0712/043541.609433:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043541.609726:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.615062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.618714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (function(c,f){if(c.PCgroup){return}var b,d=Object.prototype.toString,e=Array.prototype.slice,a=c.do
[1:1:0712/043541.618955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043541.729368:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.748918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.967229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.977026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.981152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.983983:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.987083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043541.992442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.004713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.027780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.032553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.037788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.042562:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.045461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 598 0x7fc389b9d070 0x2a9faf65f9e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.053996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.055476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.056976:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hao.pcgames.com.cn/item-20573.html"
		remove user.10_ee5641c0 -> 0
		remove user.11_31c114fa -> 0
		remove user.12_897bd2f5 -> 0
		remove user.13_5f43e0c6 -> 0
		remove user.14_e3e141e6 -> 0
[1:1:0712/043542.445080:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043542.445666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 681
[1:1:0712/043542.445946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7fc389b9d070 0x2a9fb03b9c60 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 598 0x7fc389b9d070 0x2a9faf65f9e0 
[1:1:0712/043542.466947:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 5000
[1:1:0712/043542.467464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 682
[1:1:0712/043542.467729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7fc389b9d070 0x2a9fafd36ce0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 598 0x7fc389b9d070 0x2a9faf65f9e0 
[1:1:0712/043542.810845:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043542.811397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 693
[1:1:0712/043542.811685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7fc389b9d070 0x2a9fafd37a60 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 598 0x7fc389b9d070 0x2a9faf65f9e0 
[1:1:0712/043542.836102:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 5000
[1:1:0712/043542.836710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 694
[1:1:0712/043542.836968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7fc389b9d070 0x2a9fafd50be0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 598 0x7fc389b9d070 0x2a9faf65f9e0 
[1:1:0712/043542.845570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043542.978164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043542.978484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043543.036129:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[75625:75625:0712/043543.037264:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/, 4
[75625:75625:0712/043543.037362:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0712/043543.076929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 604, 7fc38c4e2881
[1:1:0712/043543.091286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"560 0x7fc389b9d070 0x2a9faf525e60 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043543.091674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"560 0x7fc389b9d070 0x2a9faf525e60 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043543.092039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043543.092703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043543.092921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043543.093685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043543.093897:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043543.094329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 712
[1:1:0712/043543.094610:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7fc389b9d070 0x2a9fb03be560 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 604 0x7fc389b9d070 0x2a9fafc5bfe0 
[1:1:0712/043543.348728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 626 0x7fc38bac52e0 0x2a9fafd45460 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043543.349893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , var bdShare=bdShare||{version:"1.0"};bdShare.ready=bdShare.ready||function(B,C){C=C||document;if(/co
[1:1:0712/043543.350121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043544.635807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043544.636200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043544.638211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 681, 7fc38c4e28db
[1:1:0712/043544.651588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043544.651799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043544.652037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 750
[1:1:0712/043544.652158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7fc389b9d070 0x2a9fafd38d60 , 5:3_http://hao.pcgames.com.cn/, 0, , 681 0x7fc389b9d070 0x2a9fb03b9c60 
[1:1:0712/043544.652318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043544.652634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043544.652747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043544.660219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 693, 7fc38c4e28db
[1:1:0712/043544.698081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043544.698484:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043544.698903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 751
[1:1:0712/043544.699171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7fc389b9d070 0x2a9fafa02ce0 , 5:3_http://hao.pcgames.com.cn/, 0, , 693 0x7fc389b9d070 0x2a9fafd37a60 
[1:1:0712/043544.699531:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043544.700285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043544.700512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043544.765909:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043544.788469:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043545.001801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 712, 7fc38c4e2881
[1:1:0712/043545.025224:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"604 0x7fc389b9d070 0x2a9fafc5bfe0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043545.025434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"604 0x7fc389b9d070 0x2a9fafc5bfe0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043545.025651:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043545.026045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043545.026161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043545.026478:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043545.026579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043545.026762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 759
[1:1:0712/043545.026879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7fc389b9d070 0x2a9fafd52760 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 712 0x7fc389b9d070 0x2a9fb03be560 
[1:1:0712/043545.678193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 740 0x7fc38bac52e0 0x2a9fafd5dae0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043545.684511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , /*!svn:http://zzsvn.pcauto.com.cn/svn/data/pcgames/commom/js/pcgames.login.1.0.js*/
(function(h,k){f
[1:1:0712/043545.684757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043545.779286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7fc38bac52e0 0x2a9fafd2f6e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043545.784179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , var bdShare=bdShare||{version:"1.0"};(function(){var P=new Date().getTime();var N=new Date().getTime
[1:1:0712/043545.784410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[75625:75625:0712/043545.816394:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043545.818721:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2a9fafe5c420
[1:1:0712/043545.818918:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[75625:75625:0712/043545.822850:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[75625:75625:0712/043545.865277:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn/, 5
[75625:75625:0712/043545.865425:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn
[1:1:0712/043545.887078:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[75625:75625:0712/043545.896426:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043545.902466:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x2a9fafe5ce20
[1:1:0712/043545.902669:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[75625:75625:0712/043545.903083:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[75625:75625:0712/043545.939582:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn/, 6
[75625:75625:0712/043545.939674:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://hao.pcgames.com.cn/, http://hao.pcgames.com.cn
[1:1:0712/043546.151419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043546.151670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043546.175804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043546.176088:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043546.205126:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 752 0x7fc389b9d070 0x2a9fafa02de0 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043546.227822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , , 
            var $CONFIG = {
                $lang: "zh",
                $oid: "",
                
[1:1:0712/043546.228063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043546.450271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 762 0x7fc38bac52e0 0x2a9faf5329e0 , "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043546.451003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , var bdShare=bdShare||{};bdShare._LogPool=bdShare._LogPool||[],bdShare.ApiPVLogger||function(e){funct
[1:1:0712/043546.451119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043546.477513:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 759, 7fc38c4e2881
[1:1:0712/043546.489576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"712 0x7fc389b9d070 0x2a9fb03be560 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043546.489769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"712 0x7fc389b9d070 0x2a9fb03be560 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043546.489950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043546.490264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043546.490370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043546.490718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043546.490816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043546.490999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 841
[1:1:0712/043546.491108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7fc389b9d070 0x2a9fafd371e0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 759 0x7fc389b9d070 0x2a9fafd52760 
[1:1:0712/043548.087017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043548.087200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043548.605552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 841, 7fc38c4e2881
[1:1:0712/043548.642133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"759 0x7fc389b9d070 0x2a9fafd52760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043548.642440:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"759 0x7fc389b9d070 0x2a9fafd52760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043548.642744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043548.643381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043548.643559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043548.644302:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043548.644470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043548.644835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 877
[1:1:0712/043548.645042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7fc389b9d070 0x2a9faeffe760 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 841 0x7fc389b9d070 0x2a9fafd371e0 
[1:1:0712/043549.113360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043549.114100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , M.D.onload, (){bdShare.velocity.cssLoadEnd=+new Date()}
[1:1:0712/043549.114284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043549.412952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 682, 7fc38c4e28db
[1:1:0712/043549.450805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043549.451185:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043549.451566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 901
[1:1:0712/043549.451839:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7fc389b9d070 0x2a9faf5b6360 , 5:3_http://hao.pcgames.com.cn/, 0, , 682 0x7fc389b9d070 0x2a9fafd36ce0 
[1:1:0712/043549.452175:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043549.452770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043549.452983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043549.463640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043549.464095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 903
[1:1:0712/043549.464345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7fc389b9d070 0x2a9fb045cae0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 682 0x7fc389b9d070 0x2a9fafd36ce0 
[1:1:0712/043549.575801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043549.576103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043549.579384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 694, 7fc38c4e28db
[1:1:0712/043549.617974:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043549.618344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"598 0x7fc389b9d070 0x2a9faf65f9e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043549.618735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 907
[1:1:0712/043549.618977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7fc389b9d070 0x2a9faeff5660 , 5:3_http://hao.pcgames.com.cn/, 0, , 694 0x7fc389b9d070 0x2a9fafd50be0 
[1:1:0712/043549.619286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043549.619873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043549.620112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043549.650975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043549.651503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 908
[1:1:0712/043549.651787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 908 0x7fc389b9d070 0x2a9fafd1dae0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 694 0x7fc389b9d070 0x2a9fafd50be0 
[1:1:0712/043549.795420:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043550.031050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 877, 7fc38c4e2881
[1:1:0712/043550.051704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"841 0x7fc389b9d070 0x2a9fafd371e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.052074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"841 0x7fc389b9d070 0x2a9fafd371e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.052479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043550.053069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043550.053308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043550.054053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043550.054278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043550.054711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 917
[1:1:0712/043550.054943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7fc389b9d070 0x2a9fb0569960 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 877 0x7fc389b9d070 0x2a9faeffe760 
[1:1:0712/043550.750763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 903, 7fc38c4e28db
[1:1:0712/043550.799537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"682 0x7fc389b9d070 0x2a9fafd36ce0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.799935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"682 0x7fc389b9d070 0x2a9fafd36ce0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.800364:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 935
[1:1:0712/043550.800636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7fc389b9d070 0x2a9faf96cc60 , 5:3_http://hao.pcgames.com.cn/, 0, , 903 0x7fc389b9d070 0x2a9fb045cae0 
[1:1:0712/043550.800987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043550.801678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043550.801939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043550.875795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043550.876090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043550.879698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 908, 7fc38c4e28db
[1:1:0712/043550.914748:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"694 0x7fc389b9d070 0x2a9fafd50be0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.915103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"694 0x7fc389b9d070 0x2a9fafd50be0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043550.915539:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 941
[1:1:0712/043550.915772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7fc389b9d070 0x2a9fb07f69e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 908 0x7fc389b9d070 0x2a9fafd1dae0 
[1:1:0712/043550.916089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043550.916729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043550.916943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043550.975953:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 911 0x7fc3a0227080 0x2a9fb05942e0 1 0 0x2a9fb05942f8 , "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043550.978113:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043550.984582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , , var STK=function(){var a={};var b=[];a.inc=function(a,b){return true};a.register=function(c,d){var e
[1:1:0712/043550.984894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
[1:1:0712/043551.087072:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x397982834eb8, 0x2a9faedcd548
[1:1:0712/043551.087343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", 25
[1:1:0712/043551.088314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 946
[1:1:0712/043551.088564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7fc389b9d070 0x2a9fafd34960 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 911 0x7fc3a0227080 0x2a9fb05942e0 1 0 0x2a9fb05942f8 
[1:1:0712/043551.268197:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0704999, 1050, 1
[1:1:0712/043551.268465:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043551.572803:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 917, 7fc38c4e2881
[1:1:0712/043551.614408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"877 0x7fc389b9d070 0x2a9faeffe760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043551.614800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"877 0x7fc389b9d070 0x2a9faeffe760 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043551.615169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043551.615871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043551.616095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043551.616888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043551.617108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043551.617521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 999
[1:1:0712/043551.617765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7fc389b9d070 0x2a9faf5ca960 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 917 0x7fc389b9d070 0x2a9fb0569960 
[1:1:0712/043552.378189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043552.378495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043553.589403:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043553.589675:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043553.646282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 946, 7fc38c4e2881
[1:1:0712/043553.669001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5815330","ptid":"911 0x7fc3a0227080 0x2a9fb05942e0 1 0 0x2a9fb05942f8 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043553.669373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"911 0x7fc3a0227080 0x2a9fb05942e0 1 0 0x2a9fb05942f8 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043553.669797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043553.670813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/043553.671087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
[1:1:0712/043553.672364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x397982834eb8, 0x2a9faedcd150
[1:1:0712/043553.672572:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", 25
[1:1:0712/043553.673403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1025
[1:1:0712/043553.673661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7fc389b9d070 0x2a9fb093f1e0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 946 0x7fc389b9d070 0x2a9fafd34960 
[1:1:0712/043554.813091:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 995, "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043554.818757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , , STK.register("kit.extra.language", function($) {
    window.$LANG || (window.$LANG = {});
    return
[1:1:0712/043554.819076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[75625:75625:0712/043556.279124:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/043556.607662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 25, 0x397982834eb8, 0x2a9faedcd298
[1:1:0712/043556.608016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", 25
[1:1:0712/043556.609068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1096
[1:1:0712/043556.609376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7fc389b9d070 0x2a9faff75ce0 , 5:4_https://widget.weibo.com/, 1, -5:4_https://widget.weibo.com/, 995
[1:1:0712/043556.615182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 995, "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043556.648759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043556.871453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 999, 7fc38c4e2881
[1:1:0712/043556.899706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"917 0x7fc389b9d070 0x2a9fb0569960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043556.900090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"917 0x7fc389b9d070 0x2a9fb0569960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043556.900506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043556.901121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043556.901340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043556.902122:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043556.902326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043556.902718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hao.pcgames.com.cn/, 1115
[1:1:0712/043556.902938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1115 0x7fc389b9d070 0x2a9faeff5be0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 999 0x7fc389b9d070 0x2a9faf5ca960 
[1:1:0712/043557.245203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043557.245496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043557.363319:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 901, 7fc38c4e28db
[1:1:0712/043557.389330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"682 0x7fc389b9d070 0x2a9fafd36ce0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043557.389654:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"682 0x7fc389b9d070 0x2a9fafd36ce0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043557.390126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1120
[1:1:0712/043557.390399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7fc389b9d070 0x2a9faefc1460 , 5:3_http://hao.pcgames.com.cn/, 0, , 901 0x7fc389b9d070 0x2a9faf5b6360 
[1:1:0712/043557.390803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043557.391493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043557.391741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043557.401365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043557.401851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1121
[1:1:0712/043557.402083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7fc389b9d070 0x2a9fb09d5060 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 901 0x7fc389b9d070 0x2a9faf5b6360 
[1:1:0712/043557.489160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 907, 7fc38c4e28db
[1:1:0712/043557.547019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"694 0x7fc389b9d070 0x2a9fafd50be0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043557.547443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"694 0x7fc389b9d070 0x2a9fafd50be0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043557.547871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1129
[1:1:0712/043557.548108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1129 0x7fc389b9d070 0x2a9fafae7960 , 5:3_http://hao.pcgames.com.cn/, 0, , 907 0x7fc389b9d070 0x2a9faeff5660 
[1:1:0712/043557.548495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043557.549118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043557.549405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043557.575903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043557.576475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1130
[1:1:0712/043557.576729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7fc389b9d070 0x2a9fb05455e0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 907 0x7fc389b9d070 0x2a9faeff5660 
[1:1:0712/043557.710772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1025, 7fc38c4e2881
[1:1:0712/043557.751498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5815330","ptid":"946 0x7fc389b9d070 0x2a9fafd34960 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043557.751842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"946 0x7fc389b9d070 0x2a9fafd34960 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043557.752276:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043557.753251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , j, (){if(g()){h();return}setTimeout(arguments.callee,25)}
[1:1:0712/043557.753510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
[1:1:0712/043600.186916:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043600.188191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , h, (){if(c==true){return}c=true;for(var a=0,e=b.length;a<e;a++){if(d(b[a])==="function"){try{b[a].call(
[1:1:0712/043600.188493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
[1:1:0712/043600.203935:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.204685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://widget.weibo.com/-5:3_http://hao.pcgames.com.cn/, 06a0f5702860, 06a0f5815330, a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/043600.204920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 2, , , 0
[1:1:0712/043600.205354:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/043600.205634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.208945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.209574:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.210951:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x3979827229c8, 0x2a9faedcd1f0
[1:1:0712/043600.211155:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 1000
[1:1:0712/043600.211561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1201
[1:1:0712/043600.211852:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1201 0x7fc389b9d070 0x2a9fb0acff60 , 5:4_https://widget.weibo.com/, 2, -5:4_https://widget.weibo.com/-5:3_http://hao.pcgames.com.cn/, 1089
[1:1:0712/043600.214589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.216046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd2f0
[1:1:0712/043600.216248:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043600.216637:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1202
[1:1:0712/043600.216880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1202 0x7fc389b9d070 0x2a9fb0aff8e0 , 5:4_https://widget.weibo.com/, 2, -5:4_https://widget.weibo.com/-5:3_http://hao.pcgames.com.cn/, 1089
[1:1:0712/043600.478309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1096, 7fc38c4e2881
[1:1:0712/043600.529396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5815330","ptid":"995","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043600.529749:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/","ptid":"995","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043600.530189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1"
[1:1:0712/043600.531234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://widget.weibo.com/, 06a0f5815330, , h, (){var a=+(new Date);do{f.process.call(f.context,e.shift())}while(e.length>0&&+(new Date)-a<f.execTi
[1:1:0712/043600.531510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://widget.weibo.com/weiboshow/index.php?language=&width=0&height=340&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=0&uid=1661969105&verifier=62074399&dpc=1", "widget.weibo.com", 4, 1, http://hao.pcgames.com.cn, hao.pcgames.com.cn, 3
[1:1:0712/043600.701259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , document.readyState
[1:1:0712/043600.701547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043600.936461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1121, 7fc38c4e28db
[1:1:0712/043600.973261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"901 0x7fc389b9d070 0x2a9faf5b6360 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043600.973625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"901 0x7fc389b9d070 0x2a9faf5b6360 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043600.974060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1216
[1:1:0712/043600.974303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1216 0x7fc389b9d070 0x2a9fb0accae0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1121 0x7fc389b9d070 0x2a9fb09d5060 
[1:1:0712/043600.974684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043600.975305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043600.975517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043601.025844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1120, 7fc38c4e28db
[1:1:0712/043601.052930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"901 0x7fc389b9d070 0x2a9faf5b6360 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.053281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"901 0x7fc389b9d070 0x2a9faf5b6360 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.053768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1217
[1:1:0712/043601.054028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1217 0x7fc389b9d070 0x2a9fb04d26e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1120 0x7fc389b9d070 0x2a9faefc1460 
[1:1:0712/043601.054374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043601.054993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043601.055221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043601.061967:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043601.062375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1218
[1:1:0712/043601.062609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1218 0x7fc389b9d070 0x2a9faf039e60 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 1120 0x7fc389b9d070 0x2a9faefc1460 
[1:1:0712/043601.153808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1130, 7fc38c4e28db
[1:1:0712/043601.191137:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"907 0x7fc389b9d070 0x2a9faeff5660 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.191843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"907 0x7fc389b9d070 0x2a9faeff5660 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.192525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1221
[1:1:0712/043601.192990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7fc389b9d070 0x2a9fafa7e7e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1130 0x7fc389b9d070 0x2a9fb05455e0 
[1:1:0712/043601.193538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043601.194795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043601.195317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043601.217594:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1129, 7fc38c4e28db
[1:1:0712/043601.255455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"907 0x7fc389b9d070 0x2a9faeff5660 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.255826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"907 0x7fc389b9d070 0x2a9faeff5660 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043601.256324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1226
[1:1:0712/043601.256744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1226 0x7fc389b9d070 0x2a9fb09711e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1129 0x7fc389b9d070 0x2a9fafae7960 
[1:1:0712/043601.257444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043601.258508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043601.258879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043601.272944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043601.273600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1227
[1:1:0712/043601.273955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7fc389b9d070 0x2a9faff735e0 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 1129 0x7fc389b9d070 0x2a9fafae7960 
[1:1:0712/043602.048349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1202, 7fc38c4e2881
[1:1:0712/043602.085358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f581533006a0f5702860","ptid":"1089","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043602.085772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/-5:3_http://hao.pcgames.com.cn/","ptid":"1089","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043602.086187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043602.086841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043602.087063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043602.087860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043602.088113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043602.088429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1245
[1:1:0712/043602.088669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1245 0x7fc389b9d070 0x2a9faef8ca60 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1202 0x7fc389b9d070 0x2a9fb0aff8e0 
[1:1:0712/043602.584962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1218, 7fc38c4e28db
[1:1:0712/043602.668496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1120 0x7fc389b9d070 0x2a9faefc1460 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043602.668947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1120 0x7fc389b9d070 0x2a9faefc1460 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043602.669430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1257
[1:1:0712/043602.669733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1257 0x7fc389b9d070 0x2a9faf47f9e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1218 0x7fc389b9d070 0x2a9faf039e60 
[1:1:0712/043602.670177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043602.670848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043602.671125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043602.892966:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1201, 7fc38c4e2881
[1:1:0712/043602.946067:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f581533006a0f5702860","ptid":"1089","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043602.946665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://widget.weibo.com/-5:3_http://hao.pcgames.com.cn/","ptid":"1089","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043602.947448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043602.948769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){p(),h()}
[1:1:0712/043602.949193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043602.977864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 1000
[1:1:0712/043602.978317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://widget.weibo.com/, 1266
[1:1:0712/043602.978599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1266 0x7fc389b9d070 0x2a9fb0ac7be0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1201 0x7fc389b9d070 0x2a9fb0acff60 
[1:1:0712/043602.983886:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1227, 7fc38c4e28db
[1:1:0712/043603.036033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1129 0x7fc389b9d070 0x2a9fafae7960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.036475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1129 0x7fc389b9d070 0x2a9fafae7960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.037015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1270
[1:1:0712/043603.037314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7fc389b9d070 0x2a9faf6b0be0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1227 0x7fc389b9d070 0x2a9faff735e0 
[1:1:0712/043603.037774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043603.038469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043603.038802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043603.348915:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1245, 7fc38c4e2881
[1:1:0712/043603.372519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1202 0x7fc389b9d070 0x2a9fb0aff8e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043603.372921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1202 0x7fc389b9d070 0x2a9fb0aff8e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043603.373366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043603.374011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043603.374233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043603.375034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043603.375239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043603.375706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1280
[1:1:0712/043603.375945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1280 0x7fc389b9d070 0x2a9fb024c1e0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1245 0x7fc389b9d070 0x2a9faef8ca60 
[1:1:0712/043603.619290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1217, 7fc38c4e28db
[1:1:0712/043603.641112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1120 0x7fc389b9d070 0x2a9faefc1460 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.641448:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1120 0x7fc389b9d070 0x2a9faefc1460 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.641834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1289
[1:1:0712/043603.642079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7fc389b9d070 0x2a9fb09d50e0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1217 0x7fc389b9d070 0x2a9fb04d26e0 
[1:1:0712/043603.642438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043603.643080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043603.643305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043603.649412:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043603.650004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1290
[1:1:0712/043603.650247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1290 0x7fc389b9d070 0x2a9fb09a7860 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 1217 0x7fc389b9d070 0x2a9fb04d26e0 
[1:1:0712/043603.827801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1226, 7fc38c4e28db
[1:1:0712/043603.865822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1129 0x7fc389b9d070 0x2a9fafae7960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.866190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1129 0x7fc389b9d070 0x2a9fafae7960 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043603.866632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1298
[1:1:0712/043603.866909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1298 0x7fc389b9d070 0x2a9fb0ac7f60 , 5:3_http://hao.pcgames.com.cn/, 0, , 1226 0x7fc389b9d070 0x2a9fb09711e0 
[1:1:0712/043603.867262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043603.867951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043603.868182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043603.875530:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 13
[1:1:0712/043603.875923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1299
[1:1:0712/043603.876169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7fc389b9d070 0x2a9fb07cb860 , 5:3_http://hao.pcgames.com.cn/, 1, -5:3_http://hao.pcgames.com.cn/, 1226 0x7fc389b9d070 0x2a9fb09711e0 
[1:1:0712/043604.355511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1280, 7fc38c4e2881
[1:1:0712/043604.373151:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1245 0x7fc389b9d070 0x2a9faef8ca60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.373510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1245 0x7fc389b9d070 0x2a9faef8ca60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.373918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.374604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043604.374835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.375583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043604.375805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043604.376296:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1312
[1:1:0712/043604.376533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7fc389b9d070 0x2a9fb09d61e0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1280 0x7fc389b9d070 0x2a9fb024c1e0 
[1:1:0712/043604.377961:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1290, 7fc38c4e28db
[1:1:0712/043604.394978:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1217 0x7fc389b9d070 0x2a9fb04d26e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043604.395290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1217 0x7fc389b9d070 0x2a9fb04d26e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043604.395691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1313
[1:1:0712/043604.395961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1313 0x7fc389b9d070 0x2a9fb0ae8ee0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1290 0x7fc389b9d070 0x2a9fb09a7860 
[1:1:0712/043604.396337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.396917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043604.397129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.555651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1299, 7fc38c4e28db
[1:1:0712/043604.573989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1226 0x7fc389b9d070 0x2a9fb09711e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043604.574342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1226 0x7fc389b9d070 0x2a9fb09711e0 ","rf":"5:3_http://hao.pcgames.com.cn/"}
[1:1:0712/043604.574759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hao.pcgames.com.cn/, 1316
[1:1:0712/043604.575000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7fc389b9d070 0x2a9fb0c59ee0 , 5:3_http://hao.pcgames.com.cn/, 0, , 1299 0x7fc389b9d070 0x2a9fb07cb860 
[1:1:0712/043604.575380:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.576017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043604.576247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.636657:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://widget.weibo.com/, 1266, 7fc38c4e28db
[1:1:0712/043604.654932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1201 0x7fc389b9d070 0x2a9fb0acff60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.655259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1201 0x7fc389b9d070 0x2a9fb0acff60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.655675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://widget.weibo.com/, 1317
[1:1:0712/043604.655979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1317 0x7fc389b9d070 0x2a9fb0acf860 , 5:4_https://widget.weibo.com/, 0, , 1266 0x7fc389b9d070 0x2a9fb0ac7be0 
[1:1:0712/043604.656354:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.657026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){document.hasFocus()&&u++}
[1:1:0712/043604.657258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.744134:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.744934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , r.onload.r.onerror, (){e[n]=null}
[1:1:0712/043604.745168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.746891:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1312, 7fc38c4e2881
[1:1:0712/043604.798111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1280 0x7fc389b9d070 0x2a9fb024c1e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.798463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1280 0x7fc389b9d070 0x2a9fb024c1e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.798848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.799472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043604.799729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.800491:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043604.800692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043604.801121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1319
[1:1:0712/043604.801350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1319 0x7fc389b9d070 0x2a9faf462ce0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1312 0x7fc389b9d070 0x2a9fb09d61e0 
[1:1:0712/043604.951496:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1319, 7fc38c4e2881
[1:1:0712/043604.993987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1312 0x7fc389b9d070 0x2a9fb09d61e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.994389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1312 0x7fc389b9d070 0x2a9fb09d61e0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043604.994787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043604.995544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043604.995831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043604.996610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043604.996810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043604.997252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1322
[1:1:0712/043604.997483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7fc389b9d070 0x2a9fb0ad3360 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1319 0x7fc389b9d070 0x2a9faf462ce0 
[1:1:0712/043605.066433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://widget.weibo.com/, 1317, 7fc38c4e28db
[1:1:0712/043605.092208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1266 0x7fc389b9d070 0x2a9fb0ac7be0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.092525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1266 0x7fc389b9d070 0x2a9fb0ac7be0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.092948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:4_https://widget.weibo.com/, 1326
[1:1:0712/043605.093199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7fc389b9d070 0x2a9fafc82260 , 5:4_https://widget.weibo.com/, 0, , 1317 0x7fc389b9d070 0x2a9fb0acf860 
[1:1:0712/043605.093549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043605.094190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , , (){document.hasFocus()&&u++}
[1:1:0712/043605.094415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043605.137956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1322, 7fc38c4e2881
[1:1:0712/043605.155456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1319 0x7fc389b9d070 0x2a9faf462ce0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.155790:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1319 0x7fc389b9d070 0x2a9faf462ce0 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.156197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043605.156815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043605.157061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043605.157807:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043605.158003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043605.158442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1328
[1:1:0712/043605.158670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7fc389b9d070 0x2a9faf436c60 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1322 0x7fc389b9d070 0x2a9fb0ad3360 
[1:1:0712/043605.277224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1328, 7fc38c4e2881
[1:1:0712/043605.328414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1322 0x7fc389b9d070 0x2a9fb0ad3360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.328773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1322 0x7fc389b9d070 0x2a9fb0ad3360 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.329181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043605.329790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043605.330005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043605.330760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043605.330955:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043605.331380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1330
[1:1:0712/043605.331608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1330 0x7fc389b9d070 0x2a9fb0c59a60 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1328 0x7fc389b9d070 0x2a9faf436c60 
[1:1:0712/043605.485212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1330, 7fc38c4e2881
[1:1:0712/043605.536659:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1328 0x7fc389b9d070 0x2a9faf436c60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.537037:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1328 0x7fc389b9d070 0x2a9faf436c60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.537479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043605.538138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043605.538361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043605.539105:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0712/043605.539321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0712/043605.539737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1333
[1:1:0712/043605.540009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7fc389b9d070 0x2a9fb0c69360 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1330 0x7fc389b9d070 0x2a9fb0c59a60 
[1:1:0712/043605.668594:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1333, 7fc38c4e2881
[1:1:0712/043605.720077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a0f5702860","ptid":"1330 0x7fc389b9d070 0x2a9fb0c59a60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.720476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hao.pcgames.com.cn/","ptid":"1330 0x7fc389b9d070 0x2a9fb0c59a60 ","rf":"5:4_https://widget.weibo.com/"}
[1:1:0712/043605.720867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hao.pcgames.com.cn/item-20573.html"
[1:1:0712/043605.721411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hao.pcgames.com.cn/, 06a0f5702860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043605.721637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hao.pcgames.com.cn/item-20573.html", "hao.pcgames.com.cn", 3, 1, , , 0
[1:1:0100/000000.722406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3979827229c8, 0x2a9faedcd150
[1:1:0100/000000.738577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hao.pcgames.com.cn/item-20573.html", 100
[1:1:0100/000000.746050:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://widget.weibo.com/, 1350
[1:1:0100/000000.746261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7fc389b9d070 0x2a9fb0b2cbe0 , 5:4_https://widget.weibo.com/, 1, -5:3_http://hao.pcgames.com.cn/, 1333 0x7fc389b9d070 0x2a9fb0c69360 
