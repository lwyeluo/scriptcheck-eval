[0712/043721.737442:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043721.737864:INFO:switcher_clone.cc(787)] backtrace rip is 7f0b2ab60891
[0712/043722.685915:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043722.686336:INFO:switcher_clone.cc(787)] backtrace rip is 7fa49420f891
[1:1:0712/043722.690740:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043722.690934:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043722.696222:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[75879:75879:0712/043723.781384:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/eb59c2f0-f709-4b3c-bba0-b20461473901
[0712/043724.080102:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043724.080590:INFO:switcher_clone.cc(787)] backtrace rip is 7f5d37524891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[75910:75910:0712/043724.306345:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75910
[75923:75923:0712/043724.306883:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75923
[75879:75879:0712/043724.395410:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[75879:75907:0712/043724.396240:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043724.396469:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043724.396702:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043724.397272:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043724.397429:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043724.400327:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x127ea3dc, 1
[1:1:0712/043724.400666:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x92db437, 0
[1:1:0712/043724.400871:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x36822299, 3
[1:1:0712/043724.401070:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2aa2bc2f, 2
[1:1:0712/043724.401309:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 37ffffffb42d09 ffffffdcffffffa37e12 2fffffffbcffffffa22a ffffff9922ffffff8236 , 10104, 4
[1:1:0712/043724.402471:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75879:75907:0712/043724.402742:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING7�-	ܣ~/��*�"�6�	9
[75879:75907:0712/043724.402809:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 7�-	ܣ~/��*�"�6�]�	9
[75879:75907:0712/043724.403098:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/043724.402938:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa49244a0a0, 3
[75879:75907:0712/043724.403168:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75931, 4, 37b42d09 dca37e12 2fbca22a 99228236 
[1:1:0712/043724.403188:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa4925d5080, 2
[1:1:0712/043724.403346:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa47c298d20, -2
[1:1:0712/043724.424375:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043724.425486:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2aa2bc2f
[1:1:0712/043724.426265:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2aa2bc2f
[1:1:0712/043724.427288:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2aa2bc2f
[1:1:0712/043724.427894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.428009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.428104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.428201:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.428419:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2aa2bc2f
[1:1:0712/043724.428554:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa49420f7ba
[1:1:0712/043724.428627:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa494206def, 7fa49420f77a, 7fa4942110cf
[1:1:0712/043724.430082:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2aa2bc2f
[1:1:0712/043724.430244:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2aa2bc2f
[1:1:0712/043724.430514:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2aa2bc2f
[1:1:0712/043724.431199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.431304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.431396:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.431484:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2aa2bc2f
[1:1:0712/043724.431947:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2aa2bc2f
[1:1:0712/043724.432105:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa49420f7ba
[1:1:0712/043724.432181:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa494206def, 7fa49420f77a, 7fa4942110cf
[1:1:0712/043724.434341:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043724.434609:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043724.434717:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffab05a838, 0x7fffab05a7b8)
[1:1:0712/043724.452241:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043724.459638:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[75879:75879:0712/043725.005148:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75879:75879:0712/043725.006336:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75879:75890:0712/043725.029359:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[75879:75890:0712/043725.029463:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[75879:75879:0712/043725.031138:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[75879:75879:0712/043725.031215:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[75879:75879:0712/043725.031352:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,75931, 4
[1:7:0712/043725.036607:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[75879:75901:0712/043725.089606:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/043725.119046:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x19857126f220
[1:1:0712/043725.120023:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043725.397167:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/043726.947743:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043726.949706:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[75879:75879:0712/043726.955468:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[75879:75879:0712/043726.955596:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043728.101889:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043728.195211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043728.195401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043728.200169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043728.200288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043728.253920:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043728.254058:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043728.469125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043728.471819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043728.471960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043728.489525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043728.500063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043728.500293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043728.512214:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[75879:75879:0712/043728.514282:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043728.516107:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x19857126de20
[1:1:0712/043728.516276:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[75879:75879:0712/043728.521184:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[75879:75879:0712/043728.542220:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[75879:75879:0712/043728.542426:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043728.611855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043729.219993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fa47de732e0 0x198571461860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043729.221303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043729.221501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043729.222982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75879:75879:0712/043729.300392:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043729.302699:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x19857126e820
[1:1:0712/043729.302901:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[75879:75879:0712/043729.313536:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043729.322432:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043729.322694:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[75879:75879:0712/043729.331120:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[75879:75879:0712/043729.338978:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75879:75879:0712/043729.339329:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75879:75879:0712/043729.341001:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[75879:75879:0712/043729.341039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[75879:75879:0712/043729.341095:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,75931, 4
[75879:75890:0712/043729.341490:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[75879:75890:0712/043729.341529:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043729.353039:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043730.012281:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043730.604040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fa47de732e0 0x1985714f92e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043730.605175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043730.605507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043730.606338:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75879:75879:0712/043730.735989:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[75879:75879:0712/043730.736111:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043730.766512:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043730.992018:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043731.487408:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043731.487701:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043731.632794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043731.637296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c3c17d8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043731.637597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043731.645387:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[75879:75879:0712/043731.689192:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[75879:75907:0712/043731.689604:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043731.689811:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043731.690084:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043731.690568:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043731.690776:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043731.694056:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x302b4ca9, 1
[1:1:0712/043731.694661:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x132592fa, 0
[1:1:0712/043731.694830:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5cee363, 3
[1:1:0712/043731.694983:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ce73d1c, 2
[1:1:0712/043731.695132:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffaffffff922513 ffffffa94c2b30 1c3dffffffe71c 63ffffffe3ffffffce05 , 10104, 5
[1:1:0712/043731.696125:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75879:75907:0712/043731.696388:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��%�L+0=�c���	9
[75879:75907:0712/043731.696465:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��%�L+0=�c���V�	9
[1:1:0712/043731.696375:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa49244a0a0, 3
[1:1:0712/043731.696599:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa4925d5080, 2
[75879:75907:0712/043731.696743:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75975, 5, fa922513 a94c2b30 1c3de71c 63e3ce05 
[1:1:0712/043731.696786:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa47c298d20, -2
[1:1:0712/043731.728052:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043731.728465:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ce73d1c
[1:1:0712/043731.728845:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ce73d1c
[1:1:0712/043731.729542:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ce73d1c
[1:1:0712/043731.731043:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.731270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.731494:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.731768:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.732546:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ce73d1c
[1:1:0712/043731.732880:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa49420f7ba
[1:1:0712/043731.733068:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa494206def, 7fa49420f77a, 7fa4942110cf
[1:1:0712/043731.739246:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ce73d1c
[1:1:0712/043731.739722:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ce73d1c
[1:1:0712/043731.740544:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ce73d1c
[1:1:0712/043731.742709:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.742964:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.743197:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.743435:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ce73d1c
[1:1:0712/043731.744805:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ce73d1c
[1:1:0712/043731.745219:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa49420f7ba
[1:1:0712/043731.745398:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa494206def, 7fa49420f77a, 7fa4942110cf
[1:1:0712/043731.753719:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043731.754261:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043731.754457:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffab05a838, 0x7fffab05a7b8)
[1:1:0712/043731.769143:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043731.773714:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043731.832894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043731.833658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c3c17c61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043731.833899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043731.934929:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x198571236220
[1:1:0712/043731.935225:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043732.235903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043732.237655:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043732.237943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c3c17d8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043732.238280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043732.388150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043732.389101:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043732.389415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c3c17d8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043732.389793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[75879:75879:0712/043732.521188:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75879:75879:0712/043732.524333:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75879:75879:0712/043732.547908:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.pcgames.com.cn/
[75879:75879:0712/043732.548070:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.pcgames.com.cn/, http://www.pcgames.com.cn/huodong/, 1
[75879:75879:0712/043732.548314:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.pcgames.com.cn/, HTTP/1.1 200 OK Server: Tengine Connection: keep-alive Date: Fri, 12 Jul 2019 11:38:00 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 11:48:00 GMT Last-Modified: Fri, 12 Jul 2019 11:30:00 GMT Content-Type: text/html Transfer-Encoding: chunked Content-Encoding: gzip X-NWS-UUID-VERIFY: 8a191a68fcde013ff2b1f432b76a26dc Vary: Accept-Encoding X-Daa-Tunnel: hop_count=4 X-NWS-LOG-UUID: 16813647943307107786 4ca2f372b9fd9391db2869d3bcd7d964 X-Cache-Lookup: Hit From Upstream X-Cache-Lookup: Hit From Inner Cluster X-Via: PENGBOSHI-SHANXI_142(200:miss);PENGBOSHI-SHANXI_143(200:miss) X-Cache-Lookup: Hit From Upstream X-Cache-Lookup: Hit From Inner Cluster   ,75975, 5
[75879:75890:0712/043732.555675:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[75879:75890:0712/043732.555793:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043732.559310:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043732.598257:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.pcgames.com.cn/
[1:1:0712/043732.710431:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[75879:75879:0712/043732.726716:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.pcgames.com.cn/, http://www.pcgames.com.cn/, 1
[75879:75879:0712/043732.726798:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.pcgames.com.cn/, http://www.pcgames.com.cn
[1:1:0712/043732.737080:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043732.799374:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043732.876011:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043732.876272:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043733.268649:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/043733.328424:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/043733.384628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7fa47bf4b070 0x1985713c8ce0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043733.652592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||
[1:1:0712/043733.653239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043733.689461:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043733.719144:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/043733.720515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7fa47bf4b070 0x1985713c8ce0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043733.722502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7fa47bf4b070 0x1985713c8ce0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043733.732959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7fa47bf4b070 0x1985713c8ce0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043733.734318:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 999, 0x2c0847d829c8, 0x1985710999a0
[1:1:0712/043733.734544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 999
[1:1:0712/043733.734996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 218
[1:1:0712/043733.735259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 218 0x7fa47bf4b070 0x198571348c60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 187 0x7fa47bf4b070 0x1985713c8ce0 
[1:1:0712/043733.799429:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.082809, 136, 1
[1:1:0712/043733.799725:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043733.822990:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/043733.900671:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/043734.003579:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/043734.084733:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/043734.185358:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/043734.230746:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043734.231013:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.232398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7fa47bf4b070 0x19857146bbe0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.233272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , 
/*登录url*/
window.ajaxLoginUrl = "http://www1.pcgames.com.cn/common/js/pcgames.login.1.0-min.js"
[1:1:0712/043734.233493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043734.235905:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7fa47bf4b070 0x19857146bbe0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.372810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 236 0x7fa47de732e0 0x19857146cb60 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.373716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , 
[1:1:0712/043734.373947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043734.425621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 249, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.428398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (function(){function p(){this.c="1261263986";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/043734.428635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043734.766355:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 268, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043734.769494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043734.769742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043735.084850:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0769739, 466, 1
[1:1:0712/043735.085122:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043735.143311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fa47de732e0 0x198570ffcc60 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043735.145405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (function(){var h={},mt={},c={id:"5284a74a6d44c732746f8d7e14a4d920",dm:["pcgames.com.cn"],js:"tongji
[1:1:0712/043735.145628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043735.173579:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099990
[1:1:0712/043735.173825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043735.174211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 314
[1:1:0712/043735.174476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 314 0x7fa47bf4b070 0x1985715135e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 272 0x7fa47de732e0 0x198570ffcc60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043735.354787:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043735.355272:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043735.355692:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043735.356123:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043735.356502:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[75879:75879:0712/043748.743272:INFO:CONSOLE(229)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.pcgames.com.cn/huodong/ (229)
[75879:75879:0712/043748.748137:INFO:CONSOLE(229)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://www.pcgames.com.cn/huodong/ (229)
[75879:75879:0712/043748.754587:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[75879:75879:0712/043748.759134:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[75879:75879:0712/043748.773779:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043748.822162:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043749.703390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 218, 7fa47e890881
[1:1:0712/043749.718970:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"187 0x7fa47bf4b070 0x1985713c8ce0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043749.719284:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"187 0x7fa47bf4b070 0x1985713c8ce0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043749.719572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043749.720194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){var js=document.createElement("script"); js.src="http://tga.pcgames.com.cn/adpuba/show?id=pcgames
[1:1:0712/043749.720409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043750.051531:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043750.051789:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043750.052738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7fa47bf4b070 0x198571644460 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043750.053885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , 
function showXYCS(json) {
var data = json.data;
var html = "";
for (var i = 0,len = data.length > 1
[1:1:0712/043750.054126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043750.056709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7fa47bf4b070 0x198571644460 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043750.095655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7fa47bf4b070 0x198571644460 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043750.189727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043750.191676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043750.191922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043750.289419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043750.289718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043751.334903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 314, 7fa47e890881
[1:1:0712/043751.352916:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"272 0x7fa47de732e0 0x198570ffcc60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043751.353263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"272 0x7fa47de732e0 0x198570ffcc60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043751.353616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.354233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043751.354507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043751.355349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043751.355568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043751.355965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 423
[1:1:0712/043751.356193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 423 0x7fa47bf4b070 0x19857156f960 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 314 0x7fa47bf4b070 0x1985715135e0 
[1:1:0712/043751.618577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.619792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , ivymap=window.ivymap||{};
ivymap["pcgames.yz.sy.tl1-1."] = function(){document_write(unescape('%3C%7
[1:1:0712/043751.620034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043751.622707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.625531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.631765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.638397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.646638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.663454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.670968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.676014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.681266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.686266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399, "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043751.726471:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.104633, 310, 1
[1:1:0712/043751.726760:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043751.754809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043751.755105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043753.167792:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7fa47de732e0 0x1985715b7ce0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.168675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , 
[1:1:0712/043753.168909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043753.192247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 423, 7fa47e890881
[1:1:0712/043753.213270:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"314 0x7fa47bf4b070 0x1985715135e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043753.213608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"314 0x7fa47bf4b070 0x1985715135e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043753.213921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.214485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043753.214691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043753.215400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043753.215615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043753.216012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 498
[1:1:0712/043753.216245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7fa47bf4b070 0x198571980d60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 423 0x7fa47bf4b070 0x19857156f960 
[1:1:0712/043753.652896:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043753.653205:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.656775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.667899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (function(c,f){if(c.PCgroup){return}var b,d=Object.prototype.toString,e=Array.prototype.slice,a=c.do
[1:1:0712/043753.668196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043753.746375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.794324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 2000
[1:1:0712/043753.795293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 518
[1:1:0712/043753.795517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7fa47bf4b070 0x198571a745e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 457 0x7fa47bf4b070 0x19857146b8e0 
[1:1:0712/043753.803155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.816867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.819914:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.842339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.865151:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.868220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.874497:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.879343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 457 0x7fa47bf4b070 0x19857146b8e0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043753.895746:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.241426, 76, 1
[1:1:0712/043753.895987:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043753.972685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043753.972978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043755.364698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043755.365463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/043755.365684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043755.398984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 498, 7fa47e890881
[1:1:0712/043755.422921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"423 0x7fa47bf4b070 0x19857156f960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043755.423264:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"423 0x7fa47bf4b070 0x19857156f960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043755.423615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043755.424217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043755.424447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043755.425170:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043755.425365:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043755.425752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 557
[1:1:0712/043755.425976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7fa47bf4b070 0x1985721a59e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 498 0x7fa47bf4b070 0x198571980d60 
[1:1:0712/043756.498262:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043756.498516:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.499467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542 0x7fa47bf4b070 0x198571980fe0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.500747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , 
window.ajaxLogin = function(){
var url = "http://www1.pcgames.com.cn/common/js/pcgames.login.1.0-mi
[1:1:0712/043756.500992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043756.516339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542 0x7fa47bf4b070 0x198571980fe0 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.524435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.525879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.647900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043756.648205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043756.886456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 557, 7fa47e890881
[1:1:0712/043756.912121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"498 0x7fa47bf4b070 0x198571980d60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043756.912474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"498 0x7fa47bf4b070 0x198571980d60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043756.912793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043756.913386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043756.913616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043756.914364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043756.914562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043756.915056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 588
[1:1:0712/043756.915286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7fa47bf4b070 0x198571383f60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 557 0x7fa47bf4b070 0x1985721a59e0 
[1:1:0712/043757.073968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 518, 7fa47e8908db
[1:1:0712/043757.099466:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"457 0x7fa47bf4b070 0x19857146b8e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.099832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"457 0x7fa47bf4b070 0x19857146b8e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.100179:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 591
[1:1:0712/043757.100406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7fa47bf4b070 0x1985719e7be0 , 5:3_http://www.pcgames.com.cn/, 0, , 518 0x7fa47bf4b070 0x198571a745e0 
[1:1:0712/043757.100714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043757.101310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){self.next();}
[1:1:0712/043757.101518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.122866:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043757.123330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 592
[1:1:0712/043757.123572:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 592 0x7fa47bf4b070 0x19857146cde0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 518 0x7fa47bf4b070 0x198571a745e0 
[1:1:0712/043757.137322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043757.137807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 593
[1:1:0712/043757.138185:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 593 0x7fa47bf4b070 0x1985719dc160 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 518 0x7fa47bf4b070 0x198571a745e0 
[1:1:0712/043757.180047:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043757.180507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 594
[1:1:0712/043757.180737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7fa47bf4b070 0x1985719e0ee0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 518 0x7fa47bf4b070 0x198571a745e0 
[1:1:0712/043757.614700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043757.615001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.645363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 588, 7fa47e890881
[1:1:0712/043757.671866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"557 0x7fa47bf4b070 0x1985721a59e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.672279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"557 0x7fa47bf4b070 0x1985721a59e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.672584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043757.673198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043757.673429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.674197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043757.674394:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043757.674784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 616
[1:1:0712/043757.675032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7fa47bf4b070 0x1985721a3860 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 588 0x7fa47bf4b070 0x198571383f60 
[1:1:0712/043757.703018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 592, 7fa47e8908db
[1:1:0712/043757.712176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.712500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.712837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 617
[1:1:0712/043757.713083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7fa47bf4b070 0x1985719d86e0 , 5:3_http://www.pcgames.com.cn/, 0, , 592 0x7fa47bf4b070 0x19857146cde0 
[1:1:0712/043757.713427:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043757.714005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043757.714253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.757134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 594, 7fa47e8908db
[1:1:0712/043757.788649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.789051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043757.789424:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 619
[1:1:0712/043757.789670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7fa47bf4b070 0x19857178f260 , 5:3_http://www.pcgames.com.cn/, 0, , 594 0x7fa47bf4b070 0x1985719e0ee0 
[1:1:0712/043757.789975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043757.790594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043757.790814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.910369:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7fa47de732e0 0x1985721a3e60 , "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043757.911694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , /*!svn:http://zzsvn.pcauto.com.cn/svn/data/pcgames/commom/js/pcgames.login.1.0.js*/
(function(h,k){f
[1:1:0712/043757.912076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043757.997168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043757.997447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.125286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 616, 7fa47e890881
[1:1:0712/043758.156124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"588 0x7fa47bf4b070 0x198571383f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.156485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"588 0x7fa47bf4b070 0x198571383f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.156905:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.157548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043758.157795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.158541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043758.158761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043758.159182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 635
[1:1:0712/043758.159425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7fa47bf4b070 0x1985719e7460 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 616 0x7fa47bf4b070 0x1985721a3860 
[1:1:0712/043758.160896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 591, 7fa47e8908db
[1:1:0712/043758.177946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.178257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"518 0x7fa47bf4b070 0x198571a745e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.178622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 636
[1:1:0712/043758.178863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7fa47bf4b070 0x198571551de0 , 5:3_http://www.pcgames.com.cn/, 0, , 591 0x7fa47bf4b070 0x1985719e7be0 
[1:1:0712/043758.179170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.179712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){self.next();}
[1:1:0712/043758.179979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.191711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043758.192194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 638
[1:1:0712/043758.192425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7fa47bf4b070 0x198571a51660 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 591 0x7fa47bf4b070 0x1985719e7be0 
[1:1:0712/043758.202796:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043758.203254:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 639
[1:1:0712/043758.203489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7fa47bf4b070 0x1985721a0460 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 591 0x7fa47bf4b070 0x1985719e7be0 
[1:1:0712/043758.209753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043758.210167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 640
[1:1:0712/043758.210392:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7fa47bf4b070 0x1985715800e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 591 0x7fa47bf4b070 0x1985719e7be0 
[1:1:0712/043758.296747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.297506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/043758.297738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.300585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.302037:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099af0
[1:1:0712/043758.302267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043758.302666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 647
[1:1:0712/043758.302906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7fa47bf4b070 0x198571281f60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 625 0x7fa47bf4b070 0x198571553b60 
[1:1:0712/043758.372086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , document.readyState
[1:1:0712/043758.372429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.646026:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 638, 7fa47e8908db
[1:1:0712/043758.675909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.676305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.676699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 662
[1:1:0712/043758.676929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7fa47bf4b070 0x1985721af860 , 5:3_http://www.pcgames.com.cn/, 0, , 638 0x7fa47bf4b070 0x198571a51660 
[1:1:0712/043758.677272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.677847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043758.678061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.715993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 640, 7fa47e8908db
[1:1:0712/043758.726647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.727054:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.727558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 665
[1:1:0712/043758.727849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7fa47bf4b070 0x1985719a5b60 , 5:3_http://www.pcgames.com.cn/, 0, , 640 0x7fa47bf4b070 0x1985715800e0 
[1:1:0712/043758.728204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.728831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043758.729072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.858900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 647, 7fa47e890881
[1:1:0712/043758.875381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"625 0x7fa47bf4b070 0x198571553b60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.875780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"625 0x7fa47bf4b070 0x198571553b60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043758.876133:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043758.876815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043758.877035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043758.877780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043758.877978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043758.878403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 667
[1:1:0712/043758.878633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7fa47bf4b070 0x198571580d60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 647 0x7fa47bf4b070 0x198571281f60 
[1:1:0712/043759.015892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 662, 7fa47e8908db
[1:1:0712/043759.043504:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"638 0x7fa47bf4b070 0x198571a51660 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.043958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"638 0x7fa47bf4b070 0x198571a51660 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.044378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 676
[1:1:0712/043759.044664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fa47bf4b070 0x1985719db8e0 , 5:3_http://www.pcgames.com.cn/, 0, , 662 0x7fa47bf4b070 0x1985721af860 
[1:1:0712/043759.045006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.045633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043759.045881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.096453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 667, 7fa47e890881
[1:1:0712/043759.115808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"647 0x7fa47bf4b070 0x198571281f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.116373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"647 0x7fa47bf4b070 0x198571281f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.116709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.117272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043759.117473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.118182:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043759.118368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043759.118731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 680
[1:1:0712/043759.118927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7fa47bf4b070 0x1985719cb960 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 667 0x7fa47bf4b070 0x198571580d60 
[1:1:0712/043759.425147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 680, 7fa47e890881
[1:1:0712/043759.434280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"667 0x7fa47bf4b070 0x198571580d60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.434487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"667 0x7fa47bf4b070 0x198571580d60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.434645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.434954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043759.435058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.435356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043759.435521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043759.435724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 694
[1:1:0712/043759.435837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7fa47bf4b070 0x198571980be0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 680 0x7fa47bf4b070 0x1985719cb960 
[1:1:0712/043759.675936:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 694, 7fa47e890881
[1:1:0712/043759.688787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"680 0x7fa47bf4b070 0x1985719cb960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.689244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"680 0x7fa47bf4b070 0x1985719cb960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.689633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.690371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043759.690634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.691563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043759.691776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043759.692260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 702
[1:1:0712/043759.692541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7fa47bf4b070 0x1985712c67e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 694 0x7fa47bf4b070 0x198571980be0 
[1:1:0712/043759.839041:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 702, 7fa47e890881
[1:1:0712/043759.848390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"694 0x7fa47bf4b070 0x198571980be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.848588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"694 0x7fa47bf4b070 0x198571980be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.848749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.849056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043759.849175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.850211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043759.850317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043759.850527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 711
[1:1:0712/043759.850646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7fa47bf4b070 0x1985721a0a60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 702 0x7fa47bf4b070 0x1985712c67e0 
[1:1:0712/043759.873499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 636, 7fa47e8908db
[1:1:0712/043759.908975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.909301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"591 0x7fa47bf4b070 0x1985719e7be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043759.909641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 712
[1:1:0712/043759.909846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 712 0x7fa47bf4b070 0x19857222dfe0 , 5:3_http://www.pcgames.com.cn/, 0, , 636 0x7fa47bf4b070 0x198571551de0 
[1:1:0712/043759.910100:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043759.910642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){self.next();}
[1:1:0712/043759.910828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043759.928917:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043759.929426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 714
[1:1:0712/043759.929696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7fa47bf4b070 0x1985721a6960 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 636 0x7fa47bf4b070 0x198571551de0 
[1:1:0712/043759.942499:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043759.943002:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 715
[1:1:0712/043759.943248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7fa47bf4b070 0x1985719a5060 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 636 0x7fa47bf4b070 0x198571551de0 
[1:1:0712/043759.959215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043759.959444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 716
[1:1:0712/043759.959657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 716 0x7fa47bf4b070 0x198571242de0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 636 0x7fa47bf4b070 0x198571551de0 
[1:1:0712/043800.153599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 714, 7fa47e8908db
[1:1:0712/043800.185460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.185800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.186131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 726
[1:1:0712/043800.186328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7fa47bf4b070 0x198571aa6760 , 5:3_http://www.pcgames.com.cn/, 0, , 714 0x7fa47bf4b070 0x1985721a6960 
[1:1:0712/043800.186664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.187371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043800.187629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.247317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 711, 7fa47e890881
[1:1:0712/043800.279079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"702 0x7fa47bf4b070 0x1985712c67e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.279387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"702 0x7fa47bf4b070 0x1985712c67e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.279714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.280458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043800.280736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.281621:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043800.281830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043800.282272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 730
[1:1:0712/043800.282518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7fa47bf4b070 0x19857124b8e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 711 0x7fa47bf4b070 0x1985721a0a60 
[1:1:0712/043800.310720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 716, 7fa47e8908db
[1:1:0712/043800.325547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.325906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.326277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 731
[1:1:0712/043800.326474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7fa47bf4b070 0x19857222db60 , 5:3_http://www.pcgames.com.cn/, 0, , 716 0x7fa47bf4b070 0x198571242de0 
[1:1:0712/043800.326776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.327324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043800.327499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.436711:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 726, 7fa47e8908db
[1:1:0712/043800.468742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"714 0x7fa47bf4b070 0x1985721a6960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.469125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"714 0x7fa47bf4b070 0x1985721a6960 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.469446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 736
[1:1:0712/043800.469642:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7fa47bf4b070 0x198571960c60 , 5:3_http://www.pcgames.com.cn/, 0, , 726 0x7fa47bf4b070 0x198571aa6760 
[1:1:0712/043800.469933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.470446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043800.470614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.556542:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 730, 7fa47e890881
[1:1:0712/043800.585612:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"711 0x7fa47bf4b070 0x1985721a0a60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.585889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"711 0x7fa47bf4b070 0x1985721a0a60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.586174:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.586647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043800.586841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.587327:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043800.587471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043800.587765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 744
[1:1:0712/043800.587884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 744 0x7fa47bf4b070 0x198571247be0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 730 0x7fa47bf4b070 0x19857124b8e0 
[1:1:0712/043800.708753:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 744, 7fa47e890881
[1:1:0712/043800.717608:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"730 0x7fa47bf4b070 0x19857124b8e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.717808:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"730 0x7fa47bf4b070 0x19857124b8e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.717962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.718280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043800.718387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.718694:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043800.718823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043800.718992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 749
[1:1:0712/043800.719097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7fa47bf4b070 0x19857156eb60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 744 0x7fa47bf4b070 0x198571247be0 
[1:1:0712/043800.859276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 749, 7fa47e890881
[1:1:0712/043800.888204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"744 0x7fa47bf4b070 0x198571247be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.888415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"744 0x7fa47bf4b070 0x198571247be0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043800.888577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043800.888919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043800.889031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043800.889340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043800.889438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043800.889617:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 752
[1:1:0712/043800.889724:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7fa47bf4b070 0x19857232fae0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 749 0x7fa47bf4b070 0x19857156eb60 
[1:1:0712/043801.021143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 752, 7fa47e890881
[1:1:0712/043801.051509:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"749 0x7fa47bf4b070 0x19857156eb60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.051849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"749 0x7fa47bf4b070 0x19857156eb60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.052114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.052672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.052864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.053537:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.053694:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.054077:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 756
[1:1:0712/043801.054270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7fa47bf4b070 0x198571513c60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 752 0x7fa47bf4b070 0x19857232fae0 
[1:1:0712/043801.209893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 756, 7fa47e890881
[1:1:0712/043801.240480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"752 0x7fa47bf4b070 0x19857232fae0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.240791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"752 0x7fa47bf4b070 0x19857232fae0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.241071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.241614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.241788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.242485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.242643:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.243018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 758
[1:1:0712/043801.243209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 758 0x7fa47bf4b070 0x198571357160 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 756 0x7fa47bf4b070 0x198571513c60 
[1:1:0712/043801.369919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 758, 7fa47e890881
[1:1:0712/043801.403760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"756 0x7fa47bf4b070 0x198571513c60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.404094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"756 0x7fa47bf4b070 0x198571513c60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.404360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.404950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.405130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.405802:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.405972:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.406442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 760
[1:1:0712/043801.406631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7fa47bf4b070 0x198570f82a60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 758 0x7fa47bf4b070 0x198571357160 
[1:1:0712/043801.550854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 760, 7fa47e890881
[1:1:0712/043801.582311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"758 0x7fa47bf4b070 0x198571357160 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.582667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"758 0x7fa47bf4b070 0x198571357160 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.583004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.583592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.583774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.584468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.584628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.585000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 762
[1:1:0712/043801.585194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 762 0x7fa47bf4b070 0x198571249260 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 760 0x7fa47bf4b070 0x198570f82a60 
[1:1:0712/043801.717756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 762, 7fa47e890881
[1:1:0712/043801.734851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"760 0x7fa47bf4b070 0x198570f82a60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.735060:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"760 0x7fa47bf4b070 0x198570f82a60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.735219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.735531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.735633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.735927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.736087:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.736263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 766
[1:1:0712/043801.736369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7fa47bf4b070 0x198571615060 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 762 0x7fa47bf4b070 0x198571249260 
[1:1:0712/043801.838903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 712, 7fa47e8908db
[1:1:0712/043801.860853:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.861244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"636 0x7fa47bf4b070 0x198571551de0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.861629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 770
[1:1:0712/043801.861885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7fa47bf4b070 0x1985715c8de0 , 5:3_http://www.pcgames.com.cn/, 0, , 712 0x7fa47bf4b070 0x19857222dfe0 
[1:1:0712/043801.862260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.862866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){self.next();}
[1:1:0712/043801.863190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.888697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043801.889112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 772
[1:1:0712/043801.889319:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7fa47bf4b070 0x1985715459e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 712 0x7fa47bf4b070 0x19857222dfe0 
[1:1:0712/043801.899291:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043801.899639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 773
[1:1:0712/043801.899825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 773 0x7fa47bf4b070 0x198571aa6760 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 712 0x7fa47bf4b070 0x19857222dfe0 
[1:1:0712/043801.914450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 13
[1:1:0712/043801.914820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 774
[1:1:0712/043801.915007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7fa47bf4b070 0x19857225bf60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 712 0x7fa47bf4b070 0x19857222dfe0 
[1:1:0712/043801.918069:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 766, 7fa47e890881
[1:1:0712/043801.952211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"762 0x7fa47bf4b070 0x198571249260 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.952521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"762 0x7fa47bf4b070 0x198571249260 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043801.952837:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043801.953463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043801.953651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043801.954372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043801.954540:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043801.954899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 777
[1:1:0712/043801.955117:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 777 0x7fa47bf4b070 0x1985713477e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 766 0x7fa47bf4b070 0x198571615060 
[1:1:0712/043802.277251:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 772, 7fa47e8908db
[1:1:0712/043802.310239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"712 0x7fa47bf4b070 0x19857222dfe0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.310551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"712 0x7fa47bf4b070 0x19857222dfe0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.310863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 783
[1:1:0712/043802.311059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7fa47bf4b070 0x19857232f660 , 5:3_http://www.pcgames.com.cn/, 0, , 772 0x7fa47bf4b070 0x1985715459e0 
[1:1:0712/043802.311376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.311923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043802.312156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.316441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 774, 7fa47e8908db
[1:1:0712/043802.348795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"712 0x7fa47bf4b070 0x19857222dfe0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.349059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"712 0x7fa47bf4b070 0x19857222dfe0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.349401:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 785
[1:1:0712/043802.349593:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7fa47bf4b070 0x198571a519e0 , 5:3_http://www.pcgames.com.cn/, 0, , 774 0x7fa47bf4b070 0x19857225bf60 
[1:1:0712/043802.349825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.350384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043802.350600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.390626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 777, 7fa47e890881
[1:1:0712/043802.422542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"766 0x7fa47bf4b070 0x198571615060 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.422857:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"766 0x7fa47bf4b070 0x198571615060 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.423187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.423777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043802.423954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.424902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043802.425156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043802.425656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 787
[1:1:0712/043802.425923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 787 0x7fa47bf4b070 0x198571a51f60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 777 0x7fa47bf4b070 0x1985713477e0 
[1:1:0712/043802.683976:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 783, 7fa47e8908db
[1:1:0712/043802.717753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"772 0x7fa47bf4b070 0x1985715459e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.718018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"772 0x7fa47bf4b070 0x1985715459e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.718394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.pcgames.com.cn/, 791
[1:1:0712/043802.718595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7fa47bf4b070 0x198571552ce0 , 5:3_http://www.pcgames.com.cn/, 0, , 783 0x7fa47bf4b070 0x19857232f660 
[1:1:0712/043802.718876:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.719471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/043802.719691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.732079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 787, 7fa47e890881
[1:1:0712/043802.743510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"777 0x7fa47bf4b070 0x1985713477e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.743665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"777 0x7fa47bf4b070 0x1985713477e0 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.743868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.744159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043802.744314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.744627:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043802.744734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043802.744904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 793
[1:1:0712/043802.745011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 793 0x7fa47bf4b070 0x1985719dd160 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 787 0x7fa47bf4b070 0x198571a51f60 
[1:1:0712/043802.955183:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 793, 7fa47e890881
[1:1:0712/043802.986992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"787 0x7fa47bf4b070 0x198571a51f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.987270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"787 0x7fa47bf4b070 0x198571a51f60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043802.987548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043802.988091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043802.988265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043802.988998:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043802.989154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043802.989522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 801
[1:1:0712/043802.989713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 801 0x7fa47bf4b070 0x1985714e5b60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 793 0x7fa47bf4b070 0x1985719dd160 
[1:1:0712/043803.129794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 801, 7fa47e890881
[1:1:0712/043803.163703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"793 0x7fa47bf4b070 0x1985719dd160 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043803.163995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"793 0x7fa47bf4b070 0x1985719dd160 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043803.164257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043803.164915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043803.165103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043803.165851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043803.166031:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043803.166414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 803
[1:1:0712/043803.166615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7fa47bf4b070 0x1985712c69e0 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 801 0x7fa47bf4b070 0x1985714e5b60 
[1:1:0712/043803.306751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 803, 7fa47e890881
[1:1:0712/043803.338611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3f2b8f2a2860","ptid":"801 0x7fa47bf4b070 0x1985714e5b60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043803.338906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.pcgames.com.cn/","ptid":"801 0x7fa47bf4b070 0x1985714e5b60 ","rf":"5:3_http://www.pcgames.com.cn/"}
[1:1:0712/043803.339154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.pcgames.com.cn/huodong/"
[1:1:0712/043803.339703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.pcgames.com.cn/, 3f2b8f2a2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043803.339882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.pcgames.com.cn/huodong/", "www.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043803.340602:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2c0847d829c8, 0x198571099950
[1:1:0712/043803.340763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.pcgames.com.cn/huodong/", 100
[1:1:0712/043803.341110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.pcgames.com.cn/, 805
[1:1:0712/043803.341296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7fa47bf4b070 0x198570e4bc60 , 5:3_http://www.pcgames.com.cn/, 1, -5:3_http://www.pcgames.com.cn/, 803 0x7fa47bf4b070 0x1985712c69e0 
