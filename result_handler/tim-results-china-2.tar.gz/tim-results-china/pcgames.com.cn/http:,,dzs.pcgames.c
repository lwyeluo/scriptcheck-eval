[0712/042530.292873:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042530.293325:INFO:switcher_clone.cc(787)] backtrace rip is 7fc04d788891
[0712/042531.181062:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042531.181475:INFO:switcher_clone.cc(787)] backtrace rip is 7f4a91981891
[1:1:0712/042531.193317:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/042531.193634:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/042531.199226:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[74339:74339:0712/042532.411197:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f7cfb547-77bf-4f7a-a20f-763c03781e0c
[0712/042532.618784:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042532.619201:INFO:switcher_clone.cc(787)] backtrace rip is 7f3ad9893891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[74371:74371:0712/042532.835336:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=74371
[74384:74384:0712/042532.835810:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=74384
[74339:74339:0712/042532.841874:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[74339:74369:0712/042532.842813:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/042532.843089:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042532.843330:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042532.844007:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042532.844163:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/042532.847127:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfb172c, 1
[1:1:0712/042532.847443:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e332df6, 0
[1:1:0712/042532.847606:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26806684, 3
[1:1:0712/042532.847802:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e62aa20, 2
[1:1:0712/042532.847995:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff62d331e 2c17fffffffb00 20ffffffaa622e ffffff8466ffffff8026 , 10104, 4
[1:1:0712/042532.848919:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[74339:74369:0712/042532.849139:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�-3,�
[1:1:0712/042532.849130:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8fbbc0a0, 3
[74339:74369:0712/042532.849232:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �-3,�
[1:1:0712/042532.849317:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8fd47080, 2
[74339:74369:0712/042532.849557:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/042532.849472:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a79a0ad20, -2
[74339:74369:0712/042532.849628:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 74386, 4, f62d331e 2c17fb00 20aa622e 84668026 
[1:1:0712/042532.872196:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042532.873030:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e62aa20
[1:1:0712/042532.873726:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e62aa20
[1:1:0712/042532.874748:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e62aa20
[1:1:0712/042532.875273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.875374:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.875531:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.875632:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.875962:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e62aa20
[1:1:0712/042532.876113:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4a919817ba
[1:1:0712/042532.876195:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4a91978def, 7f4a9198177a, 7f4a919830cf
[1:1:0712/042532.878349:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e62aa20
[1:1:0712/042532.878520:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e62aa20
[1:1:0712/042532.878902:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e62aa20
[1:1:0712/042532.879577:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.879683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.879798:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.879901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e62aa20
[1:1:0712/042532.880430:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e62aa20
[1:1:0712/042532.880581:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4a919817ba
[1:1:0712/042532.880651:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4a91978def, 7f4a9198177a, 7f4a919830cf
[1:1:0712/042532.883276:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042532.883556:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042532.883661:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff1478d238, 0x7fff1478d1b8)
[1:1:0712/042532.895743:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042532.899997:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[74339:74364:0712/042533.502558:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/042533.535122:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1bd85e1da220
[1:1:0712/042533.535414:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[74339:74339:0712/042533.539814:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74339:74339:0712/042533.541282:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74339:74351:0712/042533.561485:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[74339:74339:0712/042533.561523:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[74339:74351:0712/042533.561591:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[74339:74339:0712/042533.561615:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[74339:74339:0712/042533.561758:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,74386, 4
[1:7:0712/042533.564584:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042534.019543:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[74339:74339:0712/042535.938466:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[74339:74339:0712/042535.938618:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042535.962038:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042535.966021:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042537.344011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042537.344343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042537.361028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042537.361341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042537.378144:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042537.489240:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042537.489528:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042537.830053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042537.836594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042537.837165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042537.874526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042537.887049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042537.887372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042537.899876:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[74339:74339:0712/042537.901620:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042537.903564:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1bd85e1d8e20
[1:1:0712/042537.903856:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[74339:74339:0712/042537.914221:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[74339:74339:0712/042537.946319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[74339:74339:0712/042537.946548:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042537.991758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042538.831049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f4a7b5e52e0 0x1bd85e25d0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042538.832513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/042538.832719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042538.834194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[74339:74339:0712/042538.894829:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042538.897014:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1bd85e1d9820
[1:1:0712/042538.897223:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[74339:74339:0712/042538.901710:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/042538.917689:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042538.917904:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[74339:74339:0712/042538.921135:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[74339:74339:0712/042538.931120:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74339:74339:0712/042538.931557:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74339:74351:0712/042538.933334:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[74339:74339:0712/042538.933458:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[74339:74351:0712/042538.933441:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[74339:74339:0712/042538.933561:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[74339:74339:0712/042538.933686:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,74386, 4
[1:7:0712/042538.942425:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042539.511844:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/042539.853395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f4a7b5e52e0 0x1bd85e47f760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042539.854447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/042539.854683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042539.855435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[74339:74339:0712/042539.995637:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[74339:74339:0712/042539.995786:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/042540.018950:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042540.331224:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[74339:74339:0712/042540.587492:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[74339:74369:0712/042540.588075:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/042540.588312:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042540.588590:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042540.589076:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042540.589234:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/042540.592504:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d7d85ac, 1
[1:1:0712/042540.592883:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3a7282a2, 0
[1:1:0712/042540.593082:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a3ab0e2, 3
[1:1:0712/042540.593266:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x13ff7e77, 2
[1:1:0712/042540.593441:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa2ffffff82723a ffffffacffffff857d2d 777effffffff13 ffffffe2ffffffb03a2a , 10104, 5
[1:1:0712/042540.594456:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[74339:74369:0712/042540.594749:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��r:��}-w~��:*��(
[74339:74369:0712/042540.594839:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��r:��}-w~��:*xU��(
[1:1:0712/042540.594736:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8fbbc0a0, 3
[74339:74369:0712/042540.595102:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 74445, 5, a282723a ac857d2d 777eff13 e2b03a2a 
[1:1:0712/042540.595108:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a8fd47080, 2
[1:1:0712/042540.595609:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4a79a0ad20, -2
[1:1:0712/042540.617061:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042540.617459:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13ff7e77
[1:1:0712/042540.617857:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13ff7e77
[1:1:0712/042540.618515:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13ff7e77
[1:1:0712/042540.620036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.620268:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.620509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.620789:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.621483:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13ff7e77
[1:1:0712/042540.621839:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4a919817ba
[1:1:0712/042540.622020:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4a91978def, 7f4a9198177a, 7f4a919830cf
[1:1:0712/042540.628874:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13ff7e77
[1:1:0712/042540.629307:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13ff7e77
[1:1:0712/042540.630137:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13ff7e77
[1:1:0712/042540.632270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.632537:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.632786:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.633021:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13ff7e77
[1:1:0712/042540.634458:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13ff7e77
[1:1:0712/042540.634895:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4a919817ba
[1:1:0712/042540.635074:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4a91978def, 7f4a9198177a, 7f4a919830cf
[1:1:0712/042540.644630:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042540.645258:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042540.645454:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff1478d238, 0x7fff1478d1b8)
[1:1:0712/042540.660173:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042540.663094:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/042540.853869:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042540.854149:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042540.905097:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1bd85e1c1220
[1:1:0712/042540.905403:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[74339:74339:0712/042541.246623:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74339:74339:0712/042541.248854:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74339:74351:0712/042541.281873:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[74339:74351:0712/042541.281979:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[74339:74339:0712/042541.282343:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://dzs.pcgames.com.cn/
[74339:74339:0712/042541.282421:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn/, 1
[74339:74339:0712/042541.282551:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://dzs.pcgames.com.cn/, HTTP/1.1 200 OK Server: NWS_TCloud_S2 Connection: keep-alive Date: Fri, 12 Jul 2019 11:26:24 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 11:36:24 GMT Last-Modified: Thu, 11 Jul 2019 19:40:00 GMT Content-Type: text/html Content-Length: 20677 Content-Encoding: gzip X-NWS-LOG-UUID: 16715105074322315110 4ca2f372b9fd9391d7044523c938768a X-Cache-Lookup: Hit From Disktank3 Gz X-Via: PENGBOSHI-JIANGSU_11(200:hit)  ,74445, 5
[1:7:0712/042541.288337:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042541.330973:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://dzs.pcgames.com.cn/
[1:1:0712/042541.426293:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042541.431298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0cbe27b6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/042541.431629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/042541.440493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[74339:74339:0712/042541.477379:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn/, 1
[74339:74339:0712/042541.477507:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn
[1:1:0712/042541.502436:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042541.553055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042541.626611:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042541.659091:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042541.659359:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://dzs.pcgames.com.cn/"
[1:1:0712/042541.848598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042541.849348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cbe27a41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/042541.849590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042542.701390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176 0x7f4a796bd070 0x1bd85e35a8e0 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042542.703984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , if(!window._addIvyID) document.write("<scr"+"ipt src='http://www.pcgames.com.cn/gamesjs/index.js'><\
[1:1:0712/042542.704286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042542.852342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188, "http://dzs.pcgames.com.cn/"
[1:1:0712/042542.854681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||
[1:1:0712/042542.854956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042542.870179:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.894301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188, "http://dzs.pcgames.com.cn/"
[1:1:0712/042542.900448:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.900892:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.901319:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.901728:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.903560:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042542.912399:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188, "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.011734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188, "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.013077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188, "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.338513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209, "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.343149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (function(){function p(){this.c="1261263986";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/042543.343442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042543.505455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f4a7b5e52e0 0x1bd85e2e9260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.506318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , 
[1:1:0712/042543.506539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042543.655326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 231, "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.659014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/042543.659287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042543.770513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f4a7b5e52e0 0x1bd85e388ce0 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042543.773238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (function(){var h={},mt={},c={id:"5284a74a6d44c732746f8d7e14a4d920",dm:["pcgames.com.cn"],js:"tongji
[1:1:0712/042543.773526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042543.805494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5990
[1:1:0712/042543.805819:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042543.806279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 251
[1:1:0712/042543.806556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 251 0x7f4a796bd070 0x1bd85e342160 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 237 0x7f4a7b5e52e0 0x1bd85e388ce0 
[74339:74339:0712/042600.205145:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[74339:74339:0712/042600.209473:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[74339:74339:0712/042600.235732:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[74339:74339:0712/042600.239993:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[74339:74339:0712/042600.270858:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/042600.276967:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/042600.810601:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042601.066632:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://dzs.pcgames.com.cn/"
[1:1:0712/042601.068689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042601.068943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042601.234595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/042601.234905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042601.794555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 251, 7f4a7c002881
[1:1:0712/042601.813317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"237 0x7f4a7b5e52e0 0x1bd85e388ce0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042601.813759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"237 0x7f4a7b5e52e0 0x1bd85e388ce0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042601.814124:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042601.814797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042601.815047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042601.816063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042601.816271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042601.816725:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 343
[1:1:0712/042601.817466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 343 0x7f4a796bd070 0x1bd85e2e2d60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 251 0x7f4a796bd070 0x1bd85e342160 
[1:1:0712/042601.891353:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042601.891629:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://dzs.pcgames.com.cn/"
[1:1:0712/042602.289029:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.397228, 3847, 1
[1:1:0712/042602.289256:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042606.893621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042606.893945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042609.763601:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042609.763870:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://dzs.pcgames.com.cn/"
[1:1:0712/042609.767139:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4a796bd070 0x1bd85e822260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042609.768303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.write("<style type=\"text/css\"> .clearfix:after{content:'';display:block;clear:both;visibi
[1:1:0712/042609.768537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042609.774431:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4a796bd070 0x1bd85e822260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042609.802293:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4a796bd070 0x1bd85e822260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042609.942669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4a796bd070 0x1bd85e822260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042609.948937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4a796bd070 0x1bd85e822260 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042610.535229:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.771272, 1, 0
[1:1:0712/042610.535515:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042610.597017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 343, 7f4a7c002881
[1:1:0712/042610.623915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"251 0x7f4a796bd070 0x1bd85e342160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042610.624305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"251 0x7f4a796bd070 0x1bd85e342160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042610.624645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042610.625234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042610.625451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042610.626349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042610.626560:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042610.626928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 565
[1:1:0712/042610.627173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f4a796bd070 0x1bd85dda6160 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 343 0x7f4a796bd070 0x1bd85e2e2d60 
[1:1:0712/042610.680187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042610.680956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/042610.681208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042612.495817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042612.496059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042612.740468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042612.740949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/042612.741076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042613.457680:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042613.457869:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.459210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7f4a796bd070 0x1bd85dde4960 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.459660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , 

[1:1:0712/042613.459796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042613.460679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7f4a796bd070 0x1bd85dde4960 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.469221:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.470701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.472315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://dzs.pcgames.com.cn/"
[1:1:0712/042613.971749:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 13
[1:1:0712/042613.972036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 613
[1:1:0712/042613.972160:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f4a796bd070 0x1bd85ed45460 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 557 0x7f4a796bd070 0x1bd85dde4960 
[1:1:0712/042614.011870:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 13
[1:1:0712/042614.012171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 614
[1:1:0712/042614.012288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f4a796bd070 0x1bd85e4e27e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 557 0x7f4a796bd070 0x1bd85dde4960 
[1:1:0712/042614.320032:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 13
[1:1:0712/042614.320326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 615
[1:1:0712/042614.320453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 615 0x7f4a796bd070 0x1bd85e588d60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 557 0x7f4a796bd070 0x1bd85dde4960 
[1:1:0712/042614.329750:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042614.343775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 13
[1:1:0712/042614.344040:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 616
[1:1:0712/042614.344201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f4a796bd070 0x1bd85e339560 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 557 0x7f4a796bd070 0x1bd85dde4960 
[1:1:0712/042614.832739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 565, 7f4a7c002881
[1:1:0712/042614.860225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"343 0x7f4a796bd070 0x1bd85e2e2d60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042614.860515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"343 0x7f4a796bd070 0x1bd85e2e2d60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042614.860878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042614.861432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042614.861619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042614.862287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042614.862447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042614.862769:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 638
[1:1:0712/042614.862956:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f4a796bd070 0x1bd85f244460 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 565 0x7f4a796bd070 0x1bd85dda6160 
[1:1:0712/042615.507701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://dzs.pcgames.com.cn/"
[1:1:0712/042615.508555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , g, (p){var p=p||window.event,n=this;if(p!==f){var o=PCgroup.extend({},p);p=pc.eventTarget(p)}j.apply(l,
[1:1:0712/042615.508780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.027923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042616.028140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042616.170107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 599 0x7f4a7b5e52e0 0x1bd85f242160 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.172643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , /*!svn:http://zzsvn.pcauto.com.cn/svn/data/pcgames/commom/js/pcgames.login.1.0.js*/
(function(h,k){f
[1:1:0712/042616.172797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.247074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 600 0x7f4a7b5e52e0 0x1bd85ec78ee0 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.248121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , var bdShare=bdShare||{version:"1.0"};bdShare.ready=bdShare.ready||function(B,C){C=C||document;if(/co
[1:1:0712/042616.248311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.576734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 613, 7f4a7c0028db
[1:1:0712/042616.613932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.614326:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.614839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 672
[1:1:0712/042616.615089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f4a796bd070 0x1bd85f23a960 , 5:3_http://dzs.pcgames.com.cn/, 0, , 613 0x7f4a796bd070 0x1bd85ed45460 
[1:1:0712/042616.615446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.616114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/042616.616339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.626977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 614, 7f4a7c0028db
[1:1:0712/042616.638263:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.638445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.638690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 674
[1:1:0712/042616.638815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 674 0x7f4a796bd070 0x1bd85e7ce960 , 5:3_http://dzs.pcgames.com.cn/, 0, , 614 0x7f4a796bd070 0x1bd85e4e27e0 
[1:1:0712/042616.638959:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.639228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/042616.639331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.663356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 615, 7f4a7c0028db
[1:1:0712/042616.672253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.672403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.672621:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 675
[1:1:0712/042616.672755:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f4a796bd070 0x1bd85e1fb760 , 5:3_http://dzs.pcgames.com.cn/, 0, , 615 0x7f4a796bd070 0x1bd85e588d60 
[1:1:0712/042616.672895:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.673170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/042616.673269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.675732:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 616, 7f4a7c0028db
[1:1:0712/042616.684726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.684870:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"557 0x7f4a796bd070 0x1bd85dde4960 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.685052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 676
[1:1:0712/042616.685152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f4a796bd070 0x1bd85e941760 , 5:3_http://dzs.pcgames.com.cn/, 0, , 616 0x7f4a796bd070 0x1bd85e339560 
[1:1:0712/042616.685283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.685524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){if(c.run===false){return}g.apply(c,f);c.repeatCount++;if(h){var i=d.now()-c.startTime;if(i>h){c.o
[1:1:0712/042616.685648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.775018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 638, 7f4a7c002881
[1:1:0712/042616.783955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"565 0x7f4a796bd070 0x1bd85dda6160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.784129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"565 0x7f4a796bd070 0x1bd85dda6160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042616.784319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042616.784617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042616.784775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042616.785098:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042616.785197:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042616.785360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 678
[1:1:0712/042616.785467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f4a796bd070 0x1bd85e7f18e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 638 0x7f4a796bd070 0x1bd85f244460 
[1:1:0712/042617.211377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042617.211696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042617.613261:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 678, 7f4a7c002881
[1:1:0712/042617.623520:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"638 0x7f4a796bd070 0x1bd85f244460 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042617.623695:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"638 0x7f4a796bd070 0x1bd85f244460 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042617.623906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042617.624225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042617.624330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042617.624646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042617.624745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042617.624937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 699
[1:1:0712/042617.625051:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f4a796bd070 0x1bd85e4e40e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 678 0x7f4a796bd070 0x1bd85e7f18e0 
[1:1:0712/042617.634964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042617.635099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042617.818077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 692 0x7f4a7b5e52e0 0x1bd85e9413e0 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042617.818724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , var bdShare=bdShare||{};bdShare._LogPool=bdShare._LogPool||[],bdShare.ApiPVLogger||function(e){funct
[1:1:0712/042617.818838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042617.841728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7f4a7b5e52e0 0x1bd85f2389e0 , "http://dzs.pcgames.com.cn/"
[1:1:0712/042617.843033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , var bdShare=bdShare||{version:"1.0"};(function(){var P=new Date().getTime();var N=new Date().getTime
[1:1:0712/042617.843150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[74339:74339:0712/042617.877403:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042617.879679:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1bd85e6e0420
[1:1:0712/042617.879876:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[74339:74339:0712/042617.891651:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/042617.916734:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042617.923436:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1bd85e6dfa20
[1:1:0712/042617.923585:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[74339:74339:0712/042617.926198:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn/, 4
[74339:74339:0712/042617.926634:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn
[74339:74339:0712/042617.985702:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[74339:74339:0712/042617.994228:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[74339:74339:0712/042618.021713:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn/, 5
[74339:74339:0712/042618.021912:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://dzs.pcgames.com.cn/, http://dzs.pcgames.com.cn
		remove user.10_2eb82d7c -> 0
[74339:74339:0712/042618.079143:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/042618.195853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042618.196152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042618.199622:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 699, 7f4a7c002881
[1:1:0712/042618.214585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"678 0x7f4a796bd070 0x1bd85e7f18e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042618.214904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"678 0x7f4a796bd070 0x1bd85e7f18e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042618.215320:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042618.215873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042618.216165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042618.216869:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042618.217094:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042618.217470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 757
[1:1:0712/042618.217699:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f4a796bd070 0x1bd85e2fabe0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 699 0x7f4a796bd070 0x1bd85e4e40e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042619.836804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042619.837101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042620.003382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 757, 7f4a7c002881
[1:1:0712/042620.029979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"699 0x7f4a796bd070 0x1bd85e4e40e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042620.030317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"699 0x7f4a796bd070 0x1bd85e4e40e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042620.030825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.031419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042620.031649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042620.032360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042620.032565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042620.032941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 784
[1:1:0712/042620.033176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f4a796bd070 0x1bd85e804060 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 757 0x7f4a796bd070 0x1bd85e2fabe0 
[1:1:0712/042620.329860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.330630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , M.D.onload, (){bdShare.velocity.cssLoadEnd=+new Date()}
[1:1:0712/042620.330864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042620.798569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.799304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/042620.799539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042620.800047:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.802059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.803446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x13ecd6c629c8, 0x1bd85dcf59f0
[1:1:0712/042620.803756:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 1000
[1:1:0712/042620.804239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 803
[1:1:0712/042620.804479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f4a796bd070 0x1bd85eae15e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 779 0x7f4a796bd070 0x1bd85f2495e0 
[1:1:0712/042620.807233:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://dzs.pcgames.com.cn/"
[1:1:0712/042620.808617:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5af0
[1:1:0712/042620.808842:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042620.809194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 804
[1:1:0712/042620.809418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f4a796bd070 0x1bd85e7cc3e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 779 0x7f4a796bd070 0x1bd85f2495e0 
[1:1:0712/042620.865660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , document.readyState
[1:1:0712/042620.865963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042621.458840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 804, 7f4a7c002881
[1:1:0712/042621.493265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"779 0x7f4a796bd070 0x1bd85f2495e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042621.493592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"779 0x7f4a796bd070 0x1bd85f2495e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042621.494012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042621.494619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042621.494882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042621.495618:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042621.495889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042621.496772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 822
[1:1:0712/042621.497245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 822 0x7f4a796bd070 0x1bd85eabdb60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 804 0x7f4a796bd070 0x1bd85e7cc3e0 
[1:1:0712/042621.851949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 822, 7f4a7c002881
[1:1:0712/042621.885588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"804 0x7f4a796bd070 0x1bd85e7cc3e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042621.885943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"804 0x7f4a796bd070 0x1bd85e7cc3e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042621.886333:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042621.886878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042621.887123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042621.887784:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042621.888019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042621.888379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 838
[1:1:0712/042621.888601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f4a796bd070 0x1bd85ec73560 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 822 0x7f4a796bd070 0x1bd85eabdb60 
[1:1:0712/042622.039742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 803, 7f4a7c002881
[1:1:0712/042622.058735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"779 0x7f4a796bd070 0x1bd85f2495e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.059091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"779 0x7f4a796bd070 0x1bd85f2495e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.059482:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.060055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){p(),h()}
[1:1:0712/042622.060274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.083354:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 1000
[1:1:0712/042622.083886:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 842
[1:1:0712/042622.084155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7f4a796bd070 0x1bd85e57a5e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 803 0x7f4a796bd070 0x1bd85eae15e0 
[1:1:0712/042622.122140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 838, 7f4a7c002881
[1:1:0712/042622.134527:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"822 0x7f4a796bd070 0x1bd85eabdb60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.134873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"822 0x7f4a796bd070 0x1bd85eabdb60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.135288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.135861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042622.136125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.136842:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042622.137093:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042622.137484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 850
[1:1:0712/042622.137718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f4a796bd070 0x1bd85e389f60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 838 0x7f4a796bd070 0x1bd85ec73560 
[1:1:0712/042622.379925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 850, 7f4a7c002881
[1:1:0712/042622.415534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"838 0x7f4a796bd070 0x1bd85ec73560 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.415900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"838 0x7f4a796bd070 0x1bd85ec73560 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.416547:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.417560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042622.417813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.418687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042622.418904:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042622.419311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 859
[1:1:0712/042622.419562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f4a796bd070 0x1bd85e03b260 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 850 0x7f4a796bd070 0x1bd85e389f60 
[1:1:0712/042622.503239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.504679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , r.onload.r.onerror, (){e[n]=null}
[1:1:0712/042622.505215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.545075:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 859, 7f4a7c002881
[1:1:0712/042622.585306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"850 0x7f4a796bd070 0x1bd85e389f60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.586004:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"850 0x7f4a796bd070 0x1bd85e389f60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.586840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.588294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042622.588759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.590652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042622.591057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042622.591989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 865
[1:1:0712/042622.592553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f4a796bd070 0x1bd85eb4a160 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 859 0x7f4a796bd070 0x1bd85e03b260 
[74339:74339:0712/042622.597461:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/042622.696750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 865, 7f4a7c002881
[1:1:0712/042622.746022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"859 0x7f4a796bd070 0x1bd85e03b260 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.746830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"859 0x7f4a796bd070 0x1bd85e03b260 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.747833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.749307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042622.749896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.751867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042622.752503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042622.753507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 871
[1:1:0712/042622.754109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7f4a796bd070 0x1bd85e2e41e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 865 0x7f4a796bd070 0x1bd85eb4a160 
[1:1:0712/042622.929281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 871, 7f4a7c002881
[1:1:0712/042622.949628:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"865 0x7f4a796bd070 0x1bd85eb4a160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.950045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"865 0x7f4a796bd070 0x1bd85eb4a160 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042622.950456:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042622.951098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042622.951350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042622.952060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042622.952328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042622.952862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 880
[1:1:0712/042622.953137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f4a796bd070 0x1bd85f26dee0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 871 0x7f4a796bd070 0x1bd85e2e41e0 
[1:1:0712/042623.189192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 880, 7f4a7c002881
[1:1:0712/042623.230286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"871 0x7f4a796bd070 0x1bd85e2e41e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.230715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"871 0x7f4a796bd070 0x1bd85e2e41e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.231134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.231744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042623.232033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.236973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042623.237310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042623.237771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 889
[1:1:0712/042623.238021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7f4a796bd070 0x1bd85e7f73e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 880 0x7f4a796bd070 0x1bd85f26dee0 
[1:1:0712/042623.242556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 842, 7f4a7c0028db
[1:1:0712/042623.264866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"803 0x7f4a796bd070 0x1bd85eae15e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.265333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"803 0x7f4a796bd070 0x1bd85eae15e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.265977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 892
[1:1:0712/042623.266374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f4a796bd070 0x1bd85e2f2be0 , 5:3_http://dzs.pcgames.com.cn/, 0, , 842 0x7f4a796bd070 0x1bd85e57a5e0 
[1:1:0712/042623.266768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.267482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){document.hasFocus()&&u++}
[1:1:0712/042623.267813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.357125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 889, 7f4a7c002881
[1:1:0712/042623.401786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"880 0x7f4a796bd070 0x1bd85f26dee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.402264:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"880 0x7f4a796bd070 0x1bd85f26dee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.402728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.403376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042623.403675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.404467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042623.404689:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042623.405084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 895
[1:1:0712/042623.405376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7f4a796bd070 0x1bd85e8f9560 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 889 0x7f4a796bd070 0x1bd85e7f73e0 
[1:1:0712/042623.530028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 895, 7f4a7c002881
[1:1:0712/042623.549895:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"889 0x7f4a796bd070 0x1bd85e7f73e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.550278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"889 0x7f4a796bd070 0x1bd85e7f73e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.550695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.551266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042623.551521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.552283:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042623.552534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042623.552912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 903
[1:1:0712/042623.553142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7f4a796bd070 0x1bd85e57a5e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 895 0x7f4a796bd070 0x1bd85e8f9560 
[1:1:0712/042623.672252:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 903, 7f4a7c002881
[1:1:0712/042623.689367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"895 0x7f4a796bd070 0x1bd85e8f9560 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.689800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"895 0x7f4a796bd070 0x1bd85e8f9560 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.690220:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.690810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042623.691025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.691615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042623.691850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042623.692215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 909
[1:1:0712/042623.692455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f4a796bd070 0x1bd85e7f7d60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 903 0x7f4a796bd070 0x1bd85e57a5e0 
[1:1:0712/042623.821333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 909, 7f4a7c002881
[1:1:0712/042623.859971:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"903 0x7f4a796bd070 0x1bd85e57a5e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.860386:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"903 0x7f4a796bd070 0x1bd85e57a5e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042623.860789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042623.861362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042623.861630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042623.862363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042623.862581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042623.862982:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 915
[1:1:0712/042623.863212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f4a796bd070 0x1bd85f23fc60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 909 0x7f4a796bd070 0x1bd85e7f7d60 
[1:1:0712/042623.997536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 915, 7f4a7c002881
[1:1:0712/042624.032654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"909 0x7f4a796bd070 0x1bd85e7f7d60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.033064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"909 0x7f4a796bd070 0x1bd85e7f7d60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.033457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.034077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042624.034303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.035024:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042624.035247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042624.035648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 922
[1:1:0712/042624.035945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f4a796bd070 0x1bd85e7f0a60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 915 0x7f4a796bd070 0x1bd85f23fc60 
[1:1:0712/042624.085801:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 892, 7f4a7c0028db
[1:1:0712/042624.126875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"842 0x7f4a796bd070 0x1bd85e57a5e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.127256:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"842 0x7f4a796bd070 0x1bd85e57a5e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.127861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 927
[1:1:0712/042624.128128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7f4a796bd070 0x1bd85f2490e0 , 5:3_http://dzs.pcgames.com.cn/, 0, , 892 0x7f4a796bd070 0x1bd85e2f2be0 
[1:1:0712/042624.128428:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.128988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){document.hasFocus()&&u++}
[1:1:0712/042624.129216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.292145:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 922, 7f4a7c002881
[1:1:0712/042624.308922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"915 0x7f4a796bd070 0x1bd85f23fc60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.309299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"915 0x7f4a796bd070 0x1bd85f23fc60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.309730:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.310350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042624.310598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.311302:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042624.311503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042624.311934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 934
[1:1:0712/042624.312163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 934 0x7f4a796bd070 0x1bd85e7f90e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 922 0x7f4a796bd070 0x1bd85e7f0a60 
[1:1:0712/042624.455811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 934, 7f4a7c002881
[1:1:0712/042624.483917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"922 0x7f4a796bd070 0x1bd85e7f0a60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.484339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"922 0x7f4a796bd070 0x1bd85e7f0a60 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.484773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.485371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042624.485649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.486366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042624.486568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042624.486960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 938
[1:1:0712/042624.487208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f4a796bd070 0x1bd85dda87e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 934 0x7f4a796bd070 0x1bd85e7f90e0 
[1:1:0712/042624.629052:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 938, 7f4a7c002881
[1:1:0712/042624.668103:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"934 0x7f4a796bd070 0x1bd85e7f90e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.668503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"934 0x7f4a796bd070 0x1bd85e7f90e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.668936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.669559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042624.669793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.670492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042624.670709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042624.671093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 941
[1:1:0712/042624.671323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7f4a796bd070 0x1bd85eb405e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 938 0x7f4a796bd070 0x1bd85dda87e0 
[1:1:0712/042624.795890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 941, 7f4a7c002881
[1:1:0712/042624.828644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"938 0x7f4a796bd070 0x1bd85dda87e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.829100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"938 0x7f4a796bd070 0x1bd85dda87e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042624.829519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042624.830147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042624.830384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042624.831132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042624.831348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042624.831810:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 943
[1:1:0712/042624.832064:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 943 0x7f4a796bd070 0x1bd85e7cc4e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 941 0x7f4a796bd070 0x1bd85eb405e0 
[1:1:0712/042624.963530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 943, 7f4a7c002881
[1:1:0712/042625.001857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"941 0x7f4a796bd070 0x1bd85eb405e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.002281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"941 0x7f4a796bd070 0x1bd85eb405e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.002691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.003289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.003519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.004036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.004252:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.004634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 945
[1:1:0712/042625.004882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7f4a796bd070 0x1bd85f242ee0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 943 0x7f4a796bd070 0x1bd85e7cc4e0 
[1:1:0712/042625.100813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 927, 7f4a7c0028db
[1:1:0712/042625.118345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"892 0x7f4a796bd070 0x1bd85e2f2be0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.119012:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"892 0x7f4a796bd070 0x1bd85e2f2be0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.120020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://dzs.pcgames.com.cn/, 947
[1:1:0712/042625.120525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f4a796bd070 0x1bd85f2540e0 , 5:3_http://dzs.pcgames.com.cn/, 0, , 927 0x7f4a796bd070 0x1bd85f2490e0 
[1:1:0712/042625.121004:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.122166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , , (){document.hasFocus()&&u++}
[1:1:0712/042625.122622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.126324:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 945, 7f4a7c002881
[1:1:0712/042625.152217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"943 0x7f4a796bd070 0x1bd85e7cc4e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.153022:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"943 0x7f4a796bd070 0x1bd85e7cc4e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.153888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.155104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.155515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.156492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.156939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.157687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 949
[1:1:0712/042625.158101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 949 0x7f4a796bd070 0x1bd85e9266e0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 945 0x7f4a796bd070 0x1bd85f242ee0 
[1:1:0712/042625.273269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 949, 7f4a7c002881
[1:1:0712/042625.295021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"945 0x7f4a796bd070 0x1bd85f242ee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.295500:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"945 0x7f4a796bd070 0x1bd85f242ee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.296052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.296682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.297006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.297760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.298136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.299256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 951
[1:1:0712/042625.299696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f4a796bd070 0x1bd85f238ee0 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 949 0x7f4a796bd070 0x1bd85e9266e0 
[1:1:0712/042625.418125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 951, 7f4a7c002881
[1:1:0712/042625.435461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"949 0x7f4a796bd070 0x1bd85e9266e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.435979:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"949 0x7f4a796bd070 0x1bd85e9266e0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.436472:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.437216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.437483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.438311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.438553:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.439017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 953
[1:1:0712/042625.439267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f4a796bd070 0x1bd85e388060 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 951 0x7f4a796bd070 0x1bd85f238ee0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042625.577283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 953, 7f4a7c002881
[1:1:0712/042625.616361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"951 0x7f4a796bd070 0x1bd85f238ee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.616769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"951 0x7f4a796bd070 0x1bd85f238ee0 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.617202:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.617786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.618054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.618800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.619022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.619411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 955
[1:1:0712/042625.619707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 955 0x7f4a796bd070 0x1bd85f25df60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 953 0x7f4a796bd070 0x1bd85e388060 
[1:1:0712/042625.752204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 955, 7f4a7c002881
[1:1:0712/042625.785249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"340b42402860","ptid":"953 0x7f4a796bd070 0x1bd85e388060 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.785715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://dzs.pcgames.com.cn/","ptid":"953 0x7f4a796bd070 0x1bd85e388060 ","rf":"5:3_http://dzs.pcgames.com.cn/"}
[1:1:0712/042625.786225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://dzs.pcgames.com.cn/"
[1:1:0712/042625.786972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://dzs.pcgames.com.cn/, 340b42402860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/042625.787234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://dzs.pcgames.com.cn/", "dzs.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042625.788030:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x13ecd6c629c8, 0x1bd85dcf5950
[1:1:0712/042625.788296:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://dzs.pcgames.com.cn/", 100
[1:1:0712/042625.788787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://dzs.pcgames.com.cn/, 957
[1:1:0712/042625.789084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7f4a796bd070 0x1bd85e1d0b60 , 5:3_http://dzs.pcgames.com.cn/, 1, -5:3_http://dzs.pcgames.com.cn/, 955 0x7f4a796bd070 0x1bd85f25df60 
