[0712/042944.919212:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042944.919598:INFO:switcher_clone.cc(787)] backtrace rip is 7f21714ad891
[0712/042945.860393:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042945.860765:INFO:switcher_clone.cc(787)] backtrace rip is 7fb532213891
[1:1:0712/042945.873157:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/042945.873403:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/042945.881412:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[74874:74874:0712/042947.169204:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/63a43e06-5708-4506-a25a-71a80de4848e
[0712/042947.402427:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/042947.402767:INFO:switcher_clone.cc(787)] backtrace rip is 7fa8794bd891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[74907:74907:0712/042947.594964:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=74907
[74918:74918:0712/042947.595392:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=74918
[74874:74874:0712/042947.756444:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[74874:74904:0712/042947.757044:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/042947.757254:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042947.757526:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042947.758110:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042947.758358:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/042947.761643:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1c6865d9, 1
[1:1:0712/042947.762035:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x194e2a28, 0
[1:1:0712/042947.762255:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x362d8ca7, 3
[1:1:0712/042947.762439:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1012c8aa, 2
[1:1:0712/042947.762637:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 282a4e19 ffffffd965681c ffffffaaffffffc81210 ffffffa7ffffff8c2d36 , 10104, 4
[1:1:0712/042947.763787:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[74874:74904:0712/042947.764043:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING(*N�eh����-6�
�+
[74874:74904:0712/042947.764107:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is (*N�eh����-6H��
�+
[74874:74904:0712/042947.764476:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/042947.764045:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb53044e0a0, 3
[74874:74904:0712/042947.764541:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 74926, 4, 282a4e19 d965681c aac81210 a78c2d36 
[1:1:0712/042947.764569:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5305d9080, 2
[1:1:0712/042947.764730:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb51a29cd20, -2
[1:1:0712/042947.780579:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042947.781621:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1012c8aa
[1:1:0712/042947.782854:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1012c8aa
[1:1:0712/042947.784773:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1012c8aa
[1:1:0712/042947.785820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.786010:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.786177:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.786437:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.786873:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1012c8aa
[1:1:0712/042947.787142:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5322137ba
[1:1:0712/042947.787324:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb53220adef, 7fb53221377a, 7fb5322150cf
[1:1:0712/042947.789887:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1012c8aa
[1:1:0712/042947.790133:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1012c8aa
[1:1:0712/042947.790583:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1012c8aa
[1:1:0712/042947.791635:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.791783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.791940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.792077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1012c8aa
[1:1:0712/042947.792790:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1012c8aa
[1:1:0712/042947.793035:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5322137ba
[1:1:0712/042947.793144:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb53220adef, 7fb53221377a, 7fb5322150cf
[1:1:0712/042947.796620:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042947.796962:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042947.797081:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe13ec1f78, 0x7ffe13ec1ef8)
[1:1:0712/042947.815909:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042947.823182:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[74874:74874:0712/042948.513955:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74874:74874:0712/042948.515655:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74874:74885:0712/042948.534644:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[74874:74885:0712/042948.534772:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[74874:74874:0712/042948.534849:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[74874:74874:0712/042948.534926:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[74874:74874:0712/042948.535064:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,74926, 4
[1:7:0712/042948.538773:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[74874:74897:0712/042948.565407:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/042948.587290:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3c990fa96220
[1:1:0712/042948.587637:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/042949.006333:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[74874:74874:0712/042950.570444:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[74874:74874:0712/042950.570567:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042950.586935:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042950.590462:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042951.371149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042951.371488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042951.402453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/042951.402775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042951.420763:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042951.791680:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042951.791969:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042952.107011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042952.115170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042952.115437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042952.137018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042952.146187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/042952.146520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042952.158498:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/042952.161868:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c990fa94e20
[1:1:0712/042952.162074:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[74874:74874:0712/042952.162771:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[74874:74874:0712/042952.179444:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[74874:74874:0712/042952.212232:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[74874:74874:0712/042952.212376:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/042952.261114:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042953.019316:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fb51be772e0 0x3c990f6751e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042953.020638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/042953.020872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042953.022289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[74874:74874:0712/042953.091063:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/042953.092324:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c990fa95820
[1:1:0712/042953.092617:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[74874:74874:0712/042953.104196:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/042953.111136:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/042953.111338:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[74874:74874:0712/042953.129685:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[74874:74874:0712/042953.144960:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74874:74874:0712/042953.146249:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74874:74885:0712/042953.153867:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[74874:74885:0712/042953.153959:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[74874:74874:0712/042953.154198:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[74874:74874:0712/042953.154295:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[74874:74874:0712/042953.154470:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,74926, 4
[1:7:0712/042953.158047:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042953.627006:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/042953.956045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fb51be772e0 0x3c990fd39de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/042953.957025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 00c240b01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/042953.957276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/042953.958063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[74874:74874:0712/042954.049684:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[74874:74874:0712/042954.049831:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/042954.066368:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042954.348990:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042954.942480:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042954.942677:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[74874:74874:0712/042954.991411:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[74874:74904:0712/042954.991861:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/042954.992077:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/042954.992315:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/042954.992717:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/042954.992886:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/042954.996242:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23f4880f, 1
[1:1:0712/042954.996629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x191bb685, 0
[1:1:0712/042954.996785:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c045685, 3
[1:1:0712/042954.996927:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc7c288a, 2
[1:1:0712/042954.997095:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff85ffffffb61b19 0fffffff88fffffff423 ffffff8a287c0c ffffff8556041c , 10104, 5
[1:1:0712/042954.998059:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[74874:74904:0712/042954.998305:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����#�(|�V�+
[74874:74904:0712/042954.998376:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����#�(|�V(�+
[1:1:0712/042954.998295:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb53044e0a0, 3
[1:1:0712/042954.998491:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5305d9080, 2
[74874:74904:0712/042954.998614:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 74970, 5, 85b61b19 0f88f423 8a287c0c 8556041c 
[1:1:0712/042954.998670:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb51a29cd20, -2
[1:1:0712/042955.020516:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/042955.020870:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c7c288a
[1:1:0712/042955.021205:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c7c288a
[1:1:0712/042955.021819:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c7c288a
[1:1:0712/042955.023231:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.023416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.023604:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.023780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.024463:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c7c288a
[1:1:0712/042955.024750:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5322137ba
[1:1:0712/042955.024881:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb53220adef, 7fb53221377a, 7fb5322150cf
[1:1:0712/042955.030827:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c7c288a
[1:1:0712/042955.031239:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c7c288a
[1:1:0712/042955.031958:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c7c288a
[1:1:0712/042955.034007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.034220:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.034404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.034605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c7c288a
[1:1:0712/042955.035829:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c7c288a
[1:1:0712/042955.036232:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5322137ba
[1:1:0712/042955.036383:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb53220adef, 7fb53221377a, 7fb5322150cf
[1:1:0712/042955.044387:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/042955.044928:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/042955.045131:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe13ec1f78, 0x7ffe13ec1ef8)
[1:1:0712/042955.060693:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/042955.066584:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/042955.247867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042955.252502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 00c240c2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/042955.252814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/042955.260726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/042955.275364:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c990fa5b220
[1:1:0712/042955.275628:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[74874:74874:0712/042955.705427:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74874:74874:0712/042955.710075:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74874:74885:0712/042955.724031:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[74874:74885:0712/042955.724127:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[74874:74874:0712/042955.724234:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://age.pcgames.com.cn/
[74874:74874:0712/042955.724287:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://age.pcgames.com.cn/, http://age.pcgames.com.cn/, 1
[74874:74874:0712/042955.724355:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://age.pcgames.com.cn/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 11:29:55 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 11:39:55 GMT Cache-Control: max-age=600 Content-Encoding: gzip  ,74970, 5
[1:7:0712/042955.730899:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/042955.779623:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://age.pcgames.com.cn/
[74874:74874:0712/042955.928951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://age.pcgames.com.cn/, http://age.pcgames.com.cn/, 1
[74874:74874:0712/042955.929082:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://age.pcgames.com.cn/, http://age.pcgames.com.cn
[1:1:0712/042955.967118:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042956.067625:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/042956.115758:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/042956.169030:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/042956.169311:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://age.pcgames.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/042957.644536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 246 0x7fb519f4f070 0x3c990fd62660 , "http://age.pcgames.com.cn/"
[1:1:0712/042957.646701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , if(!window._addIvyID) document.write("<scr"+"ipt src='http://gamesjs.pcgames.com.cn/index.js'><\/scr
[1:1:0712/042957.646935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042957.738077:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042957.738565:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042957.740057:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042957.740416:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042957.740787:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/042958.411037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307, "http://age.pcgames.com.cn/"
[1:1:0712/042958.415237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||
[1:1:0712/042958.415495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042958.430707:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_c2065b5f -> 0
		remove user.11_1b58e120 -> 0
		remove user.12_fb8bd57d -> 0
		remove user.13_ba6f1a26 -> 0
		remove user.14_ebf93b67 -> 0
[1:1:0712/042958.452732:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307, "http://age.pcgames.com.cn/"
[1:1:0712/042958.469738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307, "http://age.pcgames.com.cn/"
[1:1:0712/042958.548532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307, "http://age.pcgames.com.cn/"
[1:1:0712/042958.551285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307, "http://age.pcgames.com.cn/"
[1:1:0712/042959.502390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376, "http://age.pcgames.com.cn/"
[1:1:0712/042959.505224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , (function(){function p(){this.c="1261263986";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/042959.505473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/042959.910760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7fb51be772e0 0x3c990fbfdae0 , "http://age.pcgames.com.cn/"
[1:1:0712/042959.911611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , 
[1:1:0712/042959.911847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043000.114511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416, "http://age.pcgames.com.cn/"
[1:1:0712/043000.115926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043000.117607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043000.233338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fb51be772e0 0x3c990fc237e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043000.238331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , (function(){var h={},mt={},c={id:"5284a74a6d44c732746f8d7e14a4d920",dm:["pcgames.com.cn"],js:"tongji
[1:1:0712/043000.238582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043000.265358:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671190
[1:1:0712/043000.265624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043000.266094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 434
[1:1:0712/043000.266377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7fb519f4f070 0x3c990fbd7b60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 420 0x7fb51be772e0 0x3c990fc237e0 
[74874:74874:0712/043013.185049:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[74874:74874:0712/043013.191242:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[74874:74874:0712/043013.258750:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[74874:74874:0712/043013.262717:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[74874:74874:0712/043013.272939:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043013.293072:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043013.774677:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043013.880654:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://age.pcgames.com.cn/"
[1:1:0712/043013.882693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043013.882926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043014.102498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043014.102852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043015.198995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 434, 7fb51c894881
[1:1:0712/043015.224461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"420 0x7fb51be772e0 0x3c990fc237e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043015.224828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"420 0x7fb51be772e0 0x3c990fc237e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043015.225205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043015.225767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043015.225976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043015.226771:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043015.227071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043015.227438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 521
[1:1:0712/043015.227789:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7fb519f4f070 0x3c990fbfd960 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 434 0x7fb519f4f070 0x3c990fbd7b60 
[1:1:0712/043015.291959:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043015.292243:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://age.pcgames.com.cn/"
[1:1:0712/043015.316509:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[74874:74874:0712/043015.320287:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043015.322701:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c9910215820
[1:1:0712/043015.322997:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[74874:74874:0712/043015.325581:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/043015.348479:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043015.350233:INFO:render_frame_impl.cc(7019)] 	 [url] = http://age.pcgames.com.cn
[74874:74874:0712/043015.353637:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://age.pcgames.com.cn/
[74874:74874:0712/043015.399930:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[74874:74874:0712/043015.404001:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[74874:74885:0712/043015.416603:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[74874:74874:0712/043015.416654:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://follow.v.t.qq.com/
[74874:74874:0712/043015.416697:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://follow.v.t.qq.com/, http://follow.v.t.qq.com/index.php?c=follow&a=index&appkey=801396213&bg=ffffff&hsize=50&name=pcgage,pcgames, 4
[74874:74885:0712/043015.416704:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[74874:74874:0712/043015.416759:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://follow.v.t.qq.com/, HTTP/1.1 403 Forbidden Server: squid/3.5.24 Date: Fri, 12 Jul 2019 11:30:15 GMT Content-Type: text/html Content-Length: 571 Connection: keep-alive  ,74970, 5
[1:7:0712/043015.421759:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043015.562029:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.269723, 2625, 1
[1:1:0712/043015.562317:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043018.369545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043018.370140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043019.602708:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://follow.v.t.qq.com/
[1:1:0712/043019.610561:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 (Forbidden)","http://follow.v.t.qq.com/index.php?c=follow&a=index&appkey=801396213&bg=ffffff&hsize=50&name=pcgage,pcgames"
[1:1:0712/043020.954905:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043020.955177:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://age.pcgames.com.cn/"
[1:1:0712/043020.958374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043020.959162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , 

[1:1:0712/043020.959345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043020.964821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043020.971464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043020.983607:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043021.050428:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043021.081574:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 3000
[1:1:0712/043021.082067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 668
[1:1:0712/043021.082305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7fb519f4f070 0x3c99102bdbe0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 607 0x7fb519f4f070 0x3c990fbfd9e0 
[1:1:0712/043021.104122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7fb519f4f070 0x3c990fbfd9e0 , "http://age.pcgames.com.cn/"
[1:1:0712/043021.107252:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://age.pcgames.com.cn/"
[1:1:0712/043021.108376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://age.pcgames.com.cn/"
[1:1:0712/043021.109403:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://age.pcgames.com.cn/"
[1:1:0712/043021.897043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 521, 7fb51c894881
[1:1:0712/043021.927240:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"434 0x7fb519f4f070 0x3c990fbd7b60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043021.927636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"434 0x7fb519f4f070 0x3c990fbd7b60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043021.927975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043021.928320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043021.928434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043021.928854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043021.928962:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043021.929142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 678
[1:1:0712/043021.929256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7fb519f4f070 0x3c9910ba3c60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 521 0x7fb519f4f070 0x3c990fbfd960 
[1:1:0712/043021.953102:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://age.pcgames.com.cn/"
[1:1:0712/043021.953675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043021.953851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043022.115272:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","http://www1.pcgames.com.cn/zt/g130809/sgsj/img/ftbg.png"
[1:1:0712/043022.978450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043022.978817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043023.289900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://age.pcgames.com.cn/"
[1:1:0712/043023.290349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/043023.290476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043023.433825:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[74874:74874:0712/043023.441589:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://follow.v.t.qq.com/, http://follow.v.t.qq.com/, 4
[74874:74874:0712/043023.441719:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://follow.v.t.qq.com/, http://follow.v.t.qq.com
[1:1:0712/043023.720516:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 678, 7fb51c894881
[1:1:0712/043023.736838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"521 0x7fb519f4f070 0x3c990fbfd960 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043023.737110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"521 0x7fb519f4f070 0x3c990fbfd960 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043023.737404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043023.737840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043023.737992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043023.738461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043023.738602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043023.738841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 728
[1:1:0712/043023.738999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7fb519f4f070 0x3c99102c0be0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 678 0x7fb519f4f070 0x3c9910ba3c60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043024.172673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043024.172867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043024.376961:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043024.790965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 724 0x7fb51be772e0 0x3c990fff5ae0 , "http://age.pcgames.com.cn/"
[1:1:0712/043024.793266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , /*!svn:http://zzsvn.pcauto.com.cn/svn/data/pcgames/commom/js/pcgames.login.1.0.js*/
(function(h,k){f
[1:1:0712/043024.793547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043024.893839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 728, 7fb51c894881
[1:1:0712/043024.920220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"678 0x7fb519f4f070 0x3c9910ba3c60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043024.920601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"678 0x7fb519f4f070 0x3c9910ba3c60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043024.920900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043024.921440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043024.921638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043024.922284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043024.922459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043024.922885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 760
[1:1:0712/043024.923077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7fb519f4f070 0x3c990ffe87e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 728 0x7fb519f4f070 0x3c99102c0be0 
[1:1:0712/043025.003849:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 668, 7fb51c8948db
[1:1:0712/043025.019700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"607 0x7fb519f4f070 0x3c990fbfd9e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043025.019910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"607 0x7fb519f4f070 0x3c990fbfd9e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043025.020107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 761
[1:1:0712/043025.020220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7fb519f4f070 0x3c990fbe8360 , 5:3_http://age.pcgames.com.cn/, 0, , 668 0x7fb519f4f070 0x3c99102bdbe0 
[1:1:0712/043025.020371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043025.020940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043025.021165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043025.260761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043025.261032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043025.431089:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043025.431371:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://follow.v.t.qq.com/index.php?c=follow&a=index&appkey=801396213&bg=ffffff&hsize=50&name=pcgage,pcgames"
[1:1:0712/043025.999752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 760, 7fb51c894881
[1:1:0712/043026.032714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"728 0x7fb519f4f070 0x3c99102c0be0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043026.033088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"728 0x7fb519f4f070 0x3c99102c0be0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043026.037154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043026.038044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043026.038316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043026.039072:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043026.039278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043026.039659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 808
[1:1:0712/043026.039999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7fb519f4f070 0x3c990ffe7460 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 760 0x7fb519f4f070 0x3c990ffe87e0 
[1:1:0712/043026.148642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043026.148963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043026.737394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043026.737737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043026.741291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 808, 7fb51c894881
[1:1:0712/043026.770084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"760 0x7fb519f4f070 0x3c990ffe87e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043026.770441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"760 0x7fb519f4f070 0x3c990ffe87e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043026.770804:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043026.771406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043026.771664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043026.772188:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043026.772381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043026.772756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 823
[1:1:0712/043026.773023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7fb519f4f070 0x3c990fb1c260 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 808 0x7fb519f4f070 0x3c990ffe7460 
[1:1:0712/043026.816235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://age.pcgames.com.cn/"
[1:1:0712/043026.817000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/043026.817330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043026.817964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://age.pcgames.com.cn/"
[1:1:0712/043026.833519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://age.pcgames.com.cn/"
[1:1:0712/043026.834631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f6712f0
[1:1:0712/043026.834867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043026.835255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 833
[1:1:0712/043026.835486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7fb519f4f070 0x3c9910b99f60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 819 0x7fb5305d9080 0x3c9910dca420 1 0 0x3c9910dca438 
[1:1:0712/043027.061278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , document.readyState
[1:1:0712/043027.061593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043027.288876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 833, 7fb51c894881
[1:1:0712/043027.301923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"819 0x7fb5305d9080 0x3c9910dca420 1 0 0x3c9910dca438 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043027.302172:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"819 0x7fb5305d9080 0x3c9910dca420 1 0 0x3c9910dca438 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043027.302387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043027.302743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043027.302878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043027.303232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043027.303334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043027.303515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 857
[1:1:0712/043027.303628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 857 0x7fb519f4f070 0x3c9910a6a660 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 833 0x7fb519f4f070 0x3c9910b99f60 
[1:1:0712/043027.408148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 761, 7fb51c8948db
[1:1:0712/043027.422884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"668 0x7fb519f4f070 0x3c99102bdbe0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043027.423140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"668 0x7fb519f4f070 0x3c99102bdbe0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043027.423419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 868
[1:1:0712/043027.423546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7fb519f4f070 0x3c991027f1e0 , 5:3_http://age.pcgames.com.cn/, 0, , 761 0x7fb519f4f070 0x3c990fbe8360 
[1:1:0712/043027.423706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043027.424026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043027.424197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043028.044566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 857, 7fb51c894881
[1:1:0712/043028.082355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"833 0x7fb519f4f070 0x3c9910b99f60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.082736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"833 0x7fb519f4f070 0x3c9910b99f60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.083059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043028.083616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043028.083809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043028.084533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043028.084698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043028.085023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 877
[1:1:0712/043028.085238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7fb519f4f070 0x3c99102cf9e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 857 0x7fb519f4f070 0x3c9910a6a660 
[1:1:0712/043028.440767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 877, 7fb51c894881
[1:1:0712/043028.478551:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"857 0x7fb519f4f070 0x3c9910a6a660 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.478893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"857 0x7fb519f4f070 0x3c9910a6a660 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.479182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043028.479738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043028.479917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043028.480611:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043028.480775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043028.481107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 892
[1:1:0712/043028.481295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7fb519f4f070 0x3c9910b90660 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 877 0x7fb519f4f070 0x3c99102cf9e0 
[1:1:0712/043028.766239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 892, 7fb51c894881
[1:1:0712/043028.778123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"877 0x7fb519f4f070 0x3c99102cf9e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.778428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"877 0x7fb519f4f070 0x3c99102cf9e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.778667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043028.779112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043028.779290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043028.779648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043028.779753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043028.779930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 896
[1:1:0712/043028.780043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7fb519f4f070 0x3c990fc2d560 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 892 0x7fb519f4f070 0x3c9910b90660 
[1:1:0712/043028.890078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 896, 7fb51c894881
[1:1:0712/043028.901866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"892 0x7fb519f4f070 0x3c9910b90660 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.902074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"892 0x7fb519f4f070 0x3c9910b90660 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043028.902250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043028.902584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043028.902696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043028.903007:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043028.903109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043028.903286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 909
[1:1:0712/043028.903401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7fb519f4f070 0x3c990fb70ce0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 896 0x7fb519f4f070 0x3c990fc2d560 
[1:1:0712/043029.012750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 909, 7fb51c894881
[1:1:0712/043029.051221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"896 0x7fb519f4f070 0x3c990fc2d560 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.051592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"896 0x7fb519f4f070 0x3c990fc2d560 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.051891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.052424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.052663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.057411:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.057598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.057934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 917
[1:1:0712/043029.058125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7fb519f4f070 0x3c990fa8d960 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 909 0x7fb519f4f070 0x3c990fb70ce0 
[1:1:0712/043029.176573:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 917, 7fb51c894881
[1:1:0712/043029.215868:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"909 0x7fb519f4f070 0x3c990fb70ce0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.216189:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"909 0x7fb519f4f070 0x3c990fb70ce0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.216508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.217048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.217252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.217972:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.218133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.218458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 923
[1:1:0712/043029.218669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7fb519f4f070 0x3c990ffe97e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 917 0x7fb519f4f070 0x3c990fa8d960 
[1:1:0712/043029.358191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 923, 7fb51c894881
[1:1:0712/043029.406375:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"917 0x7fb519f4f070 0x3c990fa8d960 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.406833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"917 0x7fb519f4f070 0x3c990fa8d960 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.407197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.407912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.408160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.409029:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.409235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.409688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 930
[1:1:0712/043029.409943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 930 0x7fb519f4f070 0x3c99102def60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 923 0x7fb519f4f070 0x3c990ffe97e0 
[1:1:0712/043029.532889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 930, 7fb51c894881
[1:1:0712/043029.544342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"923 0x7fb519f4f070 0x3c990ffe97e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.544510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"923 0x7fb519f4f070 0x3c990ffe97e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.544694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.544994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.545096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.545392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.545489:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.545687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 936
[1:1:0712/043029.545798:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7fb519f4f070 0x3c990fc8d6e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 930 0x7fb519f4f070 0x3c99102def60 
[1:1:0712/043029.684995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 936, 7fb51c894881
[1:1:0712/043029.722150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"930 0x7fb519f4f070 0x3c99102def60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.722483:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"930 0x7fb519f4f070 0x3c99102def60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.722775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.723286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.723456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.724134:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.724288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.724611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 938
[1:1:0712/043029.724819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7fb519f4f070 0x3c990fe4de60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 936 0x7fb519f4f070 0x3c990fc8d6e0 
[1:1:0712/043029.845172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 938, 7fb51c894881
[1:1:0712/043029.886631:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"936 0x7fb519f4f070 0x3c990fc8d6e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.886997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"936 0x7fb519f4f070 0x3c990fc8d6e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043029.887283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043029.887862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043029.888044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043029.888725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043029.888887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043029.889222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 942
[1:1:0712/043029.889410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7fb519f4f070 0x3c99102effe0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 938 0x7fb519f4f070 0x3c990fe4de60 
[1:1:0712/043030.017965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 942, 7fb51c894881
[1:1:0712/043030.037721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"938 0x7fb519f4f070 0x3c990fe4de60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.037951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"938 0x7fb519f4f070 0x3c990fe4de60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.038129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.038440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.038546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.038903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.039005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.039181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 944
[1:1:0712/043030.039292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 944 0x7fb519f4f070 0x3c990fc230e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 942 0x7fb519f4f070 0x3c99102effe0 
[1:1:0712/043030.127270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 868, 7fb51c8948db
[1:1:0712/043030.160558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"761 0x7fb519f4f070 0x3c990fbe8360 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.160942:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"761 0x7fb519f4f070 0x3c990fbe8360 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.161369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://age.pcgames.com.cn/, 946
[1:1:0712/043030.161629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7fb519f4f070 0x3c99102bf260 , 5:3_http://age.pcgames.com.cn/, 0, , 868 0x7fb519f4f070 0x3c991027f1e0 
[1:1:0712/043030.161988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.162671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , , (){var c=d.curPage+1;d.playTo(c)}
[1:1:0712/043030.162872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.228906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 944, 7fb51c894881
[1:1:0712/043030.275070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"942 0x7fb519f4f070 0x3c99102effe0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.275393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"942 0x7fb519f4f070 0x3c99102effe0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.275725:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.276364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.276550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.277451:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.277681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.278170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 954
[1:1:0712/043030.278465:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7fb519f4f070 0x3c99102b63e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 944 0x7fb519f4f070 0x3c990fc230e0 
[1:1:0712/043030.399038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 954, 7fb51c894881
[1:1:0712/043030.413943:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"944 0x7fb519f4f070 0x3c990fc230e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.414169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"944 0x7fb519f4f070 0x3c990fc230e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.414345:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.414664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.414772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.415096:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.415194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.415389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 957
[1:1:0712/043030.415515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7fb519f4f070 0x3c990fb648e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 954 0x7fb519f4f070 0x3c99102b63e0 
[1:1:0712/043030.556134:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 957, 7fb51c894881
[1:1:0712/043030.595953:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"954 0x7fb519f4f070 0x3c99102b63e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.596302:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"954 0x7fb519f4f070 0x3c99102b63e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.596588:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.597139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.597317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.597990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.598153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.598488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 959
[1:1:0712/043030.598693:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7fb519f4f070 0x3c99103a9c60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 957 0x7fb519f4f070 0x3c990fb648e0 
[1:1:0712/043030.741078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 959, 7fb51c894881
[1:1:0712/043030.785409:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"957 0x7fb519f4f070 0x3c990fb648e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.785785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"957 0x7fb519f4f070 0x3c990fb648e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.786151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.786754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.787030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.787700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.787979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.788345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 961
[1:1:0712/043030.788575:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7fb519f4f070 0x3c990ffed7e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 959 0x7fb519f4f070 0x3c99103a9c60 
[1:1:0712/043030.955274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 961, 7fb51c894881
[1:1:0712/043030.994049:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"959 0x7fb519f4f070 0x3c99103a9c60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.994344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"959 0x7fb519f4f070 0x3c99103a9c60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043030.994615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043030.995157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043030.995335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043030.996022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043030.996184:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043030.996510:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 965
[1:1:0712/043030.996710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7fb519f4f070 0x3c990fd8ce60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 961 0x7fb519f4f070 0x3c990ffed7e0 
[1:1:0712/043031.166190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 965, 7fb51c894881
[1:1:0712/043031.205247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"961 0x7fb519f4f070 0x3c990ffed7e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.205561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"961 0x7fb519f4f070 0x3c990ffed7e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.205842:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043031.206390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043031.206580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043031.207257:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043031.207421:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043031.207752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 967
[1:1:0712/043031.207940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7fb519f4f070 0x3c9910b991e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 965 0x7fb519f4f070 0x3c990fd8ce60 
[1:1:0712/043031.356434:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 967, 7fb51c894881
[1:1:0712/043031.395494:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"965 0x7fb519f4f070 0x3c990fd8ce60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.395798:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"965 0x7fb519f4f070 0x3c990fd8ce60 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.396106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043031.396632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043031.396808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043031.397479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043031.397637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043031.397967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 969
[1:1:0712/043031.398185:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7fb519f4f070 0x3c990fad67e0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 967 0x7fb519f4f070 0x3c9910b991e0 
[1:1:0712/043031.563276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 969, 7fb51c894881
[1:1:0712/043031.586981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"967 0x7fb519f4f070 0x3c9910b991e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.587180:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"967 0x7fb519f4f070 0x3c9910b991e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.587357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043031.587670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043031.587791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043031.588156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043031.588266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043031.588443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 971
[1:1:0712/043031.588556:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7fb519f4f070 0x3c990fa78be0 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 969 0x7fb519f4f070 0x3c990fad67e0 
[1:1:0712/043031.737868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 971, 7fb51c894881
[1:1:0712/043031.780356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"969 0x7fb519f4f070 0x3c990fad67e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.780707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"969 0x7fb519f4f070 0x3c990fad67e0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043031.781000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043031.781568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043031.781755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043031.782468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043031.782637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043031.782989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 973
[1:1:0712/043031.783211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7fb519f4f070 0x3c990fb70a60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 971 0x7fb519f4f070 0x3c990fa78be0 
[1:1:0712/043031.968516:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 973, 7fb51c894881
[1:1:0712/043032.010329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32de90d22860","ptid":"971 0x7fb519f4f070 0x3c990fa78be0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043032.010640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://age.pcgames.com.cn/","ptid":"971 0x7fb519f4f070 0x3c990fa78be0 ","rf":"5:3_http://age.pcgames.com.cn/"}
[1:1:0712/043032.010926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://age.pcgames.com.cn/"
[1:1:0712/043032.011484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://age.pcgames.com.cn/, 32de90d22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043032.011684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://age.pcgames.com.cn/", "age.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043032.012416:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xaa50fd629c8, 0x3c990f671150
[1:1:0712/043032.012585:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://age.pcgames.com.cn/", 100
[1:1:0712/043032.012928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://age.pcgames.com.cn/, 977
[1:1:0712/043032.013126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7fb519f4f070 0x3c990f8eca60 , 5:3_http://age.pcgames.com.cn/, 1, -5:3_http://age.pcgames.com.cn/, 973 0x7fb519f4f070 0x3c990fb70a60 
