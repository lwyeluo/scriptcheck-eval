[0712/043426.488289:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043426.488626:INFO:switcher_clone.cc(787)] backtrace rip is 7f65e4317891
[0712/043427.464638:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043427.465170:INFO:switcher_clone.cc(787)] backtrace rip is 7f8f5edb4891
[1:1:0712/043427.479483:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/043427.479834:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/043427.485184:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[75502:75502:0712/043428.752831:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/504c56b2-f82b-4ffd-b8ec-229c033aaf4c
[0712/043428.876596:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/043428.876896:INFO:switcher_clone.cc(787)] backtrace rip is 7eff4e297891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[75535:75535:0712/043429.085688:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75535
[75547:75547:0712/043429.086103:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=75547
[75502:75502:0712/043429.283800:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[75502:75533:0712/043429.284577:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/043429.284783:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043429.284996:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043429.285537:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043429.285646:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/043429.288056:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d02f53b, 1
[1:1:0712/043429.288421:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2816f9b5, 0
[1:1:0712/043429.288622:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x166292bc, 3
[1:1:0712/043429.288820:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x332ca2c8, 2
[1:1:0712/043429.289053:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb5fffffff91628 3bfffffff5021d ffffffc8ffffffa22c33 ffffffbcffffff926216 , 10104, 4
[1:1:0712/043429.290047:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75502:75533:0712/043429.290324:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��(;�Ȣ,3��bN�d*
[75502:75533:0712/043429.290392:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��(;�Ȣ,3��b�gN�d*
[1:1:0712/043429.290318:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f5cfef0a0, 3
[1:1:0712/043429.290510:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f5d17a080, 2
[75502:75533:0712/043429.290633:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/043429.290663:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f46e3dd20, -2
[75502:75533:0712/043429.290714:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75555, 4, b5f91628 3bf5021d c8a22c33 bc926216 
[1:1:0712/043429.314697:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043429.315612:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 332ca2c8
[1:1:0712/043429.316599:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 332ca2c8
[1:1:0712/043429.318167:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 332ca2c8
[1:1:0712/043429.319692:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.319879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.320064:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.320296:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.320935:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 332ca2c8
[1:1:0712/043429.321296:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8f5edb47ba
[1:1:0712/043429.321437:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8f5edabdef, 7f8f5edb477a, 7f8f5edb60cf
[1:1:0712/043429.327067:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 332ca2c8
[1:1:0712/043429.327445:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 332ca2c8
[1:1:0712/043429.328174:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 332ca2c8
[1:1:0712/043429.330302:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.330500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.330688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.330868:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 332ca2c8
[1:1:0712/043429.332137:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 332ca2c8
[1:1:0712/043429.332543:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8f5edb47ba
[1:1:0712/043429.332684:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8f5edabdef, 7f8f5edb477a, 7f8f5edb60cf
[1:1:0712/043429.340529:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043429.341016:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043429.341164:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeed099598, 0x7ffeed099518)
[1:1:0712/043429.356854:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043429.363268:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[75502:75502:0712/043429.880799:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75502:75502:0712/043429.882168:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75502:75502:0712/043429.895703:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[75502:75513:0712/043429.895669:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[75502:75502:0712/043429.895771:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[75502:75502:0712/043429.895839:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,75555, 4
[75502:75513:0712/043429.895813:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043429.898521:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[75502:75524:0712/043429.931417:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/043430.016696:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2411e9cde220
[1:1:0712/043430.016959:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/043430.355737:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/043431.862710:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043431.864742:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[75502:75502:0712/043431.880834:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[75502:75502:0712/043431.880998:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043432.811714:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043433.006695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043433.006996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043433.016997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/043433.017298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043433.281652:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043433.281943:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043433.665785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043433.674007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043433.674265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043433.709770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043433.720706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/043433.720993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043433.726623:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/043433.730013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2411e9cdce20
[1:1:0712/043433.730237:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[75502:75502:0712/043433.731969:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[75502:75502:0712/043433.750685:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[75502:75502:0712/043433.798490:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[75502:75502:0712/043433.798699:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/043433.814297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[75502:75502:0712/043433.828485:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/043434.610349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f8f48a182e0 0x2411e9dfa5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043434.611831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/043434.612082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043434.613643:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75502:75502:0712/043434.679190:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/043434.681456:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2411e9cdd820
[1:1:0712/043434.681683:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[75502:75502:0712/043434.689152:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/043434.703957:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/043434.704227:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[75502:75502:0712/043434.711524:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[75502:75502:0712/043434.723107:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75502:75502:0712/043434.724129:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75502:75513:0712/043434.730672:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[75502:75513:0712/043434.730766:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[75502:75502:0712/043434.730909:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[75502:75502:0712/043434.730987:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[75502:75502:0712/043434.731121:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,75555, 4
[1:7:0712/043434.734279:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043435.214453:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/043435.452894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f8f48a182e0 0x2411e9d193e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043435.453947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/043435.454178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043435.454954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[75502:75502:0712/043435.533629:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[75502:75502:0712/043435.533737:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/043435.560794:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043435.779086:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043436.203798:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043436.204109:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043436.521877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043436.526435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 178b8afae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/043436.526739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043436.534681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[75502:75502:0712/043436.641164:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[75502:75533:0712/043436.641554:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/043436.641759:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/043436.642079:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/043436.642674:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/043436.642909:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/043436.646595:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2c2e9f52, 1
[1:1:0712/043436.646978:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x167c5cb3, 0
[1:1:0712/043436.647206:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x88507d2, 3
[1:1:0712/043436.647401:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f85e3ce, 2
[1:1:0712/043436.647630:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb35c7c16 52ffffff9f2e2c ffffffceffffffe3ffffff852f ffffffd207ffffff8508 , 10104, 5
[1:1:0712/043436.648954:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[75502:75533:0712/043436.649374:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�\|R�.,��/����d*
[75502:75533:0712/043436.649481:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �\|R�.,��/���.��d*
[1:1:0712/043436.649367:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f5cfef0a0, 3
[75502:75533:0712/043436.649719:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 75601, 5, b35c7c16 529f2e2c cee3852f d2078508 
[1:1:0712/043436.649591:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f5d17a080, 2
[1:1:0712/043436.649930:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8f46e3dd20, -2
[1:1:0712/043436.673115:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/043436.673575:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f85e3ce
[1:1:0712/043436.674154:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f85e3ce
[1:1:0712/043436.674836:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f85e3ce
[1:1:0712/043436.676330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.676572:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.676799:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.677021:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.677718:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f85e3ce
[1:1:0712/043436.678089:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8f5edb47ba
[1:1:0712/043436.678279:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8f5edabdef, 7f8f5edb477a, 7f8f5edb60cf
[1:1:0712/043436.684062:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f85e3ce
[1:1:0712/043436.684455:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f85e3ce
[1:1:0712/043436.685229:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f85e3ce
[1:1:0712/043436.687313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.687556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.687797:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.688027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f85e3ce
[1:1:0712/043436.689318:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f85e3ce
[1:1:0712/043436.689710:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8f5edb47ba
[1:1:0712/043436.689881:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8f5edabdef, 7f8f5edb477a, 7f8f5edb60cf
[1:1:0712/043436.695862:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/043436.696507:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/043436.696702:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeed099598, 0x7ffeed099518)
[1:1:0712/043436.713824:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/043436.718983:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/043436.734728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/043436.735525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 178b8ae81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/043436.735774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/043436.921511:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2411e9cb4220
[1:1:0712/043436.921804:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/043436.932197:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043436.933888:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043436.934122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 178b8afae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043436.934374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043437.051002:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043437.051931:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/043437.052196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 178b8afae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/043437.052463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[75502:75502:0712/043437.120237:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[75502:75502:0712/043437.126838:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[75502:75502:0712/043437.166779:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://app.pcgames.com.cn/
[75502:75502:0712/043437.166875:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://app.pcgames.com.cn/, http://app.pcgames.com.cn/?ad=3323, 1
[75502:75502:0712/043437.167005:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://app.pcgames.com.cn/, HTTP/1.1 200 OK Server: nws_ocmid_hy Connection: keep-alive Date: Fri, 12 Jul 2019 11:34:36 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 11:44:36 GMT Last-Modified: Thu, 11 Jul 2019 15:40:00 GMT Content-Type: text/html Content-Length: 121061 X-NWS-UUID-VERIFY: 783d047bb268d057392bcbb50d273331 X-NWS-LOG-UUID: 18250548884693451739 d8b9e3ab6376d3d096922da3b72b4df6 X-Cache-Lookup: Hit From Disktank3 X-Daa-Tunnel: hop_count=3 X-Cache-Lookup: Hit From Inner Cluster X-Cache-Lookup: Hit From Upstream X-Cache-Lookup: Hit From Inner Cluster   ,75601, 5
[75502:75513:0712/043437.168665:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[75502:75513:0712/043437.168754:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/043437.171354:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/043437.243769:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://app.pcgames.com.cn/
[75502:75502:0712/043437.358344:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://app.pcgames.com.cn/, http://app.pcgames.com.cn/, 1
[75502:75502:0712/043437.358453:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://app.pcgames.com.cn/, http://app.pcgames.com.cn
[1:1:0712/043437.404335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043437.437293:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043437.448405:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/043437.468100:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043437.468324:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.657735:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/043437.752960:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/043437.772278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 149 0x7f8f46af0070 0x2411e9e2ebe0 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.774668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , if(!window._addIvyID) document.write("<scr"+"ipt src='http://www.pcgames.com.cn/gamesjs/index.js'><\
[1:1:0712/043437.774971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043437.811909:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/043437.817288:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.819180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||
[1:1:0712/043437.819429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043437.831970:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043437.848934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.865191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.890855:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/043437.929828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.932876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043437.972068:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/043438.021252:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/043438.177156:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/043438.181669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 177, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043438.184393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , (function(){function p(){this.c="1261263986";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/043438.184717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043438.228189:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/043438.415323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/043438.416396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 178b8afae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/043438.416679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/043438.568030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200, "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043438.569437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/043438.569701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043438.602342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f8f48a182e0 0x2411e9e839e0 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043438.603181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , 
[1:1:0712/043438.603400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043438.625872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f8f48a182e0 0x2411e9dccee0 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043438.630819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , (function(){var h={},mt={},c={id:"5284a74a6d44c732746f8d7e14a4d920",dm:["pcgames.com.cn"],js:"tongji
[1:1:0712/043438.631089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043438.654558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1190
[1:1:0712/043438.654829:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043438.655275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 223
[1:1:0712/043438.655504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 223 0x7f8f46af0070 0x2411e9d84a60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 205 0x7f8f48a182e0 0x2411e9dccee0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043439.474333:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043439.474847:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043439.481567:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043439.482138:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/043439.482511:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[75502:75502:0712/043453.239492:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[75502:75502:0712/043453.243511:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1261263986, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source:  (1)
[75502:75502:0712/043453.267468:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[75502:75502:0712/043453.271542:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1261263986&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1261263986 (17)
[75502:75502:0712/043453.316437:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/043453.323311:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/043453.814216:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043454.071287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/043454.071604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043454.548225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 223, 7f8f49435881
[1:1:0712/043454.562897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"205 0x7f8f48a182e0 0x2411e9dccee0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043454.563253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"205 0x7f8f48a182e0 0x2411e9dccee0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043454.563624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043454.564291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043454.564577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043454.565425:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043454.565649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043454.566043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 313
[1:1:0712/043454.566272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 313 0x7f8f46af0070 0x2411ea02bf60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 223 0x7f8f46af0070 0x2411e9d84a60 
[1:1:0712/043454.597361:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043454.599285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043454.599575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043454.616713:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043454.616931:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043454.634795:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.017756, 211, 1
[1:1:0712/043454.635051:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/043455.524585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , document.readyState
[1:1:0712/043455.524910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043455.964919:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/043455.965184:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043455.967242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043455.986487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , (function(c,f){if(c.PCgroup){return}var b,d=Object.prototype.toString,e=Array.prototype.slice,a=c.do
[1:1:0712/043455.986773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043456.102315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.157985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.216379:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.224569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.260968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.277656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.294393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7f8f46af0070 0x2411e9f55260 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.302267:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.303673:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.305174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.435930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.538330:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.539223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/043456.539474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043456.541426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 313, 7f8f49435881
[1:1:0712/043456.558936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"223 0x7f8f46af0070 0x2411e9d84a60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043456.559310:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"223 0x7f8f46af0070 0x2411e9d84a60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043456.559608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043456.560241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043456.560471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043456.561220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043456.561587:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043456.561970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 402
[1:1:0712/043456.562238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7f8f46af0070 0x2411ea0407e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 313 0x7f8f46af0070 0x2411ea02bf60 
[1:1:0712/043457.158683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , document.readyState
[1:1:0712/043457.158966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043457.414588:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043457.415334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/043457.415577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043457.732410:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 402, 7f8f49435881
[1:1:0712/043457.751887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"313 0x7f8f46af0070 0x2411ea02bf60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043457.752291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"313 0x7f8f46af0070 0x2411ea02bf60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043457.752700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043457.753500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043457.753733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043457.754496:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043457.754698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043457.755112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 446
[1:1:0712/043457.755426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 446 0x7f8f46af0070 0x2411e9e7f1e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 402 0x7f8f46af0070 0x2411ea0407e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043458.170318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , document.readyState
[1:1:0712/043458.170633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043458.441636:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f8f48a182e0 0x2411e9e861e0 , "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.447848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , /*!svn:http://zzsvn.pcauto.com.cn/svn/data/pcgames/commom/js/pcgames.login.1.0.js*/
(function(h,k){f
[1:1:0712/043458.448146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043458.546298:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.547114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/043458.547347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043458.548091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.548913:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.564310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.565926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f12f0
[1:1:0712/043458.566156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043458.566594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 470
[1:1:0712/043458.566842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7f8f46af0070 0x2411e9dc34e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 448 0x7f8f5d17a080 0x2411ea071380 1 0 0x2411ea071398 
[1:1:0712/043458.782112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , , document.readyState
[1:1:0712/043458.782482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043458.927914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 470, 7f8f49435881
[1:1:0712/043458.949489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"448 0x7f8f5d17a080 0x2411ea071380 1 0 0x2411ea071398 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043458.949918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"448 0x7f8f5d17a080 0x2411ea071380 1 0 0x2411ea071398 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043458.950268:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043458.950953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043458.951184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043458.952001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043458.952216:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043458.952678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 489
[1:1:0712/043458.952938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 489 0x7f8f46af0070 0x2411e9dc28e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 470 0x7f8f46af0070 0x2411e9dc34e0 
[1:1:0712/043459.381872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 489, 7f8f49435881
[1:1:0712/043459.407517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"470 0x7f8f46af0070 0x2411e9dc34e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.407908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"470 0x7f8f46af0070 0x2411e9dc34e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.408221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043459.408838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043459.409102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043459.409860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043459.410059:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043459.410453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 499
[1:1:0712/043459.410692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7f8f46af0070 0x2411ea2ad960 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 489 0x7f8f46af0070 0x2411e9dc28e0 
[1:1:0712/043459.645693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 499, 7f8f49435881
[1:1:0712/043459.655427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"489 0x7f8f46af0070 0x2411e9dc28e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.655827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"489 0x7f8f46af0070 0x2411e9dc28e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.656163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043459.656783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043459.657009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043459.657775:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043459.657977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043459.658395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 512
[1:1:0712/043459.658629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 512 0x7f8f46af0070 0x2411e9e7f1e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 499 0x7f8f46af0070 0x2411ea2ad960 
[1:1:0712/043459.770948:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 512, 7f8f49435881
[1:1:0712/043459.788400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"499 0x7f8f46af0070 0x2411ea2ad960 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.788767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"499 0x7f8f46af0070 0x2411ea2ad960 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.789109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043459.789713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043459.789958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043459.790682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043459.790889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043459.791282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 518
[1:1:0712/043459.791509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f8f46af0070 0x2411e9d4aae0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 512 0x7f8f46af0070 0x2411e9e7f1e0 
[1:1:0712/043459.954642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 518, 7f8f49435881
[1:1:0712/043459.977141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"512 0x7f8f46af0070 0x2411e9e7f1e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.977523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"512 0x7f8f46af0070 0x2411e9e7f1e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043459.977870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043459.978453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043459.978660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043459.979356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043459.979547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043459.980028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 525
[1:1:0712/043459.980287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f8f46af0070 0x2411e9d4b4e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 518 0x7f8f46af0070 0x2411e9d4aae0 
[1:1:0712/043500.094978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 525, 7f8f49435881
[1:1:0712/043500.109996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"518 0x7f8f46af0070 0x2411e9d4aae0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.110376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"518 0x7f8f46af0070 0x2411e9d4aae0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.110703:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.111344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.111576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.112558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.112954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.113473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 530
[1:1:0712/043500.113738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7f8f46af0070 0x2411e9f15ce0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 525 0x7f8f46af0070 0x2411e9d4b4e0 
[1:1:0712/043500.236834:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 530, 7f8f49435881
[1:1:0712/043500.257936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"525 0x7f8f46af0070 0x2411e9d4b4e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.258257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"525 0x7f8f46af0070 0x2411e9d4b4e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.258548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.259130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.259341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.260101:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.260311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.260691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 532
[1:1:0712/043500.260968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f8f46af0070 0x2411e9dc4ae0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 530 0x7f8f46af0070 0x2411e9f15ce0 
[1:1:0712/043500.382232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 532, 7f8f49435881
[1:1:0712/043500.403063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"530 0x7f8f46af0070 0x2411e9f15ce0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.403366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"530 0x7f8f46af0070 0x2411e9f15ce0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.403646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.404249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.404454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.405269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.405462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.405906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 536
[1:1:0712/043500.406152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f8f46af0070 0x2411e9b1ce60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 532 0x7f8f46af0070 0x2411e9dc4ae0 
[1:1:0712/043500.528474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 536, 7f8f49435881
[1:1:0712/043500.535816:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"532 0x7f8f46af0070 0x2411e9dc4ae0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.536185:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"532 0x7f8f46af0070 0x2411e9dc4ae0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.536479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.537097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.537310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.538044:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.538348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.538732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 538
[1:1:0712/043500.538955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 538 0x7f8f46af0070 0x2411e9d4a560 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 536 0x7f8f46af0070 0x2411e9b1ce60 
[1:1:0712/043500.670972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 538, 7f8f49435881
[1:1:0712/043500.687603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"536 0x7f8f46af0070 0x2411e9b1ce60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.688217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"536 0x7f8f46af0070 0x2411e9b1ce60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.688729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.689818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.690201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.691610:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.691918:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.692613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 540
[1:1:0712/043500.692985:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7f8f46af0070 0x2411e9c8e8e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 538 0x7f8f46af0070 0x2411e9d4a560 
[1:1:0712/043500.818674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 540, 7f8f49435881
[1:1:0712/043500.847092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"538 0x7f8f46af0070 0x2411e9d4a560 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.847534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"538 0x7f8f46af0070 0x2411e9d4a560 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043500.847953:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043500.848627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043500.848891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043500.849665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043500.849908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043500.850675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 542
[1:1:0712/043500.851175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7f8f46af0070 0x2411e99ae2e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 540 0x7f8f46af0070 0x2411e9c8e8e0 
[1:1:0712/043500.976000:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 542, 7f8f49435881
[1:1:0712/043501.007022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"540 0x7f8f46af0070 0x2411e9c8e8e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.007616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"540 0x7f8f46af0070 0x2411e9c8e8e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.008159:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.009223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.009580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.010368:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.010636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.011102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 544
[1:1:0712/043501.011384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 544 0x7f8f46af0070 0x2411e9d263e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 542 0x7f8f46af0070 0x2411e99ae2e0 
[1:1:0712/043501.137187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 544, 7f8f49435881
[1:1:0712/043501.158798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"542 0x7f8f46af0070 0x2411e99ae2e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.159110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"542 0x7f8f46af0070 0x2411e99ae2e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.159423:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.160027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.160273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.160959:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.161195:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.161575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 546
[1:1:0712/043501.161792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7f8f46af0070 0x2411e9e81d60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 544 0x7f8f46af0070 0x2411e9d263e0 
[1:1:0712/043501.287370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 546, 7f8f49435881
[1:1:0712/043501.300043:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"544 0x7f8f46af0070 0x2411e9d263e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.300978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"544 0x7f8f46af0070 0x2411e9d263e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.301791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.303356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.303869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.306131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.306682:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.307753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 548
[1:1:0712/043501.308467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7f8f46af0070 0x2411ea2e1f60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 546 0x7f8f46af0070 0x2411e9e81d60 
[1:1:0712/043501.416715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 548, 7f8f49435881
[1:1:0712/043501.455736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"546 0x7f8f46af0070 0x2411e9e81d60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.456186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"546 0x7f8f46af0070 0x2411e9e81d60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.456604:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.457374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.457685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.458541:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.458841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.459503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 551
[1:1:0712/043501.459793:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 551 0x7f8f46af0070 0x2411e9d524e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 548 0x7f8f46af0070 0x2411ea2e1f60 
[1:1:0712/043501.602574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 551, 7f8f49435881
[1:1:0712/043501.645876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"548 0x7f8f46af0070 0x2411ea2e1f60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.646304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"548 0x7f8f46af0070 0x2411ea2e1f60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.646633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.647258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.647485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.648305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.648510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.648918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 553
[1:1:0712/043501.649156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 553 0x7f8f46af0070 0x2411ea051660 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 551 0x7f8f46af0070 0x2411e9d524e0 
[1:1:0712/043501.775954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 553, 7f8f49435881
[1:1:0712/043501.783361:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"551 0x7f8f46af0070 0x2411e9d524e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.783991:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"551 0x7f8f46af0070 0x2411e9d524e0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.784628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.785848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.786344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.787952:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.788331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.789268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 555
[1:1:0712/043501.789725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7f8f46af0070 0x2411e9c8dbe0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 553 0x7f8f46af0070 0x2411ea051660 
[1:1:0712/043501.929211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 555, 7f8f49435881
[1:1:0712/043501.951925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"553 0x7f8f46af0070 0x2411ea051660 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.952299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"553 0x7f8f46af0070 0x2411ea051660 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043501.952668:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043501.953356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043501.953613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043501.954401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043501.954638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043501.955069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 557
[1:1:0712/043501.955332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f8f46af0070 0x2411e995ca60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 555 0x7f8f46af0070 0x2411e9c8dbe0 
[1:1:0712/043502.055847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 557, 7f8f49435881
[1:1:0712/043502.085472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"555 0x7f8f46af0070 0x2411e9c8dbe0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.085859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"555 0x7f8f46af0070 0x2411e9c8dbe0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.086190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.086834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.087071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.087860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.088641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.089165:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 559
[1:1:0712/043502.089499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 559 0x7f8f46af0070 0x2411ea02b860 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 557 0x7f8f46af0070 0x2411e995ca60 
[1:1:0712/043502.209041:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 559, 7f8f49435881
[1:1:0712/043502.227200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"557 0x7f8f46af0070 0x2411e995ca60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.227734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"557 0x7f8f46af0070 0x2411e995ca60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.228244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.229199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.229563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.230780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.231063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.231724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 561
[1:1:0712/043502.232080:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f8f46af0070 0x2411ea3d5be0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 559 0x7f8f46af0070 0x2411ea02b860 
[1:1:0712/043502.356368:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 561, 7f8f49435881
[1:1:0712/043502.379496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"559 0x7f8f46af0070 0x2411ea02b860 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.379861:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"559 0x7f8f46af0070 0x2411ea02b860 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.380190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.380828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.381145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.381907:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.382136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.382657:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 563
[1:1:0712/043502.382922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f8f46af0070 0x2411e9f5f160 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 561 0x7f8f46af0070 0x2411ea3d5be0 
[1:1:0712/043502.518053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 563, 7f8f49435881
[1:1:0712/043502.541055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"561 0x7f8f46af0070 0x2411ea3d5be0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.541418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"561 0x7f8f46af0070 0x2411ea3d5be0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.541758:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.542365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.542651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.543409:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.543724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.544152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 565
[1:1:0712/043502.544414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f8f46af0070 0x2411e9e60760 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 563 0x7f8f46af0070 0x2411e9f5f160 
[1:1:0712/043502.681421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 565, 7f8f49435881
[1:1:0712/043502.704355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"563 0x7f8f46af0070 0x2411e9f5f160 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.704688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"563 0x7f8f46af0070 0x2411e9f5f160 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.704987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.705585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.705802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.706538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.706779:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.707174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 567
[1:1:0712/043502.707403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f8f46af0070 0x2411e9d20560 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 565 0x7f8f46af0070 0x2411e9e60760 
[1:1:0712/043502.830202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 567, 7f8f49435881
[1:1:0712/043502.842471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"565 0x7f8f46af0070 0x2411e9e60760 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.842878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"565 0x7f8f46af0070 0x2411e9e60760 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.843250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.844081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.844350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.845344:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.845614:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.846138:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 569
[1:1:0712/043502.846654:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7f8f46af0070 0x2411e9d26ce0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 567 0x7f8f46af0070 0x2411e9d20560 
[1:1:0712/043502.970983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 569, 7f8f49435881
[1:1:0712/043502.994337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"567 0x7f8f46af0070 0x2411e9d20560 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.994697:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"567 0x7f8f46af0070 0x2411e9d20560 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043502.995003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043502.995623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043502.995843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043502.996555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043502.996772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043502.997170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 571
[1:1:0712/043502.997406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f8f46af0070 0x2411e9aa5e60 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 569 0x7f8f46af0070 0x2411e9d26ce0 
[1:1:0712/043503.119315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 571, 7f8f49435881
[1:1:0712/043503.142688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"569 0x7f8f46af0070 0x2411e9d26ce0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.143021:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"569 0x7f8f46af0070 0x2411e9d26ce0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.143322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043503.143961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043503.144179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043503.144927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043503.145129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043503.145521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 573
[1:1:0712/043503.145776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f8f46af0070 0x2411e9db4360 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 571 0x7f8f46af0070 0x2411e9aa5e60 
[1:1:0712/043503.285432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 573, 7f8f49435881
[1:1:0712/043503.325519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"571 0x7f8f46af0070 0x2411e9aa5e60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.326110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"571 0x7f8f46af0070 0x2411e9aa5e60 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.326455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043503.327290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043503.327581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043503.328508:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043503.328761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043503.329203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 575
[1:1:0712/043503.329466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f8f46af0070 0x2411ea3d5be0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 573 0x7f8f46af0070 0x2411e9db4360 
[1:1:0712/043503.454814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 575, 7f8f49435881
[1:1:0712/043503.491325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"573 0x7f8f46af0070 0x2411e9db4360 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.491835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"573 0x7f8f46af0070 0x2411e9db4360 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.492201:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043503.492864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043503.493146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043503.493956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043503.494219:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043503.494775:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 577
[1:1:0712/043503.495066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 577 0x7f8f46af0070 0x2411e9f94360 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 575 0x7f8f46af0070 0x2411ea3d5be0 
[1:1:0712/043503.631613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 577, 7f8f49435881
[1:1:0712/043503.668471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"575 0x7f8f46af0070 0x2411ea3d5be0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.668811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"575 0x7f8f46af0070 0x2411ea3d5be0 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0712/043503.669114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0712/043503.669693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/043503.669921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0712/043503.670653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0712/043503.670862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0712/043503.671253:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 579
[1:1:0712/043503.671678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f8f46af0070 0x2411e9f5f5e0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 577 0x7f8f46af0070 0x2411e9f94360 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/043503.802544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 579, 7f8f49435881
[1:1:0100/000000.829121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"027581662860","ptid":"577 0x7f8f46af0070 0x2411e9f94360 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0100/000000.842850:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://app.pcgames.com.cn/","ptid":"577 0x7f8f46af0070 0x2411e9f94360 ","rf":"5:3_http://app.pcgames.com.cn/"}
[1:1:0100/000000.843156:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://app.pcgames.com.cn/?ad=3323"
[1:1:0100/000000.843820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://app.pcgames.com.cn/, 027581662860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.844007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://app.pcgames.com.cn/?ad=3323", "app.pcgames.com.cn", 3, 1, , , 0
[1:1:0100/000000.844866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x36e2eb9429c8, 0x2411e97f1150
[1:1:0100/000000.845003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://app.pcgames.com.cn/?ad=3323", 100
[1:1:0100/000000.845376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://app.pcgames.com.cn/, 618
[1:1:0100/000000.845550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f8f46af0070 0x2411e9dd6ce0 , 5:3_http://app.pcgames.com.cn/, 1, -5:3_http://app.pcgames.com.cn/, 579 0x7f8f46af0070 0x2411e9f5f5e0 
