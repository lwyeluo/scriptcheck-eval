[0712/010848.736469:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010848.736933:INFO:switcher_clone.cc(787)] backtrace rip is 7f9f36a87891
[0712/010849.849400:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010849.849789:INFO:switcher_clone.cc(787)] backtrace rip is 7f7205be5891
[1:1:0712/010849.861549:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/010849.861875:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/010849.867227:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[46641:46641:0712/010851.109718:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c7788604-4c9b-4d44-8008-5764ed6919ff
[0712/010851.332567:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/010851.332997:INFO:switcher_clone.cc(787)] backtrace rip is 7fe0a5c82891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[46673:46673:0712/010851.536354:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46673
[46686:46686:0712/010851.536977:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=46686
[46641:46641:0712/010851.768533:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[46641:46671:0712/010851.769215:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/010851.769438:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010851.769732:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010851.770343:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010851.770506:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/010851.774088:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x29ef12fc, 1
[1:1:0712/010851.774463:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12c20671, 0
[1:1:0712/010851.774663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1b92b16e, 3
[1:1:0712/010851.774904:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2b40cf42, 2
[1:1:0712/010851.775151:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7106ffffffc212 fffffffc12ffffffef29 42ffffffcf402b 6effffffb1ffffff921b , 10104, 4
[1:1:0712/010851.776351:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46641:46671:0712/010851.776625:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGq���)B�@+n��佁
[46641:46671:0712/010851.776693:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is q���)B�@+n���佁
[1:1:0712/010851.776631:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203e200a0, 3
[46641:46671:0712/010851.777170:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/010851.777148:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203fab080, 2
[46641:46671:0712/010851.777250:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46694, 4, 7106c212 fc12ef29 42cf402b 6eb1921b 
[1:1:0712/010851.777352:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71edc6ed20, -2
[1:1:0712/010851.800301:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010851.801203:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b40cf42
[1:1:0712/010851.802042:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b40cf42
[1:1:0712/010851.803357:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b40cf42
[1:1:0712/010851.804176:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.804329:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.804465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.804607:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.804967:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b40cf42
[1:1:0712/010851.805163:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010851.805277:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010851.807600:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b40cf42
[1:1:0712/010851.807854:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b40cf42
[1:1:0712/010851.808270:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b40cf42
[1:1:0712/010851.809319:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.809462:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.809694:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.809941:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b40cf42
[1:1:0712/010851.811494:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b40cf42
[1:1:0712/010851.811993:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010851.812189:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010851.821623:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010851.822152:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010851.822326:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd226803b8, 0x7ffd22680338)
[1:1:0712/010851.837336:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010851.842924:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[46641:46641:0712/010852.478386:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46641:46641:0712/010852.479815:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46641:46653:0712/010852.500493:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[46641:46653:0712/010852.500631:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[46641:46641:0712/010852.500674:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[46641:46641:0712/010852.500778:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[46641:46641:0712/010852.500961:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,46694, 4
[1:7:0712/010852.506157:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[46641:46665:0712/010852.513796:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/010852.622737:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x41c59c9220
[1:1:0712/010852.623050:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/010853.007022:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[46641:46641:0712/010854.713725:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[46641:46641:0712/010854.713842:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010854.721467:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010854.724825:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010855.912671:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010855.976158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010855.976659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010855.990915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/010855.991342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010856.335329:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010856.335700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010856.668486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010856.677094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010856.677556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010856.717725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010856.722701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/010856.722939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010856.734599:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/010856.737864:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x41c59c7e20
[1:1:0712/010856.738083:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[46641:46641:0712/010856.738709:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[46641:46641:0712/010856.748267:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[46641:46641:0712/010856.774471:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[46641:46641:0712/010856.774565:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/010856.838756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010857.743092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f71ef8492e0 0x41c5ad0d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010857.744593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/010857.744851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010857.746397:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[46641:46641:0712/010857.814133:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/010857.817004:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x41c59c8820
[1:1:0712/010857.817379:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[46641:46641:0712/010857.826947:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/010857.835830:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/010857.836185:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[46641:46641:0712/010857.851688:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[46641:46641:0712/010857.866445:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46641:46641:0712/010857.867772:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[46641:46653:0712/010857.875558:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[46641:46653:0712/010857.875664:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[46641:46641:0712/010857.875886:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[46641:46641:0712/010857.875991:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[46641:46641:0712/010857.876176:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,46694, 4
[1:7:0712/010857.891079:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010858.453475:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/010858.996351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7f71ef8492e0 0x41c5c04d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010858.997364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/010858.997620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010858.998371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[46641:46641:0712/010859.093827:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[46641:46641:0712/010859.093978:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/010859.124087:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[46641:46641:0712/010859.357647:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[46641:46671:0712/010859.358067:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/010859.358271:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010859.358509:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010859.358895:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010859.359030:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/010859.361609:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31c9076c, 1
[1:1:0712/010859.362002:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3f9c1d5a, 0
[1:1:0712/010859.362188:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2a313284, 3
[1:1:0712/010859.362368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x29262303, 2
[1:1:0712/010859.362562:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5a1dffffff9c3f 6c07ffffffc931 03232629 ffffff8432312a , 10104, 5
[1:1:0712/010859.363538:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46641:46671:0712/010859.363875:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGZ�?l�1#&)�21*Q��
[46641:46671:0712/010859.363947:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Z�?l�1#&)�21*�Q��
[1:1:0712/010859.363875:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203e200a0, 3
[46641:46671:0712/010859.364172:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46738, 5, 5a1d9c3f 6c07c931 03232629 8432312a 
[1:1:0712/010859.364121:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203fab080, 2
[1:1:0712/010859.364370:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71edc6ed20, -2
[1:1:0712/010859.385536:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010859.385920:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29262303
[1:1:0712/010859.386297:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29262303
[1:1:0712/010859.386976:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29262303
[1:1:0712/010859.388444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.388699:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.388918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.389132:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.389845:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29262303
[1:1:0712/010859.390165:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010859.390348:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010859.394301:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29262303
[1:1:0712/010859.394714:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29262303
[1:1:0712/010859.395465:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29262303
[1:1:0712/010859.398003:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.398277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.398512:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.398780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29262303
[1:1:0712/010859.400079:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29262303
[1:1:0712/010859.400480:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010859.400702:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010859.408551:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010859.409102:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010859.409291:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd226803b8, 0x7ffd22680338)
[1:1:0712/010859.429668:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010859.433994:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/010859.492143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010859.662223:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x41c5992220
[1:1:0712/010859.662472:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/010859.983985:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010859.984244:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[46641:46641:0712/010900.433839:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[46641:46641:0712/010900.457409:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[46641:46671:0712/010900.457750:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/010900.457985:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/010900.458166:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/010900.458539:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/010900.458682:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/010900.461828:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x4fc9a3d, 1
[1:1:0712/010900.462221:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x16fe0bdf, 0
[1:1:0712/010900.462468:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x33190d71, 3
[1:1:0712/010900.462668:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e42365f, 2
[1:1:0712/010900.462846:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdf0bfffffffe16 3dffffff9afffffffc04 5f36423e 710d1933 , 10104, 6
[1:1:0712/010900.464092:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[46641:46671:0712/010900.464417:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��=��_6B>q3<��
[46641:46671:0712/010900.464505:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��=��_6B>q3X�<��
[1:1:0712/010900.464642:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203e200a0, 3
[46641:46671:0712/010900.464779:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 46754, 6, df0bfe16 3d9afc04 5f36423e 710d1933 
[1:1:0712/010900.464863:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7203fab080, 2
[1:1:0712/010900.465078:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71edc6ed20, -2
[1:1:0712/010900.482138:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[46641:46641:0712/010900.482708:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/010900.486941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11609f98e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/010900.487280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010900.491547:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/010900.491892:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e42365f
[1:1:0712/010900.492212:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e42365f
[1:1:0712/010900.492778:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e42365f
[1:1:0712/010900.493301:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.493421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.493515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.493611:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.493835:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e42365f
[1:1:0712/010900.493980:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010900.494058:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010900.495496:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e42365f
[1:1:0712/010900.495069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010900.495647:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e42365f
[1:1:0712/010900.495904:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e42365f
[1:1:0712/010900.496580:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.496700:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.496793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.496884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e42365f
[1:1:0712/010900.497322:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e42365f
[1:1:0712/010900.497473:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7205be57ba
[1:1:0712/010900.497553:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7205bdcdef, 7f7205be577a, 7f7205be70cf
[1:1:0712/010900.499589:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/010900.499905:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/010900.500014:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd226803b8, 0x7ffd22680338)
[46641:46653:0712/010900.500577:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[46641:46653:0712/010900.500658:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[46641:46641:0712/010900.501265:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.bozhong.com/
[46641:46641:0712/010900.501365:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.bozhong.com/, https://www.bozhong.com/ivf/bbs/41590031, 1
[46641:46641:0712/010900.501547:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.bozhong.com/, HTTP/1.1 200 OK Server: openresty Date: Fri, 12 Jul 2019 08:09:00 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: MTap_315e_sid=IIVIcq; expires=Sat, 13-Jul-2019 08:09:00 GMT; path=/; domain=.bozhong.com Set-Cookie: MTap_315e_lastact=1562918940%09forum.php%09ivf_info; expires=Sat, 13-Jul-2019 08:09:00 GMT; path=/; domain=.bozhong.com Set-Cookie: MTap_315e_visitedfid=1929D2258D2156D2331D37D2150; expires=Sun, 11-Aug-2019 08:09:00 GMT; path=/; domain=.bozhong.com HIT: web-004 fromwww: yes Content-Encoding: gzip  ,0, 6
[3:3:0712/010900.506630:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/010900.512761:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/010900.516835:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/010900.641422:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/010900.816929:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x41c59c8220
[1:1:0712/010900.817213:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/010900.896655:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.bozhong.com/
[1:1:0712/010900.914820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/010900.915688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11609f861f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/010900.915941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/010901.043840:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[46641:46641:0712/010901.053648:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.bozhong.com/, https://www.bozhong.com/, 1
[46641:46641:0712/010901.053701:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.bozhong.com/, https://www.bozhong.com
[1:1:0712/010901.129270:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010901.210237:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/010901.287459:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010901.287701:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010901.475753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010901.477781:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/010901.477995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11609f98e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/010901.478282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010901.608462:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/010901.609528:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/010901.609858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11609f98e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/010901.616529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/010902.004605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.007081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , var STYLEID = '1', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = 'eC1', charset =
[1:1:0712/010902.007334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010902.018891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.021054:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010902.207436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.220389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.259447:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.331736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010902.367168:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7f71ed921070 0x41c5843ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010902.446003:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.435546, 481, 1
[1:1:0712/010902.446290:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010903.105411:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010903.105674:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.106497:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f71ed921070 0x41c5d182e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.107854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
                      // 兼容https，不用form形式，改成触发跳转搜索
                
[1:1:0712/010903.108080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010903.131337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f71ed921070 0x41c5d182e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.147116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f71ed921070 0x41c5d182e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.153414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f71ed921070 0x41c5d182e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.158861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 267 0x7f71ed921070 0x41c5d182e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010903.164886:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0590401, 81, 1
[1:1:0712/010903.165107:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010904.407684:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010904.407993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010904.408863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f71ed921070 0x41c5b54960 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010904.410013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
          var fromuid = document.getElementById("fromuid");
          var str = "";
          if(fr
[1:1:0712/010904.410237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010904.425079:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.016907, 63, 1
[1:1:0712/010904.425296:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010904.798944:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010904.799247:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010904.800194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 381 0x7f71ed921070 0x41c5b16060 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010904.801153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
function checkform(theform) {
if (theform.message.value.length > 200) {
alert('您的留言超过 2
[1:1:0712/010904.801372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010904.829957:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0305741, 275, 1
[1:1:0712/010904.830216:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010905.128900:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010905.129132:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010905.130000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 397 0x7f71ed921070 0x41c5cf4460 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010905.130862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
aimgcount[107379494] = ['1212750'];
attachimggroup(107379494);

[1:1:0712/010905.131041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010906.993495:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.86432, 0, 0
[1:1:0712/010906.993803:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010907.375785:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010907.376057:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010907.379767:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f71ed921070 0x41c5f24f60 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010907.380751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
	var $theme = jq('.theme_box');
	if($theme.length > 0){
		jq('#ooxx_59').show();
	}

[1:1:0712/010907.380973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010907.896223:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.520083, 479, 1
[1:1:0712/010907.896535:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.410334:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.410606:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.411479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f71ed921070 0x41c5e8b760 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.412486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
    //内容 链接 新窗口
    jq('.t_f a').each(function(){
        jq(this).attr("target", "_b
[1:1:0712/010908.412719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010908.439349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f71ed921070 0x41c5e8b760 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.446124:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0353591, 61, 1
[1:1:0712/010908.446375:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.779307:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.779607:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.783198:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f71ed921070 0x41c5f24b60 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.784825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , /*
    [Discuz!] (C)2001-2009 Comsenz Inc.
    This is NOT a freeware, use is subject to license t
[1:1:0712/010908.785088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010908.790008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f71ed921070 0x41c5f24b60 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.799237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f71ed921070 0x41c5f24b60 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.803815:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0240519, 56, 1
[1:1:0712/010908.804058:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.944624:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010908.944902:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.945810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f71ed921070 0x41c5ec8e60 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010908.946690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 


        new lazyload();

        
[1:1:0712/010908.946909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010909.599872:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010909.600405:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010909.600796:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010909.601143:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010909.601484:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010909.657503:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.712448, 0, 0
[1:1:0712/010909.657769:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010910.000123:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010910.000449:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.001598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f71ed921070 0x41c5be6de0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.002550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , document.onkeyup = function(e){keyPageScroll(e, 0, 0, '$/forum.php?mod=viewthread&tid=41590031', 1);
[1:1:0712/010910.002759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010910.005305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f71ed921070 0x41c5be6de0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.008942:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f71ed921070 0x41c5be6de0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.037628:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0370691, 149, 1
[1:1:0712/010910.037891:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010910.646088:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010910.646372:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.652700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7f71ed921070 0x41c55aa360 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010910.653770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
		//姐妹都在抢下线
		/*jQuery.ajax({
            url:'//mall.bozhong.com/openapi/other/get_r
[1:1:0712/010910.653994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010910.689423:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0428391, 86, 1
[1:1:0712/010910.689696:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010911.107633:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010911.107886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.108764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7f71ed921070 0x41c5ee7460 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.109669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
        var fid = 1929;
    var tid = 41590031;
    var isAdmin =  0;

[1:1:0712/010911.109887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010911.113024:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7f71ed921070 0x41c5ee7460 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.122155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7f71ed921070 0x41c5ee7460 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.174281:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0662861, 303, 1
[1:1:0712/010911.174559:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010911.519495:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010911.519801:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.520678:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f71ed921070 0x41c5ee9060 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.521991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
    seajs.use('url/1.2.0/url',function(Url){
      var url = new Url(window.location.href);
      i
[1:1:0712/010911.522218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010911.542291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f71ed921070 0x41c5ee9060 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.555970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f71ed921070 0x41c5ee9060 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010911.828277:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.308352, 59, 1
[1:1:0712/010911.828553:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/010911.863054:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010912.346614:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/010912.346886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.347752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.348707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
    seajs.use('//source.bozhong.com/common/js/modules/zhuanjia_tk.js');

[1:1:0712/010912.348949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010912.362416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.385703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.409081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.421707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.429606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
		remove user.10_417fee7e -> 0
[1:1:0712/010912.437033:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x389653a429c8, 0x41c58331a8
[1:1:0712/010912.437295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 250
[1:1:0712/010912.437711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 604
[1:1:0712/010912.437981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f71ed921070 0x41c5b216e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 564 0x7f71ed921070 0x41c5b541e0 
[1:1:0712/010912.439698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c58331a8
[1:1:0712/010912.439925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010912.440314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 605
[1:1:0712/010912.440535:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7f71ed921070 0x41c5ee46e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 564 0x7f71ed921070 0x41c5b541e0 
[1:1:0712/010912.443593:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.456873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f71ed921070 0x41c5b541e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010912.471630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010913.399141:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 571 0x7f71ef8492e0 0x41c5b00de0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010913.404040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , (function(){var h={},mt={},c={id:"efd66f9ff45e06146515d4b6339faee9",dm:["www.bozhong.com/ivf"],js:"t
[1:1:0712/010913.404318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010913.434290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833190
[1:1:0712/010913.434571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010913.434999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 648
[1:1:0712/010913.435261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f71ed921070 0x41c66cf9e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 571 0x7f71ef8492e0 0x41c5b00de0 
[46641:46641:0712/010915.255081:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/010915.266226:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/010915.490895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 572 0x7f71ef8492e0 0x41c538a6e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010915.494078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , (function(){var h={},mt={},c={id:"587d9cbce5b7f554283d493c9be28ea7",dm:["bozhong.com"],js:"tongji.ba
[1:1:0712/010915.494330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010915.512685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833190
[1:1:0712/010915.512974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010915.513410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 695
[1:1:0712/010915.513666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f71ed921070 0x41c66d0460 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 572 0x7f71ef8492e0 0x41c538a6e0 
[1:1:0712/010915.640762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f71ef8492e0 0x41c5aad1e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010915.641880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("url/1.2.0/url",[],function(t,r,e){function s(t){var r="=",e="&",s={};if(!t)return s;t=t.repl
[1:1:0712/010915.642093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010915.646846:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010916.803332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 605, 7f71f0266881
[1:1:0712/010916.817614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"564 0x7f71ed921070 0x41c5b541e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010916.818047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"564 0x7f71ed921070 0x41c5b541e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010916.818442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010916.819058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , () {
				aj.XMLHttpRequest.open('GET', aj.targetUrl);
				aj.XMLHttpRequest.setRequestHeader('X-Re
[1:1:0712/010916.819275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010916.820226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010916.824535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 604, 7f71f0266881
[1:1:0712/010916.861373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"564 0x7f71ed921070 0x41c5b541e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010916.861767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"564 0x7f71ed921070 0x41c5b541e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010916.862287:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010916.862948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , () {
			aj.showLoading()
		}
[1:1:0712/010916.863171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010917.085658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/010917.085963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010918.420881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 648, 7f71f0266881
[1:1:0712/010918.435808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"571 0x7f71ef8492e0 0x41c5b00de0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010918.436008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"571 0x7f71ef8492e0 0x41c5b00de0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010918.436201:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010918.436560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010918.436669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010918.437036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010918.437134:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010918.437339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 765
[1:1:0712/010918.437476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 765 0x7f71ed921070 0x41c6998760 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 648 0x7f71ed921070 0x41c66cf9e0 
[1:1:0712/010918.901694:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 695, 7f71f0266881
[1:1:0712/010918.922866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"572 0x7f71ef8492e0 0x41c538a6e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010918.923055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"572 0x7f71ef8492e0 0x41c538a6e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010918.923287:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010918.923700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010918.923854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010918.924230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010918.924326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010918.924522:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 779
[1:1:0712/010918.924637:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 779 0x7f71ed921070 0x41c69ba460 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 695 0x7f71ed921070 0x41c66d0460 
[1:1:0712/010919.088947:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7f71ef8492e0 0x41c5eeb460 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.090101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define(function(require, exports, module){
	var $ = require('jquery');
	//api
	var APICore = require
[1:1:0712/010919.090290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010919.114914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.259286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f71ef8492e0 0x41c5be80e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.262503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define(function(require, exports, module) {
    var $ = require('jquery');
    var Config = requir
[1:1:0712/010919.262776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010919.420202:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.597996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7f71ef8492e0 0x41c5ed58e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.601695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , (function(){var h={},mt={},c={id:"eedfd92e702130c0d16faddde1fc2cd6",dm:["bbs.bozhong.com"],js:"tongj
[1:1:0712/010919.601905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010919.621959:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833188
[1:1:0712/010919.622129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010919.622315:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 810
[1:1:0712/010919.622435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7f71ed921070 0x41c69b1c60 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 723 0x7f71ef8492e0 0x41c5ed58e0 
[1:1:0712/010919.710494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 724 0x7f71ef8492e0 0x41c5844560 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010919.717022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/010919.717255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010920.312249:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 727 0x7f71ef8492e0 0x41c5d184e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010920.315475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , /*!
 * Third Party Scripts v0.1.0 (https://github.com/unclay/third-party-scripts)
 * Clone at 2017-1
[1:1:0712/010920.315753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010920.358562:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c58331c8
[1:1:0712/010920.358720:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010920.358937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 882
[1:1:0712/010920.359058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f71ed921070 0x41c69780e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 727 0x7f71ef8492e0 0x41c5d184e0 
[1:1:0712/010920.365363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c58331c8
[1:1:0712/010920.365518:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010920.365707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 883
[1:1:0712/010920.365819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 883 0x7f71ed921070 0x41c5be8c60 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 727 0x7f71ef8492e0 0x41c5d184e0 
[1:1:0712/010920.369683:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x389653a429c8, 0x41c58331c8
[1:1:0712/010920.369814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 3000
[1:1:0712/010920.370022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 884
[1:1:0712/010920.370136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f71ed921070 0x41c6baafe0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 727 0x7f71ef8492e0 0x41c5d184e0 
[1:1:0712/010920.443471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7f71ef8492e0 0x41c55a7560 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010920.445451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define(function(require,exports,module){function loadingImg(){$(".categoryList").children(".tab_main
[1:1:0712/010920.445588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010920.452980:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010920.453399:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/010920.743352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010921.761473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , document.readyState
[1:1:0712/010921.761726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010922.374315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 765, 7f71f0266881
[1:1:0712/010922.414220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"648 0x7f71ed921070 0x41c66cf9e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010922.414445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"648 0x7f71ed921070 0x41c66cf9e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010922.414715:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010922.415064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010922.415203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010922.415648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010922.415786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010922.415980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 962
[1:1:0712/010922.416097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f71ed921070 0x41c70d6ee0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 765 0x7f71ed921070 0x41c6998760 
[1:1:0712/010922.469446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010922.469897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/010922.470041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010922.798789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010922.799552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/010922.799755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010922.808054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 779, 7f71f0266881
[1:1:0712/010922.844993:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"695 0x7f71ed921070 0x41c66d0460 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010922.845210:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"695 0x7f71ed921070 0x41c66d0460 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010922.845515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010922.846220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010922.846462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010922.847335:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010922.847578:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010922.848031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1005
[1:1:0712/010922.848267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7f71ed921070 0x41c55e6f60 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 779 0x7f71ed921070 0x41c69ba460 
[1:1:0712/010926.763908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 810, 7f71f0266881
[1:1:0712/010926.811279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"723 0x7f71ef8492e0 0x41c5ed58e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010926.811746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"723 0x7f71ef8492e0 0x41c5ed58e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010926.812264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010926.813003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010926.813231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010926.814106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010926.814275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010926.814674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1363
[1:1:0712/010926.814878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1363 0x7f71ed921070 0x41c7bc2ae0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 810 0x7f71ed921070 0x41c69b1c60 
[1:1:0712/010927.486659:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 892 0x7f71ef8492e0 0x41c5eebae0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010927.487264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("seedit-config/0.1.3/index",[],function(t,o,e){function n(t){return t=t||document.location.ho
[1:1:0712/010927.487401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010927.489194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010927.576819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 893 0x7f71ef8492e0 0x41c6385960 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010927.577405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("seedit-user/0.0.7/index",["seedit-api/0.0.6/index","seedit-config/0.1.3/index","query-string
[1:1:0712/010927.577572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010927.581063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010929.551582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , document.readyState
[1:1:0712/010929.551957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010929.615957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010929.616985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , Ajax.aj.processHandle, () {
		if (aj.XMLHttpRequest.readyState == 4 && aj.XMLHttpRequest.status == 200) {
			for (k in AJ
[1:1:0712/010929.617281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010929.618128:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010933.128144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 962, 7f71f0266881
[1:1:0712/010933.220068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"765 0x7f71ed921070 0x41c6998760 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010933.220481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"765 0x7f71ed921070 0x41c6998760 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010933.220964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010933.221815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010933.222103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010933.222997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010933.223225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010933.223694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1689
[1:1:0712/010933.223947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1689 0x7f71ed921070 0x41c7f9fbe0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 962 0x7f71ed921070 0x41c70d6ee0 
[1:1:0712/010935.987439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1015 0x7f71ef8492e0 0x41c71771e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010935.989106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("import-style/1.0.0/index",[],function(e,t,n){function l(e,t){if(!t||(t=t.replace(d,"-"),!m.g
[1:1:0712/010935.989363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010935.994707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010936.067402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1016 0x7f71ef8492e0 0x41c71776e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010936.068171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("seedit-nav/1.2.0/index",[],function(a,s){var e=function(a){return a.replace(/<\?=RIJI_SEEDIT
[1:1:0712/010936.068316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010936.078699:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010936.164578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1005, 7f71f0266881
[1:1:0712/010936.243047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"779 0x7f71ed921070 0x41c69ba460 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010936.243376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"779 0x7f71ed921070 0x41c69ba460 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010936.243826:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010936.244516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/010936.244710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010936.245454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833150
[1:1:0712/010936.245614:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010936.246020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1791
[1:1:0712/010936.246215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1791 0x7f71ed921070 0x41c7ac0760 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1005 0x7f71ed921070 0x41c55e6f60 
[1:1:0712/010936.731047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1023 0x7f71ef8492e0 0x41c7177ee0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010936.734310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , window.Messenger=function(){function a(a,b){var c="";if(arguments.length<2?c="target error - target 
[1:1:0712/010936.734453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010936.766089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
		remove user.11_805d8f5c -> 0
		remove user.12_422bb385 -> 0
[1:1:0712/010936.960417:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x389653a429c8, 0x41c5833210
[1:1:0712/010936.960706:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 0
[1:1:0712/010936.961205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1821
[1:1:0712/010936.961466:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1821 0x7f71ed921070 0x41c699e5e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010937.015396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 13
[1:1:0712/010937.015962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.bozhong.com/, 1823
[1:1:0712/010937.016266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1823 0x7f71ed921070 0x41c5358460 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010937.059753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x389653a429c8, 0x41c5833210
[1:1:0712/010937.059942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 2000
[1:1:0712/010937.060243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1826
[1:1:0712/010937.060369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1826 0x7f71ed921070 0x41c7f5fb60 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010937.065198:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x389653a429c8, 0x41c5833210
[1:1:0712/010937.065350:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 2000
[1:1:0712/010937.065544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1827
[1:1:0712/010937.065655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1827 0x7f71ed921070 0x41c69c5fe0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010937.091467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x389653a429c8, 0x41c5833210
[1:1:0712/010937.091650:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 100
[1:1:0712/010937.091848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1828
[1:1:0712/010937.091964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1828 0x7f71ed921070 0x41c5f24ce0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[46641:46641:0712/010937.095626:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/010937.591490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x389653a429c8, 0x41c5833210
[1:1:0712/010937.591728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 300
[1:1:0712/010937.592112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1852
[1:1:0712/010937.592385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1852 0x7f71ed921070 0x41c625a3e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010939.493769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x389653a429c8, 0x41c5833210
[1:1:0712/010939.493949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 0
[1:1:0712/010939.494143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1903
[1:1:0712/010939.494257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1903 0x7f71ed921070 0x41c5ed5860 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
[1:1:0712/010939.809673:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x389653a429c8, 0x41c5833210
[1:1:0712/010939.809915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 800
[1:1:0712/010939.810194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1917
[1:1:0712/010939.810350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1917 0x7f71ed921070 0x41c7ac01e0 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1023 0x7f71ef8492e0 0x41c7177ee0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/010940.005705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1024 0x7f71ef8492e0 0x41c71746e0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010940.006545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , /*!
 * Third Party Scripts v0.1.0 (https://github.com/unclay/third-party-scripts)
 * Clone at 2017-1
[1:1:0712/010940.006718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010940.021234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c5833190
[1:1:0712/010940.021413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010940.021604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1935
[1:1:0712/010940.021723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1935 0x7f71ed921070 0x41c6baa060 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1024 0x7f71ef8492e0 0x41c71746e0 
[1:1:0712/010940.048953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c5833190
[1:1:0712/010940.049179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010940.049555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1938
[1:1:0712/010940.049750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1938 0x7f71ed921070 0x41c5e8b160 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1024 0x7f71ef8492e0 0x41c71746e0 
[1:1:0712/010940.055450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010940.746327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1031 0x7f71ef8492e0 0x41c64d1de0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010940.747685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , /*!
 * Third Party Scripts v0.1.0 (https://github.com/unclay/third-party-scripts)
 * Clone at 2017-1
[1:1:0712/010940.747958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010940.785568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c5833190
[1:1:0712/010940.785794:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010940.786207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 1968
[1:1:0712/010940.786405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1968 0x7f71ed921070 0x41c5ecf660 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 1031 0x7f71ef8492e0 0x41c64d1de0 
[1:1:0712/010940.793539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010940.862780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1032 0x7f71ef8492e0 0x41c7177be0 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010940.863930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("seedit-oncetip/0.0.1/index",["cookie-store/0.0.9/index","seedit-config/0.1.1/index","jquery/
[1:1:0712/010940.864262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010940.868840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010942.087473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1046 0x7f71ef8492e0 0x41c79ac860 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010942.088866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define("pager/1.1.3/index",["jquery/1.8.3/jquery","eventor/0.0.3/events"],function(t,i,e){e.exports=
[1:1:0712/010942.089146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010942.098350:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010942.247084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1047 0x7f71ef8492e0 0x41c79b1160 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010942.251099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , 
define(function(require, exports, module){
    var $ = require('jquery');
    var Eventor = requ
[1:1:0712/010942.251365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010942.402101:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010943.223275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1057 0x7f71ef8492e0 0x41c79ab160 , "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010943.229012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , define(function(require, exports, module) {
    //require api
    var $ = require('jquery');
    
[1:1:0712/010943.229253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010943.319274:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[46641:46641:0712/010943.753178:INFO:CONSOLE(13)] "Uncaught TypeError: Cannot read property 'slice' of undefined", source: https://scdn.bozhong.com/source/bbs/js/bbs_v3.min.js?eC1 (13)
[1:1:0712/010944.411397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 884, 7f71f0266881
[1:1:0712/010944.469589:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2acdf67e2860","ptid":"727 0x7f71ef8492e0 0x41c5d184e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010944.469794:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.bozhong.com/","ptid":"727 0x7f71ef8492e0 0x41c5d184e0 ","rf":"6:3_https://www.bozhong.com/"}
[1:1:0712/010944.470075:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010944.470438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/010944.470573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
[1:1:0712/010944.474957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x389653a429c8, 0x41c5833150
[1:1:0712/010944.475100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.bozhong.com/ivf/bbs/41590031", 15000
[1:1:0712/010944.475299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.bozhong.com/, 2118
[1:1:0712/010944.475423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2118 0x7f71ed921070 0x41c70e5a60 , 6:3_https://www.bozhong.com/, 1, -6:3_https://www.bozhong.com/, 884 0x7f71ed921070 0x41c6baafe0 
[1:1:0712/010950.141225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.bozhong.com/ivf/bbs/41590031"
[1:1:0712/010950.141984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.bozhong.com/, 2acdf67e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/010950.142183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.bozhong.com/ivf/bbs/41590031", "www.bozhong.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
[46641:46641:0712/011000.534408:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
