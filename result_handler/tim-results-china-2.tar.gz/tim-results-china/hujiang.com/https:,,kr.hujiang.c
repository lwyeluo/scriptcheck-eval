[0711/205027.555342:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205027.555639:INFO:switcher_clone.cc(787)] backtrace rip is 7fd8bc83d891
[0711/205028.480510:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205028.480788:INFO:switcher_clone.cc(787)] backtrace rip is 7efd3f248891
[1:1:0711/205028.484785:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/205028.484960:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/205028.489619:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[12317:12317:0711/205029.492337:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/26ec2cfd-ced2-47e7-a7a5-5faea5e1f511
[0711/205029.960413:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/205029.960893:INFO:switcher_clone.cc(787)] backtrace rip is 7f09f69cb891
[12317:12317:0711/205029.985538:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[12317:12347:0711/205029.986325:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/205029.986558:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/205029.986835:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/205029.987544:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/205029.987811:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/205029.991195:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x21efde2, 1
[1:1:0711/205029.991574:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xcea2aaa, 0
[1:1:0711/205029.991804:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f7041ef, 3
[1:1:0711/205029.991994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2027f305, 2
[1:1:0711/205029.992224:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffaa2affffffea0c ffffffe2fffffffd1e02 05fffffff32720 ffffffef41701f , 10104, 4
[1:1:0711/205029.993402:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12317:12347:0711/205029.993636:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�*����' �Ap�."
[12317:12347:0711/205029.993759:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �*����' �Ap�d�."
[12317:12347:0711/205029.994072:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[12317:12347:0711/205029.994165:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12362, 4, aa2aea0c e2fd1e02 05f32720 ef41701f 
[1:1:0711/205029.994694:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd3d4830a0, 3
[1:1:0711/205029.994944:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd3d60e080, 2
[1:1:0711/205029.995151:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd272d1d20, -2
[1:1:0711/205030.015959:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/205030.017025:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2027f305
[1:1:0711/205030.018152:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2027f305
[1:1:0711/205030.020060:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2027f305
[1:1:0711/205030.021890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.022142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.022366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.022585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.023364:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2027f305
[1:1:0711/205030.023823:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efd3f2487ba
[1:1:0711/205030.023990:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efd3f23fdef, 7efd3f24877a, 7efd3f24a0cf
[1:1:0711/205030.029982:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2027f305
[1:1:0711/205030.030365:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2027f305
[1:1:0711/205030.031113:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2027f305
[1:1:0711/205030.033763:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.034066:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.034333:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.034592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2027f305
[1:1:0711/205030.036223:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2027f305
[1:1:0711/205030.036679:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efd3f2487ba
[1:1:0711/205030.036877:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efd3f23fdef, 7efd3f24877a, 7efd3f24a0cf
[1:1:0711/205030.042274:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/205030.042635:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/205030.042763:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe6a5e20e8, 0x7ffe6a5e2068)
[1:1:0711/205030.057904:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/205030.064505:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[12349:12349:0711/205030.182087:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12349
[12376:12376:0711/205030.182566:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=12376
[12317:12317:0711/205030.585793:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12317:12317:0711/205030.587186:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12317:12328:0711/205030.609606:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[12317:12328:0711/205030.609700:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[12317:12317:0711/205030.609943:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[12317:12317:0711/205030.610041:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[12317:12317:0711/205030.610223:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,12362, 4
[1:7:0711/205030.615536:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[12317:12340:0711/205030.634657:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/205030.714663:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x29bbbb575220
[1:1:0711/205030.715025:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/205030.980425:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[12317:12317:0711/205032.685803:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[12317:12317:0711/205032.685923:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/205032.723363:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205032.726840:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/205033.811316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/205033.811625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205033.844656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/205033.845000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205033.890452:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205034.176856:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205034.177177:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205034.480559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205034.488928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/205034.489175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205034.522805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205034.526562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/205034.526802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205034.538930:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[12317:12317:0711/205034.541235:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/205034.542853:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x29bbbb573e20
[1:1:0711/205034.543113:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[12317:12317:0711/205034.548899:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[12317:12317:0711/205034.573066:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[12317:12317:0711/205034.573246:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/205034.622314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205035.122487:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7efd28eac2e0 0x29bbbb57c3e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205035.123820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/205035.124021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205035.125619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205035.204850:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x29bbbb574820
[1:1:0711/205035.204997:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[12317:12317:0711/205035.205720:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/205035.211252:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/205035.211393:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[12317:12317:0711/205035.222975:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[12317:12317:0711/205035.241328:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[12317:12317:0711/205035.247262:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12317:12317:0711/205035.247975:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12317:12328:0711/205035.249617:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[12317:12328:0711/205035.249660:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[12317:12317:0711/205035.251139:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[12317:12317:0711/205035.251183:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[12317:12317:0711/205035.251236:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,12362, 4
[1:7:0711/205035.252030:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/205035.810716:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/205036.197853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7efd28eac2e0 0x29bbbb788260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205036.199057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/205036.199319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/205036.200073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[12317:12317:0711/205036.321105:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[12317:12317:0711/205036.321224:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/205036.321750:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/205036.568160:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205036.912239:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205036.912525:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205037.228539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 534, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205037.233211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/205037.233484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205037.238886:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205037.517516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/205037.518283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17512d861f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/205037.518466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[12317:12317:0711/205037.675286:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[12317:12347:0711/205037.675808:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/205037.676014:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/205037.676216:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/205037.676589:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/205037.676761:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/205037.679178:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x101b629b, 1
[1:1:0711/205037.679512:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x308b2bcd, 0
[1:1:0711/205037.679786:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5a2430, 3
[1:1:0711/205037.680009:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x12a72217, 2
[1:1:0711/205037.680184:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcd2bffffff8b30 ffffff9b621b10 1722ffffffa712 30245a00 , 10104, 5
[1:1:0711/205037.681092:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[12317:12347:0711/205037.681356:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�+�0�b"�0$Z
[12317:12347:0711/205037.681425:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �+�0�b"�0$Z
[1:1:0711/205037.681352:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd3d4830a0, 3
[12317:12347:0711/205037.681727:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12413, 5, cd2b8b30 9b621b10 1722a712 30245a00 
[1:1:0711/205037.681659:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd3d60e080, 2
[1:1:0711/205037.682093:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7efd272d1d20, -2
[1:1:0711/205037.702512:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/205037.702896:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12a72217
[1:1:0711/205037.703252:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12a72217
[1:1:0711/205037.704005:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12a72217
[1:1:0711/205037.705454:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.705683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.705918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.706130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.706876:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12a72217
[1:1:0711/205037.707199:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efd3f2487ba
[1:1:0711/205037.707368:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efd3f23fdef, 7efd3f24877a, 7efd3f24a0cf
[1:1:0711/205037.713728:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 12a72217
[1:1:0711/205037.714144:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 12a72217
[1:1:0711/205037.714935:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 12a72217
[1:1:0711/205037.717487:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.717775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.718003:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.718229:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 12a72217
[1:1:0711/205037.719528:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 12a72217
[1:1:0711/205037.719972:INFO:switcher_clone.cc(775)] clone wrapper rip is 7efd3f2487ba
[1:1:0711/205037.720142:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7efd3f23fdef, 7efd3f24877a, 7efd3f24a0cf
[1:1:0711/205037.728405:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/205037.729040:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/205037.729256:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe6a5e20e8, 0x7ffe6a5e2068)
[1:1:0711/205037.743194:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/205037.745798:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/205037.769878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205037.771616:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/205037.771912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/205037.772175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205037.897808:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205037.920878:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/205037.921114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/205037.921431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205037.958746:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x29bbbb538220
[1:1:0711/205037.959070:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/205038.768997:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0711/205038.833851:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/205038.902354:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/205039.019957:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/205039.092110:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/205039.137431:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/205039.205244:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/205039.269704:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/205039.636835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205039.637820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205039.638099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205039.671464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205039.672421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205039.672699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205039.745674:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205039.746618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205039.746903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[12317:12317:0711/205039.750250:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[12317:12317:0711/205039.757527:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[12317:12328:0711/205039.778155:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[12317:12328:0711/205039.778270:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[12317:12317:0711/205039.778868:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://kr.hujiang.com/
[12317:12317:0711/205039.778969:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kr.hujiang.com/, https://kr.hujiang.com/zt/shishang/, 1
[12317:12317:0711/205039.779145:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://kr.hujiang.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 03:50:39 GMT content-type:text/html; charset=utf-8 content-length:8688 server-node:20.20.154 etag:"caaa-eNjh0unbmGBKIdWsKv96qh4f0hc" content-encoding:gzip x-in-apigateway:bx-61/75 x-in-waf:BX-06/021 server:SSL-API-GATEWAY/1.0 x-in-ssl-apigateway:bx-128 x-via:1.1 PSshzk2hi198:5 (Cdn Cache Server V2.0)  ,12413, 5
[1:7:0711/205039.786047:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/205039.817721:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://kr.hujiang.com/
[1:1:0711/205039.905108:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205039.906073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205039.906600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[12317:12317:0711/205039.972213:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kr.hujiang.com/, https://kr.hujiang.com/, 1
[12317:12317:0711/205039.972362:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://kr.hujiang.com/, https://kr.hujiang.com
[1:1:0711/205039.977507:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205039.978535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205039.978806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.018880:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/205040.126411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.127351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205040.127628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.166986:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205040.227866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.228830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205040.229110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.271150:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205040.271460:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205040.288930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.289653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205040.289922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.356073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7efd26f84070 0x29bbbb579560 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205040.358647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , 
            var _gentian = {
                start_time: +new Date,
                project: '1000'
[1:1:0711/205040.358976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205040.363258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7efd26f84070 0x29bbbb579560 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205040.419750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.420786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205040.421132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.477877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.478803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205040.479087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.575954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.577126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205040.577484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.581135:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.309634, 1132, 1
[1:1:0711/205040.581562:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205040.617373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.618316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205040.618620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.758961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.759892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205040.760169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.863348:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.864780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205040.865106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205040.931363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205040.932316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/205040.932626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/205041.006391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/205041.007359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17512d98e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/205041.007699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/205041.582849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205041.583135:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205041.584025:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7efd26f84070 0x29bbbb735b60 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205041.584999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , 
        this.CUR_DATA = {
            user: {
                id: 0,
                name: ''
     
[1:1:0711/205041.585252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205042.183030:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205043.530363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7efd272ecbd0 0x29bbbb71ad58 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205043.541850:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205043.550127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , /*!
 * jQuery JavaScript Library v1.8.3
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://siz
[1:1:0711/205043.550425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205043.830330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7efd272ecbd0 0x29bbbb71ad58 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205043.854760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7efd272ecbd0 0x29bbbb71ad58 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205043.889841:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7efd272ecbd0 0x29bbbb71ad58 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.505440:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.678682, 0, 0
[1:1:0711/205044.505753:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/205044.848506:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.850696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , callback, ( _, isAbort ) {

						var status,
							statusText,
							responseHeaders,
							responses,
			
[1:1:0711/205044.851248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205044.852850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.855416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.856217:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1ee326ef5238
[1:1:0711/205044.963691:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/205044.963919:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.967073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363 0x7efd26f84070 0x29bbbb614360 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205044.969109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , !function(n,e,t,c){var o=Math.round(+new Date/864e5),a=/^https?:$/.test(location.protocol)&&location
[1:1:0711/205044.969304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205044.991950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363 0x7efd26f84070 0x29bbbb614360 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205045.029142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205047.571200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205047.969107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 381 0x7efd28eac2e0 0x29bbbb73b3e0 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205047.970218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , jQuery18309175431303534192_1562903443782({"hjclass":[{"classid":19397113,"classname":"延世韩国�
[1:1:0711/205047.970453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205047.971640:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205048.006895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7efd28eac2e0 0x29bbbb675b60 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205048.007793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , jQuery18309175431303534192_1562903443783({"data":null,"message":"资源不存在","status":-40400,"t
[1:1:0711/205048.008042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205048.008878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205048.223290:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205048.227118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205048.227638:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205048.228002:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205048.228327:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205048.799049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7efd28eac2e0 0x29bbbb7385e0 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205048.800871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==type
[1:1:0711/205048.800984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
		remove user.10_3445cbb5 -> 0
		remove user.11_6bfcc95f -> 0
		remove user.12_c84bf2 -> 0
		remove user.13_6f941074 -> 0
		remove user.14_4d84aaa2 -> 0
[1:1:0711/205051.383474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7efd28eac2e0 0x29bbbb548a60 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205051.384341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , 
[1:1:0711/205051.384557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[12317:12317:0711/205051.896526:INFO:CONSOLE(332)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2017/01/17/0e9e4ff528dd76d78e7b07dc5e5ebe9f.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (332)
[12317:12317:0711/205051.900144:INFO:CONSOLE(466)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2017/01/17/02df06a60b0762cb092b7abb1bb94f71.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (466)
[12317:12317:0711/205051.902699:INFO:CONSOLE(475)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2017/01/17/2f1d111d113a78a4960d0588904f34e4.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (475)
[12317:12317:0711/205051.903987:INFO:CONSOLE(484)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2017/01/17/94f0333838c77c83ff4d4aaa891df814.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (484)
[12317:12317:0711/205051.912771:INFO:CONSOLE(612)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2016/10/10/8f944781d652bcf74d80f06bb2a72c69.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (612)
[12317:12317:0711/205051.920440:INFO:CONSOLE(747)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2016/09/08/f19bb2b5049933dd394d3a3290b9c894.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (747)
[12317:12317:0711/205051.929088:INFO:CONSOLE(791)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://i2.w.hjfile.cn/news/201504/201504234510965379.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (791)
[12317:12317:0711/205051.934110:INFO:CONSOLE(802)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://n1image.hjfile.cn/mh/2016/10/21/cb1687b0d4475796042bc1ea7b93b1b3.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (802)
[12317:12317:0711/205051.935478:INFO:CONSOLE(824)] "Mixed Content: The page at 'https://kr.hujiang.com/zt/shishang/' was loaded over HTTPS, but requested an insecure image 'http://i2.w.hjfile.cn/news/201504/201504243513973089.jpg'. This content should also be served over HTTPS.", source: https://kr.hujiang.com/zt/shishang/ (824)
[3:3:0711/205052.098867:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[12317:12317:0711/205052.099305:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/205052.473486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205052.474293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , S.onreadystatechange, (){var e=void 0,t=void 0,n=void 0;if(S.readyState===i.DONE){if(t=S.status,n=S.statusText,e=S.respons
[1:1:0711/205052.474523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205052.475727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205052.573040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/205052.573396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205052.740931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205052.741695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , S.onreadystatechange, (){var e=void 0,t=void 0,n=void 0;if(S.readyState===i.DONE){if(t=S.status,n=S.statusText,e=S.respons
[1:1:0711/205052.741930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205052.742431:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205052.745268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205054.173682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205054.174011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205056.099496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205056.099784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205056.472188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205056.472531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205056.785768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205056.786198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205056.869010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205056.869299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205056.972355:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 588 0x7efd28eac2e0 0x29bbbce0bf60 , "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205057.024832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={i:i,l:!1,exports:{}};return e[i].
[1:1:0711/205057.025151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205057.040995:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205057.041985:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/205058.448728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205058.468864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1181510c29c8, 0x29bbbb0c3210
[1:1:0711/205058.469145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kr.hujiang.com/zt/shishang/", 0
[1:1:0711/205058.469534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kr.hujiang.com/, 613
[1:1:0711/205058.469754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7efd26f84070 0x29bbbce09660 , 5:3_https://kr.hujiang.com/, 1, -5:3_https://kr.hujiang.com/, 588 0x7efd28eac2e0 0x29bbbce0bf60 
[1:1:0711/205058.539302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205058.539468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205058.926439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205058.927148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&r(+n.data.slice(t.length))}
[1:1:0711/205058.927280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205059.074093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205059.074348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205059.108026:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kr.hujiang.com/, 613, 7efd298c9881
[1:1:0711/205059.135838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0162a2322860","ptid":"588 0x7efd28eac2e0 0x29bbbce0bf60 ","rf":"5:3_https://kr.hujiang.com/"}
[1:1:0711/205059.136141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kr.hujiang.com/","ptid":"588 0x7efd28eac2e0 0x29bbbce0bf60 ","rf":"5:3_https://kr.hujiang.com/"}
[1:1:0711/205059.136522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205059.137060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , (){e.fire("PageShow",{version:"v1.0.5@741"+(y.default.isWeixin?"-wx":"")})}
[1:1:0711/205059.137253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205100.595983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205100.596421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , ready, ( wait ) {

		// Abort if there are pending holds or we're already ready
		if ( wait === true ? --jQ
[1:1:0711/205100.596536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205100.596797:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205100.632670:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1181510c29c8, 0x29bbbb0c31f0
[1:1:0711/205100.632840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kr.hujiang.com/zt/shishang/", 0
[1:1:0711/205100.633035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kr.hujiang.com/, 654
[1:1:0711/205100.633159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7efd26f84070 0x29bbbd9fb560 , 5:3_https://kr.hujiang.com/, 1, -5:3_https://kr.hujiang.com/, 637 0x7efd28eac2e0 0x29bbbb72d360 
[1:1:0711/205100.655115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , document.readyState
[1:1:0711/205100.655279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205100.767787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205100.768183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , S.onreadystatechange, (){var e=void 0,t=void 0,n=void 0;if(S.readyState===i.DONE){if(t=S.status,n=S.statusText,e=S.respons
[1:1:0711/205100.768291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
[1:1:0711/205100.768478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205100.887655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kr.hujiang.com/, 654, 7efd298c9881
[1:1:0711/205100.915572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0162a2322860","ptid":"637 0x7efd28eac2e0 0x29bbbb72d360 ","rf":"5:3_https://kr.hujiang.com/"}
[1:1:0711/205100.915987:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kr.hujiang.com/","ptid":"637 0x7efd28eac2e0 0x29bbbb72d360 ","rf":"5:3_https://kr.hujiang.com/"}
[1:1:0711/205100.916339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kr.hujiang.com/zt/shishang/"
[1:1:0711/205100.916888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kr.hujiang.com/, 0162a2322860, , , (){var e=new Image(1,1);e.src=i,i=null}
[1:1:0711/205100.917066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kr.hujiang.com/zt/shishang/", "kr.hujiang.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
