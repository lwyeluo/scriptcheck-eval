[0711/212029.415671:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212029.415942:INFO:switcher_clone.cc(787)] backtrace rip is 7fa25b156891
[0711/212030.255691:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212030.256184:INFO:switcher_clone.cc(787)] backtrace rip is 7f89f3c7f891
[1:1:0711/212030.260476:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/212030.260641:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/212030.265921:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[16134:16134:0711/212031.472680:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1225eb37-dace-4c3c-ac6c-a375702319d2
[0711/212031.668813:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212031.669315:INFO:switcher_clone.cc(787)] backtrace rip is 7f75431d9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[16167:16167:0711/212031.885906:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16167
[16179:16179:0711/212031.886336:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16179
[16134:16134:0711/212031.985705:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[16134:16165:0711/212031.986478:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/212031.986808:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/212031.987023:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/212031.987616:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/212031.987849:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/212031.990678:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x269f7059, 1
[1:1:0711/212031.991004:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x99dd33, 0
[1:1:0711/212031.991191:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x226677df, 3
[1:1:0711/212031.991408:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x22800c5a, 2
[1:1:0711/212031.991636:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 33ffffffddffffff9900 5970ffffff9f26 5a0cffffff8022 ffffffdf776622 , 10104, 4
[1:1:0711/212031.992568:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16134:16165:0711/212031.992857:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING3ݙ
[16134:16165:0711/212031.992928:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 3ݙ
[1:1:0711/212031.992842:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89f1eba0a0, 3
[1:1:0711/212031.993017:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89f2045080, 2
[16134:16165:0711/212031.993238:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/212031.993163:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89dbd08d20, -2
[16134:16165:0711/212031.993311:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16187, 4, 33dd9900 59709f26 5a0c8022 df776622 
[1:1:0711/212032.015874:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/212032.017015:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22800c5a
[1:1:0711/212032.018160:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22800c5a
[1:1:0711/212032.020135:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22800c5a
[1:1:0711/212032.022068:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.022299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.022527:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.022782:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.023589:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22800c5a
[1:1:0711/212032.024030:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89f3c7f7ba
[1:1:0711/212032.024204:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89f3c76def, 7f89f3c7f77a, 7f89f3c810cf
[1:1:0711/212032.031298:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22800c5a
[1:1:0711/212032.031777:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22800c5a
[1:1:0711/212032.032678:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22800c5a
[1:1:0711/212032.035317:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.035573:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.035835:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.036068:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22800c5a
[1:1:0711/212032.037648:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22800c5a
[1:1:0711/212032.038142:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89f3c7f7ba
[1:1:0711/212032.038314:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89f3c76def, 7f89f3c7f77a, 7f89f3c810cf
[1:1:0711/212032.048113:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/212032.048632:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/212032.048829:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff6d17cc88, 0x7fff6d17cc08)
[1:1:0711/212032.068062:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/212032.075224:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[16134:16134:0711/212032.674563:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16134:16134:0711/212032.676137:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16134:16146:0711/212032.698593:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[16134:16146:0711/212032.698689:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[16134:16134:0711/212032.700665:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[16134:16134:0711/212032.700836:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[16134:16134:0711/212032.701031:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,16187, 4
[1:7:0711/212032.705120:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[16134:16157:0711/212032.722803:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/212032.810714:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2b1b729de220
[1:1:0711/212032.811059:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/212033.173756:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[16134:16134:0711/212034.976226:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[16134:16134:0711/212034.976304:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/212035.012969:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212035.017474:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/212036.292150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/212036.292700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212036.318416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/212036.318689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212036.383006:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212036.654684:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212036.654975:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212036.976839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212036.982119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/212036.982415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212037.003756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212037.013244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/212037.013538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212037.026074:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[16134:16134:0711/212037.030996:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/212037.031738:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b1b729dce20
[1:1:0711/212037.032018:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16134:16134:0711/212037.038459:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[16134:16134:0711/212037.070954:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[16134:16134:0711/212037.071111:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/212037.094092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212037.886077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f89dd8e32e0 0x2b1b72b621e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212037.889187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/212037.889616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212037.893092:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16134:16134:0711/212037.977559:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/212037.980701:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2b1b729dd820
[1:1:0711/212037.980992:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[16134:16134:0711/212037.981686:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/212037.991425:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/212037.991607:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[16134:16134:0711/212038.005906:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[16134:16134:0711/212038.016763:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16134:16134:0711/212038.017735:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16134:16146:0711/212038.023662:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[16134:16146:0711/212038.023748:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[16134:16134:0711/212038.023901:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[16134:16134:0711/212038.023975:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[16134:16134:0711/212038.024133:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,16187, 4
[1:7:0711/212038.026968:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/212038.688361:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/212039.342838:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f89dd8e32e0 0x2b1b72da6a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212039.343873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/212039.344136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212039.344904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16134:16134:0711/212039.463455:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[16134:16134:0711/212039.463608:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/212039.491435:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/212039.967303:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[16134:16134:0711/212040.213142:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[16134:16165:0711/212040.213571:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/212040.213834:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/212040.214144:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/212040.214854:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/212040.215129:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/212040.219837:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3fca22ac, 1
[1:1:0711/212040.220325:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1574d1f4, 0
[1:1:0711/212040.220629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x7674375, 3
[1:1:0711/212040.220880:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d60e0e5, 2
[1:1:0711/212040.221134:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff4ffffffd17415 ffffffac22ffffffca3f ffffffe5ffffffe0603d 75436707 , 10104, 5
[1:1:0711/212040.222705:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16134:16165:0711/212040.223104:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��t�"�?��`=uCgF�>0
[16134:16165:0711/212040.223213:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��t�"�?��`=uCg�%F�>0
[1:1:0711/212040.223401:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89f1eba0a0, 3
[16134:16165:0711/212040.223668:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16231, 5, f4d17415 ac22ca3f e5e0603d 75436707 
[1:1:0711/212040.223836:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89f2045080, 2
[1:1:0711/212040.224124:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f89dbd08d20, -2
[1:1:0711/212040.252575:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/212040.252994:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d60e0e5
[1:1:0711/212040.253360:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d60e0e5
[1:1:0711/212040.254112:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d60e0e5
[1:1:0711/212040.255861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.256084:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.256299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.256514:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.257326:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d60e0e5
[1:1:0711/212040.257697:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89f3c7f7ba
[1:1:0711/212040.257861:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89f3c76def, 7f89f3c7f77a, 7f89f3c810cf
[1:1:0711/212040.264782:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d60e0e5
[1:1:0711/212040.265206:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d60e0e5
[1:1:0711/212040.266102:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d60e0e5
[1:1:0711/212040.268633:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.268907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.269139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.269374:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d60e0e5
[1:1:0711/212040.271049:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d60e0e5
[1:1:0711/212040.271495:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f89f3c7f7ba
[1:1:0711/212040.271702:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f89f3c76def, 7f89f3c7f77a, 7f89f3c810cf
[1:1:0711/212040.281196:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/212040.281773:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/212040.282016:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff6d17cc88, 0x7fff6d17cc08)
[1:1:0711/212040.292831:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/212040.297421:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/212040.419036:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212040.419268:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212040.499426:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2b1b729a9220
[1:1:0711/212040.499695:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/212040.810100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212040.815138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ba1a37ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/212040.815458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/212040.824313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212040.890597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212040.891375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ba1a36a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/212040.891640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212041.046217:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212041.048097:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/212041.048434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ba1a37ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/212041.048794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/212041.148240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212041.149139:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/212041.149366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ba1a37ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/212041.149652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[16134:16134:0711/212041.405949:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16134:16134:0711/212041.412678:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16134:16146:0711/212041.443269:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[16134:16146:0711/212041.443365:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[16134:16134:0711/212041.443856:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://user.qunar.com/
[16134:16134:0711/212041.443937:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://user.qunar.com/, https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1, 1
[16134:16134:0711/212041.444063:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://user.qunar.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 04:20:41 GMT content-type:text/html;charset=UTF-8 xq_point:228 xq_spend:0 xq_sec:null content-encoding:gzip vary:Accept-Encoding server:QWS/1.0  ,16231, 5
[1:7:0711/212041.446385:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/212041.490367:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://user.qunar.com/
[16134:16134:0711/212041.615404:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://user.qunar.com/, https://user.qunar.com/, 1
[16134:16134:0711/212041.615530:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://user.qunar.com/, https://user.qunar.com
[1:1:0711/212041.662627:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/212041.747547:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212041.823702:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0711/212041.852509:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212041.852703:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212041.924822:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0718579, 305, 1
[1:1:0711/212041.925055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212042.138793:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212042.139072:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212042.198590:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/212042.299597:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.repubblica.it/"
[1:1:0711/212042.362838:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://bitly.com/"
[1:1:0711/212042.412171:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://docin.com/"
[1:1:0711/212042.441063:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://battle.net/"
[1:1:0711/212042.519803:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://flvto.biz/"
[1:1:0711/212042.581181:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://themeforest.net/"
[1:1:0711/212042.928583:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212042.958931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212042.959852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ba1a37ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/212042.960144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/212043.444894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f89db9bb070 0x2b1b72ab4b60 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212043.452535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (function(e){var t={id:"86872605378bb90e75baf8c965514629",filename:"hfUtils.js",exports:{}};if(!e.__
[1:1:0711/212043.452815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "user.qunar.com", 3, 1, , , 0
[1:1:0711/212043.457095:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212043.568521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1c54d87629c8, 0x2b1b72831960
[1:1:0711/212043.568736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 15000
[1:1:0711/212043.569327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 213
[1:1:0711/212043.569518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 213 0x7f89db9bb070 0x2b1b72ac5960 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 199 0x7f89db9bb070 0x2b1b72ab4b60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/212044.355414:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 5000
[1:1:0711/212044.356052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 232
[1:1:0711/212044.356292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 232 0x7f89db9bb070 0x2b1b72d69960 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 199 0x7f89db9bb070 0x2b1b72ab4b60 
[1:1:0711/212044.365225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f89db9bb070 0x2b1b72ab4b60 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212044.601851:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.237578, 310, 1
[1:1:0711/212044.602129:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212045.364534:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212045.364830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.365785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f89db9bb070 0x2b1b72ac85e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.366988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , ,  (function(){var i = new Image(); i.src = "//user.qunar.com/passport/addICK.jsp" + ( document.locati
[1:1:0711/212045.367223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "user.qunar.com", 3, 1, , , 0
[1:1:0711/212045.372755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f89db9bb070 0x2b1b72ac85e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.375331:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "user.qunar.com", "qunar.com"
[1:1:0711/212045.386053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f89db9bb070 0x2b1b72ac85e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.588543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f89db9bb070 0x2b1b72ac85e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.791902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 268 0x7f89dd8e32e0 0x2b1b72c530e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.793071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , callback_174485({"ver":1,"ret":true,"errcode":200,"errmsg":"success","errkey":null,"data":{"total_nu
[1:1:0711/212045.793267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212045.795435:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.834742:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f89dd8e32e0 0x2b1b72a487e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212045.836257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (function(){callback_345261({"errcode":22012,"errkey":"username","errmsg":"修改的用户名与登�
[1:1:0711/212045.836487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212045.849317:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212046.166866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293 0x7f89dbd23bd0 0x2b1b72d70658 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212046.189298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , function CaptchaVcodeUrl(e,t){this.url="//captcha1.pbs.qunar.com/api/image";this.key="{en7mni(z";thi
[1:1:0711/212046.189595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212046.286679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212046.292619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212047.436849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1c54d87629c8, 0x2b1b728319e0
[1:1:0711/212047.437149:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 0
[1:1:0711/212047.437701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 338
[1:1:0711/212047.437925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 338 0x7f89db9bb070 0x2b1b72d79160 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 293 0x7f89dbd23bd0 0x2b1b72d70658 
[1:1:0711/212047.491542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c54d87629c8, 0x2b1b728319e0
[1:1:0711/212047.491840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 500
[1:1:0711/212047.492401:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 340
[1:1:0711/212047.492629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 340 0x7f89db9bb070 0x2b1b732c0660 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 293 0x7f89dbd23bd0 0x2b1b72d70658 
[1:1:0711/212049.450550:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.451215:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.651589:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.652135:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.656109:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.656528:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.657448:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212049.864205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212049.865267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , i.(anonymous function).i.(anonymous function), (){e[c]=null}
[1:1:0711/212049.865500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212050.546753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.547733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , r, (e,i){var f,l,c,h,p;try{if(r&&(i||u.readyState===4)){r=t;if(a){u.onreadystatechange=s.noop;if(sn){de
[1:1:0711/212050.548049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212050.549951:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.553301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.554204:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c518d62690
[1:1:0711/212050.627879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.628762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , r, (e,i){var f,l,c,h,p;try{if(r&&(i||u.readyState===4)){r=t;if(a){u.onreadystatechange=s.noop;if(sn){de
[1:1:0711/212050.628990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212050.629612:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.632234:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.633272:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c518d62690
[1:1:0711/212050.690328:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.691237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , r, (e,i){var f,l,c,h,p;try{if(r&&(i||u.readyState===4)){r=t;if(a){u.onreadystatechange=s.noop;if(sn){de
[1:1:0711/212050.691457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212050.692227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.695005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.695807:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c518d62690
[1:1:0711/212050.945756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.946682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , r, (e,i){var f,l,c,h,p;try{if(r&&(i||u.readyState===4)){r=t;if(a){u.onreadystatechange=s.noop;if(sn){de
[1:1:0711/212050.946918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212050.947639:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.950441:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212050.951248:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c518d62690
[1:1:0711/212051.567849:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 338, 7f89de300881
[1:1:0711/212051.577363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"293 0x7f89dbd23bd0 0x2b1b72d70658 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.577689:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"293 0x7f89dbd23bd0 0x2b1b72d70658 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.577996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212051.578729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){checkHalfLogin(_self.isNeedCaptcha)}
[1:1:0711/212051.578938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212051.655321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 340, 7f89de300881
[1:1:0711/212051.673938:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"293 0x7f89dbd23bd0 0x2b1b72d70658 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.674330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"293 0x7f89dbd23bd0 0x2b1b72d70658 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.674698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212051.675512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , i, (){$("#"+e).find("input[name='username']").trigger("change");$("#"+e).find("input[type='password']")
[1:1:0711/212051.675771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212051.745593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 232, 7f89de3008db
[1:1:0711/212051.764042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"199 0x7f89db9bb070 0x2b1b72ab4b60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.764458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"199 0x7f89db9bb070 0x2b1b72ab4b60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212051.764924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 415
[1:1:0711/212051.765193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f89db9bb070 0x2b1b743ad0e0 , 5:3_https://user.qunar.com/, 0, , 232 0x7f89db9bb070 0x2b1b72d69960 
[1:1:0711/212051.765520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212051.766256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212051.766466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.024342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376 0x7f89dd8e32e0 0x2b1b72ac2260 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.025715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , 
        
        (function () {
            var insertJs = function () {
                        va
[1:1:0711/212052.025951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.031302:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.033140:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 10
[1:1:0711/212052.033699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 419
[1:1:0711/212052.033930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 419 0x7f89db9bb070 0x2b1b741abee0 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 376 0x7f89dd8e32e0 0x2b1b72ac2260 
[1:1:0711/212052.056019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377 0x7f89dd8e32e0 0x2b1b72ac7fe0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.057062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , 
        
        (function () {
            var insertJs = function () {
                        va
[1:1:0711/212052.057289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.059249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.060762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 10
[1:1:0711/212052.061321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 422
[1:1:0711/212052.061550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 422 0x7f89db9bb070 0x2b1b73258ae0 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 377 0x7f89dd8e32e0 0x2b1b72ac7fe0 
[1:1:0711/212052.279619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.280606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , r, (e,i){var f,l,c,h,p;try{if(r&&(i||u.readyState===4)){r=t;if(a){u.onreadystatechange=s.noop;if(sn){de
[1:1:0711/212052.280832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.281487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.284159:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.284999:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1c518d62690
[1:1:0711/212052.339685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1c54d87629c8, 0x2b1b72831a10
[1:1:0711/212052.339959:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 0
[1:1:0711/212052.340529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 428
[1:1:0711/212052.340761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 428 0x7f89db9bb070 0x2b1b732a9460 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 413
[1:1:0711/212052.346634:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 13
[1:1:0711/212052.347197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 429
[1:1:0711/212052.347433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 429 0x7f89db9bb070 0x2b1b73a5fc60 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 413
[1:1:0711/212052.557527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 419, 7f89de3008db
[1:1:0711/212052.576966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"376 0x7f89dd8e32e0 0x2b1b72ac2260 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.577362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"376 0x7f89dd8e32e0 0x2b1b72ac2260 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.577719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 443
[1:1:0711/212052.578031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7f89db9bb070 0x2b1b732a77e0 , 5:3_https://user.qunar.com/, 0, , 419 0x7f89db9bb070 0x2b1b741abee0 
[1:1:0711/212052.578392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.579168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){var s=window.QDevice;if(e>r){i.state="error";i.error();clearInterval(n);return}if(s){i.state="rea
[1:1:0711/212052.579422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.600784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 422, 7f89de3008db
[1:1:0711/212052.622068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"377 0x7f89dd8e32e0 0x2b1b72ac7fe0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.622432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"377 0x7f89dd8e32e0 0x2b1b72ac7fe0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.622791:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 446
[1:1:0711/212052.623019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 446 0x7f89db9bb070 0x2b1b73c6a7e0 , 5:3_https://user.qunar.com/, 0, , 422 0x7f89db9bb070 0x2b1b73258ae0 
[1:1:0711/212052.623372:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.624074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){var r=window.QDevice;if(e>o){u.state="error";u.error();clearInterval(n);return}if(r){u.state="rea
[1:1:0711/212052.624304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.710071:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 428, 7f89de300881
[1:1:0711/212052.729387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"413","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.729717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"413","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.730017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.730746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , bn, (){gn=t}
[1:1:0711/212052.730963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.732794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 429, 7f89de3008db
[1:1:0711/212052.752480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"413","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.752795:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"413","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.753137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 449
[1:1:0711/212052.753442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 449 0x7f89db9bb070 0x2b1b732573e0 , 5:3_https://user.qunar.com/, 0, , 429 0x7f89db9bb070 0x2b1b73a5fc60 
[1:1:0711/212052.753800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.754529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212052.754743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.756426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1c54d87629c8, 0x2b1b72831950
[1:1:0711/212052.756624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 0
[1:1:0711/212052.757150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 450
[1:1:0711/212052.757403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f89db9bb070 0x2b1b743ad260 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 429 0x7f89db9bb070 0x2b1b73a5fc60 
[1:1:0711/212052.805406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f89dd8e32e0 0x2b1b744b50e0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.807380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , 

/**
 * Created by macbinn on 16/5/17.
 */
(function() {
    try {
        if (window.QDevice) retu
[1:1:0711/212052.807630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.850089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7f89dd8e32e0 0x2b1b744b4f60 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.851099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , 

/**
 * Created by macbinn on 16/5/17.
 */
(function() {
    try {
        if (window.QDevice) retu
[1:1:0711/212052.851349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.868081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 443, 7f89de3008db
[1:1:0711/212052.876732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"419 0x7f89db9bb070 0x2b1b741abee0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.877032:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"419 0x7f89db9bb070 0x2b1b741abee0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.877367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 454
[1:1:0711/212052.877609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 454 0x7f89db9bb070 0x2b1b72d73c60 , 5:3_https://user.qunar.com/, 0, , 443 0x7f89db9bb070 0x2b1b732a77e0 
[1:1:0711/212052.877936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.878662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){var s=window.QDevice;if(e>r){i.state="error";i.error();clearInterval(n);return}if(s){i.state="rea
[1:1:0711/212052.878883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212052.932144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 446, 7f89de3008db
[1:1:0711/212052.950329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"422 0x7f89db9bb070 0x2b1b73258ae0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.950646:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"422 0x7f89db9bb070 0x2b1b73258ae0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212052.950998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 456
[1:1:0711/212052.951229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 456 0x7f89db9bb070 0x2b1b743adce0 , 5:3_https://user.qunar.com/, 0, , 446 0x7f89db9bb070 0x2b1b73c6a7e0 
[1:1:0711/212052.951591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212052.952293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){var r=window.QDevice;if(e>o){u.state="error";u.error();clearInterval(n);return}if(r){u.state="rea
[1:1:0711/212052.952517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212053.002193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 450, 7f89de300881
[1:1:0711/212053.022489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"429 0x7f89db9bb070 0x2b1b73a5fc60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.022828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"429 0x7f89db9bb070 0x2b1b73a5fc60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.023153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212053.023920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , bn, (){gn=t}
[1:1:0711/212053.024197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212053.045930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 449, 7f89de3008db
[1:1:0711/212053.060114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"429 0x7f89db9bb070 0x2b1b73a5fc60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.060462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"429 0x7f89db9bb070 0x2b1b73a5fc60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.060830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 460
[1:1:0711/212053.061083:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 460 0x7f89db9bb070 0x2b1b72d691e0 , 5:3_https://user.qunar.com/, 0, , 449 0x7f89db9bb070 0x2b1b732573e0 
[1:1:0711/212053.061418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212053.062119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212053.062391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212053.063577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1c54d87629c8, 0x2b1b72831950
[1:1:0711/212053.063789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 0
[1:1:0711/212053.064312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 461
[1:1:0711/212053.064545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 461 0x7f89db9bb070 0x2b1b744a7a60 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 449 0x7f89db9bb070 0x2b1b732573e0 
[1:1:0711/212053.232652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 461, 7f89de300881
[1:1:0711/212053.242135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"449 0x7f89db9bb070 0x2b1b732573e0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.242462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"449 0x7f89db9bb070 0x2b1b732573e0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212053.242756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212053.243502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , bn, (){gn=t}
[1:1:0711/212053.243718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212053.308464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7f89dd8e32e0 0x2b1b732c0be0 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212053.319150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (function(W){var H=function(a,b){return (a+65)^b},d=function(a,b){return a+46-b},e=function(a,b){ret
[1:1:0711/212053.319426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[16134:16134:0711/212054.159433:INFO:CONSOLE(72)] "Mixed Content: The page at 'https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1' was loaded over HTTPS, but requested an insecure image 'http://captcha1.pbs.qunar.com/api/image?k={en7mni(z&p=ucenter_order&c=4cf6a64adc3ae2674fc9864bc55ec150&t=1384162560890&idx=3'. This content should also be served over HTTPS.", source: https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1 (72)
[16134:16134:0711/212054.166721:INFO:CONSOLE(126)] "Mixed Content: The page at 'https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1' was loaded over HTTPS, but requested an insecure image 'http://captcha1.pbs.qunar.com/api/image?k={en7mni(z&p=ucenter_order&c=4cf6a64adc3ae2674fc9864bc55ec150&t=1384162560890&idx=2'. This content should also be served over HTTPS.", source: https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1 (126)
[16134:16134:0711/212054.203889:INFO:CONSOLE(1)] "loginpop:1.1.6_2015/05/18", source: https://user.qunar.com/static/userlogin/prd/v1.1.6/LoginPop.js?20160506 (1)
[16134:16134:0711/212054.331395:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/212054.415842:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/212113.074081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/212113.074365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212113.916170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , document.readyState
[1:1:0711/212113.916488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212113.920289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 415, 7f89de3008db
[1:1:0711/212113.944349:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"232 0x7f89db9bb070 0x2b1b72d69960 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212113.944887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"232 0x7f89db9bb070 0x2b1b72d69960 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212113.945316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 534
[1:1:0711/212113.945568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f89db9bb070 0x2b1b732abce0 , 5:3_https://user.qunar.com/, 0, , 415 0x7f89db9bb070 0x2b1b743ad0e0 
[1:1:0711/212113.945927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212113.946707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212113.946956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212114.004124:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 213, 7f89de300881
[1:1:0711/212114.027492:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"32271ebc2860","ptid":"199 0x7f89db9bb070 0x2b1b72ab4b60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212114.027836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://user.qunar.com/","ptid":"199 0x7f89db9bb070 0x2b1b72ab4b60 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212114.028168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212114.028871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , P, (){s=0;var e=n.getCookie("QN44");if(l===0||v==="half"||i()){B();if(l===0){j(true)}else if(v==="login
[1:1:0711/212114.029100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212114.037173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x1c54d87629c8, 0x2b1b72831950
[1:1:0711/212114.037382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", 15000
[1:1:0711/212114.037949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://user.qunar.com/, 539
[1:1:0711/212114.038193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 539 0x7f89db9bb070 0x2b1b72c52ce0 , 5:3_https://user.qunar.com/, 1, -5:3_https://user.qunar.com/, 213 0x7f89db9bb070 0x2b1b72ac5960 
[16134:16134:0711/212114.393531:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='email', confirm at https://goo.gl/6KgkJg) %o", source: https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1 (0)
[16134:16134:0711/212114.397841:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='tel', confirm at https://goo.gl/6KgkJg) %o", source: https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1 (0)
[16134:16134:0711/212114.402375:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: autocomplete='tel', confirm at https://goo.gl/6KgkJg) %o", source: https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1 (0)
[1:1:0711/212114.644361:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f89dd8e32e0 0x2b1b744a8760 , "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212114.644940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , callback_1562905272997('885c36c4-bc53-4395-91ce-4379d06def21')
[1:1:0711/212114.645062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212114.668454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , document.readyState
[1:1:0711/212114.668618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212115.014298:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 534, 7f89de3008db
[1:1:0711/212115.032726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"415 0x7f89db9bb070 0x2b1b743ad0e0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212115.032981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"415 0x7f89db9bb070 0x2b1b743ad0e0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212115.033319:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 574
[1:1:0711/212115.033502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f89db9bb070 0x2b1b744b58e0 , 5:3_https://user.qunar.com/, 0, , 534 0x7f89db9bb070 0x2b1b732abce0 
[1:1:0711/212115.033727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212115.034197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212115.034368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212115.602151:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212115.603282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , ready, (e){if(e===true&&!--i.readyWait||e!==true&&!i.isReady){if(!n.body){return setTimeout(i.ready,1)}i.is
[1:1:0711/212115.603835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[1:1:0711/212115.655456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , document.readyState
[1:1:0711/212115.655735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
[16134:16134:0711/212116.330412:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/212119.389587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 574, 7f89de3008db
[1:1:0711/212119.403603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"534 0x7f89db9bb070 0x2b1b732abce0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212119.403827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"534 0x7f89db9bb070 0x2b1b732abce0 ","rf":"5:3_https://user.qunar.com/"}
[1:1:0711/212119.404021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://user.qunar.com/, 622
[1:1:0711/212119.404135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f89db9bb070 0x2b1b744994e0 , 5:3_https://user.qunar.com/, 0, , 574 0x7f89db9bb070 0x2b1b744b58e0 
[1:1:0711/212119.404485:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1"
[1:1:0711/212119.405179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://user.qunar.com/, 32271ebc2860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212119.405399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://user.qunar.com/order/query.jsp?ret=http%3A%2F%2Forder.qunar.com%2Fapartment?t=1", "qunar.com", 3, 1, , , 0
