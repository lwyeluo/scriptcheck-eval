[0711/212621.758059:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212621.758484:INFO:switcher_clone.cc(787)] backtrace rip is 7f91d138a891
[0711/212622.676759:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212622.677031:INFO:switcher_clone.cc(787)] backtrace rip is 7ff47d763891
[1:1:0711/212622.681031:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/212622.681189:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/212622.686116:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[16797:16797:0711/212623.596226:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f94db669-7e85-458c-a49c-5a9bfe75c601
[16797:16797:0711/212624.033789:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[16797:16827:0711/212624.034520:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/212624.034726:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/212624.034976:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/212624.035551:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/212624.035704:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/212624.038701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a2136bb, 1
[1:1:0711/212624.039125:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ad48f21, 0
[1:1:0711/212624.039345:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2688fa88, 3
[1:1:0711/212624.039572:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x230ecf7, 2
[1:1:0711/212624.039808:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 21ffffff8fffffffd43a ffffffbb36212a fffffff7ffffffec3002 ffffff88fffffffaffffff8826 , 10104, 4
[1:1:0711/212624.040815:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16797:16827:0711/212624.041073:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING!��:�6!*��0���&Z�b;
[16797:16827:0711/212624.041141:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is !��:�6!*��0���&�MZ�b;
[1:1:0711/212624.041251:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff47b99e0a0, 3
[16797:16827:0711/212624.041426:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/212624.041463:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff47bb29080, 2
[16797:16827:0711/212624.041498:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16842, 4, 218fd43a bb36212a f7ec3002 88fa8826 
[1:1:0711/212624.041636:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4657ecd20, -2
[1:1:0711/212624.061623:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/212624.062700:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 230ecf7
[1:1:0711/212624.063878:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 230ecf7
[1:1:0711/212624.065762:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 230ecf7
[1:1:0711/212624.067638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.067913:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.068150:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.068366:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.069175:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 230ecf7
[1:1:0711/212624.069577:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff47d7637ba
[1:1:0711/212624.069746:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff47d75adef, 7ff47d76377a, 7ff47d7650cf
[1:1:0711/212624.076782:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 230ecf7
[1:1:0711/212624.077270:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 230ecf7
[1:1:0711/212624.078224:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 230ecf7
[1:1:0711/212624.080852:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.081141:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.081371:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.081606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 230ecf7
[1:1:0711/212624.083196:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 230ecf7
[1:1:0711/212624.083680:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff47d7637ba
[1:1:0711/212624.083874:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff47d75adef, 7ff47d76377a, 7ff47d7650cf
[1:1:0711/212624.092733:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/212624.093235:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/212624.093378:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfd6ead68, 0x7ffdfd6eace8)
[1:1:0711/212624.107607:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/212624.113433:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[0711/212624.175694:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/212624.176224:INFO:switcher_clone.cc(787)] backtrace rip is 7f38eee0b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[16829:16829:0711/212624.436729:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16829
[16868:16868:0711/212624.437187:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16868
[16797:16797:0711/212624.569870:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16797:16797:0711/212624.571316:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16797:16808:0711/212624.581073:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[16797:16797:0711/212624.581107:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[16797:16797:0711/212624.581162:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[16797:16808:0711/212624.581203:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[16797:16797:0711/212624.581228:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,16842, 4
[1:7:0711/212624.584425:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[16797:16820:0711/212624.630175:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/212624.730624:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x4d060a9d220
[1:1:0711/212624.730927:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/212625.102121:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[16797:16797:0711/212626.913945:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[16797:16797:0711/212626.914096:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/212626.959861:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212626.963454:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/212627.843389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/212627.843745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212627.875439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/212627.875764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212627.957884:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212628.134071:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212628.134334:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212628.558330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212628.566715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/212628.567029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212628.602567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212628.613170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/212628.613428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212628.625288:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/212628.629245:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4d060a9be20
[1:1:0711/212628.629457:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16797:16797:0711/212628.630029:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[16797:16797:0711/212628.646825:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0711/212628.677703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[16797:16797:0711/212628.700465:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[16797:16797:0711/212628.700607:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/212629.543095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7ff4673c72e0 0x4d060d5bce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212629.544580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/212629.544847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212629.546367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16797:16797:0711/212629.615180:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/212629.617391:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x4d060a9c820
[1:1:0711/212629.617586:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[16797:16797:0711/212629.621468:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/212629.640077:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/212629.640349:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[16797:16797:0711/212629.644905:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[16797:16797:0711/212629.656368:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16797:16797:0711/212629.657627:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16797:16808:0711/212629.663786:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[16797:16808:0711/212629.663874:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[16797:16797:0711/212629.664018:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[16797:16797:0711/212629.664094:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[16797:16797:0711/212629.664257:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,16842, 4
[1:7:0711/212629.670604:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/212630.345089:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/212630.637673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7ff4673c72e0 0x4d060d043e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/212630.638760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 18a667d01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/212630.638998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/212630.639769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16797:16797:0711/212630.736535:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[16797:16797:0711/212630.736654:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/212630.745612:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/212631.106167:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212631.755359:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212631.755656:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[16797:16797:0711/212632.016700:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[16797:16827:0711/212632.017150:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/212632.017331:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/212632.017565:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/212632.017983:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/212632.018157:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/212632.021173:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x217966d5, 1
[1:1:0711/212632.021529:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x191863b8, 0
[1:1:0711/212632.021711:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c79d9c6, 3
[1:1:0711/212632.021918:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3114fd20, 2
[1:1:0711/212632.022112:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb8631819 ffffffd5667921 20fffffffd1431 ffffffc6ffffffd9793c , 10104, 5
[1:1:0711/212632.023113:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16797:16827:0711/212632.023358:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�c�fy! �1��y<_
[16797:16827:0711/212632.023427:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �c�fy! �1��y<��_
[1:1:0711/212632.023553:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff47b99e0a0, 3
[16797:16827:0711/212632.023709:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16893, 5, b8631819 d5667921 20fd1431 c6d9793c 
[1:1:0711/212632.023804:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff47bb29080, 2
[1:1:0711/212632.024056:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4657ecd20, -2
[1:1:0711/212632.045140:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/212632.045565:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3114fd20
[1:1:0711/212632.045935:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3114fd20
[1:1:0711/212632.046583:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3114fd20
[1:1:0711/212632.048118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.048360:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.048603:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.048862:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.049586:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3114fd20
[1:1:0711/212632.049988:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff47d7637ba
[1:1:0711/212632.050204:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff47d75adef, 7ff47d76377a, 7ff47d7650cf
[1:1:0711/212632.056108:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3114fd20
[1:1:0711/212632.056576:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3114fd20
[1:1:0711/212632.057355:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3114fd20
[1:1:0711/212632.059416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.059748:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.060163:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.060404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3114fd20
[1:1:0711/212632.061746:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3114fd20
[1:1:0711/212632.062152:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff47d7637ba
[1:1:0711/212632.062318:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff47d75adef, 7ff47d76377a, 7ff47d7650cf
[1:1:0711/212632.070183:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/212632.070630:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/212632.070811:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdfd6ead68, 0x7ffdfd6eace8)
[1:1:0711/212632.085904:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/212632.090143:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/212632.137507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212632.142022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18a667e2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/212632.142323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/212632.150612:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/212632.357519:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x4d060a67220
[1:1:0711/212632.357861:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16797:16797:0711/212632.411716:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16797:16797:0711/212632.417079:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16797:16808:0711/212632.450790:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[16797:16808:0711/212632.450889:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[16797:16797:0711/212632.451480:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://guide.qunar.com/
[16797:16797:0711/212632.451589:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://guide.qunar.com/, http://guide.qunar.com/krabi.htm?from=quner_index_text, 1
[16797:16797:0711/212632.451754:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://guide.qunar.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 04:26:32 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: JSESSIONID=37ABB7A541412825478EB73D10F01005; Path=/; HttpOnly Content-Language: en-US Content-Encoding: gzip Vary: Accept-Encoding Server: QWS/1.0  ,16893, 5
[1:7:0711/212632.456601:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/212632.568114:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://guide.qunar.com/
[1:1:0711/212632.720361:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[16797:16797:0711/212632.725216:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://guide.qunar.com/, http://guide.qunar.com/, 1
[16797:16797:0711/212632.725316:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://guide.qunar.com/, http://guide.qunar.com
[1:1:0711/212632.855545:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212632.999235:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212632.999495:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212633.194441:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.354464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7ff465807bd0 0x4d060b76058 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212633.370781:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.379325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(e,t){function u(e){var t=o[e]={},n,r;e=e.split(/\s+/);for(n=0,r=e.length;n<r;n++){t[e[n]]=
[1:1:0711/212633.379596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/212633.736687:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.739113:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.739513:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.739873:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212633.740189:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212634.060274:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7ff465807bd0 0x4d060b76058 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212634.154161:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.097326, 478, 1
[1:1:0711/212634.154446:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212634.540513:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212634.540810:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212634.549045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 196 0x7ff46549f070 0x4d060d08f60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212634.554348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(e){var t={id:"86872605378bb90e75baf8c965514629",filename:"hfUtils.js",exports:{}};if(!e.__
[1:1:0711/212634.554600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212634.729770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685a10
[1:1:0711/212634.730056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212634.730499:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 232
[1:1:0711/212634.730753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 232 0x7ff46549f070 0x4d06075b2e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 196 0x7ff46549f070 0x4d060d08f60 
[1:1:0711/212635.831324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 5000
[1:1:0711/212635.832115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 262
[1:1:0711/212635.832376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 262 0x7ff46549f070 0x4d0612cd760 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 196 0x7ff46549f070 0x4d060d08f60 
[1:1:0711/212635.839294:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.29831, 0, 0
[1:1:0711/212635.839538:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212636.854494:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212636.854778:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212636.859032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7ff46549f070 0x4d060f3d0e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212636.861520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(e){function n(r){if(t[r])return t[r].exports;var i=t[r]={exports:{},id:r,loaded:false};e[r
[1:1:0711/212636.861747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212636.906700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7ff46549f070 0x4d060f3d0e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212637.250158:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.395215, 168, 1
[1:1:0711/212637.250421:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212637.738589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 292 0x7ff4673c72e0 0x4d060cc10e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212637.739821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , callback_255736({"ver":1,"ret":true,"errcode":200,"errmsg":"success","errkey":null,"data":{"total_nu
[1:1:0711/212637.740065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212637.742543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212637.762627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293 0x7ff4673c72e0 0x4d06075b0e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212637.763787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(){callback_267020({"errcode":22012,"errkey":"username","errmsg":"修改的用户名与登�
[1:1:0711/212637.764007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212637.791827:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.668439:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212638.668708:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.669577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7ff46549f070 0x4d060e99d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.670772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic"
[1:1:0711/212638.671024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212638.683807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7ff46549f070 0x4d060e99d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.686172:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/212638.689707:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x4d060fac220
[1:1:0711/212638.689924:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/212638.710677:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/212638.710922:INFO:render_frame_impl.cc(7019)] 	 [url] = http://guide.qunar.com
[1:1:0711/212638.717903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7ff46549f070 0x4d060e99d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.722109:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7ff46549f070 0x4d060e99d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.753143:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7ff46549f070 0x4d060e99d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212638.788765:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.119912, 144, 1
[1:1:0711/212638.789090:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/212639.417466:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/212639.417758:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212639.420199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394 0x7ff46549f070 0x4d061532260 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212639.421387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , ,  (function(){var i = new Image(); i.src = "//user.qunar.com/passport/addICK.jsp" + ( document.locati
[1:1:0711/212639.421624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212639.430975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.305534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 1500
[1:1:0711/212640.306093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 455
[1:1:0711/212640.306326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 455 0x7ff46549f070 0x4d06174cbe0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 394 0x7ff46549f070 0x4d061532260 
[1:1:0711/212640.370620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 3000
[1:1:0711/212640.371155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 456
[1:1:0711/212640.371382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 456 0x7ff46549f070 0x4d06177c8e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 394 0x7ff46549f070 0x4d061532260 
[1:1:0711/212640.428216:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.434619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.447727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.642937:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.643808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , i.(anonymous function).i.(anonymous function), (){e[c]=null}
[1:1:0711/212640.644027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212640.686525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.687317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , c.img.onload.c.img.onerror, (){c.img=null}
[1:1:0711/212640.687532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212640.918299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 412 0x7ff4673c72e0 0x4d061532860 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212640.926958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0711/212640.927232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212641.025427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d0606859c8
[1:1:0711/212641.025724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212641.026183:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 482
[1:1:0711/212641.026408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7ff46549f070 0x4d0617d2d60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 412 0x7ff4673c72e0 0x4d061532860 
[1:1:0711/212641.039374:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d0606859c8
[1:1:0711/212641.039725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212641.040196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 484
[1:1:0711/212641.040429:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7ff46549f070 0x4d0617bf0e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 412 0x7ff4673c72e0 0x4d061532860 
[1:1:0711/212641.045619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x284501ac29c8, 0x4d0606859c8
[1:1:0711/212641.045869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 3000
[1:1:0711/212641.046400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 485
[1:1:0711/212641.046645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7ff46549f070 0x4d061562fe0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 412 0x7ff4673c72e0 0x4d061532860 
[1:1:0711/212641.081376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7ff4673c72e0 0x4d060ceace0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212641.084020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(){var e=function(){this.param={};};e.prototype.cookie=function(i,j,g){if(arguments.length>
[1:1:0711/212641.084250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212641.085959:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x284501ac29c8, 0x4d060685990
[1:1:0711/212641.086157:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 100
[1:1:0711/212641.086606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 490
[1:1:0711/212641.086847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7ff46549f070 0x4d0618d4ee0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 413 0x7ff4673c72e0 0x4d060ceace0 
[1:1:0711/212642.221274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 262, 7ff467de48db
[1:1:0711/212642.229844:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"196 0x7ff46549f070 0x4d060d08f60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.230203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"196 0x7ff46549f070 0x4d060d08f60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.230541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 516
[1:1:0711/212642.230766:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7ff46549f070 0x4d06157e460 , 5:3_http://guide.qunar.com/, 0, , 262 0x7ff46549f070 0x4d0612cd760 
[1:1:0711/212642.231053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212642.231665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212642.231895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212642.433846:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 490, 7ff467de4881
[1:1:0711/212642.456055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"413 0x7ff4673c72e0 0x4d060ceace0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.456428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"413 0x7ff4673c72e0 0x4d060ceace0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.456731:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212642.457374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){if(window._ba_utm_init||window._ba_utm_s){c();}else{a++;if(a<50){setTimeout(arguments.callee,100)
[1:1:0711/212642.457594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212642.713999:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 455, 7ff467de48db
[1:1:0711/212642.736386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"394 0x7ff46549f070 0x4d061532260 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.736716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"394 0x7ff46549f070 0x4d061532260 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212642.737068:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 533
[1:1:0711/212642.737318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7ff46549f070 0x4d0617758e0 , 5:3_http://guide.qunar.com/, 0, , 455 0x7ff46549f070 0x4d06174cbe0 
[1:1:0711/212642.737624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212642.738209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212642.738420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212642.829462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212642.829731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212642.830172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 535
[1:1:0711/212642.830409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 535 0x7ff46549f070 0x4d0619b1be0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 455 0x7ff46549f070 0x4d06174cbe0 
[1:1:0711/212642.835427:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212642.835853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 536
[1:1:0711/212642.836081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7ff46549f070 0x4d0619c9160 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 455 0x7ff46549f070 0x4d06174cbe0 
[1:1:0711/212642.930140:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212642.930945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , c.img.onload.c.img.onerror, (){c.img=null}
[1:1:0711/212642.931162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.008479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7ff4673c72e0 0x4d061580960 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.009752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , 
        
        (function () {
            var insertJs = function () {
                        va
[1:1:0711/212643.009972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.015696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.017312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 10
[1:1:0711/212643.017788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 547
[1:1:0711/212643.018012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 547 0x7ff46549f070 0x4d0619b15e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 509 0x7ff4673c72e0 0x4d061580960 
[1:1:0711/212643.046813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 510 0x7ff4673c72e0 0x4d06157a7e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.048416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0711/212643.048688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.070648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685990
[1:1:0711/212643.070905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212643.071372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 550
[1:1:0711/212643.071640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7ff46549f070 0x4d0619a7a60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 510 0x7ff4673c72e0 0x4d06157a7e0 
[1:1:0711/212643.100231:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685990
[1:1:0711/212643.100535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212643.101013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 552
[1:1:0711/212643.101247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7ff46549f070 0x4d061a217e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 510 0x7ff4673c72e0 0x4d06157a7e0 
[1:1:0711/212643.104489:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.311027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7ff4673c72e0 0x4d06094cf60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.312164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0711/212643.312404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.343286:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685990
[1:1:0711/212643.343573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212643.344035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 575
[1:1:0711/212643.344267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7ff46549f070 0x4d061a22d60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 520 0x7ff4673c72e0 0x4d06094cf60 
[1:1:0711/212643.348965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[16797:16797:0711/212643.419335:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[16797:16797:0711/212643.425690:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[16797:16797:0711/212643.436709:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://guide.qunar.com/
[3:3:0711/212643.527805:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/212643.529972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 535, 7ff467de4881
[1:1:0711/212643.555328:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.555713:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.556025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.556649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212643.556862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.558591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 536, 7ff467de48db
[1:1:0711/212643.583715:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.584041:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.584377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 596
[1:1:0711/212643.584631:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7ff46549f070 0x4d0619fa660 , 5:3_http://guide.qunar.com/, 0, , 536 0x7ff46549f070 0x4d0619c9160 
[1:1:0711/212643.584958:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.585581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212643.585790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.587294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212643.587491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212643.587971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 597
[1:1:0711/212643.588190:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7ff46549f070 0x4d06149ac60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 536 0x7ff46549f070 0x4d0619c9160 
[1:1:0711/212643.665504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/212643.665784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212643.934450:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 547, 7ff467de48db
[1:1:0711/212643.959937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"509 0x7ff4673c72e0 0x4d061580960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.960285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"509 0x7ff4673c72e0 0x4d061580960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212643.960628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 611
[1:1:0711/212643.960880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7ff46549f070 0x4d061596860 , 5:3_http://guide.qunar.com/, 0, , 547 0x7ff46549f070 0x4d0619b15e0 
[1:1:0711/212643.961208:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212643.961852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){var r=window.QDevice;if(e>o){u.state="error";u.error();clearInterval(n);return}if(r){u.state="rea
[1:1:0711/212643.962062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212644.410203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 533, 7ff467de48db
[1:1:0711/212644.436778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212644.437129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"455 0x7ff46549f070 0x4d06174cbe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212644.437472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 627
[1:1:0711/212644.437698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7ff46549f070 0x4d06190d460 , 5:3_http://guide.qunar.com/, 0, , 533 0x7ff46549f070 0x4d0617758e0 
[1:1:0711/212644.438059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212644.438655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212644.438895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212644.485761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212644.486321:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 628
[1:1:0711/212644.486554:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7ff46549f070 0x4d061a70ae0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 533 0x7ff46549f070 0x4d0617758e0 
[1:1:0711/212644.517451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 456, 7ff467de48db
[1:1:0711/212644.526736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"394 0x7ff46549f070 0x4d061532260 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212644.527157:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"394 0x7ff46549f070 0x4d061532260 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212644.527516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 631
[1:1:0711/212644.527782:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7ff46549f070 0x4d061a22360 , 5:3_http://guide.qunar.com/, 0, , 456 0x7ff46549f070 0x4d06177c8e0 
[1:1:0711/212644.528086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212644.528727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){show(1)}
[1:1:0711/212644.529029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[16797:16797:0711/212644.693048:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16797:16797:0711/212644.695332:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16797:16808:0711/212644.704031:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[16797:16808:0711/212644.704148:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[16797:16797:0711/212644.704383:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://widget.weibo.com/
[16797:16797:0711/212644.704473:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/distribution/comments.php?width=0&url=http%3A%2F%2Fguide.qunar.com%2Fkrabi.htm%3Ffrom%3Dquner_index_text&border=1&appkey=2613808104&dpc=1, 4
[16797:16797:0711/212644.704653:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://widget.weibo.com/, HTTP/1.1 200 OK Server: WeiBo/LB Date: Fri, 12 Jul 2019 04:26:43 GMT Content-Type: text/html Content-Length: 20 Connection: keep-alive Vary: Host,Accept-Encoding Set-Cookie: U_TRS1=00000022.18bb3c26.5d280c03.6a60ebef; path=/; expires=Mon, 09-Jul-29 04:26:43 GMT; domain=.sina.com.cn Set-Cookie: U_TRS2=00000022.18ca3c26.5d280c03.502747c5; path=/; domain=.sina.com.cn Content-Security-Policy: upgrade-insecure-requests xPlugins-Type: 1 Cache-Control: max-age=60, must-revalidate Pragma:  Expires: Fri, 12 Jul 2019 04:31:43 GMT Last-Modified: Fri, 12 Jul 2019 04:26:43 GMT DPOOL_HEADER: qubele36 Content-Encoding: gzip Set-Cookie: YF-Widget-G0=0cdde4dae554168aec1787e746028684;Path=/ LB_HEADER: venus240 Strict-Transport-Security: max-age=31536000; preload  ,16893, 5
[1:7:0711/212644.725918:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/212645.010194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 597, 7ff467de4881
[1:1:0711/212645.036967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"536 0x7ff46549f070 0x4d0619c9160 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.037312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"536 0x7ff46549f070 0x4d0619c9160 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.037671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.038300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212645.038509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.301490:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 608 0x7ff4673c72e0 0x4d0619f3060 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.303737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , 

/**
 * Created by macbinn on 16/5/17.
 */
(function() {
    try {
        if (window.QDevice) retu
[1:1:0711/212645.304006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.334423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 609 0x7ff4673c72e0 0x4d06190d3e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.335621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0711/212645.335869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.351772:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.387362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 611, 7ff467de48db
[1:1:0711/212645.404883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"547 0x7ff46549f070 0x4d0619b15e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.405202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"547 0x7ff46549f070 0x4d0619b15e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.405568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 654
[1:1:0711/212645.405804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7ff46549f070 0x4d061d7ff60 , 5:3_http://guide.qunar.com/, 0, , 611 0x7ff46549f070 0x4d061596860 
[1:1:0711/212645.406152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.406793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){var r=window.QDevice;if(e>o){u.state="error";u.error();clearInterval(n);return}if(r){u.state="rea
[1:1:0711/212645.407034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.448512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 485, 7ff467de4881
[1:1:0711/212645.464528:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"412 0x7ff4673c72e0 0x4d061532860 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.464878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"412 0x7ff4673c72e0 0x4d061532860 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212645.465230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.465853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0711/212645.466062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.473414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212645.473665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212645.474120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 659
[1:1:0711/212645.474435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7ff46549f070 0x4d061d566e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 485 0x7ff46549f070 0x4d061562fe0 
[1:1:0711/212645.637886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 618 0x7ff4673c72e0 0x4d060c94d60 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.638959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0711/212645.639238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212645.651528:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[16797:16797:0711/212645.654733:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/212645.721463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 619 0x7ff4673c72e0 0x4d0617b97e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212645.726119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0711/212645.726454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212646.463676:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685948
[1:1:0711/212646.464004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212646.464589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 666
[1:1:0711/212646.464847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7ff46549f070 0x4d061c97be0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 619 0x7ff4673c72e0 0x4d0617b97e0 
[1:1:0711/212646.550157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685948
[1:1:0711/212646.550431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212646.550901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 669
[1:1:0711/212646.551126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7ff46549f070 0x4d061c7c2e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 619 0x7ff4673c72e0 0x4d0617b97e0 
[1:1:0711/212646.551653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685948
[1:1:0711/212646.551854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212646.552287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 670
[1:1:0711/212646.552546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 670 0x7ff46549f070 0x4d061eeeee0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 619 0x7ff4673c72e0 0x4d0617b97e0 
[1:1:0711/212646.570825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212646.740365:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 628, 7ff467de48db
[1:1:0711/212646.772381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"533 0x7ff46549f070 0x4d0617758e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212646.772800:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"533 0x7ff46549f070 0x4d0617758e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212646.773256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 677
[1:1:0711/212646.773554:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7ff46549f070 0x4d061efba60 , 5:3_http://guide.qunar.com/, 0, , 628 0x7ff46549f070 0x4d061a70ae0 
[1:1:0711/212646.773915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212646.774570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212646.774831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212646.776196:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212646.776415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212646.777124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 678
[1:1:0711/212646.777381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7ff46549f070 0x4d0619c9e60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 628 0x7ff46549f070 0x4d061a70ae0 
[1:1:0711/212646.857866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , document.readyState
[1:1:0711/212646.858196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212646.964312:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://widget.weibo.com/
[1:1:0711/212646.988952:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212646.989464:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/212647.219360:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 627, 7ff467de48db
[1:1:0711/212647.256191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"533 0x7ff46549f070 0x4d0617758e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212647.256551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"533 0x7ff46549f070 0x4d0617758e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212647.257107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 709
[1:1:0711/212647.257372:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7ff46549f070 0x4d061cf4fe0 , 5:3_http://guide.qunar.com/, 0, , 627 0x7ff46549f070 0x4d06190d460 
[1:1:0711/212647.257749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212647.258480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212647.258747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212647.294942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212647.295477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 713
[1:1:0711/212647.295679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7ff46549f070 0x4d0625fa7e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 627 0x7ff46549f070 0x4d06190d460 
[1:1:0711/212647.723485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 662 0x7ff4673c72e0 0x4d061ab4860 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212647.726731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (function(S){var d=function(a,b){return (a-91)^b},f=function(a,b){return a+41-b},g=function(a,b){ret
[1:1:0711/212647.726940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
		remove user.11_5eaf92c5 -> 0
		remove user.12_d70886ea -> 0
[16797:16797:0711/212707.651269:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/212708.419713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 663 0x7ff4673c72e0 0x4d061d722e0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.420795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0711/212708.421014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212708.455854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 1000
[1:1:0711/212708.456451:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 749
[1:1:0711/212708.456690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7ff46549f070 0x4d061ffbce0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 663 0x7ff4673c72e0 0x4d061d722e0 
[1:1:0711/212708.488615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.615969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 516, 7ff467de48db
[1:1:0711/212708.647874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"262 0x7ff46549f070 0x4d0612cd760 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.648207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"262 0x7ff46549f070 0x4d0612cd760 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.648615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 760
[1:1:0711/212708.648845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7ff46549f070 0x4d0697d1ae0 , 5:3_http://guide.qunar.com/, 0, , 516 0x7ff46549f070 0x4d06157e460 
[1:1:0711/212708.649149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.649786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212708.650000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212708.721544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 631, 7ff467de48db
[1:1:0711/212708.753792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"456 0x7ff46549f070 0x4d06177c8e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.754101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"456 0x7ff46549f070 0x4d06177c8e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.754479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 762
[1:1:0711/212708.754729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 762 0x7ff46549f070 0x4d062312d60 , 5:3_http://guide.qunar.com/, 0, , 631 0x7ff46549f070 0x4d061a22360 
[1:1:0711/212708.755017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.755645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){show(1)}
[1:1:0711/212708.755881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212708.777202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 669, 7ff467de4881
[1:1:0711/212708.809707:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"619 0x7ff4673c72e0 0x4d0617b97e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.810058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"619 0x7ff4673c72e0 0x4d0617b97e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.810436:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.811077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){l(e,t)}
[1:1:0711/212708.811310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212708.814316:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212708.814543:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 1
[1:1:0711/212708.814986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 764
[1:1:0711/212708.815211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7ff46549f070 0x4d069aafb60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 669 0x7ff46549f070 0x4d061c7c2e0 
[1:1:0711/212708.867965:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 678, 7ff467de4881
[1:1:0711/212708.899785:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"628 0x7ff46549f070 0x4d061a70ae0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.900140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"628 0x7ff46549f070 0x4d061a70ae0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212708.900637:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212708.901428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212708.901661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212708.952636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , document.readyState
[1:1:0711/212708.952933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[16797:16797:0711/212709.135465:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://widget.weibo.com/, https://widget.weibo.com/, 4
[16797:16797:0711/212709.135571:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://widget.weibo.com/, https://widget.weibo.com
[1:1:0711/212710.014144:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 713, 7ff467de48db
[1:1:0711/212710.049778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"627 0x7ff46549f070 0x4d06190d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.050134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"627 0x7ff46549f070 0x4d06190d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.050544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 797
[1:1:0711/212710.050770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 797 0x7ff46549f070 0x4d069adc260 , 5:3_http://guide.qunar.com/, 0, , 713 0x7ff46549f070 0x4d0625fa7e0 
[1:1:0711/212710.051103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.051713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212710.051990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212710.053058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212710.053252:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212710.053682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 798
[1:1:0711/212710.053917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7ff46549f070 0x4d069a4b1e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 713 0x7ff46549f070 0x4d0625fa7e0 
[1:1:0711/212710.202408:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 722 0x7ff4673c72e0 0x4d061cb6ae0 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.204336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0711/212710.204586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212710.239457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.553554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 709, 7ff467de48db
[1:1:0711/212710.587770:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7ff46549f070 0x4d06190d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.588115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7ff46549f070 0x4d06190d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.588520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 812
[1:1:0711/212710.588777:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7ff46549f070 0x4d069b19960 , 5:3_http://guide.qunar.com/, 0, , 709 0x7ff46549f070 0x4d061cf4fe0 
[1:1:0711/212710.589181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.589993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212710.590286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212710.615235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212710.615743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 817
[1:1:0711/212710.616019:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7ff46549f070 0x4d069afc960 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 709 0x7ff46549f070 0x4d061cf4fe0 
[1:1:0711/212710.617749:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 232, 7ff467de4881
[1:1:0711/212710.651554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"196 0x7ff46549f070 0x4d060d08f60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.651972:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"196 0x7ff46549f070 0x4d060d08f60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.652450:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.653136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , P, (){s=0;var e=n.getCookie("QN44");if(l===0||v==="half"||i()){B();if(l===0){j(true)}else if(v==="login
[1:1:0711/212710.653408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212710.661872:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212710.662151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 15000
[1:1:0711/212710.662605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 822
[1:1:0711/212710.662840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 822 0x7ff46549f070 0x4d069aff5e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 232 0x7ff46549f070 0x4d06075b2e0 
[1:1:0711/212710.699195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 670, 7ff467de4881
[1:1:0711/212710.717982:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"619 0x7ff4673c72e0 0x4d0617b97e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.718355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"619 0x7ff4673c72e0 0x4d0617b97e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212710.718717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.719389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){throw new Error("load "+n+" timeout : "+t)}
[1:1:0711/212710.719659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212710.721781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212710.723421:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[16797:16797:0711/212710.732020:INFO:CONSOLE(1)] "Uncaught Error: load css timeout : http://bdimg.share.baidu.com/static/api/css/share_style0_16.css?v=8105b07e.css", source: http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=434139 (1)
[1:1:0711/212711.190257:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 756 0x7ff4673c72e0 0x4d069a51960 , "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212711.191294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , callback_1562905628400('a20f51d4-abad-44ec-a026-0cfe30ea5cba')
[1:1:0711/212711.191524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212711.241641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 764, 7ff467de4881
[1:1:0711/212711.277258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"669 0x7ff46549f070 0x4d061c7c2e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212711.277639:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"669 0x7ff46549f070 0x4d061c7c2e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212711.277992:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212711.278617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){n?t&&t():l(e,t)}
[1:1:0711/212711.278827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212711.414764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , document.readyState
[1:1:0711/212711.415064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212711.943759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 749, 7ff467de48db
[1:1:0711/212711.979008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"663 0x7ff4673c72e0 0x4d061d722e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212711.979365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"663 0x7ff4673c72e0 0x4d061d722e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212711.979851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 846
[1:1:0711/212711.980082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7ff46549f070 0x4d061ced4e0 , 5:3_http://guide.qunar.com/, 0, , 749 0x7ff46549f070 0x4d061ffbce0 
[1:1:0711/212711.980384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212711.981002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212711.981214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.127607:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 798, 7ff467de4881
[1:1:0711/212712.161983:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"713 0x7ff46549f070 0x4d0625fa7e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.162325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"713 0x7ff46549f070 0x4d0625fa7e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.162742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.163345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212712.163599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.165894:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 762, 7ff467de48db
[1:1:0711/212712.194740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"631 0x7ff46549f070 0x4d061a22360 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.195067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"631 0x7ff46549f070 0x4d061a22360 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.195478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 847
[1:1:0711/212712.195791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7ff46549f070 0x4d069b44c60 , 5:3_http://guide.qunar.com/, 0, , 762 0x7ff46549f070 0x4d062312d60 
[1:1:0711/212712.196093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.196738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){show(1)}
[1:1:0711/212712.196975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.480286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 817, 7ff467de48db
[1:1:0711/212712.515856:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"709 0x7ff46549f070 0x4d061cf4fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.516204:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"709 0x7ff46549f070 0x4d061cf4fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.516622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 853
[1:1:0711/212712.516867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7ff46549f070 0x4d061eeede0 , 5:3_http://guide.qunar.com/, 0, , 817 0x7ff46549f070 0x4d069afc960 
[1:1:0711/212712.517199:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.517831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212712.518040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.519140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212712.519335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212712.519815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 854
[1:1:0711/212712.520039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 854 0x7ff46549f070 0x4d069b44ee0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 817 0x7ff46549f070 0x4d069afc960 
[1:1:0711/212712.647762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 760, 7ff467de48db
[1:1:0711/212712.682973:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"516 0x7ff46549f070 0x4d06157e460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.683291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"516 0x7ff46549f070 0x4d06157e460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212712.683743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 858
[1:1:0711/212712.683975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7ff46549f070 0x4d069aac8e0 , 5:3_http://guide.qunar.com/, 0, , 760 0x7ff46549f070 0x4d0697d1ae0 
[1:1:0711/212712.684266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.684924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212712.685139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.743934:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.744705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0711/212712.744950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.814602:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.815375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0711/212712.815606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212712.819036:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.819680:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.826583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212712.908887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , document.readyState
[1:1:0711/212712.909144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212713.037007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 812, 7ff467de48db
[1:1:0711/212713.072832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7ff46549f070 0x4d061cf4fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.073139:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7ff46549f070 0x4d061cf4fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.073546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 878
[1:1:0711/212713.073815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7ff46549f070 0x4d0622159e0 , 5:3_http://guide.qunar.com/, 0, , 812 0x7ff46549f070 0x4d069b19960 
[1:1:0711/212713.074144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212713.074771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212713.075028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212713.103737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212713.104320:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 880
[1:1:0711/212713.104554:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7ff46549f070 0x4d0610c41e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 812 0x7ff46549f070 0x4d069b19960 
[1:1:0711/212713.147145:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 846, 7ff467de48db
[1:1:0711/212713.180530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"749 0x7ff46549f070 0x4d061ffbce0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.180830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"749 0x7ff46549f070 0x4d061ffbce0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.181209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 890
[1:1:0711/212713.181433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7ff46549f070 0x4d0625b35e0 , 5:3_http://guide.qunar.com/, 0, , 846 0x7ff46549f070 0x4d061ced4e0 
[1:1:0711/212713.181712:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212713.182327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212713.182537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212713.216525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 854, 7ff467de4881
[1:1:0711/212713.275725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"817 0x7ff46549f070 0x4d069afc960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.276177:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"817 0x7ff46549f070 0x4d069afc960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212713.276594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212713.277266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212713.277527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.136954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 880, 7ff467de48db
[1:1:0711/212714.187366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"812 0x7ff46549f070 0x4d069b19960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.187897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"812 0x7ff46549f070 0x4d069b19960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.188363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 903
[1:1:0711/212714.188716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7ff46549f070 0x4d0610c2160 , 5:3_http://guide.qunar.com/, 0, , 880 0x7ff46549f070 0x4d0610c41e0 
[1:1:0711/212714.189315:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.190412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212714.190752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.192804:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212714.193107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212714.193899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 904
[1:1:0711/212714.194293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7ff46549f070 0x4d0610c0b60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 880 0x7ff46549f070 0x4d0610c41e0 
[1:1:0711/212714.253019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 878, 7ff467de48db
[1:1:0711/212714.288389:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"812 0x7ff46549f070 0x4d069b19960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.288668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"812 0x7ff46549f070 0x4d069b19960 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.289028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 909
[1:1:0711/212714.289272:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7ff46549f070 0x4d069bc68e0 , 5:3_http://guide.qunar.com/, 0, , 878 0x7ff46549f070 0x4d0622159e0 
[1:1:0711/212714.289571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.290651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212714.290896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.326791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212714.327290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 910
[1:1:0711/212714.327518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 910 0x7ff46549f070 0x4d069c7d4e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 878 0x7ff46549f070 0x4d0622159e0 
[1:1:0711/212714.329335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 847, 7ff467de48db
[1:1:0711/212714.365902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"762 0x7ff46549f070 0x4d062312d60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.366189:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"762 0x7ff46549f070 0x4d062312d60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.366571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 913
[1:1:0711/212714.366797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7ff46549f070 0x4d069b513e0 , 5:3_http://guide.qunar.com/, 0, , 847 0x7ff46549f070 0x4d069b44c60 
[1:1:0711/212714.367081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.367661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){show(1)}
[1:1:0711/212714.367902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.482842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.483657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , c.img.onload.c.img.onerror, (){c.img=null}
[1:1:0711/212714.483918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.485457:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 890, 7ff467de48db
[1:1:0711/212714.524360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"846 0x7ff46549f070 0x4d061ced4e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.524877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"846 0x7ff46549f070 0x4d061ced4e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.525689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 920
[1:1:0711/212714.526090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7ff46549f070 0x4d069c52860 , 5:3_http://guide.qunar.com/, 0, , 890 0x7ff46549f070 0x4d0625b35e0 
[1:1:0711/212714.526652:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.527921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212714.528357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.759031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 904, 7ff467de4881
[1:1:0711/212714.803857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"880 0x7ff46549f070 0x4d0610c41e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.804238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"880 0x7ff46549f070 0x4d0610c41e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.804709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.805464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212714.805726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.807376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 910, 7ff467de48db
[1:1:0711/212714.847954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"878 0x7ff46549f070 0x4d0622159e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.848327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"878 0x7ff46549f070 0x4d0622159e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212714.848772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 936
[1:1:0711/212714.849009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7ff46549f070 0x4d0610c03e0 , 5:3_http://guide.qunar.com/, 0, , 910 0x7ff46549f070 0x4d069c7d4e0 
[1:1:0711/212714.849331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212714.849991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212714.850209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212714.851324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212714.851548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212714.852013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 937
[1:1:0711/212714.852239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7ff46549f070 0x4d069c97fe0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 910 0x7ff46549f070 0x4d069c7d4e0 
[1:1:0711/212715.194742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 909, 7ff467de48db
[1:1:0711/212715.223634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"878 0x7ff46549f070 0x4d0622159e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.223952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"878 0x7ff46549f070 0x4d0622159e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.224401:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 947
[1:1:0711/212715.224655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7ff46549f070 0x4d060a3d460 , 5:3_http://guide.qunar.com/, 0, , 909 0x7ff46549f070 0x4d069bc68e0 
[1:1:0711/212715.224963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212715.225823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212715.226131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212715.267171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212715.267824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 948
[1:1:0711/212715.268071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 948 0x7ff46549f070 0x4d061d59d60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 909 0x7ff46549f070 0x4d069bc68e0 
[1:1:0711/212715.446640:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 937, 7ff467de4881
[1:1:0711/212715.486567:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"910 0x7ff46549f070 0x4d069c7d4e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.487001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"910 0x7ff46549f070 0x4d069c7d4e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.487346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212715.488010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212715.488229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212715.566159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 948, 7ff467de48db
[1:1:0711/212715.604339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"909 0x7ff46549f070 0x4d069bc68e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.604792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"909 0x7ff46549f070 0x4d069bc68e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.605265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 960
[1:1:0711/212715.605553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7ff46549f070 0x4d069c98ae0 , 5:3_http://guide.qunar.com/, 0, , 948 0x7ff46549f070 0x4d061d59d60 
[1:1:0711/212715.605964:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212715.606702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212715.606982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212715.608166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212715.608423:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212715.608931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 961
[1:1:0711/212715.609222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7ff46549f070 0x4d069afe9e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 948 0x7ff46549f070 0x4d061d59d60 
[1:1:0711/212715.932185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 920, 7ff467de48db
[1:1:0711/212715.978122:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"890 0x7ff46549f070 0x4d0625b35e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.978503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"890 0x7ff46549f070 0x4d0625b35e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212715.978951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 966
[1:1:0711/212715.979215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7ff46549f070 0x4d069c7d1e0 , 5:3_http://guide.qunar.com/, 0, , 920 0x7ff46549f070 0x4d069c52860 
[1:1:0711/212715.979535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212715.980094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212715.980376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.100303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 961, 7ff467de4881
[1:1:0711/212716.134809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"948 0x7ff46549f070 0x4d061d59d60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.135162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"948 0x7ff46549f070 0x4d061d59d60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.135541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.136277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212716.136526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.138003:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 858, 7ff467de48db
[1:1:0711/212716.177123:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"760 0x7ff46549f070 0x4d0697d1ae0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.177445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"760 0x7ff46549f070 0x4d0697d1ae0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.177864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 973
[1:1:0711/212716.178105:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7ff46549f070 0x4d069af9860 , 5:3_http://guide.qunar.com/, 0, , 858 0x7ff46549f070 0x4d069aac8e0 
[1:1:0711/212716.178402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.179038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){m[l(s(228,52),a(10452,39),o(5917,15))](false,false)}
[1:1:0711/212716.179255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.375661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 947, 7ff467de48db
[1:1:0711/212716.415807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"909 0x7ff46549f070 0x4d069bc68e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.416201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"909 0x7ff46549f070 0x4d069bc68e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.416630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 979
[1:1:0711/212716.416869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7ff46549f070 0x4d061cf51e0 , 5:3_http://guide.qunar.com/, 0, , 947 0x7ff46549f070 0x4d060a3d460 
[1:1:0711/212716.417214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.417836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212716.418095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.449670:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212716.449957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212716.450446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 980
[1:1:0711/212716.450696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 980 0x7ff46549f070 0x4d0625b3ee0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 947 0x7ff46549f070 0x4d060a3d460 
[1:1:0711/212716.452832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212716.453299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 981
[1:1:0711/212716.453526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7ff46549f070 0x4d069e39fe0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 947 0x7ff46549f070 0x4d060a3d460 
[1:1:0711/212716.455118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 913, 7ff467de48db
[1:1:0711/212716.490959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"847 0x7ff46549f070 0x4d069b44c60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.491311:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"847 0x7ff46549f070 0x4d069b44c60 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.491721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 984
[1:1:0711/212716.492017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7ff46549f070 0x4d069ccade0 , 5:3_http://guide.qunar.com/, 0, , 913 0x7ff46549f070 0x4d069b513e0 
[1:1:0711/212716.492323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.492971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){show(1)}
[1:1:0711/212716.493192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.518152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 980, 7ff467de4881
[1:1:0711/212716.551459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.551816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.552180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.552783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212716.553014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.554438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 966, 7ff467de48db
[1:1:0711/212716.593082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"920 0x7ff46549f070 0x4d069c52860 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.593391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"920 0x7ff46549f070 0x4d069c52860 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.593786:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 987
[1:1:0711/212716.594035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7ff46549f070 0x4d069d3ffe0 , 5:3_http://guide.qunar.com/, 0, , 966 0x7ff46549f070 0x4d069c7d1e0 
[1:1:0711/212716.594335:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.594926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212716.595153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.596741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 981, 7ff467de48db
[1:1:0711/212716.626569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.626915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.627323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 988
[1:1:0711/212716.627560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7ff46549f070 0x4d069e486e0 , 5:3_http://guide.qunar.com/, 0, , 981 0x7ff46549f070 0x4d069e39fe0 
[1:1:0711/212716.627922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.628550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , tick, (){var e,t=s.timers,n=0;for(;n<t.length;n++){e=t[n];if(!e()&&t[n]===e){t.splice(n--,1)}}if(!t.length
[1:1:0711/212716.628768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212716.629876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212716.630097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212716.630546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 989
[1:1:0711/212716.630778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 989 0x7ff46549f070 0x4d061d79360 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 981 0x7ff46549f070 0x4d069e39fe0 
[1:1:0711/212716.643469:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 989, 7ff467de4881
[1:1:0711/212716.663188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"981 0x7ff46549f070 0x4d069e39fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.663510:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"981 0x7ff46549f070 0x4d069e39fe0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212716.663891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212716.664571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0711/212716.664789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212717.510607:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 987, 7ff467de48db
[1:1:0711/212717.534485:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"966 0x7ff46549f070 0x4d069c7d1e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212717.534872:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"966 0x7ff46549f070 0x4d069c7d1e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212717.535348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 996
[1:1:0711/212717.535662:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7ff46549f070 0x4d0606eaae0 , 5:3_http://guide.qunar.com/, 0, , 987 0x7ff46549f070 0x4d069d3ffe0 
[1:1:0711/212717.535977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212717.536659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , (){document.hasFocus()&&s++}
[1:1:0711/212717.536898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212717.850535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 979, 7ff467de48db
[1:1:0711/212717.894795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212717.895205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"947 0x7ff46549f070 0x4d060a3d460 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0711/212717.895736:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 998
[1:1:0711/212717.896089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7ff46549f070 0x4d069d590e0 , 5:3_http://guide.qunar.com/, 0, , 979 0x7ff46549f070 0x4d061cf51e0 
[1:1:0711/212717.896490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0711/212717.897282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , , ()
	{
		count(-1);
	}
[1:1:0711/212717.897584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
[1:1:0711/212717.935245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x284501ac29c8, 0x4d060685950
[1:1:0711/212717.935558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 0
[1:1:0711/212717.936079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 999
[1:1:0711/212717.936335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7ff46549f070 0x4d069e725e0 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 979 0x7ff46549f070 0x4d061cf51e0 
[1:1:0711/212717.938425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text", 13
[1:1:0711/212717.938893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://guide.qunar.com/, 1000
[1:1:0711/212717.939152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7ff46549f070 0x4d069e72d60 , 5:3_http://guide.qunar.com/, 1, -5:3_http://guide.qunar.com/, 979 0x7ff46549f070 0x4d061cf51e0 
[1:1:0711/212717.940115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://guide.qunar.com/, 999, 7ff467de4881
[1:1:0100/000000.983436:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"05a186962860","ptid":"979 0x7ff46549f070 0x4d061cf51e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0100/000000.004601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://guide.qunar.com/","ptid":"979 0x7ff46549f070 0x4d061cf51e0 ","rf":"5:3_http://guide.qunar.com/"}
[1:1:0100/000000.004991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://guide.qunar.com/krabi.htm?from=quner_index_text"
[1:1:0100/000000.005847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://guide.qunar.com/, 05a186962860, , bn, (){gn=t}
[1:1:0100/000000.006059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://guide.qunar.com/krabi.htm?from=quner_index_text", "guide.qunar.com", 3, 1, , , 0
