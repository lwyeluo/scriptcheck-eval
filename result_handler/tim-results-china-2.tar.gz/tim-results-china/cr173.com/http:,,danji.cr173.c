[0712/074331.511253:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/074331.511688:INFO:switcher_clone.cc(787)] backtrace rip is 7f20bb2e8891
[0712/074332.678557:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/074332.678915:INFO:switcher_clone.cc(787)] backtrace rip is 7f6f2b09b891
[1:1:0712/074332.690594:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/074332.690857:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/074332.699356:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[103020:103020:0712/074334.326375:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/074334.382293:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/074334.382557:INFO:switcher_clone.cc(787)] backtrace rip is 7f6032298891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4449e9dd-fb4e-43c1-88e7-d685f99d9dd9
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[103054:103054:0712/074334.647663:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=103054
[103066:103066:0712/074334.649019:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=103066
[103020:103020:0712/074334.946914:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[103020:103052:0712/074334.949488:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/074334.949874:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/074334.950113:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/074334.950754:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/074334.950920:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/074334.954176:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x14bbdac0, 1
[1:1:0712/074334.954666:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8f6996a, 0
[1:1:0712/074334.954919:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xa6991b1, 3
[1:1:0712/074334.955200:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3fd45878, 2
[1:1:0712/074334.955587:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6affffff99fffffff608 ffffffc0ffffffdaffffffbb14 7858ffffffd43f ffffffb1ffffff91690a , 10104, 4
[1:1:0712/074334.956984:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[103020:103052:0712/074334.957335:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGj���ڻxX�?��i
��	
[1:1:0712/074334.957295:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f292d60a0, 3
[103020:103052:0712/074334.957489:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is j���ڻxX�?��i
����	
[1:1:0712/074334.957536:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f29461080, 2
[1:1:0712/074334.957731:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f13124d20, -2
[103020:103052:0712/074334.957930:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[103020:103052:0712/074334.958101:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 103074, 4, 6a99f608 c0dabb14 7858d43f b191690a 
[1:1:0712/074334.978907:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/074334.979791:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fd45878
[1:1:0712/074334.980836:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fd45878
[1:1:0712/074334.982518:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fd45878
[1:1:0712/074334.984080:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.984347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.984540:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.984741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.985451:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fd45878
[1:1:0712/074334.985774:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6f2b09b7ba
[1:1:0712/074334.985912:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6f2b092def, 7f6f2b09b77a, 7f6f2b09d0cf
[1:1:0712/074334.991853:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fd45878
[1:1:0712/074334.992240:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fd45878
[1:1:0712/074334.993001:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fd45878
[1:1:0712/074334.995135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.995369:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.995584:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.995773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fd45878
[1:1:0712/074334.997074:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fd45878
[1:1:0712/074334.997472:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6f2b09b7ba
[1:1:0712/074334.997643:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6f2b092def, 7f6f2b09b77a, 7f6f2b09d0cf
[1:1:0712/074335.005793:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/074335.006265:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/074335.006417:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffec82eea98, 0x7ffec82eea18)
[1:1:0712/074335.039598:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/074335.046095:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[103020:103020:0712/074335.669976:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[103020:103020:0712/074335.671067:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[103020:103020:0712/074335.677989:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[103020:103020:0712/074335.678038:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[103020:103020:0712/074335.678100:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,103074, 4
[103020:103033:0712/074335.683848:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[103020:103033:0712/074335.683914:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/074335.686108:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[103020:103046:0712/074335.758818:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/074335.787401:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1c820a5e1220
[1:1:0712/074335.787691:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/074336.243725:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/074337.494652:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074337.498475:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[103020:103020:0712/074337.743446:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[103020:103020:0712/074337.743552:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/074338.474314:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/074338.723059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/074338.723336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074338.737333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/074338.737530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074338.838553:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/074338.838770:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074339.355511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074339.363534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/074339.363740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074339.392775:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074339.395864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/074339.395989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074339.399889:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[103020:103020:0712/074339.403675:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/074339.408075:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1c820a5dfe20
[1:1:0712/074339.408611:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[103020:103020:0712/074339.418869:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[103020:103020:0712/074339.453759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[103020:103020:0712/074339.453911:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/074339.516182:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074340.107352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f6f14cff2e0 0x1c820a875060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074340.108124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/074340.108251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074340.108875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[103020:103020:0712/074340.155849:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/074340.159907:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1c820a5e0820
[1:1:0712/074340.160466:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[103020:103020:0712/074340.168870:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/074340.175492:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/074340.175675:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[103020:103020:0712/074340.193680:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[103020:103020:0712/074340.204111:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[103020:103020:0712/074340.205195:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[103020:103033:0712/074340.211669:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[103020:103033:0712/074340.211768:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[103020:103020:0712/074340.211906:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[103020:103020:0712/074340.211988:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[103020:103020:0712/074340.212131:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,103074, 4
[1:7:0712/074340.215965:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/074340.781609:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/074341.432465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f6f14cff2e0 0x1c820a99d660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074341.433550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/074341.433785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074341.434560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[103020:103020:0712/074341.782594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[103020:103020:0712/074341.782681:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/074341.804988:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/074342.217090:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[103020:103020:0712/074342.235434:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[103020:103052:0712/074342.236414:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/074342.236964:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/074342.237460:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/074342.238565:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/074342.239063:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/074342.246424:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26f24675, 1
[1:1:0712/074342.247259:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f4136b0, 0
[1:1:0712/074342.247497:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x14e3be0e, 3
[1:1:0712/074342.247684:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15716f6, 2
[1:1:0712/074342.248031:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb036411f 7546fffffff226 fffffff6165701 0effffffbeffffffe314 , 10104, 5
[1:1:0712/074342.249572:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[103020:103052:0712/074342.249987:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�6AuF�&�W�����	
[103020:103052:0712/074342.250086:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �6AuF�&�W�����	
[1:1:0712/074342.250236:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f292d60a0, 3
[1:1:0712/074342.250515:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f29461080, 2
[1:1:0712/074342.250749:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6f13124d20, -2
[103020:103052:0712/074342.250748:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 103120, 5, b036411f 7546f226 f6165701 0ebee314 
[1:1:0712/074342.289422:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/074342.289966:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15716f6
[1:1:0712/074342.290426:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15716f6
[1:1:0712/074342.291343:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15716f6
[1:1:0712/074342.293264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.293392:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.293503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.293605:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.293862:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15716f6
[1:1:0712/074342.294034:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6f2b09b7ba
[1:1:0712/074342.294116:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6f2b092def, 7f6f2b09b77a, 7f6f2b09d0cf
[1:1:0712/074342.295646:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15716f6
[1:1:0712/074342.295822:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15716f6
[1:1:0712/074342.296166:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15716f6
[1:1:0712/074342.296909:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.297042:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.297146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.297253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15716f6
[1:1:0712/074342.297718:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15716f6
[1:1:0712/074342.297926:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6f2b09b7ba
[1:1:0712/074342.298042:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6f2b092def, 7f6f2b09b77a, 7f6f2b09d0cf
[1:1:0712/074342.300390:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/074342.300751:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/074342.300852:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffec82eea98, 0x7ffec82eea18)
[1:1:0712/074342.316320:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/074342.321011:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/074342.505875:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/074342.506256:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/074342.590983:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1c820a5ac220
[1:1:0712/074342.591387:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[103020:103020:0712/074342.862679:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[103020:103020:0712/074342.868151:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[103020:103033:0712/074342.905353:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[103020:103033:0712/074342.905458:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[103020:103020:0712/074342.905856:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://danji.cr173.com/
[103020:103020:0712/074342.905942:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://danji.cr173.com/, http://danji.cr173.com/, 1
[103020:103020:0712/074342.906115:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://danji.cr173.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 14:43:42 GMT Content-Type: text/html; Charset=GB2312 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Cache-Control: max-age=1800 Server: Microsoft-IIS/7.5 Set-Cookie: ASPSESSIONIDSATDTBSQ=IBJHGCBACAJPJBGJKOBIKGNB; path=/ X-Powered-By: ASP.NET Expires: Fri, 12 Jul 2019 15:13:42 GMT Content-Encoding: gzip  ,103120, 5
[1:7:0712/074342.909861:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/074342.958467:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://danji.cr173.com/
[1:1:0712/074342.997914:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/074343.003399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2a0faafee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/074343.003786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/074343.012522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[103020:103020:0712/074343.090675:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://danji.cr173.com/, http://danji.cr173.com/, 1
[103020:103020:0712/074343.090773:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://danji.cr173.com/, http://danji.cr173.com
[1:1:0712/074343.133971:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/074343.227055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/074343.249348:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/074343.260349:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/074343.260463:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://danji.cr173.com/"
[1:1:0712/074343.364914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/074343.365688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2a0faaec1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/074343.365912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/074343.630404:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/074343.861477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f6f29461080 0x1c820a6fb560 1 0 0x1c820a6fb578 , "http://danji.cr173.com/"
[1:1:0712/074343.881358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/074343.881573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074343.906810:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.097683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7f6f29461080 0x1c820a6ffba0 1 0 0x1c820a6ffbb8 , "http://danji.cr173.com/"
[1:1:0712/074344.101351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , // 为了兼容list 文件夹下的2013年之前老页面
!function(a,b){"object"==typeof module&&"
[1:1:0712/074344.101503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/074344.592883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.593350:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.593787:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.594197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.594558:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074344.890209:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.54898, 3542, 0
[1:1:0712/074344.890520:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/074348.529237:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/074348.529496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://danji.cr173.com/"
[1:1:0712/074348.623337:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0938351, 619, 1
[1:1:0712/074348.623650:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/074355.541342:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/074355.541517:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://danji.cr173.com/"
[1:1:0712/074355.542933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 588 0x7f6f12dd7070 0x1c820ac2c9e0 , "http://danji.cr173.com/"
[1:1:0712/074355.543643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , //百度统计(总)
var _hmt = _hmt || [];
var _hmUrl = 'https://hm.baidu.com/hm.js?';
$(function
[1:1:0712/074355.543757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074355.546442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 588 0x7f6f12dd7070 0x1c820ac2c9e0 , "http://danji.cr173.com/"
[1:1:0712/074355.550500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 588 0x7f6f12dd7070 0x1c820ac2c9e0 , "http://danji.cr173.com/"
[1:1:0712/074355.611685:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://danji.cr173.com/"
[1:1:0712/074357.868047:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://danji.cr173.com/"
[103020:103020:0712/074405.641164:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/074405.751229:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/074412.519972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/074412.520285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074414.389578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7f6f14cff2e0 0x1c820b58f760 , "http://danji.cr173.com/"
[1:1:0712/074414.390147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , var returnCitySN = {"cip": "218.241.135.34", "cid": "110000", "cname": "北京市"};
[1:1:0712/074414.390266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074414.390622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://danji.cr173.com/"
[1:1:0712/074414.455735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067 0x7f6f14cff2e0 0x1c820aeeb060 , "http://danji.cr173.com/"
[1:1:0712/074414.470309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , (function(){var h={},mt={},c={id:"e32b0486ce2e2f6870da86b348af9816",dm:["cr173.com"],js:"tongji.baid
[1:1:0712/074414.470630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074414.482378:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/074414.488611:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f990
[1:1:0712/074414.488735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074414.488897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1131
[1:1:0712/074414.489001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1131 0x7f6f12dd7070 0x1c820a6b9fe0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1067 0x7f6f14cff2e0 0x1c820aeeb060 
[1:1:0712/074415.540550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , document.readyState
[1:1:0712/074415.540826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074418.600670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1131, 7f6f1571c881
[1:1:0712/074418.627909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1067 0x7f6f14cff2e0 0x1c820aeeb060 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074418.628268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1067 0x7f6f14cff2e0 0x1c820aeeb060 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074418.628718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074418.629273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074418.629498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074418.630270:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074418.630503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074418.630874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1228
[1:1:0712/074418.631108:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1228 0x7f6f12dd7070 0x1c820a99d060 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1131 0x7f6f12dd7070 0x1c820a6b9fe0 
[1:1:0712/074418.936323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , document.readyState
[1:1:0712/074418.936652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074421.530628:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://danji.cr173.com/"
[1:1:0712/074421.531835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/074421.532202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074421.543529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://danji.cr173.com/"
[1:1:0712/074421.584998:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://danji.cr173.com/"
[1:1:0712/074421.589352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://danji.cr173.com/"
[1:1:0712/074421.590962:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6faf0
[1:1:0712/074421.591221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074421.591682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1276
[1:1:0712/074421.591992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1276 0x7f6f12dd7070 0x1c820ab77760 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1230 0x7f6f12dd7070 0x1c820ab7cc60 
[1:1:0712/074421.731521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , , document.readyState
[1:1:0712/074421.731871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074422.507162:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1276, 7f6f1571c881
[1:1:0712/074422.571506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1230 0x7f6f12dd7070 0x1c820ab7cc60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074422.571923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1230 0x7f6f12dd7070 0x1c820ab7cc60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074422.572360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074422.572919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074422.573137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074422.573988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074422.574206:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074422.574585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1300
[1:1:0712/074422.574814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7f6f12dd7070 0x1c820ac27de0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1276 0x7f6f12dd7070 0x1c820ab77760 
[1:1:0712/074422.685295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1300, 7f6f1571c881
[1:1:0712/074422.742580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1276 0x7f6f12dd7070 0x1c820ab77760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074422.742980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1276 0x7f6f12dd7070 0x1c820ab77760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074422.743512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074422.744166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074422.744413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074422.745110:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074422.745332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074422.745729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1308
[1:1:0712/074422.745966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7f6f12dd7070 0x1c820c5ce7e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1300 0x7f6f12dd7070 0x1c820ac27de0 
[1:1:0712/074422.950021:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://danji.cr173.com/favicon.ico"
[1:1:0712/074423.078544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1308, 7f6f1571c881
[1:1:0712/074423.114356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1300 0x7f6f12dd7070 0x1c820ac27de0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.114764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1300 0x7f6f12dd7070 0x1c820ac27de0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.115164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074423.115739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074423.116002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074423.116703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074423.116902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074423.117266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1324
[1:1:0712/074423.117512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7f6f12dd7070 0x1c820a863760 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1308 0x7f6f12dd7070 0x1c820c5ce7e0 
[1:1:0712/074423.290672:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1324, 7f6f1571c881
[1:1:0712/074423.345501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1308 0x7f6f12dd7070 0x1c820c5ce7e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.345935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1308 0x7f6f12dd7070 0x1c820c5ce7e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.346340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074423.346925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074423.347147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074423.348109:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074423.348340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074423.348746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1331
[1:1:0712/074423.348981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1331 0x7f6f12dd7070 0x1c820b583c60 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1324 0x7f6f12dd7070 0x1c820a863760 
[1:1:0712/074423.487118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1331, 7f6f1571c881
[1:1:0712/074423.545639:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1324 0x7f6f12dd7070 0x1c820a863760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.546043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1324 0x7f6f12dd7070 0x1c820a863760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.546467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074423.547096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074423.547340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074423.552380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074423.552711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074423.553135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1338
[1:1:0712/074423.553375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f6f12dd7070 0x1c820c5df9e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1331 0x7f6f12dd7070 0x1c820b583c60 
[1:1:0712/074423.666925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1338, 7f6f1571c881
[1:1:0712/074423.722994:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1331 0x7f6f12dd7070 0x1c820b583c60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.723358:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1331 0x7f6f12dd7070 0x1c820b583c60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074423.723823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074423.724383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074423.724619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074423.725288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074423.725483:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074423.725867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1343
[1:1:0712/074423.726096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7f6f12dd7070 0x1c820a8ec0e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1338 0x7f6f12dd7070 0x1c820c5df9e0 
[1:1:0712/074423.952814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1343, 7f6f1571c881
[1:1:0712/074424.007176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1338 0x7f6f12dd7070 0x1c820c5df9e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.007600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1338 0x7f6f12dd7070 0x1c820c5df9e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.008107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074424.008687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074424.008921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074424.009593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074424.009835:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074424.010218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1353
[1:1:0712/074424.010449:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7f6f12dd7070 0x1c820a966760 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1343 0x7f6f12dd7070 0x1c820a8ec0e0 
[1:1:0712/074424.112536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1353, 7f6f1571c881
[1:1:0712/074424.174086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1343 0x7f6f12dd7070 0x1c820a8ec0e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.174505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1343 0x7f6f12dd7070 0x1c820a8ec0e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.174930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074424.175489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074424.175789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074424.176477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074424.176703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074424.177075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1360
[1:1:0712/074424.177304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1360 0x7f6f12dd7070 0x1c820a5f82e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1353 0x7f6f12dd7070 0x1c820a966760 
[1:1:0712/074424.416408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1360, 7f6f1571c881
[1:1:0712/074424.483892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1353 0x7f6f12dd7070 0x1c820a966760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.484330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1353 0x7f6f12dd7070 0x1c820a966760 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.484750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074424.485324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074424.485542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074424.486234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074424.486434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074424.486832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1370
[1:1:0712/074424.487084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7f6f12dd7070 0x1c820a8dfa60 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1360 0x7f6f12dd7070 0x1c820a5f82e0 
[1:1:0712/074424.733820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1370, 7f6f1571c881
[1:1:0712/074424.757242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1360 0x7f6f12dd7070 0x1c820a5f82e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.757587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1360 0x7f6f12dd7070 0x1c820a5f82e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074424.757984:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074424.758520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074424.758727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074424.759441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074424.759632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074424.760053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1382
[1:1:0712/074424.760292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1382 0x7f6f12dd7070 0x1c820a9991e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1370 0x7f6f12dd7070 0x1c820a8dfa60 
[1:1:0712/074424.978291:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1382, 7f6f1571c881
[1:1:0712/074425.048761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1370 0x7f6f12dd7070 0x1c820a8dfa60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.049216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1370 0x7f6f12dd7070 0x1c820a8dfa60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.049622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074425.050199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074425.050431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074425.051137:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074425.051340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074425.051711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1393
[1:1:0712/074425.052081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1393 0x7f6f12dd7070 0x1c820affaf60 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1382 0x7f6f12dd7070 0x1c820a9991e0 
[1:1:0712/074425.217655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1393, 7f6f1571c881
[1:1:0712/074425.258197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1382 0x7f6f12dd7070 0x1c820a9991e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.258590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1382 0x7f6f12dd7070 0x1c820a9991e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.259028:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074425.259586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074425.259839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074425.260547:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074425.260743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074425.261136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1402
[1:1:0712/074425.261394:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1402 0x7f6f12dd7070 0x1c820af3f8e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1393 0x7f6f12dd7070 0x1c820affaf60 
[1:1:0712/074425.418707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1402, 7f6f1571c881
[1:1:0712/074425.467012:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1393 0x7f6f12dd7070 0x1c820affaf60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.467416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1393 0x7f6f12dd7070 0x1c820affaf60 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.467875:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074425.468489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074425.468725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074425.469490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074425.469695:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074425.470089:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1411
[1:1:0712/074425.470334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1411 0x7f6f12dd7070 0x1c820a6827e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1402 0x7f6f12dd7070 0x1c820af3f8e0 
[1:1:0712/074425.652288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1411, 7f6f1571c881
[1:1:0712/074425.703893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1402 0x7f6f12dd7070 0x1c820af3f8e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.704319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1402 0x7f6f12dd7070 0x1c820af3f8e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.704716:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074425.705290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074425.705512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074425.706213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074425.706414:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074425.706784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1419
[1:1:0712/074425.707040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1419 0x7f6f12dd7070 0x1c820a5c2460 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1411 0x7f6f12dd7070 0x1c820a6827e0 
[1:1:0712/074425.831349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1419, 7f6f1571c881
[1:1:0712/074425.902299:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1411 0x7f6f12dd7070 0x1c820a6827e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.902722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1411 0x7f6f12dd7070 0x1c820a6827e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074425.903158:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074425.903720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074425.904007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074425.904833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074425.905034:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074425.905415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1422
[1:1:0712/074425.905644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1422 0x7f6f12dd7070 0x1c820a952460 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1419 0x7f6f12dd7070 0x1c820a5c2460 
[1:1:0712/074426.051602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1422, 7f6f1571c881
[1:1:0712/074426.123734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1419 0x7f6f12dd7070 0x1c820a5c2460 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.124234:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1419 0x7f6f12dd7070 0x1c820a5c2460 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.124681:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074426.125418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074426.125663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074426.126385:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074426.126967:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074426.127340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1425
[1:1:0712/074426.127545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f6f12dd7070 0x1c820a9335e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1422 0x7f6f12dd7070 0x1c820a952460 
[1:1:0712/074426.294217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1425, 7f6f1571c881
[1:1:0712/074426.356448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1422 0x7f6f12dd7070 0x1c820a952460 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.356795:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1422 0x7f6f12dd7070 0x1c820a952460 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.357151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074426.357693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074426.357872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074426.358540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074426.358705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074426.359037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1428
[1:1:0712/074426.359256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7f6f12dd7070 0x1c820a2a9de0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1425 0x7f6f12dd7070 0x1c820a9335e0 
[1:1:0712/074426.502859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1428, 7f6f1571c881
[1:1:0712/074426.570045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1425 0x7f6f12dd7070 0x1c820a9335e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.570406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1425 0x7f6f12dd7070 0x1c820a9335e0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0712/074426.570770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0712/074426.571301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/074426.571485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0712/074426.572116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0712/074426.572326:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0712/074426.572659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1431
[1:1:0712/074426.572847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1431 0x7f6f12dd7070 0x1c820a9528e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1428 0x7f6f12dd7070 0x1c820a2a9de0 
[1:1:0712/074426.730818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1431, 7f6f1571c881
[1:1:0100/000000.784540:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a495ce2860","ptid":"1428 0x7f6f12dd7070 0x1c820a2a9de0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0100/000000.793259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://danji.cr173.com/","ptid":"1428 0x7f6f12dd7070 0x1c820a2a9de0 ","rf":"5:3_http://danji.cr173.com/"}
[1:1:0100/000000.793689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://danji.cr173.com/"
[1:1:0100/000000.794215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://danji.cr173.com/, 27a495ce2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.794397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://danji.cr173.com/", "danji.cr173.com", 3, 1, , , 0
[1:1:0100/000000.795223:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3126c0d829c8, 0x1c8209f6f950
[1:1:0100/000000.795382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://danji.cr173.com/", 100
[1:1:0100/000000.795748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://danji.cr173.com/, 1434
[1:1:0100/000000.795930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1434 0x7f6f12dd7070 0x1c820ab732e0 , 5:3_http://danji.cr173.com/, 1, -5:3_http://danji.cr173.com/, 1431 0x7f6f12dd7070 0x1c820a9528e0 
