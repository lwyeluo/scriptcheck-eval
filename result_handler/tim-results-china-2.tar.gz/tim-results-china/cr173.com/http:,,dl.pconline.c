[0712/073246.197658:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073246.198042:INFO:switcher_clone.cc(787)] backtrace rip is 7f93d1111891
[0712/073247.267894:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073247.268347:INFO:switcher_clone.cc(787)] backtrace rip is 7faaecbd1891
[1:1:0712/073247.280767:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/073247.281099:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/073247.287231:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[101351:101351:0712/073248.651818:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/12057169-6bf2-40a9-bcec-02c7612a278d
[0712/073248.827228:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/073248.827763:INFO:switcher_clone.cc(787)] backtrace rip is 7f96ced41891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[101384:101384:0712/073249.050013:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=101384
[101396:101396:0712/073249.050434:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=101396
[101351:101351:0712/073249.162994:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[101351:101382:0712/073249.163700:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/073249.163938:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/073249.164201:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/073249.164925:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/073249.165148:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/073249.168135:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x18e595b9, 1
[1:1:0712/073249.168539:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1d3991f5, 0
[1:1:0712/073249.168772:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x149f5d0c, 3
[1:1:0712/073249.169051:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb530849, 2
[1:1:0712/073249.169342:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff5ffffff91391d ffffffb9ffffff95ffffffe518 4908530b 0c5dffffff9f14 , 10104, 4
[1:1:0712/073249.170646:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[101351:101382:0712/073249.170994:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��9���IS]��A
[101351:101382:0712/073249.171109:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��9���IS]����A
[1:1:0712/073249.170966:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeae0c0a0, 3
[1:1:0712/073249.171278:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeaf97080, 2
[101351:101382:0712/073249.171578:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[101351:101382:0712/073249.171675:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 101404, 4, f591391d b995e518 4908530b 0c5d9f14 
[1:1:0712/073249.171530:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faad4c5ad20, -2
[1:1:0712/073249.193092:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/073249.193957:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b530849
[1:1:0712/073249.194929:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b530849
[1:1:0712/073249.196565:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b530849
[1:1:0712/073249.198330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.198628:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.198894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.199196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.199899:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b530849
[1:1:0712/073249.200227:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073249.200360:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[1:1:0712/073249.207064:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b530849
[1:1:0712/073249.207550:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b530849
[1:1:0712/073249.208496:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b530849
[1:1:0712/073249.211049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.211441:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.211678:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.211899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b530849
[1:1:0712/073249.213189:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b530849
[1:1:0712/073249.213573:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073249.213714:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[1:1:0712/073249.221610:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/073249.222054:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/073249.222199:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe84fe74a8, 0x7ffe84fe7428)
[1:1:0712/073249.239825:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/073249.247539:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[101351:101351:0712/073249.800397:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101351:101351:0712/073249.801992:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101351:101363:0712/073249.825860:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[101351:101363:0712/073249.826007:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[101351:101351:0712/073249.826167:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[101351:101351:0712/073249.826264:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[101351:101351:0712/073249.826446:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,101404, 4
[1:7:0712/073249.828451:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[101351:101374:0712/073249.889010:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/073249.923226:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x106d8bc02220
[1:1:0712/073249.923517:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/073250.301730:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/073252.044330:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073252.048645:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[101351:101351:0712/073252.114229:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[101351:101351:0712/073252.114368:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/073252.996180:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073253.123182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/073253.123524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073253.154635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/073253.154958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073253.226606:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073253.226890:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073253.419862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073253.424125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/073253.424444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073253.443220:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073253.454824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/073253.455143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073253.461481:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[101351:101351:0712/073253.465410:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/073253.466055:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x106d8bc00e20
[1:1:0712/073253.466358:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[101351:101351:0712/073253.472635:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[101351:101351:0712/073253.505932:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[101351:101351:0712/073253.506091:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/073253.574200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073254.374084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7faad68352e0 0x106d8be30660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073254.375462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/073254.375800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073254.377325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073254.426514:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x106d8bc01820
[1:1:0712/073254.426800:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[101351:101351:0712/073254.441748:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/073254.446412:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/073254.446706:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[101351:101351:0712/073254.449270:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[101351:101351:0712/073254.465920:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[101351:101351:0712/073254.479570:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101351:101351:0712/073254.480726:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[101351:101363:0712/073254.486887:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[101351:101363:0712/073254.486985:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[101351:101351:0712/073254.487123:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[101351:101351:0712/073254.487203:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[101351:101351:0712/073254.487340:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,101404, 4
[1:7:0712/073254.492945:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073255.029503:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/073255.340333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7faad68352e0 0x106d8bed5460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073255.341354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/073255.341559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073255.342313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[101351:101351:0712/073255.506648:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[101351:101351:0712/073255.506719:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/073255.544571:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073255.912701:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[101351:101351:0712/073256.576981:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[101351:101382:0712/073256.577583:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/073256.577875:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/073256.578229:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/073256.578693:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/073256.578846:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/073256.582779:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe9928d6, 1
[1:1:0712/073256.583309:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x5842b53, 0
[1:1:0712/073256.583506:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf7d00d1, 3
[1:1:0712/073256.583686:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xe2df453, 2
[1:1:0712/073256.583836:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 532bffffff8405 ffffffd628ffffff990e 53fffffff42d0e ffffffd1007d0f , 10104, 5
[1:1:0712/073256.585138:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[101351:101382:0712/073256.585424:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGS+��(�S�-�
[101351:101382:0712/073256.585518:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is S+��(�S�-�
[1:1:0712/073256.585678:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeae0c0a0, 3
[101351:101382:0712/073256.585839:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 101448, 5, 532b8405 d628990e 53f42d0e d1007d0f 
[1:1:0712/073256.585925:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeaf97080, 2
[1:1:0712/073256.586193:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faad4c5ad20, -2
[1:1:0712/073256.598815:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/073256.599045:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e2df453
[1:1:0712/073256.599382:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e2df453
[1:1:0712/073256.599994:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e2df453
[1:1:0712/073256.601424:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.601609:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.601788:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.601966:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.602710:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e2df453
[1:1:0712/073256.602994:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073256.603149:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[1:1:0712/073256.610149:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e2df453
[1:1:0712/073256.610581:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e2df453
[1:1:0712/073256.611225:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e2df453
[1:1:0712/073256.611956:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.612138:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.612277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.612428:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e2df453
[1:1:0712/073256.613244:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e2df453
[1:1:0712/073256.613720:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073256.613870:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073256.614168:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[1:1:0712/073256.613957:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073256.618780:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/073256.619226:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/073256.619424:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe84fe74a8, 0x7ffe84fe7428)
[1:1:0712/073256.634336:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/073256.640201:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/073256.835193:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x106d8bbc9220
[1:1:0712/073256.835361:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/073257.047728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073257.052650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1edfed02e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/073257.052994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/073257.058591:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073257.249183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/073257.250006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1edfecf01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/073257.250268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/073257.464414:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073257.466109:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/073257.466341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1edfed02e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/073257.466618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/073257.587111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073257.588037:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/073257.588266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1edfed02e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/073257.588580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[101351:101351:0712/073257.753589:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[101351:101351:0712/073257.796376:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[101351:101382:0712/073257.796823:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/073257.797070:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/073257.797380:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/073257.797938:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/073257.798133:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/073257.801471:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x23790c37, 1
[1:1:0712/073257.801818:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e3a134b, 0
[1:1:0712/073257.802023:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x13c5ced0, 3
[1:1:0712/073257.802190:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x149dc836, 2
[1:1:0712/073257.802362:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4b133a2e 370c7923 36ffffffc8ffffff9d14 ffffffd0ffffffceffffffc513 , 10104, 6
[1:1:0712/073257.803286:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[101351:101382:0712/073257.803592:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGK:.7y#6ȝ����A
[101351:101382:0712/073257.803662:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is K:.7y#6ȝ����[�A
[101351:101382:0712/073257.803887:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 101464, 6, 4b133a2e 370c7923 36c89d14 d0cec513 
[1:1:0712/073257.804208:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeae0c0a0, 3
[1:1:0712/073257.804450:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faaeaf97080, 2
[1:1:0712/073257.804612:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faad4c5ad20, -2
[1:1:0712/073257.828300:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/073257.828735:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 149dc836
[1:1:0712/073257.829019:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 149dc836
[1:1:0712/073257.829656:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 149dc836
[1:1:0712/073257.831112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.831310:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.831543:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.831724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.832413:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 149dc836
[1:1:0712/073257.832704:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073257.832837:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[101351:101351:0712/073257.836243:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/073257.838560:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 149dc836
[1:1:0712/073257.838912:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 149dc836
[1:1:0712/073257.839652:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 149dc836
[1:1:0712/073257.841676:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.841891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.842083:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.842265:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 149dc836
[1:1:0712/073257.843560:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 149dc836
[1:1:0712/073257.843947:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faaecbd17ba
[1:1:0712/073257.844085:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faaecbc8def, 7faaecbd177a, 7faaecbd30cf
[1:1:0712/073257.848447:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/073257.848830:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/073257.848928:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe84fe74a8, 0x7ffe84fe7428)
[1:1:0712/073257.863240:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/073257.867808:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[101351:101363:0712/073257.874452:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[101351:101363:0712/073257.874566:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[101351:101351:0712/073257.874949:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://dl.pconline.com.cn/
[101351:101351:0712/073257.875043:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://dl.pconline.com.cn/, https://dl.pconline.com.cn/, 1
[101351:101351:0712/073257.875208:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://dl.pconline.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 14:32:57 GMT Server: Tengine Content-Type: text/html Content-Length: 85804 Expires: Fri, 12 Jul 2019 14:39:29 GMT Cache-Control: max-age=900 Content-Encoding: gzip X-Cache-Lookup: HIT from pconline-dl-ngx2-vm230-16.pconline.cnc:8080 Via: 1.0 pconline-dl-ngx2-vm230-16.pconline.cnc:8080 (squid/2.6.STABLE20) X-Via: 1.1 changk20:4 (Cdn Cache Server V2.0) Connection: keep-alive  ,0, 6
[3:3:0712/073257.882934:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/073257.955513:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/073258.097461:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x106d8bbeb220
[1:1:0712/073258.097737:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/073258.144261:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://dl.pconline.com.cn/
[101351:101351:0712/073258.383078:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://dl.pconline.com.cn/, https://dl.pconline.com.cn/, 1
[101351:101351:0712/073258.383222:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://dl.pconline.com.cn/, https://dl.pconline.com.cn
[1:1:0712/073258.403703:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073258.522786:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073258.585107:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/073258.593925:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073258.648456:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/073258.692188:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073258.692468:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073258.720723:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 115 0x7faad490d070 0x106d8bc4ade0 , "https://dl.pconline.com.cn/"
[1:1:0712/073258.724912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
var deviceJump=(function(){var u=navigator.userAgent.toLowerCase();var d=window.location.href.toLow
[1:1:0712/073258.725179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073258.728810:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073258.741398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 115 0x7faad490d070 0x106d8bc4ade0 , "https://dl.pconline.com.cn/"
[1:1:0712/073258.767756:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/073258.818806:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073258.844270:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/073258.917020:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/073258.989237:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/073259.103350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073259.104043:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://91jm.com/"
[1:1:0712/073259.238508:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://xbombo.com/"
[1:1:0712/073259.454160:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073259.547413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7faad490d070 0x106d8ba64e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073259.548363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
var ad_2016_download_v3 = 1;

[1:1:0712/073259.548693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073259.554621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7faad490d070 0x106d8ba64e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073259.615855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7faad490d070 0x106d8ba64e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073259.617397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 999, 0x23b51c9629c8, 0x106d8ba5b1a0
[1:1:0712/073259.617641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 999
[1:1:0712/073259.618116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 214
[1:1:0712/073259.618366:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 214 0x7faad490d070 0x106d8bc44160 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 167 0x7faad490d070 0x106d8ba64e60 
[1:1:0712/073259.621048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7faad490d070 0x106d8ba64e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073259.644681:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7faad490d070 0x106d8ba64e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073259.708302:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.158067, 137, 1
[1:1:0712/073259.708573:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073259.890016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/073259.890993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1edfed02e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/073259.891281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/073259.977331:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/073300.385671:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073300.386019:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073300.387768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7faad490d070 0x106d8be8afe0 , "https://dl.pconline.com.cn/"
[1:1:0712/073300.389155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
/*登录url*/
window.ajaxLoginUrl = location.protocol+"//www1.pconline.com.cn/common/js/pconline.lo
[1:1:0712/073300.389391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073300.412165:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0260451, 339, 1
[1:1:0712/073300.412430:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073300.616078:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/073300.895442:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073300.895746:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073300.896709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 271 0x7faad490d070 0x106d8bbfb360 , "https://dl.pconline.com.cn/"
[1:1:0712/073300.898876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
(function(){
function isContain(a, b) {
try {
return a.contains ? a != b && a.contains(b) : !!(a.co
[1:1:0712/073300.899185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073301.194900:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.299074, 1693, 1
[1:1:0712/073301.195248:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073301.415386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 214, 7faad7252881
[1:1:0712/073301.435388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"167 0x7faad490d070 0x106d8ba64e60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073301.435809:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"167 0x7faad490d070 0x106d8ba64e60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073301.436122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073301.436880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){var js=document.createElement("script"); js.src="//ivy.pconline.com.cn/adpuba/show?id=pc.xz.shouy
[1:1:0712/073301.437126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073302.783317:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073302.783700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073302.784604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359 0x7faad490d070 0x106d8c088860 , "https://dl.pconline.com.cn/"
[1:1:0712/073302.785668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
if(!window.preloadShow4) document.write('<script src="//ivy.pconline.com.cn/show4?opt=1&id=pc.xz.sh
[1:1:0712/073302.785921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073304.114963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.116369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , ivymap=window.ivymap||{};
ivymap["pc.xz.shouye.zu.tl1."] = function(){document_write(unescape('<scri
[1:1:0712/073304.116607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073304.117745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.118736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.121583:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.124143:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.126362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.129457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 442, "https://dl.pconline.com.cn/"
[1:1:0712/073304.256722:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.13952, 770, 1
[1:1:0712/073304.256990:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073304.642222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7faad68352e0 0x106d8b5ad2e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073304.671592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (function(){var h={},mt={},c={id:"d38ac9ad074d9e00764ad1daa6023a31",dm:["dl.pconline.com.cn"],js:"to
[1:1:0712/073304.671854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073304.699664:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b190
[1:1:0712/073304.699864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073304.700121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 568
[1:1:0712/073304.700235:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7faad490d070 0x106d8c2e1f60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 454 0x7faad68352e0 0x106d8b5ad2e0 
[1:1:0712/073308.215160:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073308.215763:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073308.216237:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073308.216654:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073308.217311:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[101351:101351:0712/073318.429188:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/073318.470230:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/073320.428012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 600000
[1:1:0712/073320.428520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 626
[1:1:0712/073320.428778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7faad490d070 0x106d8b6a6760 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 454 0x7faad68352e0 0x106d8b5ad2e0 
[1:1:0712/073320.429679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 5000
[1:1:0712/073320.430059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 627
[1:1:0712/073320.430286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7faad490d070 0x106d8b6a9560 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 454 0x7faad68352e0 0x106d8b5ad2e0 
[1:1:0712/073320.512133:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 455 0x7faad68352e0 0x106d8c07cee0 , "https://dl.pconline.com.cn/"
[1:1:0712/073320.513406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , ;(function(){
    window.__ivyTest15Count__=[];window.__tid__='pc.xz.shouye.test15.';
    var srcs
[1:1:0712/073320.513685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073322.846353:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073322.846648:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073322.847448:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548 0x7faad490d070 0x106d8c2e14e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073322.848514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , showIvyViaJs("pc.xz.shouye.zu.tl2.")
[1:1:0712/073322.848811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073323.101944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.255288, 1852, 1
[1:1:0712/073323.102348:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073323.585130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/073323.585448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073325.322169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 568, 7faad7252881
[1:1:0712/073325.358153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"454 0x7faad68352e0 0x106d8b5ad2e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073325.358542:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"454 0x7faad68352e0 0x106d8b5ad2e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073325.358879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073325.359454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073325.359734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073325.360588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073325.360805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073325.361180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 811
[1:1:0712/073325.361414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7faad490d070 0x106d8be858e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 568 0x7faad490d070 0x106d8c2e1f60 
[1:1:0712/073330.747503:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073330.747678:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073330.748438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 790 0x7faad490d070 0x106d8c969060 , "https://dl.pconline.com.cn/"
[1:1:0712/073330.748972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , showIvyViaJs("pc.xz.shouye.zu.tl3.")
[1:1:0712/073330.749091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073330.862248:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.11443, 1818, 1
[1:1:0712/073330.862505:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073331.132554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073331.132927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073333.294317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 627, 7faad72528db
[1:1:0712/073333.335106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"454 0x7faad68352e0 0x106d8b5ad2e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073333.335520:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"454 0x7faad68352e0 0x106d8b5ad2e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073333.335969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 895
[1:1:0712/073333.336225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7faad490d070 0x106d8ca63260 , 6:3_https://dl.pconline.com.cn/, 0, , 627 0x7faad490d070 0x106d8b6a9560 
[1:1:0712/073333.336591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073333.337140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/073333.337371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073333.395587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/073333.397537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , g.onload, (){g.onload=u;g=window[d]=u;a&&a(b)}
[1:1:0712/073333.397768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073333.445102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 811, 7faad7252881
[1:1:0712/073333.484246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"568 0x7faad490d070 0x106d8c2e1f60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073333.484748:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"568 0x7faad490d070 0x106d8c2e1f60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073333.485069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073333.485651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073333.485865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073333.486587:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073333.486790:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073333.487177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 898
[1:1:0712/073333.487427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7faad490d070 0x106d8bdcd860 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 811 0x7faad490d070 0x106d8be858e0 
[1:1:0712/073335.014322:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073335.014630:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073335.019475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 854 0x7faad490d070 0x106d8c89dce0 , "https://dl.pconline.com.cn/"
[1:1:0712/073335.071820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , /* jQuery v1.6.3 http://jquery.com/ | http://jquery.org/license */
(function(a,b){function cu(a){ret
[1:1:0712/073335.072152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073335.296661:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/073335.473258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 854 0x7faad490d070 0x106d8c89dce0 , "https://dl.pconline.com.cn/"
[1:1:0712/073337.595744:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b248
[1:1:0712/073337.596145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073337.596621:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 909
[1:1:0712/073337.596953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7faad490d070 0x106d8cb2b7e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 854 0x7faad490d070 0x106d8c89dce0 
[1:1:0712/073337.602598:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073337.603086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 910
[1:1:0712/073337.603355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 910 0x7faad490d070 0x106d8cafb560 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 854 0x7faad490d070 0x106d8c89dce0 
[1:1:0712/073337.678231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 3500
[1:1:0712/073337.678719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 912
[1:1:0712/073337.678974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7faad490d070 0x106d8bd17ce0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 854 0x7faad490d070 0x106d8c89dce0 
[1:1:0712/073337.817902:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.80315, 0, 0
[1:1:0712/073337.818179:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073338.170832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073338.171147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073339.755072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 898, 7faad7252881
[1:1:0712/073339.797453:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"811 0x7faad490d070 0x106d8be858e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073339.797882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"811 0x7faad490d070 0x106d8be858e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073339.798313:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073339.798924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073339.799168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073339.799911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073339.800111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073339.800477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 965
[1:1:0712/073339.800705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 965 0x7faad490d070 0x106d8cb37ce0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 898 0x7faad490d070 0x106d8bdcd860 
[101351:101351:0712/073340.429059:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/073340.461224:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073340.461492:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073340.476773:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.01524, 85, 1
[1:1:0712/073340.477082:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/073340.478603:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 895, 7faad72528db
[1:1:0712/073340.521075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7faad490d070 0x106d8b6a9560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.521396:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7faad490d070 0x106d8b6a9560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.521801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1000
[1:1:0712/073340.522046:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7faad490d070 0x106d8c4ee460 , 6:3_https://dl.pconline.com.cn/, 0, , 895 0x7faad490d070 0x106d8ca63260 
[1:1:0712/073340.522447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073340.522994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/073340.523220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073340.743756:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 909, 7faad7252881
[1:1:0712/073340.787741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.788177:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.788597:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073340.789164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073340.789381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073340.790935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 910, 7faad72528db
[1:1:0712/073340.815162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.815538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073340.816054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1002
[1:1:0712/073340.816292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7faad490d070 0x106d8ca39660 , 6:3_https://dl.pconline.com.cn/, 0, , 910 0x7faad490d070 0x106d8cafb560 
[1:1:0712/073340.816688:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073340.817249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073340.817465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073340.818931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073340.819165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073340.819527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1003
[1:1:0712/073340.819782:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7faad490d070 0x106d8c342960 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 910 0x7faad490d070 0x106d8cafb560 
[1:1:0712/073342.111148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073342.111481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073342.319302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 965, 7faad7252881
[1:1:0712/073342.365862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"898 0x7faad490d070 0x106d8bdcd860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073342.366258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"898 0x7faad490d070 0x106d8bdcd860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073342.366711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073342.367278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073342.367514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073342.368249:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073342.368466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073342.368837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1047
[1:1:0712/073342.369063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7faad490d070 0x106d8cb17260 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 965 0x7faad490d070 0x106d8cb37ce0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/073343.730329:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/073343.730602:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dl.pconline.com.cn/"
[1:1:0712/073343.731759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.733503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , 
(function(){
var thisurl = window.location.href;
if (thisurl.match('//dl.pconline.com.cn/') || this
[1:1:0712/073343.733778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073343.745431:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.772412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.779901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.798652:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x4e5983b8f50
[1:1:0712/073343.803642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.805030:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x23b51c9629c8, 0x106d8ba5b1a0
[1:1:0712/073343.805236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 250
[1:1:0712/073343.805605:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1080
[1:1:0712/073343.805858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7faad490d070 0x106d8c4fc560 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 998 0x7faad490d070 0x106d8caf51e0 
[1:1:0712/073343.808808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.812772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.819378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.832317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.835145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.838341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.841796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7faad490d070 0x106d8caf51e0 , "https://dl.pconline.com.cn/"
[1:1:0712/073343.851593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/073343.852983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/073343.854493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dl.pconline.com.cn/"
[1:1:0712/073343.950099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1003, 7faad7252881
[1:1:0712/073343.998625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"910 0x7faad490d070 0x106d8cafb560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073343.999041:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"910 0x7faad490d070 0x106d8cafb560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073343.999463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073344.000075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073344.000328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073344.063973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 912, 7faad72528db
[1:1:0712/073344.108390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073344.108793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"854 0x7faad490d070 0x106d8c89dce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073344.109287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1104
[1:1:0712/073344.109535:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7faad490d070 0x106d8b8ece60 , 6:3_https://dl.pconline.com.cn/, 0, , 912 0x7faad490d070 0x106d8bd17ce0 
[1:1:0712/073344.109977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073344.110564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073344.110849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073344.186184:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073344.186476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073344.186875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1105
[1:1:0712/073344.187104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7faad490d070 0x106d8c4cd5e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 912 0x7faad490d070 0x106d8bd17ce0 
[1:1:0712/073344.188741:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073344.189127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1106
[1:1:0712/073344.189356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7faad490d070 0x106d8db24360 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 912 0x7faad490d070 0x106d8bd17ce0 
[1:1:0712/073345.580081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073345.580386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073345.583663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1047, 7faad7252881
[1:1:0712/073345.633588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"965 0x7faad490d070 0x106d8cb37ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073345.633967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"965 0x7faad490d070 0x106d8cb37ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073345.634395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073345.634958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073345.635189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073345.635882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073345.636132:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073345.636546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1121
[1:1:0712/073345.636782:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1121 0x7faad490d070 0x106d8dbc4d60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1047 0x7faad490d070 0x106d8cb17260 
[1:1:0712/073346.879132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1080, 7faad7252881
[1:1:0712/073346.925071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"998 0x7faad490d070 0x106d8caf51e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073346.925469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"998 0x7faad490d070 0x106d8caf51e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073346.925871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073346.926492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){var js=document.createElement("script"); js.src="//ivy.pconline.com.cn/show?id=pc.other.test15.&m
[1:1:0712/073346.926709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073346.942762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073346.943020:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 2000
[1:1:0712/073346.943403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1150
[1:1:0712/073346.943687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1150 0x7faad490d070 0x106d8db22660 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1080 0x7faad490d070 0x106d8c4fc560 
[1:1:0712/073347.103454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1105, 7faad7252881
[1:1:0712/073347.153519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.153880:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.154303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073347.154853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073347.155068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.156810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1106, 7faad72528db
[1:1:0712/073347.184791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.185160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.185636:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1157
[1:1:0712/073347.185873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1157 0x7faad490d070 0x106d8cb372e0 , 6:3_https://dl.pconline.com.cn/, 0, , 1106 0x7faad490d070 0x106d8db24360 
[1:1:0712/073347.186275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073347.186835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073347.187053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.188078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073347.188307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073347.188690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1158
[1:1:0712/073347.188917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1158 0x7faad490d070 0x106d8b5afae0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1106 0x7faad490d070 0x106d8db24360 
[1:1:0712/073347.341871:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1104, 7faad72528db
[1:1:0712/073347.375869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.376219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"912 0x7faad490d070 0x106d8bd17ce0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.376688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1166
[1:1:0712/073347.376922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7faad490d070 0x106d8bcedee0 , 6:3_https://dl.pconline.com.cn/, 0, , 1104 0x7faad490d070 0x106d8b8ece60 
[1:1:0712/073347.377322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073347.377879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073347.378094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.433717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073347.434169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1167
[1:1:0712/073347.434421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7faad490d070 0x106d8db26de0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1104 0x7faad490d070 0x106d8b8ece60 
[1:1:0712/073347.606744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1000, 7faad72528db
[1:1:0712/073347.659107:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"895 0x7faad490d070 0x106d8ca63260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.659462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"895 0x7faad490d070 0x106d8ca63260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.659979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1175
[1:1:0712/073347.660216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7faad490d070 0x106d8db24de0 , 6:3_https://dl.pconline.com.cn/, 0, , 1000 0x7faad490d070 0x106d8c4ee460 
[1:1:0712/073347.660605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073347.661153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/073347.661404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.787088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073347.787382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.791514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1121, 7faad7252881
[1:1:0712/073347.844546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1047 0x7faad490d070 0x106d8cb17260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.844937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1047 0x7faad490d070 0x106d8cb17260 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073347.845361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073347.845987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073347.846208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073347.846920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073347.847121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073347.847509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1179
[1:1:0712/073347.847823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1179 0x7faad490d070 0x106d8db15d60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1121 0x7faad490d070 0x106d8dbc4d60 
[1:1:0712/073348.565801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1140 0x7faad68352e0 0x106d8dc4eee0 , "https://dl.pconline.com.cn/"
[1:1:0712/073348.574427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , /*!  svn://js.3conline.com/pcauto/commom/js/login.1.1.js*/
(function(h,k){function l(b,a){return ne
[1:1:0712/073348.574736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073348.698475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1141 0x7faad68352e0 0x106d8c500660 , "https://dl.pconline.com.cn/"
[1:1:0712/073348.716886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (function(c,g){if(c.PCgroup){return}var b,d=Object.prototype.toString,f=Array.prototype.slice,a=c.do
[1:1:0712/073348.717219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073348.820383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/073349.784619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1158, 7faad7252881
[1:1:0712/073349.829621:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1106 0x7faad490d070 0x106d8db24360 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073349.829995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1106 0x7faad490d070 0x106d8db24360 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073349.830400:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073349.830946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073349.831202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073350.048773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1167, 7faad72528db
[1:1:0712/073350.101176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1104 0x7faad490d070 0x106d8b8ece60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.101570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1104 0x7faad490d070 0x106d8b8ece60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.102017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1223
[1:1:0712/073350.102292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7faad490d070 0x106d8db1fd60 , 6:3_https://dl.pconline.com.cn/, 0, , 1167 0x7faad490d070 0x106d8db26de0 
[1:1:0712/073350.102731:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073350.103309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073350.103530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073350.104615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073350.104820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073350.105231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1224
[1:1:0712/073350.105485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1224 0x7faad490d070 0x106d8c846c60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1167 0x7faad490d070 0x106d8db26de0 
[1:1:0712/073350.404224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073350.404531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073350.408085:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1179, 7faad7252881
[1:1:0712/073350.441717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1121 0x7faad490d070 0x106d8dbc4d60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.442068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1121 0x7faad490d070 0x106d8dbc4d60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.442513:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073350.443124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073350.443349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073350.444009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073350.444245:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073350.444604:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1235
[1:1:0712/073350.444824:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1235 0x7faad490d070 0x106d8bd17a60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1179 0x7faad490d070 0x106d8db15d60 
[1:1:0712/073350.498275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1166, 7faad72528db
[1:1:0712/073350.551716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1104 0x7faad490d070 0x106d8b8ece60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.552043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1104 0x7faad490d070 0x106d8b8ece60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073350.552539:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1237
[1:1:0712/073350.552772:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1237 0x7faad490d070 0x106d8cb3aa60 , 6:3_https://dl.pconline.com.cn/, 0, , 1166 0x7faad490d070 0x106d8bcedee0 
[1:1:0712/073350.553141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073350.553707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073350.553920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073350.619111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073350.619602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1238
[1:1:0712/073350.619880:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1238 0x7faad490d070 0x106d8dc4a460 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1166 0x7faad490d070 0x106d8bcedee0 
[1:1:0712/073351.005148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1150, 7faad7252881
[1:1:0712/073351.059291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1080 0x7faad490d070 0x106d8c4fc560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073351.059692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1080 0x7faad490d070 0x106d8c4fc560 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073351.060117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073351.060737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){if(window['__test15_exist']) return;var js;(js=document.createElement("script")).src=location.pro
[1:1:0712/073351.060958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073351.539579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1218 0x7faad68352e0 0x106d8dbc9e60 , "https://dl.pconline.com.cn/"
[1:1:0712/073351.542680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , ;(function(){
    window.__ivyTest15Count__=[];window.__tid__='pc.other.test15.';
    var srcs = [
[1:1:0712/073351.542933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073351.545051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x23b51c9629c8, 0x106d8ba5b1a0
[1:1:0712/073351.545260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 1
[1:1:0712/073351.545656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1268
[1:1:0712/073351.545888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1268 0x7faad490d070 0x106d8c61df60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1218 0x7faad68352e0 0x106d8dbc9e60 
[1:1:0712/073351.604224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1219 0x7faad68352e0 0x106d8c500d60 , "https://dl.pconline.com.cn/"
[1:1:0712/073351.607258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (function(d,b){var e=function(){var m=[function(){return new XMLHttpRequest()},function(){return new
[1:1:0712/073351.607519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073351.610555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/073352.144791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1224, 7faad7252881
[1:1:0712/073352.205893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1167 0x7faad490d070 0x106d8db26de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.206289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1167 0x7faad490d070 0x106d8db26de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.206749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073352.207350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073352.207689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073352.422271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073352.422582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073352.426722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1175, 7faad72528db
[1:1:0712/073352.483461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1000 0x7faad490d070 0x106d8c4ee460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.483928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1000 0x7faad490d070 0x106d8c4ee460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.484423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1289
[1:1:0712/073352.484701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7faad490d070 0x106d8db15de0 , 6:3_https://dl.pconline.com.cn/, 0, , 1175 0x7faad490d070 0x106d8db24de0 
[1:1:0712/073352.485108:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073352.485690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/073352.485939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073352.488491:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1235, 7faad7252881
[1:1:0712/073352.518158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1179 0x7faad490d070 0x106d8db15d60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.518549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1179 0x7faad490d070 0x106d8db15d60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.518988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073352.519673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073352.519902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073352.520600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073352.520825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073352.521210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1292
[1:1:0712/073352.521452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1292 0x7faad490d070 0x106d8c085c60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1235 0x7faad490d070 0x106d8bd17a60 
[1:1:0712/073352.578335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1238, 7faad72528db
[1:1:0712/073352.634478:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1166 0x7faad490d070 0x106d8bcedee0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.634884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1166 0x7faad490d070 0x106d8bcedee0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073352.635336:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1293
[1:1:0712/073352.635580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1293 0x7faad490d070 0x106d8becbe60 , 6:3_https://dl.pconline.com.cn/, 0, , 1238 0x7faad490d070 0x106d8dc4a460 
[1:1:0712/073352.636055:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073352.636621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073352.636854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073352.637895:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073352.638109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073352.638482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1294
[1:1:0712/073352.638742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1294 0x7faad490d070 0x106d8db261e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1238 0x7faad490d070 0x106d8dc4a460 
[1:1:0712/073353.138692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1268, 7faad7252881
[1:1:0712/073353.183645:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1218 0x7faad68352e0 0x106d8dbc9e60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073353.183998:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1218 0x7faad68352e0 0x106d8dbc9e60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073353.184430:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073353.185639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){
var ua = navigator.userAgent,win=window,doc=document;
if(/Baiduspider|PhantomJS|HeadlessChrome|B
[1:1:0712/073353.185889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073353.255435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1237, 7faad72528db
[1:1:0712/073353.313024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1166 0x7faad490d070 0x106d8bcedee0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073353.313376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1166 0x7faad490d070 0x106d8bcedee0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073353.313839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1316
[1:1:0712/073353.314084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7faad490d070 0x106d8db1fb60 , 6:3_https://dl.pconline.com.cn/, 0, , 1237 0x7faad490d070 0x106d8cb3aa60 
[1:1:0712/073353.314479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073353.315093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073353.315307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073353.343492:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073353.343961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1317
[1:1:0712/073353.344196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1317 0x7faad490d070 0x106d8c969660 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1237 0x7faad490d070 0x106d8cb3aa60 
[1:1:0712/073353.958429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073353.958813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073354.577710:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1292, 7faad7252881
[1:1:0712/073354.607637:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1235 0x7faad490d070 0x106d8bd17a60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073354.608037:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1235 0x7faad490d070 0x106d8bd17a60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073354.608458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073354.609146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073354.609367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073354.610080:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073354.610317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073354.610700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1348
[1:1:0712/073354.610942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1348 0x7faad490d070 0x106d8c0792e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1292 0x7faad490d070 0x106d8c085c60 
[1:1:0712/073354.612514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1294, 7faad7252881
[1:1:0712/073354.657504:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1238 0x7faad490d070 0x106d8dc4a460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073354.657879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1238 0x7faad490d070 0x106d8dc4a460 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073354.658296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073354.658843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073354.659223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073354.975742:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1309 0x7faad68352e0 0x106d8cb98de0 , "https://dl.pconline.com.cn/"
[1:1:0712/073354.979224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , ;setTimeout(function(){
var ua = navigator.userAgent,win=window,doc=document;
if(/Baiduspider|Bing
[1:1:0712/073354.979488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073354.980111:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x23b51c9629c8, 0x106d8ba5b190
[1:1:0712/073354.980340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 1
[1:1:0712/073354.980868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1353
[1:1:0712/073354.981099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7faad490d070 0x106d8c9e6be0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1309 0x7faad68352e0 0x106d8cb98de0 
[1:1:0712/073355.031722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1310 0x7faad68352e0 0x106d8cb7d260 , "https://dl.pconline.com.cn/"
[1:1:0712/073355.032819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , pcgrouphttps3A2F2Fdlpconlinecomcn2Fintf2Fcybercop2FgetCybercopStatusjsp({"cybercopMsg":"cybercop off
[1:1:0712/073355.033055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073355.034094:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/073355.177543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1317, 7faad72528db
[1:1:0712/073355.212368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1237 0x7faad490d070 0x106d8cb3aa60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073355.212756:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1237 0x7faad490d070 0x106d8cb3aa60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073355.213210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1362
[1:1:0712/073355.213459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7faad490d070 0x106d8db22160 , 6:3_https://dl.pconline.com.cn/, 0, , 1317 0x7faad490d070 0x106d8c969660 
[1:1:0712/073355.213834:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073355.214399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073355.214624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073355.215651:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073355.215862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073355.216229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1363
[1:1:0712/073355.216479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1363 0x7faad490d070 0x106d8ca4dce0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1317 0x7faad490d070 0x106d8c969660 
[1:1:0712/073355.695604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , document.readyState
[1:1:0712/073355.695911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073355.981013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1348, 7faad7252881
[1:1:0712/073356.051598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1292 0x7faad490d070 0x106d8c085c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.051980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1292 0x7faad490d070 0x106d8c085c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.052415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073356.053074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073356.053291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073356.054001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073356.054216:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073356.054606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1381
[1:1:0712/073356.054841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7faad490d070 0x106d8dc511e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1348 0x7faad490d070 0x106d8c0792e0 
[1:1:0712/073356.057299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1353, 7faad7252881
[1:1:0712/073356.095159:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1309 0x7faad68352e0 0x106d8cb98de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.095602:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1309 0x7faad68352e0 0x106d8cb98de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.096085:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073356.097022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){
var ua = navigator.userAgent,win=window,doc=document;
if(/Baiduspider|BingPreview|YisouSpider|
[1:1:0712/073356.097238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073356.718983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1316, 7faad72528db
[1:1:0712/073356.779200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1237 0x7faad490d070 0x106d8cb3aa60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.779532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1237 0x7faad490d070 0x106d8cb3aa60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.780039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1397
[1:1:0712/073356.780271:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1397 0x7faad490d070 0x106d8b552c60 , 6:3_https://dl.pconline.com.cn/, 0, , 1316 0x7faad490d070 0x106d8db1fb60 
[1:1:0712/073356.780676:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073356.781217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073356.781436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073356.813159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073356.813632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1399
[1:1:0712/073356.813875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1399 0x7faad490d070 0x106d8c43f860 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1316 0x7faad490d070 0x106d8db1fb60 
[1:1:0712/073356.840979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1363, 7faad7252881
[1:1:0712/073356.902026:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1317 0x7faad490d070 0x106d8c969660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.902413:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1317 0x7faad490d070 0x106d8c969660 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073356.902872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073356.903445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073356.903723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073356.996454:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1289, 7faad72528db
[1:1:0712/073357.022505:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1175 0x7faad490d070 0x106d8db24de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.022846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1175 0x7faad490d070 0x106d8db24de0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.023389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1404
[1:1:0712/073357.023705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7faad490d070 0x106d8ca633e0 , 6:3_https://dl.pconline.com.cn/, 0, , 1289 0x7faad490d070 0x106d8db15de0 
[1:1:0712/073357.024083:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073357.024621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , Xb, (){var a=d.P()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/073357.026363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073357.614625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1381, 7faad7252881
[1:1:0712/073357.659390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1348 0x7faad490d070 0x106d8c0792e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.659771:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1348 0x7faad490d070 0x106d8c0792e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.660211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073357.660803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073357.661032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073357.661762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073357.661976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073357.662345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1415
[1:1:0712/073357.662574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1415 0x7faad490d070 0x106d8d859f60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1381 0x7faad490d070 0x106d8dc511e0 
[1:1:0712/073357.962197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1399, 7faad72528db
[1:1:0712/073357.987228:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1316 0x7faad490d070 0x106d8db1fb60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.987603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1316 0x7faad490d070 0x106d8db1fb60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073357.988102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1424
[1:1:0712/073357.988337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1424 0x7faad490d070 0x106d8e7c4d60 , 6:3_https://dl.pconline.com.cn/, 0, , 1399 0x7faad490d070 0x106d8c43f860 
[1:1:0712/073357.988759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073357.989345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0712/073357.989560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073357.990563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073357.990760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073357.991144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1425
[1:1:0712/073357.991399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7faad490d070 0x106d8e7b9de0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1399 0x7faad490d070 0x106d8c43f860 
[1:1:0712/073358.481708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1415, 7faad7252881
[1:1:0712/073358.516249:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1381 0x7faad490d070 0x106d8dc511e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073358.516633:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1381 0x7faad490d070 0x106d8dc511e0 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073358.517098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073358.517684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073358.517929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073358.518656:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073358.518853:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073358.519236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1441
[1:1:0712/073358.519464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7faad490d070 0x106d8dffb9e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1415 0x7faad490d070 0x106d8d859f60 
[1:1:0712/073358.926733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1425, 7faad7252881
[1:1:0712/073358.986920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1399 0x7faad490d070 0x106d8c43f860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073358.987417:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1399 0x7faad490d070 0x106d8c43f860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073358.987926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073358.988614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073358.988870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073359.158744:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/073359.159625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){if(!a.Z){a.Z=t;for(var d=0,b=f.length;d<b;d++)f[d]()}}
[1:1:0712/073359.169382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073359.170040:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://dl.pconline.com.cn/"
[1:1:0712/073359.173287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://dl.pconline.com.cn/"
[1:1:0712/073359.174820:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b2f0
[1:1:0712/073359.175029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073359.175433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1455
[1:1:0712/073359.175670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7faad490d070 0x106d8dbc70e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1432 0x7faad490d070 0x106d8e7bb860 
[1:1:0712/073359.770302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1397, 7faad72528db
[1:1:0712/073359.804399:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1316 0x7faad490d070 0x106d8db1fb60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073359.804620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1316 0x7faad490d070 0x106d8db1fb60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073359.804853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1465
[1:1:0712/073359.804970:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1465 0x7faad490d070 0x106d8e747b60 , 6:3_https://dl.pconline.com.cn/, 0, , 1397 0x7faad490d070 0x106d8b552c60 
[1:1:0712/073359.805172:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073359.805496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , , (){g.playTo(g.curPage+1)}
[1:1:0712/073359.805619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073359.847217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073359.847441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0712/073359.847635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1466
[1:1:0712/073359.847752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1466 0x7faad490d070 0x106d8c015e60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1397 0x7faad490d070 0x106d8b552c60 
[1:1:0712/073359.848727:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 13
[1:1:0712/073359.848906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1467
[1:1:0712/073359.849017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1467 0x7faad490d070 0x106d8e7b2a60 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1397 0x7faad490d070 0x106d8b552c60 
[1:1:0712/073359.947716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1455, 7faad7252881
[1:1:0712/073359.990834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1432 0x7faad490d070 0x106d8e7bb860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073359.991151:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1432 0x7faad490d070 0x106d8e7bb860 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073359.991464:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073359.991821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/073359.991935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073359.992263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0712/073359.992495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 100
[1:1:0712/073359.992840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1475
[1:1:0712/073359.993031:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1475 0x7faad490d070 0x106d8e7c96e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1455 0x7faad490d070 0x106d8dbc70e0 
[1:1:0712/073400.050580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1466, 7faad7252881
[1:1:0712/073400.101358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1397 0x7faad490d070 0x106d8b552c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073400.101793:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1397 0x7faad490d070 0x106d8b552c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0712/073400.102232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0712/073400.102867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , cp, (){cn=b}
[1:1:0712/073400.103086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0712/073400.105678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1467, 7faad72528db
[1:1:0100/000000.157502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0ad408842860","ptid":"1397 0x7faad490d070 0x106d8b552c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0100/000000.177573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://dl.pconline.com.cn/","ptid":"1397 0x7faad490d070 0x106d8b552c60 ","rf":"6:3_https://dl.pconline.com.cn/"}
[1:1:0100/000000.178104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://dl.pconline.com.cn/, 1486
[1:1:0100/000000.178288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1486 0x7faad490d070 0x106d8e7b7160 , 6:3_https://dl.pconline.com.cn/, 0, , 1467 0x7faad490d070 0x106d8e7b2a60 
[1:1:0100/000000.178655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dl.pconline.com.cn/"
[1:1:0100/000000.179133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://dl.pconline.com.cn/, 0ad408842860, , tick, (){for(var a=f.timers,b=0;b<a.length;++b){a[b]()||a.splice(b--,1)}a.length||f.fx.stop()}
[1:1:0100/000000.179280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dl.pconline.com.cn/", "dl.pconline.com.cn", 3, 1, , , 0
[1:1:0100/000000.180289:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x23b51c9629c8, 0x106d8ba5b150
[1:1:0100/000000.180442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dl.pconline.com.cn/", 0
[1:1:0100/000000.180726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://dl.pconline.com.cn/, 1496
[1:1:0100/000000.180857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1496 0x7faad490d070 0x106d8e7cb8e0 , 6:3_https://dl.pconline.com.cn/, 1, -6:3_https://dl.pconline.com.cn/, 1467 0x7faad490d070 0x106d8e7b2a60 
