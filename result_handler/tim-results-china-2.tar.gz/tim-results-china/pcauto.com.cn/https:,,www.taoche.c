[0712/113837.470215:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113837.470602:INFO:switcher_clone.cc(787)] backtrace rip is 7f6c77198891
[0712/113838.578831:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113838.579177:INFO:switcher_clone.cc(787)] backtrace rip is 7f3adeb71891
[1:1:0712/113838.590895:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/113838.591150:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/113838.599108:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[2020:2020:0712/113840.156387:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/113840.171121:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113840.171377:INFO:switcher_clone.cc(787)] backtrace rip is 7f5662a59891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/edcae698-3037-4740-a183-fc691516f9e1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2061:2061:0712/113840.389972:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2061
[2073:2073:0712/113840.390244:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2073
[2020:2020:0712/113840.713805:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2020:2059:0712/113840.714721:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/113840.715037:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/113840.715378:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/113840.716409:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/113840.716672:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/113840.720877:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3175d7ca, 1
[1:1:0712/113840.721347:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x165d4654, 0
[1:1:0712/113840.721568:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x907aade, 3
[1:1:0712/113840.721779:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x27305e40, 2
[1:1:0712/113840.722069:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 54465d16 ffffffcaffffffd77531 405e3027 ffffffdeffffffaa0709 , 10104, 4
[1:1:0712/113840.723291:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2020:2059:0712/113840.723618:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGTF]��u1@^0'ު	���
[2020:2059:0712/113840.723726:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is TF]��u1@^0'ު	8w���
[1:1:0712/113840.723593:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3adcdac0a0, 3
[2020:2059:0712/113840.724029:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/113840.723872:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3adcf37080, 2
[2020:2059:0712/113840.724067:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2089, 4, 54465d16 cad77531 405e3027 deaa0709 
[1:1:0712/113840.724125:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3ac6bfad20, -2
[1:1:0712/113840.750086:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/113840.751247:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27305e40
[1:1:0712/113840.752559:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27305e40
[1:1:0712/113840.754690:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27305e40
[1:1:0712/113840.756488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.756686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.756875:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.757102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.757765:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27305e40
[1:1:0712/113840.758137:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3adeb717ba
[1:1:0712/113840.758284:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3adeb68def, 7f3adeb7177a, 7f3adeb730cf
[1:1:0712/113840.764343:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27305e40
[1:1:0712/113840.764703:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27305e40
[1:1:0712/113840.765485:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27305e40
[1:1:0712/113840.767685:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.767891:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.768138:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.768328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27305e40
[1:1:0712/113840.769885:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27305e40
[1:1:0712/113840.770405:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3adeb717ba
[1:1:0712/113840.770585:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3adeb68def, 7f3adeb7177a, 7f3adeb730cf
[1:1:0712/113840.775464:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/113840.775741:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/113840.775835:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe22224f88, 0x7ffe22224f08)
[1:1:0712/113840.791344:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/113840.797421:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2020:2020:0712/113841.384456:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2020:2020:0712/113841.385585:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2020:2036:0712/113841.406161:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2020:2036:0712/113841.406229:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[2020:2020:0712/113841.406518:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2020:2020:0712/113841.406637:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2020:2020:0712/113841.406820:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2089, 4
[1:7:0712/113841.411172:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113841.464854:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2c84126c0220
[1:1:0712/113841.465014:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[2020:2047:0712/113841.473290:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/113841.656067:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/113842.815479:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113842.819293:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113843.488790:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[2020:2020:0712/113843.625249:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2020:2020:0712/113843.625308:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/113843.894603:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113843.894912:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113843.987283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/113843.987587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113844.001153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/113844.001389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113844.265764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113844.273647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/113844.273910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113844.290889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113844.300956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/113844.301202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113844.312710:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/113844.316189:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c84126bee20
[1:1:0712/113844.316398:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2020:2020:0712/113844.330474:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[2020:2020:0712/113844.336188:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2020:2020:0712/113844.355511:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2020:2020:0712/113844.355615:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/113844.355464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[2020:2020:0712/113844.366353:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/113845.382485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f3ac87d52e0 0x2c8412896860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113845.385131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/113845.385535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113845.388599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2020:2020:0712/113845.471948:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/113845.474912:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c84126bf820
[1:1:0712/113845.475296:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2020:2020:0712/113845.485761:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/113845.503723:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/113845.503992:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2020:2020:0712/113845.506881:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2020:2020:0712/113845.517920:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2020:2020:0712/113845.518729:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2020:2036:0712/113845.521936:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2020:2036:0712/113845.522019:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[2020:2020:0712/113845.522094:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2020:2020:0712/113845.522180:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2020:2020:0712/113845.522287:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2089, 4
[1:7:0712/113845.525464:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113845.924155:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/113846.227913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f3ac87d52e0 0x2c84128d15e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113846.228522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/113846.228717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113846.229062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2020:2020:0712/113846.330263:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2020:2020:0712/113846.330489:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/113846.347441:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113846.668965:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113847.336181:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113847.336343:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113847.729136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113847.733926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 025d83a2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/113847.734182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113847.742287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[2020:2020:0712/113847.835603:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2020:2059:0712/113847.840545:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/113847.840709:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/113847.840956:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/113847.841279:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/113847.841439:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/113847.844634:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6176ebf, 1
[1:1:0712/113847.845137:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2a63c700, 0
[1:1:0712/113847.845363:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x391f72a, 3
[1:1:0712/113847.845696:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2618192b, 2
[1:1:0712/113847.845950:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 00ffffffc7632a ffffffbf6e1706 2b191826 2afffffff7ffffff9103 , 10104, 5
[1:1:0712/113847.847313:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2020:2059:0712/113847.847629:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING
[2020:2059:0712/113847.847733:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 
[2020:2059:0712/113847.848114:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2145, 5, 00c7632a bf6e1706 2b191826 2af79103 
[1:1:0712/113847.847978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3adcdac0a0, 3
[1:1:0712/113847.848237:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3adcf37080, 2
[1:1:0712/113847.848527:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3ac6bfad20, -2
[1:1:0712/113847.876561:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/113847.876940:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2618192b
[1:1:0712/113847.877304:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2618192b
[1:1:0712/113847.877971:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2618192b
[1:1:0712/113847.879442:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.879640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.879874:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.880076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.880778:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2618192b
[1:1:0712/113847.881082:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3adeb717ba
[1:1:0712/113847.881219:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3adeb68def, 7f3adeb7177a, 7f3adeb730cf
[1:1:0712/113847.887260:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2618192b
[1:1:0712/113847.887629:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2618192b
[1:1:0712/113847.888410:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2618192b
[1:1:0712/113847.890535:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.890775:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.890978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.891182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2618192b
[1:1:0712/113847.892494:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2618192b
[1:1:0712/113847.892903:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f3adeb717ba
[1:1:0712/113847.893051:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f3adeb68def, 7f3adeb7177a, 7f3adeb730cf
[1:1:0712/113847.901215:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/113847.901733:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/113847.901926:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe22224f88, 0x7ffe22224f08)
[1:1:0712/113847.916022:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/113847.920403:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/113847.929039:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113847.929793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 025d83901f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/113847.930024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113848.159082:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c84126a1220
[1:1:0712/113848.159368:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/113848.185210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113848.187205:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/113848.187458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 025d83a2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/113848.187799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113848.396959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113848.400833:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/113848.401074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 025d83a2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/113848.401360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[2020:2020:0712/113848.952497:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2020:2020:0712/113848.959517:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2020:2036:0712/113849.000629:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[2020:2036:0712/113849.000723:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[2020:2020:0712/113849.004727:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.taoche.com/
[2020:2020:0712/113849.004811:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taoche.com/, https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039, 1
[2020:2020:0712/113849.004935:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.taoche.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 18:38:48 GMT Content-Type: text/html; charset=utf-8 Content-Length: 45105 Server: Tengine Cache-Control: max-age=300 Content-Encoding: gzip swebs: 3.33 X-Via: 1.1 PSahmassxkc51:7 (Cdn Cache Server V2.0), 1.1 syd154:13 (Cdn Cache Server V2.0) Connection: keep-alive  ,2145, 5
[1:7:0712/113849.006704:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113849.023212:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/113849.042888:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.taoche.com/
[2020:2020:0712/113849.166470:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taoche.com/, https://www.taoche.com/, 1
[2020:2020:0712/113849.166530:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.taoche.com/, https://www.taoche.com
[1:1:0712/113849.229322:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113849.230123:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/113849.267603:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113849.329259:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113849.390422:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113849.390693:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113849.407660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 133 0x7f3ac68ad070 0x2c84123e93e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113849.410338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , 
            (function (a, b) {
                if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|bl
[1:1:0712/113849.410573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113849.413730:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113849.505657:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/113849.528317:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113849.600146:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/113849.700416:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/113849.756058:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/113849.765238:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113849.869084:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113849.874129:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/113849.962660:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113849.972551:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/113850.158119:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113850.240315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f3ac6c15bd0 0x2c84127ec958 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113850.257715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , /*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};ret
[1:1:0712/113850.257977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113850.462802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113850.463673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 025d83a2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113850.463966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113850.482545:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0306211, 156, 1
[1:1:0712/113850.482790:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113850.514877:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113850.551216:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113850.552179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 025d83a2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113850.552515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113850.604232:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113850.604515:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113850.607939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f3ac68ad070 0x2c841288cae0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113850.612345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , !function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==t
[1:1:0712/113850.612620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113850.631081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f3ac68ad070 0x2c841288cae0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113850.719204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1fea832a29c8, 0x2c841252ca18
[1:1:0712/113850.719483:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 5000
[1:1:0712/113850.720010:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 218
[1:1:0712/113850.720252:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 218 0x7f3ac68ad070 0x2c8412891060 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 207 0x7f3ac68ad070 0x2c841288cae0 
[1:1:0712/113850.772400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1fea832a29c8, 0x2c841252ca18
[1:1:0712/113850.772691:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 5000
[1:1:0712/113850.773178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 222
[1:1:0712/113850.773410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 222 0x7f3ac68ad070 0x2c84127e65e0 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 207 0x7f3ac68ad070 0x2c841288cae0 
[1:1:0712/113850.979849:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.375138, 2076, 1
[1:1:0712/113850.980118:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113851.281333:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113851.281600:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113851.282445:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f3ac68ad070 0x2c84129720e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113851.283487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , 
    document.getElementById("tc_top_divCityListForSEO").innerHTML = '';

[1:1:0712/113851.283744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113851.291013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f3ac68ad070 0x2c84129720e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/113851.726366:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113851.728995:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113851.729386:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113851.729841:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113851.730230:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113851.804236:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237 0x7f3ac87d52e0 0x2c84127e6ae0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113851.805336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.IpLocation.saveIpCity(201);
[1:1:0712/113851.805568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113851.848088:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7f3ac87d52e0 0x2c8412972560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113851.849193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.DynamicFunc.CB__A0({"Islogin":false,"UserName":"","LoanUserID":"","Telphone":"","HashTelphone
[1:1:0712/113851.849416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113851.853383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113852.009023:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113852.913228:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113852.913491:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113853.048941:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.135276, 826, 1
[1:1:0712/113853.049235:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113853.450084:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113853.450394:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113853.783494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f3ac6c15bd0 0x2c841299c8d8 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113853.802272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , var react=function(e){function t(r){if(n[r])return n[r].exports;var o=n[r]={exports:{},id:r,loaded:!
[1:1:0712/113853.802637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113853.825098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 372 0x7f3ac6c15bd0 0x2c841299c8d8 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
		remove user.10_e01c7a96 -> 0
		remove user.11_7730984e -> 0
		remove user.12_dc3ccd47 -> 0
		remove user.13_74c5d927 -> 0
		remove user.14_40662b6b -> 0
[1:1:0712/113854.493024:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.685476, 0, 0
[1:1:0712/113854.493297:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113854.634180:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113854.634494:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113854.642327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f3ac68ad070 0x2c84123cd6e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113854.659550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , var bitAdFrame = {
    $: function (id) {
        return document.getElementById(id)
    },
    tagA
[1:1:0712/113854.659835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113854.732398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f3ac68ad070 0x2c84123cd6e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113854.867465:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113854.868122:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113855.593817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x1fea832a29c8, 0x2c841252ca90
[1:1:0712/113855.594154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 2000
[1:1:0712/113855.594634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 395
[1:1:0712/113855.594862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f3ac68ad070 0x2c841216d660 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 382 0x7f3ac68ad070 0x2c84123cd6e0 
[1:1:0712/113902.624528:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 7.99036, 0, 0
[1:1:0712/113902.625385:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113902.801307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113902.802199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , t, (n,a){var r,l,c;if(t&&(a||4===o.readyState))if(delete fn[s],t=void 0,o.onreadystatechange=ge.noop,a)
[1:1:0712/113902.802432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113902.803748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113902.806680:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113902.807518:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1026c2bccad8
[1:1:0712/113903.660040:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113903.660355:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.664436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.670626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , var gDomain="Webtrends.yccdn.com";var gDcsId="dcs8uspw7100004fybdcyak6n_2e6k";var gFpc="WT_FPC";var 
[1:1:0712/113903.670943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113903.679424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 0
[1:1:0712/113903.680031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 478
[1:1:0712/113903.680287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 478 0x7f3ac68ad070 0x2c84148ea760 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 436 0x7f3ac68ad070 0x2c8414599560 
[1:1:0712/113903.855376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.862048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.872249:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.896375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.905563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f3ac68ad070 0x2c8414599560 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113903.920570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113904.266849:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x1fea832a29c8, 0x2c841252ca10
[1:1:0712/113904.267169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 300
[1:1:0712/113904.321858:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 507
[1:1:0712/113904.322211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7f3ac68ad070 0x2c8414372660 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 436 0x7f3ac68ad070 0x2c8414599560 
[1:1:0712/113904.323365:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1fea832a29c8, 0x2c841252ca10
[1:1:0712/113904.323567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 0
[1:1:0712/113904.324061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 508
[1:1:0712/113904.324305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7f3ac68ad070 0x2c84148e2460 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 436 0x7f3ac68ad070 0x2c8414599560 
[1:1:0712/113904.338759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113904.503556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 1000
[1:1:0712/113904.504176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 511
[1:1:0712/113904.504437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7f3ac68ad070 0x2c8414981660 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 436 0x7f3ac68ad070 0x2c8414599560 
[1:1:0712/113904.516334:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113911.714125:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 1000
[1:1:0712/113911.714436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 513
[1:1:0712/113911.714550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7f3ac68ad070 0x2c84170b8260 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 436 0x7f3ac68ad070 0x2c8414599560 
[1:1:0712/113912.425844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 218, 7f3ac91f2881
[1:1:0712/113912.450244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"207 0x7f3ac68ad070 0x2c841288cae0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.450525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"207 0x7f3ac68ad070 0x2c841288cae0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.450754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113912.451102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , (){n.isLocation||n.saveIpCity(n.cityId)}
[1:1:0712/113912.451239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113912.451917:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 222, 7f3ac91f2881
[1:1:0712/113912.462615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"207 0x7f3ac68ad070 0x2c841288cae0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.462952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"207 0x7f3ac68ad070 0x2c841288cae0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.463325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113912.463950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , (){n.User.isInit||(n.User.isInit=!0,n.User.trigCbs())}
[1:1:0712/113912.464216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113912.492302:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 395, 7f3ac91f2881
[1:1:0712/113912.515674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"382 0x7f3ac68ad070 0x2c84123cd6e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.516011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"382 0x7f3ac68ad070 0x2c84123cd6e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113912.516423:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113912.517125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , t, (){a.Storage.removeCookie("t_ck","/",a.domain.cookie)}
[1:1:0712/113912.517343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113912.579561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f3ac87d52e0 0x2c8412972fe0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113912.580277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , var bit_IpRegion = '218.241.135.34:北京市;201,北京,beijing';
var bit_locationInfo = {cityId:'2
[1:1:0712/113912.580396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113913.569867:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113913.570927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , t, (n,a){var r,l,c;if(t&&(a||4===o.readyState))if(delete fn[s],t=void 0,o.onreadystatechange=ge.noop,a)
[1:1:0712/113913.571156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113913.571812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113913.572784:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1026c2bccad8
[1:1:0712/113913.739090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 478, 7f3ac91f2881
[1:1:0712/113913.769334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.769739:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.770178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113913.771364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , gJsWtid.src="https://Webtrends.yccdn.com/dcs8uspw7100004fybdcyak6n_2e6k/wtid.js"
[1:1:0712/113913.771641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113913.776393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 508, 7f3ac91f2881
[1:1:0712/113913.784718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.784914:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.785152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113913.785516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , (){var t="placeholder"in document.createElement("input");e.SearchBox.render({inputEle:"#tc_search_tx
[1:1:0712/113913.785633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113913.823402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 507, 7f3ac91f2881
[1:1:0712/113913.832222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.832421:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113913.832656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113913.833015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , (){t.initCitySelect(),t.initYixinSearchBox(),t.initMenu(),$(".search").find(".sel-car-wrapper").hide
[1:1:0712/113913.833132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113914.207799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 511, 7f3ac91f28db
[1:1:0712/113914.239317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113914.239775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113914.240284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 565
[1:1:0712/113914.240548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7f3ac68ad070 0x2c841469cd60 , 5:3_https://www.taoche.com/, 0, , 511 0x7f3ac68ad070 0x2c8414981660 
[1:1:0712/113914.240926:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113914.242094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113914.242322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113914.576492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 513, 7f3ac91f28db
[1:1:0712/113914.607976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113914.608354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"436 0x7f3ac68ad070 0x2c8414599560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113914.608854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 576
[1:1:0712/113914.609099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 576 0x7f3ac68ad070 0x2c84127e98e0 , 5:3_https://www.taoche.com/, 0, , 513 0x7f3ac68ad070 0x2c84170b8260 
[1:1:0712/113914.609459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113914.610570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113914.610810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[2020:2020:0712/113915.570350:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/113915.670554:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/113916.005850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f3ac87d52e0 0x2c8417262e60 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113916.009917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , //IWT_ID_READY_REQUEST_ONCE='//irs01.net/idex.js';
(function(e,t){function o(e){var t;while(t=e.shi
[1:1:0712/113916.010214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113916.081715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545 0x7f3ac87d52e0 0x2c8414662b60 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113916.087675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , !function(){function Beacon(){this.initOption=util.extend({clk:!0,pv:!0,exp:!1,scrollTarget:document
[1:1:0712/113916.087978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113916.859231:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551 0x7f3ac87d52e0 0x2c84128e5ee0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113916.868325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , (function(){var h={},mt={},c={id:"b43ce35f868b496d8c3af5108a539019",dm:["taoche.com"],js:"tongji.bai
[1:1:0712/113916.868708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113916.891364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c948
[1:1:0712/113916.891580:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 100
[1:1:0712/113916.891803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 635
[1:1:0712/113916.891921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f3ac68ad070 0x2c8417b769e0 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 551 0x7f3ac87d52e0 0x2c84128e5ee0 
[1:1:0712/113917.458172:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113917.458688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113917.458805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113917.499956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113917.500425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113917.500643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113917.523983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 565, 7f3ac91f28db
[1:1:0712/113917.532781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"511 0x7f3ac68ad070 0x2c8414981660 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113917.532993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"511 0x7f3ac68ad070 0x2c8414981660 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113917.533280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 664
[1:1:0712/113917.533450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f3ac68ad070 0x2c841725b560 , 5:3_https://www.taoche.com/, 0, , 565 0x7f3ac68ad070 0x2c841469cd60 
[1:1:0712/113917.533688:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113917.534189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113917.534336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113917.672130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113917.672977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113917.673203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113917.744268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/113917.744545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113918.181451:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 576, 7f3ac91f28db
[1:1:0712/113918.190766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"513 0x7f3ac68ad070 0x2c84170b8260 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113918.190965:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"513 0x7f3ac68ad070 0x2c84170b8260 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113918.191167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 676
[1:1:0712/113918.191282:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7f3ac68ad070 0x2c8417d9b960 , 5:3_https://www.taoche.com/, 0, , 576 0x7f3ac68ad070 0x2c84127e98e0 
[1:1:0712/113918.191422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113918.191883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113918.192016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113919.110694:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113919.111202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113919.111316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113919.163396:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113919.164236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113919.164428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113920.176977:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 635, 7f3ac91f2881
[1:1:0712/113920.211307:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"551 0x7f3ac87d52e0 0x2c84128e5ee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113920.211704:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"551 0x7f3ac87d52e0 0x2c84128e5ee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113920.212181:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113920.212991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/113920.213236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113920.214340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c950
[1:1:0712/113920.214545:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 100
[1:1:0712/113920.215099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 696
[1:1:0712/113920.215364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 696 0x7f3ac68ad070 0x2c8418575ce0 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 635 0x7f3ac68ad070 0x2c8417b769e0 
[1:1:0712/113920.467363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 658 0x7f3ac87d52e0 0x2c84120463e0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113920.469789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , <!-- 
gWtId="http://127.0.0.1/'-89365280.30750945";  
gWtAccountRollup=1; 
 
// -->

[1:1:0712/113920.469971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113920.481618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 659 0x7f3ac87d52e0 0x2c8413175be0 , "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113920.482258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , _71BZF('CLAnamadDF1OE42zR1WYOQA')
[1:1:0712/113920.482495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113920.666210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , document.readyState
[1:1:0712/113920.666526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113921.842706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 664, 7f3ac91f28db
[1:1:0712/113921.883513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"565 0x7f3ac68ad070 0x2c841469cd60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113921.883936:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"565 0x7f3ac68ad070 0x2c841469cd60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113921.884432:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 732
[1:1:0712/113921.884718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f3ac68ad070 0x2c8417d12a60 , 5:3_https://www.taoche.com/, 0, , 664 0x7f3ac68ad070 0x2c841725b560 
[1:1:0712/113921.885066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113921.885977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113921.886205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113921.953530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 676, 7f3ac91f28db
[1:1:0712/113921.994699:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"576 0x7f3ac68ad070 0x2c84127e98e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113921.995070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"576 0x7f3ac68ad070 0x2c84127e98e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113921.995559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 734
[1:1:0712/113921.995854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 734 0x7f3ac68ad070 0x2c841859eee0 , 5:3_https://www.taoche.com/, 0, , 676 0x7f3ac68ad070 0x2c8417d9b960 
[1:1:0712/113921.996193:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113921.997077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113921.997304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113922.378116:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113922.378611:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113922.378989:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113923.528583:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 696, 7f3ac91f2881
[1:1:0712/113923.569891:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"635 0x7f3ac68ad070 0x2c8417b769e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113923.570316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"635 0x7f3ac68ad070 0x2c8417b769e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113923.570770:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113923.571639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/113923.571874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113923.572870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c950
[1:1:0712/113923.573096:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", 100
[1:1:0712/113923.573690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 742
[1:1:0712/113923.573940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f3ac68ad070 0x2c841739fc60 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 696 0x7f3ac68ad070 0x2c8418575ce0 
[1:1:0712/113923.612603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113923.613123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/113923.613245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113923.617284:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113923.617867:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113923.637364:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039"
[1:1:0712/113923.641101:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113923.643241:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113923.643954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252caf0
[1:1:0712/113923.644196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", 100
[1:1:0712/113923.644428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 748
[1:1:0712/113923.644545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f3ac68ad070 0x2c8417d40f60 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 699 0x7f3ac68ad070 0x2c84185703e0 
[2020:2020:0712/113923.656493:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taoche.com/, https://www.taoche.com/, 1
[2020:2020:0712/113923.656604:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.taoche.com/, https://www.taoche.com
[1:1:0712/113923.683779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , document.readyState
[1:1:0712/113923.683980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113924.714474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 732, 7f3ac91f28db
[1:1:0712/113924.724999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"664 0x7f3ac68ad070 0x2c841725b560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113924.725190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"664 0x7f3ac68ad070 0x2c841725b560 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113924.725447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 769
[1:1:0712/113924.725566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7f3ac68ad070 0x2c8418eca1e0 , 5:3_https://www.taoche.com/, 0, , 732 0x7f3ac68ad070 0x2c8417d12a60 
[1:1:0712/113924.725719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113924.726103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113924.726210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113924.739684:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 734, 7f3ac91f28db
[1:1:0712/113924.755915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"676 0x7f3ac68ad070 0x2c8417d9b960 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113924.756195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"676 0x7f3ac68ad070 0x2c8417d9b960 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113924.756690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 771
[1:1:0712/113924.756929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f3ac68ad070 0x2c8418eb1be0 , 5:3_https://www.taoche.com/, 0, , 734 0x7f3ac68ad070 0x2c841859eee0 
[1:1:0712/113924.757231:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113924.758093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113924.758271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
		remove user.13_eda884b4 -> 0
		remove user.14_a24e04c8 -> 0
		remove user.15_edca787d -> 0
[1:1:0712/113925.681873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 748, 7f3ac91f2881
[1:1:0712/113925.724577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"699 0x7f3ac68ad070 0x2c84185703e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113925.724995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"699 0x7f3ac68ad070 0x2c84185703e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113925.725488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113925.726401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/113925.726651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113925.727689:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c950
[1:1:0712/113925.727898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", 100
[1:1:0712/113925.728481:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 780
[1:1:0712/113925.728745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f3ac68ad070 0x2c841859eee0 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 748 0x7f3ac68ad070 0x2c8417d40f60 
[1:1:0712/113925.957517:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113925.958004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , v.handle, (e){return"undefined"==typeof ge||e&&ge.event.triggered===e.type?void 0:ge.event.dispatch.apply(d.el
[1:1:0712/113925.958133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113926.166273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 769, 7f3ac91f28db
[1:1:0712/113926.177478:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"732 0x7f3ac68ad070 0x2c8417d12a60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.177691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"732 0x7f3ac68ad070 0x2c8417d12a60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.177932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 800
[1:1:0712/113926.178055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f3ac68ad070 0x2c8418ec64e0 , 5:3_https://www.taoche.com/, 0, , 769 0x7f3ac68ad070 0x2c8418eca1e0 
[1:1:0712/113926.178217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113926.178600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113926.178731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113926.215786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 771, 7f3ac91f28db
[1:1:0712/113926.242677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"734 0x7f3ac68ad070 0x2c841859eee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.243007:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"734 0x7f3ac68ad070 0x2c841859eee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.243437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 802
[1:1:0712/113926.243628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f3ac68ad070 0x2c841857b860 , 5:3_https://www.taoche.com/, 0, , 771 0x7f3ac68ad070 0x2c8418eb1be0 
[1:1:0712/113926.243914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113926.244600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113926.244800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113926.895758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 780, 7f3ac91f2881
[1:1:0712/113926.930112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"748 0x7f3ac68ad070 0x2c8417d40f60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.930477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"748 0x7f3ac68ad070 0x2c8417d40f60 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113926.930842:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113926.931530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/113926.931715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113926.932544:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c950
[1:1:0712/113926.932708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", 100
[1:1:0712/113926.933056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 807
[1:1:0712/113926.933176:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7f3ac68ad070 0x2c841923dd60 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 780 0x7f3ac68ad070 0x2c841859eee0 
[1:1:0712/113927.166256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 800, 7f3ac91f28db
[1:1:0712/113927.177893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"769 0x7f3ac68ad070 0x2c8418eca1e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.178120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"769 0x7f3ac68ad070 0x2c8418eca1e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.178354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 815
[1:1:0712/113927.178467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f3ac68ad070 0x2c8419296260 , 5:3_https://www.taoche.com/, 0, , 800 0x7f3ac68ad070 0x2c8418ec64e0 
[1:1:0712/113927.178622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113927.179021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113927.179132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113927.204865:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 802, 7f3ac91f28db
[1:1:0712/113927.216337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"771 0x7f3ac68ad070 0x2c8418eb1be0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.216545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"771 0x7f3ac68ad070 0x2c8418eb1be0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.216777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 817
[1:1:0712/113927.216891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 817 0x7f3ac68ad070 0x2c84195ca4e0 , 5:3_https://www.taoche.com/, 0, , 802 0x7f3ac68ad070 0x2c841857b860 
[1:1:0712/113927.217069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113927.217461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113927.217572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113927.876357:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 807, 7f3ac91f2881
[1:1:0712/113927.887810:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0a6850bc2860","ptid":"780 0x7f3ac68ad070 0x2c841859eee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.888029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taoche.com/","ptid":"780 0x7f3ac68ad070 0x2c841859eee0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113927.888274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113927.888643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/113927.888754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113927.889112:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1fea832a29c8, 0x2c841252c950
[1:1:0712/113927.889312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", 100
[1:1:0712/113927.889780:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taoche.com/, 830
[1:1:0712/113927.889971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7f3ac68ad070 0x2c84127530e0 , 5:3_https://www.taoche.com/, 1, -5:3_https://www.taoche.com/, 807 0x7f3ac68ad070 0x2c841923dd60 
[1:1:0712/113928.182043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 815, 7f3ac91f28db
[1:1:0712/113928.217183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"800 0x7f3ac68ad070 0x2c8418ec64e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113928.217517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"800 0x7f3ac68ad070 0x2c8418ec64e0 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113928.217921:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 838
[1:1:0712/113928.218116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f3ac68ad070 0x2c8417deaf60 , 5:3_https://www.taoche.com/, 0, , 815 0x7f3ac68ad070 0x2c8419296260 
[1:1:0712/113928.218440:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113928.219170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , Taoche.autotrackingbind()
[1:1:0712/113928.219371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
[1:1:0712/113928.250933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 817, 7f3ac91f28db
[1:1:0712/113928.262998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"802 0x7f3ac68ad070 0x2c841857b860 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113928.263230:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"802 0x7f3ac68ad070 0x2c841857b860 ","rf":"5:3_https://www.taoche.com/"}
[1:1:0712/113928.263488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.taoche.com/, 841
[1:1:0712/113928.263602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f3ac68ad070 0x2c841928f060 , 5:3_https://www.taoche.com/, 0, , 817 0x7f3ac68ad070 0x2c84195ca4e0 
[1:1:0712/113928.263744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat"
[1:1:0712/113928.264118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taoche.com/, 0a6850bc2860, , , btnclickbind()
[1:1:0712/113928.264229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taoche.com/sem/mercedesbenz/?hd_source=2956&from=3622039#navStat", "www.taoche.com", 3, 1, , , 0
