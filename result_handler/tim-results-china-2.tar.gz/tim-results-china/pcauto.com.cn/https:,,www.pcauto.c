[0712/114213.163917:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114213.164382:INFO:switcher_clone.cc(787)] backtrace rip is 7ff9f7d03891
[0712/114214.023360:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114214.023636:INFO:switcher_clone.cc(787)] backtrace rip is 7fc2d6f98891
[1:1:0712/114214.027787:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/114214.027967:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/114214.033192:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[2634:2634:0712/114215.251953:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/34286324-d380-4e27-86ac-426c893a99a2
[0712/114215.476300:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114215.476736:INFO:switcher_clone.cc(787)] backtrace rip is 7f8cabab4891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2675:2675:0712/114215.705418:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2675
[2687:2687:0712/114215.705892:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2687
[2634:2634:0712/114215.765098:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2634:2671:0712/114215.765830:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/114215.766050:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114215.766311:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114215.766967:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114215.767135:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/114215.770543:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25a8f2c9, 1
[1:1:0712/114215.770917:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x97a5bc3, 0
[1:1:0712/114215.771081:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1bcae294, 3
[1:1:0712/114215.771244:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x5c6cb06, 2
[1:1:0712/114215.771438:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc35b7a09 ffffffc9fffffff2ffffffa825 06ffffffcbffffffc605 ffffff94ffffffe2ffffffca1b , 10104, 4
[1:1:0712/114215.772495:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2634:2671:0712/114215.772701:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�[z	��%�����c�'7
[2634:2671:0712/114215.772809:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �[z	��%�����xLc�'7
[1:1:0712/114215.772932:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2d51d30a0, 3
[2634:2671:0712/114215.773102:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/114215.773146:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2d535e080, 2
[2634:2671:0712/114215.773186:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2695, 4, c35b7a09 c9f2a825 06cbc605 94e2ca1b 
[1:1:0712/114215.773319:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2bf021d20, -2
[1:1:0712/114215.786716:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114215.787390:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5c6cb06
[1:1:0712/114215.788118:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5c6cb06
[1:1:0712/114215.789188:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5c6cb06
[1:1:0712/114215.789718:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.789849:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.790008:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.790118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.790351:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5c6cb06
[1:1:0712/114215.790496:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2d6f987ba
[1:1:0712/114215.790570:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2d6f8fdef, 7fc2d6f9877a, 7fc2d6f9a0cf
[1:1:0712/114215.792043:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5c6cb06
[1:1:0712/114215.792204:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5c6cb06
[1:1:0712/114215.792470:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5c6cb06
[1:1:0712/114215.793178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.793289:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.793382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.793473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5c6cb06
[1:1:0712/114215.793947:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5c6cb06
[1:1:0712/114215.794106:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2d6f987ba
[1:1:0712/114215.794188:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2d6f8fdef, 7fc2d6f9877a, 7fc2d6f9a0cf
[1:1:0712/114215.798555:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114215.798948:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114215.799044:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffda383d0c8, 0x7ffda383d048)
[1:1:0712/114215.814119:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114215.820483:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2634:2634:0712/114216.374987:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2634:2634:0712/114216.376167:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2634:2646:0712/114216.395607:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2634:2646:0712/114216.395714:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[2634:2634:0712/114216.395755:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2634:2634:0712/114216.395836:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2634:2634:0712/114216.396054:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2695, 4
[1:7:0712/114216.398984:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[2634:2663:0712/114216.459825:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/114216.512934:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3e530b4a5220
[1:1:0712/114216.513159:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/114216.822608:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/114218.087817:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114218.091368:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2634:2634:0712/114218.428218:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2634:2634:0712/114218.428328:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114219.108416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114219.267276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114219.267481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114219.274578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114219.274803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114219.325376:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114219.325574:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114219.781828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114219.784573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114219.784715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114219.797392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114219.800531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114219.800669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114219.804919:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2634:2634:0712/114219.808425:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114219.809088:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3e530b4a3e20
[1:1:0712/114219.809722:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2634:2634:0712/114219.814991:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2634:2634:0712/114219.851148:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2634:2634:0712/114219.851311:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114219.922518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114220.541276:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fc2c0bfc2e0 0x3e530b6b92e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114220.542690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/114220.542967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114220.544621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2634:2634:0712/114220.618275:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114220.620489:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3e530b4a4820
[1:1:0712/114220.620748:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2634:2634:0712/114220.627604:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/114220.639708:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/114220.639957:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2634:2634:0712/114220.649381:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2634:2634:0712/114220.661137:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2634:2634:0712/114220.662107:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2634:2646:0712/114220.667945:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2634:2646:0712/114220.668063:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[2634:2634:0712/114220.668186:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2634:2634:0712/114220.668261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2634:2634:0712/114220.668393:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2695, 4
[1:7:0712/114220.676845:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114221.210509:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/114221.707712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fc2c0bfc2e0 0x3e530b864360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114221.708830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/114221.709294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114221.710093:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2634:2634:0712/114221.862659:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2634:2634:0712/114221.862771:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/114221.883706:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114222.148489:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114222.567305:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114222.567615:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114222.766726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114222.771360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/114222.771702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114222.779382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114222.935550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114222.936355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1b0ef96c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/114222.936593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[2634:2634:0712/114222.993095:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2634:2671:0712/114222.993516:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/114222.993753:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114222.994028:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114222.994454:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114222.994701:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/114222.998041:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x396d9474, 1
[1:1:0712/114222.998469:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e96e038, 0
[1:1:0712/114222.998679:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x385ed492, 3
[1:1:0712/114222.998870:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c15d260, 2
[1:1:0712/114222.999057:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 38ffffffe0ffffff962e 74ffffff946d39 60ffffffd2153c ffffff92ffffffd45e38 , 10104, 5
[1:1:0712/114223.000162:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2634:2671:0712/114223.000456:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING8��.t�m9`�<��^8λ'7
[2634:2671:0712/114223.000530:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 8��.t�m9`�<��^8Hλ'7
[1:1:0712/114223.000712:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2d51d30a0, 3
[2634:2671:0712/114223.000917:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2739, 5, 38e0962e 74946d39 60d2153c 92d45e38 
[1:1:0712/114223.000974:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2d535e080, 2
[1:1:0712/114223.001212:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2bf021d20, -2
[1:1:0712/114223.024322:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114223.024768:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c15d260
[1:1:0712/114223.025126:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c15d260
[1:1:0712/114223.025797:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c15d260
[1:1:0712/114223.027376:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.027696:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.027925:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.028145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.028861:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c15d260
[1:1:0712/114223.029185:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2d6f987ba
[1:1:0712/114223.029360:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2d6f8fdef, 7fc2d6f9877a, 7fc2d6f9a0cf
[1:1:0712/114223.036470:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c15d260
[1:1:0712/114223.036884:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c15d260
[1:1:0712/114223.037628:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c15d260
[1:1:0712/114223.037368:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114223.039023:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114223.039258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114223.039543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114223.040077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.040335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.040558:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.040822:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c15d260
[1:1:0712/114223.042117:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c15d260
[1:1:0712/114223.042537:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2d6f987ba
[1:1:0712/114223.042778:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2d6f8fdef, 7fc2d6f9877a, 7fc2d6f9a0cf
[1:1:0712/114223.051744:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114223.052372:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114223.052578:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffda383d0c8, 0x7ffda383d048)
[1:1:0712/114223.065404:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114223.070778:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/114223.161653:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114223.162600:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/114223.162954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/114223.163252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114223.264118:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3e530b476220
[1:1:0712/114223.264391:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/114223.651051:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[2634:2634:0712/114223.948116:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2634:2634:0712/114223.955425:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2634:2646:0712/114223.970167:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[2634:2646:0712/114223.970269:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[2634:2634:0712/114223.970679:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.pcauto.com.cn/
[2634:2634:0712/114223.970762:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.pcauto.com.cn/, https://www.pcauto.com.cn/taglist/tagword1341.html, 1
[2634:2634:0712/114223.970939:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.pcauto.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 18:42:23 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Expires: Fri, 12 Jul 2019 18:42:24 GMT Server: Tengine Cache-Control: max-age=600 Vary: Accept-Encoding Content-Encoding: gzip X-Ser: BC197_dx-lt-yd-jiangsu-taizhou-4-cache-11, BC88_cl-shanghai-shanghai-1-cache-1, BC165_ck-shanghai-shanghai-2-cache-1, BC158_ck-beijing-beijing-2-cache-2  ,2739, 5
[1:7:0712/114223.974749:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114224.028302:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.pcauto.com.cn/
[1:1:0712/114224.118001:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[2634:2634:0712/114224.139718:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.pcauto.com.cn/, https://www.pcauto.com.cn/, 1
[2634:2634:0712/114224.139821:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.pcauto.com.cn/, https://www.pcauto.com.cn
[1:1:0712/114224.147518:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114224.212465:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/114224.248076:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114224.285665:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/114224.301991:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114224.359255:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114224.359539:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114224.417732:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/114224.499240:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/114224.531987:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/114224.617826:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/114224.803239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114224.804300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114224.804577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114224.874503:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114224.875430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/114224.875748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114224.938807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 166 0x7fc2becd4070 0x3e530b6242e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114224.942565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , ,  
!function(a,b){var o,c=navigator.userAgent.toLowerCase(),d=location.href.toLowerCase(),e=location.
[1:1:0712/114224.942888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114224.946603:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114225.008826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 166 0x7fc2becd4070 0x3e530b6242e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114225.028062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114225.029287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1b0ef97ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/114225.029595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114225.136891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 166 0x7fc2becd4070 0x3e530b6242e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114225.201611:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.245142, 69, 1
[1:1:0712/114225.201883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114225.952809:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114225.953111:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114225.961993:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00869203, 51, 1
[1:1:0712/114225.962251:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/114226.635426:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114226.639325:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114226.639915:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114226.640327:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114226.640845:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114226.874956:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114226.875261:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114226.876437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7fc2becd4070 0x3e530b5a30e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114226.878012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
if(/ad=3987/.test(location))+function(ch,chout,now,ck,chf){ now=1*now||1*new Date();
function run(s
[1:1:0712/114226.878241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114226.903251:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.02777, 122, 1
[1:1:0712/114226.903633:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.115389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7fc2c0bfc2e0 0x3e530b69cb60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.116565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , try{ document.cookie = "c=423yfo7a;domain=" + top.location.href.replace(/http:\/\/.+?\.(.*?)\/.*/, '
[1:1:0712/114227.116847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114227.366673:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.367075:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.368055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc2becd4070 0x3e530b6a02e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.369098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
var menu = document.getElementById("chaMenu").getElementsByTagName("li");
for(var i=0;i<menu.length
[1:1:0712/114227.369382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114227.402682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc2becd4070 0x3e530b6a02e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.406892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc2becd4070 0x3e530b6a02e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.414134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc2becd4070 0x3e530b6a02e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.419088:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7fc2becd4070 0x3e530b6a02e0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.425394:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0581059, 62, 1
[1:1:0712/114227.425637:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.680569:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.680854:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.681693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.682737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
function callbackFunc_3(data){
var total = typeof(data.total)=='undefined'?0:data.total;
var target
[1:1:0712/114227.682961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114227.688552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.695410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.697414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.704266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.710182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.718704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.721892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353 0x7fc2becd4070 0x3e530b699de0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.725497:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0444341, 52, 1
[1:1:0712/114227.725723:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.972949:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114227.973251:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.974106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.975195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
function callbackFunc_7(data){
var total = typeof(data.total)=='undefined'?0:data.total;
var target
[1:1:0712/114227.975435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114227.979153:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.987062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.992983:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114227.999713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.004097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.011081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.014637:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 375 0x7fc2becd4070 0x3e530b6c3ee0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.021655:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.04826, 52, 1
[1:1:0712/114228.021944:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114228.328278:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114228.328557:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.329544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.330594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
function callbackFunc_11(data){
var total = typeof(data.total)=='undefined'?0:data.total;
var targe
[1:1:0712/114228.330818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114228.335532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.343728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.348894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.354308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.359289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.366398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.372053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fc2becd4070 0x3e530b666ae0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.378161:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.049433, 52, 1
[1:1:0712/114228.378410:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114228.807085:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114228.807375:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.808317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fc2becd4070 0x3e530b51afe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.809431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
function callbackFunc_15(data){
var total = typeof(data.total)=='undefined'?0:data.total;
var targe
[1:1:0712/114228.809660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114228.819338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fc2becd4070 0x3e530b51afe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.825116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fc2becd4070 0x3e530b51afe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.953019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429, "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.953938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
[1:1:0712/114228.954180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114228.956613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429, "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.960183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429, "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.963513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429, "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114228.986649:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.030978, 185, 1
[1:1:0712/114228.986974:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114229.339952:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114229.340256:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114229.342558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fc2becd4070 0x3e530b596160 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114229.345848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , // 图片滚动按需加载
var Lazy={eCatch:{},eHandle:0,addEvent:function(c,b,a){if(c.addEventLis
[1:1:0712/114229.346089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114229.350526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fc2becd4070 0x3e530b596160 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114230.327310:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.987045, 0, 0
[1:1:0712/114230.327738:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114230.633409:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114230.633740:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114230.634962:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fc2becd4070 0x3e530b856fe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114230.636047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
Lazy.create({lazyId:'doc', trueSrc:'src2'})

[1:1:0712/114230.636288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114230.647002:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fc2becd4070 0x3e530b856fe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114230.653272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7fc2becd4070 0x3e530b856fe0 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114230.662092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x394a104a29c8, 0x3e530b08a1a8
[1:1:0712/114230.662379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 500
[1:1:0712/114230.662904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 483
[1:1:0712/114230.663139:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7fc2becd4070 0x3e530b85b5e0 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 468 0x7fc2becd4070 0x3e530b856fe0 
[1:1:0712/114230.679500:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0455911, 74, 1
[1:1:0712/114230.679828:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114231.202786:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114231.203082:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.204168:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.206373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , 
var getddCommon={setCookie:function(name,value,expires,path,domain,secure){var expires=new Date();e
[1:1:0712/114231.206608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114231.214436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.219362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.224983:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.226000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.228203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.229922:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.230591:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 999, 0x394a104a29c8, 0x3e530b08a1a0
[1:1:0712/114231.230736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 999
[1:1:0712/114231.231209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 511
[1:1:0712/114231.231434:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 511 0x7fc2becd4070 0x3e530b85ece0 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 492 0x7fc2becd4070 0x3e530b86da60 
[1:1:0712/114231.234171:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.239460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.244364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.249026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fc2becd4070 0x3e530b86da60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.251551:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.456112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 483, 7fc2c1619881
[1:1:0712/114231.480059:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"468 0x7fc2becd4070 0x3e530b856fe0 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114231.480489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"468 0x7fc2becd4070 0x3e530b856fe0 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114231.480874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.481636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){
targets[rom].style.display = 'block';
if(targets[rom].getAttribute('data-load')=='y'){
var imgs 
[1:1:0712/114231.481888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114231.780990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537 0x7fc2c0bfc2e0 0x3e530b872360 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.782115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , /*!  svn:http://js.3conline.com/pcauto/common/js/pcauto.login.1.7.js*/
(function(b,f){function e(h,
[1:1:0712/114231.782249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114231.808371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7fc2c0bfc2e0 0x3e530b85e060 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.809068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0712/114231.809197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114231.993544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114231.994520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , oimg.onload, (){
_img.setAttribute('src',_src);
_img.removeAttribute('data-src');
}
[1:1:0712/114231.994756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.095821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.096361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , oimg.onload, (){
_img.setAttribute('src',_src);
_img.removeAttribute('data-src');
}
[1:1:0712/114232.096478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.121625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.122092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , oimg.onload, (){
_img.setAttribute('src',_src);
_img.removeAttribute('data-src');
}
[1:1:0712/114232.122208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.287638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562 0x7fc2c0bfc2e0 0x3e530b1d0e60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.288687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , _1CJ6Q('CLAnamadDF1OE42zR1WYOQA')
[1:1:0712/114232.288882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.345668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 511, 7fc2c1619881
[1:1:0712/114232.355405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"492 0x7fc2becd4070 0x3e530b86da60 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.355605:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"492 0x7fc2becd4070 0x3e530b86da60 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.355776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.356331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){var js=document.createElement("script"); js.src="//ivy.pconline.com.cn/show?id=auto.other.test15.
[1:1:0712/114232.356546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.362140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x394a104a29c8, 0x3e530b08a150
[1:1:0712/114232.362319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 2000
[1:1:0712/114232.362708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 568
[1:1:0712/114232.362899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7fc2becd4070 0x3e530b8605e0 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 511 0x7fc2becd4070 0x3e530b85ece0 
[1:1:0712/114232.560963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573 0x7fc2c0bfc2e0 0x3e530b699a60 , "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.562894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , ;(function(){
    window.__ivyTest15Count__=[];window.__tid__='auto.other.test15.';
    var srcs =
[1:1:0712/114232.563075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.564230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x394a104a29c8, 0x3e530b08a1a0
[1:1:0712/114232.564342:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 1
[1:1:0712/114232.564538:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 577
[1:1:0712/114232.564649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 577 0x7fc2becd4070 0x3e530bc67360 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 573 0x7fc2c0bfc2e0 0x3e530b699a60 
[1:1:0712/114232.617671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 577, 7fc2c1619881
[1:1:0712/114232.630564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"573 0x7fc2c0bfc2e0 0x3e530b699a60 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.630779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"573 0x7fc2c0bfc2e0 0x3e530b699a60 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.630962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.631383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){
var ua = navigator.userAgent,win=window,doc=document;
if(/Baiduspider|PhantomJS|HeadlessChrome|B
[1:1:0712/114232.631495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.638903:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x394a104a29c8, 0x3e530b08a150
[1:1:0712/114232.639100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 1000
[1:1:0712/114232.639357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 582
[1:1:0712/114232.639477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7fc2becd4070 0x3e530b675ee0 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 577 0x7fc2becd4070 0x3e530bc67360 
[1:1:0712/114232.639723:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 6000, 0x394a104a29c8, 0x3e530b08a150
[1:1:0712/114232.639820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 6000
[1:1:0712/114232.639985:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 583
[1:1:0712/114232.640145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7fc2becd4070 0x3e530b1d0460 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 577 0x7fc2becd4070 0x3e530bc67360 
[1:1:0712/114232.653147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 269, 0x394a104a29c8, 0x3e530b08a150
[1:1:0712/114232.653317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 269
[1:1:0712/114232.653513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 587
[1:1:0712/114232.653624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 587 0x7fc2becd4070 0x3e530b6574e0 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 577 0x7fc2becd4070 0x3e530bc67360 
[1:1:0712/114232.935005:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 587, 7fc2c1619881
[1:1:0712/114232.946280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.946471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114232.946634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114232.947092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){show(s);}
[1:1:0712/114232.947296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114232.948597:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/114232.952469:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3e530bb72e20
[1:1:0712/114232.952640:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/114232.964705:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/114232.964914:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.pcauto.com.cn
[1:1:0712/114232.966227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x394a104a29c8, 0x3e530b08a150
[1:1:0712/114232.966381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pcauto.com.cn/taglist/tagword1341.html", 30000
[1:1:0712/114232.966625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 598
[1:1:0712/114232.966770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7fc2becd4070 0x3e530b6a3e60 , 5:3_https://www.pcauto.com.cn/, 1, -5:3_https://www.pcauto.com.cn/, 587 0x7fc2becd4070 0x3e530b6574e0 
[1:1:0712/114233.671880:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 582, 7fc2c1619881
[1:1:0712/114233.687051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114233.687358:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114233.687596:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114233.688026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , watcher, (){if(win.outerHeight&&win.innerHeight&&win.outerHeight-Math.floor((win.outerWidth-10)/win.innerWidt
[1:1:0712/114233.688176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114234.393935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 568, 7fc2c1619881
[1:1:0712/114234.420907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"511 0x7fc2becd4070 0x3e530b85ece0 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114234.421243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"511 0x7fc2becd4070 0x3e530b85ece0 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114234.421542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114234.422189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){if(window['__test15_exist']) return;var js;(js=document.createElement("script")).src="//mgcdn2.pc
[1:1:0712/114234.422367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114238.693990:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.pcauto.com.cn/, 583, 7fc2c1619881
[1:1:0712/114238.708480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08893c402860","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114238.708668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.pcauto.com.cn/","ptid":"577 0x7fc2becd4070 0x3e530bc67360 ","rf":"5:3_https://www.pcauto.com.cn/"}
[1:1:0712/114238.708838:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pcauto.com.cn/taglist/tagword1341.html"
[1:1:0712/114238.709149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , (){ if(!ivyMouseTag){ unbind(doc,'mousemove',fn); clear();}}
[1:1:0712/114238.709267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/114248.766109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.pcauto.com.cn/, 08893c402860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/114248.766358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pcauto.com.cn/taglist/tagword1341.html", "www.pcauto.com.cn", 3, 1, , , 0
[2634:2634:0712/114249.245777:INFO:CONSOLE(779)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ivy.pconline.com.cn/show4?id=auto.qcyp.dhlwymc., is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.pcauto.com.cn/taglist/tagword1341.html (779)
[2634:2634:0712/114249.249894:INFO:CONSOLE(779)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ivy.pconline.com.cn/show4?id=auto.qcyp.dhlwymc., is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.pcauto.com.cn/taglist/tagword1341.html (779)
[2634:2634:0712/114249.452858:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[2634:2634:0712/114249.461240:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: test15ShowIfr-https:bda2c95a/dc531065/10557cf5/92ca647c.html?3-38568750-16-954515&s&uv-__v0c14083dcdde7b1b22ac95eef773daf8-900000-https://www.pcauto.com.cn/taglist/tagword1341.html--true, 4, 4, 
[2634:2634:0712/114249.475178:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.pcauto.com.cn/
[2634:2634:0712/114249.500695:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/114250.249647:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
