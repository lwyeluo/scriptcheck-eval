[0712/113452.338259:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113452.338736:INFO:switcher_clone.cc(787)] backtrace rip is 7ff1e2fb4891
[0712/113453.362199:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113453.362452:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f3e644891
[1:1:0712/113453.366561:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/113453.366732:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/113453.371348:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1413:1413:0712/113454.583723:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f5fa4a52-4858-4637-96b8-b349b2b99cf3
[0712/113454.871754:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/113454.872254:INFO:switcher_clone.cc(787)] backtrace rip is 7f2b6bc3e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1413:1413:0712/113455.044797:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1413:1443:0712/113455.045800:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/113455.046045:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/113455.046273:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/113455.046860:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/113455.047047:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/113455.049967:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11b7e6b5, 1
[1:1:0712/113455.050282:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xe1893f5, 0
[1:1:0712/113455.050445:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x4c5b0ca, 3
[1:1:0712/113455.050620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x244842ee, 2
[1:1:0712/113455.050813:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff5ffffff93180e ffffffb5ffffffe6ffffffb711 ffffffee424824 ffffffcaffffffb0ffffffc504 , 10104, 4
[1:1:0712/113455.051751:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1413:1443:0712/113455.052036:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�����BH$ʰ�]��
[1:1:0712/113455.052021:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f3c87f0a0, 3
[1413:1443:0712/113455.052123:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �����BH$ʰ��]��
[1:1:0712/113455.052165:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f3ca0a080, 2
[1:1:0712/113455.052259:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f266cdd20, -2
[1413:1443:0712/113455.052431:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1413:1443:0712/113455.052505:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1458, 4, f593180e b5e6b711 ee424824 cab0c504 
[1445:1445:0712/113455.058842:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1445
[1459:1459:0712/113455.059280:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1459
[1:1:0712/113455.060712:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/113455.061339:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 244842ee
[1:1:0712/113455.062036:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 244842ee
[1:1:0712/113455.063131:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 244842ee
[1:1:0712/113455.063665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.063771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.063863:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.064012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.064246:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 244842ee
[1:1:0712/113455.064383:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f3e6447ba
[1:1:0712/113455.064459:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f3e63bdef, 7f7f3e64477a, 7f7f3e6460cf
[1:1:0712/113455.065883:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 244842ee
[1:1:0712/113455.066072:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 244842ee
[1:1:0712/113455.066350:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 244842ee
[1:1:0712/113455.067171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.067289:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.067388:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.067482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 244842ee
[1:1:0712/113455.067961:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 244842ee
[1:1:0712/113455.068125:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f3e6447ba
[1:1:0712/113455.068201:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f3e63bdef, 7f7f3e64477a, 7f7f3e6460cf
[1:1:0712/113455.070359:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/113455.070663:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/113455.070759:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc23be2ef8, 0x7ffc23be2e78)
[1:1:0712/113455.079813:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/113455.085695:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1413:1436:0712/113455.669753:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1413:1413:0712/113455.711318:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1413:1413:0712/113455.712758:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1413:1424:0712/113455.729179:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1413:1413:0712/113455.729285:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1413:1424:0712/113455.729305:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1413:1413:0712/113455.729350:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1413:1413:0712/113455.729444:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,1458, 4
[1:7:0712/113455.732164:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113455.736613:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3f313392d220
[1:1:0712/113455.736833:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/113456.262716:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/113457.319327:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113457.322980:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1413:1413:0712/113457.756982:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1413:1413:0712/113457.757112:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/113458.304223:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113458.432488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/113458.432812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113458.438256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/113458.438505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113458.483793:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113458.484058:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113458.925614:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113458.933681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/113458.933945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113458.985591:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113458.996058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/113458.996331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113459.011346:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1413:1413:0712/113459.014383:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/113459.014649:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f313392be20
[1:1:0712/113459.014856:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1413:1413:0712/113459.028805:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1413:1413:0712/113459.070526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1413:1413:0712/113459.070681:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/113459.093562:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113459.802678:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f7f282a82e0 0x3f3133b6a460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113459.804090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/113459.804337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113459.805860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1413:1413:0712/113459.850412:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/113459.852129:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f313392c820
[1:1:0712/113459.852341:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1413:1413:0712/113459.853240:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/113459.872116:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/113459.872363:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1413:1413:0712/113459.873437:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1413:1413:0712/113459.881092:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1413:1413:0712/113459.882093:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1413:1424:0712/113459.887967:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1413:1413:0712/113459.888011:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1413:1413:0712/113459.888051:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1413:1424:0712/113459.888051:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1413:1413:0712/113459.888116:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,1458, 4
[1:7:0712/113459.889390:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113500.594037:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/113501.077595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f7f282a82e0 0x3f3133b62560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/113501.079685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/113501.079962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113501.080750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1413:1413:0712/113501.239437:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1413:1413:0712/113501.239555:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/113501.276928:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113501.648570:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113502.293842:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113502.294158:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113502.706992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113502.708988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/113502.709164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113502.711962:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1413:1413:0712/113502.765794:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1413:1443:0712/113502.766448:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/113502.766828:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/113502.767082:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[1:1:0712/113502.767170:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[3:3:0712/113502.767662:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/113502.767838:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/113502.767888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2406914a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/113502.768091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/113502.772003:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x30977320, 1
[1:1:0712/113502.772742:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x34f0777e, 0
[1:1:0712/113502.773044:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x24f189fa, 3
[1:1:0712/113502.773320:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3a6963e6, 2
[1:1:0712/113502.773689:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7e77fffffff034 2073ffffff9730 ffffffe663693a fffffffaffffff89fffffff124 , 10104, 5
[1:1:0712/113502.775500:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1413:1443:0712/113502.775922:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING~w�4 s�0�ci:���$���
[1413:1443:0712/113502.776062:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ~w�4 s�0�ci:���$����
[1413:1443:0712/113502.776443:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1527, 5, 7e77f034 20739730 e663693a fa89f124 
[1:1:0712/113502.776304:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f3c87f0a0, 3
[1:1:0712/113502.776744:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f3ca0a080, 2
[1:1:0712/113502.777097:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f266cdd20, -2
[1:1:0712/113502.813390:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/113502.813782:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3a6963e6
[1:1:0712/113502.814103:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3a6963e6
[1:1:0712/113502.814772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3a6963e6
[1:1:0712/113502.816243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.816440:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.816673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.816859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.817559:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3a6963e6
[1:1:0712/113502.817860:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f3e6447ba
[1:1:0712/113502.818001:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f3e63bdef, 7f7f3e64477a, 7f7f3e6460cf
[1:1:0712/113502.823990:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3a6963e6
[1:1:0712/113502.824370:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3a6963e6
[1:1:0712/113502.825145:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3a6963e6
[1:1:0712/113502.827275:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.827525:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.827728:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.827928:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3a6963e6
[1:1:0712/113502.829237:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3a6963e6
[1:1:0712/113502.829638:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f3e6447ba
[1:1:0712/113502.829787:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f3e63bdef, 7f7f3e64477a, 7f7f3e6460cf
[1:1:0712/113502.838070:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/113502.838647:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/113502.838815:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc23be2ef8, 0x7ffc23be2e78)
[1:1:0712/113502.852947:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/113502.857483:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/113502.872411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113502.873856:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/113502.874114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/113502.874390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113503.037244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113503.052474:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/113503.053097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/113503.053374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113503.308782:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f31338f2220
[1:1:0712/113503.309037:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/113504.027546:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/113504.065628:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/113504.131564:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1413:1413:0712/113504.226841:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1413:1413:0712/113504.229439:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/113504.231886:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1413:1424:0712/113504.243483:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[1413:1424:0712/113504.243576:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1413:1413:0712/113504.243728:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bbs.pcauto.com.cn/
[1413:1413:0712/113504.243819:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.pcauto.com.cn/, https://bbs.pcauto.com.cn/topic-20068130.html, 1
[1413:1413:0712/113504.244010:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://bbs.pcauto.com.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 18:35:03 GMT Server: Tengine Content-Type: text/html; charset=GBK Cache-Control: max-age=7200 Expires: Fri, 12 Jul 2019 20:33:31 GMT Content-Language: zh-CN Via: http/1.1 autobbs-html (PCSERVER/4.2.2 [cHs f ]) Cache-Control: no-store Content-Encoding: gzip Age: 1 X-Via: 1.1 jchk22:8 (Cdn Cache Server V2.0) Transfer-Encoding: chunked Connection: keep-alive  ,1527, 5
[1:7:0712/113504.248093:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/113504.268529:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://bbs.pcauto.com.cn/
[1:1:0712/113504.306845:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1413:1413:0712/113504.402606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bbs.pcauto.com.cn/, https://bbs.pcauto.com.cn/, 1
[1413:1413:0712/113504.402714:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bbs.pcauto.com.cn/, https://bbs.pcauto.com.cn
[1:1:0712/113504.415712:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113504.419654:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/113504.539019:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/113504.551363:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113504.584615:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113504.635521:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/113504.652406:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113504.652636:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113504.830102:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113504.960254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113504.963411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , var deviceJump=(function(){var w=function(){};var r=navigator.userAgent.toLowerCase(),c=window.locat
[1:1:0712/113504.963667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113504.967118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113504.983829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 155, "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113505.110997:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113505.120173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.120618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.120755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.174870:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.175926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113505.176298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.215555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.216010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.216186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.234588:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.235013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113505.235164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.291792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.292688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.292922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.390989:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.391514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113505.391661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.432595:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.433483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.433722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.562434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.563543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113505.563830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.775223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.775691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.775830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.818524:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/113505.822445:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.823252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/113505.823507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/113505.919612:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/113505.920082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2406915ce5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/113505.920231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/113509.274390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f7f26380070 0x3f3133b9fa60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113509.276097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , var _ivyIDs=window._ivyIDs||"";
var _tmpIvyIDs=window._tmpIvyIDs||"";
var _cntUrl=window._cntUrl||""
[1:1:0712/113509.276292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113509.296683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f7f26380070 0x3f3133b9fa60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113509.299265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413 0x7f7f26380070 0x3f3133b9fa60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113509.319958:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0237892, 62, 1
[1:1:0712/113509.320134:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.233477:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.233667:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.236388:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00268197, 51, 1
[1:1:0712/113510.236527:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.436196:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.436382:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.436867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 494 0x7f7f26380070 0x3f3133d23060 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.437557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
if(/ad=3987/.test(location))+function(ch,chout,now,ck,chf){ now=1*now||1*new Date();
function run(s
[1:1:0712/113510.437677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113510.446443:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0101058, 74, 1
[1:1:0712/113510.446711:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.520046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7f7f282a82e0 0x3f3133b9f460 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.521459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , try{ document.cookie = "c=423yfo7a;domain=" + top.location.href.replace(/http:\/\/.+?\.(.*?)\/.*/, '
[1:1:0712/113510.521728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113510.758715:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113510.758951:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.759868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f7f26380070 0x3f3133bbe3e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.761357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
    (function(){
        var nav = document.getElementById('Jheader');
        var li= nav.getEleme
[1:1:0712/113510.761558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113510.770137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f7f26380070 0x3f3133bbe3e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.773312:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f7f26380070 0x3f3133bbe3e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.777808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f7f26380070 0x3f3133bbe3e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113510.895284:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.136184, 539, 1
[1:1:0712/113510.895502:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113511.307369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113511.310849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113511.311047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113511.633930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113511.635362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113511.635604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113513.199037:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113513.200531:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113513.204761:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113513.205296:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113513.205749:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/113513.780959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113513.782161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113513.782428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113513.821963:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113513.823119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113513.823373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113513.849324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113513.850463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113513.850695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113513.940847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113513.941993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113513.942228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113513.974063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113513.975216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113513.975493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.013594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.014749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.014978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.047864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.049046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.049274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.103133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.104307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.104550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.164260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.165424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.165670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.232213:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.233368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.233620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.263365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.264741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.265317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.299014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.300222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.300449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.393044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.394238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.394481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.424842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.426057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.426310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.456447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.457702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.457942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.511341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.512578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.512859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.552982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.554122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.554385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.588794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.589982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.590214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.632116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.633285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.633526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.692076:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.693287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.693523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.716225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.717117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.717340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.760687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.761873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.762099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.792652:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.793829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.794066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.824258:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.825445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.825699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.888466:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.889647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.889883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.942829:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.944022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.944249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113514.978301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113514.979655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113514.979961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.052006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.053200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.053442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.079444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.080554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.080822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.138193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.139380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.139642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.162560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.163761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.164057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.198819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.200096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.200361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.218484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.219639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.219902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.276724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.277933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.278161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.322096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.323241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, aw_(this)
[1:1:0712/113515.323475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.415013:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113515.415333:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.418651:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 589 0x7f7f26380070 0x3f3133aeeae0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.426131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , var dhtmlwindow = {
        //imagefiles:['img/min.gif', '//www1.pconline.com.cn/qknow/images/icon_
[1:1:0712/113515.426415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113515.445443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 589 0x7f7f26380070 0x3f3133aeeae0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.580066:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 589 0x7f7f26380070 0x3f3133aeeae0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113515.630158:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.214701, 431, 1
[1:1:0712/113515.630454:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113517.832380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113517.833595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113517.833837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113517.935655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113517.936835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width=120;this.height=120
[1:1:0712/113517.937090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113517.980374:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113517.980691:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113517.984751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7f7f26380070 0x3f3133a2d560 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113517.986722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , ;(function(){var Locate={running:false,cookieName:'pcLocate',callbackQueue:[],defaultData:{proCode:'
[1:1:0712/113517.986959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113517.994805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 668 0x7f7f26380070 0x3f3133a2d560 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113518.043818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pcauto.com.cn/topic-20068130.html", 0
[1:1:0712/113518.044305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 701
[1:1:0712/113518.044570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f7f26380070 0x3f3133fb6ae0 , 5:3_https://bbs.pcauto.com.cn/, 1, -5:3_https://bbs.pcauto.com.cn/, 668 0x7f7f26380070 0x3f3133a2d560 
[1:1:0712/113518.121225:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.140431, 789, 1
[1:1:0712/113518.121527:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113518.815189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113518.816394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113518.816641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113519.410571:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113519.411826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113519.412138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113519.981550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113519.982860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113519.983174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113520.347443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.348694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width = 120;this.height = 120
[1:1:0712/113520.348928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113520.537188:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113520.537527:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.538432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.539702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
    function goPost(id,callback){
        addCount(id);
        if(callback){
            callback(
[1:1:0712/113520.540001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113520.542377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.551592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.560663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.573597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.589946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.604786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.629414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113520.705366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f7f26380070 0x3f3133b6c660 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113521.284090:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.746422, 0, 0
[1:1:0712/113521.284364:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113521.286492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 701, 7f7f28cc58db
[1:1:0712/113521.300750:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"053eb2822860","ptid":"668 0x7f7f26380070 0x3f3133a2d560 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113521.301110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bbs.pcauto.com.cn/","ptid":"668 0x7f7f26380070 0x3f3133a2d560 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113521.301476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 781
[1:1:0712/113521.301702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f7f26380070 0x3f3133f72ae0 , 5:3_https://bbs.pcauto.com.cn/, 0, , 701 0x7f7f26380070 0x3f3133fb6ae0 
[1:1:0712/113521.302021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113521.302678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , GetRTime, (){
                                        var EndTime= new Date(timeover);//格式固定这么写�
[1:1:0712/113521.302888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.057136:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113522.057428:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.061122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 779 0x7f7f26380070 0x3f31343877e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.062785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , /**
 * Cookie plugin
 *
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 * Dual licensed under 
[1:1:0712/113522.063010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.071592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 779 0x7f7f26380070 0x3f31343877e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.098473:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/113522.102340:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f3134534020
[1:1:0712/113522.102879:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/113522.183027:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.125473, 193, 1
[1:1:0712/113522.183354:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113522.187132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 781, 7f7f28cc58db
[1:1:0712/113522.217987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7f7f26380070 0x3f3133fb6ae0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113522.218318:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7f7f26380070 0x3f3133fb6ae0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113522.218691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 808
[1:1:0712/113522.218961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f7f26380070 0x3f3133d33860 , 5:3_https://bbs.pcauto.com.cn/, 0, , 781 0x7f7f26380070 0x3f3133f72ae0 
[1:1:0712/113522.219293:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.220073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , GetRTime, (){
                                        var EndTime= new Date(timeover);//格式固定这么写�
[1:1:0712/113522.220349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.337477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 785 0x7f7f282a82e0 0x3f3133b2fa60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.338467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
ivyData1({})

[1:1:0712/113522.338717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.339675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.529920:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.531078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , onload, this.width=120;this.height=120
[1:1:0712/113522.531308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.692917:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113522.693256:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.695570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 804 0x7f7f26380070 0x3f3133a42de0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113522.699450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
                        var smiliesUrlRoot='//www1.pcauto.com.cn/autobbs/2013/images/emot/';
      
[1:1:0712/113522.699867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113522.703867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 804 0x7f7f26380070 0x3f3133a42de0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113523.409262:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.715786, 2, 0
[1:1:0712/113523.409546:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113523.629792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 808, 7f7f28cc58db
[1:1:0712/113523.681889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"781 0x7f7f26380070 0x3f3133f72ae0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113523.682360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"781 0x7f7f26380070 0x3f3133f72ae0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113523.682832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 993
[1:1:0712/113523.683170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f7f26380070 0x3f3133ba8ce0 , 5:3_https://bbs.pcauto.com.cn/, 0, , 808 0x7f7f26380070 0x3f3133d33860 
[1:1:0712/113523.683538:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113523.684335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , GetRTime, (){
                                        var EndTime= new Date(timeover);//格式固定这么写�
[1:1:0712/113523.684587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113523.855278:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://bbs.pcauto.com.cn/undefined"
[1413:1413:0712/113529.843120:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1413:1413:0712/113529.874337:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1413:1413:0712/113529.880351:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1413:1413:0712/113529.896003:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bbs.pcauto.com.cn/, https://bbs.pcauto.com.cn/, 4
[1413:1413:0712/113529.896133:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://bbs.pcauto.com.cn/, https://bbs.pcauto.com.cn
[3:3:0712/113530.093223:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1413:1413:0712/113530.241190:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/113530.649455:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113530.649762:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.652282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.656700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , 
	/*20180704 zhangqifeng 添加提示文案和禁止粘贴标识 S*/
	var notPaste = 0;//0是不可�
[1:1:0712/113530.656955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113530.715844:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 053eb28d4168, 5:3_https://bbs.pcauto.com.cn/, 5:4_https://bbs.pcauto.com.cn/, about:blank
[1:1:0712/113530.716238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/, 053eb28d4168, 053eb2822860, open, 
[1:1:0712/113530.716572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "bbs.pcauto.com.cn", 4, 2, https://bbs.pcauto.com.cn, bbs.pcauto.com.cn, 3
[1:1:0712/113530.719642:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.writeEditorContents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.732747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/, 053eb2822860, 053eb28d4168, createElement, 
[1:1:0712/113530.733081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 3, , , 0
[1:1:0712/113530.734385:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.writeEditorContents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.735026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/, 053eb28d4168, 053eb2822860, getElementById, 
[1:1:0712/113530.735384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 4, 4, https://bbs.pcauto.com.cn, bbs.pcauto.com.cn, 3
[1:1:0712/113530.736707:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.writeEditorContents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.743618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.748066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/, 053eb2822860, 053eb28d4168, ubb.editor.setEditorStyle, () {
    if(wysiwyg) {
        textobj.style.display = 'none';
        if (typeof postFlag !== "u
[1:1:0712/113530.748381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 5, , , 0
[1:1:0712/113530.749657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.writeEditorContents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.754079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/, 053eb28d4168, 053eb2822860, addEventListener, 
[1:1:0712/113530.754440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 4, 6, https://bbs.pcauto.com.cn, bbs.pcauto.com.cn, 3
[1:1:0712/113530.755701:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.setEditorEvents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.756700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/, 053eb2822860, 053eb28d4168, e, (a,b){return new e.fn.init(a,b,h)}
[1:1:0712/113530.757032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 7, , , 0
[1:1:0712/113530.758274:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.ubb.editor.setEditorEvents (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	Object.ubb.editor.newEditor (https://js.3conline.com/bbs/pcauto/2015/js/ubb_new_v3.2.js:1:1)
	https://bbs.pcauto.com.cn/topic-20068130.html:3129:32

[1:1:0712/113530.796500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.831311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.836735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.841891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f26380070 0x3f31348d0b60 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113530.879319:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100000, 0x2b0906b429c8, 0x3f313351c9b0
[1:1:0712/113530.879832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pcauto.com.cn/topic-20068130.html", 100000
[1:1:0712/113530.880282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bbs.pcauto.com.cn/, 1249
[1:1:0712/113530.880525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7f7f26380070 0x3f3134c7f9e0 , 5:3_https://bbs.pcauto.com.cn/, 7, -5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/-5:4_https://bbs.pcauto.com.cn/-5:3_https://bbs.pcauto.com.cn/, 971 0x7f7f26380070 0x3f31348d0b60 
[1:1:0712/113530.890540:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.240607, 57, 1
[1:1:0712/113530.890817:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/113532.053054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 993, 7f7f28cc58db
[1:1:0712/113532.119434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"808 0x7f7f26380070 0x3f3133d33860 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113532.120254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"808 0x7f7f26380070 0x3f3133d33860 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113532.120640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 1278
[1:1:0712/113532.120876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1278 0x7f7f26380070 0x3f3134623860 , 5:3_https://bbs.pcauto.com.cn/, 0, , 993 0x7f7f26380070 0x3f3133ba8ce0 
[1:1:0712/113532.121274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113532.121758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 1279
[1:1:0712/113532.121990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1279 0x7f7f26380070 0x3f3134c5d660 , 5:3_https://bbs.pcauto.com.cn/, 0, , 993 0x7f7f26380070 0x3f3133ba8ce0 
[1:1:0712/113532.122675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , GetRTime, (){
                                        var EndTime= new Date(timeover);//格式固定这么写�
[1:1:0712/113532.122896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113542.652585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/113542.652907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113545.611357:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/113545.611641:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.615023:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.616404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , , document.write("<style> .topText{height:120px; overflow:hidden;position: relative;} .topText .ADicon
[1:1:0712/113545.616645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113545.657941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.667987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.691446:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.716594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.721692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1251 0x7f7f26380070 0x3f3133fac7e0 , "https://bbs.pcauto.com.cn/topic-20068130.html"
[1413:1413:0712/113545.742624:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://jwz.3conline.com/auto_default_show?id=auto.fubiao.&media=js&channel=inline&trace=1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.pcauto.com.cn/global/footer/index.html (1)
[1413:1413:0712/113545.761711:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://jwz.3conline.com/auto_default_show?id=auto.fubiao.&media=js&channel=inline&trace=1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://www.pcauto.com.cn/global/footer/index.html (1)
[1:1:0712/113545.889199:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.890075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , d, (a,e){var j,k,l,m,n;try{if(d&&(e||h.readyState===4)){d=b,i&&(h.onreadystatechange=f.noop,cf&&delete 
[1:1:0712/113545.890339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1:1:0712/113545.891797:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.896424:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113545.897263:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xbfd7320d230
[1:1:0712/113547.559233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 1279, 7f7f28cc58db
[1:1:0712/113547.643200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"993 0x7f7f26380070 0x3f3133ba8ce0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113547.643583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"993 0x7f7f26380070 0x3f3133ba8ce0 ","rf":"5:3_https://bbs.pcauto.com.cn/"}
[1:1:0712/113547.643971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bbs.pcauto.com.cn/, 1767
[1:1:0712/113547.644206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1767 0x7f7f26380070 0x3f3134e8f5e0 , 5:3_https://bbs.pcauto.com.cn/, 0, , 1279 0x7f7f26380070 0x3f3134c5d660 
[1:1:0712/113547.644628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pcauto.com.cn/topic-20068130.html"
[1:1:0712/113547.645297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bbs.pcauto.com.cn/, 053eb2822860, , GetRTime, (){
                                        var EndTime= new Date(timeover);//格式固定这么写�
[1:1:0712/113547.645541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pcauto.com.cn/topic-20068130.html", "bbs.pcauto.com.cn", 3, 1, , , 0
[1413:1413:0712/113552.090633:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
