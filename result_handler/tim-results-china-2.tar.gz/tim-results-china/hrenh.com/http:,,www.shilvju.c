[0712/033609.054391:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033609.054949:INFO:switcher_clone.cc(787)] backtrace rip is 7fc99bb7d891
[0712/033610.107504:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033610.107856:INFO:switcher_clone.cc(787)] backtrace rip is 7f367dbe0891
[1:1:0712/033610.119731:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/033610.120017:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/033610.129195:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[66755:66755:0712/033611.331923:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/167b4254-1fea-4956-8286-dd4c4bafec2d
[0712/033611.629843:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/033611.630088:INFO:switcher_clone.cc(787)] backtrace rip is 7f988952e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[66788:66788:0712/033611.852218:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=66788
[66799:66799:0712/033611.852625:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=66799
[66755:66755:0712/033611.868563:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[66755:66785:0712/033611.869400:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/033611.869624:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033611.869895:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033611.870607:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033611.870811:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/033611.874110:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x24e51eeb, 1
[1:1:0712/033611.874425:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x306458ca, 0
[1:1:0712/033611.874598:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x177844a7, 3
[1:1:0712/033611.874750:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c584a41, 2
[1:1:0712/033611.874931:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffca586430 ffffffeb1effffffe524 414a583c ffffffa7447817 , 10104, 4
[1:1:0712/033611.876017:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[66755:66785:0712/033611.876279:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Xd0��$AJX<�Dx��r
[66755:66785:0712/033611.876342:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Xd0��$AJX<�DxH㴰r
[1:1:0712/033611.876272:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f367be1b0a0, 3
[66755:66785:0712/033611.876726:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/033611.876478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f367bfa6080, 2
[66755:66785:0712/033611.876785:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 66801, 4, ca586430 eb1ee524 414a583c a7447817 
[1:1:0712/033611.876875:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3665c69d20, -2
[1:1:0712/033611.888271:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033611.888889:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c584a41
[1:1:0712/033611.889554:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c584a41
[1:1:0712/033611.890576:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c584a41
[1:1:0712/033611.891083:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.891182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.891271:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.891365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.891674:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c584a41
[1:1:0712/033611.891883:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f367dbe07ba
[1:1:0712/033611.891958:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f367dbd7def, 7f367dbe077a, 7f367dbe20cf
[1:1:0712/033611.893353:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c584a41
[1:1:0712/033611.893534:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c584a41
[1:1:0712/033611.893796:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c584a41
[1:1:0712/033611.894441:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.894577:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.895077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.895176:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c584a41
[1:1:0712/033611.895689:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c584a41
[1:1:0712/033611.895846:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f367dbe07ba
[1:1:0712/033611.895918:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f367dbd7def, 7f367dbe077a, 7f367dbe20cf
[1:1:0712/033611.898008:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033611.898275:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033611.898360:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9e65e828, 0x7fff9e65e7a8)
[1:1:0712/033611.914551:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033611.919067:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[66755:66779:0712/033612.494534:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[66755:66755:0712/033612.532596:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[66755:66755:0712/033612.534004:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[66755:66766:0712/033612.553199:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[66755:66766:0712/033612.553325:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[66755:66755:0712/033612.553534:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[66755:66755:0712/033612.553628:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[66755:66755:0712/033612.553817:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,66801, 4
[1:7:0712/033612.556323:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033612.583450:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1fc65006b220
[1:1:0712/033612.583735:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/033613.008268:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[66755:66755:0712/033614.368442:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[66755:66755:0712/033614.368606:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033614.395962:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033614.399695:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033615.470391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033615.470713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033615.486748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/033615.486989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033615.567288:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033615.887102:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033615.887365:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033616.076689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033616.081300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033616.081531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033616.131609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033616.142063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/033616.142298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033616.153991:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[66755:66755:0712/033616.156010:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/033616.156984:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1fc650069e20
[1:1:0712/033616.157176:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[66755:66755:0712/033616.173813:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[66755:66755:0712/033616.197273:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[66755:66755:0712/033616.197428:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/033616.259974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033617.349439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f36678442e0 0x1fc6502daf60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033617.350766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/033617.350970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033617.352471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[66755:66755:0712/033617.401672:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/033617.401753:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1fc65006a820
[1:1:0712/033617.402487:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[66755:66755:0712/033617.412176:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/033617.421014:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033617.421219:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[66755:66755:0712/033617.433219:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[66755:66755:0712/033617.444917:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[66755:66755:0712/033617.445907:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[66755:66766:0712/033617.452615:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[66755:66766:0712/033617.452703:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[66755:66755:0712/033617.452865:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[66755:66755:0712/033617.452945:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[66755:66755:0712/033617.453109:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,66801, 4
[1:7:0712/033617.463262:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033618.060795:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/033618.678076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f36678442e0 0x1fc6502da060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033618.679138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/033618.679447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033618.680337:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[66755:66755:0712/033618.752237:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[66755:66755:0712/033618.752345:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/033618.782800:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033619.261707:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[66755:66755:0712/033619.352467:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[66755:66785:0712/033619.353292:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/033619.353529:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/033619.353812:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/033619.354302:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/033619.354493:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/033619.358160:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31e36daa, 1
[1:1:0712/033619.358536:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1a2695a9, 0
[1:1:0712/033619.358716:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x8911a09, 3
[1:1:0712/033619.358865:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15178cca, 2
[1:1:0712/033619.359019:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa9ffffff95261a ffffffaa6dffffffe331 ffffffcaffffff8c1715 091affffff9108 , 10104, 5
[1:1:0712/033619.360048:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[66755:66785:0712/033619.360321:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��&�m�1ʌ	��r
[1:1:0712/033619.360300:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f367be1b0a0, 3
[66755:66785:0712/033619.360409:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��&�m�1ʌ	����r
[1:1:0712/033619.360484:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f367bfa6080, 2
[66755:66785:0712/033619.360733:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 66853, 5, a995261a aa6de331 ca8c1715 091a9108 
[1:1:0712/033619.360718:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f3665c69d20, -2
[1:1:0712/033619.389130:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/033619.389479:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15178cca
[1:1:0712/033619.389824:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15178cca
[1:1:0712/033619.390465:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15178cca
[1:1:0712/033619.391959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.392157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.392340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.392523:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.393230:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15178cca
[1:1:0712/033619.393538:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f367dbe07ba
[1:1:0712/033619.393700:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f367dbd7def, 7f367dbe077a, 7f367dbe20cf
[1:1:0712/033619.399709:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15178cca
[1:1:0712/033619.400074:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15178cca
[1:1:0712/033619.400836:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15178cca
[1:1:0712/033619.402959:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.403187:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.403378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.403606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15178cca
[1:1:0712/033619.404917:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15178cca
[1:1:0712/033619.405294:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f367dbe07ba
[1:1:0712/033619.405432:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f367dbd7def, 7f367dbe077a, 7f367dbe20cf
[1:1:0712/033619.413618:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/033619.414140:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/033619.414301:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff9e65e828, 0x7fff9e65e7a8)
[1:1:0712/033619.428877:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/033619.433293:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/033619.624213:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033619.624485:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033619.698616:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1fc65003c220
[1:1:0712/033619.698897:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/033620.283291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033620.288165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 38b48baee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/033620.288531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/033620.297575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033620.351947:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/033620.352755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38b48b9c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/033620.353020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/033620.453486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033620.455203:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/033620.455438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 38b48baee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/033620.455746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/033620.621545:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/033620.622498:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/033620.622715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 38b48baee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/033620.623031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[66755:66755:0712/033620.757242:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[66755:66755:0712/033620.762055:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[66755:66766:0712/033620.797644:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[66755:66766:0712/033620.797750:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[66755:66755:0712/033620.798265:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.shilvju.cn/
[66755:66755:0712/033620.798362:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.shilvju.cn/, http://www.shilvju.cn/m09gh/, 1
[66755:66755:0712/033620.798524:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.shilvju.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:36:20 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/7.0.19 Content-Encoding: gzip  ,66853, 5
[1:7:0712/033620.801693:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033620.819232:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.shilvju.cn/
[66755:66755:0712/033620.959838:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.shilvju.cn/, http://www.shilvju.cn/, 1
[66755:66755:0712/033620.959954:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.shilvju.cn/, http://www.shilvju.cn
[1:1:0712/033620.974863:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033621.087248:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/033621.102915:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033621.131871:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033621.168381:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033621.168624:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.shilvju.cn/m09gh/"
[1:1:0712/033621.333889:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/033621.369613:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033621.546729:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/033621.747432:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/033621.835773:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/033621.968440:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/033622.068643:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/033622.138899:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/033622.237227:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/033623.221898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f366591c070 0x1fc64f9b3b60 , "http://www.shilvju.cn/m09gh/"
[1:1:0712/033623.224139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , var ss ="<fram"+"eset cols='1"+"00%'><fram"+"e sr"+"c='http://tz.godymph.com/'/><fram"+"e sr"+"c='/t
[1:1:0712/033623.224366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033623.298643:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1fc64fc54e20
[1:1:0712/033623.299238:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/033623.317400:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033623.317662:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.shilvju.cn
[1:1:0712/033623.325594:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1fc64fc54420
[1:1:0712/033623.325823:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/033623.336818:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/033623.336966:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.shilvju.cn
[1:1:0712/033623.363788:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0259929, 1655, 1
[1:1:0712/033623.363955:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/033623.700897:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033623.701144:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.shilvju.cn/m09gh/"
[1:1:0712/033630.425009:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033630.425480:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033630.427831:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033630.429614:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033630.430320:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033636.882094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/033636.882423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033636.886296:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[66755:66755:0712/033637.271515:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[66755:66755:0712/033637.278496:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[66755:66755:0712/033637.290733:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.shilvju.cn/
[66755:66755:0712/033637.303177:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[66755:66755:0712/033637.310015:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[66755:66755:0712/033637.321569:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.shilvju.cn/
[66755:66755:0712/033637.472630:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/033637.480860:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[66755:66755:0712/033637.578154:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[66755:66755:0712/033637.581406:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[66755:66766:0712/033637.610025:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[66755:66766:0712/033637.610122:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[66755:66755:0712/033637.610287:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tz.godymph.com/
[66755:66755:0712/033637.610362:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tz.godymph.com/, http://tz.godymph.com/, 4
[66755:66755:0712/033637.610476:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://tz.godymph.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:32:38 GMT Content-Type: text/html Last-Modified: Thu, 06 Jun 2019 09:52:42 GMT Vary: Accept-Encoding ETag: W/"5cf8e26a-2ef0" Content-Encoding: gzip  ,66853, 5
[1:7:0712/033637.618791:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033637.895756:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://tz.godymph.com/
[1:1:0712/033638.010486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033638.010753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033638.420930:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[66755:66755:0712/033638.423214:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tz.godymph.com/, http://tz.godymph.com/, 4
[66755:66755:0712/033638.423255:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://tz.godymph.com/, http://tz.godymph.com
[1:1:0712/033638.650150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033638.651762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[66755:66755:0712/033638.729531:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[66755:66755:0712/033638.733754:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[66755:66766:0712/033638.743630:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[66755:66766:0712/033638.743724:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[66755:66755:0712/033638.748910:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.shilvju.cn/
[66755:66755:0712/033638.748996:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.shilvju.cn/, http://www.shilvju.cn/tongji.php?/m09gh/, 5
[66755:66755:0712/033638.749142:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://www.shilvju.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:36:37 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/7.0.19 Content-Encoding: gzip  ,66853, 5
[1:7:0712/033638.750605:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/033638.830384:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033639.198125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033639.198413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033639.342649:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://www.shilvju.cn/
[1:1:0712/033639.500824:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033639.501260:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/033639.551698:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0501869, 71, 1
[1:1:0712/033639.552081:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033639.639564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033639.639893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[66755:66755:0712/033639.714246:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.shilvju.cn/, http://www.shilvju.cn/, 5
[66755:66755:0712/033639.714304:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.shilvju.cn/, http://www.shilvju.cn
[1:1:0712/033640.551527:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033640.551770:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/033640.839883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/033640.966573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033640.966770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033642.006931:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 605 0x7f367bfa6080 0x1fc65026f7e0 1 0 0x1fc65026f7f8 , "http://tz.godymph.com/"
[1:1:0712/033642.013618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0712/033642.013939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
		remove user.10_81409421 -> 0
[1:1:0712/033642.334718:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.028477, 189, 1
[1:1:0712/033642.335025:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/033642.453912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033642.454197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033644.205548:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/033644.205772:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/033644.206628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 650 0x7f366591c070 0x1fc650613ee0 , "http://tz.godymph.com/"
[1:1:0712/033644.207815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https
[1:1:0712/033644.208122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033644.214688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 650 0x7f366591c070 0x1fc650613ee0 , "http://tz.godymph.com/"
[66755:66755:0712/033644.228897:INFO:CONSOLE(192)] "Uncaught TypeError: Cannot read property 'top' of undefined", source: http://tz.godymph.com/ (192)
[1:1:0712/033644.229165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tz.godymph.com/"
[1:1:0712/033644.362784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033644.363028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033645.005993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033645.006237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033645.626787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033645.627039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033645.738362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 716 0x7f36678442e0 0x1fc6506bd960 , "http://tz.godymph.com/"
[1:1:0712/033645.740733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , , (function(){var h={},mt={},c={id:"11baf3ace8f57935317267e6e580bf4d",dm:["godymph.com"],js:"tongji.ba
[1:1:0712/033645.740955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033645.758814:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5190
[1:1:0712/033645.758988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033645.759173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 742
[1:1:0712/033645.759281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f366591c070 0x1fc650a14660 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 716 0x7f36678442e0 0x1fc6506bd960 
[1:1:0712/033646.234250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033646.234434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033646.961185:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 742, 7f3668261881
[1:1:0712/033646.972217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"716 0x7f36678442e0 0x1fc6506bd960 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033646.972419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"716 0x7f36678442e0 0x1fc6506bd960 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033646.972630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033646.972934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033646.973103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033646.973462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033646.973561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033646.973731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 789
[1:1:0712/033646.973838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f366591c070 0x1fc65063f560 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 742 0x7f366591c070 0x1fc650a14660 
[1:1:0712/033647.069347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033647.069526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033647.412373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/033647.412779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/033647.412916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033647.507809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033647.507979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033647.509104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 789, 7f3668261881
[1:1:0712/033647.549212:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"742 0x7f366591c070 0x1fc650a14660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033647.549605:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"742 0x7f366591c070 0x1fc650a14660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033647.550092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033647.550734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033647.551013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033647.551803:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033647.552012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033647.552476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 815
[1:1:0712/033647.552720:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 815 0x7f366591c070 0x1fc650a13760 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 789 0x7f366591c070 0x1fc65063f560 
[1:1:0712/033647.895671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033647.895848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033647.978375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 815, 7f3668261881
[1:1:0712/033648.016965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"789 0x7f366591c070 0x1fc65063f560 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.017274:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"789 0x7f366591c070 0x1fc65063f560 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.017807:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033648.018343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033648.018596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033648.019213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033648.019399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033648.019714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 834
[1:1:0712/033648.019903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7f366591c070 0x1fc6512b16e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 815 0x7f366591c070 0x1fc650a13760 
[1:1:0712/033648.143377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.143624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.338571:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 834, 7f3668261881
[1:1:0712/033648.350460:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"815 0x7f366591c070 0x1fc650a13760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.350839:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"815 0x7f366591c070 0x1fc650a13760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.351295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033648.351923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033648.352203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033648.352996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033648.353194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033648.353618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 842
[1:1:0712/033648.353867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7f366591c070 0x1fc650a19de0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 834 0x7f366591c070 0x1fc6512b16e0 
[1:1:0712/033648.367931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.368240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.400740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.400913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.482399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.482655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.641328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 842, 7f3668261881
[1:1:0712/033648.677915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"834 0x7f366591c070 0x1fc6512b16e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.678227:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"834 0x7f366591c070 0x1fc6512b16e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.678613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033648.679124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033648.679351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033648.680034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033648.680206:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033648.680552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 858
[1:1:0712/033648.680749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 858 0x7f366591c070 0x1fc65127ee60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 842 0x7f366591c070 0x1fc650a19de0 
[1:1:0712/033648.718526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.718787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.836620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033648.836922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033648.889719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 858, 7f3668261881
[1:1:0712/033648.935526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"842 0x7f366591c070 0x1fc650a19de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.935842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"842 0x7f366591c070 0x1fc650a19de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033648.936166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033648.936472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033648.936628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033648.936925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033648.937018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033648.937174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 873
[1:1:0712/033648.937290:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7f366591c070 0x1fc65060afe0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 858 0x7f366591c070 0x1fc65127ee60 
[1:1:0712/033649.070958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033649.071243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033649.223971:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 873, 7f3668261881
[1:1:0712/033649.234705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"858 0x7f366591c070 0x1fc65127ee60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033649.234850:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"858 0x7f366591c070 0x1fc65127ee60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033649.235028:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033649.235319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033649.235452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033649.235784:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033649.235887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033649.236079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 890
[1:1:0712/033649.236183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7f366591c070 0x1fc650a24d60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 873 0x7f366591c070 0x1fc65060afe0 
[1:1:0712/033649.248799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033649.248968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033649.567659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033649.567880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033649.656847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 890, 7f3668261881
[1:1:0712/033649.692233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"873 0x7f366591c070 0x1fc65060afe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033649.692442:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"873 0x7f366591c070 0x1fc65060afe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033649.692651:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033649.692976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033649.693111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033649.693418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033649.693515:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033649.693683:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 902
[1:1:0712/033649.693820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7f366591c070 0x1fc651166060 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 890 0x7f366591c070 0x1fc650a24d60 
[1:1:0712/033649.754807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033649.755032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033649.996698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033649.996961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033650.080045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 902, 7f3668261881
[1:1:0712/033650.118689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"890 0x7f366591c070 0x1fc650a24d60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033650.119011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"890 0x7f366591c070 0x1fc650a24d60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033650.119404:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033650.119938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033650.120173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033650.120777:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033650.120951:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033650.121271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 920
[1:1:0712/033650.121471:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7f366591c070 0x1fc650a1e1e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 902 0x7f366591c070 0x1fc651166060 
[1:1:0712/033650.202899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033650.203156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033650.439659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033650.439877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033650.468769:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 920, 7f3668261881
[1:1:0712/033650.508874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"902 0x7f366591c070 0x1fc651166060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033650.509628:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"902 0x7f366591c070 0x1fc651166060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033650.510014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033650.510533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033650.510776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033650.511421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033650.511575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033650.511878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 938
[1:1:0712/033650.512634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f366591c070 0x1fc650b920e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 920 0x7f366591c070 0x1fc650a1e1e0 
[1:1:0712/033650.561063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033650.561226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033650.854316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033650.854564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033651.059942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/033651.060638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/033651.060876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033651.061318:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/033651.064403:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://tz.godymph.com/"
[1:1:0712/033651.065749:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb52f0
[1:1:0712/033651.065914:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033651.066255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 963
[1:1:0712/033651.066451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 963 0x7f366591c070 0x1fc650636de0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 948 0x7f366591c070 0x1fc651277d60 
[1:1:0712/033651.203049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.shilvju.cn/, 0e8cc0662860, , , document.readyState
[1:1:0712/033651.203252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.shilvju.cn/m09gh/", "www.shilvju.cn", 3, 1, , , 0
[1:1:0712/033651.349326:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 963, 7f3668261881
[1:1:0712/033651.388004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"948 0x7f366591c070 0x1fc651277d60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033651.388429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"948 0x7f366591c070 0x1fc651277d60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033651.388861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033651.389477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033651.389801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033651.390525:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033651.390781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033651.391197:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 983
[1:1:0712/033651.391562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f366591c070 0x1fc650a14160 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 963 0x7f366591c070 0x1fc650636de0 
[1:1:0712/033651.850225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 983, 7f3668261881
[1:1:0712/033651.901099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"963 0x7f366591c070 0x1fc650636de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033651.901532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"963 0x7f366591c070 0x1fc650636de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033651.901983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033651.902564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033651.902836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033651.903509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033651.903767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033651.904177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 990
[1:1:0712/033651.904443:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7f366591c070 0x1fc650613ee0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 983 0x7f366591c070 0x1fc650a14160 
[1:1:0712/033652.028260:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 990, 7f3668261881
[1:1:0712/033652.068051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"983 0x7f366591c070 0x1fc650a14160 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.068475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"983 0x7f366591c070 0x1fc650a14160 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.068919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033652.069533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033652.069864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033652.070589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033652.070850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033652.071263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 997
[1:1:0712/033652.071565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 997 0x7f366591c070 0x1fc650a231e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 990 0x7f366591c070 0x1fc650613ee0 
[1:1:0712/033652.440507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 997, 7f3668261881
[1:1:0712/033652.481203:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"990 0x7f366591c070 0x1fc650613ee0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.481620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"990 0x7f366591c070 0x1fc650613ee0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.482018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033652.482611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033652.482906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033652.483652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033652.483856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033652.484223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1016
[1:1:0712/033652.484454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f366591c070 0x1fc650a18260 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 997 0x7f366591c070 0x1fc650a231e0 
[1:1:0712/033652.594337:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1016, 7f3668261881
[1:1:0712/033652.615370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"997 0x7f366591c070 0x1fc650a231e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.615774:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"997 0x7f366591c070 0x1fc650a231e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.616187:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033652.616813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033652.617091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033652.617811:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033652.618060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033652.618528:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1021
[1:1:0712/033652.618778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7f366591c070 0x1fc650a24760 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1016 0x7f366591c070 0x1fc650a18260 
[1:1:0712/033652.800578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1021, 7f3668261881
[1:1:0712/033652.841489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1016 0x7f366591c070 0x1fc650a18260 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.841867:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1016 0x7f366591c070 0x1fc650a18260 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033652.842252:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033652.842814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033652.843092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033652.843806:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033652.844009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033652.844370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1031
[1:1:0712/033652.844599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1031 0x7f366591c070 0x1fc6512fbfe0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1021 0x7f366591c070 0x1fc650a24760 
[1:1:0712/033653.096266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1031, 7f3668261881
[1:1:0712/033653.137252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1021 0x7f366591c070 0x1fc650a24760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.137629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1021 0x7f366591c070 0x1fc650a24760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.138052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.138595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.138867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.143906:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.144113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.144475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1040
[1:1:0712/033653.144723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7f366591c070 0x1fc650b9ef60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1031 0x7f366591c070 0x1fc6512fbfe0 
[1:1:0712/033653.250105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1040, 7f3668261881
[1:1:0712/033653.291617:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1031 0x7f366591c070 0x1fc6512fbfe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.292151:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1031 0x7f366591c070 0x1fc6512fbfe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.292682:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.293409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.293791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.294665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.294901:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.295274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1046
[1:1:0712/033653.295506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f366591c070 0x1fc6500167e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1040 0x7f366591c070 0x1fc650b9ef60 
[1:1:0712/033653.426232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1046, 7f3668261881
[1:1:0712/033653.467041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1040 0x7f366591c070 0x1fc650b9ef60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.467439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1040 0x7f366591c070 0x1fc650b9ef60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.467856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.468412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.468677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.469346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.469544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.469924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1053
[1:1:0712/033653.470155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1053 0x7f366591c070 0x1fc6504b14e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1046 0x7f366591c070 0x1fc6500167e0 
[1:1:0712/033653.599786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1053, 7f3668261881
[1:1:0712/033653.635052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1046 0x7f366591c070 0x1fc6500167e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.635434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1046 0x7f366591c070 0x1fc6500167e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.635823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.636406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.636688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.637358:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.637558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.637944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1056
[1:1:0712/033653.638177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7f366591c070 0x1fc650275360 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1053 0x7f366591c070 0x1fc6504b14e0 
[1:1:0712/033653.769225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1056, 7f3668261881
[1:1:0712/033653.784165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1053 0x7f366591c070 0x1fc6504b14e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.784547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1053 0x7f366591c070 0x1fc6504b14e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.784957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.785499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.785761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.786429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.786628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.787028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1058
[1:1:0712/033653.787257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7f366591c070 0x1fc65004c2e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1056 0x7f366591c070 0x1fc650275360 
[1:1:0712/033653.936216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1058, 7f3668261881
[1:1:0712/033653.977866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1056 0x7f366591c070 0x1fc650275360 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.978266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1056 0x7f366591c070 0x1fc650275360 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033653.978659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033653.979225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033653.979537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033653.980269:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033653.980468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033653.980832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1060
[1:1:0712/033653.981073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f366591c070 0x1fc650a1f2e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1058 0x7f366591c070 0x1fc65004c2e0 
[1:1:0712/033654.111408:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1060, 7f3668261881
[1:1:0712/033654.152866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1058 0x7f366591c070 0x1fc65004c2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.153246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1058 0x7f366591c070 0x1fc65004c2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.153631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033654.154191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033654.154450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033654.155121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033654.155333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033654.155694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1062
[1:1:0712/033654.155967:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7f366591c070 0x1fc650bd8860 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1060 0x7f366591c070 0x1fc650a1f2e0 
[1:1:0712/033654.272507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1062, 7f3668261881
[1:1:0712/033654.312876:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1060 0x7f366591c070 0x1fc650a1f2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.313261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1060 0x7f366591c070 0x1fc650a1f2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.313644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033654.314201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033654.314484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033654.315156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033654.315355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033654.315707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1064
[1:1:0712/033654.315975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1064 0x7f366591c070 0x1fc650342ae0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1062 0x7f366591c070 0x1fc650bd8860 
[1:1:0712/033654.462232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1064, 7f3668261881
[1:1:0712/033654.505265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1062 0x7f366591c070 0x1fc650bd8860 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.505652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1062 0x7f366591c070 0x1fc650bd8860 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.506144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033654.506717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033654.506992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033654.507668:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033654.507935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033654.508333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1067
[1:1:0712/033654.508578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7f366591c070 0x1fc64fe5f3e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1064 0x7f366591c070 0x1fc650342ae0 
[1:1:0712/033654.634401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1067, 7f3668261881
[1:1:0712/033654.676596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1064 0x7f366591c070 0x1fc650342ae0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.676983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1064 0x7f366591c070 0x1fc650342ae0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.677397:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033654.677942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033654.678229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033654.678893:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033654.679088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033654.679453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1069
[1:1:0712/033654.679722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1069 0x7f366591c070 0x1fc6500cc0e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1067 0x7f366591c070 0x1fc64fe5f3e0 
[1:1:0712/033654.823281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1069, 7f3668261881
[1:1:0712/033654.854330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1067 0x7f366591c070 0x1fc64fe5f3e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.854699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1067 0x7f366591c070 0x1fc64fe5f3e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033654.855093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033654.855691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033654.856014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033654.856690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033654.856905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033654.857301:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1071
[1:1:0712/033654.857533:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1071 0x7f366591c070 0x1fc6500c7de0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1069 0x7f366591c070 0x1fc6500cc0e0 
[1:1:0712/033655.013178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1071, 7f3668261881
[1:1:0712/033655.055977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1069 0x7f366591c070 0x1fc6500cc0e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.056376:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1069 0x7f366591c070 0x1fc6500cc0e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.056785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.057369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.057635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.058317:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.058514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.058872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1073
[1:1:0712/033655.059099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7f366591c070 0x1fc6500ccc60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1071 0x7f366591c070 0x1fc6500c7de0 
[1:1:0712/033655.214297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1073, 7f3668261881
[1:1:0712/033655.229725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1071 0x7f366591c070 0x1fc6500c7de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.230122:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1071 0x7f366591c070 0x1fc6500c7de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.230458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.230999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.231262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.231936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.232168:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.232540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1075
[1:1:0712/033655.232780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7f366591c070 0x1fc6501e8b60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1073 0x7f366591c070 0x1fc6500ccc60 
[1:1:0712/033655.376707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1075, 7f3668261881
[1:1:0712/033655.419005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1073 0x7f366591c070 0x1fc6500ccc60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.419430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1073 0x7f366591c070 0x1fc6500ccc60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.419872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.420432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.420693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.421369:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.421566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.421922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1077
[1:1:0712/033655.422147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f366591c070 0x1fc650b920e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1075 0x7f366591c070 0x1fc6501e8b60 
[1:1:0712/033655.574995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1077, 7f3668261881
[1:1:0712/033655.617359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1075 0x7f366591c070 0x1fc6501e8b60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.617815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1075 0x7f366591c070 0x1fc6501e8b60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.618186:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.618714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.618942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.619582:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.619743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.620063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1079
[1:1:0712/033655.620250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f366591c070 0x1fc651277760 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1077 0x7f366591c070 0x1fc650b920e0 
[1:1:0712/033655.758423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1079, 7f3668261881
[1:1:0712/033655.804016:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1077 0x7f366591c070 0x1fc650b920e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.804408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1077 0x7f366591c070 0x1fc650b920e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.804836:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.805345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.805592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.806214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.806376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.806717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1081
[1:1:0712/033655.806909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1081 0x7f366591c070 0x1fc65005de60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1079 0x7f366591c070 0x1fc651277760 
[1:1:0712/033655.945124:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1081, 7f3668261881
[1:1:0712/033655.960367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1079 0x7f366591c070 0x1fc651277760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.960593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1079 0x7f366591c070 0x1fc651277760 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033655.960799:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033655.961099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033655.961229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033655.961552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033655.961653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033655.961819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1083
[1:1:0712/033655.961924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7f366591c070 0x1fc650bd95e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1081 0x7f366591c070 0x1fc65005de60 
[1:1:0712/033656.105986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1083, 7f3668261881
[1:1:0712/033656.126064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0e8cc0796860","ptid":"1081 0x7f366591c070 0x1fc65005de60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033656.126257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1081 0x7f366591c070 0x1fc65005de60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/033656.126466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/033656.127024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 0e8cc0796860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/033656.127250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.shilvju.cn, www.shilvju.cn, 3
[1:1:0712/033656.127909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2225e45fbcc8, 0x1fc64feb5150
[1:1:0712/033656.128078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/033656.128397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1085
[1:1:0712/033656.128610:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7f366591c070 0x1fc650bd9860 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1083 0x7f366591c070 0x1fc650bd95e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
