[0712/034443.331586:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034443.331941:INFO:switcher_clone.cc(787)] backtrace rip is 7f683adb4891
[0712/034444.419339:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034444.419737:INFO:switcher_clone.cc(787)] backtrace rip is 7fc2aeb45891
[1:1:0712/034444.431341:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/034444.431625:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/034444.439972:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[68164:68164:0712/034445.795439:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/9d0e0297-bb9e-45f9-8b12-c79ea0601f45
[0712/034446.018081:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/034446.018424:INFO:switcher_clone.cc(787)] backtrace rip is 7f28cf8a5891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[68164:68164:0712/034446.190265:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[68164:68194:0712/034446.190996:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/034446.191244:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034446.191490:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034446.192147:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034446.192304:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/034446.195268:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b672f12, 1
[1:1:0712/034446.195648:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x39069403, 0
[1:1:0712/034446.195847:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1d8dcfb2, 3
[1:1:0712/034446.196096:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15de09b6, 2
[1:1:0712/034446.196407:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 03ffffff940639 122f673b ffffffb609ffffffde15 ffffffb2ffffffcfffffff8d1d , 10104, 4
[1:1:0712/034446.197368:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68164:68194:0712/034446.197564:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�9/g;�	��ύϒ  
[68164:68194:0712/034446.197627:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �9/g;�	��ύ�ϒ  
[68164:68194:0712/034446.197891:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[68164:68194:0712/034446.197958:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68209, 4, 03940639 122f673b b609de15 b2cf8d1d 
[1:1:0712/034446.198434:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2acd800a0, 3
[1:1:0712/034446.198642:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2acf0b080, 2
[1:1:0712/034446.198795:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc296bced20, -2
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/034446.232608:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034446.233479:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15de09b6
[1:1:0712/034446.234463:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15de09b6
[1:1:0712/034446.236135:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15de09b6
[1:1:0712/034446.237640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.237833:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.238059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.238246:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.238878:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15de09b6
[1:1:0712/034446.239241:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2aeb457ba
[1:1:0712/034446.239382:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2aeb3cdef, 7fc2aeb4577a, 7fc2aeb470cf
[1:1:0712/034446.245138:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15de09b6
[1:1:0712/034446.245586:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15de09b6
[1:1:0712/034446.246545:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15de09b6
[68196:68196:0712/034446.246677:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68196
[68210:68210:0712/034446.247172:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=68210
[1:1:0712/034446.249164:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.249415:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.249656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.249888:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15de09b6
[1:1:0712/034446.251486:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15de09b6
[1:1:0712/034446.251940:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2aeb457ba
[1:1:0712/034446.252174:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2aeb3cdef, 7fc2aeb4577a, 7fc2aeb470cf
[1:1:0712/034446.261917:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034446.262625:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034446.262805:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd11ad1d78, 0x7ffd11ad1cf8)
[1:1:0712/034446.283134:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034446.288840:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[68164:68164:0712/034446.699527:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68164:68164:0712/034446.700688:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68164:68175:0712/034446.720454:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[68164:68175:0712/034446.720554:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[68164:68164:0712/034446.720774:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[68164:68164:0712/034446.720865:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[68164:68164:0712/034446.721038:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,68209, 4
[1:7:0712/034446.722804:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68164:68188:0712/034446.783003:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/034446.805846:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2ca1793b4220
[1:1:0712/034446.806126:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/034447.220715:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[68164:68164:0712/034448.903706:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[68164:68164:0712/034448.903855:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034448.949421:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034448.953161:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034450.442027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034450.442312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034450.458572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/034450.458771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034450.540076:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034450.880847:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034450.881060:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034451.323173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034451.331730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034451.331954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034451.385197:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034451.401933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/034451.402152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034451.414754:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[68164:68164:0712/034451.416702:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/034451.420022:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ca1793b2e20
[1:1:0712/034451.420193:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[68164:68164:0712/034451.433732:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[68164:68164:0712/034451.494725:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[68164:68164:0712/034451.494884:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/034451.550780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034452.288135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7fc2987a92e0 0x2ca17965e8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034452.289550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/034452.290108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034452.291788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68164:68164:0712/034452.364672:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/034452.366055:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ca1793b3820
[1:1:0712/034452.366299:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[68164:68164:0712/034452.373177:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/034452.385751:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034452.386088:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[68164:68164:0712/034452.389775:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[68164:68164:0712/034452.402051:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68164:68164:0712/034452.403282:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68164:68175:0712/034452.410679:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[68164:68175:0712/034452.410801:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[68164:68164:0712/034452.410932:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[68164:68164:0712/034452.411016:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[68164:68164:0712/034452.411159:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,68209, 4
[1:7:0712/034452.419282:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034452.873875:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/034453.246522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fc2987a92e0 0x2ca17974f7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034453.247537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/034453.247826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034453.248619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[68164:68164:0712/034453.364570:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[68164:68164:0712/034453.364725:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/034453.398607:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68164:68164:0712/034453.545147:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[68164:68194:0712/034453.545564:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/034453.545751:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/034453.545941:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/034453.546343:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/034453.546481:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/034453.549621:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b0e2bd3, 1
[1:1:0712/034453.549982:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x306d6d5c, 0
[1:1:0712/034453.550138:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2abc735a, 3
[1:1:0712/034453.550275:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x27ccbcf3, 2
[1:1:0712/034453.550417:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5c6d6d30 ffffffd32b0e1b fffffff3ffffffbcffffffcc27 5a73ffffffbc2a , 10104, 5
[1:1:0712/034453.551335:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[68164:68194:0712/034453.551600:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING\mm0�+��'Zs�*��  
[68164:68194:0712/034453.551670:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is \mm0�+��'Zs�*����  
[1:1:0712/034453.551594:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2acd800a0, 3
[1:1:0712/034453.551778:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2acf0b080, 2
[68164:68194:0712/034453.551904:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 68261, 5, 5c6d6d30 d32b0e1b f3bccc27 5a73bc2a 
[1:1:0712/034453.551951:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc296bced20, -2
[1:1:0712/034453.574325:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/034453.574691:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27ccbcf3
[1:1:0712/034453.575020:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27ccbcf3
[1:1:0712/034453.575639:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27ccbcf3
[1:1:0712/034453.577076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.577262:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.577440:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.577616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.578282:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27ccbcf3
[1:1:0712/034453.578565:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2aeb457ba
[1:1:0712/034453.578706:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2aeb3cdef, 7fc2aeb4577a, 7fc2aeb470cf
[1:1:0712/034453.584943:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27ccbcf3
[1:1:0712/034453.585401:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27ccbcf3
[1:1:0712/034453.586317:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27ccbcf3
[1:1:0712/034453.588834:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.589122:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.589370:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.589610:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27ccbcf3
[1:1:0712/034453.591170:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27ccbcf3
[1:1:0712/034453.591622:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2aeb457ba
[1:1:0712/034453.591800:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2aeb3cdef, 7fc2aeb4577a, 7fc2aeb470cf
[1:1:0712/034453.597367:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/034453.597782:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/034453.597901:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd11ad1d78, 0x7ffd11ad1cf8)
[1:1:0712/034453.609239:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/034453.613949:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/034453.709840:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034453.799148:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ca179374220
[1:1:0712/034453.799439:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/034454.466454:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034454.466729:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034454.857340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034454.861893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/034454.862179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034454.870100:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034454.911991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/034454.912755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21b5b9ee1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/034454.912976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/034455.011458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034455.013129:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/034455.016118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/034455.016444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034455.136467:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034455.137987:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/034455.138199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/034455.138486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[68164:68164:0712/034455.611975:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68164:68164:0712/034455.616985:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/034455.626655:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[68164:68175:0712/034455.648655:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[68164:68175:0712/034455.648757:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[68164:68164:0712/034455.649122:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.siranda.cn/
[68164:68164:0712/034455.649198:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.siranda.cn/, http://www.siranda.cn/5v38tqiz/, 1
[68164:68164:0712/034455.649326:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.siranda.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:44:55 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/7.0.19 Content-Encoding: gzip  ,68261, 5
[1:7:0712/034455.653084:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034455.688726:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.siranda.cn/
[1:1:0712/034455.819298:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[68164:68164:0712/034455.821831:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.siranda.cn/, http://www.siranda.cn/, 1
[68164:68164:0712/034455.821876:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.siranda.cn/, http://www.siranda.cn
[1:1:0712/034455.885433:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/034455.896788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034455.983148:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/034456.006392:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034456.063798:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034456.113610:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034456.113914:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.siranda.cn/5v38tqiz/"
[1:1:0712/034456.134461:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/034456.182102:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/034456.268464:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/034456.347019:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/034456.393949:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034456.402028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034456.402942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/034456.403209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034456.442316:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034456.443284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/034456.443551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034456.599572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034456.600529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/034456.600836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034456.892451:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/034456.932609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 159 0x7fc296881070 0x2ca1794e5160 , "http://www.siranda.cn/5v38tqiz/"
[1:1:0712/034456.934770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , var ss ="<fram"+"eset cols='1"+"00%'><fram"+"e sr"+"c='http://tz.godymph.com/'/><fram"+"e sr"+"c='/t
[1:1:0712/034456.934991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034457.151907:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/034457.152865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21b5ba00e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/034457.153155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/034457.445425:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ca1794efa20
[1:1:0712/034457.445580:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/034457.452713:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034457.452873:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.siranda.cn
[1:1:0712/034457.465419:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2ca1794f0420
[1:1:0712/034457.465648:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/034457.484149:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/034457.484356:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.siranda.cn
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/034457.812334:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034500.986226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034500.986406:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.siranda.cn/5v38tqiz/"
[1:1:0712/034500.988475:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00200701, 189, 1
[1:1:0712/034500.988585:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034503.406456:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034503.407481:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034503.407916:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034503.408270:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034503.408606:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034503.437636:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034503.437903:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.siranda.cn/5v38tqiz/"
[68164:68164:0712/034511.888367:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[68164:68164:0712/034511.895470:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[68164:68164:0712/034511.906716:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.siranda.cn/
[68164:68164:0712/034511.916137:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[68164:68164:0712/034511.918204:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[68164:68164:0712/034511.921519:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.siranda.cn/
[68164:68164:0712/034512.311335:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/034512.392098:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[68164:68164:0712/034512.464376:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68164:68164:0712/034512.468254:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[68164:68175:0712/034512.486541:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[68164:68164:0712/034512.486674:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://tz.godymph.com/
[68164:68175:0712/034512.486648:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[68164:68164:0712/034512.486759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tz.godymph.com/, http://tz.godymph.com/, 4
[68164:68164:0712/034512.486849:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://tz.godymph.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:32:38 GMT Content-Type: text/html Last-Modified: Thu, 06 Jun 2019 09:52:42 GMT Vary: Accept-Encoding ETag: W/"5cf8e26a-2ef0" Content-Encoding: gzip  ,68261, 5
[68164:68164:0712/034512.488371:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[68164:68164:0712/034512.491063:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:7:0712/034512.491443:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[68164:68164:0712/034512.495512:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.siranda.cn/
[68164:68164:0712/034512.495580:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.siranda.cn/, http://www.siranda.cn/tongji.php?/5v38tqiz/, 5
[68164:68164:0712/034512.495670:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://www.siranda.cn/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 10:45:12 GMT Content-Type: text/html;charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/7.0.19 Content-Encoding: gzip  ,68261, 5
[68164:68175:0712/034512.497467:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[68164:68175:0712/034512.497560:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/034512.504041:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/034512.690678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/034512.690881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034512.692095:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034514.224476:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://tz.godymph.com/
[1:1:0712/034514.365068:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://www.siranda.cn/
[1:1:0712/034514.491317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034514.491636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[68164:68164:0712/034515.042134:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://tz.godymph.com/, http://tz.godymph.com/, 4
[68164:68164:0712/034515.042227:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://tz.godymph.com/, http://tz.godymph.com
[1:1:0712/034515.043650:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[68164:68164:0712/034515.181310:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://www.siranda.cn/, http://www.siranda.cn/, 5
[68164:68164:0712/034515.181368:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://www.siranda.cn/, http://www.siranda.cn
[1:1:0712/034515.810193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034515.810385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034516.059684:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034516.741388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034516.741569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034517.084588:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034517.084810:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/034517.134155:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0492971, 71, 1
[1:1:0712/034517.134411:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034517.180781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034517.181052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034517.949327:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034517.949518:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/034518.394607:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/034518.423739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034518.423912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034519.681754:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1060 0x7fc2acf0b080 0x2ca1796816a0 1 0 0x2ca1796816b8 , "http://tz.godymph.com/"
[1:1:0712/034519.692965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};ret
[1:1:0712/034519.693299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
		remove user.10_1a174808 -> 0
		remove user.11_564972cf -> 0
		remove user.12_9acdfa5e -> 0
		remove user.13_16429770 -> 0
		remove user.14_f79bb433 -> 0
		remove user.f_401c3faf -> 0
		remove user.10_19f8b063 -> 0
[1:1:0712/034519.971518:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0359879, 189, 1
[1:1:0712/034519.971859:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/034520.060685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034520.060975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034522.343783:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/034522.343947:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://tz.godymph.com/"
[1:1:0712/034522.344488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1115 0x7fc296881070 0x2ca179a143e0 , "http://tz.godymph.com/"
[1:1:0712/034522.345158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https
[1:1:0712/034522.345340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034522.348515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1115 0x7fc296881070 0x2ca179a143e0 , "http://tz.godymph.com/"
[1:1:0712/034522.355114:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://tz.godymph.com/"
[68164:68164:0712/034522.361576:INFO:CONSOLE(192)] "Uncaught TypeError: Cannot read property 'top' of undefined", source: http://tz.godymph.com/ (192)
[1:1:0712/034522.557943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034522.558196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034523.594174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034523.594417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034524.141114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1188 0x7fc2987a92e0 0x2ca1795c9460 , "http://tz.godymph.com/"
[1:1:0712/034524.142715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , , (function(){var h={},mt={},c={id:"11baf3ace8f57935317267e6e580bf4d",dm:["godymph.com"],js:"tongji.ba
[1:1:0712/034524.142860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034524.173707:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea190
[1:1:0712/034524.173928:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034524.174290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1215
[1:1:0712/034524.174480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1215 0x7fc296881070 0x2ca1796d4660 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1188 0x7fc2987a92e0 0x2ca1795c9460 
[1:1:0712/034524.570141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034524.570440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034526.353593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1215, 7fc2991c6881
[1:1:0712/034526.371770:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1188 0x7fc2987a92e0 0x2ca1795c9460 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034526.371967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1188 0x7fc2987a92e0 0x2ca1795c9460 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034526.372211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034526.372513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034526.372642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034526.373009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034526.373109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034526.373275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1281
[1:1:0712/034526.373383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1281 0x7fc296881070 0x2ca1798fb3e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1215 0x7fc296881070 0x2ca1796d4660 
[1:1:0712/034526.508300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034526.508553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034527.308633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/034527.309382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/034527.309654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034527.373806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034527.374129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034527.416242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1281, 7fc2991c6881
[1:1:0712/034527.478884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1215 0x7fc296881070 0x2ca1796d4660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034527.479297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1215 0x7fc296881070 0x2ca1796d4660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034527.479728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034527.480617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034527.480931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034527.481620:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034527.481818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034527.482130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1320
[1:1:0712/034527.482367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7fc296881070 0x2ca179ef7060 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1281 0x7fc296881070 0x2ca1798fb3e0 
[1:1:0712/034528.249432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034528.249730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034528.364385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1320, 7fc2991c6881
[1:1:0712/034528.421693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1281 0x7fc296881070 0x2ca1798fb3e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034528.422067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1281 0x7fc296881070 0x2ca1798fb3e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034528.422579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034528.423143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034528.423453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034528.424158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034528.424403:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034528.425120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1350
[1:1:0712/034528.425410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7fc296881070 0x2ca1790c6ce0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1320 0x7fc296881070 0x2ca179ef7060 
[1:1:0712/034528.794610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034528.794912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034529.229786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1350, 7fc2991c6881
[1:1:0712/034529.282184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1320 0x7fc296881070 0x2ca179ef7060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034529.282593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1320 0x7fc296881070 0x2ca179ef7060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034529.283024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034529.283600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034529.283901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034529.284594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034529.284791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034529.285150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1369
[1:1:0712/034529.285375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1369 0x7fc296881070 0x2ca179e74060 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1350 0x7fc296881070 0x2ca1790c6ce0 
[1:1:0712/034529.380420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034529.380733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034529.593755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034529.594060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034529.598962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1369, 7fc2991c6881
[1:1:0712/034529.664500:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1350 0x7fc296881070 0x2ca1790c6ce0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034529.664941:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1350 0x7fc296881070 0x2ca1790c6ce0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034529.665421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034529.666032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034529.666299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034529.666984:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034529.667190:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034529.667697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1392
[1:1:0712/034529.667958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1392 0x7fc296881070 0x2ca17a13abe0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1369 0x7fc296881070 0x2ca179e74060 
[1:1:0712/034530.098541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034530.098862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034530.359373:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1392, 7fc2991c6881
[1:1:0712/034530.382374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1369 0x7fc296881070 0x2ca179e74060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034530.382725:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1369 0x7fc296881070 0x2ca179e74060 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034530.383221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034530.384074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034530.384335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034530.384985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034530.385179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034530.385529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1408
[1:1:0712/034530.385805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7fc296881070 0x2ca17958f0e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1392 0x7fc296881070 0x2ca17a13abe0 
[1:1:0712/034530.522192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034530.522480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034530.694811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034530.695066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034530.726590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1408, 7fc2991c6881
[1:1:0712/034530.782313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1392 0x7fc296881070 0x2ca17a13abe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034530.782621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1392 0x7fc296881070 0x2ca17a13abe0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034530.783011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034530.783504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034530.783718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034530.784380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034530.784532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034530.784880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1423
[1:1:0712/034530.785066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1423 0x7fc296881070 0x2ca17a14dc60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1408 0x7fc296881070 0x2ca17958f0e0 
[1:1:0712/034530.914984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034530.915388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034531.296153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034531.296442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034531.465325:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1423, 7fc2991c6881
[1:1:0712/034531.526048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1408 0x7fc296881070 0x2ca17958f0e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034531.526383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1408 0x7fc296881070 0x2ca17958f0e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034531.526764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034531.527292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034531.527518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034531.528195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034531.528359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034531.528685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1454
[1:1:0712/034531.528875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7fc296881070 0x2ca17a95ba60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1423 0x7fc296881070 0x2ca17a14dc60 
[1:1:0712/034532.006635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034532.006933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034532.076245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1454, 7fc2991c6881
[1:1:0712/034532.141539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1423 0x7fc296881070 0x2ca17a14dc60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.141876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1423 0x7fc296881070 0x2ca17a14dc60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.142279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034532.142797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034532.143022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034532.143658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034532.143818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034532.144142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1474
[1:1:0712/034532.144380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1474 0x7fc296881070 0x2ca179769c60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1454 0x7fc296881070 0x2ca17a95ba60 
[1:1:0712/034532.351428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034532.351706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034532.432890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1474, 7fc2991c6881
[1:1:0712/034532.455926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1454 0x7fc296881070 0x2ca17a95ba60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.456236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1454 0x7fc296881070 0x2ca17a95ba60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.456657:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034532.457156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034532.457397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034532.458008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034532.458166:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034532.458508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1489
[1:1:0712/034532.458702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1489 0x7fc296881070 0x2ca17a2da9e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1474 0x7fc296881070 0x2ca179769c60 
[1:1:0712/034532.539418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034532.539605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034532.912807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034532.912984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034532.939295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1489, 7fc2991c6881
[1:1:0712/034532.977736:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1474 0x7fc296881070 0x2ca179769c60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.978034:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1474 0x7fc296881070 0x2ca179769c60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034532.978402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034532.978923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034532.979139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034532.979821:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034532.979976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034532.980288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1511
[1:1:0712/034532.980529:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1511 0x7fc296881070 0x2ca178ee6be0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1489 0x7fc296881070 0x2ca17a2da9e0 
[1:1:0712/034533.507254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034533.507517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034533.629777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1511, 7fc2991c6881
[1:1:0712/034533.657514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1489 0x7fc296881070 0x2ca17a2da9e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034533.657865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1489 0x7fc296881070 0x2ca17a2da9e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034533.658249:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034533.658769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034533.658996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034533.659603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034533.659789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034533.660110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1527
[1:1:0712/034533.660298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1527 0x7fc296881070 0x2ca17a7208e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1511 0x7fc296881070 0x2ca178ee6be0 
[1:1:0712/034533.892928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034533.893134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034533.999984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1527, 7fc2991c6881
[1:1:0712/034534.067693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1511 0x7fc296881070 0x2ca178ee6be0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034534.068104:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1511 0x7fc296881070 0x2ca178ee6be0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034534.068608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034534.069265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034534.069595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034534.070377:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034534.070573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034534.070968:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1549
[1:1:0712/034534.071205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1549 0x7fc296881070 0x2ca17a859460 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1527 0x7fc296881070 0x2ca17a7208e0 
[68164:68164:0712/034534.133656:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/034534.135164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034534.135329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034534.511738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034534.511935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034534.708036:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/034534.708496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , ready, (e){if(e===!0?--v.readyWait:v.isReady)return;if(!i.body)return setTimeout(v.ready,1);v.isReady=!0;if
[1:1:0712/034534.708635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034534.708823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://tz.godymph.com/"
[1:1:0712/034534.709764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://tz.godymph.com/"
[1:1:0712/034534.710461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea2f0
[1:1:0712/034534.710567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034534.710726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1571
[1:1:0712/034534.710834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1571 0x7fc296881070 0x2ca17a2bc4e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1556 0x7fc296881070 0x2ca179728260 
[1:1:0712/034534.935526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.siranda.cn/, 14d3f2a02860, , , document.readyState
[1:1:0712/034534.935799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.siranda.cn/5v38tqiz/", "www.siranda.cn", 3, 1, , , 0
[1:1:0712/034535.184224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1571, 7fc2991c6881
[1:1:0712/034535.203692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1556 0x7fc296881070 0x2ca179728260 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034535.203882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1556 0x7fc296881070 0x2ca179728260 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034535.204122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034535.204435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034535.204568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034535.204862:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034535.204957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034535.205139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1593
[1:1:0712/034535.205251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1593 0x7fc296881070 0x2ca178fa5c60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1571 0x7fc296881070 0x2ca17a2bc4e0 
[1:1:0712/034536.143225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1593, 7fc2991c6881
[1:1:0712/034536.207665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1571 0x7fc296881070 0x2ca17a2bc4e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034536.207996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1571 0x7fc296881070 0x2ca17a2bc4e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034536.208422:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034536.208927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034536.209153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034536.209783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034536.209943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034536.210262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1617
[1:1:0712/034536.210484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1617 0x7fc296881070 0x2ca17a15d2e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1593 0x7fc296881070 0x2ca178fa5c60 
[1:1:0712/034536.804022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1617, 7fc2991c6881
[1:1:0712/034536.870590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1593 0x7fc296881070 0x2ca178fa5c60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034536.870930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1593 0x7fc296881070 0x2ca178fa5c60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034536.871316:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034536.871845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034536.872086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034536.872747:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034536.872914:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034536.873235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1638
[1:1:0712/034536.873423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1638 0x7fc296881070 0x2ca17a977660 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1617 0x7fc296881070 0x2ca17a15d2e0 
[1:1:0712/034537.072818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1638, 7fc2991c6881
[1:1:0712/034537.094001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1617 0x7fc296881070 0x2ca17a15d2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.094206:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1617 0x7fc296881070 0x2ca17a15d2e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.094416:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034537.094747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034537.094886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034537.095191:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034537.095291:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034537.095462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1653
[1:1:0712/034537.095629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1653 0x7fc296881070 0x2ca17a15af60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1638 0x7fc296881070 0x2ca17a977660 
[1:1:0712/034537.387805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1653, 7fc2991c6881
[1:1:0712/034537.471578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1638 0x7fc296881070 0x2ca17a977660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.472053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1638 0x7fc296881070 0x2ca17a977660 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.472533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034537.473177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034537.473475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034537.479117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034537.479327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034537.479767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1660
[1:1:0712/034537.480018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1660 0x7fc296881070 0x2ca17a2bc7e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1653 0x7fc296881070 0x2ca17a15af60 
[1:1:0712/034537.609353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1660, 7fc2991c6881
[1:1:0712/034537.675593:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1653 0x7fc296881070 0x2ca17a15af60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.675988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1653 0x7fc296881070 0x2ca17a15af60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.676389:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034537.676923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034537.677151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034537.677787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034537.677952:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034537.681853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1669
[1:1:0712/034537.682086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1669 0x7fc296881070 0x2ca17a15a6e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1660 0x7fc296881070 0x2ca17a2bc7e0 
[1:1:0712/034537.886498:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1669, 7fc2991c6881
[1:1:0712/034537.947972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1660 0x7fc296881070 0x2ca17a2bc7e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.948323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1660 0x7fc296881070 0x2ca17a2bc7e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034537.948709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034537.949237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034537.949473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034537.950102:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034537.950262:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034537.950585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1677
[1:1:0712/034537.950792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1677 0x7fc296881070 0x2ca178ee6f60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1669 0x7fc296881070 0x2ca17a15a6e0 
[1:1:0712/034538.096300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1677, 7fc2991c6881
[1:1:0712/034538.117693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1669 0x7fc296881070 0x2ca17a15a6e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.117947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1669 0x7fc296881070 0x2ca17a15a6e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.118169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034538.118472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034538.118603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034538.118939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034538.119043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034538.119212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1688
[1:1:0712/034538.119322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1688 0x7fc296881070 0x2ca1798192e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1677 0x7fc296881070 0x2ca178ee6f60 
[1:1:0712/034538.269745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1688, 7fc2991c6881
[1:1:0712/034538.302021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1677 0x7fc296881070 0x2ca178ee6f60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.302249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1677 0x7fc296881070 0x2ca178ee6f60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.302467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034538.302769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034538.302942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034538.303296:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034538.303417:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034538.303666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1692
[1:1:0712/034538.303820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1692 0x7fc296881070 0x2ca178fa16e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1688 0x7fc296881070 0x2ca1798192e0 
[1:1:0712/034538.480141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1692, 7fc2991c6881
[1:1:0712/034538.547751:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1688 0x7fc296881070 0x2ca1798192e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.548160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1688 0x7fc296881070 0x2ca1798192e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.548548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034538.549073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034538.549300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034538.549909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034538.550097:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034538.550421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1694
[1:1:0712/034538.550608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1694 0x7fc296881070 0x2ca178ee4be0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1692 0x7fc296881070 0x2ca178fa16e0 
[1:1:0712/034538.732218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1694, 7fc2991c6881
[1:1:0712/034538.766302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1692 0x7fc296881070 0x2ca178fa16e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.766541:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1692 0x7fc296881070 0x2ca178fa16e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034538.766763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034538.767099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034538.767254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034538.767554:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034538.767650:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034538.767820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1697
[1:1:0712/034538.767929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1697 0x7fc296881070 0x2ca17a2f3de0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1694 0x7fc296881070 0x2ca178ee4be0 
[1:1:0712/034538.946798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1697, 7fc2991c6881
[1:1:0712/034539.018153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1694 0x7fc296881070 0x2ca178ee4be0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.018504:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1694 0x7fc296881070 0x2ca178ee4be0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.018886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034539.019420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034539.019647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034539.020315:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034539.020481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034539.020808:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1700
[1:1:0712/034539.021002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1700 0x7fc296881070 0x2ca1798d2f60 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1697 0x7fc296881070 0x2ca17a2f3de0 
[1:1:0712/034539.199333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1700, 7fc2991c6881
[1:1:0712/034539.275533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1697 0x7fc296881070 0x2ca17a2f3de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.275890:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1697 0x7fc296881070 0x2ca17a2f3de0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.276362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034539.276898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034539.277151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034539.277830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034539.277996:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034539.278360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1704
[1:1:0712/034539.278584:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1704 0x7fc296881070 0x2ca179ee76e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1700 0x7fc296881070 0x2ca1798d2f60 
[1:1:0712/034539.458114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1704, 7fc2991c6881
[1:1:0712/034539.531093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1700 0x7fc296881070 0x2ca1798d2f60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.531551:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1700 0x7fc296881070 0x2ca1798d2f60 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.532034:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034539.532717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034539.533001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034539.533788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034539.533990:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034539.534418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1707
[1:1:0712/034539.534665:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1707 0x7fc296881070 0x2ca17a7aa8e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1704 0x7fc296881070 0x2ca179ee76e0 
[1:1:0712/034539.688003:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1707, 7fc2991c6881
[1:1:0712/034539.746421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14d3f2ac5ff0","ptid":"1704 0x7fc296881070 0x2ca179ee76e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.746886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://tz.godymph.com/","ptid":"1704 0x7fc296881070 0x2ca179ee76e0 ","rf":"5:4_http://tz.godymph.com/"}
[1:1:0712/034539.747394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://tz.godymph.com/"
[1:1:0712/034539.748036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://tz.godymph.com/, 14d3f2ac5ff0, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/034539.748372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://tz.godymph.com/", "tz.godymph.com", 4, 1, http://www.siranda.cn, www.siranda.cn, 3
[1:1:0712/034539.749178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x15da5f4475b0, 0x2ca1791ea150
[1:1:0712/034539.749413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://tz.godymph.com/", 100
[1:1:0712/034539.749823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1710
[1:1:0712/034539.750091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1710 0x7fc296881070 0x2ca178ee43e0 , 5:4_http://tz.godymph.com/, 1, -5:4_http://tz.godymph.com/, 1707 0x7fc296881070 0x2ca17a7aa8e0 
[1:1:0712/034539.910687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_http://tz.godymph.com/, 1710, 7fc2991c6881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
