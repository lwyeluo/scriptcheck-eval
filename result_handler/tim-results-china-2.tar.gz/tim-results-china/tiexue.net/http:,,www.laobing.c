[0712/061019.795735:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/061019.798549:INFO:switcher_clone.cc(787)] backtrace rip is 7f4ccb86d891
[0712/061020.817257:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/061020.817759:INFO:switcher_clone.cc(787)] backtrace rip is 7f66d28e7891
[1:1:0712/061020.832114:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/061020.832434:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/061020.838069:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[88588:88588:0712/061021.955100:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/66ef9fe6-f34a-4a3b-8202-73efada5338c
[0712/061022.238251:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/061022.238580:INFO:switcher_clone.cc(787)] backtrace rip is 7fa4acc11891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[88620:88620:0712/061022.454308:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=88620
[88634:88634:0712/061022.454720:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=88634
[88588:88588:0712/061022.558058:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[88588:88618:0712/061022.558793:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/061022.559045:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/061022.559309:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/061022.559911:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/061022.560146:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/061022.563244:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x39cada14, 1
[1:1:0712/061022.563595:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36ba0c83, 0
[1:1:0712/061022.563811:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf946361, 3
[1:1:0712/061022.564052:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb73dcb9, 2
[1:1:0712/061022.564284:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff830cffffffba36 14ffffffdaffffffca39 ffffffb9ffffffdc730b 6163ffffff940f , 10104, 4
[1:1:0712/061022.565290:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[88588:88618:0712/061022.565544:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��6��9��sac�=/*
[88588:88618:0712/061022.565611:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��6��9��sac�%=/*
[1:1:0712/061022.565729:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66d0b220a0, 3
[88588:88618:0712/061022.565884:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/061022.565962:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66d0cad080, 2
[88588:88618:0712/061022.566007:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 88642, 4, 830cba36 14daca39 b9dc730b 6163940f 
[1:1:0712/061022.566137:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66ba970d20, -2
[1:1:0712/061022.587352:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/061022.588256:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b73dcb9
[1:1:0712/061022.589258:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b73dcb9
[1:1:0712/061022.590833:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b73dcb9
[1:1:0712/061022.592368:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.592559:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.592743:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.592935:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.593593:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b73dcb9
[1:1:0712/061022.593915:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f66d28e77ba
[1:1:0712/061022.594068:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f66d28dedef, 7f66d28e777a, 7f66d28e90cf
[1:1:0712/061022.596236:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b73dcb9
[1:1:0712/061022.596423:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b73dcb9
[1:1:0712/061022.596704:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b73dcb9
[1:1:0712/061022.598754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.599023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.599270:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.599504:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b73dcb9
[1:1:0712/061022.600314:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b73dcb9
[1:1:0712/061022.600495:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f66d28e77ba
[1:1:0712/061022.600587:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f66d28dedef, 7f66d28e777a, 7f66d28e90cf
[1:1:0712/061022.602789:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/061022.603095:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/061022.603189:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3e1f4608, 0x7ffc3e1f4588)
[1:1:0712/061022.621166:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/061022.628801:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[88588:88588:0712/061023.227999:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[88588:88588:0712/061023.229523:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[88588:88600:0712/061023.242001:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[88588:88588:0712/061023.242032:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[88588:88600:0712/061023.242137:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[88588:88588:0712/061023.242146:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[88588:88588:0712/061023.242309:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,88642, 4
[1:7:0712/061023.244621:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/061023.346169:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1f64cf1c5220
[1:1:0712/061023.346439:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[88588:88613:0712/061023.355619:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/061023.828836:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/061025.506487:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061025.510248:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[88588:88588:0712/061025.551128:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[88588:88588:0712/061025.551255:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/061026.563217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061026.667075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/061026.667412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061026.683673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/061026.684050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061026.780092:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061026.780270:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061027.201228:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061027.211210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/061027.211539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061027.254072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061027.264784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/061027.265068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061027.277925:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[88588:88588:0712/061027.280880:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/061027.281895:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1f64cf1c3e20
[1:1:0712/061027.282142:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[88588:88588:0712/061027.288073:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[88588:88588:0712/061027.343413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[88588:88588:0712/061027.343615:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/061027.393380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061028.137225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f66bc54b2e0 0x1f64cf466960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061028.138581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/061028.138793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061028.140253:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[88588:88588:0712/061028.216225:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/061028.218655:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1f64cf1c4820
[1:1:0712/061028.218950:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[88588:88588:0712/061028.223723:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/061028.237886:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/061028.238109:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[88588:88588:0712/061028.239332:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[88588:88588:0712/061028.247132:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[88588:88588:0712/061028.248185:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[88588:88600:0712/061028.254918:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[88588:88600:0712/061028.255016:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[88588:88588:0712/061028.255364:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[88588:88588:0712/061028.255469:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[88588:88588:0712/061028.255651:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,88642, 4
[1:7:0712/061028.262639:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/061028.886717:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/061029.434785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7f66bc54b2e0 0x1f64cf5638e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061029.435919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/061029.436158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061029.436939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[88588:88588:0712/061029.514899:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[88588:88588:0712/061029.515022:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/061029.546712:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/061029.933378:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[88588:88588:0712/061030.177951:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[88588:88618:0712/061030.178468:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/061030.178710:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/061030.179007:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/061030.179398:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/061030.179541:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/061030.182689:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x380dea5c, 1
[1:1:0712/061030.183116:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x386cccdb, 0
[1:1:0712/061030.183268:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x11f55fb9, 3
[1:1:0712/061030.183410:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1edcb96c, 2
[1:1:0712/061030.183552:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdbffffffcc6c38 5cffffffea0d38 6cffffffb9ffffffdc1e ffffffb95ffffffff511 , 10104, 5
[1:1:0712/061030.184632:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[88588:88618:0712/061030.184895:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��l8\�8l���_��1*
[88588:88618:0712/061030.184967:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��l8\�8l���_�(�1*
[1:1:0712/061030.185078:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66d0b220a0, 3
[88588:88618:0712/061030.185227:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 88688, 5, dbcc6c38 5cea0d38 6cb9dc1e b95ff511 
[1:1:0712/061030.185252:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66d0cad080, 2
[1:1:0712/061030.185455:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66ba970d20, -2
[1:1:0712/061030.196319:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/061030.196535:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1edcb96c
[1:1:0712/061030.196719:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1edcb96c
[1:1:0712/061030.197028:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1edcb96c
[1:1:0712/061030.197478:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.197582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.197674:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.197772:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.198032:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1edcb96c
[1:1:0712/061030.198175:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f66d28e77ba
[1:1:0712/061030.198251:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f66d28dedef, 7f66d28e777a, 7f66d28e90cf
[1:1:0712/061030.199709:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1edcb96c
[1:1:0712/061030.200033:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1edcb96c
[1:1:0712/061030.200770:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1edcb96c
[1:1:0712/061030.202911:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.203195:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.203389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.203583:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1edcb96c
[1:1:0712/061030.204273:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1edcb96c
[1:1:0712/061030.204468:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f66d28e77ba
[1:1:0712/061030.204551:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f66d28dedef, 7f66d28e777a, 7f66d28e90cf
[1:1:0712/061030.206840:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/061030.207183:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/061030.207275:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc3e1f4608, 0x7ffc3e1f4588)
[1:1:0712/061030.217895:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/061030.222577:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/061030.383812:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1f64cf194220
[1:1:0712/061030.384114:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/061030.454103:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061030.454368:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061031.021712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061031.026311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 262d53cee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/061031.026652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/061031.032596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061031.154734:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/061031.155487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 262d53bc1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/061031.155773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/061031.251309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061031.253037:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/061031.253333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 262d53cee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/061031.253630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[88588:88588:0712/061031.393362:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/061031.396165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061031.397401:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/061031.397615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 262d53cee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/061031.397883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[88588:88588:0712/061031.401533:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[88588:88600:0712/061031.437879:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[88588:88600:0712/061031.437984:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[88588:88588:0712/061031.438175:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.laobing.cn/
[88588:88588:0712/061031.438233:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.laobing.cn/, http://www.laobing.cn/online, 1
[88588:88588:0712/061031.438320:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.laobing.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:10:31 GMT Content-Type: text/html; charset=utf-8 Content-Length: 3925 Connection: keep-alive Vary: Accept-Encoding Cache-Control: private Content-Encoding: gzip Vary: Accept-Encoding X-AspNetMvc-Version: 4.0 X-AspNet-Version: 4.0.30319 Set-Cookie: p=; domain=laobing.cn; expires=Thu, 12-Jul-2018 13:10:30 GMT; path=/ X-Via-JSL: 838e7c2,- Set-Cookie: __jsluid_h=ade04e7e3b7b7c3d6c95d6977409e851; max-age=31536000; path=/; HttpOnly X-Cache: bypass  ,88688, 5
[1:7:0712/061031.442456:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/061031.487308:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.laobing.cn/
[88588:88588:0712/061031.614975:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.laobing.cn/, http://www.laobing.cn/, 1
[88588:88588:0712/061031.615044:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.laobing.cn/, http://www.laobing.cn
[1:1:0712/061031.642268:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/061031.680002:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/061031.758290:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061031.819292:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061031.819558:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.laobing.cn/online"
[1:1:0712/061031.840322:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/061031.984407:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061032.038652:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/061032.109060:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://s.itiexue.net/js/base-all-v2.js"
[1:1:0712/061032.333673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7f66ba98bbd0 0x1f64cf2b4cd8 , "http://www.laobing.cn/online"
[1:1:0712/061032.347423:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061032.361105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/061032.361465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "www.laobing.cn", 3, 1, , , 0
[1:1:0712/061032.383287:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/061032.445695:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/061032.582318:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/061032.691605:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/061032.752606:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/061033.044301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/061033.045267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 262d53cee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/061033.045586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
		remove user.f_f8769a29 -> 0
[1:1:0712/061033.882821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7f66ba98bbd0 0x1f64cf2b4cd8 , "http://www.laobing.cn/online"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/061034.123640:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "www.laobing.cn", "laobing.cn"
[1:1:0712/061041.326609:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061041.327149:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061041.329593:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061041.330092:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061041.330476:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[88588:88588:0712/061050.614149:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/061050.620210:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/061050.770411:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 16.9052, 0, 0
[1:1:0712/061050.770690:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061050.949618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/061050.949930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061051.399961:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061051.400262:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.laobing.cn/online"
[1:1:0712/061051.412295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f66ba623070 0x1f64cf2b07e0 , "http://www.laobing.cn/online"
[1:1:0712/061051.419590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , /*============loginBar start======================
	登陆条调用方法：
	var pageRefresh=fals
[1:1:0712/061051.419893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061051.421225:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "laobing.cn", "laobing.cn"
[1:1:0712/061051.429400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f66ba623070 0x1f64cf2b07e0 , "http://www.laobing.cn/online"
[1:1:0712/061051.665944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.265636, 92, 1
[1:1:0712/061051.666263:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061052.151044:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_INVALID_ARGUMENT","http://im.bizapp.qq.com:8000/zx_qq.gif"
[1:1:0712/061052.382127:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061052.382289:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.laobing.cn/online"
[1:1:0712/061052.382915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7f66ba623070 0x1f64cf96a860 , "http://www.laobing.cn/online"
[1:1:0712/061052.383561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , 
    $("#do1").addClass("select");

[1:1:0712/061052.383777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061053.029785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061053.030089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061053.249707:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://s.itiexue.net/js/base-all-v2.js"
[1:1:0712/061053.257144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306, "http://www.laobing.cn/online"
[1:1:0712/061053.258830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , //����ͼ���
(function($){$.fn.WIT_SetTab=function(iSet){iSet=$.extend({Nav:null,Field
[1:1:0712/061053.259097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061053.262627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306, "http://www.laobing.cn/online"
[1:1:0712/061053.278305:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0242541, 70, 1
[1:1:0712/061053.278590:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061053.635823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061053.636258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061053.943136:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061053.943414:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.laobing.cn/online"
[1:1:0712/061053.944422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 345 0x7f66ba623070 0x1f64d0e2e1e0 , "http://www.laobing.cn/online"
[1:1:0712/061053.946002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , 
        //兼容ie6客服悬浮
        var ie6 = ! -[1, ] && !window.XMLHttpRequest;
        $(win
[1:1:0712/061053.946291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061053.969973:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 345 0x7f66ba623070 0x1f64d0e2e1e0 , "http://www.laobing.cn/online"
[1:1:0712/061053.974108:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.laobing.cn/online"
[1:1:0712/061053.987553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.laobing.cn/online"
[88588:88588:0712/061054.189227:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: http://www.laobing.cn/online (0)
[1:1:0712/061054.275857:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_INVALID_ARGUMENT","http://im.bizapp.qq.com:8000/zx_qq.gif"
[1:1:0712/061054.368093:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.laobing.cn/online"
[1:1:0712/061054.369053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , i, (a) { return typeof f != "undefined" && (!a || f.event.triggered !== a.type) ? f.event.dispatch.appl
[1:1:0712/061054.369580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061054.464018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061054.464316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/061054.959029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061054.960979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061055.150505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 402 0x7f66bc54b2e0 0x1f64cf8fc360 , "http://www.laobing.cn/online"
[1:1:0712/061055.151566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , ___baidu_union_callback_("auto","81482c0090f57e9deedcbe2e1c1ccfc1",[])
[1:1:0712/061055.151842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061055.167966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7f66bc54b2e0 0x1f64cf8fcfe0 , "http://www.laobing.cn/online"
[1:1:0712/061055.168917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , jQuery17201541456344153158_1562937034101([{"U":"0"}])
[1:1:0712/061055.169164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061055.170629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.laobing.cn/online"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/061055.320359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061055.320674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061055.453095:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.laobing.cn/online"
[1:1:0712/061055.453890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/061055.454196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[1:1:0712/061055.456780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.laobing.cn/online"
[88588:88588:0712/061055.469493:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/061055.470407:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1f64cf994420
[1:1:0712/061055.470711:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[88588:88588:0712/061055.482392:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/061055.491053:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/061055.491389:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.laobing.cn
[1:1:0712/061055.494136:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.laobing.cn/online"
[1:1:0712/061055.494847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.laobing.cn/online"
[88588:88588:0712/061055.497792:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.laobing.cn/
[1:1:0712/061055.658180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.laobing.cn/, 3d44ac6e2860, , , document.readyState
[1:1:0712/061055.658491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.laobing.cn/online", "laobing.cn", 3, 1, , , 0
[88588:88588:0712/061055.661430:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[88588:88588:0712/061055.667613:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[88588:88600:0712/061055.698482:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[88588:88600:0712/061055.698586:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[88588:88588:0712/061055.698743:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[88588:88588:0712/061055.698824:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 4
[88588:88588:0712/061055.698957:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 13:10:55 GMT Last-Modified: Fri, 12 Jul 2019 03:18:19 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d27fbfb-229"  ,88688, 5
[1:7:0712/061055.709982:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/061056.233392:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://pos.baidu.com/
[1:1:0712/061056.453491:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[88588:88588:0712/061056.458006:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/, 4
[88588:88588:0712/061056.458127:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0712/061056.547256:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/061056.746111:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/061056.746424:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061057.375624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 527 0x7f66ba98bbd0 0x1f64d0db6158 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061057.383448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , , (function(){if(!PluginDetect)var PluginDetect={getNum:function(b,c){if(!this.num(b))return null;var 
[1:1:0712/061057.383768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061057.409837:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061057.410309:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/061057.443082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x4796d05b1c0, 0x1f64cf009160
[1:1:0712/061057.445062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 2000
[1:1:0712/061057.445463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 532
[1:1:0712/061057.445706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 532 0x7f66ba623070 0x1f64d12a04e0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 527 0x7f66ba98bbd0 0x1f64d0db6158 
[1:1:0712/061057.448074:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009160
[1:1:0712/061057.448274:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061057.448671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 533
[1:1:0712/061057.448900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7f66ba623070 0x1f64cf96bee0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 527 0x7f66ba98bbd0 0x1f64d0db6158 
[1:1:0712/061057.459968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 527 0x7f66ba98bbd0 0x1f64d0db6158 , "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061057.472760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061057.767469:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 533, 7f66bcf68881
[1:1:0712/061057.813515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"527 0x7f66ba98bbd0 0x1f64d0db6158 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061057.814383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"527 0x7f66ba98bbd0 0x1f64d0db6158 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061057.815155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061057.815901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061057.816255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061057.817934:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061057.818198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061057.818703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 559
[1:1:0712/061057.819003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 559 0x7f66ba623070 0x1f64cedd7b60 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 533 0x7f66ba623070 0x1f64cf96bee0 
[1:1:0712/061058.091982:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 559, 7f66bcf68881
[1:1:0712/061058.110965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"533 0x7f66ba623070 0x1f64cf96bee0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.111215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"533 0x7f66ba623070 0x1f64cf96bee0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.111431:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061058.111795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061058.111935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061058.113168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061058.113275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061058.113453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 568
[1:1:0712/061058.113561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7f66ba623070 0x1f64cf96d5e0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 559 0x7f66ba623070 0x1f64cedd7b60 
[1:1:0712/061058.410895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 568, 7f66bcf68881
[1:1:0712/061058.442550:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"559 0x7f66ba623070 0x1f64cedd7b60 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.442876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"559 0x7f66ba623070 0x1f64cedd7b60 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.443264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061058.443787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061058.444051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061058.444857:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061058.445021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061058.445373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 571
[1:1:0712/061058.445561:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7f66ba623070 0x1f64cf22f860 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 568 0x7f66ba623070 0x1f64cf96d5e0 
[1:1:0712/061058.724316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 571, 7f66bcf68881
[1:1:0712/061058.749902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"568 0x7f66ba623070 0x1f64cf96d5e0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.750253:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"568 0x7f66ba623070 0x1f64cf96d5e0 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061058.750654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061058.751225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061058.751460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061058.752316:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061058.752488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061058.752861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 574
[1:1:0712/061058.753088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f66ba623070 0x1f64cf860460 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 571 0x7f66ba623070 0x1f64cf22f860 
[1:1:0712/061059.043256:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 574, 7f66bcf68881
[1:1:0712/061059.068579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"571 0x7f66ba623070 0x1f64cf22f860 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.068878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"571 0x7f66ba623070 0x1f64cf22f860 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.069292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061059.069845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061059.070113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061059.070927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061059.071121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061059.071583:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 576
[1:1:0712/061059.071780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 576 0x7f66ba623070 0x1f64d12a3560 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 574 0x7f66ba623070 0x1f64cf860460 
[1:1:0712/061059.349973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 576, 7f66bcf68881
[1:1:0712/061059.361090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"574 0x7f66ba623070 0x1f64cf860460 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.361294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"574 0x7f66ba623070 0x1f64cf860460 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.361520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061059.361852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , F, (){if(!detectFlash(fname)&&
!isSend)return setTimeout(F,250)}
[1:1:0712/061059.361995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
[1:1:0712/061059.362859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4796d05b1c0, 0x1f64cf009150
[1:1:0712/061059.362974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://pos.baidu.com/wh/o.htm?ltr=", 250
[1:1:0712/061059.363187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 579
[1:1:0712/061059.363307:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f66ba623070 0x1f64d0ed58e0 , 5:4_https://pos.baidu.com/, 1, -5:4_https://pos.baidu.com/, 576 0x7f66ba623070 0x1f64d12a3560 
[1:1:0712/061059.465940:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://pos.baidu.com/, 532, 7f66bcf68881
[1:1:0712/061059.492356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d44ac7ede58","ptid":"527 0x7f66ba98bbd0 0x1f64d0db6158 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.492733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://pos.baidu.com/","ptid":"527 0x7f66ba98bbd0 0x1f64d0db6158 ","rf":"5:4_https://pos.baidu.com/"}
[1:1:0712/061059.493192:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://pos.baidu.com/wh/o.htm?ltr="
[1:1:0712/061059.493765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://pos.baidu.com/, 3d44ac7ede58, , , (){if(!isSend)send()}
[1:1:0712/061059.494008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://pos.baidu.com/wh/o.htm?ltr=", "pos.baidu.com", 4, 1, http://www.laobing.cn, laobing.cn, 3
		remove user.11_88b14bc3 -> 0
		remove user.12_e44b1fad -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
