[0711/234034.074966:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234034.075364:INFO:switcher_clone.cc(787)] backtrace rip is 7f960b08a891
[0711/234034.998351:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234034.998763:INFO:switcher_clone.cc(787)] backtrace rip is 7fa159910891
[1:1:0711/234035.010526:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/234035.010803:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/234035.016314:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[35309:35309:0711/234036.149038:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0752ea24-3552-42e1-b0bd-c83d8342b7d2
[0711/234036.400065:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234036.400516:INFO:switcher_clone.cc(787)] backtrace rip is 7fc443efe891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[35340:35340:0711/234036.626004:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35340
[35353:35353:0711/234036.626445:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35353
[35309:35309:0711/234036.721921:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[35309:35338:0711/234036.722715:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/234036.722924:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234036.723224:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234036.723973:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234036.724226:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/234036.727160:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x15b3a10f, 1
[1:1:0711/234036.727580:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12994afa, 0
[1:1:0711/234036.727773:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2f0346c3, 3
[1:1:0711/234036.727981:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x280df308, 2
[1:1:0711/234036.728255:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffa4affffff9912 0fffffffa1ffffffb315 08fffffff30d28 ffffffc346032f , 10104, 4
[1:1:0711/234036.729424:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35309:35338:0711/234036.729684:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�J����(�F/ED�'
[35309:35338:0711/234036.729770:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �J����(�F/8GED�'
[1:1:0711/234036.729678:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa157b4b0a0, 3
[35309:35338:0711/234036.730012:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/234036.729930:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa157cd6080, 2
[35309:35338:0711/234036.730079:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35361, 4, fa4a9912 0fa1b315 08f30d28 c346032f 
[1:1:0711/234036.730131:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa141999d20, -2
[1:1:0711/234036.754659:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234036.755718:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 280df308
[1:1:0711/234036.756926:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 280df308
[1:1:0711/234036.758514:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 280df308
[1:1:0711/234036.759074:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.759208:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.759323:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.759424:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.759653:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 280df308
[1:1:0711/234036.759793:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa1599107ba
[1:1:0711/234036.759867:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa159907def, 7fa15991077a, 7fa1599120cf
[1:1:0711/234036.761342:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 280df308
[1:1:0711/234036.761502:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 280df308
[1:1:0711/234036.761775:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 280df308
[1:1:0711/234036.762472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.762583:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.762677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.762770:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 280df308
[1:1:0711/234036.763228:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 280df308
[1:1:0711/234036.763390:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa1599107ba
[1:1:0711/234036.763464:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa159907def, 7fa15991077a, 7fa1599120cf
[1:1:0711/234036.767427:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234036.767923:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234036.768109:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd77d4a518, 0x7ffd77d4a498)
[1:1:0711/234036.787311:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234036.793661:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[35309:35309:0711/234037.367933:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35309:35309:0711/234037.369116:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35309:35320:0711/234037.391172:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[35309:35320:0711/234037.391302:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[35309:35309:0711/234037.391505:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[35309:35309:0711/234037.391606:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[35309:35309:0711/234037.391837:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,35361, 4
[1:7:0711/234037.394429:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[35309:35333:0711/234037.431268:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/234037.501795:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1e6477fed220
[1:1:0711/234037.502070:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/234037.916530:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[35309:35309:0711/234039.367113:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[35309:35309:0711/234039.367195:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234039.411929:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234039.413402:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234040.272825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234040.273016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234040.282668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234040.282915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234040.334373:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234040.724932:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234040.725152:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234041.119326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234041.127403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234041.127660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234041.162744:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234041.173234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234041.173501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234041.185471:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[35309:35309:0711/234041.187933:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234041.188846:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e6477febe20
[1:1:0711/234041.189042:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[35309:35309:0711/234041.194752:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[35309:35309:0711/234041.226456:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[35309:35309:0711/234041.226619:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234041.290336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234042.092661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fa1435742e0 0x1e64781c5460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234042.094036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/234042.094301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234042.095907:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35309:35309:0711/234042.164123:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[35309:35309:0711/234042.166352:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/234042.166274:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1e6477fec820
[1:1:0711/234042.166513:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/234042.185753:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/234042.186008:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[35309:35309:0711/234042.187101:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[35309:35309:0711/234042.197070:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35309:35309:0711/234042.198084:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35309:35320:0711/234042.204191:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[35309:35320:0711/234042.204282:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[35309:35309:0711/234042.204435:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[35309:35309:0711/234042.204511:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[35309:35309:0711/234042.204671:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,35361, 4
[1:7:0711/234042.208554:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234042.672263:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/234042.991673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fa1435742e0 0x1e647827f0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234042.992657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3f0fc0b61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/234042.992896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234042.993614:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35309:35309:0711/234043.142406:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[35309:35309:0711/234043.142564:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/234043.173231:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234043.458080:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234044.051482:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234044.051774:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[35309:35309:0711/234044.209733:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[35309:35338:0711/234044.210266:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/234044.210533:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234044.210783:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234044.211299:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234044.211438:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/234044.214576:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x167d281e, 1
[1:1:0711/234044.215042:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2970e10d, 0
[1:1:0711/234044.215257:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x111ae5c8, 3
[1:1:0711/234044.215441:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ba3bc98, 2
[1:1:0711/234044.215607:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0dffffffe17029 1e287d16 ffffff98ffffffbcffffffa32b ffffffc8ffffffe51a11 , 10104, 5
[1:1:0711/234044.216648:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35309:35338:0711/234044.216897:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�p)(}���+���E�'
[35309:35338:0711/234044.216971:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �p)(}���+��8��E�'
[1:1:0711/234044.216883:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa157b4b0a0, 3
[1:1:0711/234044.217093:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa157cd6080, 2
[35309:35338:0711/234044.217266:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35405, 5, 0de17029 1e287d16 98bca32b c8e51a11 
[1:1:0711/234044.217390:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa141999d20, -2
[1:1:0711/234044.238424:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234044.238902:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ba3bc98
[1:1:0711/234044.239353:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ba3bc98
[1:1:0711/234044.240173:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ba3bc98
[1:1:0711/234044.241919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.242194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.242431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.242666:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.243567:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ba3bc98
[1:1:0711/234044.243933:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa1599107ba
[1:1:0711/234044.244106:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa159907def, 7fa15991077a, 7fa1599120cf
[1:1:0711/234044.248828:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ba3bc98
[1:1:0711/234044.249014:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ba3bc98
[1:1:0711/234044.249666:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ba3bc98
[1:1:0711/234044.251668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.251883:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.252064:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.252341:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ba3bc98
[1:1:0711/234044.253591:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ba3bc98
[1:1:0711/234044.253956:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa1599107ba
[1:1:0711/234044.254088:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa159907def, 7fa15991077a, 7fa1599120cf
[1:1:0711/234044.262508:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234044.263159:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234044.263365:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd77d4a518, 0x7ffd77d4a498)
[1:1:0711/234044.277905:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234044.282229:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/234044.497686:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e6477fae220
[1:1:0711/234044.497898:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/234044.548398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234044.551033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3f0fc0c8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/234044.551327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/234044.559125:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[35309:35309:0711/234045.323588:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35309:35309:0711/234045.329631:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35309:35320:0711/234045.359778:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[35309:35320:0711/234045.359869:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[35309:35309:0711/234045.360676:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://game.g.pptv.com/
[35309:35309:0711/234045.360782:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.g.pptv.com/, http://game.g.pptv.com/go?gid=bjsg&sid=40, 1
[35309:35309:0711/234045.360942:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://game.g.pptv.com/, HTTP/1.1 200 OK Server: styx Date: Fri, 12 Jul 2019 06:40:44 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=1vkp4s3va2h9d3frce4tvajbp5; path=/; domain=.pptv.com Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Content-Encoding: gzip  ,35405, 5
[1:7:0711/234045.367298:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234045.393533:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://game.g.pptv.com/
[35309:35309:0711/234045.475536:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.g.pptv.com/, http://game.g.pptv.com/, 1
[35309:35309:0711/234045.475658:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://game.g.pptv.com/, http://game.g.pptv.com
[1:1:0711/234045.496001:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234045.600727:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234045.648825:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234045.649090:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.g.pptv.com/go?gid=bjsg&sid=40"
[1:1:0711/234045.652932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 121 0x7fa14164c070 0x1e64780d41e0 , "http://game.g.pptv.com/go?gid=bjsg&sid=40"
[1:1:0711/234045.654951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.g.pptv.com/, 09a6d84c2860, , , document.location.href="/user/login?goto=%2Fgo%3Fgid%3Dbjsg%26sid%3D40";
[1:1:0711/234045.655178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.g.pptv.com/go?gid=bjsg&sid=40", "game.g.pptv.com", 3, 1, , , 0
[1:1:0711/234045.703094:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/234045.703339:INFO:render_frame_impl.cc(7019)] 	 [url] = http://game.g.pptv.com
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234046.710213:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234046.710683:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234046.711253:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234046.711754:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234046.712181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234058.901203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.g.pptv.com/, 09a6d84c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/234058.901484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.g.pptv.com/go?gid=bjsg&sid=40", "game.g.pptv.com", 3, 1, , , 0
[1:1:0711/234058.904771:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[35309:35309:0711/234059.259023:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://game.g.pptv.com/
[35309:35309:0711/234059.320546:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/234059.327833:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[35309:35309:0711/234059.818989:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35309:35309:0711/234059.819578:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35309:35320:0711/234059.845342:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[35309:35320:0711/234059.845451:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[35309:35309:0711/234059.845674:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://game.g.pptv.com/
[35309:35309:0711/234059.845771:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.g.pptv.com/, http://game.g.pptv.com/user/login?goto=%2Fgo%3Fgid%3Dbjsg%26sid%3D40, 1
[35309:35309:0711/234059.845889:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://game.g.pptv.com/, HTTP/1.1 200 OK Server: styx Date: Fri, 12 Jul 2019 06:40:59 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Content-Encoding: gzip  ,35405, 5
[1:7:0711/234059.848437:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234059.871428:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://game.g.pptv.com/
[1:1:0711/234100.015497:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[35309:35309:0711/234100.021741:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://game.g.pptv.com/, http://game.g.pptv.com/, 1
[35309:35309:0711/234100.021831:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://game.g.pptv.com/, http://game.g.pptv.com
[1:1:0711/234100.098396:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234100.204731:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234100.204993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://game.g.pptv.com/user/login?goto=%2Fgo%3Fgid%3Dbjsg%26sid%3D40"
[1:1:0711/234102.817244:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234103.598958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7fa14164c070 0x1e64780536e0 , "http://game.g.pptv.com/user/login?goto=%2Fgo%3Fgid%3Dbjsg%26sid%3D40"
[1:1:0711/234103.614860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://game.g.pptv.com/, 09a6d84c2860, , , var _0x3f3d=["","\x56\x31\x38\x30\x39\x30\x36","\x6C\x65\x6E\x67\x74\x68","\x72\x61\x6E\x64\x6F\x6D"
[1:1:0711/234103.615095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://game.g.pptv.com/user/login?goto=%2Fgo%3Fgid%3Dbjsg%26sid%3D40", "game.g.pptv.com", 3, 1, , , 0
