[0711/234832.839846:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234832.840229:INFO:switcher_clone.cc(787)] backtrace rip is 7f55fbddf891
[0711/234834.230291:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234834.230528:INFO:switcher_clone.cc(787)] backtrace rip is 7fe2deefe891
[1:1:0711/234834.234535:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/234834.234700:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/234834.239211:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[36224:36224:0711/234835.316788:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f56326b9-dd60-4b46-8e8e-09e9053b14b9
[0711/234835.758601:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/234835.758990:INFO:switcher_clone.cc(787)] backtrace rip is 7f826d54b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[36224:36224:0711/234835.923998:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[36224:36255:0711/234835.924849:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/234835.925088:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234835.925294:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234835.925871:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234835.926063:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/234835.928983:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x41e8369, 1
[1:1:0711/234835.929367:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x160e0df5, 0
[1:1:0711/234835.929581:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3dd8bfa9, 3
[1:1:0711/234835.929782:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xf861c7c, 2
[1:1:0711/234835.930206:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff50d0e16 69ffffff831e04 7c1cffffff860f ffffffa9ffffffbfffffffd83d , 10104, 4
[1:1:0711/234835.931200:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[36224:36255:0711/234835.931473:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�i�|����=�&�?
[36224:36255:0711/234835.931588:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �i�|����=�&�?
[1:1:0711/234835.931465:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2dd1390a0, 3
[1:1:0711/234835.931828:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2dd2c4080, 2
[36224:36255:0711/234835.931983:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[36224:36255:0711/234835.932096:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36270, 4, f50d0e16 69831e04 7c1c860f a9bfd83d 
[1:1:0711/234835.932097:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2c6f87d20, -2
[1:1:0711/234835.950766:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234835.951602:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal f861c7c
[1:1:0711/234835.952495:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal f861c7c
[1:1:0711/234835.953982:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal f861c7c
[1:1:0711/234835.955443:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.955660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.955872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.956099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.956730:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal f861c7c
[1:1:0711/234835.957112:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe2deefe7ba
[1:1:0711/234835.957296:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe2deef5def, 7fe2deefe77a, 7fe2def000cf
[1:1:0711/234835.964526:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal f861c7c
[1:1:0711/234835.964898:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal f861c7c
[1:1:0711/234835.965631:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal f861c7c
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/234835.967570:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.967808:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.968054:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.968281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal f861c7c
[1:1:0711/234835.969519:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal f861c7c
[1:1:0711/234835.969897:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe2deefe7ba
[1:1:0711/234835.970080:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe2deef5def, 7fe2deefe77a, 7fe2def000cf
[1:1:0711/234835.977567:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234835.978091:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234835.978266:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4e5073c8, 0x7ffe4e507348)
[36257:36257:0711/234835.984449:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=36257
[36277:36277:0711/234835.984867:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=36277
[1:1:0711/234835.992259:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234835.998090:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[36224:36249:0711/234836.635312:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[36224:36224:0711/234836.660624:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[36224:36224:0711/234836.662076:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[36224:36236:0711/234836.685002:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[36224:36236:0711/234836.685102:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[36224:36224:0711/234836.685389:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[36224:36224:0711/234836.685489:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[36224:36224:0711/234836.685661:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,36270, 4
[1:7:0711/234836.690497:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234836.702093:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2ad90cdb220
[1:1:0711/234836.702342:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/234837.115564:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[36224:36224:0711/234838.747503:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[36224:36224:0711/234838.747673:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234838.777832:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234838.781358:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234839.511000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234839.511354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234839.531214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/234839.531505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234839.545266:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234839.836141:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234839.836416:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234840.083075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234840.091217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234840.091457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234840.109694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234840.120035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/234840.120235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234840.132003:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36224:36224:0711/234840.134797:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234840.135818:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ad90cd9e20
[1:1:0711/234840.135991:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[36224:36224:0711/234840.141573:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[36224:36224:0711/234840.174968:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[36224:36224:0711/234840.175163:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/234840.220208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234841.179715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fe2c8b622e0 0x2ad908c2fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234841.181390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/234841.181650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234841.183512:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[36224:36224:0711/234841.253225:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234841.254392:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ad90cda820
[1:1:0711/234841.254583:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/234841.262766:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/234841.263012:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[36224:36224:0711/234841.264427:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[36224:36224:0711/234841.283330:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[36224:36224:0711/234841.295204:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[36224:36224:0711/234841.296210:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[36224:36236:0711/234841.303310:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[36224:36236:0711/234841.303396:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[36224:36224:0711/234841.303660:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[36224:36224:0711/234841.303759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[36224:36224:0711/234841.304240:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,36270, 4
[1:7:0711/234841.307118:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234841.716175:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/234842.164342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7fe2c8b622e0 0x2ad91096660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234842.165390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/234842.165994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/234842.166797:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[36224:36224:0711/234842.214297:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[36224:36224:0711/234842.214414:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/234842.228418:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234842.827853:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[36224:36224:0711/234842.987086:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[36224:36255:0711/234842.987547:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/234842.987737:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/234842.988019:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/234842.988434:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/234842.988573:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/234842.991500:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x258a331, 1
[1:1:0711/234842.991828:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x14695b8f, 0
[1:1:0711/234842.991975:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39785920, 3
[1:1:0711/234842.992117:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1d544796, 2
[1:1:0711/234842.992324:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8f5b6914 31ffffffa35802 ffffff9647541d 20597839 , 10104, 5
[1:1:0711/234842.993288:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[36224:36255:0711/234842.993547:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�[i1�X�GT Yx9�)�?
[1:1:0711/234842.993526:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2dd1390a0, 3
[36224:36255:0711/234842.993624:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �[i1�X�GT Yx9�K�)�?
[1:1:0711/234842.993698:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2dd2c4080, 2
[36224:36255:0711/234842.993881:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 36323, 5, 8f5b6914 31a35802 9647541d 20597839 
[1:1:0711/234842.993897:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe2c6f87d20, -2
[1:1:0711/234843.015205:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/234843.015515:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d544796
[1:1:0711/234843.015850:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d544796
[1:1:0711/234843.016540:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d544796
[1:1:0711/234843.017936:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.018119:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.018313:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.018488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.019122:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d544796
[1:1:0711/234843.019461:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe2deefe7ba
[1:1:0711/234843.019596:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe2deef5def, 7fe2deefe77a, 7fe2def000cf
[1:1:0711/234843.025438:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d544796
[1:1:0711/234843.025788:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d544796
[1:1:0711/234843.026517:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d544796
[1:1:0711/234843.028638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.028904:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.029088:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.029304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d544796
[1:1:0711/234843.030523:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d544796
[1:1:0711/234843.030882:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe2deefe7ba
[1:1:0711/234843.031015:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe2deef5def, 7fe2deefe77a, 7fe2def000cf
[1:1:0711/234843.039872:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/234843.040398:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/234843.040562:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4e5073c8, 0x7ffe4e507348)
[1:1:0711/234843.055228:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/234843.059799:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/234843.251026:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ad90cb7220
[1:1:0711/234843.251207:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/234843.268009:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234843.268292:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234843.614424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234843.618998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39b879aae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/234843.619327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/234843.627053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234843.707652:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/234843.708471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39b879981f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/234843.708733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[36224:36224:0711/234843.833140:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0711/234843.838651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[36224:36224:0711/234843.839973:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/234843.840246:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/234843.840545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39b879aae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/234843.840833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[36224:36236:0711/234843.864678:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[36224:36236:0711/234843.864741:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[36224:36224:0711/234843.867091:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://sports.pptv.com/
[36224:36224:0711/234843.867134:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sports.pptv.com/, http://sports.pptv.com/article/pg_detail?aid=614035&type=article, 1
[36224:36224:0711/234843.867195:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://sports.pptv.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:48:43 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Pragma: public Last-Modified: Fri, 12 Jul 2019 06:48:43 GMT Cache-Control: public, max-age=300 expires: Fri, 12 Jul 2019 06:53:43 GMT Content-Encoding: gzip Sta-Last-Modified: 1562914123 Age: 0 X-C: HIT Via-2: http/1.1 shnj-b-ats-161-32-2 ( [uIcSsSfUpSeN:t cCSi pSs ]) Via: http/1.1 wh-ck-ats-158-73-1 (ApacheTrafficServer/4.2.3 [uScSsSfUpSeN:t cCSi pSs ])  ,36323, 5
[1:7:0711/234843.870001:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/234843.897635:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://sports.pptv.com/
[1:1:0711/234843.972795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/234843.973564:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/234843.973783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39b879aae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/234843.974060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/234844.058978:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234844.059713:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[36224:36224:0711/234844.075372:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://sports.pptv.com/, http://sports.pptv.com/, 1
[36224:36224:0711/234844.075500:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://sports.pptv.com/, http://sports.pptv.com
[1:1:0711/234844.122707:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234844.157186:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234844.159239:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234844.159380:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234844.250713:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234844.312736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 138, "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234844.316148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , !function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==type
[1:1:0711/234844.316340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234844.327447:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234844.512227:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0711/234844.575415:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0711/234844.726601:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/234844.779718:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0711/234844.836259:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0711/234844.853339:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234844.891501:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0711/234844.988294:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0711/234845.311286:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234845.360402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7fe2c6c3a070 0x2ad90e52ae0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234845.361697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , 
(function(){
var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11
[1:1:0711/234845.361854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234845.464430:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/234845.565696:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199, "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234845.566734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.write('<script charset="utf-8" src="http://s6.qhres.com/static/ab77b6ea7f3fbf79.js"></scrip
[1:1:0711/234845.566959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234845.721727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209, "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234845.722523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (function(e){function t(e){var t=location.href,n=t.split("").reverse(),r=e.split(""),i=[];for(var s=
[1:1:0711/234845.722653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234845.753219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209, "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234845.778111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209, "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234846.015614:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234846.016077:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234846.016381:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234846.016858:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234846.017286:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234846.354127:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.620607, 4, 1
[1:1:0711/234846.354303:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234847.046040:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234847.046249:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234847.049496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7fe2c6c3a070 0x2ad90dc43e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234847.051275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , /*! Sea.js 2.2.0 | seajs.org/LICENSE.md */
;!function(a4,a3){function a2(b){return function(a){retur
[1:1:0711/234847.051457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234847.067356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7fe2c6c3a070 0x2ad90dc43e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234847.077823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7fe2c6c3a070 0x2ad90dc43e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234847.353119:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.306735, 66, 1
[1:1:0711/234847.353384:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234847.967751:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234847.968053:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234847.977359:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/234847.982784:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ad90cb4a20
[1:1:0711/234847.983010:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/234848.051438:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.083107, 126, 1
[1:1:0711/234848.051675:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.209347:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.209560:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.217907:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00825882, 90, 1
[1:1:0711/234848.218075:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.295707:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.295933:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.373900:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.077801, 206, 1
[1:1:0711/234848.374190:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.695864:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/234848.696137:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.697317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.700193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , 
	var widgets=(function(){var FP=Function.prototype,AP=Array.prototype,slice=String.prototype.slice,
[1:1:0711/234848.700451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234848.706553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.715713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.876195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.898690:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.902292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.903919:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.906335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.910014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.914764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.919256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7fe2c6c3a070 0x2ad90fd1d60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234848.923633:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234848.931826:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234850.367508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234850.503072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7fe2c8b622e0 0x2ad90fb3260 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234850.513441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (function(){var l;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:
[1:1:0711/234850.513696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[36224:36224:0711/234858.205512:INFO:CONSOLE(56)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://js.passport.qihucdn.com/11.0.1.js?d68c36bbda92ae9db6336213429cb09e, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://sports.pptv.com/article/pg_detail?aid=614035&type=article (56)
[36224:36224:0711/234858.209593:INFO:CONSOLE(56)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://js.passport.qihucdn.com/11.0.1.js?d68c36bbda92ae9db6336213429cb09e, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://sports.pptv.com/article/pg_detail?aid=614035&type=article (56)
[36224:36224:0711/234858.225121:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s6.qhres.com/static/ab77b6ea7f3fbf79.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.passport.qihucdn.com/11.0.1.js?d68c36bbda92ae9db6336213429cb09e (1)
[36224:36224:0711/234858.226161:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s6.qhres.com/static/ab77b6ea7f3fbf79.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://js.passport.qihucdn.com/11.0.1.js?d68c36bbda92ae9db6336213429cb09e (1)
[36224:36224:0711/234858.255338:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[36224:36224:0711/234858.261501:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[36224:36224:0711/234858.275143:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://sports.pptv.com/, http://sports.pptv.com/, 4
[36224:36224:0711/234858.275296:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://sports.pptv.com/, http://sports.pptv.com
[36224:36224:0711/234858.305737:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/234858.311536:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[36224:36224:0711/234858.424409:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0711/234858.471713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x37e5ff3c29c8, 0x2ad90b3d9a8
[1:1:0711/234858.471988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 1000
[1:1:0711/234858.472501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 470
[1:1:0711/234858.472733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7fe2c6c3a070 0x2ad90fd2ee0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 398 0x7fe2c8b622e0 0x2ad90fb3260 
[1:1:0711/234858.954606:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://b.scorecardresearch.com/beacon.js"
[1:1:0711/234859.435072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/234859.435369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234900.791864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7fe2c8b622e0 0x2ad913b64e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.793562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0711/234900.793858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234900.826737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fe2c8b622e0 0x2ad91362b60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.827520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0711/234900.827734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234900.884252:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7fe2c8b622e0 0x2ad90fd45e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.887995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , define("modules/pub/checkin",["lib/jquery/1.8.2/jquery","modules/utils/ajax","modules/utils/user","m
[1:1:0711/234900.888212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234900.910085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.921068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7fe2c8b622e0 0x2ad90dc1be0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.921727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0711/234900.921840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234900.963886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7fe2c8b622e0 0x2ad90fd1f60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234900.965252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , !function(t){function e(n){if(r[n])return r[n].exports;var o=r[n]={i:n,l:!1,exports:{}};return t[n].
[1:1:0711/234900.965399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[36224:36224:0711/234900.995899:INFO:CONSOLE(1)] "sta.js 版本号 >>>>>>>>>> ", source: http://s1.pplive.cn/sta.js?debug=6 (1)
[1:1:0711/234901.012173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x37e5ff3c29c8, 0x2ad90b3d9d8
[1:1:0711/234901.012399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 10000
[1:1:0711/234901.012864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 556
[1:1:0711/234901.013057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7fe2c6c3a070 0x2ad9154aee0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 487 0x7fe2c8b622e0 0x2ad90fd1f60 
[1:1:0711/234901.140809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7fe2c8b622e0 0x2ad91b15f60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234901.146248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (function(){var h={},mt={},c={id:"7adaa440f53512a144c13de93f4c22db",dm:["pptv.com","pplive.com"],js:
[1:1:0711/234901.146465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234901.176067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d988
[1:1:0711/234901.176236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234901.176442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 566
[1:1:0711/234901.176551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7fe2c6c3a070 0x2ad918cace0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 492 0x7fe2c8b622e0 0x2ad91b15f60 
[1:1:0711/234901.434240:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 498 0x7fe2c8b622e0 0x2ad90db86e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234901.435329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , processGoogleToken({"newToken":"NT","validLifetimeSecs":300,"freshLifetimeSecs":300,"1p_jar":"","puc
[1:1:0711/234901.435512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234901.730631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234901.730900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234901.734535:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 470, 7fe2c957f881
[1:1:0711/234901.760713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"398 0x7fe2c8b622e0 0x2ad90fb3260 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234901.761045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"398 0x7fe2c8b622e0 0x2ad90fb3260 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234901.761346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234901.761999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return n.processGoogleToken(d,1)}
[1:1:0711/234901.762176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234903.616852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 566, 7fe2c957f881
[1:1:0711/234903.631670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"492 0x7fe2c8b622e0 0x2ad91b15f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234903.631869:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"492 0x7fe2c8b622e0 0x2ad91b15f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234903.632035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234903.632399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234903.632505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234903.632931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234903.633033:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234903.633259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 647
[1:1:0711/234903.633373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7fe2c6c3a070 0x2ad914eb7e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 566 0x7fe2c6c3a070 0x2ad918cace0 
[1:1:0711/234903.841631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 589 0x7fe2c8b622e0 0x2ad90db8ce0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234903.842888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , _23LPC('CLAnamadDF1OE42zR1WYOQA')
[1:1:0711/234903.843116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234903.974466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234903.974773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.165560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7fe2c8b622e0 0x2ad913a48e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.176610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , var _ssa=_ssa||{};var sa=sa||{};(function(window,document){if(_ssa&&_ssa.loaded){return}var jQuery=w
[1:1:0711/234905.176898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.452086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x37e5ff3c29c8, 0x2ad90b3d988
[1:1:0711/234905.452478:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 1
[1:1:0711/234905.453526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 703
[1:1:0711/234905.453773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7fe2c6c3a070 0x2ad91b575e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 642 0x7fe2c8b622e0 0x2ad913a48e0 
[1:1:0711/234905.581352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.582161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , g.onload, (){g.onload=u;g=window[d]=u;a&&a(b)}
[1:1:0711/234905.582385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.587234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 647, 7fe2c957f881
[1:1:0711/234905.625770:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"566 0x7fe2c6c3a070 0x2ad918cace0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234905.626194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"566 0x7fe2c6c3a070 0x2ad918cace0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234905.626566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.627252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234905.627580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.628534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234905.628736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234905.629190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 714
[1:1:0711/234905.629437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7fe2c6c3a070 0x2ad91d2c6e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 647 0x7fe2c6c3a070 0x2ad914eb7e0 
[1:1:0711/234905.662710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234905.662998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.768402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.769474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){b(c)}
[1:1:0711/234905.769733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.771255:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3da20
[1:1:0711/234905.771495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234905.771986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 723
[1:1:0711/234905.772210:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7fe2c6c3a070 0x2ad9137f360 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 653 0x7fe2d5f4b960 0x2ad919974c0 0x2ad919974d0 
[1:1:0711/234905.990344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.991250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , xhr.onreadystatechange, (){if(xhr.readyState===4){if((xhr.status>=200&&xhr.status<300)||xhr.status==304){success(xhr.respons
[1:1:0711/234905.991523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234905.992544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234905.994989:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234907.058330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 703, 7fe2c957f881
[1:1:0711/234907.097841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"642 0x7fe2c8b622e0 0x2ad913a48e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234907.098215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"642 0x7fe2c8b622e0 0x2ad913a48e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234907.098515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234907.099177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , ready, (){if(!readyFired){readyFired=true;for(var i=0;i<readyList.length;i++){readyList[i].fn.call(window,r
[1:1:0711/234907.099400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234907.965776:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234907.966352:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234908.300690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234908.301082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234908.320253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 714, 7fe2c957f881
[1:1:0711/234908.346537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"647 0x7fe2c6c3a070 0x2ad914eb7e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234908.346836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"647 0x7fe2c6c3a070 0x2ad914eb7e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234908.347203:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234908.347836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234908.348055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234908.348762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234908.348936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234908.349356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 753
[1:1:0711/234908.349539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7fe2c6c3a070 0x2ad91af4160 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 714 0x7fe2c6c3a070 0x2ad91d2c6e0 
[1:1:0711/234908.531262:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 723, 7fe2c957f881
[1:1:0711/234908.563515:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"653 0x7fe2d5f4b960 0x2ad919974c0 0x2ad919974d0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234908.563833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"653 0x7fe2d5f4b960 0x2ad919974c0 0x2ad919974d0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234908.564226:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234908.564824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){a.call(b)}
[1:1:0711/234908.565021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.109373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.109552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.111570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 753, 7fe2c957f881
[1:1:0711/234909.124083:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"714 0x7fe2c6c3a070 0x2ad91d2c6e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.124289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"714 0x7fe2c6c3a070 0x2ad91d2c6e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.124487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.124818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234909.124919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.125266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234909.125363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234909.125554:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 778
[1:1:0711/234909.125658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7fe2c6c3a070 0x2ad91b30be0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 753 0x7fe2c6c3a070 0x2ad91af4160 
[1:1:0711/234909.169778:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.170756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , i.onload.i.onerror, (){window[n]=null;i=null}
[1:1:0711/234909.170994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.302382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 770 0x7fe2c8b622e0 0x2ad913b6de0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.307316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , define("modules/ui/banner/banner",["lib/jquery/1.8.2/jquery","lib/underscore/1.8.3/underscore","modu
[1:1:0711/234909.307611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.409586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.531032:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.531502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , i.onload.i.onerror, (){window[n]=null;i=null}
[1:1:0711/234909.531611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.543149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.543312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.578106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 778, 7fe2c957f881
[1:1:0711/234909.602314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"753 0x7fe2c6c3a070 0x2ad91af4160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.602511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"753 0x7fe2c6c3a070 0x2ad91af4160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.602735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.603149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234909.603259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.603580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234909.603677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234909.603883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 795
[1:1:0711/234909.603989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7fe2c6c3a070 0x2ad91d2c360 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 778 0x7fe2c6c3a070 0x2ad91b30be0 
[1:1:0711/234909.685638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.685872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.768058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.768277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.782006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 795, 7fe2c957f881
[1:1:0711/234909.798612:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"778 0x7fe2c6c3a070 0x2ad91b30be0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.798872:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"778 0x7fe2c6c3a070 0x2ad91b30be0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234909.799164:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234909.799623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234909.799771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.800284:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234909.800423:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234909.800705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 810
[1:1:0711/234909.800860:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7fe2c6c3a070 0x2ad915993e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 795 0x7fe2c6c3a070 0x2ad91d2c360 
[1:1:0711/234909.818829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.819051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.879196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.879371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.971574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234909.971827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234909.988377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 810, 7fe2c957f881
[1:1:0711/234910.008914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"795 0x7fe2c6c3a070 0x2ad91d2c360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.009114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"795 0x7fe2c6c3a070 0x2ad91d2c360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.009338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234910.009659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234910.009775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.010101:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234910.010220:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234910.010437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 823
[1:1:0711/234910.010542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7fe2c6c3a070 0x2ad913524e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 810 0x7fe2c6c3a070 0x2ad915993e0 
[1:1:0711/234910.033916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.034096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.111207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.111459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.222055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 823, 7fe2c957f881
[1:1:0711/234910.256670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"810 0x7fe2c6c3a070 0x2ad915993e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.256978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"810 0x7fe2c6c3a070 0x2ad915993e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.257379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234910.258026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234910.258241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.258988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234910.259145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234910.259610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 834
[1:1:0711/234910.259802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7fe2c6c3a070 0x2ad90fc5be0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 823 0x7fe2c6c3a070 0x2ad913524e0 
[1:1:0711/234910.296079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.296341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.377029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.377241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.391080:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 834, 7fe2c957f881
[1:1:0711/234910.402163:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"823 0x7fe2c6c3a070 0x2ad913524e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.402380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"823 0x7fe2c6c3a070 0x2ad913524e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234910.402577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234910.402893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234910.402998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.403361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234910.403473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234910.403667:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 842
[1:1:0711/234910.403774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7fe2c6c3a070 0x2ad9152c060 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 834 0x7fe2c6c3a070 0x2ad90fc5be0 
[1:1:0711/234910.431437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.431684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.475196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234910.475379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234910.560277:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846 0x7fe2c8b622e0 0x2ad90fb39e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234910.633422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , function load_c(z,y,x,w,v){function u(){load_c.cbs[p]&&v&&v.apply(w,arguments)}var t=document.getEle
[1:1:0711/234910.633603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.055535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3dd28
[1:1:0711/234911.055773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234911.056221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 851
[1:1:0711/234911.056490:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7fe2c6c3a070 0x2ad90fcf1e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 846 0x7fe2c8b622e0 0x2ad90fb39e0 
[1:1:0711/234911.138292:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.247123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234911.247298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.346889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 842, 7fe2c957f881
[1:1:0711/234911.373313:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"834 0x7fe2c6c3a070 0x2ad90fc5be0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.373537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"834 0x7fe2c6c3a070 0x2ad90fc5be0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.373747:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.374076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234911.374196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.374551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234911.374654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234911.374849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 873
[1:1:0711/234911.374955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7fe2c6c3a070 0x2ad91589a60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 842 0x7fe2c6c3a070 0x2ad9152c060 
[1:1:0711/234911.375462:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 556, 7fe2c957f881
[1:1:0711/234911.387303:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"487 0x7fe2c8b622e0 0x2ad90fd1f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.387522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"487 0x7fe2c8b622e0 0x2ad90fd1f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.387722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.388054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){if(window.player){var t=window.player.getPlayer();if(!t)return void(l=setTimeout(a,5e3));try{var 
[1:1:0711/234911.388160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.388522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234911.388626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 10000
[1:1:0711/234911.388817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 874
[1:1:0711/234911.388936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 874 0x7fe2c6c3a070 0x2ad9134a4e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 556 0x7fe2c6c3a070 0x2ad9154aee0 
[1:1:0711/234911.403829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 851, 7fe2c957f881
[1:1:0711/234911.415146:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"846 0x7fe2c8b622e0 0x2ad90fb39e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.415423:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"846 0x7fe2c8b622e0 0x2ad90fb39e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.415633:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.415954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234911.416070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.416481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234911.416581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234911.416790:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 875
[1:1:0711/234911.416893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7fe2c6c3a070 0x2ad91d00e60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 851 0x7fe2c6c3a070 0x2ad90fcf1e0 
[1:1:0711/234911.428689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234911.428858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.618449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 870 0x7fe2c8b622e0 0x2ad90fcbfe0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.619190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , seajs.config({alias:{jquery:"lib/jquery/1.8.2/jquery",raphael:"modules/utils/raphael-min.js",undersc
[1:1:0711/234911.619302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.621512:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.701397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 875, 7fe2c957f881
[1:1:0711/234911.747347:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"851 0x7fe2c6c3a070 0x2ad90fcf1e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.747768:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"851 0x7fe2c6c3a070 0x2ad90fcf1e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.748206:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.749056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234911.749279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.750237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234911.750459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234911.751009:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 888
[1:1:0711/234911.751251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7fe2c6c3a070 0x2ad90dc1e60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 875 0x7fe2c6c3a070 0x2ad91d00e60 
[1:1:0711/234911.753536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 873, 7fe2c957f881
[1:1:0711/234911.793050:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"842 0x7fe2c6c3a070 0x2ad9152c060 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.793354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"842 0x7fe2c6c3a070 0x2ad9152c060 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234911.793848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234911.794527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234911.794720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234911.795487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234911.795648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234911.796075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 891
[1:1:0711/234911.796263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7fe2c6c3a070 0x2ad90dbc660 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 873 0x7fe2c6c3a070 0x2ad91589a60 
[1:1:0711/234911.900100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234911.900280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.220271:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 888, 7fe2c957f881
[1:1:0711/234912.259773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"875 0x7fe2c6c3a070 0x2ad91d00e60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.260088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"875 0x7fe2c6c3a070 0x2ad91d00e60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.260445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234912.261100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234912.261276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.262033:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234912.262193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234912.262773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 907
[1:1:0711/234912.262965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7fe2c6c3a070 0x2ad91599560 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 888 0x7fe2c6c3a070 0x2ad90dc1e60 
[1:1:0711/234912.342881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 891, 7fe2c957f881
[1:1:0711/234912.383021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"873 0x7fe2c6c3a070 0x2ad91589a60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.383329:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"873 0x7fe2c6c3a070 0x2ad91589a60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.383777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234912.384725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234912.384935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.385711:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234912.385873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234912.386307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 909
[1:1:0711/234912.386507:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7fe2c6c3a070 0x2ad913b1860 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 891 0x7fe2c6c3a070 0x2ad90dbc660 
[1:1:0711/234912.425362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234912.425644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.639130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 907, 7fe2c957f881
[1:1:0711/234912.672798:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"888 0x7fe2c6c3a070 0x2ad90dc1e60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.673190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"888 0x7fe2c6c3a070 0x2ad90dc1e60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.673685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234912.674457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234912.674698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.675678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234912.675882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234912.676434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 920
[1:1:0711/234912.676695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7fe2c6c3a070 0x2ad9152c760 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 907 0x7fe2c6c3a070 0x2ad91599560 
[1:1:0711/234912.734810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234912.735040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.736730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 909, 7fe2c957f881
[1:1:0711/234912.748782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"891 0x7fe2c6c3a070 0x2ad90dbc660 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.748960:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"891 0x7fe2c6c3a070 0x2ad90dbc660 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234912.749192:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234912.749554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234912.749701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.750023:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234912.750119:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234912.750312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 925
[1:1:0711/234912.750426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7fe2c6c3a070 0x2ad90dbebe0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 909 0x7fe2c6c3a070 0x2ad913b1860 
[1:1:0711/234912.782232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 917 0x7fe2c8b622e0 0x2ad915431e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234912.783813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , define("lib/jquery/1.8.2/jquery",[],function(require){
/*! jQuery v1.8.2 jquery.com | jquery.org/lic
[1:1:0711/234912.784008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234912.786502:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
		remove user.11_70a5cfc1 -> 0
		remove user.12_2e70ddb1 -> 0
[1:1:0711/234913.345463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 120000
[1:1:0711/234913.345975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 938
[1:1:0711/234913.346174:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7fe2c6c3a070 0x2ad90fcf460 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 917 0x7fe2c8b622e0 0x2ad915431e0 
[1:1:0711/234913.510794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 920, 7fe2c957f881
[1:1:0711/234913.554015:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"907 0x7fe2c6c3a070 0x2ad91599560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234913.554611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"907 0x7fe2c6c3a070 0x2ad91599560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234913.555082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234913.555887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234913.556130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234913.557091:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234913.557293:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234913.557848:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 951
[1:1:0711/234913.558091:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7fe2c6c3a070 0x2ad92dc40e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 920 0x7fe2c6c3a070 0x2ad9152c760 
[1:1:0711/234913.684875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234913.685114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.305751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 925, 7fe2c957f881
[1:1:0711/234914.342586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"909 0x7fe2c6c3a070 0x2ad913b1860 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234914.342901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"909 0x7fe2c6c3a070 0x2ad913b1860 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234914.343246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.343840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234914.344036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.344741:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234914.344913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234914.345337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 967
[1:1:0711/234914.345517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7fe2c6c3a070 0x2ad92a7c4e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 925 0x7fe2c6c3a070 0x2ad90dbebe0 
[1:1:0711/234914.507532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 951, 7fe2c957f881
[1:1:0711/234914.519754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"920 0x7fe2c6c3a070 0x2ad9152c760 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234914.519971:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"920 0x7fe2c6c3a070 0x2ad9152c760 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234914.520190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.520518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234914.520622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.520985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234914.521092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234914.521299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 971
[1:1:0711/234914.521407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7fe2c6c3a070 0x2ad90feca60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 951 0x7fe2c6c3a070 0x2ad92dc40e0 
[1:1:0711/234914.534465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234914.534613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.781399:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 961 0x7fe2c8b622e0 0x2ad92d208e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.782401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , 
var pp = {"chids":[]};
[1:1:0711/234914.782582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.783310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.835169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 962 0x7fe2c8b622e0 0x2ad91363760 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.836180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , 
var recommend = {"recommend":[]};
[1:1:0711/234914.836364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234914.837090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234914.841544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 500
[1:1:0711/234914.842017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 981
[1:1:0711/234914.842224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7fe2c6c3a070 0x2ad92dcc160 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 962 0x7fe2c8b622e0 0x2ad91363760 
[1:1:0711/234915.090574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 967, 7fe2c957f881
[1:1:0711/234915.131965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"925 0x7fe2c6c3a070 0x2ad90dbebe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234915.132291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"925 0x7fe2c6c3a070 0x2ad90dbebe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234915.132662:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234915.133325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234915.133509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234915.134281:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234915.134440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234915.134869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 990
[1:1:0711/234915.135082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 990 0x7fe2c6c3a070 0x2ad92d7bd60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 967 0x7fe2c6c3a070 0x2ad92a7c4e0 
[1:1:0711/234915.176414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234915.176646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234915.180155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 971, 7fe2c957f881
[1:1:0711/234915.219457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"951 0x7fe2c6c3a070 0x2ad92dc40e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234915.219751:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"951 0x7fe2c6c3a070 0x2ad92dc40e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234915.220135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234915.220748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234915.220920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234915.221682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234915.221839:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234915.222348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 993
[1:1:0711/234915.222540:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7fe2c6c3a070 0x2ad92d239e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 971 0x7fe2c6c3a070 0x2ad90feca60 
[1:1:0711/234915.489787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 987 0x7fe2c8b622e0 0x2ad91398360 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234915.507194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , function load_c(z,y,x,w,v){function u(){load_c.cbs[p]&&v&&v.apply(w,arguments)}var t=document.getEle
[1:1:0711/234915.507434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "sports.pptv.com", 3, 1, , , 0
[1:1:0711/234915.576053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234916.221395:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "sports.pptv.com", "pptv.com"
[1:1:0711/234916.237081:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/234916.238079:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/234917.011492:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36224:36224:0711/234917.026563:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234917.029425:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x2ad915b9020
[1:1:0711/234917.029628:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[36224:36224:0711/234917.039327:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[36224:36224:0711/234917.101201:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://sports.pptv.com/, http://sports.pptv.com/, 5
[36224:36224:0711/234917.101378:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://sports.pptv.com/, http://sports.pptv.com
[1:1:0711/234917.199283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 5000
[1:1:0711/234917.200087:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1026
[1:1:0711/234917.200436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7fe2c6c3a070 0x2ad932e3fe0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 987 0x7fe2c8b622e0 0x2ad91398360 
[1:1:0711/234918.421077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x37e5ff3c29c8, 0x2ad90b3da10
[1:1:0711/234918.421239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 500
[1:1:0711/234918.421450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1045
[1:1:0711/234918.421597:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7fe2c6c3a070 0x2ad937a2160 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 987 0x7fe2c8b622e0 0x2ad91398360 
[1:1:0711/234918.657312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234918.657563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234918.661008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 993, 7fe2c957f881
[1:1:0711/234918.702899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"971 0x7fe2c6c3a070 0x2ad90feca60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.703213:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"971 0x7fe2c6c3a070 0x2ad90feca60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.703624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234918.704250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234918.704425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234918.705247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234918.705406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234918.705862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1063
[1:1:0711/234918.706054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1063 0x7fe2c6c3a070 0x2ad91ceb060 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 993 0x7fe2c6c3a070 0x2ad92d239e0 
[1:1:0711/234918.750390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 990, 7fe2c957f881
[1:1:0711/234918.792192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"967 0x7fe2c6c3a070 0x2ad92a7c4e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.792492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"967 0x7fe2c6c3a070 0x2ad92a7c4e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.792931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234918.793557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234918.793765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234918.794673:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234918.794834:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234918.795257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1066
[1:1:0711/234918.795444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1066 0x7fe2c6c3a070 0x2ad91ced3e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 990 0x7fe2c6c3a070 0x2ad92d7bd60 
[1:1:0711/234918.797312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 981, 7fe2c957f8db
[1:1:0711/234918.839101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"962 0x7fe2c8b622e0 0x2ad91363760 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.839404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"962 0x7fe2c8b622e0 0x2ad91363760 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234918.839855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1068
[1:1:0711/234918.840054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7fe2c6c3a070 0x2ad91543fe0 , 5:3_http://sports.pptv.com/, 0, , 981 0x7fe2c6c3a070 0x2ad92dcc160 
[1:1:0711/234918.840396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234918.841092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234918.841271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[36224:36224:0711/234920.264004:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/234922.016432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234922.016755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.231939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1063, 7fe2c957f881
[1:1:0711/234922.271778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"993 0x7fe2c6c3a070 0x2ad92d239e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.272214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"993 0x7fe2c6c3a070 0x2ad92d239e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.272630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.273366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234922.273600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.274408:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234922.274619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234922.275111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1167
[1:1:0711/234922.275446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7fe2c6c3a070 0x2ad935f6160 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1063 0x7fe2c6c3a070 0x2ad91ceb060 
[1:1:0711/234922.325447:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1068, 7fe2c957f8db
[1:1:0711/234922.375943:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"981 0x7fe2c6c3a070 0x2ad92dcc160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.376318:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"981 0x7fe2c6c3a070 0x2ad92dcc160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.376763:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1169
[1:1:0711/234922.376996:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7fe2c6c3a070 0x2ad939581e0 , 5:3_http://sports.pptv.com/, 0, , 1068 0x7fe2c6c3a070 0x2ad91543fe0 
[1:1:0711/234922.377437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.378134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234922.378409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.405011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1072 0x7fe2c8b622e0 0x2ad90e7d660 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.406122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , popbox_1({"error":0,"message":"\u64cd\u4f5c\u6210\u529f","value":null});
[1:1:0711/234922.406397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.407483:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.478324:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1073 0x7fe2c8b622e0 0x2ad935f6fe0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.487107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , commonNavList({"pagenav_www":[],"pagenav_tv":[{"id":"5668907","guid":"d212492b14cf36cdaa313e8020b2f8
[1:1:0711/234922.487487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.504882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.595666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1066, 7fe2c957f881
[1:1:0711/234922.650640:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"990 0x7fe2c6c3a070 0x2ad92d7bd60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.651020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"990 0x7fe2c6c3a070 0x2ad92d7bd60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.651540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.652467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234922.652715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234922.653570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234922.653823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234922.654490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1172
[1:1:0711/234922.654731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7fe2c6c3a070 0x2ad91d722e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1066 0x7fe2c6c3a070 0x2ad91ced3e0 
[1:1:0711/234922.698402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1045, 7fe2c957f881
[1:1:0711/234922.733530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"987 0x7fe2c8b622e0 0x2ad91398360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.733895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"987 0x7fe2c8b622e0 0x2ad91398360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234922.734327:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234922.734995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){for(var f=0,k=d.length;k>f;f++){var h=d[f].vid,g=d[f].playerID;O.prasePPTV(h,g)}}
[1:1:0711/234922.735212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234923.270468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1096 0x7fe2c8b622e0 0x2ad9384bae0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234923.277439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbHotNews({"retCode":"0","retMsg":"成功","data":{"contentList":[{"commentNum":161,"contentCover":"
[1:1:0711/234923.277707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234923.292707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234923.808292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1097 0x7fe2c8b622e0 0x2ad9142b560 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234923.810732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbChannel({"retCode":"0","retMsg":"成功","data":{"channelList":[{"channelId":10000,"channelType":1
[1:1:0711/234923.810961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234923.815459:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234924.222830:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36224:36224:0711/234924.241722:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234924.243920:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x2ad908b3020
[1:1:0711/234924.244167:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[36224:36224:0711/234924.250947:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[36224:36224:0711/234924.290140:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://sports.pptv.com/, http://sports.pptv.com/, 6
[36224:36224:0711/234924.290286:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://sports.pptv.com/, http://sports.pptv.com
[1:1:0711/234924.313663:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36224:36224:0711/234924.348323:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234924.349314:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x2ad908b3a20
[1:1:0711/234924.349592:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[36224:36224:0711/234924.353541:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[36224:36224:0711/234924.391283:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://sports.pptv.com/, http://sports.pptv.com/, 7
[36224:36224:0711/234924.391461:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://sports.pptv.com/, http://sports.pptv.com
[1:1:0711/234924.710044:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1100 0x7fe2c8b622e0 0x2ad90fc0ce0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234924.712713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbSubNav({"retCode":"0","retMsg":"成功","data":{"contentList":[{"id":137,"displayLocationId":7,"im
[1:1:0711/234924.712978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234924.717044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234924.942808:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[36224:36224:0711/234924.971493:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/234924.974028:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x2ad93b15820
[1:1:0711/234924.974312:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[36224:36224:0711/234924.978428:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[36224:36224:0711/234925.009431:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://sports.pptv.com/, http://sports.pptv.com/, 8
[36224:36224:0711/234925.009569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://sports.pptv.com/, http://sports.pptv.com
[1:1:0711/234925.138984:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1101 0x7fe2c8b622e0 0x2ad91554960 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.141035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , tabId_fn({"errors":[],"data":{"list":[{"tabId":1,"tabSportItemId":"1","tabName":"中超","tabMatchId
[1:1:0711/234925.141314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234925.144028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.482778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1106 0x7fe2c8b622e0 0x2ad91d725e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.486298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbNormalInfo({"retCode":"0","retMsg":"成功","data":{"contentList":[{"commentNum":7,"contentCover":
[1:1:0711/234925.486531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234925.493193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.770742:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1107 0x7fe2c8b622e0 0x2ad933372e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.774870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbSpecialInfo({"retCode":"0","retMsg":"成功","data":{"contentList":[{"id":119,"displayLocationId":
[1:1:0711/234925.775130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234925.788317:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.940937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1113 0x7fe2c8b622e0 0x2ad93489ce0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234925.944043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbExclusive({"retCode":"0","retMsg":"成功","data":{"contentList":[{"id":1112,"displayLocationId":5
[1:1:0711/234925.944270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234925.949515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234926.189593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x37e5ff3c29c8, 0x2ad90b3da10
[1:1:0711/234926.189818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 0
[1:1:0711/234926.190275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1275
[1:1:0711/234926.190463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1275 0x7fe2c6c3a070 0x2ad941a1d60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1113 0x7fe2c8b622e0 0x2ad93489ce0 
[1:1:0711/234926.960609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 13
[1:1:0711/234926.960883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1280
[1:1:0711/234926.961075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1280 0x7fe2c6c3a070 0x2ad94793560 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1113 0x7fe2c8b622e0 0x2ad93489ce0 
[1:1:0711/234927.075292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1115 0x7fe2c8b622e0 0x2ad93941f60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234927.076948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , cbFeature({"retCode":"0","retMsg":"成功","data":{"contentList":[{"commentNum":26,"contentCover":"h
[1:1:0711/234927.077128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234927.079768:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234927.325353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1119 0x7fe2c8b622e0 0x2ad92d23360 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234927.325938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , loadAdStatus()
[1:1:0711/234927.326074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234927.326389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.163211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 874, 7fe2c957f881
[1:1:0711/234928.218106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"556 0x7fe2c6c3a070 0x2ad9154aee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.218526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"556 0x7fe2c6c3a070 0x2ad9154aee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.218992:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.219817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){if(window.player){var t=window.player.getPlayer();if(!t)return void(l=setTimeout(a,5e3));try{var 
[1:1:0711/234928.220040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234928.220982:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234928.221202:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 10000
[1:1:0711/234928.221743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1324
[1:1:0711/234928.221979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7fe2c6c3a070 0x2ad9149b360 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 874 0x7fe2c6c3a070 0x2ad9134a4e0 
[1:1:0711/234928.487006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234928.487218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234928.488606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1026, 7fe2c957f8db
[1:1:0711/234928.535401:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"987 0x7fe2c8b622e0 0x2ad91398360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.535807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"987 0x7fe2c8b622e0 0x2ad91398360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.536349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1335
[1:1:0711/234928.536600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7fe2c6c3a070 0x2ad94972ce0 , 5:3_http://sports.pptv.com/, 0, , 1026 0x7fe2c6c3a070 0x2ad932e3fe0 
[1:1:0711/234928.537016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.537785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){aI()==aw&&(f++,f==g.length&&(f=0),aK.attr("value",g[f]),aw=aK.attr("value"))}
[1:1:0711/234928.538006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234928.612979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1167, 7fe2c957f881
[1:1:0711/234928.666879:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1063 0x7fe2c6c3a070 0x2ad91ceb060 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.667179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1063 0x7fe2c6c3a070 0x2ad91ceb060 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.667568:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.668181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234928.668390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234928.669076:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234928.669225:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234928.669648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1339
[1:1:0711/234928.669827:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7fe2c6c3a070 0x2ad9498dee0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1167 0x7fe2c6c3a070 0x2ad935f6160 
[1:1:0711/234928.671927:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1172, 7fe2c957f881
[1:1:0711/234928.725602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1066 0x7fe2c6c3a070 0x2ad91ced3e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.725911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1066 0x7fe2c6c3a070 0x2ad91ced3e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.726322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.726951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234928.727127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234928.727875:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234928.728050:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234928.728515:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1342
[1:1:0711/234928.728706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1342 0x7fe2c6c3a070 0x2ad949950e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1172 0x7fe2c6c3a070 0x2ad91d722e0 
[1:1:0711/234928.808937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1169, 7fe2c957f8db
[1:1:0711/234928.826707:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1068 0x7fe2c6c3a070 0x2ad91543fe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.826878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1068 0x7fe2c6c3a070 0x2ad91543fe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234928.827106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1350
[1:1:0711/234928.827218:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7fe2c6c3a070 0x2ad94995160 , 5:3_http://sports.pptv.com/, 0, , 1169 0x7fe2c6c3a070 0x2ad939581e0 
[1:1:0711/234928.827412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234928.827722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234928.827821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234932.267614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1275, 7fe2c957f881
[1:1:0711/234932.323168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1113 0x7fe2c8b622e0 0x2ad93489ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234932.323488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1113 0x7fe2c8b622e0 0x2ad93489ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234932.323891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234932.324502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){cN=b}
[1:1:0711/234932.324689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234932.326596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1280, 7fe2c957f8db
[1:1:0711/234932.365829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1113 0x7fe2c8b622e0 0x2ad93489ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234932.366056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1113 0x7fe2c8b622e0 0x2ad93489ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234932.366332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1416
[1:1:0711/234932.366450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1416 0x7fe2c6c3a070 0x2ad9499d160 , 5:3_http://sports.pptv.com/, 0, , 1280 0x7fe2c6c3a070 0x2ad94793560 
[1:1:0711/234932.366644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234932.366992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++){a=b[c],!a()&&b[c]===a&&b.splice(c--,1)}b.length||p.fx.s
[1:1:0711/234932.367115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234932.367703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234932.367806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 0
[1:1:0711/234932.368022:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1417
[1:1:0711/234932.368146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7fe2c6c3a070 0x2ad94b42fe0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1280 0x7fe2c6c3a070 0x2ad94793560 
[1:1:0711/234932.947057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234932.947297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234932.951401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1339, 7fe2c957f881
[1:1:0711/234933.011200:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1167 0x7fe2c6c3a070 0x2ad935f6160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.011391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1167 0x7fe2c6c3a070 0x2ad935f6160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.011630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234933.012009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234933.012122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234933.012437:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234933.012533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234933.012723:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1432
[1:1:0711/234933.012830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1432 0x7fe2c6c3a070 0x2ad93636960 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1339 0x7fe2c6c3a070 0x2ad9498dee0 
[1:1:0711/234933.115833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1342, 7fe2c957f881
[1:1:0711/234933.182241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1172 0x7fe2c6c3a070 0x2ad91d722e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.182643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1172 0x7fe2c6c3a070 0x2ad91d722e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.183119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234933.183959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234933.184223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234933.185158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234933.185361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234933.185905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1436
[1:1:0711/234933.186171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1436 0x7fe2c6c3a070 0x2ad94bd0460 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1342 0x7fe2c6c3a070 0x2ad949950e0 
[1:1:0711/234933.188330:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1350, 7fe2c957f8db
[1:1:0711/234933.259110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1169 0x7fe2c6c3a070 0x2ad939581e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.259466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1169 0x7fe2c6c3a070 0x2ad939581e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234933.259983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1438
[1:1:0711/234933.260265:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1438 0x7fe2c6c3a070 0x2ad94bc4360 , 5:3_http://sports.pptv.com/, 0, , 1350 0x7fe2c6c3a070 0x2ad94995160 
[1:1:0711/234933.260664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234933.261483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234933.261708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234934.665199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1387 0x7fe2c8b622e0 0x2ad9474e5e0 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234934.667887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , group_fn,group_fn({"errors":[],"data":{"competitionDesc":"中国足球超级联赛共由16支球队�
[1:1:0711/234934.668103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234934.671970:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234934.914683:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x37e5ff3c29c8, 0x2ad90b3da10
[1:1:0711/234934.914963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 1000
[1:1:0711/234934.915575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1468
[1:1:0711/234934.915823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1468 0x7fe2c6c3a070 0x2ad94b45560 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1387 0x7fe2c8b622e0 0x2ad9474e5e0 
[1:1:0711/234935.963359:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1335, 7fe2c957f8db
[1:1:0711/234936.002778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1026 0x7fe2c6c3a070 0x2ad932e3fe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.003090:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1026 0x7fe2c6c3a070 0x2ad932e3fe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.003582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1498
[1:1:0711/234936.003848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1498 0x7fe2c6c3a070 0x2ad94bdb1e0 , 5:3_http://sports.pptv.com/, 0, , 1335 0x7fe2c6c3a070 0x2ad94972ce0 
[1:1:0711/234936.004223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234936.004883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){aI()==aw&&(f++,f==g.length&&(f=0),aK.attr("value",g[f]),aw=aK.attr("value"))}
[1:1:0711/234936.005098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234936.010768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1417, 7fe2c957f881
[1:1:0711/234936.039754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1280 0x7fe2c6c3a070 0x2ad94793560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.040149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1280 0x7fe2c6c3a070 0x2ad94793560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.040600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234936.041242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){cN=b}
[1:1:0711/234936.041451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234936.575210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234936.575486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234936.653597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1432, 7fe2c957f881
[1:1:0711/234936.690059:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1339 0x7fe2c6c3a070 0x2ad9498dee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.690410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1339 0x7fe2c6c3a070 0x2ad9498dee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.690877:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234936.691646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234936.691872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234936.692653:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234936.692852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234936.693326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1522
[1:1:0711/234936.693550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1522 0x7fe2c6c3a070 0x2ad94d99b60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1432 0x7fe2c6c3a070 0x2ad93636960 
[1:1:0711/234936.694727:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1436, 7fe2c957f881
[1:1:0711/234936.719022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1342 0x7fe2c6c3a070 0x2ad949950e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.719355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1342 0x7fe2c6c3a070 0x2ad949950e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.719852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234936.720508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234936.720761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234936.721550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234936.721765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234936.722343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1523
[1:1:0711/234936.722562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1523 0x7fe2c6c3a070 0x2ad94db53e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1436 0x7fe2c6c3a070 0x2ad94bd0460 
[1:1:0711/234936.724387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1438, 7fe2c957f8db
[1:1:0711/234936.785155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1350 0x7fe2c6c3a070 0x2ad94995160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.785488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1350 0x7fe2c6c3a070 0x2ad94995160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234936.785949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1525
[1:1:0711/234936.786173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1525 0x7fe2c6c3a070 0x2ad9498aae0 , 5:3_http://sports.pptv.com/, 0, , 1438 0x7fe2c6c3a070 0x2ad94bc4360 
[1:1:0711/234936.786511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234936.787147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234936.787351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234938.053626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1468, 7fe2c957f881
[1:1:0711/234938.087093:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1387 0x7fe2c8b622e0 0x2ad9474e5e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234938.087438:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1387 0x7fe2c8b622e0 0x2ad9474e5e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234938.087868:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234938.088554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){p(".scoreList .match_detail").mCustomScrollbar("update"),p(".scoreList .match_detail").mCustomScr
[1:1:0711/234938.088798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234938.977420:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234938.977703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234938.978208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1565
[1:1:0711/234938.978455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1565 0x7fe2c6c3a070 0x2ad94bd0560 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1468 0x7fe2c6c3a070 0x2ad94b45560 
[1:1:0711/234939.052632:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234939.080693:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234939.081285:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234939.081693:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/234939.135047:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234939.135316:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234939.135806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1567
[1:1:0711/234939.136103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1567 0x7fe2c6c3a070 0x2ad94bbfce0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1468 0x7fe2c6c3a070 0x2ad94b45560 
[1:1:0711/234939.530461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1518 0x7fe2c8b622e0 0x2ad94719b60 , "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234939.545738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , function load_c(z,y,x,w,v){function u(){load_c.cbs[p]&&v&&v.apply(w,arguments)}var t=document.getEle
[1:1:0711/234939.546031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234939.584544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234939.954572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234939.954857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234940.019340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1522, 7fe2c957f881
[1:1:0711/234940.079339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1432 0x7fe2c6c3a070 0x2ad93636960 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.079694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1432 0x7fe2c6c3a070 0x2ad93636960 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.080118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234940.080805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234940.081030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234940.081820:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234940.082019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234940.082506:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1583
[1:1:0711/234940.082745:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1583 0x7fe2c6c3a070 0x2ad94b42d60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1522 0x7fe2c6c3a070 0x2ad94d99b60 
[1:1:0711/234940.229818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1523, 7fe2c957f881
[1:1:0711/234940.291342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1436 0x7fe2c6c3a070 0x2ad94bd0460 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.291770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1436 0x7fe2c6c3a070 0x2ad94bd0460 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.292255:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234940.292971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234940.293218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234940.294066:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234940.294305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234940.294806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1588
[1:1:0711/234940.295060:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1588 0x7fe2c6c3a070 0x2ad94baafe0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1523 0x7fe2c6c3a070 0x2ad94db53e0 
[1:1:0711/234940.296838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1525, 7fe2c957f8db
[1:1:0711/234940.368863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1438 0x7fe2c6c3a070 0x2ad94bc4360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.369268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1438 0x7fe2c6c3a070 0x2ad94bc4360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.369998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1590
[1:1:0711/234940.370251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1590 0x7fe2c6c3a070 0x2ad9499d960 , 5:3_http://sports.pptv.com/, 0, , 1525 0x7fe2c6c3a070 0x2ad9498aae0 
[1:1:0711/234940.370602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234940.371332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234940.371553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/234940.767652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1498, 7fe2c957f8db
[1:1:0711/234940.830023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1335 0x7fe2c6c3a070 0x2ad94972ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.830368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1335 0x7fe2c6c3a070 0x2ad94972ce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234940.830870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1599
[1:1:0711/234940.831123:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1599 0x7fe2c6c3a070 0x2ad94dd81e0 , 5:3_http://sports.pptv.com/, 0, , 1498 0x7fe2c6c3a070 0x2ad94bdb1e0 
[1:1:0711/234940.831517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234940.832229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){aI()==aw&&(f++,f==g.length&&(f=0),aK.attr("value",g[f]),aw=aK.attr("value"))}
[1:1:0711/234940.832487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234941.436228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , M, (){y.stop||(B||F.call(),B=aE()-C,L(),B>=y.time&&(y.time=B>y.time?B+H-(B-y.time):B+H-1,y.time<B+1&&(y
[1:1:0711/234941.436529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234941.646187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1324, 7fe2c957f881
[1:1:0711/234941.704335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"874 0x7fe2c6c3a070 0x2ad9134a4e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234941.704714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"874 0x7fe2c6c3a070 0x2ad9134a4e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234941.705111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234941.705806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){if(window.player){var t=window.player.getPlayer();if(!t)return void(l=setTimeout(a,5e3));try{var 
[1:1:0711/234941.706020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234941.706716:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234941.706912:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 10000
[1:1:0711/234941.707382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1621
[1:1:0711/234941.707686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1621 0x7fe2c6c3a070 0x2ad90a05be0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1324 0x7fe2c6c3a070 0x2ad9149b360 
[1:1:0711/234941.766996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1565, 7fe2c957f881
[1:1:0711/234941.808041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1468 0x7fe2c6c3a070 0x2ad94b45560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234941.808387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1468 0x7fe2c6c3a070 0x2ad94b45560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234941.808838:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234941.809521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){a6.event.special.mousewheel?(clearTimeout(h),at.call(d[0])):g()}
[1:1:0711/234941.809753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234942.029019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1567, 7fe2c957f881
[1:1:0711/234942.091078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1468 0x7fe2c6c3a070 0x2ad94b45560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.091434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1468 0x7fe2c6c3a070 0x2ad94b45560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.092009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234942.092739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return g.advanced.updateOnSelectorChange&&(l.poll.change.n=o(),l.poll.change.n!==l.poll.change.o)
[1:1:0711/234942.092956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234942.261750:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234942.262011:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234942.262463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1631
[1:1:0711/234942.262737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1631 0x7fe2c6c3a070 0x2ad94dc5de0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1567 0x7fe2c6c3a070 0x2ad94bbfce0 
[1:1:0711/234942.405278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , document.readyState
[1:1:0711/234942.405571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234942.470780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1583, 7fe2c957f881
[1:1:0711/234942.500385:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1522 0x7fe2c6c3a070 0x2ad94d99b60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.500744:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1522 0x7fe2c6c3a070 0x2ad94d99b60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.501185:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234942.501850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234942.502064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234942.502848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234942.503044:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234942.503507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1636
[1:1:0711/234942.503780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1636 0x7fe2c6c3a070 0x2ad94b75860 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1583 0x7fe2c6c3a070 0x2ad94b42d60 
[1:1:0711/234942.571074:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1588, 7fe2c957f881
[1:1:0711/234942.624842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1523 0x7fe2c6c3a070 0x2ad94db53e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.625177:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1523 0x7fe2c6c3a070 0x2ad94db53e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.625613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234942.626258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234942.626442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234942.627235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234942.627436:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234942.627899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1639
[1:1:0711/234942.628119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1639 0x7fe2c6c3a070 0x2ad94dc7560 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1588 0x7fe2c6c3a070 0x2ad94baafe0 
[1:1:0711/234942.837697:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1590, 7fe2c957f8db
[1:1:0711/234942.900077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1525 0x7fe2c6c3a070 0x2ad9498aae0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.900395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1525 0x7fe2c6c3a070 0x2ad9498aae0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234942.900841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1644
[1:1:0711/234942.901075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1644 0x7fe2c6c3a070 0x2ad94d99360 , 5:3_http://sports.pptv.com/, 0, , 1590 0x7fe2c6c3a070 0x2ad9499d960 
[1:1:0711/234942.901438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234942.902128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234942.902343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234943.698463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , M, (){y.stop||(B||F.call(),B=aE()-C,L(),B>=y.time&&(y.time=B>y.time?B+H-(B-y.time):B+H-1,y.time<B+1&&(y
[1:1:0711/234943.698744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234943.945486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1599, 7fe2c957f8db
[1:1:0711/234943.984583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1498 0x7fe2c6c3a070 0x2ad94bdb1e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234943.984931:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1498 0x7fe2c6c3a070 0x2ad94bdb1e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234943.985354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1667
[1:1:0711/234943.985586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1667 0x7fe2c6c3a070 0x2ad9545a160 , 5:3_http://sports.pptv.com/, 0, , 1599 0x7fe2c6c3a070 0x2ad94dd81e0 
[1:1:0711/234943.985981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234943.986621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){aI()==aw&&(f++,f==g.length&&(f=0),aK.attr("value",g[f]),aw=aK.attr("value"))}
[1:1:0711/234943.986846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[36224:36224:0711/234944.023437:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/234944.056485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1631, 7fe2c957f881
[1:1:0711/234944.082860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1567 0x7fe2c6c3a070 0x2ad94bbfce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.083211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1567 0x7fe2c6c3a070 0x2ad94bbfce0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.083604:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234944.084339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return g.advanced.updateOnSelectorChange&&(l.poll.change.n=o(),l.poll.change.n!==l.poll.change.o)
[1:1:0711/234944.084555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234944.094429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234944.094654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234944.095164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1668
[1:1:0711/234944.095391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1668 0x7fe2c6c3a070 0x2ad95477f60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1631 0x7fe2c6c3a070 0x2ad94dc5de0 
[1:1:0711/234944.096958:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1636, 7fe2c957f881
[1:1:0711/234944.143389:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1583 0x7fe2c6c3a070 0x2ad94b42d60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.143736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1583 0x7fe2c6c3a070 0x2ad94b42d60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.144152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234944.144801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234944.145029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234944.145796:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234944.145999:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234944.146470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1669
[1:1:0711/234944.146706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1669 0x7fe2c6c3a070 0x2ad9546c2e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1636 0x7fe2c6c3a070 0x2ad94b75860 
[1:1:0711/234944.195312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1639, 7fe2c957f881
[1:1:0711/234944.256467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1588 0x7fe2c6c3a070 0x2ad94baafe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.256816:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1588 0x7fe2c6c3a070 0x2ad94baafe0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.257225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234944.257887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234944.258095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234944.258836:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234944.259038:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234944.259493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1675
[1:1:0711/234944.259754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1675 0x7fe2c6c3a070 0x2ad94bc8160 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1639 0x7fe2c6c3a070 0x2ad94dc7560 
[1:1:0711/234944.331737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1644, 7fe2c957f8db
[1:1:0711/234944.389669:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1590 0x7fe2c6c3a070 0x2ad9499d960 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.390040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1590 0x7fe2c6c3a070 0x2ad9499d960 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234944.390503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1678
[1:1:0711/234944.390737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1678 0x7fe2c6c3a070 0x2ad9545abe0 , 5:3_http://sports.pptv.com/, 0, , 1644 0x7fe2c6c3a070 0x2ad94d99360 
[1:1:0711/234944.391114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234944.391786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234944.392074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.006461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1668, 7fe2c957f881
[1:1:0711/234945.032915:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1631 0x7fe2c6c3a070 0x2ad94dc5de0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.033292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1631 0x7fe2c6c3a070 0x2ad94dc5de0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.033720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234945.034439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return g.advanced.updateOnSelectorChange&&(l.poll.change.n=o(),l.poll.change.n!==l.poll.change.o)
[1:1:0711/234945.034654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.044843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234945.045114:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234945.045738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1698
[1:1:0711/234945.045969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1698 0x7fe2c6c3a070 0x2ad94db4ee0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1668 0x7fe2c6c3a070 0x2ad95477f60 
[1:1:0711/234945.047662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1669, 7fe2c957f881
[1:1:0711/234945.097904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1636 0x7fe2c6c3a070 0x2ad94b75860 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.098290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1636 0x7fe2c6c3a070 0x2ad94b75860 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.098719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234945.099389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234945.099631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.100405:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234945.100620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234945.101111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1699
[1:1:0711/234945.101352:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1699 0x7fe2c6c3a070 0x2ad95477060 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1669 0x7fe2c6c3a070 0x2ad9546c2e0 
[1:1:0711/234945.103214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1675, 7fe2c957f881
[1:1:0711/234945.154766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1639 0x7fe2c6c3a070 0x2ad94dc7560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.155145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1639 0x7fe2c6c3a070 0x2ad94dc7560 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.155573:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234945.156299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234945.156516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.157312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234945.157507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234945.157978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1702
[1:1:0711/234945.158243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1702 0x7fe2c6c3a070 0x2ad94dd2e60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1675 0x7fe2c6c3a070 0x2ad94bc8160 
[1:1:0711/234945.812056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1678, 7fe2c957f8db
[1:1:0711/234945.892345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1644 0x7fe2c6c3a070 0x2ad94d99360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.892694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1644 0x7fe2c6c3a070 0x2ad94d99360 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.893126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://sports.pptv.com/, 1724
[1:1:0711/234945.893381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1724 0x7fe2c6c3a070 0x2ad954c78e0 , 5:3_http://sports.pptv.com/, 0, , 1678 0x7fe2c6c3a070 0x2ad9545abe0 
[1:1:0711/234945.893787:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234945.894486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){try{for(var k,q,p="",o=0,n=d.length;n>o;o++){k=d[o].start.replace(/-/gi,"/"),d[o].time&&(p=d[o].t
[1:1:0711/234945.894715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.896456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1698, 7fe2c957f881
[1:1:0711/234945.941860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1668 0x7fe2c6c3a070 0x2ad95477f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.942242:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1668 0x7fe2c6c3a070 0x2ad95477f60 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234945.942639:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234945.943541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return g.advanced.updateOnSelectorChange&&(l.poll.change.n=o(),l.poll.change.n!==l.poll.change.o)
[1:1:0711/234945.943820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234945.950126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234945.950363:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234945.950859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1726
[1:1:0711/234945.951103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1726 0x7fe2c6c3a070 0x2ad94c8c3e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1698 0x7fe2c6c3a070 0x2ad94db4ee0 
[1:1:0711/234946.011380:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1699, 7fe2c957f881
[1:1:0711/234946.052076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1669 0x7fe2c6c3a070 0x2ad9546c2e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.052527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1669 0x7fe2c6c3a070 0x2ad9546c2e0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.052939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234946.053634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , m, (){/in/.test(b.readyState)?setTimeout(m,9):a6.eve("raphael.DOMload")}
[1:1:0711/234946.053868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234946.054746:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 9, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234946.054985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 9
[1:1:0711/234946.055501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1728
[1:1:0711/234946.055775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1728 0x7fe2c6c3a070 0x2ad914806e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1699 0x7fe2c6c3a070 0x2ad95477060 
[1:1:0711/234946.129552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1702, 7fe2c957f881
[1:1:0711/234946.199998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1675 0x7fe2c6c3a070 0x2ad94bc8160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.200521:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1675 0x7fe2c6c3a070 0x2ad94bc8160 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.200944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234946.201667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0711/234946.201912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234946.202729:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234946.202935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 100
[1:1:0711/234946.203443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1733
[1:1:0711/234946.203673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1733 0x7fe2c6c3a070 0x2ad94238d60 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1702 0x7fe2c6c3a070 0x2ad94dd2e60 
context mismatch in svga_sampler_view_destroy
[1:1:0711/234946.747879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1726, 7fe2c957f881
[1:1:0711/234946.785817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1cc79d3e2860","ptid":"1698 0x7fe2c6c3a070 0x2ad94db4ee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.786174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://sports.pptv.com/","ptid":"1698 0x7fe2c6c3a070 0x2ad94db4ee0 ","rf":"5:3_http://sports.pptv.com/"}
[1:1:0711/234946.786606:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article"
[1:1:0711/234946.787320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://sports.pptv.com/, 1cc79d3e2860, , , (){return g.advanced.updateOnSelectorChange&&(l.poll.change.n=o(),l.poll.change.n!==l.poll.change.o)
[1:1:0711/234946.787539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", "pptv.com", 3, 1, , , 0
[1:1:0711/234946.792123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x37e5ff3c29c8, 0x2ad90b3d950
[1:1:0711/234946.792385:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://sports.pptv.com/article/pg_detail?aid=614035&type=article", 60
[1:1:0711/234946.792869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1747
[1:1:0711/234946.793097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1747 0x7fe2c6c3a070 0x2ad94b449e0 , 5:3_http://sports.pptv.com/, 1, -5:3_http://sports.pptv.com/, 1726 0x7fe2c6c3a070 0x2ad94c8c3e0 
[1:1:0100/000000.869654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://sports.pptv.com/, 1728, 7fe2c957f881
