[0711/222607.125301:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222607.125673:INFO:switcher_clone.cc(787)] backtrace rip is 7fa257118891
[0711/222608.336101:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222608.336468:INFO:switcher_clone.cc(787)] backtrace rip is 7f0a68383891
[1:1:0711/222608.348198:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/222608.348453:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/222608.355482:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[25608:25608:0711/222609.391021:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/5141c44a-8863-4268-9a8b-149207c5061d
[0711/222609.812906:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/222609.813420:INFO:switcher_clone.cc(787)] backtrace rip is 7fc494504891
[25608:25608:0711/222609.926978:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[25608:25638:0711/222609.927766:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/222609.928015:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/222609.928291:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/222609.928897:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/222609.929144:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/222609.931951:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b54f183, 1
[1:1:0711/222609.932336:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2ea5f6e7, 0
[1:1:0711/222609.932528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x94972b7, 3
[1:1:0711/222609.932750:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3560fd81, 2
[1:1:0711/222609.933017:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe7fffffff6ffffffa52e ffffff83fffffff1541b ffffff81fffffffd6035 ffffffb7724909 , 10104, 4
[1:1:0711/222609.934000:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25608:25638:0711/222609.934259:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���.��T��`5�rI	(+1
[25608:25638:0711/222609.934326:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���.��T��`5�rI	/(+1
[1:1:0711/222609.934256:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a665be0a0, 3
[25608:25638:0711/222609.934616:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/222609.934571:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a66749080, 2
[25608:25638:0711/222609.934685:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25653, 4, e7f6a52e 83f1541b 81fd6035 b7724909 
[1:1:0711/222609.934731:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a5040cd20, -2
[1:1:0711/222609.944322:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/222609.944908:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3560fd81
[1:1:0711/222609.945577:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3560fd81
[1:1:0711/222609.946577:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3560fd81
[1:1:0711/222609.947146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.947253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.947340:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.947429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.947649:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3560fd81
[1:1:0711/222609.947780:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a683837ba
[1:1:0711/222609.947853:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a6837adef, 7f0a6838377a, 7f0a683850cf
[1:1:0711/222609.949351:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3560fd81
[1:1:0711/222609.949511:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3560fd81
[1:1:0711/222609.949773:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3560fd81
[1:1:0711/222609.950458:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.950569:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.950661:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.950755:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3560fd81
[1:1:0711/222609.951220:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3560fd81
[1:1:0711/222609.951379:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a683837ba
[1:1:0711/222609.951450:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a6837adef, 7f0a6838377a, 7f0a683850cf
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0711/222609.953665:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/222609.953998:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/222609.954086:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe7011c008, 0x7ffe7011bf88)
[1:1:0711/222609.968494:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/222609.974463:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[25640:25640:0711/222610.025912:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25640
[25662:25662:0711/222610.029142:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25662
[25608:25630:0711/222610.608688:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/222610.636923:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x192fc4f68220
[1:1:0711/222610.639658:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[25608:25608:0711/222610.682889:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25608:25608:0711/222610.684323:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25608:25619:0711/222610.703137:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[25608:25619:0711/222610.703283:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[25608:25608:0711/222610.703495:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[25608:25608:0711/222610.703596:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[25608:25608:0711/222610.703768:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,25653, 4
[1:7:0711/222610.705964:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222611.139488:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[25608:25608:0711/222612.738113:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[25608:25608:0711/222612.738233:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/222612.783536:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222612.787039:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222613.608178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/222613.608503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222613.629072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/222613.629280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222613.675427:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222613.823934:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222613.824198:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222614.091865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222614.098356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/222614.098639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222614.151457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222614.158337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/222614.158596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222614.170217:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[25608:25608:0711/222614.173419:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/222614.173807:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x192fc4f66e20
[1:1:0711/222614.174056:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[25608:25608:0711/222614.181966:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[25608:25608:0711/222614.218028:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[25608:25608:0711/222614.218251:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/222614.284446:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222615.129374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f0a51fe72e0 0x192fc50e4ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222615.130736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/222615.130985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222615.132536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25608:25608:0711/222615.199392:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/222615.201584:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x192fc4f67820
[1:1:0711/222615.201818:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[25608:25608:0711/222615.206314:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/222615.220027:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/222615.220328:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[25608:25608:0711/222615.225765:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[25608:25608:0711/222615.238611:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25608:25608:0711/222615.239879:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25608:25619:0711/222615.247376:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[25608:25619:0711/222615.247458:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[25608:25608:0711/222615.247713:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[25608:25608:0711/222615.247807:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[25608:25608:0711/222615.247979:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,25653, 4
[1:7:0711/222615.250351:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222615.766209:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/222616.399755:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f0a51fe72e0 0x192fc52562e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222616.400799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/222616.401028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/222616.401776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25608:25608:0711/222616.452871:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[25608:25608:0711/222616.452990:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/222616.497052:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222616.825144:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[25608:25608:0711/222616.999057:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[25608:25638:0711/222616.999486:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/222616.999734:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/222616.999976:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/222617.000365:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/222617.000540:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/222617.003614:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe62d898, 1
[1:1:0711/222617.004054:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xcc612b1, 0
[1:1:0711/222617.004205:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1b3d0826, 3
[1:1:0711/222617.004348:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3f65bebe, 2
[1:1:0711/222617.004490:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb112ffffffc60c ffffff98ffffffd8620e ffffffbeffffffbe653f 26083d1b , 10104, 5
[1:1:0711/222617.005284:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25608:25638:0711/222617.005434:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����b��e?&=# +1
[25608:25638:0711/222617.005471:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����b��e?&=�# +1
[1:1:0711/222617.005540:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a665be0a0, 3
[1:1:0711/222617.005650:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a66749080, 2
[25608:25638:0711/222617.005722:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25705, 5, b112c60c 98d8620e bebe653f 26083d1b 
[1:1:0711/222617.005775:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0a5040cd20, -2
[1:1:0711/222617.016201:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/222617.016415:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f65bebe
[1:1:0711/222617.016589:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f65bebe
[1:1:0711/222617.016866:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f65bebe
[1:1:0711/222617.017304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.017412:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.017501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.017588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.017844:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f65bebe
[1:1:0711/222617.017980:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a683837ba
[1:1:0711/222617.018053:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a6837adef, 7f0a6838377a, 7f0a683850cf
[1:1:0711/222617.019502:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f65bebe
[1:1:0711/222617.019659:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f65bebe
[1:1:0711/222617.019951:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f65bebe
[1:1:0711/222617.020609:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.020743:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.020844:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.020936:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f65bebe
[1:1:0711/222617.021360:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f65bebe
[1:1:0711/222617.021508:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0a683837ba
[1:1:0711/222617.021580:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0a6837adef, 7f0a6838377a, 7f0a683850cf
[1:1:0711/222617.024551:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/222617.025235:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/222617.025416:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe7011c008, 0x7ffe7011bf88)
[1:1:0711/222617.041929:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/222617.047096:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/222617.223351:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x192fc4f2d220
[1:1:0711/222617.223507:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/222617.401056:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222617.401328:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222617.910705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222617.916080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1baa40bce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/222617.916370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/222617.925106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25608:25608:0711/222618.023842:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25608:25608:0711/222618.031000:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25608:25619:0711/222618.060392:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[25608:25619:0711/222618.060494:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[25608:25608:0711/222618.060878:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://coupon.yhd.com/
[25608:25608:0711/222618.060979:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://coupon.yhd.com/, https://coupon.yhd.com/couponCenter/home, 1
[25608:25608:0711/222618.061112:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://coupon.yhd.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 05:26:17 GMT content-type:text/html;charset=UTF-8 vary:Accept-Encoding set-cookie:JSESSIONID=A779EBCF96CF7AABC47C6E22449DFE67.s1; Path=/; HttpOnly set-cookie:GUID=8Y87JD1TPJ6TD9GZKRS8JE3ZDJE6BZBD3U2B; Path=/ p3p:CP="NOI DEVa TAIa OUR BUS UNI" content-language:zh-CN expires:Fri, 12 Jul 2019 05:26:18 GMT cache-control:max-age=0 content-encoding:gzip server:jfe  ,25705, 5
[1:7:0711/222618.064419:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/222618.098999:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://coupon.yhd.com/
[1:1:0711/222618.109694:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/222618.110421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1baa40aa1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/222618.110644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[25608:25608:0711/222618.252313:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://coupon.yhd.com/, https://coupon.yhd.com/, 1
[25608:25608:0711/222618.252414:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://coupon.yhd.com/, https://coupon.yhd.com
[1:1:0711/222618.304022:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222618.403953:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222618.425787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222618.427413:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/222618.427653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1baa40bce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/222618.427913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/222618.468660:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/222618.546569:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222618.546835:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222618.576603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/222618.588929:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/222618.589159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1baa40bce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/222618.589436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/222620.064711:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.065337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.065732:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.066106:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.066503:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.464013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f0a500bf070 0x192fc50590e0 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222620.468104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , 
var URLPrefix = {"shop":"//shop.yhd.com","busystock":"//gps.yhd.com","cms":"//cms.yhd.com","img":"/
[1:1:0711/222620.468337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222620.470251:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222620.540479:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0659041, 207, 1
[1:1:0711/222620.540791:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222620.950915:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222620.951183:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222620.952116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7f0a500bf070 0x192fc5184760 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222620.953786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , 
    var jaq = jaq || [];
    jaq.push(['account', 'JA2017_111805']); //站点编号
    jaq.push(['
[1:1:0711/222620.954007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222621.137421:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.186138, 991, 1
[1:1:0711/222621.137739:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222621.744966:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222621.789102:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222621.789393:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222621.793151:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7f0a500bf070 0x192fc528ece0 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222621.798021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromChar
[1:1:0711/222621.798292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222623.129354:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:2:0711/222623.240339:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[25608:25608:0711/222629.751991:INFO:CONSOLE(392)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/47016/20/3825/51508/5d19d1c6E1c4c682e/40272ab73c51bba0.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (392)
[25608:25608:0711/222629.753450:INFO:CONSOLE(444)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/71485/27/1785/177016/5d00c913E4ca64068/394c5d099020ed89.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (444)
[25608:25608:0711/222629.755065:INFO:CONSOLE(496)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/66565/24/1069/359557/5cf48a2bEe861f47b/97fb0f16ff0e9276.png'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (496)
[25608:25608:0711/222629.756324:INFO:CONSOLE(548)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/59558/19/1693/206236/5d00c521E5c2d4fe6/dad4f2f9a9f2c41b.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (548)
[25608:25608:0711/222629.757625:INFO:CONSOLE(600)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/75067/30/3301/14335/5d19d104E56118343/577b9fd29221eb7b.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (600)
[25608:25608:0711/222629.758911:INFO:CONSOLE(652)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/46721/30/3880/26959/5d19d133E5aa2bbd1/431c8896e5596ae6.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (652)
[25608:25608:0711/222629.760178:INFO:CONSOLE(704)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/82981/10/3346/35416/5d19d16dE32f8eb07/6e74fda3a69a656c.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (704)
[25608:25608:0711/222629.761511:INFO:CONSOLE(756)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/39119/13/10355/13966/5d19d19fE5b9a6b51/fca72a95b293d243.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (756)
[25608:25608:0711/222629.762776:INFO:CONSOLE(808)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/56207/36/3908/32489/5d19d295Eacf8ecdf/1612f18c1a5c1edb.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (808)
[25608:25608:0711/222629.764029:INFO:CONSOLE(860)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/42158/1/8136/18544/5d19d32eEfc556f5c/4de96e12a13cc869.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (860)
[25608:25608:0711/222629.766035:INFO:CONSOLE(912)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/57962/28/3915/15955/5d19d3adE8fd4b7e4/b635053822aee163.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (912)
[25608:25608:0711/222629.767673:INFO:CONSOLE(964)] "Mixed Content: The page at 'https://coupon.yhd.com/couponCenter/home' was loaded over HTTPS, but requested an insecure image 'http://img10.360buyimg.com/n3/jfs/t1/38792/33/10361/19476/5d19d3e8E6ad94839/7c4e9ff266f9484a.jpg'. This content should also be served over HTTPS.", source: https://coupon.yhd.com/couponCenter/home (964)
[3:3:0711/222629.812133:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/222629.890506:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x26e3f22229c8, 0x192fc4da89a8
[1:1:0711/222629.894602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 30
[1:1:0711/222629.895082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 376
[1:1:0711/222629.895382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 376 0x7f0a500bf070 0x192fc5c155e0 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 295 0x7f0a500bf070 0x192fc528ece0 
[25608:25608:0711/222630.729751:INFO:CONSOLE(1)] "The AudioContext was not allowed to start. It must be resume (or created) after a user gesture on the page. https://goo.gl/7K7WLu", source:  (1)
[25608:25608:0711/222631.650842:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/222640.389098:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222640.389621:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222640.389963:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222643.426011:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222643.426545:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222649.518592:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222649.518956:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/222649.520011:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:25:0711/222649.525706:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0711/222649.555997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x26e3f22229c8, 0x192fc4da89a8
[1:1:0711/222649.556267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 500
[1:1:0711/222649.556748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 394
[1:1:0711/222649.556968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7f0a500bf070 0x192fc9a18de0 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 295 0x7f0a500bf070 0x192fc528ece0 
[1:1:0711/222649.557627:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x26e3f22229c8, 0x192fc4da89a8
[1:1:0711/222649.557786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 100
[1:1:0711/222649.558136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 395
[1:1:0711/222649.558322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f0a500bf070 0x192fc99d6160 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 295 0x7f0a500bf070 0x192fc528ece0 
[1:1:0711/222649.560351:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 27.7708, 0, 0
[1:1:0711/222649.560568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222650.022007:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 337 0x7f0a51fe72e0 0x192fc51832e0 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222650.027941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , /* 2019-07-09 13:52:03 joya.js @issue to lijiwen@jd.com Thanks */
try{window.fingerprint={},function
[1:1:0711/222650.028176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
		remove user.13_782a5ef -> 0
		remove user.14_9acd6a2d -> 0
		remove user.15_fac208cd -> 0
		remove user.16_17c009ed -> 0
		remove user.17_35fea421 -> 0
		remove user.18_8a8b75f3 -> 0
		remove user.19_355c1a77 -> 0
		remove user.1a_120d7689 -> 0
		remove user.1b_ee00cebd -> 0
		remove user.1c_8398dcf6 -> 0
[1:27:0711/222651.564322:WARNING:paced_sender.cc(261)] Elapsed time (2009 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222652.067420:WARNING:paced_sender.cc(261)] Elapsed time (2512 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222652.569560:WARNING:paced_sender.cc(261)] Elapsed time (3014 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222653.071664:WARNING:paced_sender.cc(261)] Elapsed time (3516 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222653.573796:WARNING:paced_sender.cc(261)] Elapsed time (4018 ms) longer than expected, limiting to 2000 ms
[25608:25608:0711/222653.636009:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:27:0711/222654.075172:WARNING:paced_sender.cc(261)] Elapsed time (4519 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222654.575121:WARNING:paced_sender.cc(261)] Elapsed time (5019 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222655.077173:WARNING:paced_sender.cc(261)] Elapsed time (5521 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222655.579296:WARNING:paced_sender.cc(261)] Elapsed time (6024 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222656.042852:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7f0a51fe72e0 0x192fc4b3ce60 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222656.054071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , var a=['GungsuhChe','Gurmukhi\x20MN','Harrington','Heather','Heiti\x20SC','Heiti\x20TC','High\x20Tow
[1:1:0711/222656.054402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0711/222656.082391:WARNING:paced_sender.cc(261)] Elapsed time (6527 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222656.583594:WARNING:paced_sender.cc(261)] Elapsed time (7028 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222657.083668:WARNING:paced_sender.cc(261)] Elapsed time (7528 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222657.585755:WARNING:paced_sender.cc(261)] Elapsed time (8030 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222658.087873:WARNING:paced_sender.cc(261)] Elapsed time (8532 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222658.590001:WARNING:paced_sender.cc(261)] Elapsed time (9034 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222659.090407:WARNING:paced_sender.cc(261)] Elapsed time (9535 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222659.593238:WARNING:paced_sender.cc(261)] Elapsed time (10038 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222700.095683:WARNING:paced_sender.cc(261)] Elapsed time (10540 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222700.598476:WARNING:paced_sender.cc(261)] Elapsed time (11043 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222701.100601:WARNING:paced_sender.cc(261)] Elapsed time (11545 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222701.602753:WARNING:paced_sender.cc(261)] Elapsed time (12047 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222702.104895:WARNING:paced_sender.cc(261)] Elapsed time (12549 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222702.606958:WARNING:paced_sender.cc(261)] Elapsed time (13051 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222703.109087:WARNING:paced_sender.cc(261)] Elapsed time (13553 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222703.611215:WARNING:paced_sender.cc(261)] Elapsed time (14056 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222704.113337:WARNING:paced_sender.cc(261)] Elapsed time (14558 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222704.616454:WARNING:paced_sender.cc(261)] Elapsed time (15061 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222705.118575:WARNING:paced_sender.cc(261)] Elapsed time (15563 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222705.620690:WARNING:paced_sender.cc(261)] Elapsed time (16065 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222706.121447:WARNING:paced_sender.cc(261)] Elapsed time (16566 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222706.623928:WARNING:paced_sender.cc(261)] Elapsed time (17068 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222707.126063:WARNING:paced_sender.cc(261)] Elapsed time (17570 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222707.627174:WARNING:paced_sender.cc(261)] Elapsed time (18071 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222708.129333:WARNING:paced_sender.cc(261)] Elapsed time (18574 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222708.631438:WARNING:paced_sender.cc(261)] Elapsed time (19076 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222709.133542:WARNING:paced_sender.cc(261)] Elapsed time (19578 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222709.635684:WARNING:paced_sender.cc(261)] Elapsed time (20080 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222710.137786:WARNING:paced_sender.cc(261)] Elapsed time (20582 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222710.639937:WARNING:paced_sender.cc(261)] Elapsed time (21084 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222711.141037:WARNING:paced_sender.cc(261)] Elapsed time (21585 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222711.642293:WARNING:paced_sender.cc(261)] Elapsed time (22087 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222712.145280:WARNING:paced_sender.cc(261)] Elapsed time (22590 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222712.648403:WARNING:paced_sender.cc(261)] Elapsed time (23093 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222713.151534:WARNING:paced_sender.cc(261)] Elapsed time (23596 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222713.653644:WARNING:paced_sender.cc(261)] Elapsed time (24098 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222714.155787:WARNING:paced_sender.cc(261)] Elapsed time (24600 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222714.656227:WARNING:paced_sender.cc(261)] Elapsed time (25100 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222715.158990:WARNING:paced_sender.cc(261)] Elapsed time (25603 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222715.647832:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://coupon.yhd.com/couponCenter/home"
[1:27:0711/222715.661145:WARNING:paced_sender.cc(261)] Elapsed time (26105 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222715.890736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/222715.891057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0711/222716.162238:WARNING:paced_sender.cc(261)] Elapsed time (26607 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222716.536458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , (a){a.executeSql("SELECT value FROM cache WHERE name=?",[d],function(a,c){1<=c.rows.length?q._ec.dbD
[1:1:0711/222716.536802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0711/222716.663280:WARNING:paced_sender.cc(261)] Elapsed time (27108 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222716.738812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , (d){k.setLocalDescription(d,function(){},function(){})}
[1:1:0711/222716.739097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222716.757568:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/222716.757802:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222716.764888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f0a500bf070 0x192fc99d6be0 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222716.765968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , 
        try{
		getJdEid(function(eid,fp,udfp){
		        //alert("eid="+eid+"   fp="+fp+" token="+u
[1:1:0711/222716.766208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222716.766973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x26e3f22229c8, 0x192fc4da89a0
[1:1:0711/222716.767175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 15
[1:1:0711/222716.767610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 536
[1:1:0711/222716.767924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 536 0x7f0a500bf070 0x192fc528ebe0 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 396 0x7f0a500bf070 0x192fc99d6be0 
[1:1:0711/222716.804933:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.04703, 173, 1
[1:1:0711/222716.805221:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/222716.916565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7f0a51fe72e0 0x192fc851ffe0 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222716.917667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , var jd_risk_token_id='MEAUTVYLFWLKJLJGBVHIHOR3KWPVNLGPMHPJAOIVGPOIGSHYIZ7RRZPUMLZZGEMCAOYFTO5PLEZ7C'
[1:1:0711/222716.917922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222716.979472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 376, 7f0a52a04881
[1:1:0711/222717.008988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b5010ba2860","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.009346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://coupon.yhd.com/","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.009816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222717.010423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , (){q._jdtdstorage(n,e,a,c,b)}
[1:1:0711/222717.010676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222717.012136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x26e3f22229c8, 0x192fc4da8958
[1:1:0711/222717.012351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 30
[1:1:0711/222717.012804:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 556
[1:1:0711/222717.013074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7f0a500bf070 0x192fd6c836e0 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 376 0x7f0a500bf070 0x192fc5c155e0 
[1:1:0711/222717.040036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 395, 7f0a52a04881
[1:1:0711/222717.064665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b5010ba2860","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.065015:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://coupon.yhd.com/","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.065550:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222717.066235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , td_collect_exe, (){!function(){var f=_JdJrTdRiskFp.getData();!function(f,r,u){_JdJrRiskClientStorage.get("3AB9D23F7A
[1:1:0711/222717.066499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222717.095861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x26e3f22229c8, 0x192fc4da8958
[1:1:0711/222717.096263:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://coupon.yhd.com/couponCenter/home", 30
[1:1:0711/222717.096819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 558
[1:1:0711/222717.097088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7f0a500bf070 0x192fd6f582e0 , 5:3_https://coupon.yhd.com/, 1, -5:3_https://coupon.yhd.com/, 395 0x7f0a500bf070 0x192fc99d6160 
[1:27:0711/222717.165488:WARNING:paced_sender.cc(261)] Elapsed time (27610 ms) longer than expected, limiting to 2000 ms
[25608:25608:0711/222717.522017:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/222717.640692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://coupon.yhd.com/, 394, 7f0a52a04881
[1:1:0711/222717.665311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2b5010ba2860","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.665696:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://coupon.yhd.com/","ptid":"295 0x7f0a500bf070 0x192fc528ece0 ","rf":"5:3_https://coupon.yhd.com/"}
[1:1:0711/222717.666226:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://coupon.yhd.com/couponCenter/home"
[1:27:0711/222717.666755:WARNING:paced_sender.cc(261)] Elapsed time (28111 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222717.666857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , (){try{k.localDescription.sdp.split("\n").forEach(function(d){0===d.indexOf("a=candidate:")&&e(d)})}
[1:1:0711/222717.667065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0711/222718.168728:WARNING:paced_sender.cc(261)] Elapsed time (28613 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222718.670849:WARNING:paced_sender.cc(261)] Elapsed time (29115 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222719.172959:WARNING:paced_sender.cc(261)] Elapsed time (29617 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222719.204752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 506 0x7f0a51fe72e0 0x192fd6ce1e60 , "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222719.208953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , var _0xa88f=["\x6D\x6C\x6F\x67\x69\x6E","\x6D\x72\x65\x67\x69\x73\x74\x65\x72","\x62\x65\x61\x6E\x47
[1:1:0711/222719.209198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222719.243291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "upgradeneeded", "https://coupon.yhd.com/couponCenter/home"
[1:1:0711/222719.244713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , c.onupgradeneeded, (){c.result.createObjectStore("jdtdstorage",{keyPath:"name"})}
[1:1:0711/222719.244995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0711/222719.272717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , document.readyState
[1:1:0711/222719.273025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0711/222719.673099:WARNING:paced_sender.cc(261)] Elapsed time (30117 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222720.175238:WARNING:paced_sender.cc(261)] Elapsed time (30620 ms) longer than expected, limiting to 2000 ms
[1:27:0711/222720.677336:WARNING:paced_sender.cc(261)] Elapsed time (31122 ms) longer than expected, limiting to 2000 ms
[1:1:0711/222720.796105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , , (a,c){}
[1:1:0711/222720.796440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:27:0100/000000.179522:WARNING:paced_sender.cc(261)] Elapsed time (31624 ms) longer than expected, limiting to 2000 ms
[1:1:0100/000000.176875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://coupon.yhd.com/couponCenter/home"
[1:1:0100/000000.180375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://coupon.yhd.com/, 2b5010ba2860, , eE.(anonymous function), (){if(eE[b('0x33a')]==0x4&&eE[b('0x33b')]==0xc8){var eF=em[b('0x328')](eE['responseText']);backfp=eF
[1:1:0100/000000.180616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://coupon.yhd.com/couponCenter/home", "coupon.yhd.com", 3, 1, , , 0
[1:1:0100/000000.182016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://coupon.yhd.com/couponCenter/home"
[1:1:0100/000000.185627:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://coupon.yhd.com/couponCenter/home"
