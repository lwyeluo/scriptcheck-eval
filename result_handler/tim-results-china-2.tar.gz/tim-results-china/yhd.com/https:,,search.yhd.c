[0711/223107.155323:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223107.155738:INFO:switcher_clone.cc(787)] backtrace rip is 7f7483378891
[0711/223108.191732:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223108.192108:INFO:switcher_clone.cc(787)] backtrace rip is 7f6715ead891
[1:1:0711/223108.203877:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/223108.204127:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/223108.208271:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26134:26134:0711/223109.407960:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0b681d6c-db49-4325-b930-a2709ef81643
[0711/223109.578221:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/223109.578718:INFO:switcher_clone.cc(787)] backtrace rip is 7f25424f5891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26168:26168:0711/223109.809000:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26168
[26179:26179:0711/223109.809443:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26179
[26134:26134:0711/223109.874385:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26134:26164:0711/223109.875215:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/223109.875441:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223109.875749:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223109.876332:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223109.876493:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/223109.879394:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb8c3eb8, 1
[1:1:0711/223109.879837:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1154ef30, 0
[1:1:0711/223109.879996:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x24f71774, 3
[1:1:0711/223109.880152:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd5d7bc1, 2
[1:1:0711/223109.880348:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 30ffffffef5411 ffffffb83effffff8c0b ffffffc17b5d0d 7417fffffff724 , 10104, 4
[1:1:0711/223109.881302:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26134:26164:0711/223109.881531:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING0�T�>��{]t�$V4N!
[26134:26164:0711/223109.881599:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 0�T�>��{]t�$�tV4N!
[1:1:0711/223109.881515:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f67140e80a0, 3
[1:1:0711/223109.881774:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6714273080, 2
[26134:26164:0711/223109.882007:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/223109.881938:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66fdf36d20, -2
[26134:26164:0711/223109.882085:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26187, 4, 30ef5411 b83e8c0b c17b5d0d 7417f724 
[1:1:0711/223109.900696:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223109.901546:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d5d7bc1
[1:1:0711/223109.902502:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d5d7bc1
[1:1:0711/223109.904123:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d5d7bc1
[1:1:0711/223109.905598:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.905818:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.906001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.906189:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.906845:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d5d7bc1
[1:1:0711/223109.907149:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6715ead7ba
[1:1:0711/223109.907280:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6715ea4def, 7f6715ead77a, 7f6715eaf0cf
[1:1:0711/223109.913019:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d5d7bc1
[1:1:0711/223109.913445:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d5d7bc1
[1:1:0711/223109.914191:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d5d7bc1
[1:1:0711/223109.916219:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.916413:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.916597:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.916807:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d5d7bc1
[1:1:0711/223109.918040:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d5d7bc1
[1:1:0711/223109.918394:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6715ead7ba
[1:1:0711/223109.918558:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6715ea4def, 7f6715ead77a, 7f6715eaf0cf
[1:1:0711/223109.926350:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223109.926843:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223109.926986:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe503f5168, 0x7ffe503f50e8)
[1:1:0711/223109.945056:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223109.950883:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26134:26157:0711/223110.409565:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[26134:26134:0711/223110.445310:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26134:26134:0711/223110.446663:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26134:26146:0711/223110.466873:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26134:26146:0711/223110.466972:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26134:26134:0711/223110.467276:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26134:26134:0711/223110.467389:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26134:26134:0711/223110.467582:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26187, 4
[1:7:0711/223110.473495:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223110.564261:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x39720c6a8220
[1:1:0711/223110.565733:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/223110.832299:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[26134:26134:0711/223112.310426:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26134:26134:0711/223112.310548:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223112.320149:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223112.323193:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223113.385977:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223113.450023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223113.450323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223113.466755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/223113.467066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223113.788185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223113.788461:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223114.240033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223114.248292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223114.248527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223114.283248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223114.291390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/223114.291682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223114.298504:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/223114.302552:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x39720c6a6e20
[1:1:0711/223114.302777:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26134:26134:0711/223114.302957:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26134:26134:0711/223114.309704:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26134:26134:0711/223114.342564:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26134:26134:0711/223114.342779:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/223114.367742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223115.257669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f66ffb112e0 0x39720c6e71e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223115.259024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/223115.259255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223115.260796:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26134:26134:0711/223115.329246:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/223115.329421:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x39720c6a7820
[1:1:0711/223115.329637:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26134:26134:0711/223115.338863:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/223115.348353:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/223115.348597:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26134:26134:0711/223115.351533:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26134:26134:0711/223115.363226:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26134:26134:0711/223115.364207:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26134:26146:0711/223115.366567:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26134:26134:0711/223115.366602:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26134:26134:0711/223115.366641:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26134:26146:0711/223115.366650:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26134:26134:0711/223115.366703:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26187, 4
[1:7:0711/223115.375208:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223116.049144:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/223116.339121:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f66ffb112e0 0x39720c7dbb60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/223116.340206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d9b60021f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/223116.340494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/223116.341301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26134:26134:0711/223116.371401:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26134:26134:0711/223116.371473:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/223116.389754:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223116.715598:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223117.159720:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223117.160014:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26134:26134:0711/223117.219697:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26134:26164:0711/223117.220021:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/223117.220204:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/223117.220404:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/223117.220790:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/223117.220928:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/223117.224073:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8d0a40, 1
[1:1:0711/223117.224412:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30ec481c, 0
[1:1:0711/223117.224700:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1de38932, 3
[1:1:0711/223117.224841:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x240c318e, 2
[1:1:0711/223117.224976:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1c48ffffffec30 400affffff8d00 ffffff8e310c24 32ffffff89ffffffe31d , 10104, 5
[1:1:0711/223117.225905:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26134:26164:0711/223117.226115:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGH�0@
�
[26134:26164:0711/223117.226183:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is H�0@
�
[26134:26164:0711/223117.226399:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26231, 5, 1c48ec30 400a8d00 8e310c24 3289e31d 
[1:1:0711/223117.226717:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f67140e80a0, 3
[1:1:0711/223117.226929:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6714273080, 2
[1:1:0711/223117.227141:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f66fdf36d20, -2
[1:1:0711/223117.251770:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/223117.252199:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 240c318e
[1:1:0711/223117.252623:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 240c318e
[1:1:0711/223117.253372:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 240c318e
[1:1:0711/223117.255078:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.255304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.255556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.255773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.256594:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 240c318e
[1:1:0711/223117.256940:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6715ead7ba
[1:1:0711/223117.257106:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6715ea4def, 7f6715ead77a, 7f6715eaf0cf
[1:1:0711/223117.264011:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 240c318e
[1:1:0711/223117.264446:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 240c318e
[1:1:0711/223117.265365:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 240c318e
[1:1:0711/223117.267877:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.268148:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.268379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.268660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 240c318e
[1:1:0711/223117.270200:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 240c318e
[1:1:0711/223117.270664:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6715ead7ba
[1:1:0711/223117.270853:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6715ea4def, 7f6715ead77a, 7f6715eaf0cf
[1:1:0711/223117.280496:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/223117.281160:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/223117.281346:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe503f5168, 0x7ffe503f50e8)
[1:1:0711/223117.297166:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/223117.301858:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/223117.348160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223117.353021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d9b6014e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/223117.355129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/223117.363888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/223117.531353:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x39720c672220
[1:1:0711/223117.531718:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26134:26134:0711/223118.291202:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26134:26134:0711/223118.296525:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26134:26146:0711/223118.307413:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26134:26146:0711/223118.307508:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26134:26134:0711/223118.307590:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://search.yhd.com/
[26134:26134:0711/223118.307643:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://search.yhd.com/, https://search.yhd.com/c655-0-0, 1
[26134:26134:0711/223118.307708:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://search.yhd.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 05:31:18 GMT content-type:text/html;charset=UTF-8 vary:Accept-Encoding set-cookie:JSESSIONID=BAB74E14EE176941208E4B3279D8C38A.s1; Path=/; HttpOnly set-cookie:yhd_location=2_2817_51973_0; Domain=.yhd.com; Expires=Wed, 30-Jul-2087 08:45:25 GMT; Path=/ set-cookie:provinceId=2; Domain=.yhd.com; Expires=Wed, 30-Jul-2087 08:45:25 GMT; Path=/ set-cookie:cityId=2817; Domain=.yhd.com; Expires=Wed, 30-Jul-2087 08:45:25 GMT; Path=/ p3p:CP="NOI DEVa TAIa OUR BUS UNI" content-language:zh-CN expires:Fri, 12 Jul 2019 05:31:18 GMT cache-control:max-age=0 content-encoding:gzip server:jfe  ,26231, 5
[1:7:0711/223118.310864:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223118.328279:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://search.yhd.com/
[26134:26134:0711/223118.437333:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://search.yhd.com/, https://search.yhd.com/, 1
[26134:26134:0711/223118.437435:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://search.yhd.com/, https://search.yhd.com
[1:1:0711/223118.462909:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223118.614727:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223118.688599:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223118.733586:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223118.733809:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://search.yhd.com/c655-0-0"
[1:1:0711/223119.059769:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223119.510982:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223119.713739:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223119.716365:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223119.716841:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223119.717501:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223119.717968:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223119.796895:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223119.960213:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223120.605353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7f66fdbe9070 0x39720c823ee0 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223120.609980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , 
var URLPrefix = {"shop":"//shop.yhd.com","busystock":"//gps.yhd.com","cms":"//cms.yhd.com","img":"/
[1:1:0711/223120.610224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223120.612189:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223120.779940:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.164354, 227, 1
[1:1:0711/223120.780235:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223121.561088:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223121.561244:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://search.yhd.com/c655-0-0"
[1:1:0711/223121.561770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 277 0x7f66fdbe9070 0x39720c9cd060 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223121.563441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , 
window.HASH = {
longUrl : "//search.yhd.com/c655-0-0/mbname-b/a-s1-v4-p1-price-d0-f0b-m1-rt0-pid-mi
[1:1:0711/223121.563663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223121.569566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 277 0x7f66fdbe9070 0x39720c9cd060 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223122.062851:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.501668, 3614, 0
[1:1:0711/223122.063142:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223126.493547:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223126.493841:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://search.yhd.com/c655-0-0"
[1:1:0711/223126.915355:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.421319, 3709, 1
[1:1:0711/223126.915534:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[26134:26134:0711/223132.335256:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/223132.346694:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/223136.324426:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/223136.324700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://search.yhd.com/c655-0-0"
[1:1:0711/223136.909460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/223136.909800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223138.869629:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223139.065030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223139.065311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223144.722352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223144.722643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223150.024752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.043497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , /* SVN.committedRevision=0972654 */
var requirejs,require,define;(function(global){var req,s,head,ba
[1:1:0711/223150.043789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223150.063884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x28cc18f829c8, 0x39720c28ebb0
[1:1:0711/223150.064175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 4
[1:1:0711/223150.064671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1022
[1:1:0711/223150.064918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f66fdbe9070 0x39720c79d060 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 
		remove user.10_6ba02dd4 -> 0
[1:1:0711/223150.095668:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x28cc18f829c8, 0x39720c28ebb0
[1:1:0711/223150.096061:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 4
[1:1:0711/223150.096500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1023
[1:1:0711/223150.096733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f66fdbe9070 0x39720c1fc660 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 
[1:1:0711/223150.505117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.509612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , /* SVN.committedRevision=1200 */
(function(t,r,f){t.migrateMute=1;var j={};t.migrateWarnings=[];if(!
[1:1:0711/223150.509866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223150.609326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.612272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.615921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.619001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.621161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.641633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://search.yhd.com/c655-0-0"
[1:1:0711/223150.734336:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223150.751261:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223150.751514:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 4
[1:1:0711/223150.751961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1071
[1:1:0711/223150.752243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1071 0x7f66fdbe9070 0x39720c8ea060 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[1:1:0711/223150.821257:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 2000
[1:1:0711/223150.821754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1075
[1:1:0711/223150.822015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7f66fdbe9070 0x39720c963460 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[1:1:0711/223151.134500:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223151.134792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 2000
[1:1:0711/223151.135188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1085
[1:1:0711/223151.135421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7f66fdbe9070 0x39720cee1c60 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[1:1:0711/223151.230692:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223151.231466:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 3000
[1:1:0711/223151.231898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1090
[1:1:0711/223151.232124:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7f66fdbe9070 0x39720d8ebce0 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[1:1:0711/223151.278474:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223151.278732:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 3000
[1:1:0711/223151.279139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1093
[1:1:0711/223151.279376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f66fdbe9070 0x39720dbea460 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[26134:26134:0711/223151.297064:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26134:26134:0711/223151.299405:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0711/223151.299319:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x39720d402a20
[1:1:0711/223151.299546:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/223151.328292:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/223151.328522:INFO:render_frame_impl.cc(7019)] 	 [url] = https://search.yhd.com
[26134:26134:0711/223151.333493:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://search.yhd.com/
[1:1:0711/223151.345619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223151.345891:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 4
[1:1:0711/223151.346286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1106
[1:1:0711/223151.346524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f66fdbe9070 0x39720c94c960 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[26134:26134:0711/223151.362177:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26134:26134:0711/223151.365991:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0711/223151.366588:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x28cc18f829c8, 0x39720c28ec40
[1:1:0711/223151.366852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 200
[1:1:0711/223151.367263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1107
[1:1:0711/223151.367497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7f66fdbe9070 0x39720d8aa660 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[26134:26146:0711/223151.391817:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[26134:26146:0711/223151.391883:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[26134:26134:0711/223151.392169:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.yhd.com/
[26134:26134:0711/223151.392258:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.yhd.com/, https://www.yhd.com/html/getLocalStorage.html?v=2019711, 4
[26134:26134:0711/223151.392419:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://www.yhd.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 05:31:51 GMT content-type:text/html vary:Accept-Encoding etag:W/"3974-1553073506000" last-modified:Wed, 20 Mar 2019 09:18:26 GMT expires:Fri, 12 Jul 2019 05:31:51 GMT cache-control:max-age=0 content-encoding:gzip server:jfe strict-transport-security:max-age=7776000  ,26231, 5
[1:7:0711/223151.394890:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/223151.422277:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 2000
[1:1:0711/223151.422750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1112
[1:1:0711/223151.422986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f66fdbe9070 0x39720ced6fe0 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 
[1:1:0711/223151.626557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223151.626887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223153.918104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1022, 7f670052e881
[1:1:0711/223153.969963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223153.970365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223153.970940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223153.971588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){intakeDefines();requireMod=getModule(makeModuleMap(null,relMap));requireMod.skipMap=options.skipM
[1:1:0711/223153.971852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223153.988022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1023, 7f670052e881
[1:1:0711/223154.038921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223154.039314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"984 0x7f6714273080 0x39720cc2b240 1 0 0x39720cc2b258 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223154.039729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223154.040348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){intakeDefines();requireMod=getModule(makeModuleMap(null,relMap));requireMod.skipMap=options.skipM
[1:1:0711/223154.040597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[26134:26134:0711/223154.319502:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223155.387933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.388672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , a, (m,n){var o,j,l;if(a&&(n||f.readyState===4)){delete dg[c];a=undefined;f.onreadystatechange=dd.noop;i
[1:1:0711/223155.388936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223155.390147:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.393271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.394044:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x34f61078f520
[1:1:0711/223155.733432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.733906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , a, (m,n){var o,j,l;if(a&&(n||f.readyState===4)){delete dg[c];a=undefined;f.onreadystatechange=dd.noop;i
[1:1:0711/223155.734033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223155.734271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.736111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223155.736815:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x34f61078f520
[1:1:0711/223155.944486:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://www.yhd.com/
[1:1:0711/223156.103089:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1071, 7f670052e881
[1:1:0711/223156.120023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.120219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.120483:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223156.120822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){intakeDefines();requireMod=getModule(makeModuleMap(null,relMap));requireMod.skipMap=options.skipM
[1:1:0711/223156.120986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223156.363392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223156.363627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 800
[1:1:0711/223156.364279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1202
[1:1:0711/223156.364504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1202 0x7f66fdbe9070 0x39720bfd7060 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1071 0x7f66fdbe9070 0x39720c8ea060 
[1:1:0711/223156.626781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223156.627027:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 5000
[1:1:0711/223156.627403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1206
[1:1:0711/223156.627594:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7f66fdbe9070 0x39720d2ab760 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1071 0x7f66fdbe9070 0x39720c8ea060 
[1:1:0711/223156.695052:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1106, 7f670052e881
[1:1:0711/223156.712396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.712585:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.712813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223156.713166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){intakeDefines();requireMod=getModule(makeModuleMap(null,relMap));requireMod.skipMap=options.skipM
[1:1:0711/223156.713270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223156.791071:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223156.791319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 5000
[1:1:0711/223156.791681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1214
[1:1:0711/223156.791873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f66fdbe9070 0x39720cc2c6e0 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1106 0x7f66fdbe9070 0x39720c94c960 
[1:1:0711/223156.816800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1107, 7f670052e881
[1:1:0711/223156.843173:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.843545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223156.843848:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223156.844202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){try{b.apply(e,a)}catch(f){}runfunctions(d,c,e)}
[1:1:0711/223156.844312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223157.361477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223157.361647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 200
[1:1:0711/223157.361835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1229
[1:1:0711/223157.361953:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1229 0x7f66fdbe9070 0x39720c8b2c60 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1107 0x7f66fdbe9070 0x39720d8aa660 
[1:1:0711/223157.408370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223157.408540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223157.448420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1075, 7f670052e8db
[1:1:0711/223157.466362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223157.466566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223157.466824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1234
[1:1:0711/223157.466941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1234 0x7f66fdbe9070 0x39720d0fee60 , 5:3_https://search.yhd.com/, 0, , 1075 0x7f66fdbe9070 0x39720c963460 
[1:1:0711/223157.467130:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223157.467454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){if(g.isBusy){return false}var m=g.imgArray;var n=m.length;if(n>h){g._imgLoad(m,0,h,p)}else{if(n>0
[1:1:0711/223157.467560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223157.652305:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1085, 7f670052e881
[1:1:0711/223157.671873:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223157.672091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223157.672375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223157.672733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){o.abort("timeout")}
[1:1:0711/223157.672842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223157.998561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1112, 7f670052e8db
[1:1:0711/223158.054990:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223158.055312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"985 0x7f6714273080 0x39720c63fd80 1 0 0x39720c63fd98 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223158.055777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1246
[1:1:0711/223158.055978:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1246 0x7f66fdbe9070 0x39720c791b60 , 5:3_https://search.yhd.com/, 0, , 1112 0x7f66fdbe9070 0x39720ced6fe0 
[1:1:0711/223158.056384:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223158.056973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){if(g.isBusy){return false}var m=g.imgArray;var n=m.length;if(n>h){g._imgLoad(m,0,h,p)}else{if(n>0
[1:1:0711/223158.057154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223158.229664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1165 0x7f66ffb112e0 0x39720d100fe0 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223158.231364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , /* 2019-07-09 13:52:03 joya.js @issue to lijiwen@jd.com Thanks */
try{window.fingerprint={},function
[1:1:0711/223158.231632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
		remove user.11_d08606ab -> 0
[1:1:0711/223159.140221:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223159.140793:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/223204.732881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223205.070843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x28cc18f829c8, 0x39720c28ea10
[1:1:0711/223205.071195:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 2000
[1:1:0711/223205.071584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1303
[1:1:0711/223205.071837:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f66fdbe9070 0x3972113c37e0 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1165 0x7f66ffb112e0 0x39720d100fe0 
[1:1:0711/223205.277498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7f66ffb112e0 0x39720d217de0 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223205.278619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , jsonp_getCityById6({"message":0,"city":{"areaId":51973,"areaName":"城区","cityId":2817,"cityName":
[1:1:0711/223205.278864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223205.279947:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223205.604235:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1176 0x7f66ffb112e0 0x39720d5c7b60 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223205.605618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , var loginFrameClientFunction;var loginRegisterFrameType;var srcUrl;function passportLoginFrame(t,v,p
[1:1:0711/223205.605877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223205.919302:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1183 0x7f66ffb112e0 0x39720c963160 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223205.927868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , jsonp_getAllCity6({"message":0,"objCitys":{"A":[{"areaId":6822,"areaName":"北屯市","cityId":2744,
[1:1:0711/223205.928140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[26134:26134:0711/223205.977758:INFO:CONSOLE(1)] "Uncaught TypeError: jsonp_getAllCity6 is not a function", source: https://www.yhd.com/homepage/getAllCity.do?callback=jsonp_getAllCity6 (1)
[26134:26134:0711/223206.487185:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.yhd.com/, https://www.yhd.com/, 4
[26134:26134:0711/223206.487240:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.yhd.com/, https://www.yhd.com
[1:1:0711/223206.487682:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/223207.884760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1202, 7f670052e881
[1:1:0711/223207.944883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1071 0x7f66fdbe9070 0x39720c8ea060 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223207.945231:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1071 0x7f66fdbe9070 0x39720c8ea060 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223207.945627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223207.946184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){j.slideDown();a.slideUp()}
[1:1:0711/223207.946362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223208.034775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223208.035013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223208.063264:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1229, 7f670052e881
[1:1:0711/223208.096717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1107 0x7f66fdbe9070 0x39720d8aa660 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223208.097123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1107 0x7f66fdbe9070 0x39720d8aa660 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223208.097581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223208.098242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){try{b.apply(e,a)}catch(f){}runfunctions(d,c,e)}
[1:1:0711/223208.098455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
		remove user.12_ad4377c7 -> 0
		remove user.13_a53e7f94 -> 0
[1:1:0711/223208.381583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223208.381748:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 200
[1:1:0711/223208.381960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1425
[1:1:0711/223208.382072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f66fdbe9070 0x3972118e4e60 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1229 0x7f66fdbe9070 0x39720c8b2c60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/223212.511598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1246, 7f670052e8db
[1:1:0711/223212.558386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1112 0x7f66fdbe9070 0x39720ced6fe0 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.558577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1112 0x7f66fdbe9070 0x39720ced6fe0 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.558798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1479
[1:1:0711/223212.559055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1479 0x7f66fdbe9070 0x3972119d03e0 , 5:3_https://search.yhd.com/, 0, , 1246 0x7f66fdbe9070 0x39720c791b60 
[1:1:0711/223212.559412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223212.560006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){if(g.isBusy){return false}var m=g.imgArray;var n=m.length;if(n>h){g._imgLoad(m,0,h,p)}else{if(n>0
[1:1:0711/223212.560214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223212.673266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1206, 7f670052e881
[1:1:0711/223212.746372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1071 0x7f66fdbe9070 0x39720c8ea060 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.746781:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1071 0x7f66fdbe9070 0x39720c8ea060 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.747365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223212.748183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){o.abort("timeout")}
[1:1:0711/223212.748442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223212.920851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1214, 7f670052e881
[1:1:0711/223212.996630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1106 0x7f66fdbe9070 0x39720c94c960 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.997026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1106 0x7f66fdbe9070 0x39720c94c960 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223212.997453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223212.998092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){o.abort("timeout")}
[1:1:0711/223212.998313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223215.233435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1366 0x7f66ffb112e0 0x39720d9bc1e0 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.234054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , jsonp1562909516565({"code":"00000000","data":0,"msg":"操作成功。","result":null})
[1:1:0711/223215.234168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[26134:26134:0711/223215.239002:INFO:CONSOLE(1)] "Uncaught TypeError: jsonp1562909516565 is not a function", source: https://cart.yhd.com/cart/opt/getCartCount.do?callback=jsonp1562909516565&_=1562909510213 (1)
[1:1:0711/223215.280233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1367 0x7f66ffb112e0 0x397210db9560 , "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.280848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , jsonp1562909516730({"code":"00000000","data":0,"msg":"操作成功。","result":null})
[1:1:0711/223215.280965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[26134:26134:0711/223215.285585:INFO:CONSOLE(1)] "Uncaught TypeError: jsonp1562909516730 is not a function", source: https://cart.yhd.com/cart/opt/getCartCount.do?callback=jsonp1562909516730&_=1562909510214 (1)
[1:1:0711/223215.342921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.343693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , a, (m,n){var o,j,l;if(a&&(n||f.readyState===4)){delete dg[c];a=undefined;f.onreadystatechange=dd.noop;i
[1:1:0711/223215.343880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223215.344339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.346727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.347343:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x34f61078f520
[1:1:0711/223215.521386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.522105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , a, (m,n){var o,j,l;if(a&&(n||f.readyState===4)){delete dg[c];a=undefined;f.onreadystatechange=dd.noop;i
[1:1:0711/223215.522284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223215.522832:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.525426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://search.yhd.com/c655-0-0"
[1:1:0711/223215.526078:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x34f61078f520
[1:1:0711/223217.240900:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/223217.836376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1303, 7f670052e881
[1:1:0711/223217.904258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1165 0x7f66ffb112e0 0x39720d100fe0 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223217.904568:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1165 0x7f66ffb112e0 0x39720d100fe0 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223217.904922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223217.905548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , popProductExpose, () {
var popProducts = "null_4:47824517783_8:45640155444_12:44048919346_16:40784838666_20:2820943659
[1:1:0711/223217.905725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[26134:26134:0711/223218.462714:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/223218.586160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , document.readyState
[1:1:0711/223218.586434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223218.659828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1425, 7f670052e881
[1:1:0711/223218.735506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2673c0a02860","ptid":"1229 0x7f66fdbe9070 0x39720c8b2c60 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223218.735704:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://search.yhd.com/","ptid":"1229 0x7f66fdbe9070 0x39720c8b2c60 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223218.735907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223218.736259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){try{b.apply(e,a)}catch(f){}runfunctions(d,c,e)}
[1:1:0711/223218.736442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223218.953560:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x28cc18f829c8, 0x39720c28e950
[1:1:0711/223218.953787:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://search.yhd.com/c655-0-0", 200
[1:1:0711/223218.954141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://search.yhd.com/, 1635
[1:1:0711/223218.954331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1635 0x7f66fdbe9070 0x3972118e2fe0 , 5:3_https://search.yhd.com/, 1, -5:3_https://search.yhd.com/, 1425 0x7f66fdbe9070 0x3972118e4e60 
[1:1:0711/223219.631745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223219.632183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223219.632294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223219.792765:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223219.793455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223219.793679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223220.532217:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223220.532937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223220.533137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223220.534681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1479, 7f670052e8db
[1:1:0711/223220.585557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1246 0x7f66fdbe9070 0x39720c791b60 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223220.585762:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1246 0x7f66fdbe9070 0x39720c791b60 ","rf":"5:3_https://search.yhd.com/"}
[1:1:0711/223220.586074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://search.yhd.com/, 1658
[1:1:0711/223220.586189:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1658 0x7f66fdbe9070 0x397211cbb760 , 5:3_https://search.yhd.com/, 0, , 1479 0x7f66fdbe9070 0x3972119d03e0 
[1:1:0711/223220.586401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://search.yhd.com/c655-0-0"
[1:1:0711/223220.586703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , , (){if(g.isBusy){return false}var m=g.imgArray;var n=m.length;if(n>h){g._imgLoad(m,0,h,p)}else{if(n>0
[1:1:0711/223220.586842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223220.868280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223220.868710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223220.868857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223220.963079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223220.963988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223220.964218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223221.131700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223221.132580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223221.132825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
[1:1:0711/223221.273150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://search.yhd.com/c655-0-0"
[1:1:0711/223221.273827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://search.yhd.com/, 2673c0a02860, , Ct.r.onload.r.onerror, (){r.onload=null,r.onerror=null}
[1:1:0711/223221.274024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://search.yhd.com/c655-0-0", "search.yhd.com", 3, 1, , , 0
