[0713/002535.740152:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002535.740430:INFO:switcher_clone.cc(787)] backtrace rip is 7f750de32891
[0713/002536.720146:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002536.720669:INFO:switcher_clone.cc(787)] backtrace rip is 7fdf4391a891
[1:1:0713/002536.729139:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/002536.729390:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/002536.734730:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/002538.051482:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/002538.051795:INFO:switcher_clone.cc(787)] backtrace rip is 7f371c9ce891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[25430:25430:0713/002538.244303:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[25461:25461:0713/002538.274680:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25461
[25471:25471:0713/002538.275144:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=25471

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ad2fda93-0e51-4faf-bc9f-d78b25d05bb6
[25430:25430:0713/002538.891841:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[25430:25459:0713/002538.893265:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/002538.893753:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002538.894215:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002538.895785:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002538.896194:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/002538.900939:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34efc4e8, 1
[1:1:0713/002538.901281:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1ffab7a7, 0
[1:1:0713/002538.901487:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2318e75f, 3
[1:1:0713/002538.901695:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1615ec70, 2
[1:1:0713/002538.901936:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa7ffffffb7fffffffa1f ffffffe8ffffffc4ffffffef34 70ffffffec1516 5fffffffe71823 , 10104, 4
[1:1:0713/002538.902905:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25430:25459:0713/002538.903198:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING������4p�_�#�+n
[25430:25459:0713/002538.903294:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ������4p�_�#� �+n
[1:1:0713/002538.903168:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf41b550a0, 3
[1:1:0713/002538.903419:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf41ce0080, 2
[1:1:0713/002538.903569:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf2b9a3d20, -2
[25430:25459:0713/002538.903672:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[25430:25459:0713/002538.903765:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25481, 4, a7b7fa1f e8c4ef34 70ec1516 5fe71823 
[1:1:0713/002538.921111:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002538.921902:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1615ec70
[1:1:0713/002538.922776:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1615ec70
[1:1:0713/002538.924263:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1615ec70
[1:1:0713/002538.925670:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.925886:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.926067:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.926243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.926868:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1615ec70
[1:1:0713/002538.927164:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdf4391a7ba
[1:1:0713/002538.927289:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdf43911def, 7fdf4391a77a, 7fdf4391c0cf
[1:1:0713/002538.932749:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1615ec70
[1:1:0713/002538.933142:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1615ec70
[1:1:0713/002538.933840:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1615ec70
[1:1:0713/002538.935719:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.935925:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.936118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.936293:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1615ec70
[1:1:0713/002538.937467:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1615ec70
[1:1:0713/002538.937822:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdf4391a7ba
[1:1:0713/002538.937989:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdf43911def, 7fdf4391a77a, 7fdf4391c0cf
[1:1:0713/002538.945254:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002538.945659:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002538.945798:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc506088a8, 0x7ffc50608828)
[1:1:0713/002538.962805:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002538.968277:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[25430:25430:0713/002539.584033:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25430:25430:0713/002539.585446:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25430:25440:0713/002539.597841:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[25430:25440:0713/002539.597961:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[25430:25430:0713/002539.598166:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[25430:25430:0713/002539.598264:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[25430:25430:0713/002539.598462:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,25481, 4
[1:7:0713/002539.607206:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[25430:25453:0713/002539.654031:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/002539.725495:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe177aa5220
[1:1:0713/002539.725757:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/002540.047153:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/002541.402791:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002541.406973:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[25430:25430:0713/002541.724922:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[25430:25430:0713/002541.725068:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002542.444883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002542.603052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002542.603401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002542.620253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/002542.620583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002542.690276:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002542.690564:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002543.110270:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002543.115749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002543.116020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002543.141976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002543.152493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/002543.152800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002543.167513:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[25430:25430:0713/002543.170687:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002543.170961:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe177aa3e20
[1:1:0713/002543.171684:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[25430:25430:0713/002543.178240:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[25430:25430:0713/002543.209280:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[25430:25430:0713/002543.209499:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/002543.283339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002543.892990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fdf2d57e2e0 0xe177d10a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002543.894375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/002543.894636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002543.896128:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25430:25430:0713/002543.955093:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/002543.957398:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe177aa4820
[1:1:0713/002543.957727:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[25430:25430:0713/002543.965544:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/002543.973323:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/002543.973606:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[25430:25430:0713/002543.985697:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[25430:25430:0713/002543.999800:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25430:25430:0713/002544.001237:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25430:25440:0713/002544.009099:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[25430:25440:0713/002544.009189:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[25430:25430:0713/002544.009449:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[25430:25430:0713/002544.009568:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[25430:25430:0713/002544.009744:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,25481, 4
[1:7:0713/002544.011920:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002544.531130:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/002544.962810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fdf2d57e2e0 0xe177c744e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/002544.963827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 10c1191a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/002544.964206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/002544.964991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[25430:25430:0713/002545.088595:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[25430:25430:0713/002545.088979:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/002545.101992:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002545.286408:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002545.941745:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002545.942020:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25430:25430:0713/002546.013533:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[25430:25459:0713/002546.013999:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/002546.014190:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/002546.014505:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/002546.014920:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/002546.015092:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/002546.018134:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3a5e4b98, 1
[1:1:0713/002546.018493:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15738c39, 0
[1:1:0713/002546.018671:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26868e1b, 3
[1:1:0713/002546.018860:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f2bc8bc, 2
[1:1:0713/002546.019045:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 39ffffff8c7315 ffffff984b5e3a ffffffbcffffffc82b2f 1bffffff8effffff8626 , 10104, 5
[1:1:0713/002546.020025:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[25430:25459:0713/002546.020291:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING9�s�K^:��+/��&�+n
[25430:25459:0713/002546.020376:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 9�s�K^:��+/��&��+n
[1:1:0713/002546.020283:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf41b550a0, 3
[25430:25459:0713/002546.020630:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 25527, 5, 398c7315 984b5e3a bcc82b2f 1b8e8626 
[1:1:0713/002546.020517:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf41ce0080, 2
[1:1:0713/002546.020791:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fdf2b9a3d20, -2
[1:1:0713/002546.041658:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/002546.042034:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f2bc8bc
[1:1:0713/002546.042367:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f2bc8bc
[1:1:0713/002546.043022:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f2bc8bc
[1:1:0713/002546.044439:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.044665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.044923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.045137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.045841:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f2bc8bc
[1:1:0713/002546.046157:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdf4391a7ba
[1:1:0713/002546.046326:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdf43911def, 7fdf4391a77a, 7fdf4391c0cf
[1:1:0713/002546.053015:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f2bc8bc
[1:1:0713/002546.053419:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f2bc8bc
[1:1:0713/002546.054191:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f2bc8bc
[1:1:0713/002546.056234:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.056480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.056701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.056927:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2bc8bc
[1:1:0713/002546.058194:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f2bc8bc
[1:1:0713/002546.058586:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fdf4391a7ba
[1:1:0713/002546.058775:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fdf43911def, 7fdf4391a77a, 7fdf4391c0cf
[1:1:0713/002546.066518:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/002546.067052:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/002546.067239:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc506088a8, 0x7ffc50608828)
[1:1:0713/002546.081006:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/002546.085151:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/002546.226268:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe177a7a220
[1:1:0713/002546.226518:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/002546.420735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/002546.425322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 10c1192ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/002546.425595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/002546.433282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[25430:25430:0713/002546.583319:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[25430:25430:0713/002546.587691:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[25430:25440:0713/002546.631513:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[25430:25440:0713/002546.631606:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[25430:25430:0713/002546.631810:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://int.ems.com.cn/
[25430:25430:0713/002546.631859:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://int.ems.com.cn/, http://int.ems.com.cn/, 1
[25430:25430:0713/002546.631949:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://int.ems.com.cn/, HTTP/1.1 403 Forbidden Server: nginx Date: Sat, 13 Jul 2019 07:34:43 GMT Content-Type: text/html Content-Length: 564 Connection: keep-alive Set-Cookie: BIGipServerDMZ_80_pool=706544394.20480.0000; path=/  ,25527, 5
[1:7:0713/002546.640478:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/002546.653394:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://int.ems.com.cn/
[1:1:0713/002546.666190:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 (Forbidden)","http://int.ems.com.cn/"
[25430:25430:0713/002546.801019:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://int.ems.com.cn/, http://int.ems.com.cn/, 1
[25430:25430:0713/002546.801095:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://int.ems.com.cn/, http://int.ems.com.cn
[1:1:0713/002546.811712:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/002546.927384:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/002546.997683:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/002546.997930:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://int.ems.com.cn/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/002548.085356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002548.089101:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002548.089521:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002548.089930:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002548.090303:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/002622.295633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://int.ems.com.cn/, 288a00702860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/002622.295897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://int.ems.com.cn/", "int.ems.com.cn", 3, 1, , , 0
[1:1:0713/002622.300144:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[25430:25430:0713/002622.726468:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/002622.785018:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/002623.230826:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://int.ems.com.cn/favicon.ico"
