[0712/093152.271293:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/093152.271576:INFO:switcher_clone.cc(787)] backtrace rip is 7fd1c1ecb891
[0712/093153.106894:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/093153.107255:INFO:switcher_clone.cc(787)] backtrace rip is 7fa780963891
[1:1:0712/093153.118860:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/093153.119100:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/093153.128846:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[116704:116704:0712/093154.592785:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/093154.634934:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/093154.635432:INFO:switcher_clone.cc(787)] backtrace rip is 7fd3dcffa891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/48cac9ad-c0df-4be8-beb3-c99c61a931e8
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[116736:116736:0712/093154.860984:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=116736
[116748:116748:0712/093154.861405:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=116748
[116704:116704:0712/093155.077457:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[116704:116733:0712/093155.078250:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/093155.078483:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/093155.078786:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/093155.079381:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/093155.079539:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/093155.082676:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d4abbe4, 1
[1:1:0712/093155.082988:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2b06b9d, 0
[1:1:0712/093155.083164:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x23a547f2, 3
[1:1:0712/093155.083337:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x38a09e0d, 2
[1:1:0712/093155.083531:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9d6bffffffb002 ffffffe4ffffffbb4a2d 0dffffff9effffffa038 fffffff247ffffffa523 , 10104, 4
[1:1:0712/093155.084511:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[116704:116733:0712/093155.084762:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�k��J-��8�G�#
[116704:116733:0712/093155.084845:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �k��J-��8�G�#��
[1:1:0712/093155.084754:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa77eb9e0a0, 3
[1:1:0712/093155.084981:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa77ed29080, 2
[116704:116733:0712/093155.085133:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/093155.085135:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7689ecd20, -2
[116704:116733:0712/093155.085204:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 116756, 4, 9d6bb002 e4bb4a2d 0d9ea038 f247a523 
[1:1:0712/093155.103981:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/093155.104854:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38a09e0d
[1:1:0712/093155.105811:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38a09e0d
[1:1:0712/093155.107387:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38a09e0d
[1:1:0712/093155.108914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.109102:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.109290:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.109481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.110140:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38a09e0d
[1:1:0712/093155.110468:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7809637ba
[1:1:0712/093155.110601:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa78095adef, 7fa78096377a, 7fa7809650cf
[1:1:0712/093155.116248:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38a09e0d
[1:1:0712/093155.116586:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38a09e0d
[1:1:0712/093155.117342:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38a09e0d
[1:1:0712/093155.119369:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.119581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.119816:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.120006:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38a09e0d
[1:1:0712/093155.121232:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38a09e0d
[1:1:0712/093155.121588:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7809637ba
[1:1:0712/093155.121745:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa78095adef, 7fa78096377a, 7fa7809650cf
[1:1:0712/093155.129464:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/093155.129919:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/093155.130064:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd6222dd58, 0x7ffd6222dcd8)
[1:1:0712/093155.145741:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/093155.151383:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[116704:116704:0712/093155.722055:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[116704:116704:0712/093155.722502:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[116704:116715:0712/093155.737740:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[116704:116715:0712/093155.737874:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[116704:116704:0712/093155.737990:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[116704:116704:0712/093155.738068:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[116704:116704:0712/093155.738203:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,116756, 4
[1:7:0712/093155.740027:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[116704:116726:0712/093155.805631:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/093155.859746:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2d1be6a81220
[1:1:0712/093155.860002:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/093156.194704:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/093157.797276:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093157.801421:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[116704:116704:0712/093157.856698:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[116704:116704:0712/093157.856832:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/093158.686673:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093158.919034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/093158.919334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093158.937283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/093158.937620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093159.070432:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093159.070723:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093159.354940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093159.363187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/093159.363448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093159.394542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093159.398414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/093159.398663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093159.406828:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/093159.410566:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d1be6a7fe20
[1:1:0712/093159.410788:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[116704:116704:0712/093159.431882:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[116704:116704:0712/093159.445891:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[116704:116704:0712/093159.465802:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[116704:116704:0712/093159.465936:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[116704:116704:0712/093159.473121:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/093159.488065:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093200.232671:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fa76a5c72e0 0x2d1be6d2af60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093200.233415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/093200.233541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093200.234131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[116704:116704:0712/093200.263992:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/093200.266192:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2d1be6a80820
[1:1:0712/093200.266405:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[116704:116704:0712/093200.275857:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/093200.286745:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/093200.286977:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[116704:116704:0712/093200.297334:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[116704:116704:0712/093200.304800:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[116704:116704:0712/093200.305547:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[116704:116715:0712/093200.307300:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[116704:116704:0712/093200.307339:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[116704:116704:0712/093200.307381:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[116704:116715:0712/093200.307384:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[116704:116704:0712/093200.307452:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,116756, 4
[1:7:0712/093200.316385:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/093200.894863:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/093201.370657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7fa76a5c72e0 0x2d1be6d2db60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/093201.371749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3ca9dec41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/093201.372009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/093201.372799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[116704:116704:0712/093201.556609:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[116704:116704:0712/093201.556718:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/093201.584753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093202.003612:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093202.516223:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093202.516517:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[116704:116704:0712/093202.589463:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[116704:116733:0712/093202.589964:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/093202.590153:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/093202.590410:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/093202.590848:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/093202.591029:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/093202.594947:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31124149, 1
[1:1:0712/093202.595345:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x366d36b0, 0
[1:1:0712/093202.595626:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x14e1a0a1, 3
[1:1:0712/093202.595833:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x68f67be, 2
[1:1:0712/093202.596034:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb0366d36 49411231 ffffffbe67ffffff8f06 ffffffa1ffffffa0ffffffe114 , 10104, 5
[1:1:0712/093202.597053:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[116704:116733:0712/093202.597361:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�6m6IA1�g����G
[116704:116733:0712/093202.597454:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �6m6IA1�g����qG
[1:1:0712/093202.597345:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa77eb9e0a0, 3
[1:1:0712/093202.597642:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa77ed29080, 2
[116704:116733:0712/093202.597799:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 116799, 5, b0366d36 49411231 be678f06 a1a0e114 
[1:1:0712/093202.597889:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7689ecd20, -2
[1:1:0712/093202.615241:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/093202.618674:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 68f67be
[1:1:0712/093202.619029:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 68f67be
[1:1:0712/093202.619811:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 68f67be
[1:1:0712/093202.621928:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.622209:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.622438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.622669:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.623363:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 68f67be
[1:1:0712/093202.623705:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7809637ba
[1:1:0712/093202.623894:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa78095adef, 7fa78096377a, 7fa7809650cf
[1:1:0712/093202.630080:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 68f67be
[1:1:0712/093202.630552:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 68f67be
[1:1:0712/093202.631331:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 68f67be
[1:1:0712/093202.633437:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.633719:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.633951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.634184:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 68f67be
[1:1:0712/093202.635455:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 68f67be
[1:1:0712/093202.635870:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7809637ba
[1:1:0712/093202.636064:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa78095adef, 7fa78096377a, 7fa7809650cf
[1:1:0712/093202.640110:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/093202.640627:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/093202.640822:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd6222dd58, 0x7ffd6222dcd8)
[1:1:0712/093202.655600:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/093202.659832:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/093202.828345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 551, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/093202.832985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3ca9ded6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/093202.833322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/093202.841138:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/093202.881022:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2d1be6a49220
[1:1:0712/093202.881293:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[116704:116704:0712/093206.536562:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[116704:116704:0712/093206.542935:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[116704:116704:0712/093206.569494:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://yule.iqiyi.com/
[116704:116704:0712/093206.569602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[116704:116704:0712/093206.569729:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://yule.iqiyi.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 16:32:04 GMT content-type:text/html; charset=UTF-8 expires:Fri, 12 Jul 2019 16:35:04 GMT cache-control:max-age=180 x-cache:EXPIRED from 124.193.229.74 content-encoding:gzip  ,116799, 5
[116704:116715:0712/093206.574065:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[116704:116715:0712/093206.574180:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/093206.585345:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/093206.605883:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://yule.iqiyi.com/
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[116704:116704:0712/093206.801361:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[116704:116704:0712/093206.801465:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://yule.iqiyi.com/, https://yule.iqiyi.com
[1:1:0712/093206.870344:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.047007:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093207.104629:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.163497:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093207.163845:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/093207.259232:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.480908:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.564818:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.648334:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.676247:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093207.716447:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/093208.183950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7fa76869f070 0x2d1be7036b60 , "https://yule.iqiyi.com/"
[1:1:0712/093208.186394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , 
    var pageJsMap = window.pageJsMap = {"albumBodan":"albumBodan.1c84c9e1.js","dianshiju":"dianshij
[1:1:0712/093208.186638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "yule.iqiyi.com", 3, 1, , , 0
[1:1:0712/093208.187999:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093208.190941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7fa76869f070 0x2d1be7036b60 , "https://yule.iqiyi.com/"
[1:1:0712/093208.192567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7fa76869f070 0x2d1be7036b60 , "https://yule.iqiyi.com/"
[1:1:0712/093208.222639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7fa76869f070 0x2d1be7036b60 , "https://yule.iqiyi.com/"
[1:1:0712/093208.536132:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.34602, 605, 1
[1:1:0712/093208.536384:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093209.155964:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093209.156277:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/093209.157145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7fa76869f070 0x2d1be6e4e0e0 , "https://yule.iqiyi.com/"
[1:1:0712/093209.158589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , 
    function getCookie(name){
          var strcookie = document.cookie;
          var arrcookie = 
[1:1:0712/093209.158819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "yule.iqiyi.com", 3, 1, , , 0
[1:1:0712/093209.160886:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "yule.iqiyi.com", "iqiyi.com"
[1:1:0712/093209.171722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 263 0x7fa76869f070 0x2d1be6e4e0e0 , "https://yule.iqiyi.com/"
[1:1:0712/093209.505990:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.34957, 1330, 1
[1:1:0712/093209.506194:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093210.143008:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093210.143172:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/093210.143818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 302 0x7fa76869f070 0x2d1be6e7af60 , "https://yule.iqiyi.com/"
[1:1:0712/093210.144391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , 
    window.__qlt = {};
    window.__qlt.statisticsStart = +new Date;
    window.__qlt.cid = "";

[1:1:0712/093210.144505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093210.145726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 302 0x7fa76869f070 0x2d1be6e7af60 , "https://yule.iqiyi.com/"
[1:1:0712/093210.214319:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0712519, 467, 1
[1:1:0712/093210.214626:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093211.071984:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093211.072141:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/093211.072580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7fa76869f070 0x2d1be6e43fe0 , "https://yule.iqiyi.com/"
[1:1:0712/093211.073173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , 
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
   
[1:1:0712/093211.073291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093211.078154:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7fa76869f070 0x2d1be6e43fe0 , "https://yule.iqiyi.com/"
[1:1:0712/093211.089028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7fa76869f070 0x2d1be6e43fe0 , "https://yule.iqiyi.com/"
[1:1:0712/093211.103441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7fa76869f070 0x2d1be6e43fe0 , "https://yule.iqiyi.com/"
[1:1:0712/093211.234391:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093212.249885:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093212.250207:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093212.250457:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093212.250824:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093212.251290:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093213.042416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fa76a5c72e0 0x2d1be6d0a560 , "https://yule.iqiyi.com/"
[1:1:0712/093213.043190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , (function(o,s,f){var t=false,e=/msie/.test(navigator.userAgent.toLowerCase()),r="//iqiyi.irs01.com/i
[1:1:0712/093213.043321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093213.074377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7fa76a5c72e0 0x2d1be702fae0 , "https://yule.iqiyi.com/"
[1:1:0712/093213.075146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , try{ updateUserIconCallback({"code":"A00003","data":{"type":"params_error","msg":"userinfoDetail","d
[1:1:0712/093213.075296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093213.076139:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x2f19636e29c8, 0x2d1be65bb188
[1:1:0712/093213.076276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 10
[1:1:0712/093213.076502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 504
[1:1:0712/093213.076650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7fa76869f070 0x2d1be6e3f2e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 483 0x7fa76a5c72e0 0x2d1be702fae0 
[1:1:0712/093213.115128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7fa76a5c72e0 0x2d1be6f61060 , "https://yule.iqiyi.com/"
[1:1:0712/093213.116483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , function udm_(e,t){var n="comScore=",r=document,i=r.cookie,s="",o="indexOf",u="substring",a="length"
[1:1:0712/093213.116714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093213.132119:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://yule.iqiyi.com/"
[1:1:0712/093213.142329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7fa76a5c72e0 0x2d1be6665360 , "https://yule.iqiyi.com/"
[1:1:0712/093213.147154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , (function(){var h={},mt={},c={id:"53b7374a63c37483e5dd97d78d9bb36e",dm:["iqiyi.com"],js:"tongji.baid
[1:1:0712/093213.147384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093213.186046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb190
[1:1:0712/093213.186349:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093213.186753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 513
[1:1:0712/093213.186999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7fa76869f070 0x2d1be6ddfae0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 486 0x7fa76a5c72e0 0x2d1be6665360 
[116704:116704:0712/093229.043687:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/093229.057446:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/093231.402730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 504, 7fa76afe4881
[1:1:0712/093231.429405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"483 0x7fa76a5c72e0 0x2d1be702fae0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093231.429807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"483 0x7fa76a5c72e0 0x2d1be702fae0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093231.430211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093231.430822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , () {
                oHead.removeChild(script);    
            }
[1:1:0712/093231.431025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093231.779736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/093231.780061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093232.960138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 513, 7fa76afe4881
[1:1:0712/093232.989752:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"486 0x7fa76a5c72e0 0x2d1be6665360 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093232.990199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"486 0x7fa76a5c72e0 0x2d1be6665360 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093232.990614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093232.991290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093232.991580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093232.992374:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093232.992577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093232.992934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 609
[1:1:0712/093232.993167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7fa76869f070 0x2d1be702f3e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 513 0x7fa76869f070 0x2d1be6ddfae0 
[1:1:0712/093233.252401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7fa76a5c72e0 0x2d1be6e260e0 , "https://yule.iqiyi.com/"
[1:1:0712/093233.253386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , MTJY0BK5BW5RUTHM('CLAnamadDF1OE42zR1WYOQA')
[1:1:0712/093233.253614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093233.300133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093233.300427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093234.642550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://yule.iqiyi.com/"
[1:1:0712/093234.643286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , g.onload, (){g.onload=u;g=window[d]=u;a&&a(b)}
[1:1:0712/093234.643551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093234.696140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 609, 7fa76afe4881
[1:1:0712/093234.727416:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"513 0x7fa76869f070 0x2d1be6ddfae0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093234.727817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"513 0x7fa76869f070 0x2d1be6ddfae0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093234.728243:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093234.728985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093234.729222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093234.729914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093234.730114:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093234.730516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 659
[1:1:0712/093234.730749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7fa76869f070 0x2d1be74adf60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 609 0x7fa76869f070 0x2d1be702f3e0 
[1:1:0712/093234.790777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093234.791072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093235.960916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093235.961220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093235.998480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 659, 7fa76afe4881
[1:1:0712/093236.012784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"609 0x7fa76869f070 0x2d1be702f3e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093236.013129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"609 0x7fa76869f070 0x2d1be702f3e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093236.013564:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093236.014144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093236.014362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093236.015020:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093236.015212:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093236.015644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 686
[1:1:0712/093236.015911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7fa76869f070 0x2d1be668ed60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 659 0x7fa76869f070 0x2d1be74adf60 
[1:1:0712/093236.458922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093236.459217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093236.581146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 686, 7fa76afe4881
[1:1:0712/093236.617251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"659 0x7fa76869f070 0x2d1be74adf60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093236.617639:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"659 0x7fa76869f070 0x2d1be74adf60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093236.618073:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093236.618626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093236.618911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093236.619572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093236.619818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093236.620193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 709
[1:1:0712/093236.620422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7fa76869f070 0x2d1be76f0560 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 686 0x7fa76869f070 0x2d1be668ed60 
[1:1:0712/093237.053749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093237.054052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.091081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 709, 7fa76afe4881
[1:1:0712/093237.106639:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"686 0x7fa76869f070 0x2d1be668ed60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.107013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"686 0x7fa76869f070 0x2d1be668ed60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.107412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093237.108015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093237.108266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.109002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093237.109204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093237.109562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 718
[1:1:0712/093237.109786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 718 0x7fa76869f070 0x2d1be77e0de0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 709 0x7fa76869f070 0x2d1be76f0560 
[1:1:0712/093237.306482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093237.306787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.418854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 718, 7fa76afe4881
[1:1:0712/093237.451222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"709 0x7fa76869f070 0x2d1be76f0560 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.451589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"709 0x7fa76869f070 0x2d1be76f0560 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.452005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093237.452597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093237.452828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.453516:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093237.453711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093237.454079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 733
[1:1:0712/093237.454310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7fa76869f070 0x2d1be732f960 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 718 0x7fa76869f070 0x2d1be77e0de0 
[1:1:0712/093237.559260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093237.559555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.602545:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 733, 7fa76afe4881
[1:1:0712/093237.634638:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"718 0x7fa76869f070 0x2d1be77e0de0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.635023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"718 0x7fa76869f070 0x2d1be77e0de0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093237.635437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093237.635993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093237.636228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.636886:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093237.637085:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093237.637492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 741
[1:1:0712/093237.637726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7fa76869f070 0x2d1be6e4e760 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 733 0x7fa76869f070 0x2d1be732f960 
[1:1:0712/093237.721031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093237.721352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.768809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093237.769107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.854475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 , "https://yule.iqiyi.com/"
[1:1:0712/093237.884814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , /*! Built by pcw player group @2019-7-12 23:01:24 */
!function(e,t){"object"==typeof exports&&"objec
[1:1:0712/093237.885165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093237.973447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x2f19636e29c8, 0x2d1be65bb1b0
[1:1:0712/093237.973725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 30000
[1:1:0712/093237.974108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 754
[1:1:0712/093237.974380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7fa76869f070 0x2d1be6e4ee60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093237.995043:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2f19636e29c8, 0x2d1be65bb1b0
[1:1:0712/093237.995361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/093237.995862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 757
[1:1:0712/093237.996128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7fa76869f070 0x2d1be769afe0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
		remove user.10_705a82ac -> 0
		remove user.10_f899838a -> 0
		remove user.11_243f5066 -> 0
		remove user.12_bbb2c681 -> 0
		remove user.13_fd2da73b -> 0
		remove user.14_f6767d3f -> 0
[1:1:0712/093238.583383:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093238.660314:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2f19636e29c8, 0x2d1be65bb1b0
[1:1:0712/093238.660703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/093238.661142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 768
[1:1:0712/093238.661407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 768 0x7fa76869f070 0x2d1be76a6b60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093240.320667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2f19636e29c8, 0x2d1be65bb1b0
[1:1:0712/093240.320867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/093240.321056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 769
[1:1:0712/093240.321167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7fa76869f070 0x2d1be84138e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093240.323663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x2f19636e29c8, 0x2d1be65bb1b0
[1:1:0712/093240.323792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/093240.323957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 770
[1:1:0712/093240.324063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7fa76869f070 0x2d1be838b760 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093240.785156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 , "https://yule.iqiyi.com/"
[1:1:0712/093241.061404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 , "https://yule.iqiyi.com/"
[1:1:0712/093241.209030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 , "https://yule.iqiyi.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/093241.492870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f19636e29c8, 0x2d1be65bb328
[1:1:0712/093241.493180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/093241.493598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 777
[1:1:0712/093241.493847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 777 0x7fa76869f070 0x2d1be86ad060 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093244.784383:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3600000, 0x2f19636e29c8, 0x2d1be65bb328
[1:1:0712/093244.784561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 3600000
[1:1:0712/093244.784735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 781
[1:1:0712/093244.784850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7fa76869f070 0x2d1be96b1a60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093246.657970:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093246.658305:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[116704:116704:0712/093247.596311:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[116704:116704:0712/093247.596375:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://yule.iqiyi.com/, https://yule.iqiyi.com
[1:1:0712/093247.604722:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "iqiyi.com", "iqiyi.com"
[116704:116704:0712/093247.629808:INFO:CONSOLE(1)] "%ciQIYI", source: https://stc.iqiyipic.com/gaze/uniqy/main/js/common.aab3c125.js (1)
[116704:116704:0712/093247.630511:INFO:CONSOLE(1)] "%c一不小心被你发现了:-)
什么都不说了,这里需要喜欢探寻秘密的你!
爱奇艺直聘网址:http://zhaopin.iqiyi.com/", source: https://stc.iqiyipic.com/gaze/uniqy/main/js/common.aab3c125.js (1)
[1:1:0712/093247.741293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f19636e29c8, 0x2d1be65bb328
[1:1:0712/093247.741543:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/093247.742065:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 782
[1:1:0712/093247.742266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 782 0x7fa76869f070 0x2d1bea0f1f60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093247.775124:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f19636e29c8, 0x2d1be65bb328
[1:1:0712/093247.775310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/093247.775497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 783
[1:1:0712/093247.775722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7fa76869f070 0x2d1bea33fce0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 
[1:1:0712/093247.777511:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 7.06211, 1, 0
[1:1:0712/093247.777684:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/093247.821354:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 741, 7fa76afe4881
[1:1:0712/093247.836456:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"733 0x7fa76869f070 0x2d1be732f960 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093247.836690:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"733 0x7fa76869f070 0x2d1be732f960 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093247.836914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093247.837224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/093247.837347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093247.856718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093247.856916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093247.857124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 800
[1:1:0712/093247.857246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7fa76869f070 0x2d1be74d3560 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 741 0x7fa76869f070 0x2d1be6e4e760 
[1:1:0712/093247.894942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093247.895134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093248.898451:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/093248.898733:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/093248.912021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 784 0x7fa76869f070 0x2d1bea5cc6e0 , "https://yule.iqiyi.com/"
[1:1:0712/093248.914272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , 
    (function() { 
        var addedParams = {
            pagec:'7',
            ptp:'2',
        
[1:1:0712/093248.914513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093248.928325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 784 0x7fa76869f070 0x2d1bea5cc6e0 , "https://yule.iqiyi.com/"
[1:1:0712/093248.937609:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://yule.iqiyi.com/"
[1:1:0712/093249.124310:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 757, 7fa76afe4881
[1:1:0712/093249.139169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.139371:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.139572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.139873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , f, (){s.browser.weixin?s.os.ios?c="02038001010000000000":s.os.android&&(c="02028001010000000000"):s.os.
[1:1:0712/093249.140056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.175199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , document.readyState
[1:1:0712/093249.175514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.179654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 768, 7fa76afe4881
[1:1:0712/093249.212216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.212428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.212720:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.213076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , P, (){c.browser.weixin?c.os.ios?E="02038001010000000000":c.os.android&&(E="02028001010000000000"):c.os.
[1:1:0712/093249.213192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.213795:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 777, 7fa76afe4881
[1:1:0712/093249.246875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.247276:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.247681:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.248256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , (){D.devtools&&et&&et.emit("init",mn)}
[1:1:0712/093249.248494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.278027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 769, 7fa76afe4881
[1:1:0712/093249.313283:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.313494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.313726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.314178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , S, (){c.browser.weixin?c.os.ios?w="02038001010000000000":c.os.android&&(w="02028001010000000000"):c.os.
[1:1:0712/093249.314303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.348930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 770, 7fa76afe4881
[1:1:0712/093249.388714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.389075:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.389551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.390173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , x, (){c.browser.weixin?c.os.ios?y="02038001010000000000":c.os.android&&(y="02028001010000000000"):c.os.
[1:1:0712/093249.390358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.391995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 782, 7fa76afe4881
[1:1:0712/093249.435784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.436224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.436706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.437369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , (){navigator.serviceWorker.register("/service-worker.js",{scope:"/"}).then(function(e){}).catch(func
[1:1:0712/093249.437602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.489211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 783, 7fa76afe4881
[1:1:0712/093249.534928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0f7ae0262860","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.535356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"744 0x7fa77ed29080 0x2d1be7043ec0 1 0 0x2d1be7043ed8 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/093249.535811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/093249.536480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 0f7ae0262860, , , (){(new g).$mount(a.a.appId)}
[1:1:0712/093249.536726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/093249.591988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/093249.592530:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://yule.iqiyi.com/, 834
[1:1:0712/093249.592803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7fa76869f070 0x2d1bea526de0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 783 0x7fa76869f070 0x2d1bea33fce0 
[1:1:0712/093249.627016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2f19636e29c8, 0x2d1be65bb150
[1:1:0712/093249.627222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 800
[1:1:0712/093249.627404:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 835
[1:1:0712/093249.627515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7fa76869f070 0x2d1be77e03e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 783 0x7fa76869f070 0x2d1bea33fce0 
[116704:116704:0712/093250.950804:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/093257.194973:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093257.195540:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/093257.196416:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.11_58f745f7 -> 0
		remove user.12_1b0ab113 -> 0
		remove user.13_24215ce7 -> 0
