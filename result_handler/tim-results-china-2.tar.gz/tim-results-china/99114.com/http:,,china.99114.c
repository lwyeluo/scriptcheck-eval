[0712/080600.864665:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/080600.865148:INFO:switcher_clone.cc(787)] backtrace rip is 7fa3f4088891
[0712/080601.957033:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/080601.957426:INFO:switcher_clone.cc(787)] backtrace rip is 7f01df5cb891
[1:1:0712/080601.969441:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/080601.969723:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/080601.975880:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[105625:105625:0712/080603.338214:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/080603.358233:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/080603.358546:INFO:switcher_clone.cc(787)] backtrace rip is 7fd8ebd47891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ecf7b266-bed0-40b8-8391-17bb75bafa8b
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[105659:105659:0712/080603.571843:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=105659
[105670:105670:0712/080603.572243:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=105670
[105625:105625:0712/080603.939884:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[105625:105655:0712/080603.940721:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/080603.940963:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/080603.941248:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/080603.941859:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/080603.942019:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/080603.945471:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1bc84484, 1
[1:1:0712/080603.945811:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x6bde395, 0
[1:1:0712/080603.945966:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31e99594, 3
[1:1:0712/080603.946122:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x14c2832a, 2
[1:1:0712/080603.946395:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff95ffffffe3ffffffbd06 ffffff8444ffffffc81b 2affffff83ffffffc214 ffffff94ffffff95ffffffe931 , 10104, 4
[1:1:0712/080603.947472:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[105625:105655:0712/080603.947722:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���D�*�����1~�Q
[105625:105655:0712/080603.947807:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���D�*�����1��~�Q
[1:1:0712/080603.947737:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01dd8060a0, 3
[1:1:0712/080603.948030:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01dd991080, 2
[105625:105655:0712/080603.948203:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/080603.948180:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01c7654d20, -2
[105625:105655:0712/080603.948303:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 105678, 4, 95e3bd06 8444c81b 2a83c214 9495e931 
[1:1:0712/080603.967249:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/080603.968174:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14c2832a
[1:1:0712/080603.969178:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14c2832a
[1:1:0712/080603.971203:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14c2832a
[1:1:0712/080603.973057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.973321:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.973563:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.973813:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.974618:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14c2832a
[1:1:0712/080603.975027:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f01df5cb7ba
[1:1:0712/080603.975147:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f01df5c2def, 7f01df5cb77a, 7f01df5cd0cf
[1:1:0712/080603.976719:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14c2832a
[1:1:0712/080603.976882:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14c2832a
[1:1:0712/080603.977157:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14c2832a
[1:1:0712/080603.977855:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.977970:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.978065:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.978171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14c2832a
[1:1:0712/080603.978632:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14c2832a
[1:1:0712/080603.978796:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f01df5cb7ba
[1:1:0712/080603.978871:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f01df5c2def, 7f01df5cb77a, 7f01df5cd0cf
[1:1:0712/080603.981332:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/080603.981610:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/080603.981709:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd14d39b58, 0x7ffd14d39ad8)
[1:1:0712/080603.997893:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/080604.004025:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[105625:105625:0712/080604.532247:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080604.533148:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080604.550961:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[105625:105637:0712/080604.551065:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080604.551361:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[105625:105625:0712/080604.551474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[105625:105625:0712/080604.551635:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,105678, 4
[1:7:0712/080604.554470:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[105625:105648:0712/080604.630555:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/080604.686349:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x7733945a220
[1:1:0712/080604.691893:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/080605.160284:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[105625:105625:0712/080607.075063:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[105625:105625:0712/080607.075299:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/080607.105715:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080607.110255:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080608.056991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/080608.057336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080608.069853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/080608.070146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080608.144565:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080608.496940:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080608.497237:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080608.846314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080608.854575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/080608.854905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080608.893600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080608.906895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/080608.907191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080608.919453:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[105625:105625:0712/080608.922472:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/080608.922956:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x77339458e20
[1:1:0712/080608.923188:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[105625:105625:0712/080608.929915:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[105625:105625:0712/080608.959973:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[105625:105625:0712/080608.960142:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/080609.025736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080610.078083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f01c922f2e0 0x773396db5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080610.079493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/080610.079837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080610.081374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080610.159704:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x77339459820
[105625:105625:0712/080610.159899:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/080610.160013:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[105625:105625:0712/080610.164677:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/080610.182825:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/080610.183115:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[105625:105625:0712/080610.186933:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[105625:105625:0712/080610.201630:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080610.204373:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080610.210549:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[105625:105637:0712/080610.210641:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080610.210818:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[105625:105625:0712/080610.210896:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[105625:105625:0712/080610.211061:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,105678, 4
[1:7:0712/080610.214443:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080610.839225:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/080611.330281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f01c922f2e0 0x773397f0060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080611.331429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/080611.331803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080611.332568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[105625:105625:0712/080611.412693:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[105625:105655:0712/080611.413128:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/080611.413376:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/080611.413647:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/080611.414914:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/080611.415060:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/080611.418379:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3aa5fa52, 1
[1:1:0712/080611.419610:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x236bceea, 0
[1:1:0712/080611.419766:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2afb2de0, 3
[1:1:0712/080611.419910:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ff4cb7f, 2
[1:1:0712/080611.420061:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffeaffffffce6b23 52fffffffaffffffa53a 7fffffffcbfffffff41f ffffffe02dfffffffb2a , 10104, 5
[1:1:0712/080611.420931:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[105625:105655:0712/080611.421094:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��k#R��:���-�*��Q
[105625:105655:0712/080611.421137:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��k#R��:���-�*���Q
[1:1:0712/080611.421209:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01dd8060a0, 3
[105625:105655:0712/080611.421401:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 105723, 5, eace6b23 52faa53a 7fcbf41f e02dfb2a 
[1:1:0712/080611.421327:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01dd991080, 2
[1:1:0712/080611.421584:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f01c7654d20, -2
[1:1:0712/080611.436713:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080611.446307:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/080611.446713:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ff4cb7f
[1:1:0712/080611.447121:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ff4cb7f
[1:1:0712/080611.447904:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ff4cb7f
[1:1:0712/080611.449647:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.449909:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.450146:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.450376:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.451178:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ff4cb7f
[1:1:0712/080611.451539:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f01df5cb7ba
[1:1:0712/080611.451710:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f01df5c2def, 7f01df5cb77a, 7f01df5cd0cf
[1:1:0712/080611.458762:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ff4cb7f
[1:1:0712/080611.459286:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ff4cb7f
[1:1:0712/080611.460218:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ff4cb7f
[1:1:0712/080611.462762:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.463031:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.463272:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.463524:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff4cb7f
[1:1:0712/080611.465092:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ff4cb7f
[1:1:0712/080611.465582:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f01df5cb7ba
[1:1:0712/080611.465758:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f01df5c2def, 7f01df5cb77a, 7f01df5cd0cf
[1:1:0712/080611.474397:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/080611.474941:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/080611.475092:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd14d39b58, 0x7ffd14d39ad8)
[105625:105625:0712/080611.482513:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[105625:105625:0712/080611.482613:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/080611.490158:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/080611.494138:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/080611.705347:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x77339441220
[1:1:0712/080611.705647:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/080611.917937:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080612.458718:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080612.459010:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080612.775806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080612.780260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/080612.780563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080612.787163:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080612.925708:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/080612.926535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1633c1361f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/080612.926783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/080613.002991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080613.004760:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/080613.005051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/080613.005336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080613.139105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080613.140143:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/080613.140399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/080613.140668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080613.508553:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/080613.935655:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/080614.032779:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/080614.078379:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/080614.140402:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/080614.181392:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/080614.281389:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/080614.326670:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/080614.398550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080614.399555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080614.399870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080614.504539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080614.505521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080614.505811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080614.788089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080614.789331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080614.789591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080614.960025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080614.960962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080614.961207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.043245:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.043753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.043893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.092756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.093674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.093915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.191930:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.192465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.192613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.217347:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.218245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.218492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.268518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.269471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.269730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.321939:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.322481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.322635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.423722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.424598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.424752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.455816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.456319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.456533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.478732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.479223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.479363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.509212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.509726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.509874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.569837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.570741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/080615.570888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/080615.671022:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/080615.672208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1633c148e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/080615.672549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[105625:105625:0712/080616.109301:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('http://china.99114.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[105625:105625:0712/080617.376122:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080617.377978:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080617.390746:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[105625:105637:0712/080617.390850:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080617.390981:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://china.99114.com/
[105625:105625:0712/080617.391079:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://china.99114.com/, http://china.99114.com/106/, 1
[105625:105625:0712/080617.391263:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://china.99114.com/, HTTP/1.1 200 Server: Tengine Date: Fri, 12 Jul 2019 15:06:17 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: en-US Content-Encoding: gzip  ,105723, 5
[1:7:0712/080617.394955:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080617.412609:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://china.99114.com/
[105625:105625:0712/080617.499185:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://china.99114.com/, http://china.99114.com/, 1
[105625:105625:0712/080617.499618:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://china.99114.com/, http://china.99114.com
[1:1:0712/080617.587198:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080617.747913:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080617.798224:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080617.852385:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080617.852700:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080618.003215:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080618.257120:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080618.358033:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080618.578385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f01c766fbd0 0x773396869d8 , "http://china.99114.com/106/"
[1:1:0712/080618.583406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , // JavaScript Document
/*! jQuery v@1.8.0 jquery.com | jquery.org/license */
(function(a,b){function
[1:1:0712/080618.583611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080618.584448:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080618.766257:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f01c766fbd0 0x773396869d8 , "http://china.99114.com/106/"
[1:1:0712/080618.788313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f01c766fbd0 0x773396869d8 , "http://china.99114.com/106/"
[1:1:0712/080618.800465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7f01c766fbd0 0x773396869d8 , "http://china.99114.com/106/"
[1:1:0712/080618.807394:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/080618.836926:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x7733943e020
[1:1:0712/080618.837143:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/080618.866036:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/080618.866241:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0712/080619.023955:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.259238, 557, 1
[1:1:0712/080619.024239:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080619.379025:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080619.379248:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080619.381308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f01c7307070 0x77339824260 , "http://china.99114.com/106/"
[1:1:0712/080619.387266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , 
    /**
     * Created by duanz on 2015/12/22.
     */

    (function($){
        /**初始化基�
[1:1:0712/080619.387497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080619.399640:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f01c7307070 0x77339824260 , "http://china.99114.com/106/"
[1:1:0712/080619.481065:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 234 0x7f01c7307070 0x77339824260 , "http://china.99114.com/106/"
[1:1:0712/080619.505100:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.125897, 117, 1
[1:1:0712/080619.505499:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080619.788825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 256 0x7f01c922f2e0 0x7733968dce0 , "http://china.99114.com/106/"
[1:1:0712/080619.789658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , /////////////工具类/////////////////////////////////////////////////////
/**
 * 判断浏览器�
[1:1:0712/080619.789773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080619.799830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a9d8
[1:1:0712/080619.800060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080619.800398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 281
[1:1:0712/080619.800598:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 281 0x7f01c7307070 0x7733968efe0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 256 0x7f01c922f2e0 0x7733968dce0 
[1:1:0712/080619.970937:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080619.971120:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080619.975348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 276 0x7f01c7307070 0x773397efde0 , "http://china.99114.com/106/"
[1:1:0712/080619.983573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , var INTERACTIVE_PLUGIN=function(exports){"use strict";function getUID(){function t(t){var e,n=1,i=0;
[1:1:0712/080619.983735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080621.153735:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080621.157878:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080621.158341:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080621.158873:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080621.159276:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[105625:105625:0712/080639.537868:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[105625:105625:0712/080639.544496:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[105625:105625:0712/080639.559483:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[105625:105625:0712/080639.645459:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/080639.659038:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/080639.752857:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.7818, 0, 0
[1:1:0712/080639.753185:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[105625:105625:0712/080639.769612:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080639.776149:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080639.821048:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[105625:105637:0712/080639.821180:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080639.821424:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://trusted.shuidi.cn/
[105625:105625:0712/080639.821531:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://trusted.shuidi.cn/, http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0, 4
[105625:105625:0712/080639.821718:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://trusted.shuidi.cn/, HTTP/1.1 200 OK Server: nginx/1.9.12 Date: Fri, 12 Jul 2019 15:06:39 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Access-Control-Allow-Origin: http://cha.shuidi.cn Access-Control-Allow-Methods: POST,GET Access-Control-Allow-Credentials: true Content-Encoding: gzip  ,105723, 5
[1:1:0712/080639.823222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 281, 7f01c9c4c881
[1:7:0712/080639.827736:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080639.840179:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"256 0x7f01c922f2e0 0x7733968dce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080639.840630:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"256 0x7f01c922f2e0 0x7733968dce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080639.841163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080639.841826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080639.842119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080639.843019:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080639.843227:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080639.843730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 329
[1:1:0712/080639.844103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 329 0x7f01c7307070 0x77339820360 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 281 0x7f01c7307070 0x7733968efe0 
[1:1:0712/080639.934104:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","http://static.99114.cn/static/portal/imagesv4/logo.png"
[1:1:0712/080639.956747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/080639.957046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080640.459674:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080640.459990:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080640.461215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318 0x7f01c7307070 0x77339696d60 , "http://china.99114.com/106/"
[1:1:0712/080640.462173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , 
                INTERACTIVE_PLUGIN.render({
                    showid: 'kRmhRE',
                 
[1:1:0712/080640.462396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080640.481590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a053a3229c8, 0x7733906a998
[1:1:0712/080640.481885:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080640.482308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 342
[1:1:0712/080640.482581:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 342 0x7f01c7307070 0x7733903e3e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 318 0x7f01c7307070 0x77339696d60 
[1:1:0712/080640.508992:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.048944, 96, 1
[1:1:0712/080640.509328:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080640.719016:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://trusted.shuidi.cn/
[1:1:0712/080640.751866:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 329, 7f01c9c4c881
[1:1:0712/080640.770666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"281 0x7f01c7307070 0x7733968efe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080640.771070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"281 0x7f01c7307070 0x7733968efe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080640.771402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080640.772041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080640.772277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080640.772989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080640.773203:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080640.773648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 353
[1:1:0712/080640.773895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 353 0x7f01c7307070 0x77339683a60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 329 0x7f01c7307070 0x77339820360 
[1:1:0712/080640.947908:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080640.948247:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080640.949063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346 0x7f01c7307070 0x7733968e460 , "http://china.99114.com/106/"
[1:1:0712/080640.949978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , 
                    var mediav_ad_pub = 'HHqMvu_2335583';
                    var mediav_ad_width =
[1:1:0712/080640.950205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080640.956213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346 0x7f01c7307070 0x7733968e460 , "http://china.99114.com/106/"
[105625:105625:0712/080640.999533:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/080641.000318:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x7733981a420
[1:1:0712/080641.000610:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[105625:105625:0712/080641.007380:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ifr2335583, 5, 5, 
[1:1:0712/080641.022190:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/080641.022504:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[105625:105625:0712/080641.025140:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[1:1:0712/080641.028494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 12000, 0x2a053a3229c8, 0x7733906aae0
[1:1:0712/080641.028751:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 12000
[1:1:0712/080641.029131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 371
[1:1:0712/080641.029361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 371 0x7f01c7307070 0x773397d8fe0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 346 0x7f01c7307070 0x7733968e460 
[1:1:0712/080641.030177:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a053a3229c8, 0x7733906aae0
[1:1:0712/080641.030383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0712/080641.030745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 372
[1:1:0712/080641.030979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7f01c7307070 0x77339688660 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 346 0x7f01c7307070 0x7733968e460 
[105625:105625:0712/080641.121648:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080641.123445:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080641.147156:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[105625:105637:0712/080641.147258:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080641.147521:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://show.g.mediav.com/
[105625:105625:0712/080641.147623:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://show.g.mediav.com/, http://show.g.mediav.com/s?ver=1.2.8&enifr=1&showid=HHqMvu&type=1&of=2&uid=15629440009847926177307303175943&isifr=0&title=%E3%80%90%E7%BA%B8%E4%B8%9A%E3%80%91%E4%BC%81%E4%B8%9A%E5%90%8D%E5%BD%95_%E4%BC%81%E4%B8%9A%E9%BB%84%E9%A1%B5_%E4%BC%81%E4%B8%9A%E5%A4%A7%E5%85%A8-%E4%B8%AD&refurl=, 5
[105625:105625:0712/080641.147850:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://show.g.mediav.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 15:06:41 GMT Content-Type: image/gif Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Pragma: no-cache P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Cache-Control: no-cache, must-revalidate Content-Encoding: gzip  ,105723, 5
[1:7:0712/080641.152334:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080641.286650:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.33835, 2008, 1
[1:1:0712/080641.286987:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[105625:105625:0712/080641.418578:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://trusted.shuidi.cn/, http://trusted.shuidi.cn/, 4
[105625:105625:0712/080641.418716:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://trusted.shuidi.cn/, http://trusted.shuidi.cn
[1:1:0712/080641.422850:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/080641.429715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 353, 7f01c9c4c881
[1:1:0712/080641.445734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"329 0x7f01c7307070 0x77339820360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080641.446130:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"329 0x7f01c7307070 0x77339820360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080641.446455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080641.447066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080641.447333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080641.448361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080641.448595:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080641.449020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 402
[1:1:0712/080641.449348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 402 0x7f01c7307070 0x7733990e4e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 353 0x7f01c7307070 0x77339683a60 
[1:1:0712/080644.624381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080644.624720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080645.006640:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://show.g.mediav.com/
[1:1:0712/080645.034657:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080645.034949:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080645.039910:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f01c7307070 0x77339911ce0 , "http://china.99114.com/106/"
[1:1:0712/080645.057979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , var BANNER_SLIDER=function(){"use strict";Date.now||(Date.now=function(){return+new Date}),Function.
[1:1:0712/080645.058278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080645.211509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f01c7307070 0x77339911ce0 , "http://china.99114.com/106/"
[1:1:0712/080645.319996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a053a3229c8, 0x7733906a998
[1:1:0712/080645.320285:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080645.320674:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 460
[1:1:0712/080645.320934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 460 0x7f01c7307070 0x77339817be0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 385 0x7f01c7307070 0x77339911ce0 
[1:1:0712/080645.420956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a053a3229c8, 0x7733906a998
[1:1:0712/080645.421242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080645.421722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 468
[1:1:0712/080645.421972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 468 0x7f01c7307070 0x773397acb60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 385 0x7f01c7307070 0x77339911ce0 
[1:1:0712/080645.462938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f01c7307070 0x77339911ce0 , "http://china.99114.com/106/"
[1:1:0712/080645.467216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f01c7307070 0x77339911ce0 , "http://china.99114.com/106/"
[105625:105625:0712/080645.469985:INFO:CONSOLE(2899)] "Uncaught SyntaxError: Unexpected end of input", source: http://china.99114.com/106/ (2899)
[1:1:0712/080645.472012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f01c7307070 0x77339911ce0 , "http://china.99114.com/106/"
[105625:105625:0712/080645.515997:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/080645.517848:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x77339c53e20
[1:1:0712/080645.518127:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[105625:105625:0712/080645.522464:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ifr2335584, 6, 6, 
[1:1:0712/080645.542073:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/080645.542277:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[1:1:0712/080645.546215:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a053a3229c8, 0x7733906aad0
[1:1:0712/080645.546391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0712/080645.546715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 493
[1:1:0712/080645.546938:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 493 0x7f01c7307070 0x7733a379a60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 385 0x7f01c7307070 0x77339911ce0 
[105625:105625:0712/080645.548841:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[1:1:0712/080645.549828:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.514708, 21, 0
[1:1:0712/080645.550023:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080645.552558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 372, 7f01c9c4c881
[1:1:0712/080645.574757:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"346 0x7f01c7307070 0x7733968e460 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080645.575095:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"346 0x7f01c7307070 0x7733968e460 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080645.575434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080645.576005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){try{j.onclick=function(p){var q=this,p=p||event;mediav[h]();mediav.ad.lisenClick(p,q,d,c,m)}}catc
[1:1:0712/080645.576188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[105625:105625:0712/080645.607015:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080645.613116:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/080645.627711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 391 0x7f01c922f2e0 0x773397effe0 , "http://china.99114.com/106/"
[1:1:0712/080645.628424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){ var json={"ads":[{"clktk":["http://xdssp.mediav.com/s?type=13&r=20&an=__ACT_NUM__&uai=F
[1:1:0712/080645.628545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080645.630630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a990
[1:1:0712/080645.630744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080645.630943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 498
[1:1:0712/080645.631061:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7f01c7307070 0x7733a392060 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 391 0x7f01c922f2e0 0x773397effe0 
[105625:105637:0712/080645.652856:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[105625:105637:0712/080645.653003:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080645.653257:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://show.g.mediav.com/
[105625:105625:0712/080645.653349:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://show.g.mediav.com/, http://show.g.mediav.com/s?ver=1.2.8&enifr=1&showid=sB1ZYl&type=1&of=2&uid=15629440009847926177307303175943&isifr=0&title=%E3%80%90%E7%BA%B8%E4%B8%9A%E3%80%91%E4%BC%81%E4%B8%9A%E5%90%8D%E5%BD%95_%E4%BC%81%E4%B8%9A%E9%BB%84%E9%A1%B5_%E4%BC%81%E4%B8%9A%E5%A4%A7%E5%85%A8-%E4%B8%AD&refurl=, 6
[105625:105625:0712/080645.653515:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://show.g.mediav.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 15:06:45 GMT Content-Type: image/gif Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Pragma: no-cache P3P: CP="CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Cache-Control: no-cache, must-revalidate Content-Encoding: gzip  ,105723, 5
[1:1:0712/080645.653612:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:7:0712/080645.659139:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080645.711044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 402, 7f01c9c4c881
[1:1:0712/080645.723570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"353 0x7f01c7307070 0x77339683a60 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080645.724071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"353 0x7f01c7307070 0x77339683a60 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080645.724435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080645.725003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080645.725184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080645.725913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080645.726108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080645.726435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 506
[1:1:0712/080645.726623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 506 0x7f01c7307070 0x7733a3a4960 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 402 0x7f01c7307070 0x7733990e4e0 
[1:1:0712/080646.950121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080646.950445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[105625:105625:0712/080647.330851:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://show.g.mediav.com/, http://show.g.mediav.com/, 5
[105625:105625:0712/080647.330960:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://show.g.mediav.com/, http://show.g.mediav.com
[1:1:0712/080648.542884:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080648.543142:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080648.564321:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.021091, 98, 1
[1:1:0712/080648.564598:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080648.609523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 498, 7f01c9c4c881
[1:1:0712/080648.634889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"391 0x7f01c922f2e0 0x773397effe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080648.635249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"391 0x7f01c922f2e0 0x773397effe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080648.635578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080648.636079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var i;try{i=n(t._value)}catch(o){retur
[1:1:0712/080648.636303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080648.823996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 493, 7f01c9c4c881
[1:1:0712/080648.849410:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"385 0x7f01c7307070 0x77339911ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080648.849775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"385 0x7f01c7307070 0x77339911ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080648.850174:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080648.850799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){try{j.onclick=function(p){var q=this,p=p||event;mediav[h]();mediav.ad.lisenClick(p,q,d,c,m)}}catc
[1:1:0712/080648.851044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080648.896292:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080648.896555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080648.920498:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0237799, 58, 1
[1:1:0712/080648.920794:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080648.979715:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://show.g.mediav.com/
[1:1:0712/080649.011895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 506, 7f01c9c4c881
[1:1:0712/080649.038410:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"402 0x7f01c7307070 0x7733990e4e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080649.038796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"402 0x7f01c7307070 0x7733990e4e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080649.039142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080649.039752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080649.040035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080649.040715:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080649.040971:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080649.041440:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 590
[1:1:0712/080649.041694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 590 0x7f01c7307070 0x7733a3cd860 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 506 0x7f01c7307070 0x7733a3a4960 
[1:1:0712/080649.483108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080649.483405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/080652.168327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558 0x7f01c922f2e0 0x77339b96160 , "http://china.99114.com/106/"
[1:1:0712/080652.169374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){
var json=	[];
window['QIHOO__WEB__SO__BANNER_SLIDER1562944005225Z8TH40'](json);
})();
[1:1:0712/080652.169601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080652.272289:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080652.272521:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://china.99114.com/106/"
[1:1:0712/080652.273311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f01c7307070 0x77339f15ee0 , "http://china.99114.com/106/"
[1:1:0712/080652.274217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){document.getElementById('___szfw_logo___').oncontextmenu = function(){return false;}})()
[1:1:0712/080652.274394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080652.278512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f01c7307070 0x77339f15ee0 , "http://china.99114.com/106/"
[1:1:0712/080652.282162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f01c7307070 0x77339f15ee0 , "http://china.99114.com/106/"
[1:1:0712/080652.287193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f01c7307070 0x77339f15ee0 , "http://china.99114.com/106/"
[1:1:0712/080652.307651:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080652.389105:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f01c7307070 0x77339f15ee0 , "http://china.99114.com/106/"
[1:1:0712/080652.450054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0712/080652.450479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 654
[1:1:0712/080652.450673:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f01c7307070 0x7733a3a40e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 565 0x7f01c7307070 0x77339f15ee0 
[1:1:0712/080652.546128:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a053a3229c8, 0x7733906a9a0
[1:1:0712/080652.546371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080652.546713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 656
[1:1:0712/080652.546926:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f01c7307070 0x77339978760 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 565 0x7f01c7307070 0x77339f15ee0 
[1:1:0712/080652.566884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[1:1:0712/080653.065364:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[1:1:0712/080653.084351:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2a053a3229c8, 0x7733906a9e0
[1:1:0712/080653.084633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080653.085063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 668
[1:1:0712/080653.085302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7f01c7307070 0x77339a18ee0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 565 0x7f01c7307070 0x77339f15ee0 
[105625:105625:0712/080653.130916:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/080653.133298:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x77339cfd020
[1:1:0712/080653.133509:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[105625:105625:0712/080653.139808:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0712/080653.160164:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/080653.160389:INFO:render_frame_impl.cc(7019)] 	 [url] = http://china.99114.com
[105625:105625:0712/080653.162731:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://china.99114.com/
[1:1:0712/080653.163755:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[1:1:0712/080653.164547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://china.99114.com/106/"
[105625:105625:0712/080653.225911:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[105625:105625:0712/080653.232183:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[105625:105637:0712/080653.267417:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[105625:105637:0712/080653.267513:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[105625:105625:0712/080653.267675:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://cjhd.mediav.com/
[105625:105625:0712/080653.267753:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://cjhd.mediav.com/, http://cjhd.mediav.com/games/wheel.html?&si=kRmhRE&containerID=QIHOO__INTERACTIVE_PLUGIN1562944000466&t=1562944013126, 7
[105625:105625:0712/080653.267893:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://cjhd.mediav.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 15:06:53 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Last-Modified: Thu, 15 Nov 2018 03:47:49 GMT Vary: Accept-Encoding Cache-Control: max-age=7200 Content-Encoding: gzip Expires: Fri, 12 Jul 2019 17:06:53 GMT KCS-Via: HIT from w-fc03.bjyt;HIT from w-sc04.bjyt  ,105723, 5
[1:7:0712/080653.273280:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/080653.652820:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/080653.653129:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080653.839011:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 584, "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080653.840469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://trusted.shuidi.cn/, 14fb78152eb0, , , function got_url(url) {
    var script = document.createElement('script');
    script.type = 'text/j
[1:1:0712/080653.840737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0", "trusted.shuidi.cn", 4, 1, http://china.99114.com, china.99114.com, 3
[1:1:0712/080654.038752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://china.99114.com/106/"
[1:1:0712/080654.039572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , h, (a){return typeof p!="undefined"&&(!a||p.event.triggered!==a.type)?p.event.dispatch.apply(h.elem,arg
[1:1:0712/080654.039901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[105625:105625:0712/080654.041949:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://show.g.mediav.com/, http://show.g.mediav.com/, 6
[105625:105625:0712/080654.042001:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://show.g.mediav.com/, http://show.g.mediav.com
[1:1:0712/080654.128328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 590, 7f01c9c4c881
[1:1:0712/080654.158655:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"506 0x7f01c7307070 0x7733a3a4960 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080654.159040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"506 0x7f01c7307070 0x7733a3a4960 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080654.159465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080654.159990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080654.160162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080654.160913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080654.161069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080654.161416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 735
[1:1:0712/080654.161606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f01c7307070 0x7733a447360 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 590 0x7f01c7307070 0x7733a3cd860 
[1:1:0712/080654.234236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080654.234510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080654.485631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 460, 7f01c9c4c881
[1:1:0712/080654.520743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"385 0x7f01c7307070 0x77339911ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080654.521149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"385 0x7f01c7307070 0x77339911ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080654.521646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080654.522300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){f(),n&&n(new Error("Timeout"))}
[1:1:0712/080654.522561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080654.564728:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080654.565021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 1000
[1:1:0712/080654.565465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 741
[1:1:0712/080654.565726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f01c7307070 0x7733a3ab7e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 460 0x7f01c7307070 0x77339817be0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/080657.331041:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_http://cjhd.mediav.com/
[1:1:0712/080657.379175:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 654, 7f01c9c4c8db
[1:1:0712/080657.415155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"565 0x7f01c7307070 0x77339f15ee0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080657.415537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"565 0x7f01c7307070 0x77339f15ee0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080657.416019:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 853
[1:1:0712/080657.416298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 853 0x7f01c7307070 0x7733a3b3060 , 5:3_http://china.99114.com/, 0, , 654 0x7f01c7307070 0x7733a3a40e0 
[1:1:0712/080657.416631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080657.417236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){s.data&&(o(s.data),window.clearInterval(t))}
[1:1:0712/080657.417464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080657.424276:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 371, 7f01c9c4c881
[1:1:0712/080657.445884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"346 0x7f01c7307070 0x7733968e460 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080657.446254:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"346 0x7f01c7307070 0x7733968e460 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080657.446669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080657.447289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , f, (){var q=null,o=null,l=curDateStamp=(new Date()).valueOf(),n=60000;if(!e()){var m=b.pub;o=mediav.G(g
[1:1:0712/080657.447509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080657.455655:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 800
[1:1:0712/080657.456072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 856
[1:1:0712/080657.456323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 856 0x7f01c7307070 0x773390bc5e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 371 0x7f01c7307070 0x773397d8fe0 
[1:1:0712/080657.795892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7f01dd991080 0x77339c986a0 1 0 0x77339c986b8 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080657.818644:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080657.819102:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/080657.829671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://trusted.shuidi.cn/, 14fb78152eb0, , , /*! jQuery v1.7.1 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0712/080657.830068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0", "trusted.shuidi.cn", 4, 1, http://china.99114.com, china.99114.com, 3
[1:1:0712/080657.958205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7f01dd991080 0x77339c986a0 1 0 0x77339c986b8 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080657.979372:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7f01dd991080 0x77339c986a0 1 0 0x77339c986b8 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080658.112460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7f01dd991080 0x77339c986a0 1 0 0x77339c986b8 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080658.117432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7f01dd991080 0x77339c986a0 1 0 0x77339c986b8 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080658.131644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080658.575187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 735, 7f01c9c4c881
[1:1:0712/080658.608165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"590 0x7f01c7307070 0x7733a3cd860 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080658.608370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"590 0x7f01c7307070 0x7733a3cd860 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080658.608649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080658.608998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080658.609142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080658.609513:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080658.609626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080658.609801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 912
[1:1:0712/080658.609913:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7f01c7307070 0x7733af6f5e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 735 0x7f01c7307070 0x7733a447360 
[1:1:0712/080658.624320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080658.624645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080658.876158:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 756 0x7f01c922f2e0 0x77339f249e0 , "http://china.99114.com/106/"
[1:1:0712/080658.878300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , get360mvDormerAd({"\u5bb6\u7535":[{"curl":"http:\/\/redirect.simba.taobao.com\/rd?c=un&w=unionsem&k=
[1:1:0712/080658.878422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080658.916243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 757 0x7f01c922f2e0 0x77339d308e0 , "http://china.99114.com/106/"
[1:1:0712/080658.917019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/080658.917141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/080659.711249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 741, 7f01c9c4c881
[1:1:0712/080659.762132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"460 0x7f01c7307070 0x77339817be0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080659.762530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"460 0x7f01c7307070 0x77339817be0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080659.763050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080659.763750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){pt(o+"-info",o+"-wrapper",a)}
[1:1:0712/080659.764002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080659.953622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 787 0x7f01c922f2e0 0x773399f9ce0 , "http://china.99114.com/106/"
[1:1:0712/080659.954291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){
var json=	[];
window['QIHOO__WEB__SO__BANNER_SLIDER15629440123935DEE30'](json);
})();
[1:1:0712/080659.954426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080659.964051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x2a053a3229c8, 0x7733906a988
[1:1:0712/080659.964189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 1000
[1:1:0712/080659.964359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 973
[1:1:0712/080659.964467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7f01c7307070 0x7733ad200e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 787 0x7f01c922f2e0 0x773399f9ce0 
[1:1:0712/080659.965419:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 5000
[1:1:0712/080659.965595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 974
[1:1:0712/080659.965701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f01c7307070 0x7733ad212e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 787 0x7f01c922f2e0 0x773399f9ce0 
[1:1:0712/080659.998169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7f01c922f2e0 0x77339d18d60 , "http://china.99114.com/106/"
[1:1:0712/080659.999354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , jQuery1800051663804508474964_1562943978734({"jsonValue":[["燕麦","珍珠","化纤布","红枣","�
[1:1:0712/080659.999595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080700.000756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://china.99114.com/106/"
[105625:105625:0712/080700.046165:INFO:CONSOLE(1631)] "<span>热门搜索：</span><a href='http://gongying.99114.com/listing/燕麦' target='_blank'>燕麦</a><a href='http://gongying.99114.com/listing/珍珠' target='_blank'>珍珠</a><a href='http://gongying.99114.com/listing/化纤布' target='_blank'>化纤布</a><a href='http://gongying.99114.com/listing/红枣' target='_blank'>红枣</a><a href='http://gongying.99114.com/listing/核桃' target='_blank'>核桃</a><a href="http://www.99114.com/gy_huizong" target="_blank">更多</a>", source: http://china.99114.com/106/ (1631)
[1:1:0712/080700.280777:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 795 0x7f01c922f2e0 0x77339d104e0 , "http://china.99114.com/106/"
[1:1:0712/080700.282215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){
var json={"ads":[{"clktk":["http://max-l.mediav.com/rtb?type=3&ver=1&v=CGQSEDEzNzY1MTQz
[1:1:0712/080700.282435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080700.286176:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a990
[1:1:0712/080700.286353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080700.286685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 985
[1:1:0712/080700.286879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f01c7307070 0x77339a183e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 795 0x7f01c922f2e0 0x77339d104e0 
[1:1:0712/080700.330188:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f01c922f2e0 0x7733a097ee0 , "http://china.99114.com/106/"
[1:1:0712/080700.331139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , jQuery1800051663804508474964_1562943978735({"jsonValue":[],"status":0})
[1:1:0712/080700.331350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080700.332073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://china.99114.com/106/"
[1:1:0712/080701.508181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 825 0x7f01c922f2e0 0x77339ceb0e0 , "http://china.99114.com/106/"
[1:1:0712/080701.509951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (function(){var h={},mt={},c={id:"f160a8c6f9e75fcc0c45d38950c1b318",dm:["99114.com","maiganguan.com"
[1:1:0712/080701.510096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080701.542026:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a053a3229c8, 0x7733906a990
[1:1:0712/080701.542283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0712/080701.542628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 1034
[1:1:0712/080701.542823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7f01c7307070 0x7733b1aac60 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 825 0x7f01c922f2e0 0x77339ceb0e0 
[105625:105625:0712/080701.884380:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/080702.688251:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[105625:105625:0712/080702.694112:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://cjhd.mediav.com/, http://cjhd.mediav.com/, 7
[105625:105625:0712/080702.694243:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://cjhd.mediav.com/, http://cjhd.mediav.com
[1:1:0712/080703.728225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f01c922f2e0 0x77339824c60 , "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0"
[1:1:0712/080703.729252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://trusted.shuidi.cn/, 14fb78152eb0, , , 
got_url("//source.pacra.cn/pa/resource/js/Pa_Pa.js?v=201907121830")
[1:1:0712/080703.729514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://trusted.shuidi.cn/?did=1022&jump=0&mobile=0", "trusted.shuidi.cn", 4, 1, http://china.99114.com, china.99114.com, 3
[1:1:0712/080703.873555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 856, 7f01c9c4c8db
[1:1:0712/080703.905975:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"371 0x7f01c7307070 0x773397d8fe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080703.906291:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"371 0x7f01c7307070 0x773397d8fe0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080703.906728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://china.99114.com/, 1141
[1:1:0712/080703.906947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7f01c7307070 0x7733b12ea60 , 5:3_http://china.99114.com/, 0, , 856 0x7f01c7307070 0x773390bc5e0 
[1:1:0712/080703.907289:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080703.907832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){curDateStamp=(new Date()).valueOf();if(e()){window.clearInterval(q);o&&(o.style.display="none");p
[1:1:0712/080703.908061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080704.317550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , document.readyState
[1:1:0712/080704.317752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080704.319087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 912, 7f01c9c4c881
[1:1:0712/080704.344826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"735 0x7f01c7307070 0x7733a447360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080704.345159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"735 0x7f01c7307070 0x7733a447360 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080704.345571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080704.346126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){
            if( isReady ) return;
            if (/loaded|complete/.test(document.readyState))
 
[1:1:0712/080704.346307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080704.346940:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080704.347125:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080704.347471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 1155
[1:1:0712/080704.347665:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1155 0x7f01c7307070 0x7733b31c8e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 912 0x7f01c7307070 0x7733af6f5e0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/080707.021645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 985, 7f01c9c4c881
[1:1:0712/080707.038833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"795 0x7f01c922f2e0 0x77339d104e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080707.039030:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"795 0x7f01c922f2e0 0x77339d104e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080707.039238:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080707.039550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var i;try{i=n(t._value)}catch(o){retur
[1:1:0712/080707.039671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080707.049902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080707.050058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 0
[1:1:0712/080707.050270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 1286
[1:1:0712/080707.050384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7f01c7307070 0x7733b1b3960 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 985 0x7f01c7307070 0x77339a183e0 
[1:1:0712/080708.007110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 973, 7f01c9c4c881
[1:1:0712/080708.024795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"787 0x7f01c922f2e0 0x773399f9ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080708.024996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"787 0x7f01c922f2e0 0x773399f9ce0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080708.025236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080708.025565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , , (){pt(o+"-info",o+"-wrapper",a)}
[1:1:0712/080708.025671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080710.330087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 1034, 7f01c9c4c881
[1:1:0712/080710.378000:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"14fb78022860","ptid":"825 0x7f01c922f2e0 0x77339ceb0e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080710.378444:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://china.99114.com/","ptid":"825 0x7f01c922f2e0 0x77339ceb0e0 ","rf":"5:3_http://china.99114.com/"}
[1:1:0712/080710.378940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://china.99114.com/106/"
[1:1:0712/080710.379520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://china.99114.com/, 14fb78022860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/080710.379750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://china.99114.com/106/", "china.99114.com", 3, 1, , , 0
[1:1:0712/080710.380510:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2a053a3229c8, 0x7733906a950
[1:1:0712/080710.380704:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://china.99114.com/106/", 100
[1:1:0712/080710.381119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://china.99114.com/, 1327
[1:1:0712/080710.381363:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7f01c7307070 0x7733b3d00e0 , 5:3_http://china.99114.com/, 1, -5:3_http://china.99114.com/, 1034 0x7f01c7307070 0x7733b1aac60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/080711.891224:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/080712.530744:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","http://static.99114.cn/static/portal/imagesv4/sel_ico.png"
