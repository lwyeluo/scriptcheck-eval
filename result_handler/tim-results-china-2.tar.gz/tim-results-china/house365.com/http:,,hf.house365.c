[0712/111848.553424:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111848.553988:INFO:switcher_clone.cc(787)] backtrace rip is 7fb161def891
[0712/111849.615509:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111849.615895:INFO:switcher_clone.cc(787)] backtrace rip is 7fec384f6891
[1:1:0712/111849.627508:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111849.627815:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111849.636783:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[130172:130172:0712/111851.178819:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/31ce6430-2e00-47cc-b2fa-52cc45dc2e08
[0712/111851.269237:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111851.269626:INFO:switcher_clone.cc(787)] backtrace rip is 7f9e62146891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[130206:130206:0712/111851.508202:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130206
[130219:130219:0712/111851.508646:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130219
[130172:130172:0712/111851.603371:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[130172:130204:0712/111851.604151:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111851.604374:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111851.604657:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111851.605254:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111851.605391:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111851.608340:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3433d1b1, 1
[1:1:0712/111851.608690:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x296a1efa, 0
[1:1:0712/111851.608893:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1db8ed16, 3
[1:1:0712/111851.609121:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f2214de, 2
[1:1:0712/111851.609357:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffa1e6a29 ffffffb1ffffffd13334 ffffffde14222f 16ffffffedffffffb81d , 10104, 4
[1:1:0712/111851.610294:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130172:130204:0712/111851.610579:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�j)��34�"/���x�
[130172:130204:0712/111851.610647:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �j)��34�"/�����x�
[1:1:0712/111851.610566:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec367310a0, 3
[1:1:0712/111851.610819:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec368bc080, 2
[130172:130204:0712/111851.611035:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[130172:130204:0712/111851.611137:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130227, 4, fa1e6a29 b1d13334 de14222f 16edb81d 
[1:1:0712/111851.611094:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec2057fd20, -2
[1:1:0712/111851.626170:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111851.627026:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f2214de
[1:1:0712/111851.627952:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f2214de
[1:1:0712/111851.629502:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f2214de
[1:1:0712/111851.630922:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.631209:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.631448:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.631695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.632431:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f2214de
[1:1:0712/111851.632809:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec384f67ba
[1:1:0712/111851.632989:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec384eddef, 7fec384f677a, 7fec384f80cf
[1:1:0712/111851.638817:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f2214de
[1:1:0712/111851.639157:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f2214de
[1:1:0712/111851.639964:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f2214de
[1:1:0712/111851.642201:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.642444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.642658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.642840:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f2214de
[1:1:0712/111851.644078:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f2214de
[1:1:0712/111851.644539:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec384f67ba
[1:1:0712/111851.644691:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec384eddef, 7fec384f677a, 7fec384f80cf
[1:1:0712/111851.652293:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111851.652783:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111851.652953:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb8ff8158, 0x7ffcb8ff80d8)
[1:1:0712/111851.669436:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111851.676277:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[130172:130172:0712/111852.325385:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130172:130172:0712/111852.328350:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130172:130172:0712/111852.340070:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[130172:130172:0712/111852.340125:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[130172:130172:0712/111852.340225:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,130227, 4
[130172:130186:0712/111852.341877:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[130172:130186:0712/111852.341984:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111852.343606:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[130172:130199:0712/111852.400236:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111852.476410:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1556ad6a5220
[1:1:0712/111852.476675:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/111852.925376:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[130172:130172:0712/111854.616276:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[130172:130172:0712/111854.616400:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111854.633833:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111854.636615:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111856.039217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111856.039549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111856.055963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111856.056353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111856.072890:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111856.306410:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111856.306716:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111856.544714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111856.552811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111856.553015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111856.587694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111856.598125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111856.598355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111856.610011:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[130172:130172:0712/111856.614732:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111856.616278:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1556ad6a3e20
[1:1:0712/111856.616447:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[130172:130172:0712/111856.623400:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[130172:130172:0712/111856.654926:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[130172:130172:0712/111856.655125:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[130172:130172:0712/111856.670000:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/111856.678326:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111857.213260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fec2215a2e0 0x1556ad8448e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111857.214004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111857.214120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111857.214702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130172:130172:0712/111857.242698:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111857.245315:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1556ad6a4820
[1:1:0712/111857.245590:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[130172:130172:0712/111857.249589:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111857.262319:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111857.262492:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[130172:130172:0712/111857.282248:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[130172:130172:0712/111857.293778:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130172:130172:0712/111857.294784:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130172:130186:0712/111857.300762:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[130172:130186:0712/111857.300848:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[130172:130172:0712/111857.300995:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[130172:130172:0712/111857.301069:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[130172:130172:0712/111857.301202:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,130227, 4
[1:7:0712/111857.305985:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111857.854917:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111858.385012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7fec2215a2e0 0x1556ada3b360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111858.386077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111858.386305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111858.387090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130172:130172:0712/111858.499152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[130172:130172:0712/111858.499259:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111858.505011:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[130172:130172:0712/111858.791542:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[130172:130204:0712/111858.792016:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111858.792205:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111858.792413:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111858.792808:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111858.792947:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111858.796217:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2dc1c6fd, 1
[1:1:0712/111858.796667:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd8e1870, 0
[1:1:0712/111858.796892:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2b4fe421, 3
[1:1:0712/111858.797088:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a5cedd, 2
[1:1:0712/111858.797269:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7018ffffff8e0d fffffffdffffffc6ffffffc12d ffffffddffffffceffffffa502 21ffffffe44f2b , 10104, 5
[1:1:0712/111858.798342:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130172:130204:0712/111858.798654:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGp����-�Υ!�O+]{�
[130172:130204:0712/111858.798787:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is p����-�Υ!�O+��]{�
[1:1:0712/111858.798638:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec367310a0, 3
[130172:130204:0712/111858.799113:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130271, 5, 70188e0d fdc6c12d ddcea502 21e44f2b 
[1:1:0712/111858.799069:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec368bc080, 2
[1:1:0712/111858.799143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111858.799550:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fec2057fd20, -2
[1:1:0712/111858.812676:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111858.813070:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a5cedd
[1:1:0712/111858.813448:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a5cedd
[1:1:0712/111858.814126:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a5cedd
[1:1:0712/111858.815556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.815828:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.816061:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.816281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.816829:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a5cedd
[1:1:0712/111858.817161:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec384f67ba
[1:1:0712/111858.817339:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec384eddef, 7fec384f677a, 7fec384f80cf
[1:1:0712/111858.823079:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a5cedd
[1:1:0712/111858.823481:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a5cedd
[1:1:0712/111858.824290:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a5cedd
[1:1:0712/111858.826330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.826580:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.826839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.827068:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a5cedd
[1:1:0712/111858.828355:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a5cedd
[1:1:0712/111858.828777:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fec384f67ba
[1:1:0712/111858.828958:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fec384eddef, 7fec384f677a, 7fec384f80cf
[1:1:0712/111858.836724:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111858.837290:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111858.837478:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcb8ff8158, 0x7ffcb8ff80d8)
[1:1:0712/111858.849567:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111858.854116:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111859.056028:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1556ad673220
[1:1:0712/111859.056286:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111859.499018:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111859.499303:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[130172:130172:0712/111859.729525:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130172:130172:0712/111859.734565:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130172:130186:0712/111859.764955:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[130172:130186:0712/111859.765061:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[130172:130172:0712/111859.765325:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://hf.house365.com/
[130172:130172:0712/111859.765423:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hf.house365.com/, http://hf.house365.com/index.html, 1
[130172:130172:0712/111859.765587:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://hf.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:18:59 GMT Content-Type: text/html; charset=gb2312 Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 18:10:25 GMT Vary: Accept-Encoding ETag: W/"5d28cd11-3da6b" Content-Encoding: gzip  ,130271, 5
[1:7:0712/111859.769912:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111859.788339:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://hf.house365.com/
[1:1:0712/111859.859865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111859.862835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1320497ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111859.863141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111859.871852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[130172:130172:0712/111859.949810:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hf.house365.com/, http://hf.house365.com/, 1
[130172:130172:0712/111859.949873:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://hf.house365.com/, http://hf.house365.com
[1:1:0712/111859.950182:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111900.040077:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111900.112457:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111900.144768:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111900.146233:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111900.176697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111900.177684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1320496a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111900.177915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111900.314026:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111900.727684:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111901.278540:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.279278:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.279719:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.280223:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.280731:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.281543:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.284609:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111901.296478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/111901.296767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111901.535722:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.545510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.558821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.568329:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.576620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.632426:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.637625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.642359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 10000
[1:1:0712/111901.642825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 246
[1:1:0712/111901.643055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 246 0x7fec20232070 0x1556ad9ed860 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 205 0x7fec20232070 0x1556ad773ae0 
[1:1:0712/111901.654037:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.665530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.726882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.751615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.859063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.867560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.884572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111901.890096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fec20232070 0x1556ad773ae0 , "http://hf.house365.com/index.html"
[1:1:0712/111904.013497:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=fbsimshow"
[1:1:0712/111906.403151:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 441 0x7fec368bc080 0x1556adc5f060 1 0 0x1556adc5f078 , "http://hf.house365.com/index.html"
[1:1:0712/111906.427346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111906.427685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111909.247966:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111909.762148:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111909.762463:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111909.763414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fec20232070 0x1556ad7e1e60 , "http://hf.house365.com/index.html"
[1:1:0712/111909.765116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 	$(function(){		var jqueryInputDom2 = '#keywords';		var searchUrl = 'http://transferapi.house365.com
[1:1:0712/111909.765368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111909.771717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fec20232070 0x1556ad7e1e60 , "http://hf.house365.com/index.html"
[1:1:0712/111909.796226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fec20232070 0x1556ad7e1e60 , "http://hf.house365.com/index.html"
[1:1:0712/111910.197288:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111911.081672:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=fbsimshow"
[1:1:0712/111911.489043:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111911.966471:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111911.966733:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111911.972416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7fec20232070 0x1556ad77c9e0 , "http://hf.house365.com/index.html"
[1:1:0712/111911.974123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111911.974350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111911.982805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7fec20232070 0x1556ad77c9e0 , "http://hf.house365.com/index.html"
[1:1:0712/111912.043375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 246, 7fec22b77881
[1:1:0712/111912.067821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"205 0x7fec20232070 0x1556ad773ae0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.068207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"205 0x7fec20232070 0x1556ad773ae0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.068600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111912.069476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , full_screen15111(2)
[1:1:0712/111912.069695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111912.107488:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288970
[1:1:0712/111912.107767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111912.108185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 558
[1:1:0712/111912.108428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7fec20232070 0x1556ad9fa0e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 246 0x7fec20232070 0x1556ad9ed860 
[1:1:0712/111912.222501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111912.223091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 560
[1:1:0712/111912.223361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 560 0x7fec20232070 0x1556ad99e860 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 246 0x7fec20232070 0x1556ad9ed860 
[1:1:0712/111912.262642:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=fbsimshow"
[1:1:0712/111912.315690:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548 0x7fec368bc080 0x1556ada971a0 1 0 0x1556ada971b8 , "http://hf.house365.com/index.html"
[1:1:0712/111912.447674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111912.448037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
		remove user.10_9b3f2a74 -> 0
[1:1:0712/111912.585809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548 0x7fec368bc080 0x1556ada971a0 1 0 0x1556ada971b8 , "http://hf.house365.com/index.html"
[1:1:0712/111912.612531:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0276828, 105, 1
[1:1:0712/111912.612822:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111912.847500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 558, 7fec22b77881
[1:1:0712/111912.858724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"246 0x7fec20232070 0x1556ad9ed860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.859067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"246 0x7fec20232070 0x1556ad9ed860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.859445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111912.860021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/111912.860268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111912.911648:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 560, 7fec22b778db
[1:1:0712/111912.924184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"246 0x7fec20232070 0x1556ad9ed860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.924512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"246 0x7fec20232070 0x1556ad9ed860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111912.924946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 573
[1:1:0712/111912.925186:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7fec20232070 0x1556ad9faa60 , 5:3_http://hf.house365.com/, 0, , 560 0x7fec20232070 0x1556ad99e860 
[1:1:0712/111912.925510:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111912.926103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111912.926320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111913.056806:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111913.057088:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111913.058006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7fec20232070 0x1556adab8e60 , "http://hf.house365.com/index.html"
[1:1:0712/111913.059123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , function normal15108(){
    document.write('<a href="http://hf.house365.com/adclick.php?id=15108" st
[1:1:0712/111913.059338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "hf.house365.com", 3, 1, , , 0
[1:1:0712/111913.077688:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111913.088907:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1556ae127820
[1:1:0712/111913.089202:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111913.127066:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7fec20232070 0x1556adab8e60 , "http://hf.house365.com/index.html"
[1:1:0712/111913.130041:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "hf.house365.com", "house365.com"
[1:1:0712/111913.233732:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.176522, 468, 1
[1:1:0712/111913.234014:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111913.264818:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 573, 7fec22b778db
[1:1:0712/111913.293999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"560 0x7fec20232070 0x1556ad99e860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111913.294321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"560 0x7fec20232070 0x1556ad99e860 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111913.294752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 625
[1:1:0712/111913.294999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7fec20232070 0x1556ad9de8e0 , 5:3_http://hf.house365.com/, 0, , 573 0x7fec20232070 0x1556ad9faa60 
[1:1:0712/111913.295369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111913.295943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111913.296181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111914.497910:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111914.498209:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111914.502646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 621 0x7fec20232070 0x1556ada01c60 , "http://hf.house365.com/index.html"
[1:1:0712/111914.505201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
function QR8bitByte(a){
    this.mode=QRMode.MODE_8BIT_BYTE,
        this.data=a
}

function 
[1:1:0712/111914.505452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111914.515887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 621 0x7fec20232070 0x1556ada01c60 , "http://hf.house365.com/index.html"
[130172:130172:0712/111924.458556:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[130172:130172:0712/111924.469110:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[130172:130172:0712/111924.495376:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://hf.house365.com/, http://hf.house365.com/, 4
[130172:130172:0712/111924.495563:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://hf.house365.com/, http://hf.house365.com
[130172:130172:0712/111924.536731:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/111924.551735:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[130172:130172:0712/111924.691908:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/111932.468914:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 17.9705, 0, 0
[1:1:0712/111932.469138:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111933.066348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111933.066560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111934.288198:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111934.288371:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111934.296830:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00844097, 120, 1
[1:1:0712/111934.296997:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111934.586185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111934.586877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111936.565590:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111936.565911:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111936.566890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7fec20232070 0x1556b572c460 , "http://hf.house365.com/index.html"
[1:1:0712/111936.567958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
			//banner轮播图
			jQuery(".index_fbs_wenda_ul").slide({
				titCell: ".hd ul",
				mainCell: 
[1:1:0712/111936.568198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111936.952718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288998
[1:1:0712/111936.953022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111936.953428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 768
[1:1:0712/111936.953664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 768 0x7fec20232070 0x1556ada02160 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 719 0x7fec20232070 0x1556b572c460 
[1:1:0712/111937.077199:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111937.077695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 769
[1:1:0712/111937.077946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7fec20232070 0x1556b5dc16e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 719 0x7fec20232070 0x1556b572c460 
[1:1:0712/111937.098742:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 3000
[1:1:0712/111937.099354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 770
[1:1:0712/111937.099608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7fec20232070 0x1556b57d4760 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 719 0x7fec20232070 0x1556b572c460 
[1:1:0712/111937.119469:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.553448, 0, 0
[1:1:0712/111937.119766:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111937.186053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hf.house365.com/index.html"
[1:1:0712/111937.188129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111937.188386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111937.207639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111937.208040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111937.294586:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://hf.house365.com/images/more_right_bg.png"
[1:1:0712/111938.490677:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111938.490966:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111938.535813:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0447781, 213, 1
[1:1:0712/111938.536175:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111938.612908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 768, 7fec22b77881
[1:1:0712/111938.626113:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111938.626523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111938.626915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111938.627682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/111938.627950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111938.629476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 769, 7fec22b778db
[1:1:0712/111938.650754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111938.651099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111938.651546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 803
[1:1:0712/111938.651801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7fec20232070 0x1556ada01260 , 5:3_http://hf.house365.com/, 0, , 769 0x7fec20232070 0x1556b5dc16e0 
[1:1:0712/111938.652116:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111938.652717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111938.652947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111938.695404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111938.695820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111939.887246:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111939.887535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111939.893677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 800 0x7fec20232070 0x1556b5dcc560 , "http://hf.house365.com/index.html"
[1:1:0712/111939.894563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
			
[1:1:0712/111939.894796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111939.901377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 800 0x7fec20232070 0x1556b5dcc560 , "http://hf.house365.com/index.html"
[1:1:0712/111939.912556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 800 0x7fec20232070 0x1556b5dcc560 , "http://hf.house365.com/index.html"
[1:1:0712/111940.028753:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.141108, 232, 1
[1:1:0712/111940.029057:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111940.100100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111940.100388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111942.966668:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111942.966980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111943.126859:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.159671, 928, 1
[1:1:0712/111943.127158:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111943.129196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 770, 7fec22b778db
[1:1:0712/111943.171054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111943.171445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"719 0x7fec20232070 0x1556b572c460 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111943.171831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 966
[1:1:0712/111943.172066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7fec20232070 0x1556b5dc4ee0 , 5:3_http://hf.house365.com/, 0, , 770 0x7fec20232070 0x1556b57d4760 
[1:1:0712/111943.172476:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111943.173054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/111943.173297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111943.202224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288950
[1:1:0712/111943.202542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111943.202942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 967
[1:1:0712/111943.203171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7fec20232070 0x1556ade3f3e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 770 0x7fec20232070 0x1556b57d4760 
[1:1:0712/111943.796951:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111943.797468:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 972
[1:1:0712/111943.797732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 972 0x7fec20232070 0x1556b638c9e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 770 0x7fec20232070 0x1556b57d4760 
[1:1:0712/111943.875030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111943.875367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111943.938401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://hf.house365.com/index.html"
[1:1:0712/111943.939131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Xc[g],b=void 0,f.onreadystatechange=m.noop,e)4
[1:1:0712/111943.939346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111943.941426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://hf.house365.com/index.html"
[1:1:0712/111943.945648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://hf.house365.com/index.html"
[1:1:0712/111943.946520:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x7b96008fe60
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[130172:130172:0712/111946.535409:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111948.470620:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111948.471019:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111948.471977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 963 0x7fec20232070 0x1556b2d903e0 , "http://hf.house365.com/index.html"
[1:1:0712/111948.473202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
						$(function(){
							$("#xfzx_right_lp .newhouseSItem").click(function(){
								$(this).add
[1:1:0712/111948.473474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111948.544228:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.073127, 1017, 1
[1:1:0712/111948.544531:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111948.863036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 967, 7fec22b77881
[1:1:0712/111948.894161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111948.894549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111948.894929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111948.895506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/111948.895776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111948.897751:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 972, 7fec22b778db
[1:1:0712/111948.944514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111948.944969:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111948.945349:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1052
[1:1:0712/111948.945585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7fec20232070 0x1556b63794e0 , 5:3_http://hf.house365.com/, 0, , 972 0x7fec20232070 0x1556b638c9e0 
[1:1:0712/111948.946032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111948.946603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111948.946825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111948.973044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111948.973329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111950.486887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 966, 7fec22b778db
[1:1:0712/111950.528926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111950.529283:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"770 0x7fec20232070 0x1556b57d4760 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111950.529646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1081
[1:1:0712/111950.529877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1081 0x7fec20232070 0x1556ade4e060 , 5:3_http://hf.house365.com/, 0, , 966 0x7fec20232070 0x1556b5dc4ee0 
[1:1:0712/111950.530283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111950.530826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/111950.531085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111950.595336:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288950
[1:1:0712/111950.595581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111950.595951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1082
[1:1:0712/111950.596212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7fec20232070 0x1556b58977e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 966 0x7fec20232070 0x1556b5dc4ee0 
[1:1:0712/111951.018066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111951.018666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1090
[1:1:0712/111951.018907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7fec20232070 0x1556ad8a39e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 966 0x7fec20232070 0x1556b5dc4ee0 
[1:1:0712/111951.592023:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111951.592448:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111951.642472:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0499172, 216, 1
[1:1:0712/111951.642767:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111951.922460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111951.922776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111952.945515:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1082, 7fec22b77881
[1:1:0712/111952.999893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111953.000315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111953.000683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111953.001432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/111953.001833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111953.003683:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1090, 7fec22b778db
[1:1:0712/111953.049478:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111953.050005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111953.050474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1136
[1:1:0712/111953.050760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1136 0x7fec20232070 0x1556ae8371e0 , 5:3_http://hf.house365.com/, 0, , 1090 0x7fec20232070 0x1556ad8a39e0 
[1:1:0712/111953.051194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111953.051862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111953.052096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111954.021762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111954.022079:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111954.023831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1115 0x7fec20232070 0x1556b619e0e0 , "http://hf.house365.com/index.html"
[1:1:0712/111954.025046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
    //2017/4/11 添加hover
    $(".home-vouchsafe").slide({titCell:".hd ul",mainCell:".bd",autoPag
[1:1:0712/111954.025287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111954.816601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad2889b8
[1:1:0712/111954.816894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111954.817328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1153
[1:1:0712/111954.817628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7fec20232070 0x1556b5daee60 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1115 0x7fec20232070 0x1556b619e0e0 
[1:1:0712/111954.847636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111954.848013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1154
[1:1:0712/111954.848257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1154 0x7fec20232070 0x1556b637b2e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1115 0x7fec20232070 0x1556b619e0e0 
[1:1:0712/111954.872230:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 2500
[1:1:0712/111954.872933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1155
[1:1:0712/111954.873194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1155 0x7fec20232070 0x1556b6624a60 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1115 0x7fec20232070 0x1556b619e0e0 
[1:1:0712/111954.967212:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.945191, 2, 0
[1:1:0712/111954.967702:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111955.133471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111955.133789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111955.137584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1081, 7fec22b778db
[1:1:0712/111955.190205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111955.190562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"966 0x7fec20232070 0x1556b5dc4ee0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111955.190940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1163
[1:1:0712/111955.191201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7fec20232070 0x1556ad9fa1e0 , 5:3_http://hf.house365.com/, 0, , 1081 0x7fec20232070 0x1556ade4e060 
[1:1:0712/111955.191588:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111955.192214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/111955.192438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111956.292782:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111956.293060:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111956.309254:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0161119, 215, 1
[1:1:0712/111956.309541:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111956.345012:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1153, 7fec22b77881
[1:1:0712/111956.377508:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111956.377891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111956.378264:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111956.378835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/111956.379047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111956.380459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1154, 7fec22b778db
[1:1:0712/111956.418753:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111956.419136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111956.419606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1188
[1:1:0712/111956.419905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1188 0x7fec20232070 0x1556ad7a4960 , 5:3_http://hf.house365.com/, 0, , 1154 0x7fec20232070 0x1556b637b2e0 
[1:1:0712/111956.420311:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111956.420891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111956.421131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111956.502299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111956.502627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111957.297270:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111957.297555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111957.303792:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1185 0x7fec20232070 0x1556b6634ce0 , "http://hf.house365.com/index.html"
[1:1:0712/111957.304809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
			var flag_esf_tag = true;
					
[1:1:0712/111957.305067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111957.325338:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0276709, 214, 1
[1:1:0712/111957.325623:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111957.417694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111957.418033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111958.550585:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111958.550852:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/111958.552016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1208 0x7fec20232070 0x1556b5dcca60 , "http://hf.house365.com/index.html"
[1:1:0712/111958.552950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
		var flag_zf_tag = true;
			
[1:1:0712/111958.553222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111958.613090:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0621159, 314, 1
[1:1:0712/111958.613383:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111958.634794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1155, 7fec22b778db
[1:1:0712/111958.692433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111958.692923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"1115 0x7fec20232070 0x1556b619e0e0 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111958.693360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1253
[1:1:0712/111958.693623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1253 0x7fec20232070 0x1556b6a12fe0 , 5:3_http://hf.house365.com/, 0, , 1155 0x7fec20232070 0x1556b6624a60 
[1:1:0712/111958.694076:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111958.694607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/111958.694817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111958.799152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288950
[1:1:0712/111958.799425:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/111958.799865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1254
[1:1:0712/111958.800101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7fec20232070 0x1556ae1a5660 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1155 0x7fec20232070 0x1556b6624a60 
[1:1:0712/111958.978711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/111958.979232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1255
[1:1:0712/111958.979475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1255 0x7fec20232070 0x1556ae12f5e0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1155 0x7fec20232070 0x1556b6624a60 
[1:1:0712/111959.051076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.readyState
[1:1:0712/111959.051386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111959.214954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1163, 7fec22b778db
[1:1:0712/111959.285592:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1081 0x7fec20232070 0x1556ade4e060 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111959.285944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1081 0x7fec20232070 0x1556ade4e060 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/111959.286337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1261
[1:1:0712/111959.286569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7fec20232070 0x1556b61a1b60 , 5:3_http://hf.house365.com/, 0, , 1163 0x7fec20232070 0x1556ad9fa1e0 
[1:1:0712/111959.286931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/111959.287473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/111959.287736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112000.742395:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112000.742799:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/112000.743799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1250 0x7fec20232070 0x1556b587e060 , "http://hf.house365.com/index.html"
[1:1:0712/112000.744772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , 
	jQuery(".indexhfsh-r-list").slide();

[1:1:0712/112000.744997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/112000.942007:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.199115, 188, 1
[1:1:0712/112000.942294:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112000.987088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1254, 7fec22b77881
[1:1:0712/112001.018426:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.018830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.019169:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/112001.019936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){$b=void 0}
[1:1:0712/112001.020189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/112001.082504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1255, 7fec22b778db
[1:1:0712/112001.121561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2473d1922860","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.121922:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hf.house365.com/","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.122291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1291
[1:1:0712/112001.122524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7fec20232070 0x1556ad6fb160 , 5:3_http://hf.house365.com/, 0, , 1255 0x7fec20232070 0x1556ae12f5e0 
[1:1:0712/112001.122907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/112001.123477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/112001.123761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/112001.267846:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1253, 7fec22b778db
[1:1:0712/112001.287598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.287930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1155 0x7fec20232070 0x1556b6624a60 ","rf":"5:3_http://hf.house365.com/"}
[1:1:0712/112001.288310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1298
[1:1:0712/112001.288545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1298 0x7fec20232070 0x1556b4837de0 , 5:3_http://hf.house365.com/, 0, , 1253 0x7fec20232070 0x1556b6a12fe0 
[1:1:0712/112001.288940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hf.house365.com/index.html"
[1:1:0712/112001.289493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , (){w?p--:p++,ab()}
[1:1:0712/112001.289730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/112001.360962:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xef9e39029c8, 0x1556ad288950
[1:1:0712/112001.361235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 0
[1:1:0712/112001.361655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hf.house365.com/, 1299
[1:1:0712/112001.361887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7fec20232070 0x1556ad699be0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1253 0x7fec20232070 0x1556b6a12fe0 
[1:1:0712/112001.466667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hf.house365.com/index.html", 13
[1:1:0712/112001.467162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hf.house365.com/, 1300
[1:1:0712/112001.467399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7fec20232070 0x1556b57cffe0 , 5:3_http://hf.house365.com/, 1, -5:3_http://hf.house365.com/, 1253 0x7fec20232070 0x1556b6a12fe0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112002.437449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112002.437742:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hf.house365.com/index.html"
[1:1:0712/112002.441306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1286 0x7fec20232070 0x1556b637f460 , "http://hf.house365.com/index.html"
[1:1:0712/112002.442083:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112002.443597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hf.house365.com/, 2473d1922860, , , document.write("<div class=\"w10000\">	<div class=\"pt45 pb45 bg484848\">		<div class=\"margin_auto_
[1:1:0712/112002.443960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hf.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/112002.474887:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0370929, 57, 1
[1:1:0712/112002.475258:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
