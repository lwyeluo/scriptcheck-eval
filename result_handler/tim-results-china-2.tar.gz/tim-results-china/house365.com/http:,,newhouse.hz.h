[0712/111233.282048:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111233.282342:INFO:switcher_clone.cc(787)] backtrace rip is 7f9968837891
[0712/111234.238659:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111234.239019:INFO:switcher_clone.cc(787)] backtrace rip is 7f6894214891
[1:1:0712/111234.250664:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111234.250922:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111234.260817:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[129506:129506:0712/111235.603423:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/98f79f0d-97e0-4246-9d31-5ea90b4a7d89
[0712/111235.817245:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111235.817616:INFO:switcher_clone.cc(787)] backtrace rip is 7f6eb4541891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129506:129506:0712/111235.987509:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129506:129537:0712/111235.988417:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111235.988662:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111235.988939:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111235.989616:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111235.989931:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111235.996111:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1faa42ad, 1
[1:1:0712/111235.996529:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x232991c, 0
[1:1:0712/111235.996741:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e0fc20a, 3
[1:1:0712/111235.996948:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f1f0eba, 2
[1:1:0712/111235.997209:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1cffffff993202 ffffffad42ffffffaa1f ffffffba0e1f1f 0affffffc20f2e , 10104, 4
[1:1:0712/111235.998299:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129506:129537:0712/111235.998580:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�2�B��
�.��+-
[129506:129537:0712/111235.998666:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �2�B��
�.U��+-
[1:1:0712/111235.998567:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f689244f0a0, 3
[1:1:0712/111235.998789:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f68925da080, 2
[129506:129537:0712/111235.998954:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111235.998950:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f687c29dd20, -2
[129506:129537:0712/111235.999029:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129552, 4, 1c993202 ad42aa1f ba0e1f1f 0ac20f2e 
[1:1:0712/111236.017705:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111236.018323:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f1f0eba
[1:1:0712/111236.018965:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f1f0eba
[1:1:0712/111236.019979:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f1f0eba
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/111236.020548:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.020660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.020750:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.020839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.021052:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f1f0eba
[1:1:0712/111236.021346:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f68942147ba
[1:1:0712/111236.021432:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f689420bdef, 7f689421477a, 7f68942160cf
[1:1:0712/111236.022781:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f1f0eba
[1:1:0712/111236.022936:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f1f0eba
[1:1:0712/111236.023187:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f1f0eba
[1:1:0712/111236.025521:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.025738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.025931:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[1:1:0712/111236.026117:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f1f0eba
[129539:129539:0712/111236.026716:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129539
[129553:129553:0712/111236.027139:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129553
[1:1:0712/111236.027409:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f1f0eba
[1:1:0712/111236.027789:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f68942147ba
[1:1:0712/111236.027937:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f689420bdef, 7f689421477a, 7f68942160cf
[1:1:0712/111236.035672:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111236.036124:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111236.036342:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaa3a9298, 0x7ffcaa3a9218)
[1:1:0712/111236.050911:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111236.058144:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111236.635379:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2fb5804d2220
[1:1:0712/111236.635720:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[129506:129506:0712/111236.651190:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129506:129506:0712/111236.652373:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129506:129530:0712/111236.665098:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[129506:129518:0712/111236.669855:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129506:129518:0712/111236.669985:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129506:129506:0712/111236.670056:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129506:129506:0712/111236.670155:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129506:129506:0712/111236.670462:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129552, 4
[1:7:0712/111236.697424:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111236.882413:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111238.174143:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111238.178396:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[129506:129506:0712/111238.669968:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129506:129506:0712/111238.670071:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111239.331940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111239.489328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111239.489616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111239.518216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111239.518460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111239.567707:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111239.567953:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111239.880407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111239.889125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111239.889524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111239.913489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111239.923510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111239.923869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111239.935542:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129506:129506:0712/111239.938678:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111239.941657:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2fb5804d0e20
[1:1:0712/111239.941918:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129506:129506:0712/111239.954775:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129506:129506:0712/111239.993878:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129506:129506:0712/111239.994027:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111240.060065:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111241.064821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f687de782e0 0x2fb5807a85e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111241.066195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111241.066462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111241.067996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129506:129506:0712/111241.136827:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111241.139253:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2fb5804d1820
[1:1:0712/111241.139661:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129506:129506:0712/111241.143562:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111241.149834:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111241.150061:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129506:129506:0712/111241.161038:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129506:129506:0712/111241.194433:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129506:129506:0712/111241.195445:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129506:129518:0712/111241.201431:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129506:129518:0712/111241.201564:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[129506:129506:0712/111241.201723:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129506:129506:0712/111241.201799:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129506:129506:0712/111241.201928:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129552, 4
[1:7:0712/111241.205126:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111241.771803:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111242.203550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f687de782e0 0x2fb5807a82e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111242.204197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23e7a0661f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111242.204762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111242.205478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129506:129506:0712/111242.435870:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129506:129506:0712/111242.435992:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111242.469653:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111242.831724:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111243.597432:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111243.597662:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129506:129506:0712/111243.680392:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129506:129537:0712/111243.680908:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111243.681186:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111243.681458:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111243.681981:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111243.682201:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111243.685940:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x35539fb0, 1
[1:1:0712/111243.686349:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x54dcfdc, 0
[1:1:0712/111243.686591:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1575f56d, 3
[1:1:0712/111243.686821:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x129208a2, 2
[1:1:0712/111243.687038:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdcffffffcf4d05 ffffffb0ffffff9f5335 ffffffa208ffffff9212 6dfffffff57515 , 10104, 5
[1:1:0712/111243.688357:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129506:129537:0712/111243.688685:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��M��S5��m�u˒+-
[129506:129537:0712/111243.688780:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��M��S5��m�u�h˒+-
[1:1:0712/111243.688686:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f689244f0a0, 3
[129506:129537:0712/111243.689149:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129605, 5, dccf4d05 b09f5335 a2089212 6df57515 
[1:1:0712/111243.689085:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f68925da080, 2
[1:1:0712/111243.689690:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f687c29dd20, -2
[1:1:0712/111243.721248:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111243.721729:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 129208a2
[1:1:0712/111243.722254:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 129208a2
[1:1:0712/111243.723020:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 129208a2
[1:1:0712/111243.724585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.724848:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.725118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.725375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.726101:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 129208a2
[1:1:0712/111243.726468:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f68942147ba
[1:1:0712/111243.726660:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f689420bdef, 7f689421477a, 7f68942160cf
[1:1:0712/111243.732448:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 129208a2
[1:1:0712/111243.732845:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 129208a2
[1:1:0712/111243.733618:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 129208a2
[1:1:0712/111243.735667:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.735926:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.736176:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.736413:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 129208a2
[1:1:0712/111243.737682:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 129208a2
[1:1:0712/111243.738110:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f68942147ba
[1:1:0712/111243.738284:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f689420bdef, 7f689421477a, 7f68942160cf
[1:1:0712/111243.745506:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111243.746164:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111243.746358:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaa3a9298, 0x7ffcaa3a9218)
[1:1:0712/111243.761636:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111243.768718:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111243.929350:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2fb5804aa220
[1:1:0712/111243.929628:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111244.039005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111244.043870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 23e7a078e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111244.044332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111244.054389:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129506:129506:0712/111244.508860:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129506:129506:0712/111244.522065:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129506:129518:0712/111244.565684:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129506:129518:0712/111244.565759:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129506:129506:0712/111244.571654:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.hz.house365.com/
[129506:129506:0712/111244.571708:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hz.house365.com/, http://newhouse.hz.house365.com/, 1
[129506:129506:0712/111244.571783:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.hz.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:12:44 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=vbrugjqhr0u81t4t8cv11e03j0; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,129605, 5
[1:7:0712/111244.574127:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111244.617976:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.hz.house365.com/
[129506:129506:0712/111244.752169:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hz.house365.com/, http://newhouse.hz.house365.com/, 1
[129506:129506:0712/111244.752232:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.hz.house365.com/, http://newhouse.hz.house365.com
[1:1:0712/111244.811458:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111244.927747:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111244.992883:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111245.041712:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111245.041967:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111245.277728:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111245.456750:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111245.457323:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111245.457756:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111245.458318:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111245.458716:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111246.229116:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111246.549590:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f687c2b8bd0 0x2fb5806304d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111246.569312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/111246.569587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "newhouse.hz.house365.com", 3, 1, , , 0
[1:1:0712/111246.571655:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_1c9b9004 -> 0
		remove user.11_2ee922ba -> 0
		remove user.12_6883c4df -> 0
		remove user.13_caa1c1ba -> 0
		remove user.14_18ca5207 -> 0
		remove user.f_5b9d2437 -> 0
[1:1:0712/111246.684273:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f687c2b8bd0 0x2fb5806304d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111246.732427:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f687c2b8bd0 0x2fb5806304d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111248.398902:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hz.house365.com/?action=shopfbsimshow"
[1:1:0712/111250.859846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f687bf50070 0x2fb58069b660 , "http://newhouse.hz.house365.com/"
[1:1:0712/111250.860974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'hz';
    var uid = '';
    var fav_prjid =
[1:1:0712/111250.861180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "newhouse.hz.house365.com", 3, 1, , , 0
[1:1:0712/111250.863203:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.hz.house365.com", "house365.com"
[1:1:0712/111250.870854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f687bf50070 0x2fb58069b660 , "http://newhouse.hz.house365.com/"
[1:1:0712/111250.872455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f687bf50070 0x2fb58069b660 , "http://newhouse.hz.house365.com/"
[1:1:0712/111250.875902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f687bf50070 0x2fb58069b660 , "http://newhouse.hz.house365.com/"
[1:1:0712/111251.993072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475, "http://newhouse.hz.house365.com/"
[1:1:0712/111251.994658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111251.994884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111252.919919:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111253.483735:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111253.483917:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111253.657393:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hz.house365.com/?action=shopfbsimshow"
[1:1:0712/111253.937409:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 563 0x7f687c2b8bd0 0x2fb580827cd8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111253.997260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111253.997639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111254.164869:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111254.284905:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0235589, 144, 1
[1:1:0712/111254.285110:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111254.397152:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111254.397337:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111254.397805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 578 0x7f687bf50070 0x2fb580c840e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111254.398516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/111254.398654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111254.417283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 578 0x7f687bf50070 0x2fb580c840e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111255.385401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 605, "http://newhouse.hz.house365.com/"
[1:1:0712/111255.386929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111255.387062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111255.917415:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111256.223032:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111256.223338:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111256.226840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 632 0x7f687bf50070 0x2fb5800d0260 , "http://newhouse.hz.house365.com/"
[1:1:0712/111256.236923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111256.237249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111256.478331:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.254844, 52, 1
[1:1:0712/111256.478591:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111256.556731:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hz.house365.com/?action=shopfbsimshow"
[1:1:0712/111256.778149:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111256.778341:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111256.778790:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645 0x7f687bf50070 0x2fb580c86560 , "http://newhouse.hz.house365.com/"
[1:1:0712/111256.779364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/111256.779483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111257.146276:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 658 0x7f687c2b8bd0 0x2fb580e394d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111257.150942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111257.151172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111258.878397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 658 0x7f687c2b8bd0 0x2fb580e394d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111258.884898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 658 0x7f687c2b8bd0 0x2fb580e394d8 , "http://newhouse.hz.house365.com/"
[1:1:0712/111258.905503:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.033144, 85, 1
[1:1:0712/111258.905755:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111259.430951:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111259.431197:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111259.432117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f687bf50070 0x2fb5816b0ce0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111259.433831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/111259.434036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111259.458913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f687bf50070 0x2fb5816b0ce0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111259.479599:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f687bf50070 0x2fb5816b0ce0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111259.537741:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f687bf50070 0x2fb5816b0ce0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111301.563381:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.016924:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.017232:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111302.019653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f687bf50070 0x2fb5815b0960 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.021437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111302.021675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111302.029540:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f687bf50070 0x2fb5815b0960 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.052613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f687bf50070 0x2fb5815b0960 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.138632:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111302.154601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f687bf50070 0x2fb5815b0960 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.216974:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 720 0x7f687bf50070 0x2fb5815b0960 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.283308:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.26601, 232, 1
[1:1:0712/111302.283624:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.386090:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hz.house365.com/?action=shopfbsimshow"
[1:1:0712/111302.620344:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111302.624627:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111302.625148:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111302.820729:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.820894:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111302.821391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 739 0x7f687bf50070 0x2fb581dc5ae0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.822315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/111302.822463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111302.823831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 739 0x7f687bf50070 0x2fb581dc5ae0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111302.921418:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.10054, 539, 1
[1:1:0712/111302.921613:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111303.113666:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111303.113839:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111303.114315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 754 0x7f687bf50070 0x2fb5800d0ee0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111303.114884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode245159_1").qrcode({
                                rend
[1:1:0712/111303.114994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_f26dc8be -> 0
		remove user.12_bbd59c94 -> 0
		remove user.13_2afa952a -> 0
		remove user.14_75bcb76d -> 0
		remove user.15_84d3d45 -> 0
[129506:129506:0712/111312.227699:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/111312.279137:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111321.956826:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 18.8431, 0, 0
[1:1:0712/111321.957133:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111322.184951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111322.185286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111323.453822:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111323.454137:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111323.472892:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0185702, 90, 1
[1:1:0712/111323.473184:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111323.637421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111323.637623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111325.489830:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111325.490091:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111325.491594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 821 0x7f687bf50070 0x2fb582402b60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111325.493242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode247385_1").qrcode({
                                rend
[1:1:0712/111325.493547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111328.847222:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.35704, 0, 0
[1:1:0712/111328.847597:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111328.920385:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111328.922604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111328.922888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111328.963401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111328.963726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111330.967534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111330.968323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111330.968513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111331.020129:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111331.020410:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111331.036576:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0160482, 81, 1
[1:1:0712/111331.036880:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111331.180385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111331.180565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111331.648264:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111331.648536:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111331.649381:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 899 0x7f687bf50070 0x2fb58a5739e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111331.650188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode240829_1").qrcode({
                                rend
[1:1:0712/111331.650355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111332.009828:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.361261, 85, 1
[1:1:0712/111332.010138:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111332.069882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111332.070065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111332.546234:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111332.547185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111332.547455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111332.625499:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111332.625677:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111332.626260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 922 0x7f687bf50070 0x2fb5801a82e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111332.626969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode2669_1").qrcode({
                                render
[1:1:0712/111332.627122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111332.916160:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.290488, 85, 1
[1:1:0712/111332.916350:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111332.950989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111332.951173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111333.478008:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111333.478820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111333.479060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111333.650075:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111333.650373:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111333.651402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 942 0x7f687bf50070 0x2fb58916e560 , "http://newhouse.hz.house365.com/"
[1:1:0712/111333.652676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode254098_5").qrcode({
                                rend
[1:1:0712/111333.652941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111333.976148:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.325676, 81, 1
[1:1:0712/111333.976460:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111334.079957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111334.080253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[129506:129506:0712/111334.511081:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111334.673251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111334.673992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111334.674178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111334.813258:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111334.813485:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111334.814458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 963 0x7f687bf50070 0x2fb589b64ee0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111334.815628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode244283_1").qrcode({
                                rend
[1:1:0712/111334.815841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111335.117971:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.304372, 85, 1
[1:1:0712/111335.118176:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111335.232076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111335.232379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111335.471965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111335.472765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111335.472953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111335.543535:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111335.543764:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111335.544769:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 981 0x7f687bf50070 0x2fb587881f60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111335.545971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode241495_1").qrcode({
                                rend
[1:1:0712/111335.546189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111335.907145:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.363258, 88, 1
[1:1:0712/111335.907341:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111336.001036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111336.001311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111336.431663:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111336.432413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111336.432598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111336.655586:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111336.655804:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111336.656845:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1001 0x7f687bf50070 0x2fb58940dfe0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111336.657987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode239829_1").qrcode({
                                rend
[1:1:0712/111336.658168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111336.955366:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.299495, 86, 1
[1:1:0712/111336.955626:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111337.050396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111337.050660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111337.335773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111337.336473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111337.336655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111337.422090:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111337.422260:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111337.422906:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1019 0x7f687bf50070 0x2fb58acbff60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111337.423628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode247287_1").qrcode({
                                rend
[1:1:0712/111337.423777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111337.757293:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.335075, 85, 1
[1:1:0712/111337.757535:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111337.983296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111337.983504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111338.431903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111338.432360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111338.432486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111338.555226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111338.555464:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111338.556376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1040 0x7f687bf50070 0x2fb58917cbe0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111338.557230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode240149_1").qrcode({
                                rend
[1:1:0712/111338.557401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111338.877832:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.322704, 85, 1
[1:1:0712/111338.878432:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111338.898464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111338.898644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111339.364276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111339.364988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111339.365202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111339.510057:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111339.510306:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111339.510933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1062 0x7f687bf50070 0x2fb58acb70e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111339.511569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode240359_1").qrcode({
                                rend
[1:1:0712/111339.511711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111339.611052:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.100759, 85, 1
[1:1:0712/111339.611260:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111339.747684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111339.747934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111339.957858:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111339.958362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111339.958500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111340.020289:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111340.020453:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111340.021069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1079 0x7f687bf50070 0x2fb58a5b5a60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111340.021667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode253372_5").qrcode({
                                rend
[1:1:0712/111340.021790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111340.122466:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.102022, 88, 1
[1:1:0712/111340.122653:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111340.140414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111340.140590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111340.747669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111340.748146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111340.748264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111340.917240:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111340.917492:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111340.918555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1099 0x7f687bf50070 0x2fb586c041e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111340.919634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode2546_1").qrcode({
                                render
[1:1:0712/111340.919842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111341.255121:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.33756, 97, 1
[1:1:0712/111341.255423:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111341.298107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111341.298286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111341.660646:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111341.661191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111341.661335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111341.808937:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111341.809162:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111341.810213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1120 0x7f687bf50070 0x2fb589187d60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111341.811268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode248067_1").qrcode({
                                rend
[1:1:0712/111341.811475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111341.989266:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.17996, 98, 1
[1:1:0712/111341.989450:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111342.026701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111342.026956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111342.621044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111342.621755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111342.621959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111342.885086:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111342.885311:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111342.886343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1138 0x7f687bf50070 0x2fb58b0015e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111342.887388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
                            $("#lptelqrcode248585_1").qrcode({
                                rend
[1:1:0712/111342.887575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111343.133737:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.248352, 54, 1
[1:1:0712/111343.133997:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111343.196017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , document.readyState
[1:1:0712/111343.196196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111343.763583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hz.house365.com/"
[1:1:0712/111343.764068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111343.764184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111343.826935:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111343.827132:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111343.827750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7f687bf50070 0x2fb58a570f60 , "http://newhouse.hz.house365.com/"
[1:1:0712/111343.828334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 
listCondition.p=1;
var totalpage=141;

[1:1:0712/111343.828471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111343.843703:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0165451, 262, 1
[1:1:0712/111343.843862:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111345.216086:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111345.216409:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hz.house365.com/"
[1:1:0712/111345.217503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1189 0x7f687bf50070 0x2fb58ba712e0 , "http://newhouse.hz.house365.com/"
[1:1:0712/111345.218954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hz.house365.com/, 2f512e6a2860, , , 

            var num="12237";
            var call="4008908365,506";
            var fbscity="hz";

[1:1:0712/111345.219179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hz.house365.com/", "house365.com", 3, 1, , , 0
