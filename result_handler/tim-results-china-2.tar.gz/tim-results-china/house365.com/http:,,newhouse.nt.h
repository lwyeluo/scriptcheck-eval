[0712/111618.522455:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111618.522744:INFO:switcher_clone.cc(787)] backtrace rip is 7f86f1b1a891
[0712/111619.623281:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111619.623835:INFO:switcher_clone.cc(787)] backtrace rip is 7ff5af536891
[1:1:0712/111619.638688:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111619.639039:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111619.644891:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/111621.007930:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111621.008334:INFO:switcher_clone.cc(787)] backtrace rip is 7fa4115a0891
[129910:129910:0712/111621.069811:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f86e6c79-c15a-453a-a669-66d13184e1b6
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129943:129943:0712/111621.210075:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129943
[129954:129954:0712/111621.210518:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129954
[129910:129910:0712/111621.492553:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129910:129939:0712/111621.493335:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111621.493598:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111621.493869:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111621.494490:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111621.494678:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111621.498087:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3505a33e, 1
[1:1:0712/111621.498475:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x30b56c58, 0
[1:1:0712/111621.498672:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17cd0a0c, 3
[1:1:0712/111621.498863:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xbc52a19, 2
[1:1:0712/111621.499094:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 586cffffffb530 3effffffa30535 192affffffc50b 0c0affffffcd17 , 10104, 4
[1:1:0712/111621.500411:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129910:129939:0712/111621.500681:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGXl�0>�5*�
��NE
[129910:129939:0712/111621.500771:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Xl�0>�5*�
�8��NE
[1:1:0712/111621.500664:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5ad7710a0, 3
[1:1:0712/111621.500919:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5ad8fc080, 2
[129910:129939:0712/111621.501122:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111621.501104:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5975bfd20, -2
[129910:129939:0712/111621.501207:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129962, 4, 586cb530 3ea30535 192ac50b 0c0acd17 
[1:1:0712/111621.521648:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111621.522709:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bc52a19
[1:1:0712/111621.523822:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bc52a19
[1:1:0712/111621.525690:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bc52a19
[1:1:0712/111621.527448:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.527682:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.527896:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.528122:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.528878:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bc52a19
[1:1:0712/111621.529261:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff5af5367ba
[1:1:0712/111621.529411:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff5af52ddef, 7ff5af53677a, 7ff5af5380cf
[1:1:0712/111621.530799:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal bc52a19
[1:1:0712/111621.530955:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal bc52a19
[1:1:0712/111621.531223:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal bc52a19
[1:1:0712/111621.531904:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.532015:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.532109:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.532200:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal bc52a19
[1:1:0712/111621.532656:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal bc52a19
[1:1:0712/111621.532816:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff5af5367ba
[1:1:0712/111621.532888:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff5af52ddef, 7ff5af53677a, 7ff5af5380cf
[1:1:0712/111621.536792:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111621.537073:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111621.537163:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe15b3f348, 0x7ffe15b3f2c8)
[1:1:0712/111621.554068:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111621.559672:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[129910:129910:0712/111622.141829:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129910:129910:0712/111622.143222:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129910:129921:0712/111622.165506:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129910:129921:0712/111622.165641:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129910:129910:0712/111622.165910:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129910:129910:0712/111622.166006:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129910:129910:0712/111622.166183:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129962, 4
[1:7:0712/111622.172078:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[129910:129934:0712/111622.221823:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111622.316792:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x750144a2220
[1:1:0712/111622.317143:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/111622.780281:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[129910:129910:0712/111624.538440:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129910:129910:0712/111624.538593:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111624.552859:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111624.556883:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111625.929679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111625.930018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111625.959990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111625.960272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111625.990674:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111626.345161:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111626.345578:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111626.566212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111626.571888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111626.572154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111626.609336:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111626.620431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111626.620732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111626.631657:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129910:129910:0712/111626.636094:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111626.636577:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x750144a0e20
[1:1:0712/111626.636812:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129910:129910:0712/111626.643322:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129910:129910:0712/111626.668426:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129910:129910:0712/111626.668526:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111626.739383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111627.756699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7ff59919a2e0 0x7501472fee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111627.758162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111627.758408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111627.760013:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129910:129910:0712/111627.830637:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111627.831285:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x750144a1820
[1:1:0712/111627.831642:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111627.850328:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[129910:129910:0712/111627.850725:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111627.850584:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129910:129910:0712/111627.864645:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129910:129910:0712/111627.872176:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129910:129910:0712/111627.874902:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129910:129921:0712/111627.879166:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129910:129921:0712/111627.879251:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[129910:129910:0712/111627.879517:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129910:129910:0712/111627.879611:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129910:129910:0712/111627.879775:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129962, 4
[1:7:0712/111627.883567:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111628.655841:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[129910:129910:0712/111628.720659:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129910:129939:0712/111628.721198:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111628.721418:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111628.721669:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111628.722088:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111628.722233:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111628.725432:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x77b00d6, 1
[1:1:0712/111628.725848:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1915fa5d, 0
[1:1:0712/111628.726093:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1a94ab26, 3
[1:1:0712/111628.726293:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xee7a08f, 2
[1:1:0712/111628.726495:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5dfffffffa1519 ffffffd6007b07 ffffff8fffffffa0ffffffe70e 26ffffffabffffff941a , 10104, 5
[1:1:0712/111628.727569:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129910:129939:0712/111628.727835:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING]��
[129910:129939:0712/111628.727904:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ]��
[1:1:0712/111628.728066:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5ad7710a0, 3
[129910:129939:0712/111628.728247:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130006, 5, 5dfa1519 d6007b07 8fa0e70e 26ab941a 
[1:1:0712/111628.728305:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5ad8fc080, 2
[1:1:0712/111628.728558:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff5975bfd20, -2
[1:1:0712/111628.749754:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111628.750230:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ee7a08f
[1:1:0712/111628.750607:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ee7a08f
[1:1:0712/111628.751298:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ee7a08f
[1:1:0712/111628.752784:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.753019:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.753265:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.753503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.754247:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ee7a08f
[1:1:0712/111628.754590:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff5af5367ba
[1:1:0712/111628.754767:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff5af52ddef, 7ff5af53677a, 7ff5af5380cf
[1:1:0712/111628.760587:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ee7a08f
[1:1:0712/111628.761012:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ee7a08f
[1:1:0712/111628.761805:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ee7a08f
[1:1:0712/111628.764434:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.764769:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.765068:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.765346:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ee7a08f
[1:1:0712/111628.766868:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ee7a08f
[1:1:0712/111628.767401:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff5af5367ba
[1:1:0712/111628.767644:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff5af52ddef, 7ff5af53677a, 7ff5af5380cf
[1:1:0712/111628.776496:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111628.777217:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111628.777486:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe15b3f348, 0x7ffe15b3f2c8)
[1:1:0712/111628.790622:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111628.795283:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111628.965036:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x75014482220
[1:1:0712/111628.965425:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111629.236984:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7ff59919a2e0 0x750147f74e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111629.238304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111629.238550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111629.239347:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111629.365941:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[129910:129910:0712/111629.373891:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129910:129910:0712/111629.374016:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111629.861107:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111630.230628:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111630.230900:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129910:129910:0712/111630.464308:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129910:129910:0712/111630.470081:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129910:129910:0712/111630.500833:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.nt.house365.com/
[129910:129910:0712/111630.500890:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.nt.house365.com/, http://newhouse.nt.house365.com/, 1
[129910:129910:0712/111630.500952:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.nt.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:16:30 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=t0v9fdci7vshbnghg5ql978in2; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,130006, 5
[129910:129921:0712/111630.505064:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129910:129921:0712/111630.505116:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111630.506371:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111630.529154:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.nt.house365.com/
[1:1:0712/111630.622815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111630.627804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c728bfce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111630.628117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111630.635171:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129910:129910:0712/111630.682767:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.nt.house365.com/, http://newhouse.nt.house365.com/, 1
[129910:129910:0712/111630.682899:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.nt.house365.com/, http://newhouse.nt.house365.com
[1:1:0712/111630.689249:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111630.794668:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111630.831804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111630.832573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c728bea1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111630.832793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111630.863575:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111630.885449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111630.885732:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111632.337567:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111632.862823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111632.882694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/111632.882999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "newhouse.nt.house365.com", 3, 1, , , 0
[1:1:0712/111632.885068:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_21babdcb -> 0
[1:1:0712/111633.150063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111633.204824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111633.509631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111633.512448:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.nt.house365.com", "house365.com"
[1:1:0712/111633.520089:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111633.524907:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7ff5975dabd0 0x750146801d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111633.807385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248, "http://newhouse.nt.house365.com/"
[1:1:0712/111633.810022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.write("    <link rel=\"stylesheet\" href=\"http://pic.house365.com/head/css/publicHead/icon
[1:1:0712/111633.810280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111634.961798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 318, "http://newhouse.nt.house365.com/"
[1:1:0712/111634.963644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111634.963845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111635.676823:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111636.161684:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111636.161938:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111636.554060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 401 0x7ff5975dabd0 0x7501492b758 , "http://newhouse.nt.house365.com/"
[1:1:0712/111636.643092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111636.643418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111636.938099:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.025924, 144, 1
[1:1:0712/111636.938340:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111637.463693:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111637.463971:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111637.464810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7ff597272070 0x75014458660 , "http://newhouse.nt.house365.com/"
[1:1:0712/111637.466271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/111637.466457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111637.514881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7ff597272070 0x75014458660 , "http://newhouse.nt.house365.com/"
[1:1:0712/111638.733219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475, "http://newhouse.nt.house365.com/"
[1:1:0712/111638.737572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111638.737769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111639.160166:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111639.160690:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111639.161056:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111639.161472:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111639.161925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111639.674523:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111640.531637:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111640.531937:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111640.534746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7ff597272070 0x750149756e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111640.543098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111640.543306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111640.835761:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.303768, 52, 1
[1:1:0712/111640.836037:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111641.557374:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111641.557594:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111641.558341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568 0x7ff597272070 0x7501452ce60 , "http://newhouse.nt.house365.com/"
[1:1:0712/111641.559322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/111641.559516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111642.613245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 602 0x7ff5975dabd0 0x750145883d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111642.628164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111642.628370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111644.325192:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111644.325823:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111644.948825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 602 0x7ff5975dabd0 0x750145883d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111644.954432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 602 0x7ff5975dabd0 0x750145883d8 , "http://newhouse.nt.house365.com/"
[1:1:0712/111644.992175:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.050369, 177, 1
[1:1:0712/111644.992441:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111646.062689:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111646.062961:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111646.063860:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7ff597272070 0x750155adee0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111646.065632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/111646.065858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111646.088472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7ff597272070 0x750155adee0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111646.105208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7ff597272070 0x750155adee0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111646.129553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 642 0x7ff597272070 0x750155adee0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111648.647342:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111649.357446:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111649.357703:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111649.360035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7ff597272070 0x750147c29e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111649.361683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111649.361920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111649.369000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7ff597272070 0x750147c29e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111649.379468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7ff597272070 0x750147c29e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111649.432716:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111649.433254:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111649.433661:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111649.656568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7ff597272070 0x750147c29e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111649.777862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7ff597272070 0x750147c29e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111649.834656:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.476828, 232, 1
[1:1:0712/111649.834925:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111650.492821:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111650.493050:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111650.493970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 766 0x7ff597272070 0x75014547d60 , "http://newhouse.nt.house365.com/"
[1:1:0712/111650.496108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/111650.496384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111650.499892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 766 0x7ff597272070 0x75014547d60 , "http://newhouse.nt.house365.com/"
[1:1:0712/111650.573552:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0803831, 339, 1
[1:1:0712/111650.573823:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111651.279904:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111651.280166:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111651.281023:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 798 0x7ff597272070 0x750147c5ee0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111651.282040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250936_1").qrcode({
                                rend
[1:1:0712/111651.282257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_5c916f8 -> 0
		remove user.11_f13c4eb1 -> 0
		remove user.12_c8c23519 -> 0
		remove user.13_9c3b9425 -> 0
		remove user.14_5a424091 -> 0
		remove user.11_1e2bf375 -> 0
		remove user.12_45db79c7 -> 0
		remove user.13_3ab6e01b -> 0
		remove user.14_c79b664f -> 0
		remove user.15_4b84ed90 -> 0
[129910:129910:0712/111658.340650:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/111658.470677:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111708.829851:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 17.5495, 0, 0
[1:1:0712/111708.830041:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111709.583659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111709.583899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111710.713498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111710.713673:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111710.722176:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00854897, 69, 1
[1:1:0712/111710.722429:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111711.424084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111711.424292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111713.020512:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111713.020838:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111713.021829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 899 0x7ff597272070 0x75014dda060 , "http://newhouse.nt.house365.com/"
[1:1:0712/111713.023017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250920_1").qrcode({
                                rend
[1:1:0712/111713.023289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111716.506448:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.48549, 0, 0
[1:1:0712/111716.506742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111716.695374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111716.697991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111716.698240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111717.119400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111717.119769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111718.663418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111718.664261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111718.664543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111718.711222:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111718.711599:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111718.726475:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0146739, 77, 1
[1:1:0712/111718.726729:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111718.991574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111718.991774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111719.886677:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111719.886862:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111719.887522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7ff597272070 0x7501ccd3de0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111719.888254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode251228_3").qrcode({
                                rend
[1:1:0712/111719.888424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111720.257219:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.370409, 69, 1
[1:1:0712/111720.257469:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[129910:129910:0712/111720.384577:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111720.671130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111720.671412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111721.223478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111721.224233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111721.224418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111721.330078:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111721.330251:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111721.330889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1028 0x7ff597272070 0x7501e83e760 , "http://newhouse.nt.house365.com/"
[1:1:0712/111721.331626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250942_1").qrcode({
                                rend
[1:1:0712/111721.331743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111721.629746:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.299544, 69, 1
[1:1:0712/111721.629995:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111722.129235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111722.129556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111722.696636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111722.697162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111722.697310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111722.730272:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111722.730447:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111722.731101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1062 0x7ff597272070 0x75014b26760 , "http://newhouse.nt.house365.com/"
[1:1:0712/111722.731763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250948_1").qrcode({
                                rend
[1:1:0712/111722.731940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111723.080297:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.349893, 69, 1
[1:1:0712/111723.080541:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111723.591623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111723.591818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111724.055247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111724.055718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111724.055843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111724.155030:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111724.155232:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111724.155893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1102 0x7ff597272070 0x7501469a0e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111724.156521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode251222_1").qrcode({
                                rend
[1:1:0712/111724.156682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111724.458011:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.302775, 73, 1
[1:1:0712/111724.458202:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111724.750204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111724.750413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111725.248372:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111725.248895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111725.249024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111725.396981:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111725.397167:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111725.397835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1127 0x7ff597272070 0x750180d2460 , "http://newhouse.nt.house365.com/"
[1:1:0712/111725.398457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode251074_1").qrcode({
                                rend
[1:1:0712/111725.398628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111725.718317:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.321195, 69, 1
[1:1:0712/111725.718586:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111726.152735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111726.153094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111726.840054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111726.840521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111726.840639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111726.987493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111726.987781:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111726.989105:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1160 0x7ff597272070 0x7501f3b7260 , "http://newhouse.nt.house365.com/"
[1:1:0712/111726.990448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode251042_1").qrcode({
                                rend
[1:1:0712/111726.990690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111727.377706:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.389782, 69, 1
[1:1:0712/111727.378056:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111727.734262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , document.readyState
[1:1:0712/111727.734544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111728.249966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111728.250705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111728.250885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111728.384011:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111728.384190:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111728.384855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1194 0x7ff597272070 0x7501f078be0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111728.385498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250954_1").qrcode({
                                rend
[1:1:0712/111728.385655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111728.790350:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.406183, 124, 1
[1:1:0712/111728.790608:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111729.868150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111729.868861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111729.869119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111729.983351:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111729.983549:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111729.984278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1225 0x7ff597272070 0x7501b8b8560 , "http://newhouse.nt.house365.com/"
[1:1:0712/111729.984981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode250934_1").qrcode({
                                rend
[1:1:0712/111729.985141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111730.322120:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.338488, 69, 1
[1:1:0712/111730.322312:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111731.180404:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111731.180966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111731.181131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111731.243097:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111731.243285:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nt.house365.com/"
[1:1:0712/111731.244021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1252 0x7ff597272070 0x7501d3d97e0 , "http://newhouse.nt.house365.com/"
[1:1:0712/111731.244668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , , 
                            $("#lptelqrcode251010_1").qrcode({
                                rend
[1:1:0712/111731.244864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111731.531418:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.288183, 69, 1
[1:1:0712/111731.531655:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111732.337676:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nt.house365.com/"
[1:1:0712/111732.338128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nt.house365.com/, 004955f02860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111732.338262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nt.house365.com/", "house365.com", 3, 1, , , 0
