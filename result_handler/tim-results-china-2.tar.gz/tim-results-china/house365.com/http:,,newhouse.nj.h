[0712/110848.173765:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110848.174045:INFO:switcher_clone.cc(787)] backtrace rip is 7f55b86b8891
[0712/110849.058427:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110849.058676:INFO:switcher_clone.cc(787)] backtrace rip is 7f063d50e891
[1:1:0712/110849.072212:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/110849.072476:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/110849.078253:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/110850.365443:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110850.365725:INFO:switcher_clone.cc(787)] backtrace rip is 7f9a5af61891
[129059:129059:0712/110850.371618:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/85809b91-cc56-4ac1-b428-44130e6b4eb1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129091:129091:0712/110850.538507:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129091
[129103:129103:0712/110850.538946:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129103
[129059:129059:0712/110850.920154:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129059:129088:0712/110850.920966:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/110850.921179:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110850.921422:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110850.922010:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110850.922181:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/110850.925359:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x12575539, 1
[1:1:0712/110850.925620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15f4a7b1, 0
[1:1:0712/110850.925717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x8d16e53, 3
[1:1:0712/110850.925814:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x37e2eb34, 2
[1:1:0712/110850.925931:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb1ffffffa7fffffff415 39555712 34ffffffebffffffe237 536effffffd108 , 10104, 4
[1:1:0712/110850.926594:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1:1:0712/110850.926743:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f063b7490a0, 3
[129059:129088:0712/110850.926770:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���9UW4��7Sn�Ǳ
[129059:129088:0712/110850.926861:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���9UW4��7Sn��(Ǳ
[1:1:0712/110850.926850:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f063b8d4080, 2
[1:1:0712/110850.926937:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0625597d20, -2
[129059:129088:0712/110850.927111:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[129059:129088:0712/110850.927187:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129111, 4, b1a7f415 39555712 34ebe237 536ed108 
[1:1:0712/110850.942880:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110850.943560:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37e2eb34
[1:1:0712/110850.944226:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37e2eb34
[1:1:0712/110850.945327:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37e2eb34
[1:1:0712/110850.945856:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.945965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.946057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.946160:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.946401:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37e2eb34
[1:1:0712/110850.946561:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f063d50e7ba
[1:1:0712/110850.946650:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f063d505def, 7f063d50e77a, 7f063d5100cf
[1:1:0712/110850.948074:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37e2eb34
[1:1:0712/110850.948232:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37e2eb34
[1:1:0712/110850.948579:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37e2eb34
[1:1:0712/110850.949276:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.949386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.949480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.949575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37e2eb34
[1:1:0712/110850.950009:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37e2eb34
[1:1:0712/110850.950176:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f063d50e7ba
[1:1:0712/110850.950274:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f063d505def, 7f063d50e77a, 7f063d5100cf
[1:1:0712/110850.953999:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110850.954283:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110850.954378:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe50a1b568, 0x7ffe50a1b4e8)
[1:1:0712/110850.968460:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110850.974125:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[129059:129059:0712/110851.620657:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129059:129059:0712/110851.621830:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129059:129070:0712/110851.642440:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129059:129070:0712/110851.642545:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129059:129059:0712/110851.642691:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129059:129059:0712/110851.642770:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129059:129059:0712/110851.642907:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129111, 4
[1:7:0712/110851.644897:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[129059:129083:0712/110851.678736:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/110851.716899:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1794691e6220
[1:1:0712/110851.717192:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/110852.041851:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[129059:129059:0712/110853.720174:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129059:129059:0712/110853.720297:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110853.734785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110853.737054:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110854.843227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110854.843578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110854.850286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110854.850515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110854.872130:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110855.032097:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110855.032381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110855.426570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110855.434963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110855.435258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110855.469956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110855.480653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110855.480946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110855.492905:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129059:129059:0712/110855.494318:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110855.496173:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1794691e4e20
[1:1:0712/110855.496404:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129059:129059:0712/110855.498161:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129059:129059:0712/110855.539256:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129059:129059:0712/110855.539456:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110855.567105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110856.300726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f06271722e0 0x1794693572e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110856.302219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/110856.302439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110856.304009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129059:129059:0712/110856.366439:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110856.368613:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1794691e5820
[1:1:0712/110856.368871:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129059:129059:0712/110856.378096:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/110856.381817:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/110856.382072:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129059:129059:0712/110856.399339:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129059:129059:0712/110856.411149:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129059:129059:0712/110856.412425:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129059:129059:0712/110856.417716:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129059:129070:0712/110856.417696:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129059:129059:0712/110856.417765:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129059:129059:0712/110856.417828:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129111, 4
[129059:129070:0712/110856.417813:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/110856.426289:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110856.975325:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/110857.561608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7f06271722e0 0x1794695b5060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110857.562654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/110857.562906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110857.563660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129059:129059:0712/110857.690036:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129059:129059:0712/110857.690152:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/110857.715609:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110858.278402:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[129059:129059:0712/110858.465361:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129059:129088:0712/110858.465825:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/110858.466045:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110858.466330:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110858.466768:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110858.466960:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/110858.470296:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1961a53f, 1
[1:1:0712/110858.470733:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x293749cf, 0
[1:1:0712/110858.470945:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x98ada42, 3
[1:1:0712/110858.471183:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1d19a36e, 2
[1:1:0712/110858.471386:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcf493729 3fffffffa56119 6effffffa3191d 42ffffffdaffffff8a09 , 10104, 5
[1:1:0712/110858.472454:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129059:129088:0712/110858.472747:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�I7)?�an�Bڊ	��
[129059:129088:0712/110858.472837:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �I7)?�an�Bڊ	H#��
[1:1:0712/110858.472728:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f063b7490a0, 3
[1:1:0712/110858.472985:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f063b8d4080, 2
[129059:129088:0712/110858.473160:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129154, 5, cf493729 3fa56119 6ea3191d 42da8a09 
[1:1:0712/110858.473283:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0625597d20, -2
[1:1:0712/110858.489700:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110858.490125:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d19a36e
[1:1:0712/110858.490469:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d19a36e
[1:1:0712/110858.491141:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d19a36e
[1:1:0712/110858.492616:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.492870:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.493130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.493356:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.494073:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d19a36e
[1:1:0712/110858.494398:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f063d50e7ba
[1:1:0712/110858.494573:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f063d505def, 7f063d50e77a, 7f063d5100cf
[1:1:0712/110858.500225:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1d19a36e
[1:1:0712/110858.500605:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1d19a36e
[1:1:0712/110858.501343:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1d19a36e
[1:1:0712/110858.503380:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.503669:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.503901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.504170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1d19a36e
[1:1:0712/110858.505610:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1d19a36e
[1:1:0712/110858.506054:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f063d50e7ba
[1:1:0712/110858.506240:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f063d505def, 7f063d50e77a, 7f063d5100cf
[1:1:0712/110858.514167:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110858.514786:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110858.514979:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe50a1b568, 0x7ffe50a1b4e8)
[1:1:0712/110858.529686:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110858.534608:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/110858.755594:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110858.755885:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110858.810172:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1794691b3220
[1:1:0712/110858.810499:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129059:129059:0712/110859.141885:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129059:129059:0712/110859.148435:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129059:129070:0712/110859.198098:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129059:129070:0712/110859.198216:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129059:129059:0712/110859.208015:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.nj.house365.com/
[129059:129059:0712/110859.208129:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.nj.house365.com/, http://newhouse.nj.house365.com/, 1
[129059:129059:0712/110859.208323:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.nj.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:08:59 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=b7kf5bdktu1v77vpl3sr148kg3; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,129154, 5
[1:7:0712/110859.212135:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110859.241177:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.nj.house365.com/
[1:1:0712/110859.269495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110859.274130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 23830956e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/110859.274518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110859.282516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129059:129059:0712/110859.346543:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.nj.house365.com/, http://newhouse.nj.house365.com/, 1
[129059:129059:0712/110859.346680:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.nj.house365.com/, http://newhouse.nj.house365.com
[1:1:0712/110859.348521:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110859.449486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110859.450294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 238309441f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/110859.450520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110859.468614:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110859.529985:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110859.586744:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110859.587015:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110859.705883:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110859.979136:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110900.126956:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110900.762951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f06255b2bd0 0x179469395958 , "http://newhouse.nj.house365.com/"
[1:1:0712/110900.781896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/110900.782211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "newhouse.nj.house365.com", 3, 1, , , 0
[1:1:0712/110900.784228:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110900.933027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f06255b2bd0 0x179469395958 , "http://newhouse.nj.house365.com/"
[1:1:0712/110900.965647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 229 0x7f06255b2bd0 0x179469395958 , "http://newhouse.nj.house365.com/"
[1:1:0712/110901.017132:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110901.020200:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110901.022530:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110901.023052:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110901.023656:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110901.834510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f062524a070 0x179469537ae0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110901.835784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'nj';
    var uid = '';
    var fav_prjid =
[1:1:0712/110901.836206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "newhouse.nj.house365.com", 3, 1, , , 0
[1:1:0712/110901.838254:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.nj.house365.com", "house365.com"
[1:1:0712/110901.846530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f062524a070 0x179469537ae0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110901.849435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f062524a070 0x179469537ae0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110901.861582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 297 0x7f062524a070 0x179469537ae0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110902.281527:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.nj.house365.com/?action=shopfbsimshow"
[1:1:0712/110902.635233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 345, "http://newhouse.nj.house365.com/"
[1:1:0712/110902.637059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110902.637326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110903.281894:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110903.817785:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110903.818051:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110904.253033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7f06255b2bd0 0x1794693907d8 , "http://newhouse.nj.house365.com/"
[1:1:0712/110904.275005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110904.275205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_6c7d1d02 -> 0
		remove user.11_c131cde2 -> 0
		remove user.12_6c44e08c -> 0
		remove user.13_479cd398 -> 0
		remove user.14_3978e9d2 -> 0
[1:1:0712/110904.444537:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.027391, 144, 1
[1:1:0712/110904.444789:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110904.773028:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.nj.house365.com/?action=shopfbsimshow"
[1:1:0712/110905.127277:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110905.127448:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110905.128439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f062524a070 0x1794696f00e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110905.129921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/110905.130117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110905.158761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f062524a070 0x1794696f00e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110906.538069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "http://newhouse.nj.house365.com/"
[1:1:0712/110906.539522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110906.539650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110907.603294:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110908.431968:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110908.432153:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110908.433300:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7f062524a070 0x1794692bfd60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110908.435210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110908.435355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110908.719857:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.287771, 52, 1
[1:1:0712/110908.720116:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110908.942381:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.nj.house365.com/?action=shopfbsimshow"
[1:1:0712/110909.209381:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110909.209627:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110909.210211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 681 0x7f062524a070 0x179469734960 , "http://newhouse.nj.house365.com/"
[1:1:0712/110909.210952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/110909.211104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110909.743939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 702 0x7f06255b2bd0 0x1794693933d8 , "http://newhouse.nj.house365.com/"
[1:1:0712/110909.748137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/110909.748308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110911.014904:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 702 0x7f06255b2bd0 0x1794693933d8 , "http://newhouse.nj.house365.com/"
[1:1:0712/110911.021603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 702 0x7f06255b2bd0 0x1794693933d8 , "http://newhouse.nj.house365.com/"
[1:1:0712/110911.064786:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.051971, 189, 1
[1:1:0712/110911.065127:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110911.877327:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110911.877601:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110911.878530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 728 0x7f062524a070 0x17946a3b8760 , "http://newhouse.nj.house365.com/"
[1:1:0712/110911.880301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/110911.880538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110911.898338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 728 0x7f062524a070 0x17946a3b8760 , "http://newhouse.nj.house365.com/"
[1:1:0712/110911.911486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 728 0x7f062524a070 0x17946a3b8760 , "http://newhouse.nj.house365.com/"
[1:1:0712/110911.929837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 728 0x7f062524a070 0x17946a3b8760 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.143570:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110914.705905:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110914.706188:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110914.708455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f062524a070 0x17946950dce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.710197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/110914.710434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110914.718047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f062524a070 0x17946950dce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.728305:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f062524a070 0x17946950dce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.847166:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f062524a070 0x17946950dce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.919042:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 775 0x7f062524a070 0x17946950dce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110914.978758:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.272601, 232, 1
[1:1:0712/110914.979171:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110915.044910:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.nj.house365.com/?action=shopfbsimshow"
[1:1:0712/110915.388353:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110915.395662:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110915.396086:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110915.396534:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110915.396932:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110915.635439:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110915.635714:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110915.636714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7f062524a070 0x17946a8caee0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110915.638864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/110915.639142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110915.643179:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 797 0x7f062524a070 0x17946a8caee0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110915.759493:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.123661, 512, 1
[1:1:0712/110915.759788:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110916.049051:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110916.049332:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110916.050257:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 813 0x7f062524a070 0x17946ab3dd60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110916.051337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode248043_1").qrcode({
                                rend
[1:1:0712/110916.051560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_c1f8a3f4 -> 0
		remove user.12_272a08b8 -> 0
		remove user.13_fe83928d -> 0
		remove user.14_a4396054 -> 0
		remove user.15_53209457 -> 0
[129059:129059:0712/110923.443358:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/110923.480096:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/110935.684876:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.6354, 0, 0
[1:1:0712/110935.685120:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110935.979768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/110935.980017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110937.185984:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110937.186192:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110937.196203:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0100079, 89, 1
[1:1:0712/110937.196394:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110937.409081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110937.409280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110938.988359:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110938.988649:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110938.989625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7f062524a070 0x179471c5d460 , "http://newhouse.nj.house365.com/"
[1:1:0712/110938.990768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode252462_1").qrcode({
                                rend
[1:1:0712/110938.991012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110942.065297:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.07654, 0, 0
[1:1:0712/110942.065593:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110942.119112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110942.121156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110942.121406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110942.162574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110942.162871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110944.184276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110944.185070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110944.185318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110944.222206:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110944.222368:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110944.228396:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00599408, 94, 1
[1:1:0712/110944.228536:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110944.266368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110944.266543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110945.408057:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110945.408289:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110945.409281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7f062524a070 0x179473686a60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110945.410351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode235877_1").qrcode({
                                rend
[1:1:0712/110945.410565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[129059:129059:0712/110945.701171:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/110945.771779:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.363375, 90, 1
[1:1:0712/110945.772006:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110945.822794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110945.822982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110946.415697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110946.416443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110946.416631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110946.624761:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110946.624931:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110946.625542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 963 0x7f062524a070 0x179471c6b460 , "http://newhouse.nj.house365.com/"
[1:1:0712/110946.626154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode251926_1").qrcode({
                                rend
[1:1:0712/110946.626298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110946.911731:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.286889, 90, 1
[1:1:0712/110946.912018:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110947.095543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110947.095859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110947.680209:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110947.681016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110947.681242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110947.904988:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110947.905254:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110947.906258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f062524a070 0x179472491b60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110947.907347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode248183_1").qrcode({
                                rend
[1:1:0712/110947.907639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110948.214724:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.309381, 92, 1
[1:1:0712/110948.215007:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110948.283758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110948.284046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110948.705684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110948.706498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110948.706724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110948.827124:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110948.827398:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110948.828574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1004 0x7f062524a070 0x179473a6e3e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110948.829715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode241095_1").qrcode({
                                rend
[1:1:0712/110948.830002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110949.100913:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.273371, 99, 1
[1:1:0712/110949.101198:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110949.194053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110949.194353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110949.781226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110949.781986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110949.782248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110949.883374:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110949.883681:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110949.884795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1026 0x7f062524a070 0x179473695460 , "http://newhouse.nj.house365.com/"
[1:1:0712/110949.885895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode247819_1").qrcode({
                                rend
[1:1:0712/110949.886187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110950.282552:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.398762, 86, 1
[1:1:0712/110950.282835:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110950.425600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110950.425891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110950.920444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110950.921223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110950.921494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110951.157078:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110951.157352:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110951.158445:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1051 0x7f062524a070 0x179473693be0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110951.159582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode246993_1").qrcode({
                                rend
[1:1:0712/110951.159875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110951.568290:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.410871, 88, 1
[1:1:0712/110951.568631:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110951.628575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110951.628877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110952.252959:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110952.253778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110952.254003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110952.476859:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110952.477159:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110952.478280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1075 0x7f062524a070 0x17946b578ce0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110952.479483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode226957_1").qrcode({
                                rend
[1:1:0712/110952.479814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110952.763994:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.286743, 95, 1
[1:1:0712/110952.764360:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110952.896901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110952.897201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110953.214840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110953.215854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110953.216161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110953.410370:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110953.410663:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110953.411814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f062524a070 0x1794726bb8e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110953.412964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode305_1").qrcode({
                                render 
[1:1:0712/110953.413213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110953.709063:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.298302, 86, 1
[1:1:0712/110953.709387:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110953.836306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110953.836620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110954.432697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110954.433481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110954.433708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110954.630860:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110954.631155:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110954.632271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1119 0x7f062524a070 0x179473ed9ae0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110954.633363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode102453_1").qrcode({
                                rend
[1:1:0712/110954.633592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110954.762167:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.130913, 92, 1
[1:1:0712/110954.762474:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110954.878103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110954.878466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110955.345079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110955.345985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110955.346280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110955.465792:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110955.466077:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110955.467144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1139 0x7f062524a070 0x179473f2bb60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110955.468272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode237061_1").qrcode({
                                rend
[1:1:0712/110955.468604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110955.662157:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.195986, 97, 1
[1:1:0712/110955.662473:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110955.774371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110955.774803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110956.256420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110956.257251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110956.257496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110956.456738:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110956.457024:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110956.458132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f062524a070 0x1794745ece60 , "http://newhouse.nj.house365.com/"
[1:1:0712/110956.459273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode248177_1").qrcode({
                                rend
[1:1:0712/110956.459564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110957.606825:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.14974, 0, 0
[1:1:0712/110957.607155:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110957.687432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , document.readyState
[1:1:0712/110957.687753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110958.268259:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110958.269116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110958.269462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110958.324414:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110958.324714:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110958.338013:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0132248, 97, 1
[1:1:0712/110958.338328:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110958.766873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110958.767185:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110958.769047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1204 0x7f062524a070 0x179468d941e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110958.770011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode232243_1").qrcode({
                                rend
[1:1:0712/110958.770301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110959.067717:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.300426, 103, 1
[1:1:0712/110959.068027:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110959.592426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/110959.593229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110959.593495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110959.807280:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110959.807576:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/110959.808667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1223 0x7f062524a070 0x1794747b58e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/110959.809820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
                            $("#lptelqrcode236397_1").qrcode({
                                rend
[1:1:0712/110959.810082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111000.193788:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.386134, 54, 1
[1:1:0712/111000.194092:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111000.767041:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.nj.house365.com/"
[1:1:0712/111000.767887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111000.768131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111000.811827:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111000.812124:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/111000.813191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1243 0x7f062524a070 0x1794745294e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/111000.814258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 
listCondition.p=1;
var totalpage=136;

[1:1:0712/111000.814505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111000.858214:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.046006, 254, 1
[1:1:0712/111000.858510:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111001.951634:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111001.951952:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.nj.house365.com/"
[1:1:0712/111001.953048:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1265 0x7f062524a070 0x1794747f96e0 , "http://newhouse.nj.house365.com/"
[1:1:0712/111001.954497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.nj.house365.com/, 111357922860, , , 

            var num="176036";
            var call="4008908365,501";
            var fbscity="nj";
[1:1:0712/111001.954742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.nj.house365.com/", "house365.com", 3, 1, , , 0
