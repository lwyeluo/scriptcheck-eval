[0712/111348.314723:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111348.315047:INFO:switcher_clone.cc(787)] backtrace rip is 7f5b50dcd891
[0712/111349.352315:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111349.352752:INFO:switcher_clone.cc(787)] backtrace rip is 7fe0edfeb891
[1:1:0712/111349.366035:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111349.366386:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111349.371730:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/111350.598740:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111350.599002:INFO:switcher_clone.cc(787)] backtrace rip is 7f66da52c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129683:129683:0712/111350.785727:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129683
[129693:129693:0712/111350.786135:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129693
[129650:129650:0712/111351.007563:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ae5eb9e8-570c-4bb9-8ebb-ad6aedb0f94f
[129650:129650:0712/111351.618188:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129650:129681:0712/111351.619878:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111351.620568:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111351.621489:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111351.622139:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111351.622303:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111351.625878:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x910ed60, 1
[1:1:0712/111351.626628:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xccf227b, 0
[1:1:0712/111351.627146:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x205088ba, 3
[1:1:0712/111351.627831:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x16486652, 2
[1:1:0712/111351.628332:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7b22ffffffcf0c 60ffffffed1009 52664816 ffffffbaffffff885020 , 10104, 4
[1:1:0712/111351.630852:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129650:129681:0712/111351.631652:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING{"�`�	RfH��P ɞ�
[129650:129681:0712/111351.631860:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is {"�`�	RfH��P �8ɞ�
[129650:129681:0712/111351.632434:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[129650:129681:0712/111351.632595:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129703, 4, 7b22cf0c 60ed1009 52664816 ba885020 
[1:1:0712/111351.632249:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0ec2260a0, 3
[1:1:0712/111351.634198:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0ec3b1080, 2
[1:1:0712/111351.634591:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0d6074d20, -2
[1:1:0712/111351.664029:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111351.665184:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16486652
[1:1:0712/111351.666470:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16486652
[1:1:0712/111351.668659:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16486652
[1:1:0712/111351.670598:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.670827:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.671073:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.671304:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.672037:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16486652
[1:1:0712/111351.672410:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe0edfeb7ba
[1:1:0712/111351.672587:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe0edfe2def, 7fe0edfeb77a, 7fe0edfed0cf
[1:1:0712/111351.678261:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 16486652
[1:1:0712/111351.678706:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 16486652
[1:1:0712/111351.679502:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 16486652
[1:1:0712/111351.681600:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.681851:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.682159:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.682410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 16486652
[1:1:0712/111351.683709:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 16486652
[1:1:0712/111351.684171:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe0edfeb7ba
[1:1:0712/111351.684374:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe0edfe2def, 7fe0edfeb77a, 7fe0edfed0cf
[1:1:0712/111351.692149:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111351.692608:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111351.692798:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe33db9d48, 0x7ffe33db9cc8)
[1:1:0712/111351.707040:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111351.712756:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[129650:129650:0712/111352.278145:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129650:129650:0712/111352.279533:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129650:129650:0712/111352.297917:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129650:129650:0712/111352.298011:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129650:129650:0712/111352.298185:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129703, 4
[129650:129662:0712/111352.302739:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129650:129662:0712/111352.302851:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111352.306570:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[129650:129674:0712/111352.376258:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111352.377423:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x17ca2bbbb220
[1:1:0712/111352.377786:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/111352.782813:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111354.057339:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111354.061214:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[129650:129650:0712/111354.447602:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129650:129650:0712/111354.447669:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111354.895419:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111355.242807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111355.243115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111355.249022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111355.249273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111355.282296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111355.282551:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111355.569218:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111355.578128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111355.578415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111355.612955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111355.623439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111355.623773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111355.635508:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111355.638853:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x17ca2bbb9e20
[1:1:0712/111355.639060:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129650:129650:0712/111355.639699:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[129650:129650:0712/111355.654119:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129650:129650:0712/111355.696425:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129650:129650:0712/111355.696587:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111355.740133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111356.247589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7fe0d7c4f2e0 0x17ca2bdaa060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111356.250649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111356.251156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111356.254971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129650:129650:0712/111356.332128:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111356.336327:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x17ca2bbba820
[1:1:0712/111356.336784:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129650:129650:0712/111356.347074:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111356.359267:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111356.359630:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129650:129650:0712/111356.367050:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129650:129650:0712/111356.379343:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129650:129650:0712/111356.381269:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129650:129662:0712/111356.388623:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129650:129662:0712/111356.388708:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[129650:129650:0712/111356.388890:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129650:129650:0712/111356.388971:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129650:129650:0712/111356.389111:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129703, 4
[1:7:0712/111356.393264:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111357.107857:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111357.539584:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fe0d7c4f2e0 0x17ca2bf8da60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111357.540676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111357.540948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111357.541709:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129650:129650:0712/111357.692348:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129650:129650:0712/111357.692506:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111357.716286:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111358.165340:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[129650:129650:0712/111358.416171:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129650:129681:0712/111358.416636:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111358.416842:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111358.417077:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111358.417464:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111358.417630:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111358.420787:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x27cd3a30, 1
[1:1:0712/111358.421255:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x192ddddb, 0
[1:1:0712/111358.421459:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10829bc2, 3
[1:1:0712/111358.421648:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1a4a924b, 2
[1:1:0712/111358.421845:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffdbffffffdd2d19 303affffffcd27 4bffffff924a1a ffffffc2ffffff9bffffff8210 , 10104, 5
[1:1:0712/111358.423134:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129650:129681:0712/111358.423452:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��-0:�'K�J�z��
[129650:129681:0712/111358.423523:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��-0:�'K�J��nz��
[1:1:0712/111358.423449:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0ec2260a0, 3
[1:1:0712/111358.423683:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0ec3b1080, 2
[129650:129681:0712/111358.423872:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129747, 5, dbdd2d19 303acd27 4b924a1a c29b8210 
[1:1:0712/111358.423974:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fe0d6074d20, -2
[1:1:0712/111358.451554:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111358.451860:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111358.452453:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111358.452824:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a4a924b
[1:1:0712/111358.453290:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a4a924b
[1:1:0712/111358.454125:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a4a924b
[1:1:0712/111358.455918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.456208:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.456444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.456679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.457530:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a4a924b
[1:1:0712/111358.457903:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe0edfeb7ba
[1:1:0712/111358.458104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe0edfe2def, 7fe0edfeb77a, 7fe0edfed0cf
[1:1:0712/111358.465575:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a4a924b
[1:1:0712/111358.466116:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a4a924b
[1:1:0712/111358.467323:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a4a924b
[1:1:0712/111358.470066:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.470292:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.470486:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.470679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a4a924b
[1:1:0712/111358.472199:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a4a924b
[1:1:0712/111358.472653:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fe0edfeb7ba
[1:1:0712/111358.472822:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fe0edfe2def, 7fe0edfeb77a, 7fe0edfed0cf
[1:1:0712/111358.481088:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111358.481636:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111358.481798:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe33db9d48, 0x7ffe33db9cc8)
[1:1:0712/111358.496777:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111358.502238:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111358.740457:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x17ca2bba5220
[1:1:0712/111358.740698:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111358.944441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111358.949070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ebab41ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111358.949371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111358.957812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111359.225921:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111359.226687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ebab40a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111359.226947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111359.414287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111359.416071:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111359.416346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ebab41ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111359.416628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[129650:129650:0712/111359.450567:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129650:129650:0712/111359.461894:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129650:129662:0712/111359.478423:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129650:129662:0712/111359.478569:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129650:129650:0712/111359.478694:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.hn.house365.com/
[129650:129650:0712/111359.478736:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hn.house365.com/, http://newhouse.hn.house365.com/, 1
[129650:129650:0712/111359.478834:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.hn.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:13:59 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=tvdrmkdambvd25lo5b0f3imo37; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,129747, 5
[1:7:0712/111359.485819:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111359.508688:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.hn.house365.com/
[1:1:0712/111359.584999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111359.585914:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111359.586188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ebab41ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111359.586495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[129650:129650:0712/111359.679213:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hn.house365.com/, http://newhouse.hn.house365.com/, 1
[129650:129650:0712/111359.679302:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.hn.house365.com/, http://newhouse.hn.house365.com
[1:1:0712/111359.695348:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111359.755319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111359.811468:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111359.851015:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111359.851187:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111400.158333:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/111400.265327:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/111400.606751:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111400.896979:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/111401.017581:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/111401.164476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fe0d608fbd0 0x17ca2bd538d8 , "http://newhouse.hn.house365.com/"
[1:1:0712/111401.186344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/111401.186522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "newhouse.hn.house365.com", 3, 1, , , 0
[1:1:0712/111401.187286:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111401.206211:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/111401.250439:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/111401.356875:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/111401.442373:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/111401.466826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fe0d608fbd0 0x17ca2bd538d8 , "http://newhouse.hn.house365.com/"
[1:1:0712/111401.482053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 205 0x7fe0d608fbd0 0x17ca2bd538d8 , "http://newhouse.hn.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111402.984297:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111402.985555:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111402.985973:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111402.986460:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111402.986900:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111410.091545:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 504 (Gateway Time-out)","http://headtop.house365.com/searchBannerHead.php?city=hn&css=1&type=js&base_code=utf8&bid=2"
[1:1:0712/111410.146019:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 504 (Gateway Time-out)","http://newhouse.hn.house365.com/public/css/365tf_xfhome.css"
[1:1:0712/111410.185298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7fe0d5d27070 0x17ca2bbb1ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111410.186392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'hn';
    var uid = '';
    var fav_prjid =
[1:1:0712/111410.186585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "newhouse.hn.house365.com", 3, 1, , , 0
[1:1:0712/111410.188811:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.hn.house365.com", "house365.com"
[1:1:0712/111410.197017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7fe0d5d27070 0x17ca2bbb1ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111410.199161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7fe0d5d27070 0x17ca2bbb1ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111410.201052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7fe0d5d27070 0x17ca2bbb1ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111410.525387:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332, "http://newhouse.hn.house365.com/"
[1:1:0712/111410.527010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111410.527197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111410.632493:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111410.707508:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111410.707691:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111410.750912:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 348 0x7fe0ec3b1080 0x17ca2bbcdec0 1 0 0x17ca2bbcded8 , "http://newhouse.hn.house365.com/"
[1:1:0712/111410.793334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111410.793605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_3d738ab9 -> 0
		remove user.11_5737673d -> 0
		remove user.13_3253a3 -> 0
		remove user.12_fe315747 -> 0
		remove user.14_cfe04f86 -> 0
[1:1:0712/111410.866541:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111410.923584:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.017462, 144, 1
[1:1:0712/111410.923905:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111411.062131:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111411.062367:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111411.063183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360 0x7fe0d5d27070 0x17ca2bcc9460 , "http://newhouse.hn.house365.com/"
[1:1:0712/111411.064649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/111411.064838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111411.107626:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360 0x7fe0d5d27070 0x17ca2bcc9460 , "http://newhouse.hn.house365.com/"
[1:1:0712/111411.449950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 371, "http://newhouse.hn.house365.com/"
[1:1:0712/111411.450889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111411.451048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[129650:129662:0712/111411.651370:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/111411.987955:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111412.220805:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111412.221031:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111412.223883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7fe0d5d27070 0x17ca2bcc15e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111412.231479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111412.231664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111412.343965:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.122938, 52, 1
[1:1:0712/111412.344343:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111412.541760:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111412.542036:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111412.542866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7fe0d5d27070 0x17ca2bfaae60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111412.543853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/111412.544121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111412.658500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe0ec3b1080 0x17ca2bfde240 1 0 0x17ca2bfde258 , "http://newhouse.hn.house365.com/"
[1:1:0712/111412.678040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111412.678317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111414.320074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe0ec3b1080 0x17ca2bfde240 1 0 0x17ca2bfde258 , "http://newhouse.hn.house365.com/"
[1:1:0712/111414.326529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7fe0ec3b1080 0x17ca2bfde240 1 0 0x17ca2bfde258 , "http://newhouse.hn.house365.com/"
[1:1:0712/111414.347051:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0327899, 81, 1
[1:1:0712/111414.347319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111414.745558:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111414.745830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111414.746705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fe0d5d27070 0x17ca2c8291e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111414.748385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/111414.748603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111414.769233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fe0d5d27070 0x17ca2c8291e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111414.790545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fe0d5d27070 0x17ca2c8291e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111414.827746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7fe0d5d27070 0x17ca2c8291e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.082331:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111417.268078:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111417.268312:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111417.270594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fe0d5d27070 0x17ca2ce679e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.272181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111417.272407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111417.279661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fe0d5d27070 0x17ca2ce679e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.304291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fe0d5d27070 0x17ca2ce679e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.403505:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111417.420108:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fe0d5d27070 0x17ca2ce679e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.504996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7fe0d5d27070 0x17ca2ce679e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.584037:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.315541, 232, 1
[1:1:0712/111417.584326:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111417.747941:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111417.748187:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111417.749093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 505 0x7fe0d5d27070 0x17ca2c8285e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.751068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/111417.751289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111417.754613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 505 0x7fe0d5d27070 0x17ca2c8285e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111417.815383:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0671289, 277, 1
[1:1:0712/111417.815677:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111418.083856:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111418.084132:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111418.085035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 517 0x7fe0d5d27070 0x17ca2ce96360 , "http://newhouse.hn.house365.com/"
[1:1:0712/111418.086131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode236799_2").qrcode({
                                rend
[1:1:0712/111418.086365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_f4af6d80 -> 0
		remove user.12_7c733d4d -> 0
[3:3:0712/111425.544486:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[129650:129650:0712/111432.656748:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111437.265210:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.181, 0, 0
[1:1:0712/111437.265477:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111437.424669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111437.425002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111437.953733:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111437.953943:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111437.958383:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00444889, 69, 1
[1:1:0712/111437.958579:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111438.160313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111438.160495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111439.355128:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111439.355487:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111439.356483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 568 0x7fe0d5d27070 0x17ca2cef4b60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111439.357555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode236787_4").qrcode({
                                rend
[1:1:0712/111439.357776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111443.066312:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.71074, 0, 0
[1:1:0712/111443.066657:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111443.126019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111443.128076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111443.128334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111443.159378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111443.159721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111444.195112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111444.195960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111444.196290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111444.212848:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111444.213129:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111444.232673:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0194371, 69, 1
[1:1:0712/111444.232969:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111444.267746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111444.268045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111444.788849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111444.789139:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111444.790182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 622 0x7fe0d5d27070 0x17ca2b54d3e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111444.791307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode241067_1").qrcode({
                                rend
[1:1:0712/111444.791608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111445.115107:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.325855, 85, 1
[1:1:0712/111445.115394:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111445.189698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111445.190012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111445.492714:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111445.493507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111445.493778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111445.550002:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111445.550301:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111445.551362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 638 0x7fe0d5d27070 0x17ca2bf09860 , "http://newhouse.hn.house365.com/"
[1:1:0712/111445.552633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode238967_1").qrcode({
                                rend
[1:1:0712/111445.552882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111445.915821:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.365412, 85, 1
[1:1:0712/111445.916132:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111445.939382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111445.939744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111446.247998:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111446.248993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111446.249276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111446.380420:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111446.380712:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111446.381963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 655 0x7fe0d5d27070 0x17ca2ca534e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111446.383066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode236797_1").qrcode({
                                rend
[1:1:0712/111446.383291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111446.652062:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111446.652860:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111446.653227:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111446.772657:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.391734, 73, 1
[1:1:0712/111446.772883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111446.822774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111446.823062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111447.211717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111447.212526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111447.212715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111447.262719:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111447.262897:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111447.263520:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 676 0x7fe0d5d27070 0x17ca2ca52ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111447.264192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode236807_1").qrcode({
                                rend
[1:1:0712/111447.264312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111447.614054:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.351189, 77, 1
[1:1:0712/111447.614311:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111447.642130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111447.642321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111447.938488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111447.938983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111447.939102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111448.056360:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111448.056668:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111448.057916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 694 0x7fe0d5d27070 0x17ca35d886e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111448.059287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode236765_1").qrcode({
                                rend
[1:1:0712/111448.059530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111448.507992:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.451214, 81, 1
[1:1:0712/111448.508386:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111448.590787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111448.591050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111449.047758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111449.048226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111449.048341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111449.154538:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111449.154818:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111449.155989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 716 0x7fe0d5d27070 0x17ca35f90060 , "http://newhouse.hn.house365.com/"
[1:1:0712/111449.157366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode241089_1").qrcode({
                                rend
[1:1:0712/111449.157655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111449.497302:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.342306, 215, 1
[1:1:0712/111449.497540:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111449.532627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111449.532816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111450.074865:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111450.075612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111450.075841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111450.237690:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111450.237880:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111450.238474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 736 0x7fe0d5d27070 0x17ca2ca51ce0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111450.239126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode238629_1").qrcode({
                                rend
[1:1:0712/111450.239266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
		remove user.13_26d0ddb2 -> 0
		remove user.14_254195dc -> 0
		remove user.15_6a364dc3 -> 0
[1:1:0712/111450.442473:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204602, 81, 1
[1:1:0712/111450.442667:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111450.504907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111450.505102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111450.727318:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111450.728245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111450.728500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111450.813989:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111450.814165:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111450.814766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 755 0x7fe0d5d27070 0x17ca363c5460 , "http://newhouse.hn.house365.com/"
[1:1:0712/111450.815404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
                            $("#lptelqrcode238553_1").qrcode({
                                rend
[1:1:0712/111450.815565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111451.241044:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.426883, 265, 1
[1:1:0712/111451.241235:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111451.259876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111451.260115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111451.740704:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hn.house365.com/"
[1:1:0712/111451.741199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111451.741340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111451.854385:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111451.854676:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111451.855863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 774 0x7fe0d5d27070 0x17ca36475160 , "http://newhouse.hn.house365.com/"
[1:1:0712/111451.857007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
listCondition.p=1;
var totalpage=3;

[1:1:0712/111451.857288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111451.875854:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0209711, 248, 1
[1:1:0712/111451.876038:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111451.934750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111451.935011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111452.714917:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111452.715221:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111452.716563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.717711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
    $(function(){
        $(".hotslide").on("click",function(){
            if($(this).children("im
[1:1:0712/111452.717958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111452.725454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.731424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.741301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.922424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.929813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.939843:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111452.958025:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111453.114145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111453.127132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111453.176028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111453.181887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fe0d5d27070 0x17ca3476da60 , "http://newhouse.hn.house365.com/"
[1:1:0712/111453.271044:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.55536, 0, 0
[1:1:0712/111453.271323:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111453.316631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111453.316941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[129650:129650:0712/111454.581190:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111455.443533:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111455.443815:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111455.445069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7fe0d5d27070 0x17ca364a98e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111455.446052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , 
    //消息定位的扩展字段
    //from tf_ios淘房iOS ，tf_android 淘房安卓，pc网页P
[1:1:0712/111455.446277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111455.454623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7fe0d5d27070 0x17ca364a98e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111455.464277:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7fe0d5d27070 0x17ca364a98e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111455.470952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7fe0d5d27070 0x17ca364a98e0 , "http://newhouse.hn.house365.com/"
[1:1:0712/111455.498611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7fe0d5d27070 0x17ca364a98e0 , "http://newhouse.hn.house365.com/"
[129650:129650:0712/111455.511235:INFO:CONSOLE(1952)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?a4916f4a10b456a6ea91f21d108685db, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.hn.house365.com/ (1952)
[129650:129650:0712/111455.519463:INFO:CONSOLE(1952)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?a4916f4a10b456a6ea91f21d108685db, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.hn.house365.com/ (1952)
[1:1:0712/111455.639034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111455.639346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111457.213394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111457.213706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111458.505219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , document.readyState
[1:1:0712/111458.505426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111458.952085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 944 0x7fe0d608fbd0 0x17ca367f8858 , "http://newhouse.hn.house365.com/"
[1:1:0712/111458.957538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , (function(){var h={},mt={},c={id:"a4916f4a10b456a6ea91f21d108685db",dm:["hn.house365.com"],js:"tongj
[1:1:0712/111458.957790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111458.997055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x106b9bac29c8, 0x17ca2b6cb160
[1:1:0712/111458.997300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.hn.house365.com/", 100
[1:1:0712/111458.997658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.hn.house365.com/, 952
[1:1:0712/111458.997874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 952 0x7fe0d5d27070 0x17ca2bda2ae0 , 5:3_http://newhouse.hn.house365.com/, 1, -5:3_http://newhouse.hn.house365.com/, 944 0x7fe0d608fbd0 0x17ca367f8858 
[1:1:0712/111500.505351:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111500.509329:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.hn.house365.com/, 952, 7fe0d866c881
[1:1:0712/111500.563445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d4d1b942860","ptid":"944 0x7fe0d608fbd0 0x17ca367f8858 ","rf":"5:3_http://newhouse.hn.house365.com/"}
[1:1:0712/111500.563887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.hn.house365.com/","ptid":"944 0x7fe0d608fbd0 0x17ca367f8858 ","rf":"5:3_http://newhouse.hn.house365.com/"}
[1:1:0712/111500.564410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.hn.house365.com/"
[1:1:0712/111500.565128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111500.565363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111500.566366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x106b9bac29c8, 0x17ca2b6cb150
[1:1:0712/111500.566576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.hn.house365.com/", 100
[1:1:0712/111500.567027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.hn.house365.com/, 1012
[1:1:0712/111500.567328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7fe0d5d27070 0x17ca364a7e60 , 5:3_http://newhouse.hn.house365.com/, 1, -5:3_http://newhouse.hn.house365.com/, 952 0x7fe0d5d27070 0x17ca2bda2ae0 
[1:1:0712/111501.050024:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111501.050238:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hn.house365.com/"
[1:1:0712/111501.051918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1011 0x7fe0d5d27070 0x17ca341f7860 , "http://newhouse.hn.house365.com/"
[1:1:0712/111501.053706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , , (function(){
	var parameters = {
			'guid'  : 'new_guid',
			'todayfirst' : 'new_todayfirst',
		
[1:1:0712/111501.053856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111501.200937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.hn.house365.com/, 1012, 7fe0d866c881
[1:1:0712/111501.250886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1d4d1b942860","ptid":"952 0x7fe0d5d27070 0x17ca2bda2ae0 ","rf":"5:3_http://newhouse.hn.house365.com/"}
[1:1:0712/111501.251334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.hn.house365.com/","ptid":"952 0x7fe0d5d27070 0x17ca2bda2ae0 ","rf":"5:3_http://newhouse.hn.house365.com/"}
[1:1:0712/111501.251851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.hn.house365.com/"
[1:1:0712/111501.252562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hn.house365.com/, 1d4d1b942860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111501.252795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111501.253671:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x106b9bac29c8, 0x17ca2b6cb150
[1:1:0712/111501.253885:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.hn.house365.com/", 100
[1:1:0712/111501.254356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.hn.house365.com/, 1062
[1:1:0712/111501.254609:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7fe0d5d27070 0x17ca341b4360 , 5:3_http://newhouse.hn.house365.com/, 1, -5:3_http://newhouse.hn.house365.com/, 1012 0x7fe0d5d27070 0x17ca364a7e60 
