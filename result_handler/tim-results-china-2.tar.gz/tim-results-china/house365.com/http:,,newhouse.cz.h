[0712/112315.070558:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112315.071040:INFO:switcher_clone.cc(787)] backtrace rip is 7f8cc4d97891
[0712/112315.957015:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112315.957282:INFO:switcher_clone.cc(787)] backtrace rip is 7fcda825f891
[1:1:0712/112315.961404:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/112315.961577:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/112315.966706:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/112317.369060:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112317.369349:INFO:switcher_clone.cc(787)] backtrace rip is 7f365791c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[130695:130695:0712/112317.530449:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[130729:130729:0712/112317.555813:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130729
[130739:130739:0712/112317.556189:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130739

DevTools listening on ws://127.0.0.1:9222/devtools/browser/790d3ad3-b84b-4221-a1cd-af1d372d5792
[130695:130695:0712/112318.053514:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[130695:130727:0712/112318.054142:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/112318.054379:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112318.054660:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112318.055272:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112318.055539:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/112318.058648:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x8c9e433, 1
[1:1:0712/112318.058995:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x11f17bb8, 0
[1:1:0712/112318.059193:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2465e5e1, 3
[1:1:0712/112318.059449:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1eba4f0, 2
[1:1:0712/112318.059834:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb87bfffffff111 33ffffffe4ffffffc908 fffffff0ffffffa4ffffffeb01 ffffffe1ffffffe56524 , 10104, 4
[1:1:0712/112318.060863:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130695:130727:0712/112318.061142:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�{�3������e$n�0
[130695:130727:0712/112318.061208:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �{�3������e$��n�0
[1:1:0712/112318.061130:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcda649a0a0, 3
[1:1:0712/112318.061352:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcda6625080, 2
[130695:130727:0712/112318.061542:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[130695:130727:0712/112318.061606:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130749, 4, b87bf111 33e4c908 f0a4eb01 e1e56524 
[1:1:0712/112318.061562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcd902e8d20, -2
[1:1:0712/112318.080580:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112318.081413:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1eba4f0
[1:1:0712/112318.082352:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1eba4f0
[1:1:0712/112318.083903:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1eba4f0
[1:1:0712/112318.085405:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.085628:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.085813:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.086001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.086654:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1eba4f0
[1:1:0712/112318.086987:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcda825f7ba
[1:1:0712/112318.087120:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcda8256def, 7fcda825f77a, 7fcda82610cf
[1:1:0712/112318.091076:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1eba4f0
[1:1:0712/112318.091242:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1eba4f0
[1:1:0712/112318.091531:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1eba4f0
[1:1:0712/112318.092202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.092316:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.092412:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.092537:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1eba4f0
[1:1:0712/112318.092985:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1eba4f0
[1:1:0712/112318.093142:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcda825f7ba
[1:1:0712/112318.093218:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcda8256def, 7fcda825f77a, 7fcda82610cf
[1:1:0712/112318.095397:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112318.095687:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112318.095782:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe61ad4688, 0x7ffe61ad4608)
[1:1:0712/112318.110061:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112318.114717:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[130695:130695:0712/112318.634106:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130695:130695:0712/112318.635478:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130695:130708:0712/112318.659459:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[130695:130708:0712/112318.659630:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[130695:130695:0712/112318.659783:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[130695:130695:0712/112318.659880:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[130695:130695:0712/112318.660170:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,130749, 4
[1:7:0712/112318.664750:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[130695:130721:0712/112318.685342:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/112318.790861:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xd75cf8d6220
[1:1:0712/112318.791123:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/112319.309683:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[130695:130695:0712/112320.834438:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[130695:130695:0712/112320.834558:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112320.869959:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112320.874029:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112321.714357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112321.715028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112321.742579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112321.743003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112321.834519:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112322.009911:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112322.010239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112322.230660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112322.238397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112322.238697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112322.273362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112322.283842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112322.284096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112322.295923:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/112322.299314:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd75cf8d4e20
[1:1:0712/112322.299563:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[130695:130695:0712/112322.314478:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[130695:130695:0712/112322.318128:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[130695:130695:0712/112322.335975:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[130695:130695:0712/112322.336166:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112322.396212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112323.164221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7fcd91ec32e0 0xd75cfadb560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112323.167221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/112323.167842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112323.171451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130695:130695:0712/112323.261633:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112323.264148:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xd75cf8d5820
[1:1:0712/112323.264545:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[130695:130695:0712/112323.271902:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/112323.286480:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/112323.286794:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[130695:130695:0712/112323.294311:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[130695:130695:0712/112323.326455:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130695:130695:0712/112323.327468:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130695:130708:0712/112323.333863:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[130695:130708:0712/112323.333954:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[130695:130695:0712/112323.334096:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[130695:130695:0712/112323.334171:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[130695:130695:0712/112323.334300:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,130749, 4
[1:7:0712/112323.344966:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112323.683868:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/112324.266519:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fcd91ec32e0 0xd75cfc6d060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112324.267603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/112324.267870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112324.268669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130695:130695:0712/112324.340292:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[130695:130695:0712/112324.340362:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/112324.343446:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112324.854750:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[130695:130695:0712/112325.586309:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[130695:130727:0712/112325.586810:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/112325.587016:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112325.587323:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112325.587762:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112325.587984:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/112325.591213:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2167e922, 1
[1:1:0712/112325.591617:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3adbd5d9, 0
[1:1:0712/112325.591834:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1ccd5ac, 3
[1:1:0712/112325.592021:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xd2380f2, 2
[1:1:0712/112325.592201:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd9ffffffd5ffffffdb3a 22ffffffe96721 fffffff2ffffff80230d ffffffacffffffd5ffffffcc01 , 10104, 5
[1:1:0712/112325.593315:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130695:130727:0712/112325.593572:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���:"�g!�#�����0
[130695:130727:0712/112325.593650:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���:"�g!�#�������0
[130695:130727:0712/112325.593900:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130795, 5, d9d5db3a 22e96721 f280230d acd5cc01 
[1:1:0712/112325.594254:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcda649a0a0, 3
[1:1:0712/112325.594535:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcda6625080, 2
[1:1:0712/112325.594777:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcd902e8d20, -2
[1:1:0712/112325.604573:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112325.604834:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112325.619734:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112325.620314:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d2380f2
[1:1:0712/112325.620929:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d2380f2
[1:1:0712/112325.621872:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d2380f2
[1:1:0712/112325.623673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.624059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.624403:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.624665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.625494:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d2380f2
[1:1:0712/112325.625944:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcda825f7ba
[1:1:0712/112325.626175:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcda8256def, 7fcda825f77a, 7fcda82610cf
[1:1:0712/112325.633523:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal d2380f2
[1:1:0712/112325.634026:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal d2380f2
[1:1:0712/112325.634877:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal d2380f2
[1:1:0712/112325.637370:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.637717:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.638026:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.638332:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal d2380f2
[1:1:0712/112325.640122:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal d2380f2
[1:1:0712/112325.640729:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcda825f7ba
[1:1:0712/112325.640957:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcda8256def, 7fcda825f77a, 7fcda82610cf
[1:1:0712/112325.647274:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112325.648146:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112325.648389:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe61ad4688, 0x7ffe61ad4608)
[1:1:0712/112325.666707:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112325.672881:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/112325.917391:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd75cf899220
[1:1:0712/112325.917670:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/112326.188349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112326.192629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 195da61ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/112326.192917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112326.201073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112326.266157:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112326.266957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 195da60c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/112326.267184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112326.318130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112326.319830:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/112326.320070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 195da61ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/112326.320348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112326.458377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112326.459301:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/112326.459593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 195da61ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/112326.459865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[130695:130695:0712/112326.591265:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130695:130695:0712/112326.596627:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130695:130708:0712/112326.636307:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[130695:130708:0712/112326.636406:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[130695:130695:0712/112326.636908:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.cz.house365.com/
[130695:130695:0712/112326.637006:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.cz.house365.com/, http://newhouse.cz.house365.com/, 1
[130695:130695:0712/112326.637165:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.cz.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:23:26 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=ngj6h025pv76bdh6qbbuli59m2; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,130795, 5
[1:7:0712/112326.640990:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112326.668717:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.cz.house365.com/
[1:1:0712/112326.675389:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/112326.760521:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112326.802238:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[130695:130695:0712/112326.829222:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.cz.house365.com/, http://newhouse.cz.house365.com/, 1
[130695:130695:0712/112326.829297:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.cz.house365.com/, http://newhouse.cz.house365.com
[1:1:0712/112326.855137:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112326.878998:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112326.879266:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112327.137207:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112327.410428:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112327.424142:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/112327.544589:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/112327.619024:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/112327.714196:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/112327.763570:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/112327.851172:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/112327.873366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7fcd90303bd0 0xd75cfa871d8 , "http://newhouse.cz.house365.com/"
[1:1:0712/112327.887013:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/112327.893113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/112327.893381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "newhouse.cz.house365.com", 3, 1, , , 0
[1:1:0712/112327.895397:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112327.932816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112327.933736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 195da61ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/112327.934072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112328.064539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7fcd90303bd0 0xd75cfa871d8 , "http://newhouse.cz.house365.com/"
[1:1:0712/112328.113593:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7fcd90303bd0 0xd75cfa871d8 , "http://newhouse.cz.house365.com/"
[1:1:0712/112328.145787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112328.146717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 195da61ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/112328.147017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112328.810675:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fcd8ff9b070 0xd75cfbdab60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112328.811733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'cz';
    var uid = '';
    var fav_prjid =
[1:1:0712/112328.811964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "newhouse.cz.house365.com", 3, 1, , , 0
[1:1:0712/112328.814193:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.cz.house365.com", "house365.com"
[1:1:0712/112328.817720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fcd8ff9b070 0xd75cfbdab60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112328.822696:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fcd8ff9b070 0xd75cfbdab60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112328.828960:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fcd8ff9b070 0xd75cfbdab60 , "http://newhouse.cz.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112329.425230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304, "http://newhouse.cz.house365.com/"
[1:1:0712/112329.426900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/112329.427138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112329.552469:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112329.553060:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112329.553561:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112329.554040:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112329.554574:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112330.018916:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112330.387857:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112330.388213:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112330.428270:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 374 0x7fcda6625080 0xd75cfc627e0 1 0 0xd75cfc627f8 , "http://newhouse.cz.house365.com/"
[1:1:0712/112330.456512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/112330.456844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_baabd194 -> 0
		remove user.11_5034f65d -> 0
		remove user.12_328a8470 -> 0
		remove user.13_270458df -> 0
		remove user.14_ea2de785 -> 0
[1:1:0712/112330.561356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112330.605063:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0112488, 144, 1
[1:1:0712/112330.605379:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112330.784639:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112330.784930:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112330.785716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7fcd8ff9b070 0xd75cf9977e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112330.787121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/112330.787406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112330.836698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7fcd8ff9b070 0xd75cf9977e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112331.598324:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415, "http://newhouse.cz.house365.com/"
[1:1:0712/112331.600201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/112331.600452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112332.025628:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112332.217593:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112332.217779:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112332.218936:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 437 0x7fcd8ff9b070 0xd75cfa839e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112332.220638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/112332.220752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112332.513121:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.295408, 52, 1
[1:1:0712/112332.513422:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112332.663634:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112332.663929:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112332.664943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7fcd8ff9b070 0xd75cf9a13e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112332.666165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/112332.666404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112332.810155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7fcda6625080 0xd75cf8d0a60 1 0 0xd75cf8d0a78 , "http://newhouse.cz.house365.com/"
[1:1:0712/112332.828210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/112332.828477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112334.251934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7fcda6625080 0xd75cf8d0a60 1 0 0xd75cf8d0a78 , "http://newhouse.cz.house365.com/"
[1:1:0712/112334.260006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7fcda6625080 0xd75cf8d0a60 1 0 0xd75cf8d0a78 , "http://newhouse.cz.house365.com/"
[1:1:0712/112334.282987:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0367789, 95, 1
[1:1:0712/112334.283289:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112334.822230:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112334.822548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112334.823567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fcd8ff9b070 0xd75d05ec860 , "http://newhouse.cz.house365.com/"
[1:1:0712/112334.825397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/112334.825655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112334.847404:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fcd8ff9b070 0xd75d05ec860 , "http://newhouse.cz.house365.com/"
[1:1:0712/112334.864434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fcd8ff9b070 0xd75d05ec860 , "http://newhouse.cz.house365.com/"
[1:1:0712/112334.911557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fcd8ff9b070 0xd75d05ec860 , "http://newhouse.cz.house365.com/"
[1:1:0712/112336.894330:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112337.232302:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112337.232587:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112337.239685:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fcd8ff9b070 0xd75d05ecde0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112337.241908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/112337.242178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112337.249779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fcd8ff9b070 0xd75d05ecde0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112337.262982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fcd8ff9b070 0xd75d05ecde0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112337.477142:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112337.527648:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fcd8ff9b070 0xd75d05ecde0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112337.577731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 523 0x7fcd8ff9b070 0xd75d05ecde0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112337.639535:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.406872, 232, 1
[1:1:0712/112337.639865:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112338.010087:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112338.010424:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112338.011401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7fcd8ff9b070 0xd75d05ec6e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112338.013549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/112338.013821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112338.017436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7fcd8ff9b070 0xd75d05ec6e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112338.121539:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.111042, 471, 1
[1:1:0712/112338.121858:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112338.384528:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112338.384834:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112338.385774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552 0x7fcd8ff9b070 0xd75d0c9af60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112338.387006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode246895_1").qrcode({
                                rend
[1:1:0712/112338.387349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.12_d1c857e4 -> 0
[130695:130695:0712/112350.985734:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/112351.019950:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/112357.971155:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.5862, 0, 0
[1:1:0712/112357.971434:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112358.083781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/112358.083954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112358.454569:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112358.454797:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112358.468498:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0135939, 93, 1
[1:1:0712/112358.468721:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112358.705065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112358.705345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112400.604131:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112400.604404:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112400.605341:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 609 0x7fcd8ff9b070 0xd75d05597e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112400.606421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1643_1").qrcode({
                                render
[1:1:0712/112400.606667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112404.269568:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.66497, 0, 0
[1:1:0712/112404.269759:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112404.312536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112404.313445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112404.313607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112404.324205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112404.324383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112405.612634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112405.613158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112405.613301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112405.634845:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112405.635023:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112405.640418:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00539207, 89, 1
[1:1:0712/112405.640597:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112405.676567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112405.676754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112406.064982:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112406.065246:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112406.066552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 663 0x7fcd8ff9b070 0xd75d27eb8e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112406.067703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1389_1").qrcode({
                                render
[1:1:0712/112406.067919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112406.345051:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.279422, 105, 1
[1:1:0712/112406.345315:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112406.377484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112406.377694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112406.611800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112406.612565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112406.612748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112406.705160:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112406.705392:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112406.706402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 678 0x7fcd8ff9b070 0xd75d174bae0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112406.707558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1667_1").qrcode({
                                render
[1:1:0712/112406.707770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112407.047558:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.342127, 89, 1
[1:1:0712/112407.047858:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112407.152084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112407.152453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112407.525037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112407.525832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112407.526056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112407.581435:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112407.581721:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112407.582774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7fcd8ff9b070 0xd75d1798860 , "http://newhouse.cz.house365.com/"
[1:1:0712/112407.583988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode52403_1").qrcode({
                                rende
[1:1:0712/112407.584267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112407.690804:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112407.691409:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112407.694581:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112407.695245:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112407.695770:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112407.863494:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.281653, 93, 1
[1:1:0712/112407.863768:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112407.990039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112407.990358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112408.479880:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112408.480698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112408.480923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112408.529422:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112408.529714:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112408.530798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 715 0x7fcd8ff9b070 0xd75d8345fe0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112408.532259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode49163_1").qrcode({
                                rende
[1:1:0712/112408.532553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112408.952296:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.422509, 81, 1
[1:1:0712/112408.952597:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112408.967006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112408.967376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112409.420749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112409.421625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112409.421910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112409.481760:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112409.482066:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112409.483197:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7fcd8ff9b070 0xd75d84736e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112409.484268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode248299_1").qrcode({
                                rend
[1:1:0712/112409.484501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112409.883007:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.400855, 89, 1
[1:1:0712/112409.883323:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112409.978162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112409.978462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112410.430182:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112410.431005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112410.431260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112410.527163:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112410.527450:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112410.528504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 757 0x7fcd8ff9b070 0xd75cfbdde60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112410.529633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1622_1").qrcode({
                                render
[1:1:0712/112410.529884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112410.816546:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.28899, 101, 1
[1:1:0712/112410.816831:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112410.855995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112410.856324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112411.188821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112411.189634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112411.189884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112411.255104:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112411.255419:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112411.256492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7fcd8ff9b070 0xd75d9ba13e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112411.257601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode244525_1").qrcode({
                                rend
[1:1:0712/112411.257830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.13_1e8fee7c -> 0
		remove user.14_70ba7a12 -> 0
		remove user.15_fb5ae2ad -> 0
		remove user.16_87d8b0cd -> 0
		remove user.17_92d68aa0 -> 0
[1:1:0712/112411.581303:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.325779, 89, 1
[1:1:0712/112411.581619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112411.655919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112411.656223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112412.082112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112412.082926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112412.083176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112412.152268:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112412.152535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112412.153616:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 793 0x7fcd8ff9b070 0xd75da00e3e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112412.154838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode50757_1").qrcode({
                                rende
[1:1:0712/112412.155126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112412.652976:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.500363, 93, 1
[1:1:0712/112412.653290:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112412.722291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112412.722581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[130695:130695:0712/112413.087686:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112413.220251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112413.221115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112413.221399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112413.340736:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112413.341028:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112413.342066:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7fcd8ff9b070 0xd75d1701ee0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112413.343263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1757_1").qrcode({
                                render
[1:1:0712/112413.343637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112413.564655:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.223542, 101, 1
[1:1:0712/112413.564951:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112413.618132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112413.618417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112413.969174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112413.969954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112413.970186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112414.115685:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112414.116014:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112414.117199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 829 0x7fcd8ff9b070 0xd75da1e52e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112414.118366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode52765_1").qrcode({
                                rende
[1:1:0712/112414.118599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112414.271535:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.155272, 105, 1
[1:1:0712/112414.271822:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112414.313045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112414.313419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112414.693789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112414.694570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112414.694805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112414.836326:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112414.836643:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112414.837665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 845 0x7fcd8ff9b070 0xd75da7e52e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112414.838777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode1593_1").qrcode({
                                render
[1:1:0712/112414.839057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112415.057604:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.220882, 93, 1
[1:1:0712/112415.057903:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112415.082839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112415.083220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112415.553574:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112415.554402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112415.554631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112415.635455:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112415.635758:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112415.637094:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 863 0x7fcd8ff9b070 0xd75da7e6d60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112415.638504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode52159_1").qrcode({
                                rende
[1:1:0712/112415.638881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112415.782431:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.146456, 109, 1
[1:1:0712/112415.782715:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112415.849280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112415.849584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112416.279683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112416.280511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112416.280844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112416.362922:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112416.363244:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112416.364320:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 880 0x7fcd8ff9b070 0xd75da64ad60 , "http://newhouse.cz.house365.com/"
[1:1:0712/112416.365442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
                            $("#lptelqrcode54571_1").qrcode({
                                rende
[1:1:0712/112416.365708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112416.506249:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.142935, 54, 1
[1:1:0712/112416.506577:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112416.607064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112416.607383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112417.040154:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.cz.house365.com/"
[1:1:0712/112417.040923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112417.041153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112417.091076:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112417.091365:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112417.092421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 896 0x7fcd8ff9b070 0xd75daa96460 , "http://newhouse.cz.house365.com/"
[1:1:0712/112417.093476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
listCondition.p=1;
var totalpage=30;

[1:1:0712/112417.093769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112417.189796:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0983551, 603, 1
[1:1:0712/112417.190111:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112417.231502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112417.231816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112418.787238:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112418.787526:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112418.788560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112418.789973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
    $(function(){
        $(".hotslide").on("click",function(){
            if($(this).children("im
[1:1:0712/112418.790256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112418.794811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112418.801082:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112418.813693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.051229:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.054794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.063338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.076342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.237647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.244597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.274050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.282476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 921 0x7fcd8ff9b070 0xd75cfddade0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112419.318079:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.530352, 0, 0
[1:1:0712/112419.318337:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112419.364510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112419.364920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112421.649234:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112421.649525:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.cz.house365.com/"
[1:1:0712/112421.650900:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.651954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , 
    //消息定位的扩展字段
    //from tf_ios淘房iOS ，tf_android 淘房安卓，pc网页P
[1:1:0712/112421.652187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112421.660317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.670710:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.677219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.703008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.704762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7fcd8ff9b070 0xd75db14a7e0 , "http://newhouse.cz.house365.com/"
[1:1:0712/112421.826562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112421.826881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112423.398087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033, "http://newhouse.cz.house365.com/"
[1:1:0712/112423.400097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.writeln("<style>");
document.writeln("@keyframes jumping{");
document.writeln("	0%{");
d
[1:1:0712/112423.400432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112423.441928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033, "http://newhouse.cz.house365.com/"
[130695:130695:0712/112423.454752:INFO:CONSOLE(2454)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?b3c3ef7da5e042f2f2fb407d340913f3, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.cz.house365.com/ (2454)
[130695:130695:0712/112423.464900:INFO:CONSOLE(2454)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?b3c3ef7da5e042f2f2fb407d340913f3, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.cz.house365.com/ (2454)
[1:1:0712/112423.482570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112423.482759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112425.487567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , document.readyState
[1:1:0712/112425.487865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112426.915129:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1109 0x7fcd90303bd0 0xd75db1b4b58 , "http://newhouse.cz.house365.com/"
[1:1:0712/112426.925521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.cz.house365.com/, 25fa214e2860, , , (function(){var h={},mt={},c={id:"b3c3ef7da5e042f2f2fb407d340913f3",dm:["cz.house365.com"],js:"tongj
[1:1:0712/112426.925809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.cz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112426.962023:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1f18f5ce29c8, 0xd75cf4bc960
[1:1:0712/112426.962319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.cz.house365.com/", 100
[1:1:0712/112426.962725:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.cz.house365.com/, 1123
[1:1:0712/112426.962955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1123 0x7fcd8ff9b070 0xd75d87e8ae0 , 5:3_http://newhouse.cz.house365.com/, 1, -5:3_http://newhouse.cz.house365.com/, 1109 0x7fcd90303bd0 0xd75db1b4b58 
