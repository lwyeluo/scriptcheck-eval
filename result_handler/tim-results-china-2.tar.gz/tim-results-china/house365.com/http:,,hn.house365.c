[0712/111118.258172:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111118.258487:INFO:switcher_clone.cc(787)] backtrace rip is 7f6d43268891
[0712/111119.313644:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111119.314045:INFO:switcher_clone.cc(787)] backtrace rip is 7f03b2b4c891
[1:1:0712/111119.325873:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111119.326161:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111119.330930:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[129379:129379:0712/111120.652684:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/50a3f7a3-e717-4fba-b9c8-580fa9f109f8
[0712/111120.843714:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111120.844229:INFO:switcher_clone.cc(787)] backtrace rip is 7f94b93c6891
[129379:129379:0712/111121.018281:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129379:129411:0712/111121.019083:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111121.019339:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111121.019650:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111121.020172:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111121.020314:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111121.023060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6dc4e8c, 1
[1:1:0712/111121.023276:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22d579d7, 0
[1:1:0712/111121.023377:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x301f26c9, 3
[1:1:0712/111121.023489:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x960033c, 2
[1:1:0712/111121.023651:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd779ffffffd522 ffffff8c4effffffdc06 3c036009 ffffffc9261f30 , 10104, 4
[1:1:0712/111121.024269:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129379:129411:0712/111121.024432:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�y�"�N�<`	�&0�]�
[1:1:0712/111121.024414:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0d870a0, 3
[129379:129411:0712/111121.024508:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �y�"�N�<`	�&0���]�
[1:1:0712/111121.024565:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0f12080, 2
[129379:129411:0712/111121.024772:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111121.024796:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f039abd5d20, -2
[129379:129411:0712/111121.024830:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129426, 4, d779d522 8c4edc06 3c036009 c9261f30 
[1:1:0712/111121.033301:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111121.033910:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 960033c
[1:1:0712/111121.034587:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 960033c
[1:1:0712/111121.035645:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 960033c
[1:1:0712/111121.036178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.036291:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.036384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.036477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.036729:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 960033c
[1:1:0712/111121.036875:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03b2b4c7ba
[1:1:0712/111121.036953:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03b2b43def, 7f03b2b4c77a, 7f03b2b4e0cf
[1:1:0712/111121.038385:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 960033c
[1:1:0712/111121.038563:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 960033c
[1:1:0712/111121.038841:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 960033c
[1:1:0712/111121.039507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.039648:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.039752:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.039845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 960033c
[1:1:0712/111121.040279:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 960033c
[1:1:0712/111121.040440:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03b2b4c7ba
[1:1:0712/111121.040514:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03b2b43def, 7f03b2b4c77a, 7f03b2b4e0cf
[1:1:0712/111121.042685:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111121.042929:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111121.043021:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc05447dd8, 0x7ffc05447d58)
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/111121.057623:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111121.063952:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129413:129413:0712/111121.133638:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129413
[129440:129440:0712/111121.134052:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129440
[129379:129403:0712/111121.669023:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111121.706156:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3d4d6027a220
[1:1:0712/111121.706845:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[129379:129379:0712/111121.722583:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129379:129379:0712/111121.723653:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129379:129392:0712/111121.747156:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129379:129392:0712/111121.747312:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129379:129379:0712/111121.747480:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129379:129379:0712/111121.747574:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129379:129379:0712/111121.747856:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129426, 4
[1:7:0712/111121.750170:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111122.164758:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[129379:129379:0712/111123.547311:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129379:129379:0712/111123.547433:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111123.563201:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111123.566689:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111124.230514:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111124.324845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111124.325149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111124.357639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111124.357960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111124.554079:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111124.554466:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111124.936539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111124.944852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111124.945110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111124.981964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111124.986017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111124.986281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111124.998654:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111125.002314:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3d4d60278e20
[1:1:0712/111125.002577:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129379:129379:0712/111125.003199:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[129379:129379:0712/111125.016347:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129379:129379:0712/111125.058255:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129379:129379:0712/111125.058471:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111125.080476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111125.674570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f039c7b02e0 0x3d4d6045cf60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111125.676114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111125.676380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111125.677926:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129379:129379:0712/111125.759639:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111125.762001:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3d4d60279820
[1:1:0712/111125.762314:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129379:129379:0712/111125.767815:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111125.782036:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111125.782318:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129379:129379:0712/111125.784540:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129379:129379:0712/111125.792378:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129379:129379:0712/111125.793423:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129379:129392:0712/111125.798712:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129379:129392:0712/111125.798828:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[129379:129379:0712/111125.799019:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129379:129379:0712/111125.799117:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129379:129379:0712/111125.799294:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129426, 4
[1:7:0712/111125.809843:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111126.448391:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111126.955156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f039c7b02e0 0x3d4d60467de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111126.956258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111126.956598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111126.957432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129379:129379:0712/111127.137970:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129379:129379:0712/111127.138115:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111127.167588:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111127.470146:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111127.759132:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111127.759292:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111127.949467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111127.951092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19721672e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111127.951263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111127.953475:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129379:129379:0712/111127.990506:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129379:129411:0712/111127.990945:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111127.991126:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111127.991362:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111127.991746:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111127.991888:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111127.994988:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2f503adc, 1
[1:1:0712/111127.995373:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1990a899, 0
[1:1:0712/111127.995535:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2ce889a, 3
[1:1:0712/111127.995678:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19bb756a, 2
[1:1:0712/111127.995822:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff99ffffffa8ffffff9019 ffffffdc3a502f 6a75ffffffbb19 ffffff9affffff88ffffffce02 , 10104, 5
[1:1:0712/111127.996834:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129379:129411:0712/111127.997096:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����:P/ju�����`�
[129379:129411:0712/111127.997165:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����:P/ju�������`�
[1:1:0712/111127.997083:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0d870a0, 3
[1:1:0712/111127.997304:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f03b0f12080, 2
[129379:129411:0712/111127.997438:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129476, 5, 99a89019 dc3a502f 6a75bb19 9a88ce02 
[1:1:0712/111127.997489:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f039abd5d20, -2
[1:1:0712/111128.018839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111128.019653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 197216601f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111128.019910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111128.022419:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111128.022752:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19bb756a
[1:1:0712/111128.023160:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19bb756a
[1:1:0712/111128.023944:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19bb756a
[1:1:0712/111128.025701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.025961:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.026218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.026446:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.027261:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19bb756a
[1:1:0712/111128.027610:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03b2b4c7ba
[1:1:0712/111128.027777:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03b2b43def, 7f03b2b4c77a, 7f03b2b4e0cf
[1:1:0712/111128.034727:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19bb756a
[1:1:0712/111128.035287:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19bb756a
[1:1:0712/111128.036231:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19bb756a
[1:1:0712/111128.038740:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.039001:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.039257:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.039491:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19bb756a
[1:1:0712/111128.041066:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19bb756a
[1:1:0712/111128.041535:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f03b2b4c7ba
[1:1:0712/111128.041704:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f03b2b43def, 7f03b2b4c77a, 7f03b2b4e0cf
[1:1:0712/111128.051093:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111128.051704:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111128.051887:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc05447dd8, 0x7ffc05447d58)
[1:1:0712/111128.068365:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111128.073489:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111128.221572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111128.224909:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111128.225303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19721672e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111128.225756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111128.326125:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3d4d60257220
[1:1:0712/111128.326407:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111128.385226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111128.386381:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111128.386647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19721672e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111128.386968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[129379:129379:0712/111128.668170:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129379:129379:0712/111128.673578:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129379:129392:0712/111128.715737:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129379:129392:0712/111128.715837:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129379:129379:0712/111128.716253:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://hn.house365.com/
[129379:129379:0712/111128.716337:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hn.house365.com/, http://hn.house365.com/, 1
[129379:129379:0712/111128.716495:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://hn.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:11:28 GMT Content-Type: text/html; charset=gb2312 Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 18:02:13 GMT Vary: Accept-Encoding ETag: W/"5d28cb25-1caf5" Content-Encoding: gzip  ,129476, 5
[1:7:0712/111128.720061:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111128.738394:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://hn.house365.com/
[129379:129379:0712/111128.884207:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://hn.house365.com/, http://hn.house365.com/, 1
[129379:129379:0712/111128.884353:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://hn.house365.com/, http://hn.house365.com
[1:1:0712/111128.937365:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111129.060742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111129.128395:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111129.166106:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/111129.213700:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111129.213992:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111129.241122:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/111129.295621:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/111129.415659:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/111129.448266:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/111129.500755:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/111129.630105:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/111129.700179:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/111129.764307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111129.765292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 19721672e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111129.765577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111130.597469:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111130.597983:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111130.600030:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111130.601271:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111130.601680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111131.556327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.558909:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111131.569453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/111131.569764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
		remove user.10_65d29e0 -> 0
		remove user.11_43b19b2b -> 0
		remove user.12_3bfb69a6 -> 0
		remove user.13_c8a3282e -> 0
		remove user.14_635193b9 -> 0
[1:1:0712/111131.847145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.853665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.863615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.874589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.882765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.892788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.900527:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.921686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.935449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.957809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111131.978472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111132.032532:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111132.042241:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111132.062438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111132.075137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 247 0x7f039a888070 0x3d4d604915e0 , "http://hn.house365.com/"
[1:1:0712/111133.106281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f03b0f12080 0x3d4d6038f7e0 1 0 0x3d4d6038f7f8 , "http://hn.house365.com/"
[1:1:0712/111133.177975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111133.178304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
[1:1:0712/111135.239200:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111135.632769:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111135.633102:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111135.634045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7f039a888070 0x3d4d6048f460 , "http://hn.house365.com/"
[1:1:0712/111135.635705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 	$(function(){		var jqueryInputDom2 = '#keywords';		var searchUrl = 'http://transferapi.house365.com
[1:1:0712/111135.635962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
[1:1:0712/111135.644901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7f039a888070 0x3d4d6048f460 , "http://hn.house365.com/"
[1:1:0712/111135.683524:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355 0x7f039a888070 0x3d4d6048f460 , "http://hn.house365.com/"
[1:1:0712/111135.868601:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111137.338185:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111137.630048:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111137.630311:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111137.632075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f039a888070 0x3d4d609cbb60 , "http://hn.house365.com/"
[1:1:0712/111137.633811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111137.634047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
[1:1:0712/111137.642356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f039a888070 0x3d4d609cbb60 , "http://hn.house365.com/"
[1:1:0712/111137.713636:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f03b0f12080 0x3d4d6077f9c0 1 0 0x3d4d6077f9d8 , "http://hn.house365.com/"
[1:1:0712/111137.858939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111137.859259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
		remove user.10_72bc0739 -> 0
[1:1:0712/111138.034217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f03b0f12080 0x3d4d6077f9c0 1 0 0x3d4d6077f9d8 , "http://hn.house365.com/"
[1:1:0712/111138.056426:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.022723, 115, 1
[1:1:0712/111138.056680:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111138.306101:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111138.306366:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111138.307216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f039a888070 0x3d4d60c5f260 , "http://hn.house365.com/"
[1:1:0712/111138.308332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
function normal9315(){
    document.write('<div style="display:block;position: relative;width:1200p
[1:1:0712/111138.308575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "hn.house365.com", 3, 1, , , 0
[1:1:0712/111138.329479:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111138.332848:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3d4d60916820
[1:1:0712/111138.333081:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111138.380826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f039a888070 0x3d4d60c5f260 , "http://hn.house365.com/"
[1:1:0712/111138.383850:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "hn.house365.com", "house365.com"
[1:1:0712/111138.486440:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.180001, 365, 1
[1:1:0712/111138.486729:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111139.040619:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111139.040903:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111139.045067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7f039a888070 0x3d4d60c5f660 , "http://hn.house365.com/"
[1:1:0712/111139.047550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
function QR8bitByte(a){
    this.mode=QRMode.MODE_8BIT_BYTE,
        this.data=a
}

function 
[1:1:0712/111139.047781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111139.058328:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7f039a888070 0x3d4d60c5f660 , "http://hn.house365.com/"
[129379:129379:0712/111155.001784:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[129379:129379:0712/111155.009277:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[129379:129379:0712/111155.034398:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://hn.house365.com/, http://hn.house365.com/, 4
[129379:129379:0712/111155.034534:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://hn.house365.com/, http://hn.house365.com
[129379:129379:0712/111155.087549:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/111155.136929:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[129379:129379:0712/111155.339962:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/111156.857236:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 17.8162, 0, 0
[1:1:0712/111156.857463:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111157.071574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111157.071821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111157.873378:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111157.873658:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111157.906777:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0330238, 203, 1
[1:1:0712/111157.907059:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111158.121945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111158.122233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111200.094016:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111200.094296:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111200.095184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 529 0x7f039a888070 0x3d4d60322c60 , "http://hn.house365.com/"
[1:1:0712/111200.096047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
			
[1:1:0712/111200.096291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111200.150346:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0559671, 414, 1
[1:1:0712/111200.150628:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111200.210559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://hn.house365.com/"
[1:1:0712/111200.212534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111200.212776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111200.279880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111200.280187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111202.611775:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111202.612062:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111202.631374:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0192502, 127, 1
[1:1:0712/111202.631704:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111202.752452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111202.752753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111203.431269:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111203.431805:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111203.432175:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111203.432497:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111203.432884:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111204.205178:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111204.205472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111204.206494:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 644 0x7f039a888070 0x3d4d606fb9e0 , "http://hn.house365.com/"
[1:1:0712/111204.207699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
						$(function(){
							$("#xfzx_right_lp .newhouseSItem").click(function(){
								$(this).add
[1:1:0712/111204.208027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111204.302263:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.096684, 612, 1
[1:1:0712/111204.302573:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111204.451241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111204.451575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111204.595120:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111205.992531:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111205.992802:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111206.008792:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.015928, 212, 1
[1:1:0712/111206.009097:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111206.271224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111206.271605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111206.345852:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111206.346141:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/111206.353080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 703 0x7f039a888070 0x3d4d65486de0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111206.354199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 1f2ba9246f00, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/111206.354451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/111206.379322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 703 0x7f039a888070 0x3d4d65486de0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111206.385224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 703 0x7f039a888070 0x3d4d65486de0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111206.387923:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 703 0x7f039a888070 0x3d4d65486de0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111207.228016:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111207.228423:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111207.231093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 725 0x7f039a888070 0x3d4d67cb6c60 , "http://hn.house365.com/"
[1:1:0712/111207.232085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
			var flag_esf_tag = true;
					
[1:1:0712/111207.232380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111207.245302:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0162921, 209, 1
[1:1:0712/111207.245626:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111207.335756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111207.336077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111207.533003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/111207.535047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 1f2ba9246f00, , onload, notifyDidFinishLoading();
[1:1:0712/111207.535352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111208.593959:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111208.594231:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111208.595184:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 783 0x7f039a888070 0x3d4d681c2760 , "http://hn.house365.com/"
[1:1:0712/111208.596086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
		var flag_zf_tag = true;
			
[1:1:0712/111208.596343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111208.607845:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0135491, 67, 1
[1:1:0712/111208.608126:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111208.836905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111208.837210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111209.602504:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111209.602778:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://hn.house365.com/"
[1:1:0712/111209.606304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 810 0x7f039a888070 0x3d4d67ccabe0 , "http://hn.house365.com/"
[1:1:0712/111209.607559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.write("<div class=\"w10000\">	<div class=\"pt45 pb45 bg484848\">		<div class=\"margin_auto_
[1:1:0712/111209.607837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111209.634855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 810 0x7f039a888070 0x3d4d67ccabe0 , "http://hn.house365.com/"
[1:1:0712/111209.663717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 810 0x7f039a888070 0x3d4d67ccabe0 , "http://hn.house365.com/"
[1:1:0712/111209.849427:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129379:129379:0712/111209.855609:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111209.857919:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3d4d68223820
[1:1:0712/111209.858212:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[129379:129379:0712/111209.862300:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[129379:129379:0712/111209.902920:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://hn.house365.com/, http://hn.house365.com/, 5
[129379:129379:0712/111209.903337:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://hn.house365.com/, http://hn.house365.com
[1:1:0712/111210.106557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111210.106898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111211.815583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111211.815875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111213.177043:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111213.180044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , $(".first-screen-switch").slide({titCell:".hd ul",mainCell:".bd",autoPage:true,autoPlay:true});
$(".
[1:1:0712/111213.180277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111213.720326:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111213.746878:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x156b69c029c8, 0x3d4d5fdca1b8
[1:1:0712/111213.747175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 0
[1:1:0712/111213.747562:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 954
[1:1:0712/111213.747843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7f039a888070 0x3d4d606e85e0 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 913 0x7f039a888070 0x3d4d60c444e0 
[1:1:0712/111213.783228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 2500
[1:1:0712/111213.783686:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 955
[1:1:0712/111213.783958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 955 0x7f039a888070 0x3d4d60bb1660 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 913 0x7f039a888070 0x3d4d60c444e0 
[1:1:0712/111214.805477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.824185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.836748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.849387:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.860484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.865622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.872317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111214.909535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 913 0x7f039a888070 0x3d4d60c444e0 , "http://hn.house365.com/"
[1:1:0712/111215.138188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111215.138510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[129379:129379:0712/111217.026563:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111217.323992:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985, "http://hn.house365.com/"
[1:1:0712/111217.328488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (function(){
	var parameters = {
			'guid'  : 'new_guid',
			'todayfirst' : 'new_todayfirst',
		
[1:1:0712/111217.328758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111217.417032:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 954, 7f039d1cd881
[1:1:0712/111217.442874:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"913 0x7f039a888070 0x3d4d60c444e0 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111217.443083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"913 0x7f039a888070 0x3d4d60c444e0 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111217.443336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111217.443639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){$b=void 0}
[1:1:0712/111217.443751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111217.843832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111217.844126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111219.097797:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 955, 7f039d1cd8db
[1:1:0712/111219.112688:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"913 0x7f039a888070 0x3d4d60c444e0 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111219.112901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"913 0x7f039a888070 0x3d4d60c444e0 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111219.113146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1083
[1:1:0712/111219.113286:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7f039a888070 0x3d4d68762460 , 5:3_http://hn.house365.com/, 0, , 955 0x7f039a888070 0x3d4d60bb1660 
[1:1:0712/111219.113495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111219.113772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){w?p--:p++,ab()}
[1:1:0712/111219.113880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111219.155777:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x156b69c029c8, 0x3d4d5fdca150
[1:1:0712/111219.155963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 0
[1:1:0712/111219.156151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1084
[1:1:0712/111219.156291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f039a888070 0x3d4d6871f260 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 955 0x7f039a888070 0x3d4d60bb1660 
[1:1:0712/111219.176147:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 13
[1:1:0712/111219.176448:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1086
[1:1:0712/111219.176567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f039a888070 0x3d4d60bb0660 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 955 0x7f039a888070 0x3d4d60bb1660 
[1:1:0712/111220.381785:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1052, "http://hn.house365.com/"
[1:1:0712/111220.382295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
[1:1:0712/111220.382412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111220.383411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1052, "http://hn.house365.com/"
[1:1:0712/111220.384670:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1052, "http://hn.house365.com/"
[1:1:0712/111220.386619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1052, "http://hn.house365.com/"
[1:1:0712/111220.778392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111220.778583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111221.218050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1084, 7f039d1cd881
[1:1:0712/111221.267383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111221.267843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111221.268309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111221.269003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){$b=void 0}
[1:1:0712/111221.269242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111221.271720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1086, 7f039d1cd8db
[1:1:0712/111221.314618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111221.314901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111221.315244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1164
[1:1:0712/111221.315419:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1164 0x7f039a888070 0x3d4d67259a60 , 5:3_http://hn.house365.com/, 0, , 1086 0x7f039a888070 0x3d4d60bb0660 
[1:1:0712/111221.315718:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111221.316189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111221.316351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111223.757761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143, "http://hn.house365.com/"
[1:1:0712/111223.758589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , 
[1:1:0712/111223.758772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111223.761518:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143, "http://hn.house365.com/"
[1:1:0712/111223.772971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143, "http://hn.house365.com/"
[1:1:0712/111223.782084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143, "http://hn.house365.com/"
[1:1:0712/111223.783813:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1143, "http://hn.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111224.041526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111224.041775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111224.368678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1083, 7f039d1cd8db
[1:1:0712/111224.422665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111224.422953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"955 0x7f039a888070 0x3d4d60bb1660 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111224.423346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1248
[1:1:0712/111224.423570:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1248 0x7f039a888070 0x3d4d68faa460 , 5:3_http://hn.house365.com/, 0, , 1083 0x7f039a888070 0x3d4d68762460 
[1:1:0712/111224.423918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111224.424394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){w?p--:p++,ab()}
[1:1:0712/111224.424591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111224.487808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x156b69c029c8, 0x3d4d5fdca150
[1:1:0712/111224.487991:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 0
[1:1:0712/111224.488186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1249
[1:1:0712/111224.488296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7f039a888070 0x3d4d685c3b60 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1083 0x7f039a888070 0x3d4d68762460 
[1:1:0712/111224.503002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 13
[1:1:0712/111224.503239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1251
[1:1:0712/111224.503348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f039a888070 0x3d4d68f99ee0 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1083 0x7f039a888070 0x3d4d68762460 
[1:1:0712/111224.652509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1210 0x7f039c7b02e0 0x3d4d68faa660 , "http://hn.house365.com/"
[1:1:0712/111224.662459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , var conf_ga_public_code = "UA-35147609-1";

var conf_ga_city = new Array();
conf_ga_city["nj"] = "�
[1:1:0712/111224.662772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111224.689289:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x156b69c029c8, 0x3d4d5fdca1a0
[1:1:0712/111224.689472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 5000
[1:1:0712/111224.689697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1256
[1:1:0712/111224.689823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1256 0x7f039a888070 0x3d4d68fc1260 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1210 0x7f039c7b02e0 0x3d4d68faa660 
[1:1:0712/111225.230776:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1227, "http://hn.house365.com/"
[1:1:0712/111225.231443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.domain="house365.com";
document.write('<link rel="stylesheet" href="http://pic.house365.co
[1:1:0712/111225.231564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111225.231877:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "house365.com", "house365.com"
[1:1:0712/111225.431810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111225.432115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111225.866501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1249, 7f039d1cd881
[1:1:0712/111225.923522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111225.923970:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111225.924417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111225.925039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){$b=void 0}
[1:1:0712/111225.925262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111225.994222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1251, 7f039d1cd8db
[1:1:0712/111226.029019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1f2ba9182860","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111226.029229:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://hn.house365.com/","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111226.029458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1300
[1:1:0712/111226.029583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7f039a888070 0x3d4d690a9960 , 5:3_http://hn.house365.com/, 0, , 1251 0x7f039a888070 0x3d4d68f99ee0 
[1:1:0712/111226.029784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111226.030322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111226.030549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111226.599378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1279 0x7f039c7b02e0 0x3d4d687622e0 , "http://hn.house365.com/"
[1:1:0712/111226.623052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (function(){var h={},mt={},c={id:"a4916f4a10b456a6ea91f21d108685db",dm:["hn.house365.com"],js:"tongj
[1:1:0712/111226.623306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111226.647933:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x156b69c029c8, 0x3d4d5fdca190
[1:1:0712/111226.648153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 100
[1:1:0712/111226.648338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1323
[1:1:0712/111226.648451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1323 0x7f039a888070 0x3d4d68fcbae0 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1279 0x7f039c7b02e0 0x3d4d687622e0 
[1:1:0712/111227.633381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , document.readyState
[1:1:0712/111227.633704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111227.885973:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1248, 7f039d1cd8db
[1:1:0712/111227.919033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111227.919387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1083 0x7f039a888070 0x3d4d68762460 ","rf":"5:3_http://hn.house365.com/"}
[1:1:0712/111227.919841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1371
[1:1:0712/111227.920075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1371 0x7f039a888070 0x3d4d690caf60 , 5:3_http://hn.house365.com/, 0, , 1248 0x7f039a888070 0x3d4d68faa460 
[1:1:0712/111227.920496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://hn.house365.com/"
[1:1:0712/111227.921016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , (){w?p--:p++,ab()}
[1:1:0712/111227.921261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111227.990328:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x156b69c029c8, 0x3d4d5fdca150
[1:1:0712/111227.990636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 0
[1:1:0712/111227.991029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1372
[1:1:0712/111227.991263:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1372 0x7f039a888070 0x3d4d68f204e0 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1248 0x7f039a888070 0x3d4d68faa460 
[1:1:0712/111228.025070:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 13
[1:1:0712/111228.025577:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1373
[1:1:0712/111228.025822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1373 0x7f039a888070 0x3d4d68679b60 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1248 0x7f039a888070 0x3d4d68faa460 
[1:1:0712/111228.199363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1313 0x7f039a888070 0x3d4d68fd1960 , "http://hn.house365.com/"
[1:1:0712/111228.209325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://hn.house365.com/, 1f2ba9182860, , , /**
 * jQuery Roundabout - v2.1.1
 * http://fredhq.com/projects/roundabout
 *
 * Moves list-item
[1:1:0712/111228.209640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://hn.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111228.223335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1313 0x7f039a888070 0x3d4d68fd1960 , "http://hn.house365.com/"
[1:1:0712/111228.233322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1313 0x7f039a888070 0x3d4d68fd1960 , "http://hn.house365.com/"
[1:1:0712/111228.266721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://hn.house365.com/"
[1:1:0712/111228.329068:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129379:129379:0712/111228.331689:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111228.333455:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x3d4d67ae5420
[1:1:0712/111228.333691:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[129379:129379:0712/111228.340145:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[129379:129379:0712/111228.384026:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://hn.house365.com/, http://hn.house365.com/, 6
[129379:129379:0712/111228.384213:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://hn.house365.com/, http://hn.house365.com
[1:1:0712/111231.112215:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129379:129379:0712/111231.115486:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111231.118020:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x3d4d67acea20
[1:1:0712/111231.118298:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[129379:129379:0712/111231.123161:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0712/111231.142875:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111231.143118:INFO:render_frame_impl.cc(7019)] 	 [url] = http://hn.house365.com
[129379:129379:0712/111231.144634:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://hn.house365.com/
		remove user.11_68a1d9cd -> 0
[129379:129379:0712/111231.290739:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129379:129379:0712/111231.291892:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129379:129379:0712/111231.330535:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://fbs.hn.house365.com/
[129379:129379:0712/111231.330627:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://fbs.hn.house365.com/, http://fbs.hn.house365.com/?action=fbspopup, 7
[129379:129379:0712/111231.330760:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_http://fbs.hn.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:12:31 GMT Content-Type: text/html; charset=gbk Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Content-Encoding: gzip  ,129476, 5
[129379:129392:0712/111231.331237:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[129379:129392:0712/111231.331316:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111231.332262:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111231.522085:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111231.522615:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111231.578553:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 3000
[1:1:0712/111231.579043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://hn.house365.com/, 1424
[1:1:0712/111231.579320:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1424 0x7f039a888070 0x3d4d69d8e260 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1313 0x7f039a888070 0x3d4d68fd1960 
[1:1:0712/111231.626598:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x156b69c029c8, 0x3d4d5fdca210
[1:1:0712/111231.626875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://hn.house365.com/", 0
[1:1:0712/111231.627278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://hn.house365.com/, 1425
[1:1:0712/111231.627517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f039a888070 0x3d4d6873b6e0 , 5:3_http://hn.house365.com/, 1, -5:3_http://hn.house365.com/, 1313 0x7f039a888070 0x3d4d68fd1960 
