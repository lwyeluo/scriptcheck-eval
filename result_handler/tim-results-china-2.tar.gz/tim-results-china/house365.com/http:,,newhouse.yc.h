[0712/111003.211579:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111003.211893:INFO:switcher_clone.cc(787)] backtrace rip is 7f3e571d8891
[0712/111004.036797:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111004.037157:INFO:switcher_clone.cc(787)] backtrace rip is 7f4ff93a5891
[1:1:0712/111004.041440:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111004.041632:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111004.046596:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[129246:129246:0712/111005.402080:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ade257b9-5927-48b7-b7c6-e6358f12b31c
[0712/111005.475394:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111005.475677:INFO:switcher_clone.cc(787)] backtrace rip is 7f180bb79891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129279:129279:0712/111005.711265:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129279
[129291:129291:0712/111005.711674:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129291
[129246:129246:0712/111005.988635:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129246:129277:0712/111005.989416:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111005.989693:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111005.989985:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111005.990716:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111005.990954:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111005.994425:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xe1cef93, 1
[1:1:0712/111005.994830:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2687f581, 0
[1:1:0712/111005.995062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3dbd41fc, 3
[1:1:0712/111005.995260:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x279a0dd9, 2
[1:1:0712/111005.995623:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff81fffffff5ffffff8726 ffffff93ffffffef1c0e ffffffd90dffffff9a27 fffffffc41ffffffbd3d , 10104, 4
[1:1:0712/111005.996801:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129246:129277:0712/111005.997091:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���&����'�A�=��}
[129246:129277:0712/111005.997156:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���&����'�A�=����}
[1:1:0712/111005.997091:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff75e00a0, 3
[129246:129277:0712/111005.997422:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111005.997347:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff776b080, 2
[129246:129277:0712/111005.997492:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129299, 4, 81f58726 93ef1c0e d90d9a27 fc41bd3d 
[1:1:0712/111005.997544:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fe142ed20, -2
[1:1:0712/111006.020696:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111006.021566:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 279a0dd9
[1:1:0712/111006.022568:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 279a0dd9
[1:1:0712/111006.024207:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 279a0dd9
[1:1:0712/111006.025725:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.025944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.026136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.026328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.026986:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 279a0dd9
[1:1:0712/111006.027313:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ff93a57ba
[1:1:0712/111006.027445:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ff939cdef, 7f4ff93a577a, 7f4ff93a70cf
[1:1:0712/111006.033195:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 279a0dd9
[1:1:0712/111006.033566:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 279a0dd9
[1:1:0712/111006.034321:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 279a0dd9
[1:1:0712/111006.036379:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.036582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.036766:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.036992:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 279a0dd9
[1:1:0712/111006.038254:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 279a0dd9
[1:1:0712/111006.038614:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ff93a57ba
[1:1:0712/111006.038748:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ff939cdef, 7f4ff93a577a, 7f4ff93a70cf
[1:1:0712/111006.046812:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111006.047292:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111006.047460:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe58eac718, 0x7ffe58eac698)
[1:1:0712/111006.061656:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111006.068332:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[129246:129246:0712/111006.609516:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129246:129246:0712/111006.610703:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129246:129258:0712/111006.627293:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129246:129246:0712/111006.627322:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129246:129258:0712/111006.627419:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129246:129246:0712/111006.627438:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129246:129246:0712/111006.627593:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129299, 4
[1:7:0712/111006.634183:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[129246:129270:0712/111006.679900:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111006.708825:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x393af7900220
[1:1:0712/111006.709140:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/111007.101774:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[129246:129246:0712/111008.912201:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129246:129246:0712/111008.912310:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111008.951675:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111008.957904:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111010.172249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111010.172654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111010.191255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111010.191675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111010.282086:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111010.617704:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111010.618138:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111010.947700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111010.955983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111010.956380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111010.990980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111011.001445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111011.001732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111011.013507:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129246:129246:0712/111011.019994:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111011.021667:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x393af78fee20
[1:1:0712/111011.021934:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129246:129246:0712/111011.035378:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129246:129246:0712/111011.073894:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129246:129246:0712/111011.074049:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111011.094764:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111012.224568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f4fe30092e0 0x393af7bb1b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111012.226039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111012.226252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111012.227744:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129246:129246:0712/111012.312072:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111012.314430:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x393af78ff820
[1:1:0712/111012.314651:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129246:129246:0712/111012.325447:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111012.333507:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111012.333728:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129246:129246:0712/111012.347432:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129246:129246:0712/111012.360118:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129246:129246:0712/111012.361184:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129246:129258:0712/111012.367598:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129246:129258:0712/111012.367690:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[129246:129246:0712/111012.367843:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129246:129246:0712/111012.367923:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129246:129246:0712/111012.368062:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129299, 4
[1:7:0712/111012.371127:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111012.815060:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111013.405836:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f4fe30092e0 0x393af7ad7c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111013.406806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36a25c361f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111013.406998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111013.407763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129246:129246:0712/111013.502971:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129246:129246:0712/111013.503084:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111013.504117:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[129246:129246:0712/111013.695766:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129246:129277:0712/111013.696211:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111013.696404:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111013.696619:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111013.697030:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111013.697176:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111013.700733:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x21c561ea, 1
[1:1:0712/111013.701152:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x295db198, 0
[1:1:0712/111013.701368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x21ceec21, 3
[1:1:0712/111013.701577:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x9231fa2, 2
[1:1:0712/111013.701796:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff98ffffffb15d29 ffffffea61ffffffc521 ffffffa21f2309 21ffffffecffffffce21 , 10104, 5
[1:1:0712/111013.702990:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129246:129277:0712/111013.703289:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��])�a�!�#	!��!��}
[129246:129277:0712/111013.703355:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��])�a�!�#	!��!�U��}
[1:1:0712/111013.703291:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff75e00a0, 3
[129246:129277:0712/111013.703595:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129344, 5, 98b15d29 ea61c521 a21f2309 21ecce21 
[1:1:0712/111013.703513:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ff776b080, 2
[1:1:0712/111013.703872:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fe142ed20, -2
[1:1:0712/111013.730178:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111013.730623:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9231fa2
[1:1:0712/111013.731050:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9231fa2
[1:1:0712/111013.731864:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9231fa2
[1:1:0712/111013.733597:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.733848:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.734071:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.734287:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.735102:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9231fa2
[1:1:0712/111013.735467:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ff93a57ba
[1:1:0712/111013.735632:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ff939cdef, 7f4ff93a577a, 7f4ff93a70cf
[1:1:0712/111013.742655:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9231fa2
[1:1:0712/111013.743176:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9231fa2
[1:1:0712/111013.744120:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9231fa2
[1:1:0712/111013.746679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.746984:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.747218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.747458:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9231fa2
[1:1:0712/111013.749039:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9231fa2
[1:1:0712/111013.749501:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4ff93a57ba
[1:1:0712/111013.749674:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4ff939cdef, 7f4ff93a577a, 7f4ff93a70cf
[1:1:0712/111013.759494:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111013.760200:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111013.760411:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe58eac718, 0x7ffe58eac698)
[1:1:0712/111013.777589:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111013.783043:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111013.896601:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111013.970585:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x393af78c3220
[1:1:0712/111013.970874:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129246:129246:0712/111014.471798:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129246:129246:0712/111014.479224:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129246:129258:0712/111014.506765:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129246:129258:0712/111014.506864:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129246:129246:0712/111014.507453:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.yc.house365.com/
[129246:129246:0712/111014.507557:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.yc.house365.com/, http://newhouse.yc.house365.com/, 1
[129246:129246:0712/111014.507733:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.yc.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:10:14 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=30i8o6gbgk3bv7olqjpuanjqq4; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,129344, 5
[1:7:0712/111014.511390:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111014.527340:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.yc.house365.com/
[1:1:0712/111014.641519:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111014.641834:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129246:129246:0712/111014.658702:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.yc.house365.com/, http://newhouse.yc.house365.com/, 1
[129246:129246:0712/111014.658766:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.yc.house365.com/, http://newhouse.yc.house365.com
[1:1:0712/111014.702610:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111014.802131:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111014.832859:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111014.866405:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111014.866644:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111015.493916:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111016.199754:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111016.200222:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111016.200623:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111016.201005:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111016.203282:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111016.206680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f4fe1449bd0 0x393af79ebf58 , "http://newhouse.yc.house365.com/"
[1:1:0712/111016.230580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/111016.230877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "newhouse.yc.house365.com", 3, 1, , , 0
[1:1:0712/111016.233300:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_f4a0c1e1 -> 0
[1:1:0712/111016.486462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f4fe1449bd0 0x393af79ebf58 , "http://newhouse.yc.house365.com/"
[1:1:0712/111016.542499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f4fe1449bd0 0x393af79ebf58 , "http://newhouse.yc.house365.com/"
[1:1:0712/111017.892269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f4fe10e1070 0x393af7c3f660 , "http://newhouse.yc.house365.com/"
[1:1:0712/111017.893693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'yc';
    var uid = '';
    var fav_prjid =
[1:1:0712/111017.893928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "newhouse.yc.house365.com", 3, 1, , , 0
[1:1:0712/111017.896434:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.yc.house365.com", "house365.com"
[1:1:0712/111017.906039:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f4fe10e1070 0x393af7c3f660 , "http://newhouse.yc.house365.com/"
[1:1:0712/111017.912072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f4fe10e1070 0x393af7c3f660 , "http://newhouse.yc.house365.com/"
[1:1:0712/111017.918688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7f4fe10e1070 0x393af7c3f660 , "http://newhouse.yc.house365.com/"
[1:1:0712/111018.907033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 325, "http://newhouse.yc.house365.com/"
[1:1:0712/111018.908646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111018.908849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111019.417081:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111019.499597:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111019.499764:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111019.508579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 369 0x7f4ff776b080 0x393af7cd8d80 1 0 0x393af7cd8d98 , "http://newhouse.yc.house365.com/"
[1:1:0712/111019.526450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111019.526692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111019.849913:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0283501, 144, 1
[1:1:0712/111019.850180:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111020.123037:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111020.123283:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111020.124073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f4fe10e1070 0x393af7a38960 , "http://newhouse.yc.house365.com/"
[1:1:0712/111020.125528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/111020.125712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111020.172015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 384 0x7f4fe10e1070 0x393af7a38960 , "http://newhouse.yc.house365.com/"
[1:1:0712/111020.478353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398, "http://newhouse.yc.house365.com/"
[1:1:0712/111020.479904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/111020.480113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111021.152533:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111021.551820:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111021.552100:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111021.555501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f4fe10e1070 0x393af79d3ce0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111021.564911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111021.565187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111021.723521:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.171282, 52, 1
[1:1:0712/111021.723773:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111021.866712:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111021.866897:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111021.867340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f4fe10e1070 0x393af7ac3760 , "http://newhouse.yc.house365.com/"
[1:1:0712/111021.867927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/111021.868045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111021.911668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f4ff776b080 0x393af7aaf420 1 0 0x393af7aaf438 , "http://newhouse.yc.house365.com/"
[1:1:0712/111021.919176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111021.919377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111023.449304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f4ff776b080 0x393af7aaf420 1 0 0x393af7aaf438 , "http://newhouse.yc.house365.com/"
[1:1:0712/111023.456495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f4ff776b080 0x393af7aaf420 1 0 0x393af7aaf438 , "http://newhouse.yc.house365.com/"
[1:1:0712/111023.492056:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0457089, 163, 1
[1:1:0712/111023.492398:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111023.864474:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111023.864742:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111023.865669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4fe10e1070 0x393af86c1ae0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111023.867371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/111023.867683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111023.889993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4fe10e1070 0x393af86c1ae0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111023.907540:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4fe10e1070 0x393af86c1ae0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111023.960435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4fe10e1070 0x393af86c1ae0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111025.786416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111026.135464:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111026.135757:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111026.138115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7f4fe10e1070 0x393af7ef2b60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.139815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111026.140076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111026.147482:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7f4fe10e1070 0x393af7ef2b60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.168030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7f4fe10e1070 0x393af7ef2b60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.279886:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111026.280347:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111026.294848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7f4fe10e1070 0x393af7ef2b60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.353433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 522 0x7f4fe10e1070 0x393af7ef2b60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.396953:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.261037, 232, 1
[1:1:0712/111026.397169:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111026.545182:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111026.545362:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111026.545855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7f4fe10e1070 0x393af8c130e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.546770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/111026.546889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111026.548117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538 0x7f4fe10e1070 0x393af8c130e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111026.701235:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.155891, 1243, 1
[1:1:0712/111026.701431:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111027.441238:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111027.441483:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111027.442318:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566 0x7f4fe10e1070 0x393af8f80de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111027.443204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
listCondition.p=1;
var totalpage=18;

[1:1:0712/111027.443388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111027.483767:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0422468, 240, 1
[1:1:0712/111027.484061:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111027.780848:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111027.781108:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111027.781878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4fe10e1070 0x393af84ecf60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111027.782900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
    $(function(){
        $(".hotslide").on("click",function(){
            if($(this).children("im
[1:1:0712/111027.783099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111027.790509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4fe10e1070 0x393af84ecf60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111027.795752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4fe10e1070 0x393af84ecf60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111027.806627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f4fe10e1070 0x393af84ecf60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111029.500898:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.71973, 0, 0
[1:1:0712/111029.501158:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111029.956463:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111029.956781:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111029.960319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111029.962187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , /**
 * Created by Administrator
 * 精准导购 直销
 */


function showJzdgContactMe(img,us
[1:1:0712/111029.962422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111029.967802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111029.977753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111029.995509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.096238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.108464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.129827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.136866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.225449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.241255:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.249885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.255123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.294962:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111030.298108:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f4fe10e1070 0x393af8f85de0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111032.396432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 684 0x7f4fe1449bd0 0x393af79d3358 , "http://newhouse.yc.house365.com/"
[1:1:0712/111032.405481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (function(){var h={},mt={},c={id:"10e398a5efeb9128500f1e0001f14c62",dm:["yc.house365.com"],js:"tongj
[1:1:0712/111032.405784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111032.446310:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e960
[1:1:0712/111032.446589:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111032.446992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 689
[1:1:0712/111032.447251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f4fe10e1070 0x393af9055f60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 684 0x7f4fe1449bd0 0x393af79d3358 
[129246:129246:0712/111040.767337:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[129246:129246:0712/111040.796805:INFO:CONSOLE(1726)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?10e398a5efeb9128500f1e0001f14c62, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.yc.house365.com/ (1726)
[129246:129246:0712/111040.800779:INFO:CONSOLE(1726)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?10e398a5efeb9128500f1e0001f14c62, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.yc.house365.com/ (1726)
[3:3:0712/111040.861526:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111042.481325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111042.481666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111043.835298:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111043.899222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 689, 7f4fe3a26881
[1:1:0712/111043.912345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"684 0x7f4fe1449bd0 0x393af79d3358 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111043.913108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"684 0x7f4fe1449bd0 0x393af79d3358 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111043.913553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111043.914216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111043.914474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111043.915399:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111043.915648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111043.916087:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 764
[1:1:0712/111043.916329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f4fe10e1070 0x393af901b060 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 689 0x7f4fe10e1070 0x393af9055f60 
[1:1:0712/111044.066513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111044.066814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111044.764947:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111044.765247:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.yc.house365.com/"
[1:1:0712/111044.769278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 762 0x7f4fe10e1070 0x393af9032ae0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111044.774545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (function(){
	var parameters = {
			'guid'  : 'new_guid',
			'todayfirst' : 'new_todayfirst',
		
[1:1:0712/111044.774792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111044.957203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 764, 7f4fe3a26881
[1:1:0712/111044.997080:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"689 0x7f4fe10e1070 0x393af9055f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111044.997474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"689 0x7f4fe10e1070 0x393af9055f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111044.997907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111044.998352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111044.998586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111044.999384:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111044.999631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111045.000028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 835
[1:1:0712/111045.000295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f4fe10e1070 0x393af90be8e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 764 0x7f4fe10e1070 0x393af901b060 
[1:1:0712/111045.014262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111045.014534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111046.894698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111046.896732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/111046.896968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111046.946646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 834, "http://newhouse.yc.house365.com/"
[1:1:0712/111046.947458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
[1:1:0712/111046.947678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111046.952352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 834, "http://newhouse.yc.house365.com/"
[1:1:0712/111047.053854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111047.054030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111047.055315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 835, 7f4fe3a26881
[1:1:0712/111047.068008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"764 0x7f4fe10e1070 0x393af901b060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111047.068174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"764 0x7f4fe10e1070 0x393af901b060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111047.068363:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111047.068681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111047.068797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111047.069127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111047.069227:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111047.069400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 893
[1:1:0712/111047.069509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7f4fe10e1070 0x393af8dec960 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 835 0x7f4fe10e1070 0x393af90be8e0 
[1:1:0712/111048.659386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111048.659655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111048.768892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 896, "http://newhouse.yc.house365.com/"
[1:1:0712/111048.769738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , 
[1:1:0712/111048.769922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111048.775554:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 896, "http://newhouse.yc.house365.com/"
[1:1:0712/111048.795094:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://newhouse.yc.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111050.562169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 200
[1:1:0712/111050.562484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 925
[1:1:0712/111050.562607:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f4fe10e1070 0x393af7f0f2e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 896
[1:1:0712/111050.562877:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x3c986ea229c8, 0x393af774ea10
[1:1:0712/111050.562981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 60000
[1:1:0712/111050.563171:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 926
[1:1:0712/111050.563283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f4fe10e1070 0x393af90872e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 896
[1:1:0712/111050.638826:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129246:129246:0712/111050.640203:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111050.642429:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x393af81e2420
[1:1:0712/111050.642629:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129246:129246:0712/111050.647386:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[129246:129246:0712/111050.690553:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://newhouse.yc.house365.com/, http://newhouse.yc.house365.com/, 4
[129246:129246:0712/111050.690705:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://newhouse.yc.house365.com/, http://newhouse.yc.house365.com
[1:1:0712/111052.095428:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://newhouse.yc.house365.com/"
[1:1:0712/111052.177164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 893, 7f4fe3a26881
[1:1:0712/111052.201537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"835 0x7f4fe10e1070 0x393af90be8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111052.201825:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"835 0x7f4fe10e1070 0x393af90be8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111052.202232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111052.202832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111052.203038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111052.203704:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111052.203902:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111052.204246:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 958
[1:1:0712/111052.204439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7f4fe10e1070 0x393af81c1760 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 893 0x7f4fe10e1070 0x393af8dec960 
[1:1:0712/111052.332070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111052.332253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111052.809720:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://newhouse.yc.house365.com/"
[1:1:0712/111052.810171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , r, (e,i){var u,f,l,c,h;try{if(r&&(i||a.readyState===4)){r=t,o&&(a.onreadystatechange=v.noop,Bn&&delete 
[1:1:0712/111052.810288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111052.810856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://newhouse.yc.house365.com/"
[1:1:0712/111052.812434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://newhouse.yc.house365.com/"
[1:1:0712/111052.812774:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2a9501994a0
[1:1:0712/111052.901687:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111052.902232:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111052.905788:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111053.600916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 956 0x7f4fe30092e0 0x393af9465ce0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111053.604550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var conf_ga_public_code = "UA-35147609-1";

var conf_ga_city = new Array();
conf_ga_city["nj"] = 
[1:1:0712/111053.604734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111053.624663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3c986ea229c8, 0x393af774e948
[1:1:0712/111053.624904:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 5000
[1:1:0712/111053.625268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1000
[1:1:0712/111053.625468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f4fe10e1070 0x393af9354c60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 956 0x7f4fe30092e0 0x393af9465ce0 
[1:1:0712/111053.795042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 925, 7f4fe3a268db
[1:1:0712/111053.825069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"896","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111053.825304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"896","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111053.825550:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1007
[1:1:0712/111053.825668:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7f4fe10e1070 0x393af907d5e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 925 0x7f4fe10e1070 0x393af7f0f2e0 
[1:1:0712/111053.825865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111053.826192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111053.826303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111053.873650:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 958, 7f4fe3a26881
[1:1:0712/111053.887650:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"893 0x7f4fe10e1070 0x393af8dec960 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111053.887856:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"893 0x7f4fe10e1070 0x393af8dec960 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111053.888091:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111053.888440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111053.888572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111053.888926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111053.889028:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111053.889225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1008
[1:1:0712/111053.889346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1008 0x7f4fe10e1070 0x393afa733d60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 958 0x7f4fe10e1070 0x393af81c1760 
[1:1:0712/111053.904217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111053.904414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111054.848579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111054.848770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111054.850102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1007, 7f4fe3a268db
[1:1:0712/111054.864961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"925 0x7f4fe10e1070 0x393af7f0f2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111054.865137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"925 0x7f4fe10e1070 0x393af7f0f2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111054.865403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1030
[1:1:0712/111054.865526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f4fe10e1070 0x393af907ef60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1007 0x7f4fe10e1070 0x393af907d5e0 
[1:1:0712/111054.865722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111054.866025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111054.866145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111054.932676:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1008, 7f4fe3a26881
[1:1:0712/111054.977952:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"958 0x7f4fe10e1070 0x393af81c1760 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111054.978308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"958 0x7f4fe10e1070 0x393af81c1760 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111054.978698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111054.979270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111054.979479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111054.980150:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111054.980313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111054.980694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1036
[1:1:0712/111054.980899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f4fe10e1070 0x393af88c0e60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1008 0x7f4fe10e1070 0x393afa733d60 
[1:1:0712/111055.478894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111055.479148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111055.542318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1030, 7f4fe3a268db
[1:1:0712/111055.588084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1007 0x7f4fe10e1070 0x393af907d5e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111055.588373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1007 0x7f4fe10e1070 0x393af907d5e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111055.588804:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1060
[1:1:0712/111055.589001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f4fe10e1070 0x393afa6c6be0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1030 0x7f4fe10e1070 0x393af907ef60 
[1:1:0712/111055.589361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111055.589920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111055.590112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111055.928932:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1036, 7f4fe3a26881
[1:1:0712/111055.974163:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1008 0x7f4fe10e1070 0x393afa733d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111055.974485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1008 0x7f4fe10e1070 0x393afa733d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111055.974888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111055.975437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111055.975614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111055.976317:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111055.976476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111055.976855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1074
[1:1:0712/111055.977057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7f4fe10e1070 0x393af8914060 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1036 0x7f4fe10e1070 0x393af88c0e60 
[1:1:0712/111056.073794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1047 0x7f4fe30092e0 0x393af95514e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111056.089885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/111056.090065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_bde40525 -> 0
		remove user.12_8aa13e5a -> 0
		remove user.13_5013d313 -> 0
		remove user.14_1e0546ff -> 0
		remove user.15_93b7e682 -> 0
[1:1:0712/111056.944467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1048 0x7f4fe30092e0 0x393af9059f60 , "http://newhouse.yc.house365.com/"
[1:1:0712/111056.954248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (function(){var h={},mt={},c={id:"951cc35d48efc1a61a321fa481114379",dm:["house365.com"],js:"tongji.b
[1:1:0712/111056.954525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111056.986956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e990
[1:1:0712/111056.987234:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111056.987631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1141
[1:1:0712/111056.987921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1141 0x7f4fe10e1070 0x393af90c7260 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1048 0x7f4fe30092e0 0x393af9059f60 
[1:1:0712/111057.131453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111057.131766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111057.502173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1060, 7f4fe3a268db
[1:1:0712/111057.552425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1030 0x7f4fe10e1070 0x393af907ef60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111057.552789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1030 0x7f4fe10e1070 0x393af907ef60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111057.553290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1174
[1:1:0712/111057.553535:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f4fe10e1070 0x393af7a6a860 , 5:3_http://newhouse.yc.house365.com/, 0, , 1060 0x7f4fe10e1070 0x393afa6c6be0 
[1:1:0712/111057.553928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111057.554550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111057.554771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111059.850328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1074, 7f4fe3a26881
[1:1:0712/111059.865622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1036 0x7f4fe10e1070 0x393af88c0e60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111059.865812:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1036 0x7f4fe10e1070 0x393af88c0e60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111059.866015:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111059.866324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111059.866437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111059.866786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111059.866905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111059.867121:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1227
[1:1:0712/111059.867233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7f4fe10e1070 0x393afb451660 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1074 0x7f4fe10e1070 0x393af8914060 
[1:1:0712/111101.202078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1141, 7f4fe3a26881
[1:1:0712/111101.254520:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1048 0x7f4fe30092e0 0x393af9059f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.254852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1048 0x7f4fe30092e0 0x393af9059f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.255260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111101.255805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111101.256016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111101.256783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111101.256964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111101.257318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1274
[1:1:0712/111101.257508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1274 0x7f4fe10e1070 0x393afb46a2e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1141 0x7f4fe10e1070 0x393af90c7260 
[1:1:0712/111101.311742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111101.312031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111101.704234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1174, 7f4fe3a268db
[1:1:0712/111101.759935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1060 0x7f4fe10e1070 0x393afa6c6be0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.760295:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1060 0x7f4fe10e1070 0x393afa6c6be0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.760707:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1296
[1:1:0712/111101.760902:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1296 0x7f4fe10e1070 0x393afb16efe0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1174 0x7f4fe10e1070 0x393af7a6a860 
[1:1:0712/111101.761277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111101.761807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111101.761986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111101.930720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1000, 7f4fe3a26881
[1:1:0712/111101.983013:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"956 0x7f4fe30092e0 0x393af9465ce0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.983361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"956 0x7f4fe30092e0 0x393af9465ce0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111101.983736:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111101.984345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (){
    if(typeof(isa_city) == "undefined"){
        var _source = document.URL;
        var _sta
[1:1:0712/111101.984531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111101.987008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1227, 7f4fe3a26881
[1:1:0712/111102.013090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1074 0x7f4fe10e1070 0x393af8914060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.013303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1074 0x7f4fe10e1070 0x393af8914060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.013515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111102.013835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111102.013945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111102.014293:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111102.014414:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111102.014596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1308
[1:1:0712/111102.014707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7f4fe10e1070 0x393af81c1560 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1227 0x7f4fe10e1070 0x393afb451660 
[1:1:0712/111102.172905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111102.173084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111102.210627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1274, 7f4fe3a26881
[1:1:0712/111102.263408:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1141 0x7f4fe10e1070 0x393af90c7260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.263726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1141 0x7f4fe10e1070 0x393af90c7260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.264146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111102.264722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111102.264932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111102.265626:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111102.265789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111102.266153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1329
[1:1:0712/111102.266353:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f4fe10e1070 0x393af9479b60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1274 0x7f4fe10e1070 0x393afb46a2e0 
[1:1:0712/111102.458018:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1296, 7f4fe3a268db
[1:1:0712/111102.511758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1174 0x7f4fe10e1070 0x393af7a6a860 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.512055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1174 0x7f4fe10e1070 0x393af7a6a860 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111102.512497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1343
[1:1:0712/111102.512713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7f4fe10e1070 0x393afb46a2e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1296 0x7f4fe10e1070 0x393afb16efe0 
[1:1:0712/111102.513057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111102.513610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111102.513794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111102.620827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1300 0x7f4fe30092e0 0x393afb46a0e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111102.656459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==type
[1:1:0712/111102.656749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[129246:129246:0712/111102.814635:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111103.383209:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111103.696699:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111103.697397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/111103.697602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111103.866455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111103.867165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/111103.867350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111103.876461:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1308, 7f4fe3a26881
[1:1:0712/111103.934285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1227 0x7f4fe10e1070 0x393afb451660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111103.934905:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1227 0x7f4fe10e1070 0x393afb451660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111103.935669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111103.936744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111103.937094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111103.938391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111103.938734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111103.939373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1370
[1:1:0712/111103.939814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7f4fe10e1070 0x393af7e6a360 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1308 0x7f4fe10e1070 0x393af81c1560 
[1:1:0712/111103.978225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111103.978416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.308923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1329, 7f4fe3a26881
[1:1:0712/111104.360872:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1274 0x7f4fe10e1070 0x393afb46a2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.361183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1274 0x7f4fe10e1070 0x393afb46a2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.361558:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111104.362115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111104.362286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.362941:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111104.363098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111104.363423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1388
[1:1:0712/111104.363603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1388 0x7f4fe10e1070 0x393afac38ee0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1329 0x7f4fe10e1070 0x393af9479b60 
[1:1:0712/111104.537953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1343, 7f4fe3a268db
[1:1:0712/111104.555256:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1296 0x7f4fe10e1070 0x393afb16efe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.555455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1296 0x7f4fe10e1070 0x393afb16efe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.555700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1397
[1:1:0712/111104.555817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1397 0x7f4fe10e1070 0x393afa85ee60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1343 0x7f4fe10e1070 0x393afb46a2e0 
[1:1:0712/111104.556002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111104.556302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111104.556406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.776505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111104.776696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.866230:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1370, 7f4fe3a26881
[1:1:0712/111104.884373:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1308 0x7f4fe10e1070 0x393af81c1560 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.884580:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1308 0x7f4fe10e1070 0x393af81c1560 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.884802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111104.885124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111104.885229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.885553:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111104.885652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111104.885857:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1408
[1:1:0712/111104.885974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7f4fe10e1070 0x393afb46d8e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1370 0x7f4fe10e1070 0x393af7e6a360 
[1:1:0712/111104.939522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111104.940005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/111104.940117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.940794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1388, 7f4fe3a26881
[1:1:0712/111104.979883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1329 0x7f4fe10e1070 0x393af9479b60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.980065:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1329 0x7f4fe10e1070 0x393af9479b60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111104.980266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111104.980565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111104.980684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111104.981472:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111104.981632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111104.982019:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1409
[1:1:0712/111104.982217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1409 0x7f4fe10e1070 0x393afac27760 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1388 0x7f4fe10e1070 0x393afac38ee0 
[1:1:0712/111105.033270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1397, 7f4fe3a268db
[1:1:0712/111105.088274:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1343 0x7f4fe10e1070 0x393afb46a2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.088569:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1343 0x7f4fe10e1070 0x393afb46a2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.089003:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1411
[1:1:0712/111105.089203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1411 0x7f4fe10e1070 0x393afb16d2e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1397 0x7f4fe10e1070 0x393afa85ee60 
[1:1:0712/111105.089524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111105.090080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111105.090264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111105.383683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1402 0x7f4fe30092e0 0x393afac1b360 , "http://newhouse.yc.house365.com/"
[1:1:0712/111105.385034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , (function() {
  // 配置
  var envir = 'online';
  var configMap = {
    dev: {
      appkey: 'fe41
[1:1:0712/111105.385234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111105.386773:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111105.515594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111105.515833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111105.517763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1408, 7f4fe3a26881
[1:1:0712/111105.580096:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1370 0x7f4fe10e1070 0x393af7e6a360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.580416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1370 0x7f4fe10e1070 0x393af7e6a360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.580797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111105.581361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111105.581542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111105.582224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111105.582390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111105.582738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1428
[1:1:0712/111105.582949:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7f4fe10e1070 0x393afb33f060 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1408 0x7f4fe10e1070 0x393afb46d8e0 
[1:1:0712/111105.585051:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1409, 7f4fe3a26881
[1:1:0712/111105.641522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1388 0x7f4fe10e1070 0x393afac38ee0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.641844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1388 0x7f4fe10e1070 0x393afac38ee0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.642265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111105.642817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111105.643016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111105.643687:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111105.643846:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111105.644226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1431
[1:1:0712/111105.644423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1431 0x7f4fe10e1070 0x393afac38260 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1409 0x7f4fe10e1070 0x393afac27760 
[1:1:0712/111105.875247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1411, 7f4fe3a268db
[1:1:0712/111105.932077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1397 0x7f4fe10e1070 0x393afa85ee60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.932365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1397 0x7f4fe10e1070 0x393afa85ee60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111105.932758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1440
[1:1:0712/111105.932950:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1440 0x7f4fe10e1070 0x393af94554e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1411 0x7f4fe10e1070 0x393afb16d2e0 
[1:1:0712/111105.933322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111105.933852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111105.934051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.170431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111106.170631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.202216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1428, 7f4fe3a26881
[1:1:0712/111106.220297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1408 0x7f4fe10e1070 0x393afb46d8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.220512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1408 0x7f4fe10e1070 0x393afb46d8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.220719:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111106.221028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111106.221160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.221477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111106.221574:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111106.221785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1453
[1:1:0712/111106.221900:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7f4fe10e1070 0x393afb16e4e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1428 0x7f4fe10e1070 0x393afb33f060 
[1:1:0712/111106.222393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1431, 7f4fe3a26881
[1:1:0712/111106.248343:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1409 0x7f4fe10e1070 0x393afac27760 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.248663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1409 0x7f4fe10e1070 0x393afac27760 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.249013:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111106.249550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111106.249816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.250462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111106.250619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111106.250952:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1454
[1:1:0712/111106.251179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7f4fe10e1070 0x393af8189360 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1431 0x7f4fe10e1070 0x393afac38260 
[1:1:0712/111106.252558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1440, 7f4fe3a268db
[1:1:0712/111106.290363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1411 0x7f4fe10e1070 0x393afb16d2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.290559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1411 0x7f4fe10e1070 0x393afb16d2e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.290784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1455
[1:1:0712/111106.290894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1455 0x7f4fe10e1070 0x393afa85e560 , 5:3_http://newhouse.yc.house365.com/, 0, , 1440 0x7f4fe10e1070 0x393af94554e0 
[1:1:0712/111106.291099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111106.291407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111106.291510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.537430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1449 0x7f4fe30092e0 0x393afb37a860 , "http://newhouse.yc.house365.com/"
[1:1:0712/111106.539980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var emoji={"[大笑]":{file:"emoji_0.png"},"[可爱]":{file:"emoji_01.png"},"[色]":{file:"emoji_02.
[1:1:0712/111106.540151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.548774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111106.721973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111106.722241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.783431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1453, 7f4fe3a26881
[1:1:0712/111106.841935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1428 0x7f4fe10e1070 0x393afb33f060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.842289:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1428 0x7f4fe10e1070 0x393afb33f060 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.842699:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111106.843270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111106.843453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.844129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111106.844339:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111106.844692:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1474
[1:1:0712/111106.844885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1474 0x7f4fe10e1070 0x393afb3b2460 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1453 0x7f4fe10e1070 0x393afb16e4e0 
[1:1:0712/111106.905293:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1454, 7f4fe3a26881
[1:1:0712/111106.963164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1431 0x7f4fe10e1070 0x393afac38260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.963509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1431 0x7f4fe10e1070 0x393afac38260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111106.963915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111106.964497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111106.964682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111106.965367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111106.965532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111106.965873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1478
[1:1:0712/111106.966063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1478 0x7f4fe10e1070 0x393afb1cdb60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1454 0x7f4fe10e1070 0x393af8189360 
[1:1:0712/111106.968138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1455, 7f4fe3a268db
[1:1:0712/111107.026598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1440 0x7f4fe10e1070 0x393af94554e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.026884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1440 0x7f4fe10e1070 0x393af94554e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.027302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1482
[1:1:0712/111107.027499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1482 0x7f4fe10e1070 0x393afac275e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1455 0x7f4fe10e1070 0x393afa85e560 
[1:1:0712/111107.027815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111107.028381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111107.028564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111107.458928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111107.459175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111107.593921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1474, 7f4fe3a26881
[1:1:0712/111107.654630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1453 0x7f4fe10e1070 0x393afb16e4e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.654857:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1453 0x7f4fe10e1070 0x393afb16e4e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.655077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111107.655447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111107.655670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111107.656181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111107.656285:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111107.656566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1501
[1:1:0712/111107.656688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1501 0x7f4fe10e1070 0x393afac2bd60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1474 0x7f4fe10e1070 0x393afb3b2460 
[1:1:0712/111107.657308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1478, 7f4fe3a26881
[1:1:0712/111107.710593:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1454 0x7f4fe10e1070 0x393af8189360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.710923:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1454 0x7f4fe10e1070 0x393af8189360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111107.711295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111107.711862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111107.712057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111107.712822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111107.713023:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111107.713453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1503
[1:1:0712/111107.713656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1503 0x7f4fe10e1070 0x393afa19ed60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1478 0x7f4fe10e1070 0x393afb1cdb60 
[1:1:0712/111107.959332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1482, 7f4fe3a268db
[1:1:0712/111108.017767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1455 0x7f4fe10e1070 0x393afa85e560 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.018077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1455 0x7f4fe10e1070 0x393afa85e560 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.018505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1513
[1:1:0712/111108.018709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1513 0x7f4fe10e1070 0x393afac40d60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1482 0x7f4fe10e1070 0x393afac275e0 
[1:1:0712/111108.019053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111108.019611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111108.019795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111108.182791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1493 0x7f4fe30092e0 0x393afb371ee0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111108.194347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , if (!Function.prototype.bind) {
    Function.prototype.bind = function () {
        var fn = this, a
[1:1:0712/111108.194664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111108.200225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111108.457185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111108.457435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111108.461206:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1501, 7f4fe3a26881
[1:1:0712/111108.520774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1474 0x7f4fe10e1070 0x393afb3b2460 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.521108:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1474 0x7f4fe10e1070 0x393afb3b2460 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.521501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111108.522069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111108.522253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111108.522957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111108.523121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111108.523464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1532
[1:1:0712/111108.523712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1532 0x7f4fe10e1070 0x393afb3bfde0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1501 0x7f4fe10e1070 0x393afac2bd60 
[1:1:0712/111108.585554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1503, 7f4fe3a26881
[1:1:0712/111108.646327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1478 0x7f4fe10e1070 0x393afb1cdb60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.646682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1478 0x7f4fe10e1070 0x393afb1cdb60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111108.647084:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111108.647660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111108.647842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111108.648508:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111108.648685:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111108.649035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1535
[1:1:0712/111108.649226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1535 0x7f4fe10e1070 0x393afa83ff60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1503 0x7f4fe10e1070 0x393afa19ed60 
[1:1:0712/111109.013030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1513, 7f4fe3a268db
[1:1:0712/111109.031795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1482 0x7f4fe10e1070 0x393afac275e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.032020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1482 0x7f4fe10e1070 0x393afac275e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.032244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1551
[1:1:0712/111109.032355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1551 0x7f4fe10e1070 0x393afb3f0260 , 5:3_http://newhouse.yc.house365.com/, 0, , 1513 0x7f4fe10e1070 0x393afac40d60 
[1:1:0712/111109.032577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.032892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111109.033012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.074410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111109.074593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.075920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1532, 7f4fe3a26881
[1:1:0712/111109.094826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1501 0x7f4fe10e1070 0x393afac2bd60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.095029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1501 0x7f4fe10e1070 0x393afac2bd60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.095233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.095538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111109.095659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.096009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111109.096113:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111109.096306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1553
[1:1:0712/111109.096428:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1553 0x7f4fe10e1070 0x393afb3bfd60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1532 0x7f4fe10e1070 0x393afb3bfde0 
[1:1:0712/111109.096923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1535, 7f4fe3a26881
[1:1:0712/111109.125922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1503 0x7f4fe10e1070 0x393afa19ed60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.126235:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1503 0x7f4fe10e1070 0x393afa19ed60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.126592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.127131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111109.127324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.128001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111109.128160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111109.128489:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1554
[1:1:0712/111109.128672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1554 0x7f4fe10e1070 0x393afb4073e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1535 0x7f4fe10e1070 0x393afa83ff60 
[1:1:0712/111109.262746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1548 0x7f4fe30092e0 0x393af758c060 , "http://newhouse.yc.house365.com/"
[1:1:0712/111109.265752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , // 数据缓存
// 建议开发者选择mvvm框架来通过数据来驱动UI变化
var Cache = (func
[1:1:0712/111109.265910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.266840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111109.389433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111109.389666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.393422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1551, 7f4fe3a268db
[1:1:0712/111109.454773:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1513 0x7f4fe10e1070 0x393afac40d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.455099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1513 0x7f4fe10e1070 0x393afac40d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.455497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1569
[1:1:0712/111109.455689:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1569 0x7f4fe10e1070 0x393af758c1e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1551 0x7f4fe10e1070 0x393afb3f0260 
[1:1:0712/111109.456057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.456590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111109.456771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.516776:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1553, 7f4fe3a26881
[1:1:0712/111109.576743:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1532 0x7f4fe10e1070 0x393afb3bfde0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.577093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1532 0x7f4fe10e1070 0x393afb3bfde0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.577458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.578025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111109.578207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.578887:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111109.579052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111109.579391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1573
[1:1:0712/111109.579582:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1573 0x7f4fe10e1070 0x393afb481a60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1553 0x7f4fe10e1070 0x393afb3bfd60 
[1:1:0712/111109.581698:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1554, 7f4fe3a26881
[1:1:0712/111109.642244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1535 0x7f4fe10e1070 0x393afa83ff60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.642567:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1535 0x7f4fe10e1070 0x393afa83ff60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111109.642966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111109.643533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111109.643737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111109.644454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111109.644616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111109.644983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1578
[1:1:0712/111109.645180:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1578 0x7f4fe10e1070 0x393afa83fbe0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1554 0x7f4fe10e1070 0x393afb4073e0 
[1:1:0712/111109.994589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111109.994859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111110.123666:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1569, 7f4fe3a268db
[1:1:0712/111110.184475:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1551 0x7f4fe10e1070 0x393afb3f0260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.184770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1551 0x7f4fe10e1070 0x393afb3f0260 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.185204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1597
[1:1:0712/111110.185402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1597 0x7f4fe10e1070 0x393af817fe60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1569 0x7f4fe10e1070 0x393af758c1e0 
[1:1:0712/111110.185759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111110.186304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111110.186486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111110.256844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1573, 7f4fe3a26881
[1:1:0712/111110.317741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1553 0x7f4fe10e1070 0x393afb3bfd60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.318088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1553 0x7f4fe10e1070 0x393afb3bfd60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.318477:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111110.319037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111110.319220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111110.319883:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111110.320089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111110.320446:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1600
[1:1:0712/111110.320646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1600 0x7f4fe10e1070 0x393afb48d0e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1573 0x7f4fe10e1070 0x393afb481a60 
[1:1:0712/111110.510030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1578, 7f4fe3a26881
[1:1:0712/111110.571442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1554 0x7f4fe10e1070 0x393afb4073e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.571773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1554 0x7f4fe10e1070 0x393afb4073e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111110.572184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111110.572737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111110.572918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111110.573615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111110.573778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111110.574152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1610
[1:1:0712/111110.574348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1610 0x7f4fe10e1070 0x393af7f51f60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1578 0x7f4fe10e1070 0x393afa83fbe0 
[1:1:0712/111110.905452:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1589 0x7f4fe30092e0 0x393afb48d2e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111110.915691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , /**
 * SDK连接 功能相关
 */

var SDKBridge = function(ctr, data) {

  var sdktoken = ctr.yunxi
[1:1:0712/111110.915943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111110.916945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111111.058368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111111.058628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.137966:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1597, 7f4fe3a268db
[1:1:0712/111111.204309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1569 0x7f4fe10e1070 0x393af758c1e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.204610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1569 0x7f4fe10e1070 0x393af758c1e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.205033:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1629
[1:1:0712/111111.205254:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1629 0x7f4fe10e1070 0x393afac3de60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1597 0x7f4fe10e1070 0x393af817fe60 
[1:1:0712/111111.205615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111111.206154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111111.206355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.217299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1600, 7f4fe3a26881
[1:1:0712/111111.278396:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1573 0x7f4fe10e1070 0x393afb481a60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.278725:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1573 0x7f4fe10e1070 0x393afb481a60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.279103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111111.279653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111111.279826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.280518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111111.280708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111111.281035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1632
[1:1:0712/111111.281216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1632 0x7f4fe10e1070 0x393afb3c47e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1600 0x7f4fe10e1070 0x393afb48d0e0 
[1:1:0712/111111.492204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1610, 7f4fe3a26881
[1:1:0712/111111.556178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1578 0x7f4fe10e1070 0x393afa83fbe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.556581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1578 0x7f4fe10e1070 0x393afa83fbe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.557050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111111.557769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111111.558007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.558838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111111.559005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111111.559518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1643
[1:1:0712/111111.559719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1643 0x7f4fe10e1070 0x393afb3ca8e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1610 0x7f4fe10e1070 0x393af7f51f60 
[1:1:0712/111111.824950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111111.825204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.930336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1629, 7f4fe3a268db
[1:1:0712/111111.949928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1597 0x7f4fe10e1070 0x393af817fe60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.950104:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1597 0x7f4fe10e1070 0x393af817fe60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111111.950316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1657
[1:1:0712/111111.950446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1657 0x7f4fe10e1070 0x393afb3b2ae0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1629 0x7f4fe10e1070 0x393afac3de60 
[1:1:0712/111111.950653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111111.950955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111111.951060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111111.994767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1632, 7f4fe3a26881
[1:1:0712/111112.021297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1600 0x7f4fe10e1070 0x393afb48d0e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.021642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1600 0x7f4fe10e1070 0x393afb48d0e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.022038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111112.022603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111112.022789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111112.023475:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111112.023641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111112.023993:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1661
[1:1:0712/111112.024186:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1661 0x7f4fe10e1070 0x393afb409d60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1632 0x7f4fe10e1070 0x393afb3c47e0 
[1:1:0712/111112.359064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1647 0x7f4fe30092e0 0x393afb3fa3e0 , "http://newhouse.yc.house365.com/"
[1:1:0712/111112.363483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , var appUI = {
  /**
   * 当前会话聊天面板UI
   */
  buildChatContentUI: function(id, cache) 
[1:1:0712/111112.363718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111112.365387:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.yc.house365.com/"
[1:1:0712/111112.439345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1643, 7f4fe3a26881
[1:1:0712/111112.502609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1610 0x7f4fe10e1070 0x393af7f51f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.502946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1610 0x7f4fe10e1070 0x393af7f51f60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.503332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111112.503914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111112.504094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111112.504779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111112.504944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111112.505282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1680
[1:1:0712/111112.505480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1680 0x7f4fe10e1070 0x393afb409fe0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1643 0x7f4fe10e1070 0x393afb3ca8e0 
[1:1:0712/111112.637232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , , document.readyState
[1:1:0712/111112.637480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111112.770083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1657, 7f4fe3a268db
[1:1:0712/111112.845539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1629 0x7f4fe10e1070 0x393afac3de60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.845915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1629 0x7f4fe10e1070 0x393afac3de60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111112.846434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1689
[1:1:0712/111112.846716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1689 0x7f4fe10e1070 0x393afb3d9860 , 5:3_http://newhouse.yc.house365.com/, 0, , 1657 0x7f4fe10e1070 0x393afb3b2ae0 
[1:1:0712/111112.847170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111112.847871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111112.848102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.103826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1661, 7f4fe3a26881
[1:1:0712/111113.124433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1632 0x7f4fe10e1070 0x393afb3c47e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.124624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1632 0x7f4fe10e1070 0x393afb3c47e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.124853:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.125172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111113.125279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.125602:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111113.125732:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111113.125913:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1699
[1:1:0712/111113.126022:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1699 0x7f4fe10e1070 0x393afb371ee0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1661 0x7f4fe10e1070 0x393afb409d60 
[1:1:0712/111113.346320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1680, 7f4fe3a26881
[1:1:0712/111113.371086:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1643 0x7f4fe10e1070 0x393afb3ca8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.371296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1643 0x7f4fe10e1070 0x393afb3ca8e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.371500:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.371869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111113.372034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.372354:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111113.372457:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111113.372634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1707
[1:1:0712/111113.372773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1707 0x7f4fe10e1070 0x393afb4002e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1680 0x7f4fe10e1070 0x393afb409fe0 
[1:1:0712/111113.415078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1689, 7f4fe3a268db
[1:1:0712/111113.435516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1657 0x7f4fe10e1070 0x393afb3b2ae0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.435707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1657 0x7f4fe10e1070 0x393afb3b2ae0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.435970:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1709
[1:1:0712/111113.436084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1709 0x7f4fe10e1070 0x393afb3ca0e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1689 0x7f4fe10e1070 0x393afb3d9860 
[1:1:0712/111113.436270:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.436563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111113.436678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.439416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1699, 7f4fe3a26881
[1:1:0712/111113.459084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1661 0x7f4fe10e1070 0x393afb409d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.459232:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1661 0x7f4fe10e1070 0x393afb409d60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.459415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.459673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111113.459849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.460171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111113.460268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111113.460436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1710
[1:1:0712/111113.460542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1710 0x7f4fe10e1070 0x393afb3c4ae0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1699 0x7f4fe10e1070 0x393afb371ee0 
[1:1:0712/111113.627740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1707, 7f4fe3a26881
[1:1:0712/111113.682276:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1680 0x7f4fe10e1070 0x393afb409fe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.682621:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1680 0x7f4fe10e1070 0x393afb409fe0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.683007:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.683609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111113.683791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.684503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111113.684664:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111113.685036:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1719
[1:1:0712/111113.685247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1719 0x7f4fe10e1070 0x393afb3c3360 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1707 0x7f4fe10e1070 0x393afb4002e0 
[1:1:0712/111113.752113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1710, 7f4fe3a26881
[1:1:0712/111113.818108:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1699 0x7f4fe10e1070 0x393afb371ee0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.818441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1699 0x7f4fe10e1070 0x393afb371ee0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.818885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.819440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111113.819617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111113.820323:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111113.820487:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111113.820836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1722
[1:1:0712/111113.821056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1722 0x7f4fe10e1070 0x393afb3f0660 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1710 0x7f4fe10e1070 0x393afb3c4ae0 
[1:1:0712/111113.823070:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1709, 7f4fe3a268db
[1:1:0712/111113.889147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1689 0x7f4fe10e1070 0x393afb3d9860 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.889440:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1689 0x7f4fe10e1070 0x393afb3d9860 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111113.889864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1726
[1:1:0712/111113.890067:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1726 0x7f4fe10e1070 0x393afb48dc60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1709 0x7f4fe10e1070 0x393afb3ca0e0 
[1:1:0712/111113.890387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111113.890938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111113.891121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.168745:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1719, 7f4fe3a26881
[1:1:0712/111114.234163:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1707 0x7f4fe10e1070 0x393afb4002e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.234497:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1707 0x7f4fe10e1070 0x393afb4002e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.234888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.235475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111114.235656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.236358:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111114.236521:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111114.236872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1736
[1:1:0712/111114.237084:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1736 0x7f4fe10e1070 0x393afb3f3160 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1719 0x7f4fe10e1070 0x393afb3c3360 
[1:1:0712/111114.238969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1722, 7f4fe3a26881
[1:1:0712/111114.300090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1710 0x7f4fe10e1070 0x393afb3c4ae0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.300305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1710 0x7f4fe10e1070 0x393afb3c4ae0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.300536:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.300864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111114.300993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.301330:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111114.301431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111114.301610:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1739
[1:1:0712/111114.301723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1739 0x7f4fe10e1070 0x393afb3c45e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1722 0x7f4fe10e1070 0x393afb3f0660 
[1:1:0712/111114.302413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1726, 7f4fe3a268db
[1:1:0712/111114.324405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1709 0x7f4fe10e1070 0x393afb3ca0e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.324594:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1709 0x7f4fe10e1070 0x393afb3ca0e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.324817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1742
[1:1:0712/111114.324931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1742 0x7f4fe10e1070 0x393afb4077e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1726 0x7f4fe10e1070 0x393afb48dc60 
[1:1:0712/111114.325153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.325455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111114.325561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.372992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1736, 7f4fe3a26881
[1:1:0712/111114.438363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1719 0x7f4fe10e1070 0x393afb3c3360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.438692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1719 0x7f4fe10e1070 0x393afb3c3360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.439094:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.439657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111114.439838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.440534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111114.440696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111114.441064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1747
[1:1:0712/111114.441261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1747 0x7f4fe10e1070 0x393afb497660 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1736 0x7f4fe10e1070 0x393afb3f3160 
[1:1:0712/111114.710813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1742, 7f4fe3a268db
[1:1:0712/111114.779168:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1726 0x7f4fe10e1070 0x393afb48dc60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.779459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1726 0x7f4fe10e1070 0x393afb48dc60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.779872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1758
[1:1:0712/111114.780111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1758 0x7f4fe10e1070 0x393afac3df60 , 5:3_http://newhouse.yc.house365.com/, 0, , 1742 0x7f4fe10e1070 0x393afb4077e0 
[1:1:0712/111114.780458:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.780988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111114.781192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.788783:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1739, 7f4fe3a26881
[1:1:0712/111114.854853:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1722 0x7f4fe10e1070 0x393afb3f0660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.855222:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1722 0x7f4fe10e1070 0x393afb3f0660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111114.855603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111114.856176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111114.856374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111114.857036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111114.857248:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111114.857645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1761
[1:1:0712/111114.857841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1761 0x7f4fe10e1070 0x393afb35b660 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1739 0x7f4fe10e1070 0x393afb3c45e0 
[1:1:0712/111114.939974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1747, 7f4fe3a26881
[1:1:0712/111115.002849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1736 0x7f4fe10e1070 0x393afb3f3160 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.003202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1736 0x7f4fe10e1070 0x393afb3f3160 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.003567:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111115.004092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111115.004346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111115.004985:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111115.005157:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111115.005498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1766
[1:1:0712/111115.005682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1766 0x7f4fe10e1070 0x393af86e72e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1747 0x7f4fe10e1070 0x393afb497660 
[1:1:0712/111115.405907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1761, 7f4fe3a26881
[1:1:0712/111115.474140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1739 0x7f4fe10e1070 0x393afb3c45e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.474494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1739 0x7f4fe10e1070 0x393afb3c45e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.474861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111115.475431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111115.475625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111115.476333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111115.476499:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111115.476847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1780
[1:1:0712/111115.477106:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1780 0x7f4fe10e1070 0x393afb400b60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1761 0x7f4fe10e1070 0x393afb35b660 
[1:1:0712/111115.479016:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1758, 7f4fe3a268db
[1:1:0712/111115.545457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1742 0x7f4fe10e1070 0x393afb4077e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.545763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1742 0x7f4fe10e1070 0x393afb4077e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.546170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1783
[1:1:0712/111115.546389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1783 0x7f4fe10e1070 0x393afac3d660 , 5:3_http://newhouse.yc.house365.com/, 0, , 1758 0x7f4fe10e1070 0x393afac3df60 
[1:1:0712/111115.546747:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111115.547302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111115.547485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111115.738160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1766, 7f4fe3a26881
[1:1:0712/111115.801455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1747 0x7f4fe10e1070 0x393afb497660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.801831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1747 0x7f4fe10e1070 0x393afb497660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.802215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111115.802911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111115.803145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111115.804036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111115.804247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111115.804811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1792
[1:1:0712/111115.805082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1792 0x7f4fe10e1070 0x393afa636e60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1766 0x7f4fe10e1070 0x393af86e72e0 
[1:1:0712/111115.863368:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1783, 7f4fe3a268db
[1:1:0712/111115.895670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1758 0x7f4fe10e1070 0x393afac3df60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.895891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1758 0x7f4fe10e1070 0x393afac3df60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111115.896149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1798
[1:1:0712/111115.896267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1798 0x7f4fe10e1070 0x393afb3ba9e0 , 5:3_http://newhouse.yc.house365.com/, 0, , 1783 0x7f4fe10e1070 0x393afac3d660 
[1:1:0712/111115.896487:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111115.896810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111115.896921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111115.976784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1780, 7f4fe3a26881
[1:1:0712/111116.029252:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1761 0x7f4fe10e1070 0x393afb35b660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.029612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1761 0x7f4fe10e1070 0x393afb35b660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.029982:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.030595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111116.030821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.031681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111116.031894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111116.032411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1801
[1:1:0712/111116.032694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1801 0x7f4fe10e1070 0x393afb42e6e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1780 0x7f4fe10e1070 0x393afb400b60 
[1:1:0712/111116.071693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1792, 7f4fe3a26881
[1:1:0712/111116.124004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1766 0x7f4fe10e1070 0x393af86e72e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.124608:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1766 0x7f4fe10e1070 0x393af86e72e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.124936:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.125286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111116.125430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.125781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111116.125882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111116.126061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1805
[1:1:0712/111116.126170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1805 0x7f4fe10e1070 0x393afb4da360 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1792 0x7f4fe10e1070 0x393afa636e60 
[1:1:0712/111116.126995:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1798, 7f4fe3a268db
[1:1:0712/111116.205144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1783 0x7f4fe10e1070 0x393afac3d660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.205368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1783 0x7f4fe10e1070 0x393afac3d660 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.205652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1808
[1:1:0712/111116.205786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1808 0x7f4fe10e1070 0x393afb3ba560 , 5:3_http://newhouse.yc.house365.com/, 0, , 1798 0x7f4fe10e1070 0x393afb3ba9e0 
[1:1:0712/111116.205977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.206288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111116.206444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.317226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1801, 7f4fe3a26881
[1:1:0712/111116.388701:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1780 0x7f4fe10e1070 0x393afb400b60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.389126:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1780 0x7f4fe10e1070 0x393afb400b60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.389607:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.390297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111116.390544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.391407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111116.391632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111116.392081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1816
[1:1:0712/111116.392330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1816 0x7f4fe10e1070 0x393afac28e60 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1801 0x7f4fe10e1070 0x393afb42e6e0 
[1:1:0712/111116.394908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1805, 7f4fe3a26881
[1:1:0712/111116.473400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1792 0x7f4fe10e1070 0x393afa636e60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.473762:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1792 0x7f4fe10e1070 0x393afa636e60 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.474135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.474714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111116.474899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.475632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111116.475864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111116.476458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1820
[1:1:0712/111116.476708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1820 0x7f4fe10e1070 0x393afb4cdee0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1805 0x7f4fe10e1070 0x393afb4da360 
[1:1:0712/111116.812626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1808, 7f4fe3a268db
[1:1:0712/111116.889552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1798 0x7f4fe10e1070 0x393afb3ba9e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.889869:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1798 0x7f4fe10e1070 0x393afb3ba9e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111116.890277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://newhouse.yc.house365.com/, 1830
[1:1:0712/111116.890472:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1830 0x7f4fe10e1070 0x393af7762160 , 5:3_http://newhouse.yc.house365.com/, 0, , 1808 0x7f4fe10e1070 0x393afb3ba560 
[1:1:0712/111116.890869:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111116.891408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , play, (){
    $(".peek-a-boo").removeClass("peek"+(i-1)).addClass("peek"+i);
    if(i<=19){
      i++;
[1:1:0712/111116.891688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111116.986930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1816, 7f4fe3a26881
[1:1:0712/111117.073155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1801 0x7f4fe10e1070 0x393afb42e6e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111117.073581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1801 0x7f4fe10e1070 0x393afb42e6e0 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111117.074069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111117.074779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111117.075012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111117.075904:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111117.076116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111117.076570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1834
[1:1:0712/111117.076846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1834 0x7f4fe10e1070 0x393af7963760 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1816 0x7f4fe10e1070 0x393afac28e60 
[1:1:0712/111117.079286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1820, 7f4fe3a26881
[1:1:0712/111117.166393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1be4def62860","ptid":"1805 0x7f4fe10e1070 0x393afb4da360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111117.166831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.yc.house365.com/","ptid":"1805 0x7f4fe10e1070 0x393afb4da360 ","rf":"5:3_http://newhouse.yc.house365.com/"}
[1:1:0712/111117.167291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.yc.house365.com/"
[1:1:0712/111117.168021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.yc.house365.com/, 1be4def62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/111117.168255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.yc.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111117.169136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3c986ea229c8, 0x393af774e950
[1:1:0712/111117.169340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.yc.house365.com/", 100
[1:1:0712/111117.169803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.yc.house365.com/, 1837
[1:1:0712/111117.170055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1837 0x7f4fe10e1070 0x393afb35b0e0 , 5:3_http://newhouse.yc.house365.com/, 1, -5:3_http://newhouse.yc.house365.com/, 1820 0x7f4fe10e1070 0x393afb4cdee0 
