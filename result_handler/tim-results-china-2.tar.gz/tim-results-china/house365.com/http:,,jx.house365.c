[0712/111503.365697:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111503.366136:INFO:switcher_clone.cc(787)] backtrace rip is 7fa390743891
[0712/111504.305662:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111504.307808:INFO:switcher_clone.cc(787)] backtrace rip is 7f8e7708b891
[1:1:0712/111504.319762:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111504.320108:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111504.325457:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[129779:129779:0712/111505.562985:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c454ec92-f56a-4bbd-a9f1-17be0987b3ac
[0712/111505.814007:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111505.814314:INFO:switcher_clone.cc(787)] backtrace rip is 7f3ec94f2891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[129810:129810:0712/111506.012831:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129810
[129823:129823:0712/111506.013328:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=129823
[129779:129779:0712/111506.056647:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[129779:129808:0712/111506.057316:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111506.057600:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111506.057858:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111506.058486:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111506.058778:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111506.061943:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x22f4896e, 1
[1:1:0712/111506.062345:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x5d05957, 0
[1:1:0712/111506.062598:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x21a5e8f7, 3
[1:1:0712/111506.062884:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x32c1e82a, 2
[1:1:0712/111506.063134:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5759ffffffd005 6effffff89fffffff422 2affffffe8ffffffc132 fffffff7ffffffe8ffffffa521 , 10104, 4
[1:1:0712/111506.064625:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129779:129808:0712/111506.064958:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGWY�n��"*��2��!�#`
[129779:129808:0712/111506.065031:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is WY�n��"*��2��!�ݖ#`
[1:1:0712/111506.064951:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e752c60a0, 3
[129779:129808:0712/111506.065424:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111506.065337:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e75451080, 2
[129779:129808:0712/111506.065527:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129831, 4, 5759d005 6e89f422 2ae8c132 f7e8a521 
[1:1:0712/111506.065580:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e5f114d20, -2
[1:1:0712/111506.084868:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111506.085749:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 32c1e82a
[1:1:0712/111506.086743:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 32c1e82a
[1:1:0712/111506.088335:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 32c1e82a
[1:1:0712/111506.089875:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.090061:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.090255:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.090461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.091088:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 32c1e82a
[1:1:0712/111506.091407:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e7708b7ba
[1:1:0712/111506.091631:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e77082def, 7f8e7708b77a, 7f8e7708d0cf
[1:1:0712/111506.095231:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 32c1e82a
[1:1:0712/111506.095413:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 32c1e82a
[1:1:0712/111506.095721:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 32c1e82a
[1:1:0712/111506.096372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.096528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.096631:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.096726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 32c1e82a
[1:1:0712/111506.097149:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 32c1e82a
[1:1:0712/111506.097303:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e7708b7ba
[1:1:0712/111506.097378:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e77082def, 7f8e7708b77a, 7f8e7708d0cf
[1:1:0712/111506.099480:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111506.099756:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111506.099847:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe39f905c8, 0x7ffe39f90548)
[1:1:0712/111506.114709:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111506.117265:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[129779:129803:0712/111506.627609:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[129779:129779:0712/111506.668507:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129779:129779:0712/111506.670143:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/111506.678320:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1aea37e92220
[1:1:0712/111506.678669:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[129779:129790:0712/111506.690691:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[129779:129779:0712/111506.690844:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[129779:129790:0712/111506.690828:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[129779:129779:0712/111506.690931:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[129779:129779:0712/111506.691071:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,129831, 4
[1:7:0712/111506.696319:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111507.209372:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[129779:129779:0712/111508.734284:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[129779:129779:0712/111508.734423:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111508.757764:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111508.761587:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111509.869154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111509.869533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111509.886177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111509.886511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111509.934936:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111510.147912:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111510.148242:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111510.594187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111510.602483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111510.602939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111510.636439:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111510.661853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111510.662337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111510.689308:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[129779:129779:0712/111510.692692:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111510.693292:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1aea37e90e20
[1:1:0712/111510.693590:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129779:129779:0712/111510.715219:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[129779:129779:0712/111510.746289:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[129779:129779:0712/111510.746446:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111510.790587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111511.797145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f8e60cef2e0 0x1aea3815c6e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111511.798657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111511.798938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111511.800433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[129779:129779:0712/111511.878427:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111511.880569:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1aea37e91820
[1:1:0712/111511.880776:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[129779:129779:0712/111511.886577:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111511.899161:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111511.899368:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[129779:129779:0712/111511.904223:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[129779:129779:0712/111511.916004:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129779:129779:0712/111511.917086:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129779:129779:0712/111511.923727:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[129779:129779:0712/111511.923851:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[129779:129779:0712/111511.923997:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,129831, 4
[129779:129790:0712/111511.924114:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[129779:129790:0712/111511.924201:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111511.926111:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111512.532120:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111513.090634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f8e60cef2e0 0x1aea38222a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111513.091656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111513.091920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111513.092698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111513.214604:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[129779:129779:0712/111513.218428:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[129779:129779:0712/111513.218485:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111513.602316:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[129779:129779:0712/111513.836689:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[129779:129808:0712/111513.837163:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111513.837444:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111513.837710:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111513.838207:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111513.838426:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111513.841533:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x17bd1ac4, 1
[1:1:0712/111513.841866:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1b73fd51, 0
[1:1:0712/111513.842051:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3d91721, 3
[1:1:0712/111513.842247:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2862d3ca, 2
[1:1:0712/111513.842456:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 51fffffffd731b ffffffc41affffffbd17 ffffffcaffffffd36228 2117ffffffd903 , 10104, 5
[1:1:0712/111513.843416:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[129779:129808:0712/111513.843684:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGQ�s����b(!�8&`
[129779:129808:0712/111513.843760:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Q�s����b(!�18&`
[129779:129808:0712/111513.843992:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 129874, 5, 51fd731b c41abd17 cad36228 2117d903 
[1:1:0712/111513.844338:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e752c60a0, 3
[1:1:0712/111513.844589:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e75451080, 2
[1:1:0712/111513.844814:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8e5f114d20, -2
[1:1:0712/111513.865245:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111513.865672:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2862d3ca
[1:1:0712/111513.866012:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2862d3ca
[1:1:0712/111513.866707:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2862d3ca
[1:1:0712/111513.868151:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.868466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.868686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.868905:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.869657:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2862d3ca
[1:1:0712/111513.869993:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e7708b7ba
[1:1:0712/111513.870189:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e77082def, 7f8e7708b77a, 7f8e7708d0cf
[1:1:0712/111513.876301:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2862d3ca
[1:1:0712/111513.876708:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2862d3ca
[1:1:0712/111513.877556:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2862d3ca
[1:1:0712/111513.879704:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.879996:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.880240:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.880586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2862d3ca
[1:1:0712/111513.881817:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2862d3ca
[1:1:0712/111513.882208:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8e7708b7ba
[1:1:0712/111513.882438:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8e77082def, 7f8e7708b77a, 7f8e7708d0cf
[1:1:0712/111513.887495:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111513.888037:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111513.888228:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe39f905c8, 0x7ffe39f90548)
[1:1:0712/111513.902078:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111513.905252:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111514.113478:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111514.113749:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111514.122687:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1aea37e57220
[1:1:0712/111514.122916:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[129779:129779:0712/111514.435523:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[129779:129779:0712/111514.441144:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[129779:129790:0712/111514.480296:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[129779:129790:0712/111514.480401:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[129779:129779:0712/111514.480916:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://jx.house365.com/
[129779:129779:0712/111514.481015:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jx.house365.com/, http://jx.house365.com/, 1
[129779:129779:0712/111514.481172:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://jx.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:15:14 GMT Content-Type: text/html; charset=gb2312 Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 18:11:12 GMT Vary: Accept-Encoding ETag: W/"5d28cd40-1e18e" Content-Encoding: gzip  ,129874, 5
[1:7:0712/111514.484812:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111514.517863:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://jx.house365.com/
[1:1:0712/111514.538726:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111514.544472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0fc14ca0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111514.544885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111514.554478:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[129779:129779:0712/111514.696824:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://jx.house365.com/, http://jx.house365.com/, 1
[129779:129779:0712/111514.696960:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://jx.house365.com/, http://jx.house365.com
[1:1:0712/111514.717941:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111514.723850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111514.724623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0fc14c8e1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111514.724862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111514.804765:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111514.882475:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111514.925854:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111514.926143:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111516.001727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.004839:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.015642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/111516.015980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
[1:1:0712/111516.096356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.096935:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.100329:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.100838:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.101253:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111516.222062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.233242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.242624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.252643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.260053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.281572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.290612:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.302215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 10000
[1:1:0712/111516.302740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 244
[1:1:0712/111516.303036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 244 0x7f8e5edc7070 0x1aea37fb95e0 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 202 0x7f8e5edc7070 0x1aea37f704e0 
[1:1:0712/111516.312352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.326128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.367760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.386057:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.482579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.490728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.502808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111516.505761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f8e5edc7070 0x1aea37f704e0 , "http://jx.house365.com/"
[1:1:0712/111518.494932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 325 0x7f8e75451080 0x1aea3828c420 1 0 0x1aea3828c438 , "http://jx.house365.com/"
[1:1:0712/111518.578709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111518.578999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
[1:1:0712/111521.355886:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111521.881884:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111521.882276:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111521.883360:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f8e5edc7070 0x1aea37f79660 , "http://jx.house365.com/"
[1:1:0712/111521.885119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 	$(function(){		var jqueryInputDom2 = '#keywords';		var searchUrl = 'http://transferapi.house365.com
[1:1:0712/111521.885380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
[1:1:0712/111521.894402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f8e5edc7070 0x1aea37f79660 , "http://jx.house365.com/"
[1:1:0712/111521.936163:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f8e5edc7070 0x1aea37f79660 , "http://jx.house365.com/"
[1:1:0712/111522.132252:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111522.132995:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111524.357227:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111524.951180:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111524.951477:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111524.957564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7f8e5edc7070 0x1aea38334060 , "http://jx.house365.com/"
[1:1:0712/111524.959328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111524.959573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
[1:1:0712/111524.966497:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7f8e5edc7070 0x1aea38334060 , "http://jx.house365.com/"
[1:1:0712/111525.043851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f8e75451080 0x1aea38545100 1 0 0x1aea38545118 , "http://jx.house365.com/"
[1:1:0712/111525.172705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111525.173051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
		remove user.10_4da73174 -> 0
		remove user.11_c7dc82ab -> 0
[1:1:0712/111525.299759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f8e75451080 0x1aea38545100 1 0 0x1aea38545118 , "http://jx.house365.com/"
[1:1:0712/111525.322963:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.023772, 115, 1
[1:1:0712/111525.323278:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111525.477088:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111525.477361:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111525.478207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f8e5edc7070 0x1aea38729ee0 , "http://jx.house365.com/"
[1:1:0712/111525.479198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
function normal13744(){
    document.write('<a href="http://ad.house365.com/api/ads/click?id=13744"
[1:1:0712/111525.479415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "jx.house365.com", 3, 1, , , 0
[1:1:0712/111525.493564:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111525.506444:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1aea37e55420
[1:1:0712/111525.506713:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111525.541606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f8e5edc7070 0x1aea38729ee0 , "http://jx.house365.com/"
[1:1:0712/111525.544629:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "jx.house365.com", "house365.com"
[1:1:0712/111525.610559:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.133144, 430, 1
[1:1:0712/111525.610842:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111526.362962:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111526.363265:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111526.368098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f8e5edc7070 0x1aea386fee60 , "http://jx.house365.com/"
[1:1:0712/111526.371051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
function QR8bitByte(a){
    this.mode=QRMode.MODE_8BIT_BYTE,
        this.data=a
}

function 
[1:1:0712/111526.371318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111526.382098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f8e5edc7070 0x1aea386fee60 , "http://jx.house365.com/"
[129779:129779:0712/111541.404818:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[129779:129779:0712/111541.411610:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[129779:129779:0712/111541.436848:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://jx.house365.com/, http://jx.house365.com/, 4
[129779:129779:0712/111541.437028:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://jx.house365.com/, http://jx.house365.com
[129779:129779:0712/111541.466540:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/111541.484183:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[129779:129779:0712/111541.626208:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/111544.539083:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 18.1757, 0, 0
[1:1:0712/111544.539340:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111544.826586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 244, 7f8e6170c881
[1:1:0712/111544.851181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"202 0x7f8e5edc7070 0x1aea37f704e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111544.851545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"202 0x7f8e5edc7070 0x1aea37f704e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111544.851973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111544.852879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , bigtosmall13872(2)
[1:1:0712/111544.853112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111545.499948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc8f5ec029c8, 0x1aea37c34170
[1:1:0712/111545.500244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 0
[1:1:0712/111545.500630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 590
[1:1:0712/111545.500886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 590 0x7f8e5edc7070 0x1aea3ad7bd60 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 244 0x7f8e5edc7070 0x1aea37fb95e0 
[1:1:0712/111545.572430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 13
[1:1:0712/111545.572893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 591
[1:1:0712/111545.573134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 591 0x7f8e5edc7070 0x1aea38e55e60 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 244 0x7f8e5edc7070 0x1aea37fb95e0 
[1:1:0712/111545.864737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111545.865057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111546.505611:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111546.505868:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111546.547443:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0415211, 239, 1
[1:1:0712/111546.547748:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111546.858320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 590, 7f8e6170c881
[1:1:0712/111546.867235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"244 0x7f8e5edc7070 0x1aea37fb95e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111546.867582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"244 0x7f8e5edc7070 0x1aea37fb95e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111546.868035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111546.868609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){$b=void 0}
[1:1:0712/111546.868825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111546.898124:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 591, 7f8e6170c8db
[1:1:0712/111546.925227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"244 0x7f8e5edc7070 0x1aea37fb95e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111546.925546:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"244 0x7f8e5edc7070 0x1aea37fb95e0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111546.925986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 634
[1:1:0712/111546.926227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f8e5edc7070 0x1aea3b7bc860 , 5:3_http://jx.house365.com/, 0, , 591 0x7f8e5edc7070 0x1aea38e55e60 
[1:1:0712/111546.926548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111546.927073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111546.927335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111547.023956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111547.024294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111548.567104:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111548.567426:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111548.568444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7f8e5edc7070 0x1aea3d4c56e0 , "http://jx.house365.com/"
[1:1:0712/111548.569427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
		
function normal13876(){
    document.write('<a href="http://ad.house365.com/api/ads/click?id=138
[1:1:0712/111548.569700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111548.600740:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0332439, 238, 1
[1:1:0712/111548.601111:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111548.677995:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://jx.house365.com/"
[1:1:0712/111548.680140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111548.680432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111549.297264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111549.297569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111552.090794:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111552.091072:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111552.114869:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.023705, 155, 1
[1:1:0712/111552.115147:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111552.785286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111552.785647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111553.718533:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111553.718828:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111553.719807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7f8e5edc7070 0x1aea3a67f560 , "http://jx.house365.com/"
[1:1:0712/111553.720826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
						$(function(){
							$("#xfzx_right_lp .newhouseSItem").click(function(){
								$(this).add
[1:1:0712/111553.721069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111553.799650:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.08077, 744, 1
[1:1:0712/111553.799956:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111554.295007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111554.295335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111555.302573:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111555.302875:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111555.316803:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.013865, 217, 1
[1:1:0712/111555.317152:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111555.656117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111555.656423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111556.995746:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111556.996017:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111556.996972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 837 0x7f8e5edc7070 0x1aea393ab7e0 , "http://jx.house365.com/"
[1:1:0712/111556.997928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
			var flag_esf_tag = true;
					
[1:1:0712/111556.998209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111557.027396:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0313852, 214, 1
[1:1:0712/111557.027795:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111557.186906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111557.187251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111558.326320:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111558.326497:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111558.327119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 878 0x7f8e5edc7070 0x1aea3fb1c6e0 , "http://jx.house365.com/"
[1:1:0712/111558.327649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
		var flag_zf_tag = true;
			
[1:1:0712/111558.327793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111558.341706:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0152919, 79, 1
[1:1:0712/111558.341982:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111558.612755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111558.613023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111559.309749:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111559.310085:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://jx.house365.com/"
[1:1:0712/111559.314522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 904 0x7f8e5edc7070 0x1aea41571f60 , "http://jx.house365.com/"
[1:1:0712/111559.316067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.write("<div class=\"w10000\">	<div class=\"pt45 pb45 bg484848\">		<div class=\"margin_auto_
[1:1:0712/111559.316372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111559.350336:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 904 0x7f8e5edc7070 0x1aea41571f60 , "http://jx.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111559.500300:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111559.507372:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1aea414eaa20
[1:1:0712/111559.507679:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[129779:129779:0712/111559.508333:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[129779:129779:0712/111559.514889:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[129779:129779:0712/111559.546951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://jx.house365.com/, http://jx.house365.com/, 5
[129779:129779:0712/111559.547062:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://jx.house365.com/, http://jx.house365.com
[1:1:0712/111559.818856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111559.819152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111602.013361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111602.013668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111603.343416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111603.344945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , $(".first-screen-switch").slide({titCell:".hd ul",mainCell:".bd",autoPage:true,autoPlay:true});
$(".
[1:1:0712/111603.345247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[129779:129779:0712/111603.369184:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111603.541832:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111603.967833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc8f5ec029c8, 0x1aea37c341b8
[1:1:0712/111603.968136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 0
[1:1:0712/111603.968570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1037
[1:1:0712/111603.968809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7f8e5edc7070 0x1aea41b5c4e0 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1000 0x7f8e5edc7070 0x1aea41af3760 
[1:1:0712/111604.044107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 2500
[1:1:0712/111604.044419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1038
[1:1:0712/111604.044537:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1038 0x7f8e5edc7070 0x1aea41be1ee0 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1000 0x7f8e5edc7070 0x1aea41af3760 
[1:1:0712/111604.240442:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111604.240885:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111604.950783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.959760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.964010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.968196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.971804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.975698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111604.977918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111605.009026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f8e5edc7070 0x1aea41af3760 , "http://jx.house365.com/"
[1:1:0712/111605.442907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111605.443164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111607.350358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1037, 7f8e6170c881
[1:1:0712/111607.388884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1000 0x7f8e5edc7070 0x1aea41af3760 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111607.389314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1000 0x7f8e5edc7070 0x1aea41af3760 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111607.389757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111607.390390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){$b=void 0}
[1:1:0712/111607.390616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111607.545083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067, "http://jx.house365.com/"
[1:1:0712/111607.549613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (function(){
	var parameters = {
			'guid'  : 'new_guid',
			'todayfirst' : 'new_todayfirst',
		
[1:1:0712/111607.549972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111608.093083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111608.093364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111609.318969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1038, 7f8e6170c8db
[1:1:0712/111609.351784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1000 0x7f8e5edc7070 0x1aea41af3760 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111609.352211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1000 0x7f8e5edc7070 0x1aea41af3760 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111609.352785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1173
[1:1:0712/111609.353038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7f8e5edc7070 0x1aea42516b60 , 5:3_http://jx.house365.com/, 0, , 1038 0x7f8e5edc7070 0x1aea41be1ee0 
[1:1:0712/111609.353536:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111609.354140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){w?p--:p++,ab()}
[1:1:0712/111609.354367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111609.507232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc8f5ec029c8, 0x1aea37c34150
[1:1:0712/111609.507413:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 0
[1:1:0712/111609.507633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1174
[1:1:0712/111609.507762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f8e5edc7070 0x1aea41a49260 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1038 0x7f8e5edc7070 0x1aea41be1ee0 
[1:1:0712/111609.525594:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 13
[1:1:0712/111609.525873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1176
[1:1:0712/111609.525991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f8e5edc7070 0x1aea417c6460 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1038 0x7f8e5edc7070 0x1aea41be1ee0 
[1:1:0712/111611.044927:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1139, "http://jx.house365.com/"
[1:1:0712/111611.045959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
[1:1:0712/111611.046204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111611.049514:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1139, "http://jx.house365.com/"
[1:1:0712/111611.053392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1139, "http://jx.house365.com/"
[1:1:0712/111611.059990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1139, "http://jx.house365.com/"
[1:1:0712/111611.535833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111611.536071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111612.462584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1174, 7f8e6170c881
[1:1:0712/111612.518973:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111612.519211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111612.519461:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111612.519806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){$b=void 0}
[1:1:0712/111612.519939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111612.520521:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1176, 7f8e6170c8db
[1:1:0712/111612.566104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111612.566562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111612.567151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1266
[1:1:0712/111612.567453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1266 0x7f8e5edc7070 0x1aea3d0a1ce0 , 5:3_http://jx.house365.com/, 0, , 1176 0x7f8e5edc7070 0x1aea417c6460 
[1:1:0712/111612.567921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111612.568620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111612.568889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111614.698587:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1230, "http://jx.house365.com/"
[1:1:0712/111614.699121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , 
[1:1:0712/111614.699235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111614.700225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1230, "http://jx.house365.com/"
[1:1:0712/111614.704246:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1230, "http://jx.house365.com/"
[1:1:0712/111614.706840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1230, "http://jx.house365.com/"
[1:1:0712/111614.707437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1230, "http://jx.house365.com/"
[1:1:0712/111615.039930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.readyState
[1:1:0712/111615.040175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111615.154455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1173, 7f8e6170c8db
[1:1:0712/111615.210720:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111615.211032:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1038 0x7f8e5edc7070 0x1aea41be1ee0 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111615.211420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1314
[1:1:0712/111615.211612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7f8e5edc7070 0x1aea426391e0 , 5:3_http://jx.house365.com/, 0, , 1173 0x7f8e5edc7070 0x1aea42516b60 
[1:1:0712/111615.211974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111615.212460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){w?p--:p++,ab()}
[1:1:0712/111615.212648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111615.298116:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc8f5ec029c8, 0x1aea37c34150
[1:1:0712/111615.298307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 0
[1:1:0712/111615.298524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1315
[1:1:0712/111615.298642:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1315 0x7f8e5edc7070 0x1aea3a5d9c60 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1173 0x7f8e5edc7070 0x1aea42516b60 
[1:1:0712/111615.315792:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 13
[1:1:0712/111615.316307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1316
[1:1:0712/111615.316437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7f8e5edc7070 0x1aea41200160 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1173 0x7f8e5edc7070 0x1aea42516b60 
[1:1:0712/111616.325575:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1290 0x7f8e60cef2e0 0x1aea4234fde0 , "http://jx.house365.com/"
[1:1:0712/111616.334864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , var conf_ga_public_code = "UA-35147609-1";

var conf_ga_city = new Array();
conf_ga_city["nj"] = "�
[1:1:0712/111616.335061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111616.348888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xc8f5ec029c8, 0x1aea37c341a0
[1:1:0712/111616.349104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://jx.house365.com/", 5000
[1:1:0712/111616.349358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1333
[1:1:0712/111616.349527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7f8e5edc7070 0x1aea42377be0 , 5:3_http://jx.house365.com/, 1, -5:3_http://jx.house365.com/, 1290 0x7f8e60cef2e0 0x1aea4234fde0 
[1:1:0712/111616.906599:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1303, "http://jx.house365.com/"
[1:1:0712/111616.907308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , document.domain="house365.com";
document.write('<link rel="stylesheet" href="http://pic.house365.co
[1:1:0712/111616.907434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111616.907718:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "house365.com", "house365.com"
[1:1:0712/111617.280538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://jx.house365.com/, 1315, 7f8e6170c881
[1:1:0712/111617.300004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1173 0x7f8e5edc7070 0x1aea42516b60 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111617.300211:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1173 0x7f8e5edc7070 0x1aea42516b60 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111617.300471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111617.300783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , , (){$b=void 0}
[1:1:0712/111617.300894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/111617.301299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1316, 7f8e6170c8db
[1:1:0712/111617.320929:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27a5be602860","ptid":"1173 0x7f8e5edc7070 0x1aea42516b60 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111617.321148:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://jx.house365.com/","ptid":"1173 0x7f8e5edc7070 0x1aea42516b60 ","rf":"5:3_http://jx.house365.com/"}
[1:1:0712/111617.321404:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://jx.house365.com/, 1365
[1:1:0712/111617.321528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1365 0x7f8e5edc7070 0x1aea3d8681e0 , 5:3_http://jx.house365.com/, 0, , 1316 0x7f8e5edc7070 0x1aea41200160 
[1:1:0712/111617.321727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://jx.house365.com/"
[1:1:0712/111617.322029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://jx.house365.com/, 27a5be602860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/111617.322141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://jx.house365.com/", "house365.com", 3, 1, , , 0
