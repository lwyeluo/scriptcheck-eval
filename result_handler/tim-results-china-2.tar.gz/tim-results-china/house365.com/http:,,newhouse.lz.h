[0712/112159.856605:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112159.857051:INFO:switcher_clone.cc(787)] backtrace rip is 7f20ed6a2891
[0712/112200.859695:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112200.860252:INFO:switcher_clone.cc(787)] backtrace rip is 7f4fef7ab891
[1:1:0712/112200.874576:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/112200.874913:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/112200.880701:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[130563:130563:0712/112202.291562:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/112202.323368:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/112202.323895:INFO:switcher_clone.cc(787)] backtrace rip is 7fe603761891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bd19b807-28fe-453d-b254-b688479d9b6c
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[130596:130596:0712/112202.569632:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130596
[130608:130608:0712/112202.570015:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130608
[130563:130563:0712/112202.770758:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[130563:130593:0712/112202.771413:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/112202.771659:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112202.771886:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112202.772453:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112202.772657:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/112202.775997:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x113356d4, 1
[1:1:0712/112202.776367:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21755a87, 0
[1:1:0712/112202.776579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2f2faea6, 3
[1:1:0712/112202.776779:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x867ca39, 2
[1:1:0712/112202.777023:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff875a7521 ffffffd4563311 39ffffffca6708 ffffffa6ffffffae2f2f , 10104, 4
[1:1:0712/112202.778046:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130563:130593:0712/112202.778361:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Zu!�V39�g��//��
[130563:130593:0712/112202.778472:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Zu!�V39�g��//�o��
[1:1:0712/112202.778652:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fed9e60a0, 3
[130563:130593:0712/112202.778896:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[130563:130593:0712/112202.778987:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130616, 4, 875a7521 d4563311 39ca6708 a6ae2f2f 
[1:1:0712/112202.778926:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fedb71080, 2
[1:1:0712/112202.779168:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fd7834d20, -2
[1:1:0712/112202.803085:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112202.804212:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 867ca39
[1:1:0712/112202.805410:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 867ca39
[1:1:0712/112202.807416:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 867ca39
[1:1:0712/112202.808048:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.808170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.808263:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.808367:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.808614:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 867ca39
[1:1:0712/112202.808762:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4fef7ab7ba
[1:1:0712/112202.808840:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4fef7a2def, 7f4fef7ab77a, 7f4fef7ad0cf
[1:1:0712/112202.810229:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 867ca39
[1:1:0712/112202.810389:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 867ca39
[1:1:0712/112202.810681:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 867ca39
[1:1:0712/112202.811410:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.811564:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.811701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.811795:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 867ca39
[1:1:0712/112202.812241:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 867ca39
[1:1:0712/112202.812400:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4fef7ab7ba
[1:1:0712/112202.812473:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4fef7a2def, 7f4fef7ab77a, 7f4fef7ad0cf
[1:1:0712/112202.814583:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112202.814856:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112202.814946:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdd7f47068, 0x7ffdd7f46fe8)
[1:1:0712/112202.830226:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112202.836556:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[130563:130563:0712/112203.361326:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130563:130563:0712/112203.362538:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130563:130575:0712/112203.380653:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[130563:130575:0712/112203.380800:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[130563:130563:0712/112203.380988:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[130563:130563:0712/112203.381092:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[130563:130563:0712/112203.381291:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,130616, 4
[1:7:0712/112203.386853:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[130563:130586:0712/112203.461221:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/112203.491688:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3385ff7c5220
[1:1:0712/112203.492091:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/112203.863873:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[130563:130563:0712/112206.068409:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[130563:130563:0712/112206.068558:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112206.115000:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112206.118628:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112206.695355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112206.695728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112206.709734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/112206.709968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112206.752402:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112206.968404:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112206.968691:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112207.338233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112207.346381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112207.346663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112207.413507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112207.424060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/112207.424313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112207.436119:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[130563:130563:0712/112207.438520:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112207.439482:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3385ff7c3e20
[1:1:0712/112207.439741:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[130563:130563:0712/112207.445416:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[130563:130563:0712/112207.462894:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[130563:130563:0712/112207.463051:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/112207.522505:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112208.556139:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f4fd940f2e0 0x3385ffa53ce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112208.557503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/112208.557722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112208.559194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130563:130563:0712/112208.637804:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/112208.640099:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3385ff7c4820
[1:1:0712/112208.640308:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[130563:130563:0712/112208.644592:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/112208.647260:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/112208.647403:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[130563:130563:0712/112208.662206:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[130563:130563:0712/112208.673613:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130563:130563:0712/112208.674614:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130563:130575:0712/112208.680749:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[130563:130563:0712/112208.680854:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[130563:130575:0712/112208.680842:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[130563:130563:0712/112208.680963:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[130563:130563:0712/112208.681101:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,130616, 4
[1:7:0712/112208.682812:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112209.145739:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/112209.802982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f4fd940f2e0 0x3385ff9d02e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112209.804040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/112209.804342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112209.805112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130563:130563:0712/112209.904292:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[130563:130563:0712/112209.904442:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/112209.938047:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112210.519260:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[130563:130563:0712/112210.757452:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[130563:130593:0712/112210.757802:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/112210.757935:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/112210.758155:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/112210.758461:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/112210.758611:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/112210.761875:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e5dd22d, 1
[1:1:0712/112210.762287:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xaf36b6b, 0
[1:1:0712/112210.762529:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31fed6f0, 3
[1:1:0712/112210.762750:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x216ad02d, 2
[1:1:0712/112210.762956:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6b6bfffffff30a 2dffffffd25d1e 2dffffffd06a21 fffffff0ffffffd6fffffffe31 , 10104, 5
[1:1:0712/112210.763964:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130563:130593:0712/112210.764260:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGkk�
-�]-�j!���1."�
[130563:130593:0712/112210.764329:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is kk�
-�]-�j!���1."�
[1:1:0712/112210.764456:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fed9e60a0, 3
[1:1:0712/112210.764710:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fedb71080, 2
[1:1:0712/112210.764939:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4fd7834d20, -2
[130563:130593:0712/112210.765843:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130660, 5, 6b6bf30a 2dd25d1e 2dd06a21 f0d6fe31 
[1:1:0712/112210.797182:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/112210.797637:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 216ad02d
[1:1:0712/112210.798000:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 216ad02d
[1:1:0712/112210.798704:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 216ad02d
[1:1:0712/112210.800420:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.800745:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.800978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.801207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.802100:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 216ad02d
[1:1:0712/112210.802469:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4fef7ab7ba
[1:1:0712/112210.802659:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4fef7a2def, 7f4fef7ab77a, 7f4fef7ad0cf
[1:1:0712/112210.809866:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 216ad02d
[1:1:0712/112210.810311:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 216ad02d
[1:1:0712/112210.810860:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 216ad02d
[1:1:0712/112210.813273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.813569:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.813814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.814060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 216ad02d
[1:1:0712/112210.815418:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 216ad02d
[1:1:0712/112210.815895:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4fef7ab7ba
[1:1:0712/112210.816084:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4fef7a2def, 7f4fef7ab77a, 7f4fef7ad0cf
[1:1:0712/112210.827256:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/112210.827967:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/112210.828182:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdd7f47068, 0x7ffdd7f46fe8)
[1:1:0712/112210.842609:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/112210.847243:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/112211.081656:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3385ff783220
[1:1:0712/112211.081923:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/112211.104809:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112211.105056:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112211.757219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112211.764235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 03e0e9dae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/112211.765011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112211.772642:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[130563:130563:0712/112211.775345:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130563:130563:0712/112211.777921:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130563:130575:0712/112211.814805:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[130563:130575:0712/112211.814907:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[130563:130563:0712/112211.815296:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.lz.house365.com/
[130563:130563:0712/112211.815378:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.lz.house365.com/, http://newhouse.lz.house365.com/, 1
[130563:130563:0712/112211.815511:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.lz.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:22:11 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=bc09s5h24ov9stdkgeeivnqp83; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,130660, 5
[1:7:0712/112211.819076:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/112211.832928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/112211.833762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 03e0e9c81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/112211.834054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/112211.846473:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.lz.house365.com/
[130563:130563:0712/112212.007015:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.lz.house365.com/, http://newhouse.lz.house365.com/, 1
[130563:130563:0712/112212.007083:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.lz.house365.com/, http://newhouse.lz.house365.com
[1:1:0712/112212.053117:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112212.111342:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112212.177014:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/112212.207061:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112212.207326:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112212.213087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112212.214820:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/112212.215069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 03e0e9dae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/112212.215365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112212.359866:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/112212.360824:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/112212.361076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 03e0e9dae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/112212.361362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/112213.010735:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112213.526157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112213.542064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/112213.542345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "newhouse.lz.house365.com", 3, 1, , , 0
[1:1:0712/112213.544379:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112213.851959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112213.910891:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112214.064422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112214.066483:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.lz.house365.com", "house365.com"
[1:1:0712/112214.074254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112214.079284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112214.085373:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 208 0x7f4fd784fbd0 0x3385ff9251d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112215.321575:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288, "http://newhouse.lz.house365.com/"
[1:1:0712/112215.323316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/112215.323573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112216.005504:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112216.537451:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112216.537739:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112216.665525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 349 0x7f4fd784fbd0 0x3385ff8885d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112216.687221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/112216.687435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112216.846269:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0280161, 144, 1
[1:1:0712/112216.846585:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112216.910269:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112216.910446:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112216.910868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f4fd74e7070 0x3385ff9783e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112216.911604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/112216.911725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112216.929958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f4fd74e7070 0x3385ff9783e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112217.184396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377, "http://newhouse.lz.house365.com/"
[1:1:0712/112217.185881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/112217.186041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112217.546461:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112217.865855:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112217.866096:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112217.869052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7f4fd74e7070 0x3385ff792060 , "http://newhouse.lz.house365.com/"
[1:1:0712/112217.877539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/112217.877789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112218.005307:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.139091, 52, 1
[1:1:0712/112218.005546:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112218.187216:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112218.187395:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112218.187814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7f4fd74e7070 0x3385ff8e57e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112218.188443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/112218.188560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112218.422772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7f4fd784fbd0 0x3386001f60d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112218.442304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/112218.442633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112219.964995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7f4fd784fbd0 0x3386001f60d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112219.971739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7f4fd784fbd0 0x3386001f60d8 , "http://newhouse.lz.house365.com/"
[1:1:0712/112220.011415:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0527909, 159, 1
[1:1:0712/112220.011786:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112220.048703:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112220.049257:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112220.049597:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112220.050083:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112220.050508:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112220.293609:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112220.293886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112220.294802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f4fd74e7070 0x338600532860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112220.296491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/112220.296745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112220.318793:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f4fd74e7070 0x338600532860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112220.335495:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f4fd74e7070 0x338600532860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112220.379365:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f4fd74e7070 0x338600532860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112222.488972:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112222.940641:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112222.940954:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112222.943312:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f4fd74e7070 0x3385ff973860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112222.945074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/112222.945303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112222.953111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f4fd74e7070 0x3385ff973860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112222.963388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f4fd74e7070 0x3385ff973860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.182055:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112223.182636:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112223.239840:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f4fd74e7070 0x3385ff973860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.294204:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f4fd74e7070 0x3385ff973860 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.335840:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.394825, 232, 1
[1:1:0712/112223.336157:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112223.728145:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112223.728430:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112223.729370:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 505 0x7f4fd74e7070 0x3386001f64e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.731916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/112223.732161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112223.736221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 505 0x7f4fd74e7070 0x3386001f64e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.805878:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0773749, 317, 1
[1:1:0712/112223.806199:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112223.937094:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112223.937378:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112223.938262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 518 0x7f4fd74e7070 0x338600729760 , "http://newhouse.lz.house365.com/"
[1:1:0712/112223.939318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode231307_4").qrcode({
                                rend
[1:1:0712/112223.939536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_2ed224b7 -> 0
		remove user.11_8165542c -> 0
		remove user.12_6a9132e -> 0
		remove user.13_dae8967f -> 0
		remove user.14_a9d48dfd -> 0
		remove user.11_34df4c2f -> 0
		remove user.12_e23c184c -> 0
[130563:130563:0712/112237.155568:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/112237.158651:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/112243.799836:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.8624, 0, 0
[1:1:0712/112243.800135:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112243.940444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/112243.940634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112244.460543:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112244.460774:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112244.477419:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0165601, 69, 1
[1:1:0712/112244.477666:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112244.680549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112244.680803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112245.937593:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112245.937956:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112245.939107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 575 0x7f4fd74e7070 0x338603495ce0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112245.940394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode231307_2").qrcode({
                                rend
[1:1:0712/112245.940657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112249.583651:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.64549, 0, 0
[1:1:0712/112249.583880:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112249.656998:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112249.659177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112249.659423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112249.716810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112249.717088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112250.708621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112250.709562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112250.709813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112250.743162:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112250.743394:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112250.755476:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0119629, 77, 1
[1:1:0712/112250.755683:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112250.847550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112250.847810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112251.256320:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112251.256605:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112251.257847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 628 0x7f4fd74e7070 0x3385ff42ea60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112251.259230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode231307_1").qrcode({
                                rend
[1:1:0712/112251.259479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112251.541985:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.285224, 81, 1
[1:1:0712/112251.542246:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112251.584049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112251.584324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112251.776317:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112251.777259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112251.777501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112251.842519:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112251.842697:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112251.843291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645 0x7f4fd74e7070 0x3385ff465160 , "http://newhouse.lz.house365.com/"
[1:1:0712/112251.843919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode199097_1").qrcode({
                                rend
[1:1:0712/112251.844037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112252.150218:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.307577, 85, 1
[1:1:0712/112252.150482:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112252.185648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112252.185905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112252.603712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112252.604207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112252.604329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112252.682656:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112252.682885:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112252.683901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 662 0x7f4fd74e7070 0x33860173c6e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112252.684982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode199097_3").qrcode({
                                rend
[1:1:0712/112252.685203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112252.868889:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112252.869540:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112252.869874:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/112253.034400:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.351395, 85, 1
[1:1:0712/112253.034604:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112253.072903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112253.073102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112253.475743:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112253.476554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112253.476705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112253.517958:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112253.518131:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112253.518749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 681 0x7f4fd74e7070 0x3386094bad60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112253.519312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode231971_1").qrcode({
                                rend
[1:1:0712/112253.519423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112253.830668:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.31261, 77, 1
[1:1:0712/112253.830937:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112253.857205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112253.857406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112254.146630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112254.147192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112254.147321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112254.226072:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112254.226310:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112254.227307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 700 0x7f4fd74e7070 0x3386097e3b60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112254.228422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode231971_4").qrcode({
                                rend
[1:1:0712/112254.228631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112254.649687:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.42335, 85, 1
[1:1:0712/112254.650001:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112254.753717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112254.754031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112255.358893:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112255.359731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112255.360018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112255.448283:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112255.448608:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112255.449638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 722 0x7f4fd74e7070 0x338609cef260 , "http://newhouse.lz.house365.com/"
[1:1:0712/112255.450753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode202931_1").qrcode({
                                rend
[1:1:0712/112255.451008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112255.681871:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.233194, 73, 1
[1:1:0712/112255.682217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112255.751301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112255.751622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112256.088702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112256.089422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112256.089767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112256.171749:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112256.172014:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112256.173041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 742 0x7f4fd74e7070 0x3386094cc3e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112256.174375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode202779_1").qrcode({
                                rend
[1:1:0712/112256.174660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
		remove user.13_89e617ae -> 0
		remove user.14_2c21a334 -> 0
		remove user.15_6b476c67 -> 0
[1:1:0712/112256.517492:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.345369, 73, 1
[1:1:0712/112256.517791:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112256.572844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112256.573164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112256.902278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112256.903029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112256.903221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112256.996865:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112256.997049:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112256.997686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 760 0x7f4fd74e7070 0x3386089fbce0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112256.998330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode199125_4").qrcode({
                                rend
[1:1:0712/112256.998520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112257.346608:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.349571, 77, 1
[1:1:0712/112257.346831:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112257.430351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112257.430689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112257.862977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112257.863475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112257.863602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112257.935654:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112257.935950:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112257.936810:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 778 0x7f4fd74e7070 0x33860a314d60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112257.937658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode199125_1").qrcode({
                                rend
[1:1:0712/112257.937871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112258.096866:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.160887, 77, 1
[1:1:0712/112258.097127:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112258.172450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112258.172656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112258.500895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112258.501363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112258.501487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112258.562877:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112258.563063:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112258.563676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f4fd74e7070 0x33860a391c60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112258.564338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode199125_3").qrcode({
                                rend
[1:1:0712/112258.564483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112258.670557:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.107492, 77, 1
[1:1:0712/112258.670748:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112258.698195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112258.698426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112258.945026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112258.945487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112258.945611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112259.046849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112259.047120:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112259.048146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 814 0x7f4fd74e7070 0x33860a6c6d60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112259.049389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode250113_3").qrcode({
                                rend
[1:1:0712/112259.049602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112259.283944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.236732, 69, 1
[1:1:0712/112259.284244:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112259.388111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112259.388456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[130563:130563:0712/112259.393935:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/112259.900176:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112259.900963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112259.901168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112300.013128:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112300.013390:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112300.014378:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 830 0x7f4fd74e7070 0x33860a658ae0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112300.015864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode252898_1").qrcode({
                                rend
[1:1:0712/112300.016160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112300.266334:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.252813, 77, 1
[1:1:0712/112300.266527:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112300.293409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112300.293632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112300.765251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112300.766162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112300.766414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112300.891297:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112300.891558:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112300.892510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 851 0x7f4fd74e7070 0x33860a6603e0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112300.893250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
                            $("#lptelqrcode235913_1").qrcode({
                                rend
[1:1:0712/112300.893410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112301.084085:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.192436, 54, 1
[1:1:0712/112301.084329:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112301.159654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112301.159873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112301.485844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.lz.house365.com/"
[1:1:0712/112301.486792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/112301.487030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112301.542545:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112301.542734:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112301.543323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 869 0x7f4fd74e7070 0x33860a9e9fe0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112301.543929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
listCondition.p=1;
var totalpage=23;

[1:1:0712/112301.544079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112301.574707:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.032033, 404, 1
[1:1:0712/112301.574969:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112301.605447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112301.605672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112302.704572:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112302.704909:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112302.705915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.707477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , 
    $(function(){
        $(".hotslide").on("click",function(){
            if($(this).children("im
[1:1:0712/112302.707881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112302.713477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.719237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.731427:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.923667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.930884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.941314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112302.958530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.044269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.056819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.084751:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.091167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.162596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.166388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.174604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.180252:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7f4fd74e7070 0x33860a895460 , "http://newhouse.lz.house365.com/"
[1:1:0712/112303.210417:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.505387, 1, 0
[1:1:0712/112303.210698:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112303.283115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112303.283497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112306.549517:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112306.549838:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112306.553626:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 961 0x7f4fd74e7070 0x33860ac1bd60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112306.554614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.write("<script>var accid =\"qlt_573\";</script><script src=\"http://pic.house365.com/im_sho
[1:1:0712/112306.554901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112306.555959:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 961 0x7f4fd74e7070 0x33860ac1bd60 , "http://newhouse.lz.house365.com/"
[1:1:0712/112306.656534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112306.656885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/112308.393677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012, "http://newhouse.lz.house365.com/"
[1:1:0712/112308.395668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.writeln("<style>");
document.writeln("@keyframes jumping{");
document.writeln("	0%{");
d
[1:1:0712/112308.395944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112308.431296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012, "http://newhouse.lz.house365.com/"
[130563:130563:0712/112308.443748:INFO:CONSOLE(2160)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8461be6dabbba234458468c863f484bf, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.lz.house365.com/ (2160)
[130563:130563:0712/112308.451901:INFO:CONSOLE(2160)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?8461be6dabbba234458468c863f484bf, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.lz.house365.com/ (2160)
[1:1:0712/112308.511722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112308.512118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112309.752267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , document.readyState
[1:1:0712/112309.752613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112310.769865:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1085 0x7f4fd784fbd0 0x3386083b5758 , "http://newhouse.lz.house365.com/"
[1:1:0712/112310.779258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , (function(){var h={},mt={},c={id:"8461be6dabbba234458468c863f484bf",dm:["lz.house365.com"],js:"tongj
[1:1:0712/112310.779800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112310.824376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x84216a829c8, 0x3385ff601960
[1:1:0712/112310.824677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.lz.house365.com/", 100
[1:1:0712/112310.825099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.lz.house365.com/, 1099
[1:1:0712/112310.825356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f4fd74e7070 0x3385ff394d60 , 5:3_http://newhouse.lz.house365.com/, 1, -5:3_http://newhouse.lz.house365.com/, 1085 0x7f4fd784fbd0 0x3386083b5758 
[1:1:0712/112312.199221:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/112312.203259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.lz.house365.com/, 1099, 7f4fd9e2c881
[1:1:0712/112312.224031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d858d982860","ptid":"1085 0x7f4fd784fbd0 0x3386083b5758 ","rf":"5:3_http://newhouse.lz.house365.com/"}
[1:1:0712/112312.224292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.lz.house365.com/","ptid":"1085 0x7f4fd784fbd0 0x3386083b5758 ","rf":"5:3_http://newhouse.lz.house365.com/"}
[1:1:0712/112312.224541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.lz.house365.com/"
[1:1:0712/112312.224870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/112312.224980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112312.225387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x84216a829c8, 0x3385ff601950
[1:1:0712/112312.225494:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.lz.house365.com/", 100
[1:1:0712/112312.225668:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.lz.house365.com/, 1135
[1:1:0712/112312.225783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7f4fd74e7070 0x3385ff42fce0 , 5:3_http://newhouse.lz.house365.com/, 1, -5:3_http://newhouse.lz.house365.com/, 1099 0x7f4fd74e7070 0x3385ff394d60 
[1:1:0712/112312.748239:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/112312.748529:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.lz.house365.com/"
[1:1:0712/112312.753711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1134 0x7f4fd74e7070 0x33860b27abe0 , "http://newhouse.lz.house365.com/"
[1:1:0712/112312.759591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , , (function(){
	var parameters = {
			'guid'  : 'new_guid',
			'todayfirst' : 'new_todayfirst',
		
[1:1:0712/112312.759917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112312.861826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.lz.house365.com/, 1135, 7f4fd9e2c881
[1:1:0712/112312.929297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d858d982860","ptid":"1099 0x7f4fd74e7070 0x3385ff394d60 ","rf":"5:3_http://newhouse.lz.house365.com/"}
[1:1:0712/112312.929644:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://newhouse.lz.house365.com/","ptid":"1099 0x7f4fd74e7070 0x3385ff394d60 ","rf":"5:3_http://newhouse.lz.house365.com/"}
[1:1:0712/112312.930078:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://newhouse.lz.house365.com/"
[1:1:0712/112312.930833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.lz.house365.com/, 3d858d982860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/112312.931117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.lz.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/112312.931922:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x84216a829c8, 0x3385ff601950
[1:1:0712/112312.933445:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://newhouse.lz.house365.com/", 100
[1:1:0712/112312.933852:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://newhouse.lz.house365.com/, 1181
[1:1:0712/112312.934089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7f4fd74e7070 0x33860b2b01e0 , 5:3_http://newhouse.lz.house365.com/, 1, -5:3_http://newhouse.lz.house365.com/, 1135 0x7f4fd74e7070 0x3385ff42fce0 
