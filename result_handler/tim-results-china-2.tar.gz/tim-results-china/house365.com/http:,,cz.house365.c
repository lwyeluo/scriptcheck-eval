[0712/111733.373964:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111733.374411:INFO:switcher_clone.cc(787)] backtrace rip is 7f0934972891
[0712/111734.375249:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111734.375841:INFO:switcher_clone.cc(787)] backtrace rip is 7f49a96df891
[1:1:0712/111734.390667:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111734.391007:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111734.397010:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[130045:130045:0712/111735.601984:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/111735.641800:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111735.642096:INFO:switcher_clone.cc(787)] backtrace rip is 7ff3913d5891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ef06ecf8-33e4-4c6c-a26b-2c6f7fd92ff8
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[130078:130078:0712/111735.887770:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130078
[130090:130090:0712/111735.888110:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=130090
[130045:130045:0712/111736.176360:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[130045:130076:0712/111736.177177:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111736.177380:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111736.177602:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111736.178208:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111736.178359:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111736.181624:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25125809, 1
[1:1:0712/111736.181954:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1a981cd8, 0
[1:1:0712/111736.182139:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2f0743bf, 3
[1:1:0712/111736.182309:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2de93d81, 2
[1:1:0712/111736.182499:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd81cffffff981a 09581225 ffffff813dffffffe92d ffffffbf43072f , 10104, 4
[1:1:0712/111736.183452:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130045:130076:0712/111736.183735:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��	X%�=�-�C/��
[130045:130076:0712/111736.183830:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��	X%�=�-�C/���
[1:1:0712/111736.183733:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f49a791a0a0, 3
[1:1:0712/111736.183997:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f49a7aa5080, 2
[130045:130076:0712/111736.184218:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/111736.184203:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4991768d20, -2
[130045:130076:0712/111736.184316:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130098, 4, d81c981a 09581225 813de92d bf43072f 
[1:1:0712/111736.204716:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111736.205612:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2de93d81
[1:1:0712/111736.206567:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2de93d81
[1:1:0712/111736.208209:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2de93d81
[1:1:0712/111736.209715:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.209903:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.210106:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.210308:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.210930:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2de93d81
[1:1:0712/111736.211266:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f49a96df7ba
[1:1:0712/111736.211409:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f49a96d6def, 7f49a96df77a, 7f49a96e10cf
[1:1:0712/111736.217127:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2de93d81
[1:1:0712/111736.217467:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2de93d81
[1:1:0712/111736.218221:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2de93d81
[1:1:0712/111736.220233:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.220431:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.220613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.220795:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2de93d81
[1:1:0712/111736.222028:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2de93d81
[1:1:0712/111736.222404:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f49a96df7ba
[1:1:0712/111736.222537:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f49a96d6def, 7f49a96df77a, 7f49a96e10cf
[1:1:0712/111736.230229:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111736.230669:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111736.230815:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff6b2c048, 0x7ffff6b2bfc8)
[1:1:0712/111736.246643:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111736.253841:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[130045:130045:0712/111736.861329:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130045:130045:0712/111736.862762:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130045:130057:0712/111736.886270:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[130045:130057:0712/111736.886400:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[130045:130045:0712/111736.886619:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[130045:130045:0712/111736.886779:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[130045:130045:0712/111736.886979:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,130098, 4
[1:7:0712/111736.888986:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[130045:130068:0712/111736.963318:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111737.017734:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x353b12f45220
[1:1:0712/111737.018886:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/111737.476883:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111739.122704:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111739.127143:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[130045:130045:0712/111739.129939:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[130045:130045:0712/111739.130037:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111740.097687:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111740.172792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111740.173118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111740.218606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111740.218884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111740.291964:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111740.292271:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111740.787602:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111740.795256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111740.795489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111740.829189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111740.839303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111740.839556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111740.850771:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111740.854207:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x353b12f43e20
[1:1:0712/111740.854424:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[130045:130045:0712/111740.854756:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[130045:130045:0712/111740.869074:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[130045:130045:0712/111740.908495:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[130045:130045:0712/111740.908596:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111740.931308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111741.711318:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f49933432e0 0x353b130725e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111741.712688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/111741.712876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111741.714271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130045:130045:0712/111741.780323:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111741.782649:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x353b12f44820
[1:1:0712/111741.782921:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[130045:130045:0712/111741.785679:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111741.797163:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111741.797313:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[130045:130045:0712/111741.803129:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[130045:130045:0712/111741.816726:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130045:130045:0712/111741.818013:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130045:130057:0712/111741.825912:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[130045:130045:0712/111741.825959:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[130045:130057:0712/111741.826006:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[130045:130045:0712/111741.826057:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[130045:130045:0712/111741.826228:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,130098, 4
[1:7:0712/111741.829971:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111742.443489:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111742.721483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f49933432e0 0x353b132f85e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111742.722642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111742.722898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111742.723721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[130045:130045:0712/111742.952331:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[130045:130045:0712/111742.952405:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111742.963455:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111743.426705:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[130045:130045:0712/111743.723698:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[130045:130076:0712/111743.724209:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111743.724434:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111743.724736:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111743.725079:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111743.725274:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111743.728729:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xdc33028, 1
[1:1:0712/111743.729246:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1022ffe, 0
[1:1:0712/111743.729488:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d851fb2, 3
[1:1:0712/111743.729723:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x36988f46, 2
[1:1:0712/111743.729949:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffe2f0201 2830ffffffc30d 46ffffff8fffffff9836 ffffffb21fffffff852d , 10104, 5
[1:1:0712/111743.730954:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[130045:130076:0712/111743.731232:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�/(0�F��6��-�
[130045:130076:0712/111743.731327:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �/(0�F��6��-���
[1:1:0712/111743.731221:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f49a791a0a0, 3
[1:1:0712/111743.731472:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f49a7aa5080, 2
[130045:130076:0712/111743.731611:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 130142, 5, fe2f0201 2830c30d 468f9836 b21f852d 
[1:1:0712/111743.731712:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4991768d20, -2
[1:1:0712/111743.755745:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111743.756244:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 36988f46
[1:1:0712/111743.756616:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 36988f46
[1:1:0712/111743.757330:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 36988f46
[1:1:0712/111743.759124:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.759424:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.759691:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.759983:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.760871:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 36988f46
[1:1:0712/111743.761281:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f49a96df7ba
[1:1:0712/111743.761496:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f49a96d6def, 7f49a96df77a, 7f49a96e10cf
[1:1:0712/111743.767430:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 36988f46
[1:1:0712/111743.767986:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 36988f46
[1:1:0712/111743.768772:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 36988f46
[1:1:0712/111743.771376:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.771687:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.771988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.772256:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 36988f46
[1:1:0712/111743.773575:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 36988f46
[1:1:0712/111743.774041:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f49a96df7ba
[1:1:0712/111743.774228:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f49a96d6def, 7f49a96df77a, 7f49a96e10cf
[1:1:0712/111743.780933:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111743.781534:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111743.781760:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffff6b2c048, 0x7ffff6b2bfc8)
[1:1:0712/111743.790639:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111743.790976:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111743.798156:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111743.803275:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111744.065846:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x353b12efa220
[1:1:0712/111744.066140:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[130045:130045:0712/111744.192514:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[130045:130045:0712/111744.198848:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[130045:130057:0712/111744.224690:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[130045:130057:0712/111744.224793:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[130045:130045:0712/111744.225137:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://cz.house365.com/
[130045:130045:0712/111744.225234:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://cz.house365.com/, http://cz.house365.com/index.html, 1
[130045:130045:0712/111744.225405:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://cz.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:17:44 GMT Content-Type: text/html; charset=gb2312 Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 18:11:16 GMT Vary: Accept-Encoding ETag: W/"5d28cd44-1e394" Content-Encoding: gzip  ,130142, 5
[1:7:0712/111744.228097:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111744.276462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111744.280832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 32b03392e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111744.281135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111744.289735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111744.317162:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://cz.house365.com/
[130045:130045:0712/111744.456352:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://cz.house365.com/, http://cz.house365.com/, 1
[130045:130045:0712/111744.456411:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://cz.house365.com/, http://cz.house365.com
[1:1:0712/111744.478473:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111744.552776:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111744.575664:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111744.576472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 32b033801f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111744.576711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111744.592757:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111744.629526:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111744.629785:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111745.899319:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111745.902958:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111745.903406:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111745.903886:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111745.904262:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111756.847863:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_RESET","http://pic.house365.com/homepage2018/css/index.css?1562955074"
[1:1:0712/111756.915890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111756.918578:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111756.929022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/111756.929292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
		remove user.10_e43a3c1f -> 0
		remove user.11_39d405ca -> 0
		remove user.12_eb2ffbc5 -> 0
		remove user.13_1794e875 -> 0
		remove user.14_76a7a642 -> 0
[1:1:0712/111757.224508:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.235473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.242469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.252371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.263328:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.277521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.286666:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.304503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.315811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.373008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.391807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.489410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.498875:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.508976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.515052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7f499141b070 0x353b13488760 , "http://cz.house365.com/index.html"
[1:1:0712/111757.875785:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_RESET","http://img31.house365.com/M02/0D/7A/rBEBYV0kTUGAUdvuAAKijaD7EfI771_635x317.jpg"
[1:1:0712/111758.060798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 489 0x7f49a7aa5080 0x353b134ae1a0 1 0 0x353b134ae1b8 , "http://cz.house365.com/index.html"
[1:1:0712/111758.132200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/111758.132489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[130045:130045:0712/111810.471323:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -7
[3:3:0712/111810.488177:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111810.589413:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111810.833222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111810.833527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111811.098561:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.099006:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.099332:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.099664:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.100002:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.384000:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.384464:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.384810:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.385125:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.385460:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111811.497593:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111811.497867:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111811.498825:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f499141b070 0x353b13160460 , "http://cz.house365.com/index.html"
[1:1:0712/111811.500588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 	$(function(){		var jqueryInputDom2 = '#keywords';		var searchUrl = 'http://transferapi.house365.com
[1:1:0712/111811.500843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111811.510040:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f499141b070 0x353b13160460 , "http://cz.house365.com/index.html"
[1:1:0712/111811.519267:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111811.519858:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111811.546000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f499141b070 0x353b13160460 , "http://cz.house365.com/index.html"
[1:1:0712/111813.318620:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111813.837700:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111814.111164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111814.111615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111814.596105:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111814.854200:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111814.854526:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.856117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 612 0x7f499141b070 0x353b133ad8e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.856792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 281d7036f330, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/111814.857007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/111814.882784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 612 0x7f499141b070 0x353b133ad8e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.889673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 612 0x7f499141b070 0x353b133ad8e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.892131:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 612 0x7f499141b070 0x353b133ad8e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.969709:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111814.969891:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.970661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7f499141b070 0x353b1460ace0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.971041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 281d70374e08, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/111814.971155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/111814.974060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7f499141b070 0x353b1460ace0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.975425:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7f499141b070 0x353b1460ace0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111814.976486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7f499141b070 0x353b1460ace0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/111815.236516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111815.236855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111815.632347:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111815.632558:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111815.634620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649 0x7f499141b070 0x353b13591ae0 , "http://cz.house365.com/index.html"
[1:1:0712/111815.635399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/111815.635563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111815.638640:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649 0x7f499141b070 0x353b13591ae0 , "http://cz.house365.com/index.html"
[1:1:0712/111815.759592:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/111815.761264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 281d7036f330, , onload, notifyDidFinishLoading();
[1:1:0712/111815.761538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/111815.936205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/111815.938164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 281d70374e08, , onload, notifyDidFinishLoading();
[1:1:0712/111815.938347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/111816.263839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111816.264155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111816.316087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 717 0x7f49a7aa5080 0x353b139c0ce0 1 0 0x353b139c0cf8 , "http://cz.house365.com/index.html"
[1:1:0712/111816.400639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/111816.400881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
		remove user.f_98e447d6 -> 0
		remove user.10_679590b2 -> 0
		remove user.11_6ca05064 -> 0
[1:1:0712/111816.506654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 717 0x7f49a7aa5080 0x353b139c0ce0 1 0 0x353b139c0cf8 , "http://cz.house365.com/index.html"
[1:1:0712/111816.525120:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.019376, 115, 1
[1:1:0712/111816.525454:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111817.091803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111817.092072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111817.299950:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111817.300198:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111817.308134:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/111817.312074:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x353b148fb820
[1:1:0712/111817.312344:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[130045:130045:0712/111817.317090:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[130045:130045:0712/111817.323520:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[130045:130045:0712/111817.354565:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://cz.house365.com/, http://cz.house365.com/, 4
[130045:130045:0712/111817.354705:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://cz.house365.com/, http://cz.house365.com
[1:1:0712/111817.376883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 744 0x7f499141b070 0x353b1302b9e0 , "http://cz.house365.com/index.html"
[1:1:0712/111817.379024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
    document.domain = 'house365.com';
    var uid = getCookie('passport_uid');
    var openWin = fu
[1:1:0712/111817.379286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "cz.house365.com", 3, 1, , , 0
[1:1:0712/111817.381456:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "cz.house365.com", "house365.com"
[1:1:0712/111817.415366:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.115052, 365, 1
[1:1:0712/111817.415562:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111817.522635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111817.522835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111818.783523:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111818.783873:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111818.788826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 791 0x7f499141b070 0x353b12b9d560 , "http://cz.house365.com/index.html"
[1:1:0712/111818.791435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
function QR8bitByte(a){
    this.mode=QRMode.MODE_8BIT_BYTE,
        this.data=a
}

function 
[1:1:0712/111818.791757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111818.803363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 791 0x7f499141b070 0x353b12b9d560 , "http://cz.house365.com/index.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[130045:130045:0712/111832.474537:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/111835.518473:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 16.7344, 0, 0
[1:1:0712/111835.518776:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111835.607160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111835.607495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111836.274566:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111836.274841:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111836.314644:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.039712, 246, 1
[1:1:0712/111836.314928:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111836.440571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111836.440866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111837.908983:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111837.909212:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111837.910164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 863 0x7f499141b070 0x353b153ce460 , "http://cz.house365.com/index.html"
[1:1:0712/111837.910982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
			
[1:1:0712/111837.911194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111837.988856:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0795491, 435, 1
[1:1:0712/111837.989101:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111838.088589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://cz.house365.com/index.html"
[1:1:0712/111838.089439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/111838.089565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111838.103835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111838.104009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111840.218592:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111840.218886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111840.219881:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 925 0x7f499141b070 0x353b1b321960 , "http://cz.house365.com/index.html"
[1:1:0712/111840.220982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
						$(function(){
							$("#xfzx_right_lp .newhouseSItem").click(function(){
								$(this).add
[1:1:0712/111840.221415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111840.330620:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.111909, 765, 1
[1:1:0712/111840.331176:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111840.472976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111840.473306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111842.026524:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111842.026943:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111842.067229:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.040328, 212, 1
[1:1:0712/111842.067866:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111842.174821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111842.175159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111843.437699:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111843.437974:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111843.439079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 998 0x7f499141b070 0x353b15f215e0 , "http://cz.house365.com/index.html"
[1:1:0712/111843.440245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
			var flag_esf_tag = true;
					
[1:1:0712/111843.440502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111843.467867:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0297871, 209, 1
[1:1:0712/111843.468207:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111843.498184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.readyState
[1:1:0712/111843.498499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111844.420937:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111844.421238:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111844.422269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1026 0x7f499141b070 0x353b164e3ee0 , "http://cz.house365.com/index.html"
[1:1:0712/111844.423200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , 
		var flag_zf_tag = true;
			
[1:1:0712/111844.423501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111844.449843:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.028491, 127, 1
[1:1:0712/111844.450116:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/111845.384614:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111845.384891:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://cz.house365.com/index.html"
[1:1:0712/111845.388417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1054 0x7f499141b070 0x353b12f893e0 , "http://cz.house365.com/index.html"
[1:1:0712/111845.389669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://cz.house365.com/, 281d70262860, , , document.write("<div class=\"w10000\">	<div class=\"pt45 pb45 bg484848\">		<div class=\"margin_auto_
[1:1:0712/111845.389914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://cz.house365.com/index.html", "house365.com", 3, 1, , , 0
[1:1:0712/111845.409811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1054 0x7f499141b070 0x353b12f893e0 , "http://cz.house365.com/index.html"
[1:1:0712/111845.430735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1054 0x7f499141b070 0x353b12f893e0 , "http://cz.house365.com/index.html"
[1:1:0712/111845.556432:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[130045:130045:0712/111845.560663:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111845.562736:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x353b1b1dda20
[1:1:0712/111845.562993:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[130045:130045:0712/111845.563679:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[130045:130045:0712/111845.598435:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://cz.house365.com/, http://cz.house365.com/, 5
[130045:130045:0712/111845.598626:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://cz.house365.com/, http://cz.house365.com
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
