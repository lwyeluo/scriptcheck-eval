[0712/110528.411132:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110528.411446:INFO:switcher_clone.cc(787)] backtrace rip is 7fbbee83b891
[0712/110529.261436:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110529.261743:INFO:switcher_clone.cc(787)] backtrace rip is 7fc11433e891
[1:1:0712/110529.266248:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/110529.266433:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/110529.271937:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[128665:128665:0712/110530.557563:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b0693998-26f7-4e69-8561-b9a0b26e4561
[0712/110530.712166:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110530.712748:INFO:switcher_clone.cc(787)] backtrace rip is 7fb591920891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[128698:128698:0712/110530.929785:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128698
[128710:128710:0712/110530.930220:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128710
[128665:128665:0712/110530.976555:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[128665:128696:0712/110530.977408:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/110530.977669:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110530.977914:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110530.978585:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110530.978763:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/110530.984232:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x248e97b1, 1
[1:1:0712/110530.984672:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x322f9b7a, 0
[1:1:0712/110530.984837:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f002f77, 3
[1:1:0712/110530.985001:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x222b47d5, 2
[1:1:0712/110530.985192:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7affffff9b2f32 ffffffb1ffffff97ffffff8e24 ffffffd5472b22 772f001f , 10104, 4
[1:1:0712/110530.986185:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128665:128696:0712/110530.986435:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGz�/2���$�G+"w/
[128665:128696:0712/110530.986518:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is z�/2���$�G+"w/
[1:1:0712/110530.986420:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc1125790a0, 3
[1:1:0712/110530.986657:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc112704080, 2
[128665:128696:0712/110530.986884:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/110530.986812:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc0fc3c7d20, -2
[128665:128696:0712/110530.986967:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128718, 4, 7a9b2f32 b1978e24 d5472b22 772f001f 
[1:1:0712/110531.006030:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110531.006922:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 222b47d5
[1:1:0712/110531.007941:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 222b47d5
[1:1:0712/110531.009552:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 222b47d5
[1:1:0712/110531.011073:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.011263:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.011450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.011702:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.012327:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 222b47d5
[1:1:0712/110531.012701:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc11433e7ba
[1:1:0712/110531.012846:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc114335def, 7fc11433e77a, 7fc1143400cf
[1:1:0712/110531.018490:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 222b47d5
[1:1:0712/110531.018847:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 222b47d5
[1:1:0712/110531.019612:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 222b47d5
[1:1:0712/110531.021703:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.021947:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.022175:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.022435:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 222b47d5
[1:1:0712/110531.023819:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 222b47d5
[1:1:0712/110531.024183:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc11433e7ba
[1:1:0712/110531.024318:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc114335def, 7fc11433e77a, 7fc1143400cf
[1:1:0712/110531.032073:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110531.032549:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110531.032744:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe68088768, 0x7ffe680886e8)
[1:1:0712/110531.048477:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110531.053570:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[128665:128690:0712/110531.577644:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[128665:128665:0712/110531.634041:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128665:128665:0712/110531.635378:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128665:128677:0712/110531.658188:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[128665:128677:0712/110531.658298:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[128665:128665:0712/110531.658554:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[128665:128665:0712/110531.658661:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[128665:128665:0712/110531.658861:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,128718, 4
[1:7:0712/110531.661653:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110531.762865:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x346c2413d220
[1:1:0712/110531.763186:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/110532.172388:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[128665:128665:0712/110533.776752:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[128665:128665:0712/110533.776876:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110533.806519:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110533.810779:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110534.906408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110534.906778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110534.923336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110534.923696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110534.968099:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110535.168484:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110535.168789:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110535.410759:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110535.418936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110535.419188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110535.454342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110535.465018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110535.465331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110535.477290:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/110535.480927:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x346c2413be20
[1:1:0712/110535.481169:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128665:128665:0712/110535.482065:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[128665:128665:0712/110535.496405:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[128665:128665:0712/110535.521831:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[128665:128665:0712/110535.521931:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110535.589270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110536.212882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fc0fdfa22e0 0x346c24398a60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110536.214263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/110536.214477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110536.216068:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128665:128665:0712/110536.284418:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110536.285833:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x346c2413c820
[1:1:0712/110536.286093:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[128665:128665:0712/110536.301551:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/110536.308587:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/110536.308856:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[128665:128665:0712/110536.322019:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[128665:128665:0712/110536.334967:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128665:128665:0712/110536.336230:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128665:128677:0712/110536.343521:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[128665:128677:0712/110536.343609:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[128665:128665:0712/110536.343880:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[128665:128665:0712/110536.343975:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[128665:128665:0712/110536.344139:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,128718, 4
[1:7:0712/110536.346985:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110536.959139:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/110537.474128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7fc0fdfa22e0 0x346c2434e1e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110537.475297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2ed6ac561f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/110537.475684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110537.476534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128665:128665:0712/110537.569641:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[128665:128665:0712/110537.569754:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/110537.610638:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110537.938903:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110538.296957:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110538.297247:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[128665:128665:0712/110538.337108:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[128665:128696:0712/110538.337725:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/110538.337977:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110538.338313:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110538.338838:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110538.339076:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/110538.343062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x96728e4, 1
[1:1:0712/110538.343598:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1038abf1, 0
[1:1:0712/110538.343820:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x7fffca3, 3
[1:1:0712/110538.344027:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3fc84786, 2
[1:1:0712/110538.344236:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff1ffffffab3810 ffffffe4286709 ffffff8647ffffffc83f ffffffa3fffffffcffffffff07 , 10104, 5
[1:1:0712/110538.345705:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128665:128696:0712/110538.346027:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�8�(g	�G�?�����d
[128665:128696:0712/110538.346131:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �8�(g	�G�?����q��d
[128665:128696:0712/110538.346606:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128762, 5, f1ab3810 e4286709 8647c83f a3fcff07 
[1:1:0712/110538.346343:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc1125790a0, 3
[1:1:0712/110538.347234:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc112704080, 2
[1:1:0712/110538.347534:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc0fc3c7d20, -2
[1:1:0712/110538.376886:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110538.377214:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fc84786
[1:1:0712/110538.377597:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fc84786
[1:1:0712/110538.378222:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fc84786
[1:1:0712/110538.379637:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.379863:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.380049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.380225:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.380908:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fc84786
[1:1:0712/110538.381270:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc11433e7ba
[1:1:0712/110538.381431:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc114335def, 7fc11433e77a, 7fc1143400cf
[1:1:0712/110538.387108:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3fc84786
[1:1:0712/110538.387494:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3fc84786
[1:1:0712/110538.388218:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3fc84786
[1:1:0712/110538.390263:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.390490:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.390683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.390866:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3fc84786
[1:1:0712/110538.392087:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3fc84786
[1:1:0712/110538.392512:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc11433e7ba
[1:1:0712/110538.392655:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc114335def, 7fc11433e77a, 7fc1143400cf
[1:1:0712/110538.400408:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110538.400889:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110538.401036:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe68088768, 0x7ffe680886e8)
[1:1:0712/110538.414873:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110538.419237:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/110538.544991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110538.549718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2ed6ac68e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/110538.550047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110538.558306:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110538.579053:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x346c240e6220
[1:1:0712/110538.579280:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[128665:128665:0712/110546.110416:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128665:128665:0712/110546.124074:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128665:128677:0712/110546.146323:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[128665:128665:0712/110546.146514:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.la.house365.com/
[128665:128665:0712/110546.146561:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.la.house365.com/, http://newhouse.la.house365.com/, 1
[128665:128665:0712/110546.146628:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.la.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:05:46 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=li8b5fv0m0q20pgn1543n0ig76; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,128762, 5
[128665:128677:0712/110546.146440:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/110546.152232:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110546.175514:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.la.house365.com/
[128665:128665:0712/110546.372463:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.la.house365.com/, http://newhouse.la.house365.com/, 1
[128665:128665:0712/110546.372609:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.la.house365.com/, http://newhouse.la.house365.com
[1:1:0712/110546.389689:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110546.536500:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110546.601216:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110546.652092:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110546.652411:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110547.222755:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110547.824818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7fc0fc3e2bd0 0x346c24421d58 , "http://newhouse.la.house365.com/"
[1:1:0712/110547.835104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/110547.835456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "newhouse.la.house365.com", 3, 1, , , 0
[1:1:0712/110547.837807:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_9ea07db1 -> 0
[1:1:0712/110548.051465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7fc0fc3e2bd0 0x346c24421d58 , "http://newhouse.la.house365.com/"
[1:1:0712/110548.075994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 226 0x7fc0fc3e2bd0 0x346c24421d58 , "http://newhouse.la.house365.com/"
[1:1:0712/110548.193605:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110548.198060:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110548.198586:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110548.199021:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110548.199421:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110549.173496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fc0fc07a070 0x346c24543860 , "http://newhouse.la.house365.com/"
[1:1:0712/110549.174623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'la';
    var uid = '';
    var fav_prjid =
[1:1:0712/110549.174889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "newhouse.la.house365.com", 3, 1, , , 0
[1:1:0712/110549.176996:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.la.house365.com", "house365.com"
[1:1:0712/110549.184660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fc0fc07a070 0x346c24543860 , "http://newhouse.la.house365.com/"
[1:1:0712/110549.189440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fc0fc07a070 0x346c24543860 , "http://newhouse.la.house365.com/"
[1:1:0712/110549.194867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7fc0fc07a070 0x346c24543860 , "http://newhouse.la.house365.com/"
[1:1:0712/110549.869003:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 333, "http://newhouse.la.house365.com/"
[1:1:0712/110549.870588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110549.870806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110550.199308:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110550.432792:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110550.433032:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110550.463424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 368 0x7fc112704080 0x346c245caa60 1 0 0x346c245caa78 , "http://newhouse.la.house365.com/"
[1:1:0712/110550.494031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110550.494326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
		remove user.10_f70bcfee -> 0
		remove user.11_c12df72c -> 0
		remove user.12_d323aae4 -> 0
		remove user.13_22258f95 -> 0
		remove user.14_499b910e -> 0
[1:1:0712/110550.655925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110550.742682:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0285578, 144, 1
[1:1:0712/110550.742948:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110550.936662:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110550.936980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110550.937991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 379 0x7fc0fc07a070 0x346c2433f660 , "http://newhouse.la.house365.com/"
[1:1:0712/110550.939814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/110550.940053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110550.996203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 379 0x7fc0fc07a070 0x346c2433f660 , "http://newhouse.la.house365.com/"
[1:1:0712/110551.360918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389, "http://newhouse.la.house365.com/"
[1:1:0712/110551.362784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110551.363020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110552.059633:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110552.360986:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110552.361262:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110552.364884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7fc0fc07a070 0x346c23cf27e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110552.374233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110552.374470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110552.643554:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.282157, 52, 1
[1:1:0712/110552.643824:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110552.739275:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110552.739446:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110552.739878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 438 0x7fc0fc07a070 0x346c2452d2e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110552.740458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/110552.740569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110552.821206:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7fc112704080 0x346c24588b00 1 0 0x346c24588b18 , "http://newhouse.la.house365.com/"
[1:1:0712/110552.825980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/110552.826109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110554.594239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7fc112704080 0x346c24588b00 1 0 0x346c24588b18 , "http://newhouse.la.house365.com/"
[1:1:0712/110554.600686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7fc112704080 0x346c24588b00 1 0 0x346c24588b18 , "http://newhouse.la.house365.com/"
[1:1:0712/110554.631972:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0396991, 81, 1
[1:1:0712/110554.632287:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110555.303012:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110555.303363:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110555.304326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc0fc07a070 0x346c24ee80e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110555.306014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/110555.306263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110555.327736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc0fc07a070 0x346c24ee80e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110555.344179:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc0fc07a070 0x346c24ee80e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110555.394259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc0fc07a070 0x346c24ee80e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110557.624530:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110557.911996:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110557.912274:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110557.914562:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7fc0fc07a070 0x346c24620be0 , "http://newhouse.la.house365.com/"
[1:1:0712/110557.916266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/110557.916505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110557.925191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7fc0fc07a070 0x346c24620be0 , "http://newhouse.la.house365.com/"
[1:1:0712/110557.945383:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7fc0fc07a070 0x346c24620be0 , "http://newhouse.la.house365.com/"
[1:1:0712/110558.074187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7fc0fc07a070 0x346c24620be0 , "http://newhouse.la.house365.com/"
[1:1:0712/110558.191704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7fc0fc07a070 0x346c24620be0 , "http://newhouse.la.house365.com/"
[1:1:0712/110558.262927:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.350548, 232, 1
[1:1:0712/110558.263222:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110558.770929:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110558.771275:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110558.772271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fc0fc07a070 0x346c24ea7460 , "http://newhouse.la.house365.com/"
[1:1:0712/110558.774352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/110558.774578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110558.777988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7fc0fc07a070 0x346c24ea7460 , "http://newhouse.la.house365.com/"
[1:1:0712/110558.818927:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0475771, 333, 1
[1:1:0712/110558.819224:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110559.190926:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110559.191227:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110559.192077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541 0x7fc0fc07a070 0x346c255322e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110559.193164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode235153_1").qrcode({
                                rend
[1:1:0712/110559.193407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_447b6a5c -> 0
[128665:128665:0712/110613.546365:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/110613.628667:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/110618.587377:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 19.3962, 0, 0
[1:1:0712/110618.587808:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110618.682518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/110618.682855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110619.101399:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110619.101728:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110619.124557:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0227051, 85, 1
[1:1:0712/110619.124880:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110619.347396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110619.347763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110620.600849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110620.601179:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110620.602096:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 586 0x7fc0fc07a070 0x346c25117d60 , "http://newhouse.la.house365.com/"
[1:1:0712/110620.603220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode206381_1").qrcode({
                                rend
[1:1:0712/110620.603478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110620.666871:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110621.135680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110621.150324:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110623.917730:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.31648, 0, 0
[1:1:0712/110623.918061:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110623.985083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110623.987169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110623.987441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110624.019536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110624.019854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110625.241522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110625.242308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110625.242543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110625.282458:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110625.282731:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110625.288809:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00600386, 81, 1
[1:1:0712/110625.289119:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110625.349693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110625.350010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110625.946736:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110625.947019:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110625.948107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7fc0fc07a070 0x346c2cbefbe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110625.949340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode236113_1").qrcode({
                                rend
[1:1:0712/110625.949608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110626.207203:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.261298, 77, 1
[1:1:0712/110626.208725:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110626.305247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110626.305573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110626.608379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110626.609132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110626.609324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110626.708989:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110626.709288:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110626.710544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 655 0x7fc0fc07a070 0x346c23ef2ae0 , "http://newhouse.la.house365.com/"
[1:1:0712/110626.712112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode205303_1").qrcode({
                                rend
[1:1:0712/110626.712363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
		remove user.12_9e047865 -> 0
		remove user.13_b6771aa3 -> 0
		remove user.14_bb5ac77b -> 0
[1:1:0712/110626.952819:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.243317, 85, 1
[1:1:0712/110626.953033:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110627.008866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110627.009123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110627.297041:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110627.297522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110627.297676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110627.340319:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110627.340505:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110627.341131:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7fc0fc07a070 0x346c2cbd05e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110627.341778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode205517_1").qrcode({
                                rend
[1:1:0712/110627.341896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110627.515728:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110627.516179:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110627.516480:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110627.615656:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.275312, 81, 1
[1:1:0712/110627.616034:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110627.642791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110627.642983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110628.010862:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110628.011486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110628.011653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110628.116183:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110628.116431:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110628.117395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7fc0fc07a070 0x346c23d1a160 , "http://newhouse.la.house365.com/"
[1:1:0712/110628.118415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode226483_1").qrcode({
                                rend
[1:1:0712/110628.118617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110628.376165:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.259614, 81, 1
[1:1:0712/110628.376353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110628.393814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110628.394024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110628.818589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110628.819094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110628.819216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110628.868832:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110628.869012:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110628.869661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 712 0x7fc0fc07a070 0x346c2df89060 , "http://newhouse.la.house365.com/"
[1:1:0712/110628.870293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode239609_1").qrcode({
                                rend
[1:1:0712/110628.870413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110629.280143:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.411204, 85, 1
[1:1:0712/110629.280582:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110629.300631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110629.300823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110629.595877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110629.596658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110629.596848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110629.700318:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110629.700552:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110629.701556:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 733 0x7fc0fc07a070 0x346c2e6d77e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110629.702731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode239219_1").qrcode({
                                rend
[1:1:0712/110629.703013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110630.029393:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.32875, 85, 1
[1:1:0712/110630.029638:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110630.055533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110630.055721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110630.600133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110630.600623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110630.600740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110630.685402:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110630.685702:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110630.686933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 757 0x7fc0fc07a070 0x346c2e78efe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110630.688327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode246715_1").qrcode({
                                rend
[1:1:0712/110630.688617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
		remove user.15_ab17dba3 -> 0
		remove user.16_75819dd0 -> 0
		remove user.17_40042195 -> 0
[1:1:0712/110630.997257:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.311388, 85, 1
[1:1:0712/110630.997550:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110631.113805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110631.114059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110631.675716:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110631.676609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110631.676974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110631.767331:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110631.767505:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110631.768346:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7fc0fc07a070 0x346c2cbef960 , "http://newhouse.la.house365.com/"
[1:1:0712/110631.769161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode238959_1").qrcode({
                                rend
[1:1:0712/110631.769333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110632.096586:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.329087, 89, 1
[1:1:0712/110632.096769:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110632.132411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110632.132600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110632.426510:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110632.427305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110632.427542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110632.555525:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110632.555879:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110632.557706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7fc0fc07a070 0x346c2e6db960 , "http://newhouse.la.house365.com/"
[1:1:0712/110632.558967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode235647_1").qrcode({
                                rend
[1:1:0712/110632.560517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110632.795967:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.239887, 85, 1
[1:1:0712/110632.796243:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110632.844324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110632.844775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110633.163548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110633.164059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110633.164210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110633.226354:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110633.226577:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110633.227385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 815 0x7fc0fc07a070 0x346c2eb67b60 , "http://newhouse.la.house365.com/"
[1:1:0712/110633.228228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode238831_1").qrcode({
                                rend
[1:1:0712/110633.228391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110633.421669:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.195033, 77, 1
[1:1:0712/110633.421852:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110633.443611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110633.443924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110633.882782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110633.883742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110633.884001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110634.014758:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110634.015047:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110634.016288:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 832 0x7fc0fc07a070 0x346c2ee5d060 , "http://newhouse.la.house365.com/"
[1:1:0712/110634.017624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode96301_1").qrcode({
                                rende
[1:1:0712/110634.017862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110634.322497:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.307237, 93, 1
[1:1:0712/110634.322714:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110634.381988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110634.382184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110634.842278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110634.842785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110634.842905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110634.931074:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110634.931356:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110634.932600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 851 0x7fc0fc07a070 0x346c2efba760 , "http://newhouse.la.house365.com/"
[1:1:0712/110634.933960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode206149_1").qrcode({
                                rend
[1:1:0712/110634.934223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110635.212414:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.280929, 89, 1
[1:1:0712/110635.212736:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110635.254226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110635.254480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[128665:128665:0712/110635.413755:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110635.711946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110635.712437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110635.712588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110635.765618:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110635.765812:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110635.766415:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 869 0x7fc0fc07a070 0x346c2e79fae0 , "http://newhouse.la.house365.com/"
[1:1:0712/110635.767044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
                            $("#lptelqrcode205359_1").qrcode({
                                rend
[1:1:0712/110635.767163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110636.019007:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.253276, 54, 1
[1:1:0712/110636.019318:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110636.151445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110636.151707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110636.525236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.la.house365.com/"
[1:1:0712/110636.525985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110636.526188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110636.594967:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110636.595139:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110636.595739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 885 0x7fc0fc07a070 0x346c2f5363e0 , "http://newhouse.la.house365.com/"
[1:1:0712/110636.596344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
listCondition.p=1;
var totalpage=12;

[1:1:0712/110636.596482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110636.623715:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0286181, 285, 1
[1:1:0712/110636.623938:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110636.638465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110636.638646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110637.598572:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110637.598858:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110637.599853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.601300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
    $(function(){
        $(".hotslide").on("click",function(){
            if($(this).children("im
[1:1:0712/110637.601549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110637.606228:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.610047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.619204:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.796530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.803558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.813884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.832098:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.984408:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110637.996731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110638.035043:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110638.041160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7fc0fc07a070 0x346c25122360 , "http://newhouse.la.house365.com/"
[1:1:0712/110638.106226:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.507254, 0, 0
[1:1:0712/110638.106510:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110638.182644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.readyState
[1:1:0712/110638.182950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110640.384096:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110640.384367:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.la.house365.com/"
[1:1:0712/110640.385656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110640.386682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , 
    //消息定位的扩展字段
    //from tf_ios淘房iOS ，tf_android 淘房安卓，pc网页P
[1:1:0712/110640.386938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110640.394506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110640.402266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110640.408393:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110640.444948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110640.446403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 959 0x7fc0fc07a070 0x346c2cfbbfe0 , "http://newhouse.la.house365.com/"
[1:1:0712/110642.197107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006, "http://newhouse.la.house365.com/"
[1:1:0712/110642.197969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.la.house365.com/, 0c6257bc2860, , , document.writeln("<style>");
document.writeln("@keyframes jumping{");
document.writeln("	0%{");
d
[1:1:0712/110642.198098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.la.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110642.230818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1006, "http://newhouse.la.house365.com/"
[128665:128665:0712/110642.242939:INFO:CONSOLE(2177)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?9f42630d132b103625cf04f5109b8cb1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.la.house365.com/ (2177)
[128665:128665:0712/110642.250885:INFO:CONSOLE(2177)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://hm.baidu.com/h.js?9f42630d132b103625cf04f5109b8cb1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://newhouse.la.house365.com/ (2177)
