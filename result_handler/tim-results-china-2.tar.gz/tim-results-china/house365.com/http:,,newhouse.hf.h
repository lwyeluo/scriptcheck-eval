[0712/110101.279572:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110101.279896:INFO:switcher_clone.cc(787)] backtrace rip is 7f33c4678891
[0712/110102.229263:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110102.229696:INFO:switcher_clone.cc(787)] backtrace rip is 7f2032dca891
[1:1:0712/110102.238751:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/110102.238949:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/110102.244128:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[128144:128144:0712/110103.231898:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/056f1771-8620-43e0-abb8-17e2936db6f6
[0712/110103.502329:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110103.502755:INFO:switcher_clone.cc(787)] backtrace rip is 7f17c5497891
[128144:128144:0712/110103.644024:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[128144:128175:0712/110103.645172:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/110103.645413:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110103.645646:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110103.646203:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110103.646432:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/110103.649417:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32063a0, 1
[1:1:0712/110103.649770:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x19f0b5eb, 0
[1:1:0712/110103.649966:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3dbd2ffe, 3
[1:1:0712/110103.650183:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x13517c8d, 2
[1:1:0712/110103.650421:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffebffffffb5fffffff019 ffffffa0632003 ffffff8d7c5113 fffffffe2fffffffbd3d , 10104, 4
[1:1:0712/110103.651391:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128144:128175:0712/110103.651711:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���c �|Q�/�=[G�
[128144:128175:0712/110103.651778:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���c �|Q�/�=x|[G�
[1:1:0712/110103.651696:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f20310050a0, 3
[128144:128175:0712/110103.652070:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/110103.651987:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2031190080, 2
[128144:128175:0712/110103.652212:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128190, 4, ebb5f019 a0632003 8d7c5113 fe2fbd3d 
[1:1:0712/110103.652229:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f201ae53d20, -2
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/110103.670375:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110103.671507:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13517c8d
[1:1:0712/110103.672753:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13517c8d
[1:1:0712/110103.674745:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13517c8d
[1:1:0712/110103.676695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.676977:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.677248:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.677501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.678263:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13517c8d
[1:1:0712/110103.678707:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2032dca7ba
[1:1:0712/110103.678933:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2032dc1def, 7f2032dca77a, 7f2032dcc0cf
[1:1:0712/110103.684693:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 13517c8d
[1:1:0712/110103.685116:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 13517c8d
[1:1:0712/110103.685903:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 13517c8d
[1:1:0712/110103.687973:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.688314:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.688561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.688792:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 13517c8d
[1:1:0712/110103.690109:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 13517c8d
[1:1:0712/110103.690512:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2032dca7ba
[1:1:0712/110103.690692:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2032dc1def, 7f2032dca77a, 7f2032dcc0cf
[1:1:0712/110103.698664:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110103.699270:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110103.699459:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcfa9f2af8, 0x7ffcfa9f2a78)
[1:1:0712/110103.717093:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110103.723428:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[128177:128177:0712/110103.741897:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128177
[128198:128198:0712/110103.742327:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128198
[128144:128144:0712/110104.104836:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[128144:128144:0712/110104.168670:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128144:128144:0712/110104.169122:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128144:128156:0712/110104.180302:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[128144:128156:0712/110104.180433:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[128144:128144:0712/110104.180582:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[128144:128144:0712/110104.180664:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[128144:128144:0712/110104.180809:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,128190, 4
[1:7:0712/110104.195515:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[128144:128167:0712/110104.246135:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/110104.283127:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3ef1c10dc220
[1:1:0712/110104.283480:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/110104.544829:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/110105.901366:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110105.905516:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128144:128144:0712/110106.361741:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[128144:128144:0712/110106.361845:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110107.037522:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110107.412097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110107.412406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110107.428869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110107.429130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110107.614813:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110107.615049:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110107.832092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110107.840306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110107.840632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110107.876798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110107.887250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110107.887482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110107.900141:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[128144:128144:0712/110107.903629:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110107.904553:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ef1c10dae20
[1:1:0712/110107.905293:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128144:128144:0712/110107.920725:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[128144:128144:0712/110107.945791:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[128144:128144:0712/110107.945877:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110107.973409:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110108.708733:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f201ca2e2e0 0x3ef1c13a0560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110108.710452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/110108.710699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110108.712278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128144:128144:0712/110108.780095:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110108.781585:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3ef1c10db820
[1:1:0712/110108.781831:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[128144:128144:0712/110108.791426:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/110108.801145:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/110108.801420:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[128144:128144:0712/110108.806682:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[128144:128144:0712/110108.812803:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128144:128144:0712/110108.813808:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128144:128156:0712/110108.820293:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[128144:128156:0712/110108.820384:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[128144:128144:0712/110108.820537:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[128144:128144:0712/110108.820614:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[128144:128144:0712/110108.820752:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,128190, 4
[1:7:0712/110108.832393:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110109.293542:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/110109.756822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f201ca2e2e0 0x3ef1c14834e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110109.757928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/110109.758176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110109.758972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110109.825639:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128144:128144:0712/110109.829958:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[128144:128144:0712/110109.830059:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/110110.144743:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110110.547181:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110110.547448:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110110.887392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110110.891964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/110110.892288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110110.899076:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110111.151712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110111.152580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/110111.152887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[128144:128144:0712/110111.229590:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[128144:128175:0712/110111.229855:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/110111.230022:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110111.230227:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110111.230621:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110111.230809:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/110111.234431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e678631, 1
[1:1:0712/110111.234858:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3dd9c89, 0
[1:1:0712/110111.235059:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e5b876, 3
[1:1:0712/110111.235251:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa5722af, 2
[1:1:0712/110111.235430:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff89ffffff9cffffffdd03 31ffffff86672e ffffffaf22570a 76ffffffb8ffffffe502 , 10104, 5
[1:1:0712/110111.236441:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128144:128175:0712/110111.236690:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���1�g.�"W
v��I�
[128144:128175:0712/110111.236792:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���1�g.�"W
v��8pI�
[1:1:0712/110111.236906:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f20310050a0, 3
[128144:128175:0712/110111.237054:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128243, 5, 899cdd03 3186672e af22570a 76b8e502 
[1:1:0712/110111.237133:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2031190080, 2
[1:1:0712/110111.237379:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f201ae53d20, -2
[1:1:0712/110111.254927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110111.256684:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/110111.256944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/110111.257442:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110111.257215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110111.257792:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a5722af
[1:1:0712/110111.258176:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a5722af
[1:1:0712/110111.258911:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a5722af
[1:1:0712/110111.260879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.261129:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.261355:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.261575:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.262396:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a5722af
[1:1:0712/110111.262722:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2032dca7ba
[1:1:0712/110111.262916:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2032dc1def, 7f2032dca77a, 7f2032dcc0cf
[1:1:0712/110111.268612:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a5722af
[1:1:0712/110111.269048:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a5722af
[1:1:0712/110111.269786:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a5722af
[1:1:0712/110111.271737:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.272031:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.272264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.272501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a5722af
[1:1:0712/110111.273802:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a5722af
[1:1:0712/110111.274224:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2032dca7ba
[1:1:0712/110111.274420:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2032dc1def, 7f2032dca77a, 7f2032dcc0cf
[1:1:0712/110111.284169:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110111.284747:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110111.284974:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcfa9f2af8, 0x7ffcfa9f2a78)
[1:1:0712/110111.300289:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110111.304901:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/110111.407482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110111.408492:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/110111.408749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/110111.409064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110111.491855:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3ef1c10b8220
[1:1:0712/110111.492128:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/110111.612905:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/110112.004901:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/110112.063935:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/110112.134261:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/110112.202548:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/110112.320229:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/110112.369418:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/110112.490947:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/110112.576830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.578014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110112.578333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.630493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.631422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110112.631729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.694665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.695496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110112.695918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.740636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.741621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110112.741932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.809538:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.810545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110112.810842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.860578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.861552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110112.861824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110112.927541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110112.928511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110112.928847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.047909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.048879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110113.049149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.085688:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.086631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110113.086955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.171813:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.173015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110113.173327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.251551:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.252745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110113.253067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.343301:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.344299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110113.344618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.367044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.368004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110113.368328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.448345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.449290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110113.449566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.555607:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.557331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/110113.557663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110113.612554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110113.613557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d2cd56ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/110113.613867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[128144:128144:0712/110113.879774:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128144:128144:0712/110113.885176:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128144:128156:0712/110113.904817:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[128144:128156:0712/110113.904918:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[128144:128144:0712/110113.905485:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://newhouse.hf.house365.com/
[128144:128144:0712/110113.905576:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hf.house365.com/, http://newhouse.hf.house365.com/, 1
[128144:128144:0712/110113.905741:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://newhouse.hf.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:01:13 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=nr1tov3bguh9ujqkkbdilggb45; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Access-Control-Allow-Origin: * Content-Encoding: gzip  ,128243, 5
[1:7:0712/110113.912588:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110113.937568:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://newhouse.hf.house365.com/
[128144:128144:0712/110114.035235:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://newhouse.hf.house365.com/, http://newhouse.hf.house365.com/, 1
[128144:128144:0712/110114.035297:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://newhouse.hf.house365.com/, http://newhouse.hf.house365.com
[1:1:0712/110114.035647:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110114.066509:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110114.067914:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0712/110114.068221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d2cd55c1f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0712/110114.068476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110114.123707:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110114.184764:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110114.214408:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110114.214724:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110114.307243:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110114.600336:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110114.655415:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110115.176710:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f201ae6ebd0 0x3ef1c138a858 , "http://newhouse.hf.house365.com/"
[1:1:0712/110115.194030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e,t){function _(e){var t=M[e]={};retu
[1:1:0712/110115.194332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "newhouse.hf.house365.com", 3, 1, , , 0
[1:1:0712/110115.196392:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_f348f10f -> 0
[1:1:0712/110115.527667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f201ae6ebd0 0x3ef1c138a858 , "http://newhouse.hf.house365.com/"
[1:1:0712/110115.577432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f201ae6ebd0 0x3ef1c138a858 , "http://newhouse.hf.house365.com/"
[1:1:0712/110116.682942:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f201ab06070 0x3ef1c14edb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110116.684062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
    var prjid = '';
    var listid = '';
    var CITY = 'hf';
    var uid = '';
    var fav_prjid =
[1:1:0712/110116.684256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "newhouse.hf.house365.com", 3, 1, , , 0
[1:1:0712/110116.686318:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "newhouse.hf.house365.com", "house365.com"
[1:1:0712/110116.694606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f201ab06070 0x3ef1c14edb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110116.700209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f201ab06070 0x3ef1c14edb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110116.715364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f201ab06070 0x3ef1c14edb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110117.191132:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=shopfbsimshow"
[1:1:0712/110118.591290:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f201ab06070 0x3ef1c1180ae0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110118.595424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110118.595740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110119.174982:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110119.700646:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110119.700833:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110119.703753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f201ab06070 0x3ef1c14009e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110119.780437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110119.780692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110119.971336:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.270502, 144, 1
[1:1:0712/110119.971512:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110120.254072:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=shopfbsimshow"
[1:1:0712/110120.495386:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110120.495566:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110120.496049:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 516 0x7f201ab06070 0x3ef1c14a89e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110120.496748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , ,     $(".city-select").hover(function(){        $(this).addClass("sm_hover_on");        $(".city-sele
[1:1:0712/110120.496896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110120.514646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 516 0x7f201ab06070 0x3ef1c14a89e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110121.552277:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 576, "http://newhouse.hf.house365.com/"
[1:1:0712/110121.554595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , var openWin = function(obj,isShowBg){
    var winElemt = $('#'+ obj);
    var $coverDom = "<div id
[1:1:0712/110121.554798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110121.740189:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110121.740496:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110121.742858:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110121.743244:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110121.743649:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110122.759956:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110123.834513:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110123.834723:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110123.835888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 657 0x7f201ab06070 0x3ef1c1361560 , "http://newhouse.hf.house365.com/"
[1:1:0712/110123.837834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110123.837956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110124.003223:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.168536, 52, 1
[1:1:0712/110124.003463:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110124.107591:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=shopfbsimshow"
[1:1:0712/110124.433824:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110124.434111:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110124.435057:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686 0x7f201ab06070 0x3ef1c19be5e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110124.436263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 									$(".jssel .condt  a").click(function() {										var val = $(this).attr("val");										$
[1:1:0712/110124.436491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110125.075306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 708 0x7f201ae6ebd0 0x3ef1c13cbed8 , "http://newhouse.hf.house365.com/"
[1:1:0712/110125.088156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/110125.088356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110126.801660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 708 0x7f201ae6ebd0 0x3ef1c13cbed8 , "http://newhouse.hf.house365.com/"
[1:1:0712/110126.808369:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 708 0x7f201ae6ebd0 0x3ef1c13cbed8 , "http://newhouse.hf.house365.com/"
[1:1:0712/110126.830534:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0307708, 165, 1
[1:1:0712/110126.830801:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110127.794296:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110127.794594:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110127.795507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f201ab06070 0x3ef1c249cb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110127.797288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , ,     function sub(city)    {		stat_onclick(1177,"导航搜索按钮");		        var searchStr = '';  
[1:1:0712/110127.797568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110127.815619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f201ab06070 0x3ef1c249cb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110127.831647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f201ab06070 0x3ef1c249cb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110127.854045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f201ab06070 0x3ef1c249cb60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110130.634414:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110131.268577:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110131.268891:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110131.271206:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f201ab06070 0x3ef1c1413b60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.272950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/110131.273199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110131.280443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f201ab06070 0x3ef1c1413b60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.304574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f201ab06070 0x3ef1c1413b60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.438173:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110131.440520:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110131.463609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f201ab06070 0x3ef1c1413b60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.533317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 796 0x7f201ab06070 0x3ef1c1413b60 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.587276:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.318337, 232, 1
[1:1:0712/110131.587611:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110131.664129:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://fbs.hf.house365.com/?action=shopfbsimshow"
[1:1:0712/110131.906622:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110131.906893:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110131.907822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 816 0x7f201ab06070 0x3ef1c2bc0fe0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.909932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
var openWin = function(obj,ajaxUrl,iframe,width,height,title){
    if(!width){
        width = '550
[1:1:0712/110131.910163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110131.914032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 816 0x7f201ab06070 0x3ef1c2bc0fe0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110131.936792:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110131.937304:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110131.937772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110131.970723:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.063741, 449, 1
[1:1:0712/110131.971006:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110132.294374:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110132.294717:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110132.295671:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 832 0x7f201ab06070 0x3ef1c201c8e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110132.296727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode253832_1").qrcode({
                                rend
[1:1:0712/110132.296942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
		remove user.11_7ccfd9ae -> 0
		remove user.12_1e325163 -> 0
		remove user.13_eaa5d1fb -> 0
		remove user.14_a38781bb -> 0
		remove user.15_777aec15 -> 0
[128144:128144:0712/110141.045003:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/110141.123977:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/110149.374435:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 17.0796, 0, 0
[1:1:0712/110149.374740:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110149.526412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/110149.526735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110150.327414:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110150.327711:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110150.336847:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00955701, 95, 1
[1:1:0712/110150.337702:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110150.694252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110150.694561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110152.050641:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110152.050901:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110152.051823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7f201ab06070 0x3ef1c23f9260 , "http://newhouse.hf.house365.com/"
[1:1:0712/110152.052985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode232781_1").qrcode({
                                rend
[1:1:0712/110152.053229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110155.317095:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.26609, 0, 0
[1:1:0712/110155.317389:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110155.445159:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110155.447168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110155.447368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110155.531655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110155.531904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110157.579633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110157.580556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110157.580788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110157.676457:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110157.676688:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110157.691100:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0143661, 99, 1
[1:1:0712/110157.691443:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110157.841960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110157.842256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110158.617545:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110158.617755:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110158.618351:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 956 0x7f201ab06070 0x3ef1c8b9d760 , "http://newhouse.hf.house365.com/"
[1:1:0712/110158.618991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode233213_5").qrcode({
                                rend
[1:1:0712/110158.619142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110158.932759:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.315006, 102, 1
[1:1:0712/110158.932949:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110159.086352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110159.086638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110159.650846:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110159.651678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110159.651928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110159.842274:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110159.842550:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110159.843569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 978 0x7f201ab06070 0x3ef1c8606460 , "http://newhouse.hf.house365.com/"
[1:1:0712/110159.844715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode246859_1").qrcode({
                                rend
[1:1:0712/110159.844936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110200.211743:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.369112, 87, 1
[1:1:0712/110200.212042:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110200.597432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110200.597621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110201.097030:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110201.097987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110201.098246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110201.171191:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110201.171494:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110201.173698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 997 0x7f201ab06070 0x3ef1c1b127e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110201.175125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode250664_1").qrcode({
                                rend
[1:1:0712/110201.175303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110201.580567:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.408966, 95, 1
[1:1:0712/110201.580879:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[128144:128144:0712/110201.672819:WARNING:one_google_bar_fetcher_impl.cc(315)] Request failed with error: -102: net::ERR_CONNECTION_REFUSED
[1:1:0712/110201.778544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110201.778891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110202.254251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110202.255182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110202.255438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110202.445970:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110202.446155:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110202.446809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1024 0x7f201ab06070 0x3ef1c1b30860 , "http://newhouse.hf.house365.com/"
[1:1:0712/110202.447474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode241503_1").qrcode({
                                rend
[1:1:0712/110202.447670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110202.807902:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.361784, 85, 1
[1:1:0712/110202.808150:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[128144:128144:0712/110203.014829:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/110203.079355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110203.079610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110203.519625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110203.520415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110203.520628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110203.683212:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110203.683442:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110203.684477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1046 0x7f201ab06070 0x3ef1c53f82e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110203.685628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode244743_1").qrcode({
                                rend
[1:1:0712/110203.685851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110204.091307:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.407839, 86, 1
[1:1:0712/110204.091619:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110204.186541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110204.186792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110204.815568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110204.816508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110204.816747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110205.083455:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110205.083632:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110205.084275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1071 0x7f201ab06070 0x3ef1cbb66de0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110205.084954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode235989_1").qrcode({
                                rend
[1:1:0712/110205.085070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110205.537844:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.454269, 85, 1
[1:1:0712/110205.538097:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110205.628968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110205.629165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110206.419288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110206.419801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110206.419924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110206.544368:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110206.544657:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110206.545703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1098 0x7f201ab06070 0x3ef1c9bd8160 , "http://newhouse.hf.house365.com/"
[1:1:0712/110206.546885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode239443_1").qrcode({
                                rend
[1:1:0712/110206.547102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110206.880244:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.335453, 86, 1
[1:1:0712/110206.880440:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110207.011822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110207.012144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110207.467502:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110207.468262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110207.468448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110207.687228:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110207.687462:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110207.688524:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1122 0x7f201ab06070 0x3ef1cc2f3fe0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110207.689609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode236611_1").qrcode({
                                rend
[1:1:0712/110207.689858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110208.144582:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.456954, 86, 1
[1:1:0712/110208.144766:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110208.271538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110208.271792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110208.969669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110208.970423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110208.970620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110209.220037:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110209.220239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110209.220916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1147 0x7f201ab06070 0x3ef1c1b31460 , "http://newhouse.hf.house365.com/"
[1:1:0712/110209.221598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode234371_1").qrcode({
                                rend
[1:1:0712/110209.221723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110209.452420:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.232218, 91, 1
[1:1:0712/110209.452664:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110209.559114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110209.559393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110210.242768:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110210.243529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110210.243736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110210.375250:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110210.375511:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110210.376573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1178 0x7f201ab06070 0x3ef1cc5b70e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110210.377783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode240757_1").qrcode({
                                rend
[1:1:0712/110210.378044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110210.579744:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204141, 94, 1
[1:1:0712/110210.579998:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110210.688463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , document.readyState
[1:1:0712/110210.688712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110211.573048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110211.573812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110211.574014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110211.823362:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110211.823590:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110211.824664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1209 0x7f201ab06070 0x3ef1cc5dd4e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110211.825714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode240169_1").qrcode({
                                rend
[1:1:0712/110211.825929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110211.934089:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.110325, 86, 1
[1:1:0712/110211.934275:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110212.707279:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110212.708048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110212.708240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110212.996821:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110212.997084:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110212.998162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1246 0x7f201ab06070 0x3ef1ccc51360 , "http://newhouse.hf.house365.com/"
[1:1:0712/110212.999259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode241485_1").qrcode({
                                rend
[1:1:0712/110212.999473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110213.297300:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.300118, 89, 1
[1:1:0712/110213.297540:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110214.003965:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110214.004457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110214.004613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110214.076655:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110214.076850:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110214.077476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1276 0x7f201ab06070 0x3ef1c1150de0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110214.078104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
                            $("#lptelqrcode230111_1").qrcode({
                                rend
[1:1:0712/110214.078281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110214.246605:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.169809, 54, 1
[1:1:0712/110214.246853:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110215.045431:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://newhouse.hf.house365.com/"
[1:1:0712/110215.045890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , b.src.e.onload, (){
                    d.drawImage(e,(b.width-b.imgWidth)/2,(b.height-b.imgHeight)/2,
           
[1:1:0712/110215.046007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110215.087061:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110215.087233:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://newhouse.hf.house365.com/"
[1:1:0712/110215.087893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1298 0x7f201ab06070 0x3ef1cc61e2e0 , "http://newhouse.hf.house365.com/"
[1:1:0712/110215.088478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://newhouse.hf.house365.com/, 2644fbba2860, , , 
listCondition.p=1;
var totalpage=125;

[1:1:0712/110215.088620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://newhouse.hf.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110215.132579:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0453849, 250, 1
[1:1:0712/110215.132815:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
