[0712/110216.451438:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110216.451973:INFO:switcher_clone.cc(787)] backtrace rip is 7f448f636891
[0712/110217.462420:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110217.462998:INFO:switcher_clone.cc(787)] backtrace rip is 7f37bcad4891
[1:1:0712/110217.468209:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/110217.468395:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/110217.473670:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[128278:128278:0712/110218.952680:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/622f4232-adf9-4ee6-a591-b5445bf01146
[0712/110219.191800:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/110219.192311:INFO:switcher_clone.cc(787)] backtrace rip is 7f7a15491891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[128313:128313:0712/110219.375793:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128313
[128324:128324:0712/110219.376197:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=128324
[128278:128278:0712/110219.461557:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[128278:128310:0712/110219.462337:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/110219.462584:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110219.462868:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110219.463453:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110219.463594:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/110219.466623:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2aae9b3e, 1
[1:1:0712/110219.466964:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x164e345a, 0
[1:1:0712/110219.467160:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x36dc5458, 3
[1:1:0712/110219.467357:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e82d01f, 2
[1:1:0712/110219.467656:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5a344e16 3effffff9bffffffae2a 1fffffffd0ffffff823e 5854ffffffdc36 , 10104, 4
[1:1:0712/110219.468625:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128278:128310:0712/110219.468902:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGZ4N>��*Ђ>XT�6��$
[128278:128310:0712/110219.468971:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Z4N>��*Ђ>XT�6����$
[1:1:0712/110219.468889:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37bad0f0a0, 3
[128278:128310:0712/110219.469335:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/110219.469131:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37bae9a080, 2
[128278:128310:0712/110219.469446:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128332, 4, 5a344e16 3e9bae2a 1fd0823e 5854dc36 
[1:1:0712/110219.469488:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37a4b5dd20, -2
[1:1:0712/110219.490187:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110219.491094:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e82d01f
[1:1:0712/110219.492113:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e82d01f
[1:1:0712/110219.493732:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e82d01f
[1:1:0712/110219.495207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.495465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.495721:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.495974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.496666:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e82d01f
[1:1:0712/110219.497041:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f37bcad47ba
[1:1:0712/110219.497217:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f37bcacbdef, 7f37bcad477a, 7f37bcad60cf
[1:1:0712/110219.502961:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e82d01f
[1:1:0712/110219.503375:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e82d01f
[1:1:0712/110219.504185:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e82d01f
[1:1:0712/110219.506234:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.506488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.506717:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.506944:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e82d01f
[1:1:0712/110219.508300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e82d01f
[1:1:0712/110219.508766:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f37bcad47ba
[1:1:0712/110219.508942:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f37bcacbdef, 7f37bcad477a, 7f37bcad60cf
[1:1:0712/110219.517194:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110219.517767:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110219.517984:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd822b5e98, 0x7ffd822b5e18)
[1:1:0712/110219.536099:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110219.541188:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[128278:128278:0712/110220.138993:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128278:128278:0712/110220.140405:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128278:128291:0712/110220.160929:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[128278:128291:0712/110220.161035:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[128278:128278:0712/110220.161291:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[128278:128278:0712/110220.161390:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[128278:128278:0712/110220.161616:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,128332, 4
[1:7:0712/110220.166127:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110220.234719:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe14f9fd7220
[1:1:0712/110220.234969:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[128278:128304:0712/110220.298025:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/110220.547101:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/110221.888706:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110221.892396:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[128278:128278:0712/110222.240086:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[128278:128278:0712/110222.240196:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110222.810506:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110223.059306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110223.059677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110223.078279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/110223.078544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110223.152858:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110223.153145:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110223.648502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110223.663522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110223.663980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110223.692337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110223.699582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/110223.699838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110223.711541:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[128278:128278:0712/110223.714027:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110223.715209:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe14f9fd5e20
[1:1:0712/110223.716408:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128278:128278:0712/110223.716150:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[128278:128278:0712/110223.781612:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[128278:128278:0712/110223.781935:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/110223.813173:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110224.548294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f37a67382e0 0xe14fa2babe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110224.549719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/110224.549960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110224.551474:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128278:128278:0712/110224.609796:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/110224.610529:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe14f9fd6820
[1:1:0712/110224.610775:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[128278:128278:0712/110224.620560:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/110224.629249:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/110224.629497:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[128278:128278:0712/110224.642764:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[128278:128278:0712/110224.653833:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128278:128278:0712/110224.654872:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128278:128291:0712/110224.661146:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[128278:128291:0712/110224.661245:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[128278:128278:0712/110224.661386:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[128278:128278:0712/110224.661464:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[128278:128278:0712/110224.661621:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,128332, 4
[1:7:0712/110224.665288:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110225.111654:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/110225.710917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7f37a67382e0 0xe14fa3da260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110225.712014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/110225.712252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110225.713068:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[128278:128278:0712/110225.795539:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[128278:128278:0712/110225.795613:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/110225.817003:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110226.144910:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[128278:128278:0712/110226.294805:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[128278:128310:0712/110226.295336:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/110226.295559:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/110226.295805:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/110226.296324:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/110226.296496:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/110226.300164:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d23f9d8, 1
[1:1:0712/110226.300542:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd34ef29, 0
[1:1:0712/110226.300701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb57c103, 3
[1:1:0712/110226.300843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x9bafebd, 2
[1:1:0712/110226.301013:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 29ffffffef340d ffffffd8fffffff9233d ffffffbdfffffffeffffffba09 03ffffffc1570b , 10104, 5
[1:1:0712/110226.302056:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[128278:128310:0712/110226.302336:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING)�4��#=���	�Wr��$
[128278:128310:0712/110226.302433:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is )�4��#=���	�W�8r��$
[1:1:0712/110226.302571:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37bad0f0a0, 3
[128278:128310:0712/110226.302710:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 128376, 5, 29ef340d d8f9233d bdfeba09 03c1570b 
[1:1:0712/110226.302784:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37bae9a080, 2
[1:1:0712/110226.303052:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f37a4b5dd20, -2
[1:1:0712/110226.329351:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/110226.329776:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9bafebd
[1:1:0712/110226.330178:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9bafebd
[1:1:0712/110226.330933:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9bafebd
[1:1:0712/110226.332702:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.332933:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.333202:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.333420:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.334267:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9bafebd
[1:1:0712/110226.334638:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f37bcad47ba
[1:1:0712/110226.334804:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f37bcacbdef, 7f37bcad477a, 7f37bcad60cf
[1:1:0712/110226.341650:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9bafebd
[1:1:0712/110226.342095:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9bafebd
[1:1:0712/110226.342960:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9bafebd
[1:1:0712/110226.345429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.345701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.345932:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.346190:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9bafebd
[1:1:0712/110226.347677:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9bafebd
[1:1:0712/110226.348142:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f37bcad47ba
[1:1:0712/110226.348314:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f37bcacbdef, 7f37bcad477a, 7f37bcad60cf
[1:1:0712/110226.357677:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/110226.358206:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/110226.358365:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd822b5e98, 0x7ffd822b5e18)
[1:1:0712/110226.371759:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/110226.376016:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/110226.468675:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110226.468931:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110226.623800:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe14f9fb3220
[1:1:0712/110226.624093:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[128278:128278:0712/110226.824694:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[128278:128278:0712/110226.830864:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[128278:128291:0712/110226.868726:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[128278:128291:0712/110226.868829:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[128278:128278:0712/110226.869233:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://xx.house365.com/
[128278:128278:0712/110226.869329:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://xx.house365.com/, http://xx.house365.com/, 1
[128278:128278:0712/110226.869486:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://xx.house365.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:02:26 GMT Content-Type: text/html; charset=gb2312 Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 12 Jul 2019 18:01:16 GMT Vary: Accept-Encoding ETag: W/"5d28caec-22ec1" Content-Encoding: gzip  ,128376, 5
[1:7:0712/110226.875274:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110226.876285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110226.880623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 17d091f8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/110226.880921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/110226.888881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/110226.905619:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://xx.house365.com/
[128278:128278:0712/110227.016208:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://xx.house365.com/, http://xx.house365.com/, 1
[128278:128278:0712/110227.016336:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://xx.house365.com/, http://xx.house365.com
[1:1:0712/110227.067528:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110227.109701:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110227.125285:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110227.141290:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110227.141441:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xx.house365.com/"
[1:1:0712/110227.208169:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/110227.208963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 17d091e61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/110227.209223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/110227.279726:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110228.289940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.340795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , /*! jQuery v1.11.1 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/110228.341137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110228.351576:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.586286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.591141:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.609903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.621634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.625493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.637461:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.644994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.691762:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.693202:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.693625:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.694047:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.694454:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110228.816063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.823048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 10000
[1:1:0712/110228.823458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 253
[1:1:0712/110228.823771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 253 0x7f37a4810070 0xe14f996cae0 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 202 0x7f37a4810070 0xe14fa19cee0 
[1:1:0712/110228.831376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 10000
[1:1:0712/110228.831873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 254
[1:1:0712/110228.832103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 254 0x7f37a4810070 0xe14f996bc60 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 202 0x7f37a4810070 0xe14fa19cee0 
[1:1:0712/110228.834398:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 10000
[1:1:0712/110228.834784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 255
[1:1:0712/110228.835016:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 255 0x7f37a4810070 0xe14fa4474e0 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 202 0x7f37a4810070 0xe14fa19cee0 
[1:1:0712/110228.836479:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 10000
[1:1:0712/110228.836859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 257
[1:1:0712/110228.837090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 257 0x7f37a4810070 0xe14fa445660 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 202 0x7f37a4810070 0xe14fa19cee0 
[1:1:0712/110228.887284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.901101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.950830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110228.975573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110229.056360:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110229.084550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110229.099169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110229.105342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7f37a4810070 0xe14fa19cee0 , "http://xx.house365.com/"
[1:1:0712/110231.706029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 373 0x7f37bae9a080 0xe14fa2d1560 1 0 0xe14fa2d1578 , "http://xx.house365.com/"
[1:1:0712/110231.793867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , /*! jQuery UI - v1.11.2 - 2014-10-16
* http://jqueryui.com
* Includes: core.js, widget.js, mouse.j
[1:1:0712/110231.794164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[128278:128278:0712/110255.647502:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/110255.653611:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/110256.671206:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110257.441461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/110257.441831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110257.847341:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110257.847827:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110257.848156:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110257.848487:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110257.848803:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.138512:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110258.139025:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/110258.150710:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.151145:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.151517:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.151876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.152210:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.298014:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.298533:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.298914:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.299251:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.299615:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.410867:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.411299:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.411679:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.412047:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.412391:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.534874:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.535385:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.535751:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.536070:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.536424:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110258.600453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 253, 7f37a7155881
[1:1:0712/110258.628034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110258.628486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110258.628911:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110258.629841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , full_screen13777(2)
[1:1:0712/110258.630058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110258.656503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1ff068c29c8, 0xe14f9977970
[1:1:0712/110258.656835:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 0
[1:1:0712/110258.657213:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 614
[1:1:0712/110258.657463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f37a4810070 0xe14faec2be0 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 253 0x7f37a4810070 0xe14f996cae0 
[1:1:0712/110258.741069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://xx.house365.com/", 13
[1:1:0712/110258.741549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xx.house365.com/, 626
[1:1:0712/110258.741791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f37a4810070 0xe14fa520be0 , 5:3_http://xx.house365.com/, 1, -5:3_http://xx.house365.com/, 253 0x7f37a4810070 0xe14f996cae0 
[1:1:0712/110258.758295:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 254, 7f37a7155881
[1:1:0712/110258.776842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110258.777214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110258.777677:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110258.778533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , full_screen13533(2)
[1:1:0712/110258.778760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110258.878945:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110258.879230:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xx.house365.com/"
[1:1:0712/110258.880206:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f37a4810070 0xe14faebca60 , "http://xx.house365.com/"
[1:1:0712/110258.881782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , 	$(function(){		var jqueryInputDom2 = '#keywords';		var searchUrl = 'http://transferapi.house365.com
[1:1:0712/110258.882016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110258.886468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f37a4810070 0xe14faebca60 , "http://xx.house365.com/"
[1:1:0712/110258.925169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 520 0x7f37a4810070 0xe14faebca60 , "http://xx.house365.com/"
[1:1:0712/110300.103507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 255, 7f37a7155881
[1:1:0712/110300.116516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110300.116850:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110300.117097:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110300.117645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , bigtosmall12561(2)
[1:1:0712/110300.117784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110300.225658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 257, 7f37a7155881
[1:1:0712/110300.255380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110300.255592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"202 0x7f37a4810070 0xe14fa19cee0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110300.255844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110300.256388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , bigtosmall12733(2)
[1:1:0712/110300.256517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110300.679815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , document.readyState
[1:1:0712/110300.680094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110300.902722:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110302.348708:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110303.921217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110304.153190:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110304.483503:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110305.175908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://xx.house365.com/, 614, 7f37a7155881
[1:1:0712/110305.217057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"253 0x7f37a4810070 0xe14f996cae0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110305.217477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"253 0x7f37a4810070 0xe14f996cae0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110305.217978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110305.218667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , (){$b=void 0}
[1:1:0712/110305.218948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110305.245996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xx.house365.com/, 626, 7f37a71558db
[1:1:0712/110305.271806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a0a4962860","ptid":"253 0x7f37a4810070 0xe14f996cae0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110305.272040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://xx.house365.com/","ptid":"253 0x7f37a4810070 0xe14f996cae0 ","rf":"5:3_http://xx.house365.com/"}
[1:1:0712/110305.272318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://xx.house365.com/, 899
[1:1:0712/110305.272456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 899 0x7f37a4810070 0xe15085d29e0 , 5:3_http://xx.house365.com/, 0, , 626 0x7f37a4810070 0xe14fa520be0 
[1:1:0712/110305.272613:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://xx.house365.com/"
[1:1:0712/110305.272963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , m.fx.tick, (){var a,b=m.timers,c=0;for($b=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/110305.273093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110306.479979:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110307.954814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , document.readyState
[1:1:0712/110307.955005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110308.629216:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110308.629443:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/110308.630988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743 0x7f37a4810070 0xe14fa0cfb60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110308.631953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a497ec78, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/110308.632133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110308.656006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743 0x7f37a4810070 0xe14fa0cfb60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110308.659097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743 0x7f37a4810070 0xe14fa0cfb60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110308.660357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743 0x7f37a4810070 0xe14fa0cfb60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.776351:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110310.776626:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.778615:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7f37a4810070 0xe150813b1e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.779320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a47020, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/110310.779529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110310.787355:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7f37a4810070 0xe150813b1e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.791226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7f37a4810070 0xe150813b1e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.793466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 847 0x7f37a4810070 0xe150813b1e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.864256:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110310.864434:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.865308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 890 0x7f37a4810070 0xe150825e760 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.865667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a4caf8, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/110310.865778:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110310.870652:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 890 0x7f37a4810070 0xe150825e760 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.872968:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 890 0x7f37a4810070 0xe150825e760 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.874155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 890 0x7f37a4810070 0xe150825e760 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.923170:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110310.923377:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.924267:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f37a4810070 0xe14faaa5e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.924647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a525d0, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/110310.924759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110310.928027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f37a4810070 0xe14faaa5e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.930283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f37a4810070 0xe14faaa5e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.931624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 897 0x7f37a4810070 0xe14faaa5e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.964941:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110310.965122:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.965991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7f37a4810070 0xe1508142e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.966388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a580a8, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/110310.966502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110310.972966:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7f37a4810070 0xe1508142e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.976653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7f37a4810070 0xe1508142e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110310.978932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 898 0x7f37a4810070 0xe1508142e60 , "data:text/html,pluginplaceholderdata"
[1:1:0712/110311.480133:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110311.480419:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xx.house365.com/"
[1:1:0712/110311.484845:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 932 0x7f37a4810070 0xe14fa978e60 , "http://xx.house365.com/"
[1:1:0712/110311.485747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , 	$(function(){		var jqueryInputDom = '#keywords_black';		var searchUrl = 'http://transferapi.house36
[1:1:0712/110311.485879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110311.491529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 932 0x7f37a4810070 0xe14fa978e60 , "http://xx.house365.com/"
[1:1:0712/110312.282057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , document.readyState
[1:1:0712/110312.282250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110312.925203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/110312.926332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a497ec78, , onload, notifyDidFinishLoading();
[1:1:0712/110312.926457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110313.400152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/110313.402325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a47020, , onload, notifyDidFinishLoading();
[1:1:0712/110313.402634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110313.727957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/110313.728978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a4caf8, , onload, notifyDidFinishLoading();
[1:1:0712/110313.729108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110313.918659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/110313.920988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a525d0, , onload, notifyDidFinishLoading();
[1:1:0712/110313.921210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110314.072021:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/110314.073380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 26a0a4a580a8, , onload, notifyDidFinishLoading();
[1:1:0712/110314.073539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/110314.107349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1150 0x7f37bae9a080 0xe14fa198560 1 0 0xe14fa198578 , "http://xx.house365.com/"
[1:1:0712/110314.149929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , var z=new Array();z[0x00A4]='A1E8';z[0x00A7]='A1EC';z[0x00A8]='A1A7';z[0x00B0]='A1E3';z[0x00B1]='A1C
[1:1:0712/110314.150178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
		remove user.10_c91450c8 -> 0
		remove user.11_d5668123 -> 0
[1:1:0712/110314.402339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1150 0x7f37bae9a080 0xe14fa198560 1 0 0xe14fa198578 , "http://xx.house365.com/"
[1:1:0712/110314.430759:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0293941, 111, 1
[1:1:0712/110314.431002:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110314.996925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , document.readyState
[1:1:0712/110314.997218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110316.575438:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110316.575736:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xx.house365.com/"
[1:1:0712/110316.576912:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1285 0x7f37a4810070 0xe14fbb54f60 , "http://xx.house365.com/"
[1:1:0712/110316.578420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , 
function normal11469(){
    document.write('<div style="display:block;position: relative;width:1200
[1:1:0712/110316.578701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "xx.house365.com", 3, 1, , , 0
[1:1:0712/110316.594869:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/110316.607313:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe14fb12a220
[1:1:0712/110316.607977:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[128278:128278:0712/110316.609642:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[128278:128278:0712/110316.619181:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[128278:128278:0712/110316.654557:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://xx.house365.com/, http://xx.house365.com/, 4
[128278:128278:0712/110316.654707:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://xx.house365.com/, http://xx.house365.com
[1:1:0712/110316.669438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1285 0x7f37a4810070 0xe14fbb54f60 , "http://xx.house365.com/"
[1:1:0712/110316.672566:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "xx.house365.com", "house365.com"
[1:1:0712/110316.712497:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.13671, 423, 1
[1:1:0712/110316.712824:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110316.954417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , document.readyState
[1:1:0712/110316.954749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "house365.com", 3, 1, , , 0
[128278:128278:0712/110317.587670:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/110319.929923:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110319.930190:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://xx.house365.com/"
[1:1:0712/110319.934893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1409 0x7f37a4810070 0xe1508642ee0 , "http://xx.house365.com/"
[1:1:0712/110319.943732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://xx.house365.com/, 26a0a4962860, , , 
function QR8bitByte(a){
    this.mode=QRMode.MODE_8BIT_BYTE,
        this.data=a
}

function 
[1:1:0712/110319.943990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://xx.house365.com/", "house365.com", 3, 1, , , 0
[1:1:0712/110319.956643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1409 0x7f37a4810070 0xe1508642ee0 , "http://xx.house365.com/"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
