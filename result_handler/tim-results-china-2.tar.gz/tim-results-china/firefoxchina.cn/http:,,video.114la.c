[0712/003738.339087:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/003738.339367:INFO:switcher_clone.cc(787)] backtrace rip is 7fdc1680b891
[0712/003739.453328:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/003739.454898:INFO:switcher_clone.cc(787)] backtrace rip is 7f1edc181891
[1:1:0712/003739.466664:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/003739.466917:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/003739.471969:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[42626:42626:0712/003740.468953:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/59dbe9e8-0710-4a2c-93d2-557a34995247
[0712/003740.682447:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/003740.682701:INFO:switcher_clone.cc(787)] backtrace rip is 7f14fd817891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[42626:42626:0712/003740.855049:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[42626:42656:0712/003740.855859:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/003740.856098:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/003740.856309:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/003740.856945:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/003740.857170:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/003740.860698:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xdb5d6ad, 1
[1:1:0712/003740.861129:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15b1ad99, 0
[1:1:0712/003740.861379:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2328ce3, 3
[1:1:0712/003740.861590:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x249a3ab0, 2
[1:1:0712/003740.861826:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff99ffffffadffffffb115 ffffffadffffffd6ffffffb50d ffffffb03affffff9a24 ffffffe3ffffff8c3202 , 10104, 4
[1:1:0712/003740.862869:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[42626:42656:0712/003740.863162:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING����ֵ�:�$�2��+
[42626:42656:0712/003740.863253:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ����ֵ�:�$�2�J��+
[1:1:0712/003740.863158:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1eda3bc0a0, 3
[1:1:0712/003740.863471:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1eda547080, 2
[42626:42656:0712/003740.863674:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[42626:42656:0712/003740.863739:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 42671, 4, 99adb115 add6b50d b03a9a24 e38c3202 
[1:1:0712/003740.863734:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1ec420ad20, -2
[1:1:0712/003740.879855:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/003740.880722:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 249a3ab0
[1:1:0712/003740.881684:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 249a3ab0
[1:1:0712/003740.883246:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 249a3ab0
[1:1:0712/003740.884788:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.884986:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.885205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.885426:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.886175:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 249a3ab0
[1:1:0712/003740.886560:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1edc1817ba
[1:1:0712/003740.886741:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1edc178def, 7f1edc18177a, 7f1edc1830cf
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/003740.892910:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 249a3ab0
[1:1:0712/003740.893328:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 249a3ab0
[1:1:0712/003740.894116:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 249a3ab0
[1:1:0712/003740.896230:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.896472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.896693:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.896949:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 249a3ab0
[1:1:0712/003740.898237:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 249a3ab0
[1:1:0712/003740.898629:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1edc1817ba
[1:1:0712/003740.898804:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1edc178def, 7f1edc18177a, 7f1edc1830cf
[42658:42658:0712/003740.905119:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=42658
[42672:42672:0712/003740.905525:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=42672
[1:1:0712/003740.907091:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/003740.907656:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/003740.907838:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd1c57d5f8, 0x7ffd1c57d578)
[1:1:0712/003740.926264:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/003740.932394:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[42626:42650:0712/003741.468179:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[42626:42626:0712/003741.485662:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[42626:42626:0712/003741.487107:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[42626:42637:0712/003741.510603:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[42626:42637:0712/003741.510702:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[42626:42626:0712/003741.510955:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[42626:42626:0712/003741.511070:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[42626:42626:0712/003741.511248:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,42671, 4
[1:7:0712/003741.516356:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/003741.548646:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3c3dd315c220
[1:1:0712/003741.548937:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/003741.805078:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/003742.957459:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003742.961333:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[42626:42626:0712/003743.158566:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[42626:42626:0712/003743.158670:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/003744.045078:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003744.140489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/003744.140794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003744.158014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/003744.158328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003744.400252:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003744.400529:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003744.848450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003744.865451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/003744.865997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003744.923625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003744.934190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/003744.934547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003744.947271:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[42626:42626:0712/003744.949147:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/003744.954115:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c3dd315ae20
[1:1:0712/003744.954570:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[42626:42626:0712/003744.955998:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[42626:42626:0712/003745.000066:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[42626:42626:0712/003745.000269:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/003745.041670:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003745.899189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f1ec5de52e0 0x3c3dd334e360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003745.900695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/003745.900952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003745.902540:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[42626:42626:0712/003745.972621:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/003745.973699:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c3dd315b820
[1:1:0712/003745.973896:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[42626:42626:0712/003745.986941:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/003745.992110:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/003745.992320:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[42626:42626:0712/003746.011637:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[42626:42626:0712/003746.025485:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[42626:42626:0712/003746.026489:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[42626:42637:0712/003746.032596:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[42626:42637:0712/003746.032692:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[42626:42626:0712/003746.032839:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[42626:42626:0712/003746.032915:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[42626:42626:0712/003746.033052:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,42671, 4
[1:7:0712/003746.036294:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/003746.601111:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/003746.947624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f1ec5de52e0 0x3c3dd33a6460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003746.948765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/003746.949007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003746.949802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[42626:42626:0712/003747.038039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[42626:42626:0712/003747.038192:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/003747.066616:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/003747.347028:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003747.741743:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003747.741993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/003748.131656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/003748.136324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0cdbf2d6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/003748.136619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/003748.144137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[42626:42626:0712/003748.275951:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[42626:42656:0712/003748.276448:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/003748.276685:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/003748.276954:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/003748.277410:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/003748.277583:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/003748.280620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c1d621c, 1
[1:1:0712/003748.280972:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x229d7f76, 0
[1:1:0712/003748.281166:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1d04a020, 3
[1:1:0712/003748.281353:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8d44873, 2
[1:1:0712/003748.281532:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 767fffffff9d22 1c621d3c 7348ffffffd408 20ffffffa0041d , 10104, 5
[1:1:0712/003748.282531:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[42626:42656:0712/003748.282791:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGv�"b<sH� ��!�+
[42626:42656:0712/003748.282862:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is v�"b<sH� ����!�+
[42626:42656:0712/003748.283201:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 42722, 5, 767f9d22 1c621d3c 7348d408 20a0041d 
[1:1:0712/003748.282993:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1eda3bc0a0, 3
[1:1:0712/003748.283639:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1eda547080, 2
[1:1:0712/003748.283886:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1ec420ad20, -2
[1:1:0712/003748.306020:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/003748.306331:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8d44873
[1:1:0712/003748.306682:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8d44873
[1:1:0712/003748.307303:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8d44873
[1:1:0712/003748.308724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.308948:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.309126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.309303:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.309980:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8d44873
[1:1:0712/003748.310263:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1edc1817ba
[1:1:0712/003748.310398:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1edc178def, 7f1edc18177a, 7f1edc1830cf
[1:1:0712/003748.316146:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8d44873
[1:1:0712/003748.316498:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8d44873
[1:1:0712/003748.317263:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8d44873
[1:1:0712/003748.319193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.319395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.319568:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.319750:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8d44873
[1:1:0712/003748.320964:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8d44873
[1:1:0712/003748.321305:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1edc1817ba
[1:1:0712/003748.321441:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1edc178def, 7f1edc18177a, 7f1edc1830cf
[1:1:0712/003748.328741:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/003748.329253:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/003748.329400:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd1c57d5f8, 0x7ffd1c57d578)
[1:1:0712/003748.341985:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/003748.345815:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/003748.346514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0cdbf2c41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/003748.346636:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/003748.346731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/003748.531237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/003748.532968:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/003748.533175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0cdbf2d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/003748.533437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/003748.547451:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c3dd315a220
[1:1:0712/003748.547655:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[42626:42626:0712/003748.576660:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[42626:42626:0712/003748.581251:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[42626:42637:0712/003748.600463:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[42626:42637:0712/003748.600560:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[42626:42626:0712/003748.600972:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://video.114la.com/
[42626:42626:0712/003748.601051:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://video.114la.com/, http://video.114la.com/ifr/?ch=8, 1
[42626:42626:0712/003748.601186:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://video.114la.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 07:37:48 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Thu, 27 Jun 2019 04:14:24 GMT ETag: W/"5d1442a0-3c70" Powered-By-YLMF: HB2_baike-web2 Content-Encoding: gzip  ,42722, 5
[1:7:0712/003748.603777:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/003748.696024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/003748.697143:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/003748.697369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0cdbf2d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/003748.697640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/003748.776320:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://video.114la.com/
[42626:42626:0712/003748.971612:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://video.114la.com/, http://video.114la.com/, 1
[42626:42626:0712/003748.971747:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://video.114la.com/, http://video.114la.com
[1:1:0712/003749.002308:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/003749.164108:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003749.232763:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003749.233020:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003749.398165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 145, "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003749.401630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , //designWidth:设计稿的实际宽度值，需要根据实际设置
//maxWidth:制作稿的最大�
[1:1:0712/003749.401884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "video.114la.com", 3, 1, , , 0
[1:1:0712/003749.402900:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003749.433864:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 145, "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003749.435854:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "video.114la.com", "114la.com"
[1:1:0712/003749.452791:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/003749.484212:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c3dd3157a20
[1:1:0712/003749.484493:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/003749.506647:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/003749.506885:INFO:render_frame_impl.cc(7019)] 	 [url] = http://video.114la.com
[1:1:0712/003749.538939:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/003749.548224:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3c3dd3157020
[1:1:0712/003749.548458:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/003749.574349:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003749.581035:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.149082, 134, 1
[1:1:0712/003749.581288:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003749.691721:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/003749.864358:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/003750.054644:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/003750.100863:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003750.101182:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003750.140094:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/003750.218161:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0712/003750.251668:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003750.348356:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/003750.408808:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/003750.479795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003750.493216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , !function(e,t){function n(e){return H.isWindow(e)?e:9===e.nodeType?e.defaultView||e.parentWindow:!1}
[1:1:0712/003750.493522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003750.526195:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
		remove user.10_acd0530d -> 0
[1:1:0712/003750.923622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003750.966476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.005831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.046001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.090304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.160485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.177216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/003751.294979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.322908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7f1ec4225bd0 0x3c3dd333bbd8 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.464408:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.550578, 0, 0
[1:1:0712/003751.464703:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003751.742003:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003751.742484:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003751.742880:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003751.743318:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003751.743760:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003751.769027:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003751.769300:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.770691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7f1ec3ebd070 0x3c3dd34613e0 , "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.773555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , 
        ;(function() {
            function changePage(){
                var locaPotocal = window.
[1:1:0712/003751.773815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003751.820443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003751.822453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.233143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2da43eb629c8, 0x3c3dd2fc61e0
[1:1:0712/003752.233419:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 100
[1:1:0712/003752.233812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 272
[1:1:0712/003752.234033:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 272 0x7f1ec3ebd070 0x3c3dd38970e0 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 255 0x7f1ec3ebd070 0x3c3dd34613e0 
[1:1:0712/003752.234837:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2da43eb629c8, 0x3c3dd2fc61e0
[1:1:0712/003752.235025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 100
[1:1:0712/003752.235370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 273
[1:1:0712/003752.235604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 273 0x7f1ec3ebd070 0x3c3dd32580e0 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 255 0x7f1ec3ebd070 0x3c3dd34613e0 
[1:1:0712/003752.292228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.293085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,hn&&delet
[1:1:0712/003752.293325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003752.294737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.297644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.298436:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x395d69eefa28
[1:1:0712/003752.376852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2da43eb629c8, 0x3c3dd2fc6210
[1:1:0712/003752.377173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 5000
[1:1:0712/003752.377663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 286
[1:1:0712/003752.377916:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 286 0x7f1ec3ebd070 0x3c3dd388c360 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 260
[1:1:0712/003752.437648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.438405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,hn&&delet
[1:1:0712/003752.438647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003752.439162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.441523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.442246:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x395d69eefa28
[1:1:0712/003752.475679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.476419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,hn&&delet
[1:1:0712/003752.476638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003752.477244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.479995:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.480624:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x395d69eefa28
[1:1:0712/003752.537287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.538048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , r, (e,i){var s,u,c,f,d;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=H.noop,hn&&delet
[1:1:0712/003752.538278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003752.538780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.541242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.541903:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x395d69eefa28
[1:1:0712/003752.621899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.685467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 272, 7f1ec6802881
[1:1:0712/003752.697358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"255 0x7f1ec3ebd070 0x3c3dd34613e0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003752.697658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"255 0x7f1ec3ebd070 0x3c3dd34613e0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003752.698068:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.698623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
            if ($.trim(input.val()) != "") {
                label.hide();
            }
      
[1:1:0712/003752.698827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003752.702015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 273, 7f1ec6802881
[1:1:0712/003752.716790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"255 0x7f1ec3ebd070 0x3c3dd34613e0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003752.717195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"255 0x7f1ec3ebd070 0x3c3dd34613e0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003752.717584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003752.718162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
            if ($.trim(input.val()) != "") {
                label.hide();
            }
      
[1:1:0712/003752.718380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003757.387290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 286, 7f1ec6802881
[1:1:0712/003757.408170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"260","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003757.408494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"260","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003757.408872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003757.409561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
            if (params.loop) {
                _this.fixLoop();
                _this.swipeNext
[1:1:0712/003757.409793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003802.792493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/003802.792811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[42626:42626:0712/003803.017450:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[42626:42626:0712/003803.024799:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: tongxun, 4, 4, 
[42626:42626:0712/003803.037496:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://video.114la.com/
[42626:42626:0712/003803.053142:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[42626:42626:0712/003803.061517:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[42626:42626:0712/003803.086235:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://video.114la.com/, http://video.114la.com/, 5
[42626:42626:0712/003803.086375:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://video.114la.com/, http://video.114la.com
[42626:42626:0712/003803.215671:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://video.114la.com/ifr/?ch=8 (0)
[42626:42626:0712/003803.225983:INFO:CONSOLE(46)] "[object Object]", source: http://video.114la.com/static/js/video_vip_pc.js (46)
[42626:42626:0712/003803.226705:INFO:CONSOLE(47)] "1", source: http://video.114la.com/static/js/video_vip_pc.js (47)
[42626:42626:0712/003803.281592:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/003803.330641:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[42626:42626:0712/003803.401986:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[42626:42626:0712/003803.439409:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[42626:42626:0712/003803.441790:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[42626:42637:0712/003803.456881:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[42626:42626:0712/003803.456913:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://my.114la.com/
[42626:42637:0712/003803.457008:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[42626:42626:0712/003803.457021:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://my.114la.com/, http://my.114la.com/tongxun.html, 4
[42626:42626:0712/003803.457153:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://my.114la.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 07:38:03 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Last-Modified: Fri, 20 Apr 2018 14:15:45 GMT ETag: W/"5ad9f611-766" Powered-By-YLMF: HB2_user-web1 Content-Encoding: gzip  ,42722, 5
[1:7:0712/003803.468782:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/003804.161268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , document.readyState
[1:1:0712/003804.161729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003804.295646:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://my.114la.com/
[1:1:0712/003804.979174:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[42626:42626:0712/003804.988887:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://my.114la.com/, http://my.114la.com/, 4
[42626:42626:0712/003804.988978:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://my.114la.com/, http://my.114la.com
[1:1:0712/003805.395604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , document.readyState
[1:1:0712/003805.395910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003805.593020:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/003805.751648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003805.752443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
        clearTimeout(tid); //防止执行两次
        tid = setTimeout(refreshRem, 300);
    
[1:1:0712/003805.752668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003805.753603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x2da43eb629c8, 0x3c3dd2fc6220
[1:1:0712/003805.753803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 300
[1:1:0712/003805.754178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 641
[1:1:0712/003805.754420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f1ec3ebd070 0x3c3dd38c19e0 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 
[1:1:0712/003805.754799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003805.766183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003805.784053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2da43eb629c8, 0x3c3dd2fc61f0
[1:1:0712/003805.784375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 5000
[1:1:0712/003805.784805:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 643
[1:1:0712/003805.785058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f1ec3ebd070 0x3c3dd3e97ce0 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 
[1:1:0712/003805.785777:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003805.787932:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2da43eb629c8, 0x3c3dd2fc6300
[1:1:0712/003805.788172:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://video.114la.com/ifr/?ch=8", 5000
[1:1:0712/003805.788563:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 644
[1:1:0712/003805.788788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 644 0x7f1ec3ebd070 0x3c3dd3e5e9e0 , 5:3_http://video.114la.com/, 1, -5:3_http://video.114la.com/, 631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 
[1:1:0712/003806.058577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , document.readyState
[1:1:0712/003806.058882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003806.103393:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/003806.103664:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://my.114la.com/tongxun.html"
[1:1:0712/003806.107515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7f1ec3ebd070 0x3c3dd32528e0 , "http://my.114la.com/tongxun.html"
[1:1:0712/003806.137613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://my.114la.com/, 2c6bea04d0f8, , , 
			document.domain = window.location.hostname.match(/(114la|114larc)\.com$/i)[0];
			/**
			 * 执�
[1:1:0712/003806.137948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://my.114la.com/tongxun.html", "my.114la.com", 4, 1, http://video.114la.com, 114la.com, 3
[1:1:0712/003806.139736:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "my.114la.com", "114la.com"
[1:1:0712/003806.160141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003806.160917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://my.114la.com/-5:3_http://video.114la.com/, 2c6be9f22860, 2c6bea04d0f8, ready, (e){if(e===!0&&!--s.readyWait||e!==!0&&!s.isReady){if(!M.body)return setTimeout(s.ready,1);if(s.isRe
[1:1:0712/003806.161157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 2, , , 0
[1:1:0712/003806.161551:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/003806.162775:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003806.287819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 641, 7f1ec6802881
[1:1:0712/003806.320616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003806.321008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003806.321424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003806.322044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , refreshRem, () {
        var width = docEl.getBoundingClientRect().width;
        maxWidth = maxWidth || 540;
  
[1:1:0712/003806.322270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003806.361052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , document.readyState
[1:1:0712/003806.361350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003806.820543:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 500 (Internal Server Error)","http://video.114la.com/favicon.ico"
[1:1:0712/003806.955447:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003806.955965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/003810.800283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 643, 7f1ec6802881
[1:1:0712/003810.841207:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003810.841643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003810.842079:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003810.842786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
            if (params.loop) {
                _this.fixLoop();
                _this.swipeNext
[1:1:0712/003810.843010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
[1:1:0712/003810.880550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://video.114la.com/, 644, 7f1ec6802881
[1:1:0712/003810.919127:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c6be9f22860","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003810.919455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://video.114la.com/","ptid":"631 0x7f1ed31ce960 0x3c3dd3e867e0 0x3c3dd3e867f0 ","rf":"5:3_http://video.114la.com/"}
[1:1:0712/003810.919890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://video.114la.com/ifr/?ch=8"
[1:1:0712/003810.920440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://video.114la.com/, 2c6be9f22860, , , () {
            if (params.loop) {
                _this.fixLoop();
                _this.swipeNext
[1:1:0712/003810.920636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://video.114la.com/ifr/?ch=8", "114la.com", 3, 1, , , 0
