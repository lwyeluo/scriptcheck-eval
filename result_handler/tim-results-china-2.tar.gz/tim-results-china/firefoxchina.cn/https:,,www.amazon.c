[0712/004145.112563:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004145.112970:INFO:switcher_clone.cc(787)] backtrace rip is 7f503fc28891
[0712/004146.072454:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004146.072791:INFO:switcher_clone.cc(787)] backtrace rip is 7f599d657891
[1:1:0712/004146.076930:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/004146.077107:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/004146.082257:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[43310:43310:0712/004147.452505:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/df095ec9-5d0e-4dcf-8728-4c38e5186165
[0712/004147.587487:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/004147.587866:INFO:switcher_clone.cc(787)] backtrace rip is 7fcb045e8891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[43344:43344:0712/004147.820349:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43344
[43355:43355:0712/004147.821404:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=43355
[43310:43310:0712/004148.052262:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[43310:43341:0712/004148.053411:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/004148.053748:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/004148.054007:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/004148.054609:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/004148.054756:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/004148.057815:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x9ef656d, 1
[1:1:0712/004148.058366:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1b0672f5, 0
[1:1:0712/004148.058629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xafcea13, 3
[1:1:0712/004148.058886:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x139a3c07, 2
[1:1:0712/004148.059261:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff572061b 6d65ffffffef09 073cffffff9a13 13ffffffeafffffffc0a , 10104, 4
[1:1:0712/004148.060812:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43310:43341:0712/004148.061201:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�rme�	<���
���
[43310:43341:0712/004148.061375:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �rme�	<���
����
[1:1:0712/004148.061192:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f599b8920a0, 3
[43310:43341:0712/004148.061659:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[43310:43341:0712/004148.061715:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43363, 4, f572061b 6d65ef09 073c9a13 13eafc0a 
[1:1:0712/004148.061562:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f599ba1d080, 2
[1:1:0712/004148.061817:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59856e0d20, -2
[1:1:0712/004148.094337:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/004148.095881:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 139a3c07
[1:1:0712/004148.097551:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 139a3c07
[1:1:0712/004148.100640:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 139a3c07
[1:1:0712/004148.101427:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.101579:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.101699:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.101835:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.102125:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 139a3c07
[1:1:0712/004148.102353:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599d6577ba
[1:1:0712/004148.102457:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f599d64edef, 7f599d65777a, 7f599d6590cf
[1:1:0712/004148.104517:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 139a3c07
[1:1:0712/004148.104731:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 139a3c07
[1:1:0712/004148.105091:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 139a3c07
[1:1:0712/004148.106059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.106196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.106367:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.106489:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 139a3c07
[1:1:0712/004148.107087:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 139a3c07
[1:1:0712/004148.107339:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599d6577ba
[1:1:0712/004148.107451:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f599d64edef, 7f599d65777a, 7f599d6590cf
[1:1:0712/004148.110543:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/004148.110848:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/004148.110966:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe7c9c3448, 0x7ffe7c9c33c8)
[1:1:0712/004148.129450:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/004148.136379:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[43310:43310:0712/004148.775159:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43310:43310:0712/004148.776314:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43310:43322:0712/004148.791550:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[43310:43322:0712/004148.791649:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[43310:43310:0712/004148.791822:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[43310:43310:0712/004148.791906:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[43310:43310:0712/004148.792052:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,43363, 4
[1:7:0712/004148.794117:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004148.825957:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x71ecb73220
[1:1:0712/004148.826577:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[43310:43334:0712/004148.831693:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/004149.053329:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[43310:43310:0712/004150.606018:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[43310:43310:0712/004150.606134:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/004150.631404:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004150.635104:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004151.560223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/004151.560537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004151.587528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/004151.587767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004151.619350:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004151.906718:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004151.906945:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004152.070862:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004152.073493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/004152.073612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004152.098156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004152.101274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/004152.101393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004152.105123:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/004152.110278:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x71ecb71e20
[1:1:0712/004152.110438:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[43310:43310:0712/004152.122561:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[43310:43310:0712/004152.137195:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[43310:43310:0712/004152.172092:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[43310:43310:0712/004152.172271:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[43310:43310:0712/004152.192357:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/004152.222776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004153.212596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f59872bb2e0 0x71ece084e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004153.213896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/004153.214084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004153.215592:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[43310:43310:0712/004153.287783:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004153.290116:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x71ecb72820
[1:1:0712/004153.291045:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[43310:43310:0712/004153.297447:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/004153.309230:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/004153.309484:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[43310:43310:0712/004153.340823:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[43310:43310:0712/004153.356716:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43310:43310:0712/004153.357764:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43310:43322:0712/004153.364078:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[43310:43322:0712/004153.364189:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[43310:43310:0712/004153.364293:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[43310:43310:0712/004153.364371:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[43310:43310:0712/004153.364511:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,43363, 4
[1:7:0712/004153.371777:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004154.002619:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/004154.320736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f59872bb2e0 0x71ecd9e0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004154.321830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/004154.322138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004154.322983:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[43310:43310:0712/004154.405342:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[43310:43310:0712/004154.405401:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/004154.428947:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004154.892029:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004155.189923:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004155.190215:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004155.649930:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004155.654464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 02ffbd48e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/004155.654749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/004155.662540:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[43310:43310:0712/004155.750079:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[43310:43341:0712/004155.750501:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/004155.750699:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/004155.750920:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/004155.751322:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/004155.751464:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/004155.754555:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3ea247c7, 1
[1:1:0712/004155.754905:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29cd89ed, 0
[1:1:0712/004155.755048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xa7e8e4, 3
[1:1:0712/004155.755202:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19a1513, 2
[1:1:0712/004155.755343:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffedffffff89ffffffcd29 ffffffc747ffffffa23e 1315ffffff9a01 ffffffe4ffffffe8ffffffa700 , 10104, 5
[1:1:0712/004155.756313:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[43310:43341:0712/004155.756567:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��)�G�>���
[43310:43341:0712/004155.756672:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��)�G�>���
[1:1:0712/004155.756559:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f599b8920a0, 3
[1:1:0712/004155.756778:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f599ba1d080, 2
[43310:43341:0712/004155.756947:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 43407, 5, ed89cd29 c747a23e 13159a01 e4e8a700 
[1:1:0712/004155.756985:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59856e0d20, -2
[1:1:0712/004155.777595:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/004155.777893:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19a1513
[1:1:0712/004155.778234:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19a1513
[1:1:0712/004155.778820:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19a1513
[1:1:0712/004155.780145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.780391:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.780564:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.780734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.781361:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19a1513
[1:1:0712/004155.781631:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599d6577ba
[1:1:0712/004155.781757:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f599d64edef, 7f599d65777a, 7f599d6590cf
[1:1:0712/004155.787285:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19a1513
[1:1:0712/004155.787632:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19a1513
[1:1:0712/004155.788339:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19a1513
[1:1:0712/004155.790253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.790392:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.790496:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.790592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19a1513
[1:1:0712/004155.791054:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19a1513
[1:1:0712/004155.791237:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599d6577ba
[1:1:0712/004155.791319:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f599d64edef, 7f599d65777a, 7f599d6590cf
[1:1:0712/004155.793708:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/004155.794056:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/004155.794142:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe7c9c3448, 0x7ffe7c9c33c8)
[1:1:0712/004155.804719:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/004155.809442:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/004155.812104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/004155.812832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 02ffbd361f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/004155.813058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/004156.067108:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004156.068843:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/004156.069099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 02ffbd48e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/004156.069399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/004156.087321:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x71ecb58220
[1:1:0712/004156.087727:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/004156.237641:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004156.239024:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/004156.240015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 02ffbd48e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/004156.240359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[43310:43310:0712/004156.484499:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[43310:43310:0712/004156.493486:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[43310:43322:0712/004156.506177:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[43310:43322:0712/004156.506275:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[43310:43310:0712/004156.506691:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.amazon.cn/
[43310:43310:0712/004156.506769:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.amazon.cn/, https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla, 1
[43310:43310:0712/004156.506907:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.amazon.cn/, HTTP/1.1 200 OK Server: Server Date: Fri, 12 Jul 2019 07:41:56 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Set-Cookie: session-id=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: session-id-time=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: session-token=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: ubid-acbcn=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: at-main=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: x-acbcn=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Set-Cookie: UserPref=-; path=/; domain=.www.amazon.cn; expires=Thu, 12-Jul-2007 07:41:56 GMT Strict-Transport-Security: max-age=47474747; includeSubDomains; preload Vary: Accept-Encoding,User-Agent,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment X-UA-Compatible: IE=edge Cache-Control: no-cache, no-transform Content-Encoding: gzip X-XSS-Protection: 1; X-Content-Type-Options: nosniff X-Frame-Options: SAMEORIGIN Set-Cookie: session-id=458-7161137-2864011; Domain=.amazon.cn; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: session-id-time=2082787201l; Domain=.amazon.cn; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: ubid-acbcn=460-7370190-1582939; Domain=.amazon.cn; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: session-token="F93ts13nMwAN+TvPIXlNu+01P2cIAtky1bzoM8AZ+O+j+AA/MbT2q6g5Y3miqyYKxlTNW4FZfctINcyw2vpuIty1G8CfqYIOTMTucGdklr5H9JFP06FSyMT42Cb6oYK6bFcGlKN8ECa30mcrdF5gaXchY+0l+SaOiVOhTNPgrvixfLQ5fVQCIz+5nWrxeAkiii75ugfYhO24G6FLeb1dyj20nNT35XCBH7fNVnI1FRLqgprEwUrNTg=="; Version=1; Domain=.amazon.cn; Max-Age=519869885; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: i18n-prefs=CNY; Domain=.amazon.cn; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ x-amz-rid: SKJ1J7PJZ9TEVY1GM86Q  ,43407, 5
[1:7:0712/004156.511159:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/004156.560809:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.amazon.cn/
[1:1:0712/004156.801027:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[43310:43310:0712/004156.808300:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.amazon.cn/, https://www.amazon.cn/, 1
[43310:43310:0712/004156.808436:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.amazon.cn/, https://www.amazon.cn
[1:1:0712/004156.875854:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004156.905366:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004156.971085:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004156.971419:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004156.989761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 129 0x7f5985393070 0x71ecca1ee0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004156.992310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , var ue_t0=ue_t0||+new Date();
[1:1:0712/004156.992611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004156.997449:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 129 0x7f5985393070 0x71ecca1ee0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004157.014752:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004157.049898:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 129 0x7f5985393070 0x71ecca1ee0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004157.210675:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/004157.324139:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004157.349519:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/004157.486233:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004157.523522:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/004157.627490:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004157.640265:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/004157.716872:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0712/004157.811118:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0712/004157.872848:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004157.876154:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/004157.948313:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/004158.301909:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004158.384219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004158.394208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
(function(g,h,Q,z){function G(a){x&&x.tag&&x.tag(q(":","aui",a))}function v(a,b){x&&x.count&&x.coun
[1:1:0712/004158.394447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004158.406903:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x312a5a828d78
[1:1:0712/004158.420256:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x4903e8029c8, 0x71ec9cc1b8
[1:1:0712/004158.420488:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 20
[1:1:0712/004158.421212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 219
[1:1:0712/004158.421431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 219 0x7f5985393070 0x71ecc97a60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 210 0x7f5985393070 0x71ecb696e0 
[1:1:0712/004158.543927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc1b8
[1:1:0712/004158.544223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004158.544919:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 221
[1:1:0712/004158.545146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 221 0x7f5985393070 0x71ecd54ce0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 210 0x7f5985393070 0x71ecb696e0 
[1:1:0712/004158.619505:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/004158.620422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 02ffbd48e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/004158.620651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004159.922207:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004159.922549:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004159.922785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004159.923030:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004159.923483:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[43310:43310:0712/004212.084177:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/004212.093884:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/004212.249059:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.254872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.265989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.271631:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.283774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.357289:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc1e0
[1:1:0712/004212.357593:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004212.358286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 283
[1:1:0712/004212.358544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 283 0x7f5985393070 0x71ecd52660 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 210 0x7f5985393070 0x71ecb696e0 
[1:1:0712/004212.383081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.387322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.393485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.397165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.400554:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.412603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.416673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.422279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.426298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.443379:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.457274:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.461549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.465304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.469124:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.473225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.476486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.479990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 210 0x7f5985393070 0x71ecb696e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004212.490022:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.292992, 52, 1
[1:1:0712/004212.490260:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004212.635209:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004212.722715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/004212.722988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004214.588116:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004214.588356:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.589472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f5985393070 0x71ece9f560 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.590746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , window.navmet.push({key:'Logo',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/004214.590985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004214.594537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f5985393070 0x71ece9f560 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.601193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f5985393070 0x71ece9f560 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.604945:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f5985393070 0x71ece9f560 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.627761:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.039052, 133, 1
[1:1:0712/004214.628078:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004214.629652:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 219, 7f5987cd8881
[1:1:0712/004214.637429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004214.637717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004214.638031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.638849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ia, (){h.body?p.trigger("a-bodyBegin"):setTimeout(ia,20)}
[1:1:0712/004214.639074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004214.644287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 221, 7f5987cd8881
[1:1:0712/004214.661324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004214.661659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004214.662045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004214.662873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004214.663104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004214.664418:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004214.664627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004214.665317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 390
[1:1:0712/004214.665545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 390 0x7f5985393070 0x71ecfd4560 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 221 0x7f5985393070 0x71ecd54ce0 
[1:1:0712/004215.022918:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004215.023507:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004215.658259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 283, 7f5987cd8881
[1:1:0712/004215.676966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004215.677281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"210 0x7f5985393070 0x71ecb696e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004215.677563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004215.678387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004215.678563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004215.722533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004215.722755:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004215.723403:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 424
[1:1:0712/004215.723600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7f5985393070 0x71ecfcf3e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 283 0x7f5985393070 0x71ecd52660 
[1:1:0712/004216.699174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004216.699550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004217.039493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004217.039813:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004217.041056:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7f5985393070 0x71ecfac260 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004217.042324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , window.navmet.push({key:'SearchBar',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/004217.042573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004217.048398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 388 0x7f5985393070 0x71ecfac260 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004217.055101:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.014868, 62, 1
[1:1:0712/004217.055319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004217.210754:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004218.256339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004218.256620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004218.283379:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 424, 7f5987cd8881
[1:1:0712/004218.304061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"283 0x7f5985393070 0x71ecd52660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004218.304379:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"283 0x7f5985393070 0x71ecd52660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004218.304671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.305541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004218.305756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004218.352833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004218.353121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004218.353797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 475
[1:1:0712/004218.354055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 475 0x7f5985393070 0x71ecf9c760 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 424 0x7f5985393070 0x71ecfcf3e0 
[1:1:0712/004218.466140:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.468365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (){clearTimeout(la);N=4;L()}
[1:1:0712/004218.468591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004218.470833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x4903e8029c8, 0x71ec9cc450
[1:1:0712/004218.471057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 16
[1:1:0712/004218.471715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 479
[1:1:0712/004218.471974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7f5985393070 0x71ed590de0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 456 0x7f59946a4960 0x71ed3fca60 0x71ed3fca70 
[1:1:0712/004218.589681:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004218.589959:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.591175:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f5985393070 0x71ecf9cf60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.592494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , window.navmet.push({key:'Tools',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/004218.592742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004218.598138:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f5985393070 0x71ecf9cf60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.603562:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f5985393070 0x71ecf9cf60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.607499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7f5985393070 0x71ecf9cf60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004218.633961:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0437849, 116, 1
[1:1:0712/004218.634393:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004218.753058:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/004218.973843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004218.974147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.052397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 479, 7f5987cd8881
[1:1:0712/004219.074742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"456 0x7f59946a4960 0x71ed3fca60 0x71ed3fca70 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.075109:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"456 0x7f59946a4960 0x71ed3fca60 0x71ed3fca70 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.075438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.076310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/004219.076527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.077613:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004219.077824:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 16
[1:1:0712/004219.078497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 514
[1:1:0712/004219.078814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 514 0x7f5985393070 0x71ed5f19e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 479 0x7f5985393070 0x71ed590de0 
[1:1:0712/004219.506027:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004219.506225:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.506848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.507504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , window.navmet.push({key:'Subnav',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/004219.507640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.509081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.510679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.512646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.514541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.517998:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.565311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.566685:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.567735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.568970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f5985393070 0x71ed5a0de0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.571555:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0651951, 61, 1
[1:1:0712/004219.571667:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004219.880338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004219.880576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.884438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 514, 7f5987cd8881
[1:1:0712/004219.908369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"479 0x7f5985393070 0x71ed590de0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.908729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"479 0x7f5985393070 0x71ed590de0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.909006:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.909846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/004219.910020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.911047:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004219.911205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 16
[1:1:0712/004219.911851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 554
[1:1:0712/004219.912036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7f5985393070 0x71ed600c60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 514 0x7f5985393070 0x71ed5f19e0 
[1:1:0712/004219.913367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 475, 7f5987cd8881
[1:1:0712/004219.937365:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"424 0x7f5985393070 0x71ecfcf3e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.937650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"424 0x7f5985393070 0x71ecfcf3e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004219.937933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004219.938742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004219.938925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004219.993652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004219.993836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004219.994096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 555
[1:1:0712/004219.994205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7f5985393070 0x71ecd5de60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 475 0x7f5985393070 0x71ecf9c760 
[1:1:0712/004220.432491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.433522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , i.onload, () {window.uet && uet('ne')}
[1:1:0712/004220.433748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004220.636867:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004220.637113:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.638356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f5985393070 0x71ed6249e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.640055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ,  

(typeof setCSMReq === 'function') && setCSMReq("x1");

                if(typeof uet === 'functio
[1:1:0712/004220.640301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004220.643921:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc198
[1:1:0712/004220.644154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004220.644869:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 573
[1:1:0712/004220.645109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f5985393070 0x71ed01a1e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 546 0x7f5985393070 0x71ed6249e0 
[1:1:0712/004220.649119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f5985393070 0x71ed6249e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.652314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f5985393070 0x71ed6249e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.676104:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.038595, 155, 1
[1:1:0712/004220.676376:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004220.753635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004220.753894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004220.757670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 554, 7f5987cd8881
[1:1:0712/004220.774644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"514 0x7f5985393070 0x71ed5f19e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004220.774989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"514 0x7f5985393070 0x71ed5f19e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004220.775321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004220.776222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/004220.776516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004220.777631:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004220.777843:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 16
[1:1:0712/004220.778570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 585
[1:1:0712/004220.778810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 585 0x7f5985393070 0x71ed6be260 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 554 0x7f5985393070 0x71ed600c60 
[1:1:0712/004221.043474:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://images-cn.ssl-images-amazon.com/images/G/28/digital/fiona/general/green-fade-background.jpg"
[1:1:0712/004221.454286:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004221.454546:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.456200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7f5985393070 0x71ed0330e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.457661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
        P.when("jQuery","quanityChangePriceUpdate").execute(function ($,quanityChangePriceUpdate) {
[1:1:0712/004221.457885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004221.465487:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7f5985393070 0x71ed0330e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.477028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 581 0x7f5985393070 0x71ed0330e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.497207:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.042269, 144, 1
[1:1:0712/004221.497508:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004221.510707:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 573, 7f5987cd8881
[1:1:0712/004221.537364:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"546 0x7f5985393070 0x71ed6249e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.537737:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"546 0x7f5985393070 0x71ed6249e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.538068:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.538947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004221.539164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004221.540189:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004221.540390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004221.541070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 612
[1:1:0712/004221.541297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f5985393070 0x71ecd4bf60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 573 0x7f5985393070 0x71ed01a1e0 
[1:1:0712/004221.569245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004221.569541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004221.573125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 585, 7f5987cd8881
[1:1:0712/004221.602244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"554 0x7f5985393070 0x71ed600c60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.602609:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"554 0x7f5985393070 0x71ed600c60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.602986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.603996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/004221.604247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004221.617177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 555, 7f5987cd8881
[1:1:0712/004221.635636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"475 0x7f5985393070 0x71ecf9c760 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.636003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"475 0x7f5985393070 0x71ecf9c760 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004221.636336:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004221.637218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004221.637432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004221.664614:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004221.664898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004221.665584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 614
[1:1:0712/004221.665826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f5985393070 0x71ed6c8560 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 555 0x7f5985393070 0x71ecd5de60 
[1:1:0712/004222.407299:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004222.407519:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004222.410686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7f5985393070 0x71ed590760 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004222.412185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(f) {var _np=(window.P._namespace("list-CF-register-js"));if(_np.guardFatal){_np.guardFatal
[1:1:0712/004222.412386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004222.418996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc1a8
[1:1:0712/004222.419166:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004222.419787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 636
[1:1:0712/004222.420020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7f5985393070 0x71ed590960 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 610 0x7f5985393070 0x71ed590760 
[1:1:0712/004222.427217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7f5985393070 0x71ed590760 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004222.446778:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0388732, 104, 1
[1:1:0712/004222.447038:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004222.477578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004222.477808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004223.442222:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004223.442548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004223.443888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7f5985393070 0x71ed600f60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004223.445286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
                            if (typeof uet == 'function') {
                                uet('be
[1:1:0712/004223.445884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004223.455165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7f5985393070 0x71ed600f60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004223.494030:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.051013, 116, 1
[1:1:0712/004223.494276:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004223.528562:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 636, 7f5987cd8881
[1:1:0712/004223.558182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"610 0x7f5985393070 0x71ed590760 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004223.558525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"610 0x7f5985393070 0x71ed590760 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004223.558893:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004223.559931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004223.560174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004223.561121:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004223.561333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004223.561991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 672
[1:1:0712/004223.562255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 672 0x7f5985393070 0x71ecbca8e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 636 0x7f5985393070 0x71ed590960 
[1:1:0712/004223.652257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004223.652651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004223.656137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 614, 7f5987cd8881
[1:1:0712/004223.685376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"555 0x7f5985393070 0x71ecd5de60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004223.685820:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"555 0x7f5985393070 0x71ecd5de60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004223.686274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004223.687202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004223.687534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004223.757357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004223.757730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004223.758589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 675
[1:1:0712/004223.759129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f5985393070 0x71eda18fe0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 614 0x7f5985393070 0x71ed6c8560 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004224.525856:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004224.526123:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004224.527493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f5985393070 0x71ecf589e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004224.529562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 




(function(){
    var insertCenterColStyle = function(width) {
        var totalWidth = width + 
[1:1:0712/004224.529785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004224.543794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f5985393070 0x71ecf589e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004224.550934:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.024374, 59, 1
[1:1:0712/004224.551162:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004224.646424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004224.646743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004225.405958:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004225.406222:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004225.407503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7f5985393070 0x71ecd4d760 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004225.408909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
                    P.when('A', 'ready').execute(function(A) {
                        A.declarativ
[1:1:0712/004225.409137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004225.413837:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7f5985393070 0x71ecd4d760 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004225.425370:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7f5985393070 0x71ecd4d760 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004225.435212:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.028537, 53, 1
[1:1:0712/004225.435444:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004225.500047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004225.500348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004225.535738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 675, 7f5987cd8881
[1:1:0712/004225.567514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"614 0x7f5985393070 0x71ed6c8560 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004225.567884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"614 0x7f5985393070 0x71ed6c8560 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004225.568207:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004225.569092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004225.569320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004225.610652:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004225.610930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004225.611614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 732
[1:1:0712/004225.612011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f5985393070 0x71ed6b1660 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 675 0x7f5985393070 0x71eda18fe0 
[1:1:0712/004226.565714:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004226.566011:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004226.567297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 729 0x7f5985393070 0x71ed678260 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004226.568954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
if (window.P) {
    P.when('A', 'jQuery', 'ready').execute(function(A, jQuery){
        var badge_r
[1:1:0712/004226.569283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004226.579547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 729 0x7f5985393070 0x71ed678260 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004226.594639:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0282221, 159, 1
[1:1:0712/004226.594891:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004226.631760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004226.632657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004227.546726:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004227.546999:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004227.580593:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0332041, 193, 1
[1:1:0712/004227.580870:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004227.651260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004227.651497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004227.654956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 732, 7f5987cd8881
[1:1:0712/004227.688358:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"675 0x7f5985393070 0x71eda18fe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004227.688665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"675 0x7f5985393070 0x71eda18fe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004227.688947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004227.689810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004227.689986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004227.768095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004227.768388:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004227.769157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 780
[1:1:0712/004227.769368:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f5985393070 0x71ed8f7ee0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 732 0x7f5985393070 0x71ed6b1660 
[1:1:0712/004228.469200:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004228.469464:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.471032:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.474130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
P.when("A","jQuery","cf").execute(function(A,$){
    window.registeredDDMCountdown || P.register("D
[1:1:0712/004228.474361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004228.478311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.484465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.491473:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.497009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.502795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.509267:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f5985393070 0x71ecf58e60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004228.528455:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.058661, 58, 1
[1:1:0712/004228.528788:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004228.543571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004228.543881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004229.282287:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004229.282551:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004229.284431:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7f5985393070 0x71ecc94360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004229.286392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
P.register("DynamicIframe", function(){

function DynamicIframe(options) {
  
  var nTries = 0,
   
[1:1:0712/004229.286640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004229.288718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc1a0
[1:1:0712/004229.288913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004229.289539:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 831
[1:1:0712/004229.289786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f5985393070 0x71edc26260 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 811 0x7f5985393070 0x71ecc94360 
[1:1:0712/004229.296029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7f5985393070 0x71ecc94360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004229.302643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 811 0x7f5985393070 0x71ecc94360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004229.308812:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.025867, 54, 1
[1:1:0712/004229.309064:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004229.347209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004229.347490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004229.350827:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 780, 7f5987cd8881
[1:1:0712/004229.379128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"732 0x7f5985393070 0x71ed6b1660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004229.379477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"732 0x7f5985393070 0x71ed6b1660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004229.379859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004229.380728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004229.380942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004229.451160:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004229.451457:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004229.452193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 844
[1:1:0712/004229.452439:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f5985393070 0x71ed09bde0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 780 0x7f5985393070 0x71ed8f7ee0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004230.185292:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004230.185555:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004230.186962:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 841 0x7f5985393070 0x71ecf1ce60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004230.189665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
    P.when('jQuery').execute(function(jQuery) {

     window.sitbWeblab = '';
     var postReftags 
[1:1:0712/004230.189979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004230.195335:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 841 0x7f5985393070 0x71ecf1ce60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004230.211270:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.025327, 68, 1
[1:1:0712/004230.211558:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004230.241174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 831, 7f5987cd8881
[1:1:0712/004230.285710:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"811 0x7f5985393070 0x71ecc94360 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004230.286120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"811 0x7f5985393070 0x71ecc94360 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004230.286452:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004230.287341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004230.287569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004230.288833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004230.289085:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004230.289806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 868
[1:1:0712/004230.290089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f5985393070 0x71ed678c60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 831 0x7f5985393070 0x71edc26260 
[43310:43310:0712/004230.298540:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004230.303203:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x71ed137420
[1:1:0712/004230.303949:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[43310:43310:0712/004230.305586:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[43310:43310:0712/004230.362867:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.amazon.cn/, https://www.amazon.cn/, 4
[43310:43310:0712/004230.363066:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.amazon.cn/, https://www.amazon.cn
[1:1:0712/004230.375009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004230.377241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x4903e8029c8, 0x71ec9cc278
[1:1:0712/004230.377470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 20
[1:1:0712/004230.378252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 882
[1:1:0712/004230.378493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f5985393070 0x71ecfe1360 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 831 0x7f5985393070 0x71edc26260 
[1:1:0712/004230.415768:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004230.421827:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 394b2553ae28, 5:3_https://www.amazon.cn/, 5:4_https://www.amazon.cn/, about:blank
[1:1:0712/004230.422144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/, 394b2553ae28, 394b25482860, open, 
[1:1:0712/004230.422452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.amazon.cn", 4, 2, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004230.423655:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	DynamicIframe.createIframe (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004230.426420:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b2553ae28, getElementById, 
[1:1:0712/004230.426557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 3, , , 0
[1:1:0712/004230.427052:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	DynamicIframe.createIframe (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004230.427540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/, 394b2553ae28, 394b25482860, writeln, 
[1:1:0712/004230.427690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 4, 4, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004230.428117:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	DynamicIframe.createIframe (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004230.442163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b2553ae28, pop, 
[1:1:0712/004230.442361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 5, , , 0
[1:1:0712/004230.442729:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12267:32
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004230.483227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004230.483480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004231.441112:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004231.441390:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004231.492556:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0508161, 397, 1
[1:1:0712/004231.492861:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004231.836825:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 868, 7f5987cd8881
[1:1:0712/004231.876006:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"831 0x7f5985393070 0x71edc26260 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004231.876430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"831 0x7f5985393070 0x71edc26260 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004231.876852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004231.877743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004231.877966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004231.878954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004231.879153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004231.879827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 929
[1:1:0712/004231.880073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f5985393070 0x71ed2646e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 868 0x7f5985393070 0x71ed678c60 
[1:1:0712/004231.925556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 882, 7f5987cd8881
[1:1:0712/004231.965498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"831 0x7f5985393070 0x71edc26260 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004231.965853:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"831 0x7f5985393070 0x71edc26260 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004231.966266:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004231.967123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , () {
      setIframeHeight(initialResizeCallback);
    }
[1:1:0712/004231.967376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004231.969735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/, 394b2553ae28, 394b25482860, getElementById, 
[1:1:0712/004231.970014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 4, 2, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004231.970967:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	getDocHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	setIframeHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32

[1:1:0712/004232.456430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b2553ae28, max, 
[1:1:0712/004232.456746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 3, , , 0
[1:1:0712/004232.457746:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	getDocHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	setIframeHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32

[1:1:0712/004232.667796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 844, 7f5987cd8881
[1:1:0712/004232.707740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"780 0x7f5985393070 0x71ed8f7ee0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004232.708100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"780 0x7f5985393070 0x71ed8f7ee0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004232.708519:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004232.709372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004232.709608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004232.811731:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004232.812022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004232.812740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 941
[1:1:0712/004232.812981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7f5985393070 0x71ecfbae60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 844 0x7f5985393070 0x71ed09bde0 
[1:1:0712/004232.908020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004232.908313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004234.155233:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004234.155472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004234.157181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 925 0x7f5985393070 0x71ecfd48e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004234.158757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
  var csrfParamsJson = {"csrf_rnd":"0sZgbk7fh9q2BCLlU3","csrf_token":"gGkH0gKkIzPELDTfYMKCu1fcjxSK3
[1:1:0712/004234.158904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004234.167998:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0119529, 87, 1
[1:1:0712/004234.168131:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004234.461482:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[43310:43310:0712/004234.569260:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/004234.812816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004234.813083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004234.859954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 941, 7f5987cd8881
[1:1:0712/004234.903837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"844 0x7f5985393070 0x71ed09bde0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004234.904169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"844 0x7f5985393070 0x71ed09bde0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004234.904548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004234.905384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004234.905562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004234.963643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004234.963810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004234.964096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 991
[1:1:0712/004234.964216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f5985393070 0x71ed9eebe0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 941 0x7f5985393070 0x71ecfbae60 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004236.261536:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004236.261758:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004236.263469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f5985393070 0x71ecf57360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004236.266642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 

  var emailSmartLink_, smsSmartLink_;
  if(window.P && window.P.AUI_BUILD_DATE) {
    P.when('A', 
[1:1:0712/004236.266832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004236.288103:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0259552, 137, 1
[1:1:0712/004236.288324:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004236.604961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 979 0x7f59872bb2e0 0x71ed2683e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004236.614935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(p){var k=window.AmazonUIPageJS||window.P,t=k._namespace||k.attributeErrors,r=t?t("AmazonPo
[1:1:0712/004236.615173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004236.870613:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004236.871646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , DynamicIframe.iframeload, () {
    var iframe = document.getElementById(iframeId);
    iframe.style.display = '';
    setTimeo
[1:1:0712/004236.871858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004236.873015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x4903e8029c8, 0x71ec9cc210
[1:1:0712/004236.873178:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 20
[1:1:0712/004236.873815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1027
[1:1:0712/004236.874025:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7f5985393070 0x71ee434060 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 987 0x7f5985393070 0x71ec668e60 
[1:1:0712/004236.925099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004236.925368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004237.309742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 991, 7f5987cd8881
[1:1:0712/004237.324213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"941 0x7f5985393070 0x71ecfbae60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004237.324403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"941 0x7f5985393070 0x71ecfbae60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004237.324640:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004237.325022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004237.325137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004237.411213:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004237.411442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004237.412150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1036
[1:1:0712/004237.412350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1036 0x7f5985393070 0x71ee431060 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 991 0x7f5985393070 0x71ed9eebe0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004238.528159:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004238.528454:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004238.529505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1017 0x7f5985393070 0x71ee1d43e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004238.531466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
    P.now("A","tellMeMoreLinkData").execute(function(A,tellMeMoreLinkData){
        if(typeof tellM
[1:1:0712/004238.531743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004238.571982:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.043164, 298, 1
[1:1:0712/004238.572251:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004238.952851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1027, 7f5987cd8881
[1:1:0712/004238.980477:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"987 0x7f5985393070 0x71ec668e60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004238.980832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"987 0x7f5985393070 0x71ec668e60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004238.981259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004238.982182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , () {
      setIframeHeight(initialResizeCallback);
    }
[1:1:0712/004238.982484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004238.984557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/, 394b2553ae28, 394b25482860, getElementById, 
[1:1:0712/004238.984900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 4, 2, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004238.985810:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	getDocHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	setIframeHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32

[1:1:0712/004239.713869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.amazon.cn/-5:4_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b2553ae28, max, 
[1:1:0712/004239.714187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 3, , , 0
[1:1:0712/004239.715137:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	getDocHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	setIframeHeight (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:12049:32

[1:1:0712/004239.818053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004239.818397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004240.170082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1036, 7f5987cd8881
[1:1:0712/004240.196262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"991 0x7f5985393070 0x71ed9eebe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004240.196661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"991 0x7f5985393070 0x71ed9eebe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004240.197077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004240.197944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004240.198169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004240.326550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004240.326830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004240.327529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1086
[1:1:0712/004240.327804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f5985393070 0x71ee18b660 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1036 0x7f5985393070 0x71ee431060 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004240.873707:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004240.873979:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004240.875309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1065 0x7f5985393070 0x71ee4aee60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004240.876767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
        P.when('jQuery', 'cf').execute(function($) {
            var jQuery = $;
            var di
[1:1:0712/004240.877049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004240.888868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1065 0x7f5985393070 0x71ee4aee60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004240.914990:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.040673, 183, 1
[1:1:0712/004240.915329:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004241.136796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004241.137078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004242.483699:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004242.483984:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004242.485280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1111 0x7f5985393070 0x71ee1d8660 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004242.486713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , if (typeof uet === 'function' && typeof ues === 'function') {var scope = 'Detail_customer-reviews-to
[1:1:0712/004242.486983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004242.493035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1111 0x7f5985393070 0x71ee1d8660 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004242.730246:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.24587, 1065, 1
[1:1:0712/004242.730522:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004243.126082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004243.126452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004243.130201:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1086, 7f5987cd8881
[1:1:0712/004243.180723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1036 0x7f5985393070 0x71ee431060 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004243.181078:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1036 0x7f5985393070 0x71ee431060 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004243.181524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004243.182475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004243.182699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004243.275497:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004243.275767:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004243.276439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1176
[1:1:0712/004243.276679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f5985393070 0x71ed6bf8e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1086 0x7f5985393070 0x71ee18b660 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004246.094083:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004246.094333:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.095639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.097417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , 
var isAUI = typeof P === 'object' && typeof P.when === 'function';
  if(typeof setCSMReq == 'functi
[1:1:0712/004246.097668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004246.101035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc198
[1:1:0712/004246.101242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004246.101913:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1210
[1:1:0712/004246.102154:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1210 0x7f5985393070 0x71ee6ecb60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1162 0x7f5985393070 0x71edfe63e0 
[1:1:0712/004246.104671:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.111757:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.121301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.133519:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.150507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.163707:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.178767:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1162 0x7f5985393070 0x71edfe63e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.213261:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.11852, 318, 1
[1:1:0712/004246.213518:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/004246.326692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1165 0x7f59872bb2e0 0x71ed0690e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.339149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(f){var g=window.AmazonUIPageJS||window.P,e=g._namespace||g.attributeErrors,b=e?e("Customer
[1:1:0712/004246.339450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004246.505921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1166 0x7f59872bb2e0 0x71ee018360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004246.520852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , !function o(r,s,d){function c(t,e){if(!s[t]){if(!r[t]){var a="function"==typeof require&&require;if(
[1:1:0712/004246.521147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004246.888914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004246.889212:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004247.081270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1176, 7f5987cd8881
[1:1:0712/004247.147007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1086 0x7f5985393070 0x71ee18b660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004247.147390:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1086 0x7f5985393070 0x71ee18b660 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004247.147755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004247.148627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004247.148808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004247.211439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004247.211721:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004247.212424:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1258
[1:1:0712/004247.212656:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1258 0x7f5985393070 0x71ee6972e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1176 0x7f5985393070 0x71ed6bf8e0 
[1:1:0712/004247.499738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1206 0x7f59872bb2e0 0x71ee68c860 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004247.530185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , /*
 jQuery JavaScript Library v1.6.4
 http://jquery.com/

 Copyright 2011, John Resig
 Dual licensed
[1:1:0712/004247.530477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004250.843066:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/004250.843335:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004250.844653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004250.846145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(a,b){a.attachEvent?a.attachEvent("onload",b):a.addEventListener&&a.addEventListener("load"
[1:1:0712/004250.846386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004250.849781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004250.983308:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/004250.988284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004250.994047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004250.998272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.001364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.007251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.021015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.028339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.043737:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc1d0
[1:1:0712/004251.043978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004251.044653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1333
[1:1:0712/004251.044877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1333 0x7f5985393070 0x71eeadfae0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.046976:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600000, 0x4903e8029c8, 0x71ec9cc1d0
[1:1:0712/004251.047187:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 600000
[1:1:0712/004251.047842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1334
[1:1:0712/004251.048081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1334 0x7f5985393070 0x71ee6abb60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.049128:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x4903e8029c8, 0x71ec9cc1d0
[1:1:0712/004251.049321:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 3000
[1:1:0712/004251.050123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1335
[1:1:0712/004251.050348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7f5985393070 0x71edef9de0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.088346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x4903e8029c8, 0x71ec9cc1d0
[1:1:0712/004251.088608:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 500
[1:1:0712/004251.089292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1336
[1:1:0712/004251.089538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1336 0x7f5985393070 0x71eeab98e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.135705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 3000
[1:1:0712/004251.136457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.cn/, 1337
[1:1:0712/004251.136692:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f5985393070 0x71edfe12e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.141182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.152732:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x312a5a928aa0
[1:1:0712/004251.158538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.162814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.171589:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.177074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.185617:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.201108:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.204981:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.211118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.218921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.224244:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x4903e8029c8, 0x71ec9cc1a0
[1:1:0712/004251.224460:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 5000
[1:1:0712/004251.225113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1360
[1:1:0712/004251.225383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1360 0x7f5985393070 0x71eec3d2e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.228539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.249472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.276327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.296519:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.306357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x4903e8029c8, 0x71ec9cc1a0
[1:1:0712/004251.306591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 10000
[1:1:0712/004251.307267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1370
[1:1:0712/004251.307494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7f5985393070 0x71ec6bee60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1237 0x7f5985393070 0x71ee1120e0 
[1:1:0712/004251.318111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1237 0x7f5985393070 0x71ee1120e0 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.333991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.349257:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.578929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1210, 7f5987cd8881
[1:1:0712/004251.636855:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1162 0x7f5985393070 0x71edfe63e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004251.637259:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1162 0x7f5985393070 0x71edfe63e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004251.637679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004251.638503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004251.638713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004251.639658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004251.639882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004251.640545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1381
[1:1:0712/004251.640770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7f5985393070 0x71ecfd4fe0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1210 0x7f5985393070 0x71ee6ecb60 
		remove user.10_25819cc5 -> 0
		remove user.11_ec5ca261 -> 0
		remove user.12_f89fadc2 -> 0
[1:1:0712/004252.194736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1252 0x7f59872bb2e0 0x71edffac60 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004252.197549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(e){var f=window.AmazonUIPageJS||window.P,h=f._namespace||f.attributeErrors,b=h?h("DetailPa
[1:1:0712/004252.197791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004252.371542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004252.371732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004252.410722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1258, 7f5987cd8881
[1:1:0712/004252.429885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1176 0x7f5985393070 0x71ed6bf8e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004252.430070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1176 0x7f5985393070 0x71ed6bf8e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004252.430294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004252.430686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004252.430794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004252.490493:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004252.490654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004252.490895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1404
[1:1:0712/004252.491013:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7f5985393070 0x71eed519e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1258 0x7f5985393070 0x71ee6972e0 
[1:1:0712/004253.622232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1333, 7f5987cd8881
[1:1:0712/004253.640619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.640818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.641020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004253.641391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , l, (){var a=b.length;if(0<a){for(var f=[],c=0;c<a;c++){var g=b[c].api;g.ready()?(g.on({ts:e.d,ns:n}),d.
[1:1:0712/004253.641495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004253.661036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1336, 7f5987cd8881
[1:1:0712/004253.679315:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.679484:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.679683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004253.680074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (){s(function(){f.executed||
a()})}
[1:1:0712/004253.680180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004253.681331:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1381, 7f5987cd8881
[1:1:0712/004253.722657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1210 0x7f5985393070 0x71ee6ecb60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.722976:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1210 0x7f5985393070 0x71ee6ecb60 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004253.723360:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004253.724204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004253.724393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004253.725331:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004253.725490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004253.726144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1430
[1:1:0712/004253.726337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1430 0x7f5985393070 0x71ee6fdc60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1381 0x7f5985393070 0x71ecfd4fe0 
[1:1:0712/004253.758065:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[43310:43310:0712/004253.774451:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004253.776692:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x71ed36a820
[1:1:0712/004253.776946:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[43310:43310:0712/004253.781133:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[43310:43310:0712/004253.817482:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://www.amazon.cn/, https://www.amazon.cn/, 5
[43310:43310:0712/004253.817609:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://www.amazon.cn/, https://www.amazon.cn
[1:1:0712/004253.865430:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 394b254d4300, 5:3_https://www.amazon.cn/, 5:5_https://www.amazon.cn/, about:blank
[1:1:0712/004253.865666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/, 394b254d4300, 394b25482860, , void(false)
[1:1:0712/004253.865919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.amazon.cn", 5, 2, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004253.873526:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLBodyElement.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.domManip (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.prepend (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.c.fn.(anonymous function) [as prependTo] (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004253.873962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b254d4300, push, 
[1:1:0712/004253.874167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 3, , , 0
[1:1:0712/004253.877059:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004253.880453:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[43310:43310:0712/004253.891654:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/004253.893897:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x71ed71fe20
[1:1:0712/004253.894086:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[43310:43310:0712/004253.898836:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[43310:43310:0712/004253.938879:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://www.amazon.cn/, https://www.amazon.cn/, 6
[43310:43310:0712/004253.939017:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://www.amazon.cn/, https://www.amazon.cn
[1:1:0712/004253.983060:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 394b254dbb28, 5:3_https://www.amazon.cn/, 5:6_https://www.amazon.cn/, about:blank
[1:1:0712/004253.983338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:6_https://www.amazon.cn/, 394b254dbb28, 394b25482860, , void(false)
[1:1:0712/004253.983653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.amazon.cn", 6, 4, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004253.989857:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLBodyElement.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.domManip (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.prepend (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.c.fn.(anonymous function) [as prependTo] (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004253.990403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:6_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b254dbb28, push, 
[1:1:0712/004253.990697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 5, , , 0
[1:1:0712/004253.994240:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004254.001147:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x71ed3f1220
[1:1:0712/004254.001697:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[43310:43310:0712/004254.003677:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[43310:43310:0712/004254.010277:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[43310:43310:0712/004254.044858:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://www.amazon.cn/, https://www.amazon.cn/, 7
[43310:43310:0712/004254.044991:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://www.amazon.cn/, https://www.amazon.cn
[1:1:0712/004254.088331:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 394b254a53b8, 5:3_https://www.amazon.cn/, 5:7_https://www.amazon.cn/, about:blank
[1:1:0712/004254.088568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:6_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:7_https://www.amazon.cn/, 394b254a53b8, 394b25482860, , void(false)
[1:1:0712/004254.088875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.amazon.cn", 7, 6, https://www.amazon.cn, www.amazon.cn, 3
[1:1:0712/004254.093890:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLBodyElement.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.domManip (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.prepend (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.c.fn.(anonymous function) [as prependTo] (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

[1:1:0712/004254.094301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_https://www.amazon.cn/-5:5_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:6_https://www.amazon.cn/-5:3_https://www.amazon.cn/-5:7_https://www.amazon.cn/-5:3_https://www.amazon.cn/, 394b25482860, 394b254a53b8, push, 
[1:1:0712/004254.094559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 7, , , 0
[1:1:0712/004254.097444:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	HTMLDocument.<anonymous> (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	Object.resolveWith (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	Object.done (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	init.ready (https://images-cn.ssl-images-amazon.com/images/I/61kzhTBl2qL._RC%7C11-BZEJ8lnL.js,61GQ9IdK7HL.js,21Of0-9HPCL.js,012FVc3131L.js,119KAWlHU6L.js,51xL2QLv4YL.js,11AHlQhPRjL.js,016iHgpF74L.js,11aNYFFS5hL.js,116tgw9TSaL.js,211-p4GRUCL.js,01PoLXBDXWL.js,61BanVD+50L.js,01mi-J86cyL.js,11BOgvnnntL.js,31UWuPgtTtL.js,01rpauTep4L.js,01iyxuSGj4L.js,01OWoGffjKL.js_.js?AUIClients/AmazonUI:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	r (https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1)
	https://images-cn.ssl-images-amazon.com/images/I/41U2SW8-HYL.js?AUIClients/AmazonPopoversAUIShim:1:1
	m (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)
	https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9
	ba (https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla:386:9)

context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/004254.894089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004254.895093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , b, (d,h){var n,m,r,w,v;try{if(b&&(h||4===f.readyState))if(b=p,g&&(f.onreadystatechange=c.noop,wa&&delet
[1:1:0712/004254.895291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004254.896758:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004254.899818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004254.900798:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x312a5a9316b0
[1:1:0712/004255.104760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , document.readyState
[1:1:0712/004255.104937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004255.425956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1404, 7f5987cd8881
[1:1:0712/004255.490949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1258 0x7f5985393070 0x71ee6972e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004255.491361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1258 0x7f5985393070 0x71ee6972e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004255.491842:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004255.492903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/004255.493128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004255.606077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004255.606282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 1000
[1:1:0712/004255.606551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1502
[1:1:0712/004255.606671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1502 0x7f5985393070 0x71eedf04e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1404 0x7f5985393070 0x71eed519e0 
[1:1:0712/004255.933984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (){f.executed||
a()}
[1:1:0712/004255.934306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004255.961948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x4903e8029c8, 0x71ec9cc168
[1:1:0712/004255.962228:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 500
[1:1:0712/004255.962566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1513
[1:1:0712/004255.962698:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1513 0x7f5985393070 0x71ee433460 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1429 0x7f59946a4960 0x71eeab6a60 0x71eeab6a70 
[1:1:0712/004257.549400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1430, 7f5987cd8881
[1:1:0712/004257.613355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1381 0x7f5985393070 0x71ecfd4fe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004257.613663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1381 0x7f5985393070 0x71ecfd4fe0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004257.614035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004257.614878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/004257.615057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004257.616015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004257.616182:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 0
[1:1:0712/004257.616837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1545
[1:1:0712/004257.617034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1545 0x7f5985393070 0x71eed4f5e0 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1430 0x7f5985393070 0x71ee6fdc60 
[1:1:0712/004257.669422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1335, 7f5987cd8881
[1:1:0712/004257.713143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004257.713853:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004257.714654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004257.716604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (){q(!0)}
[1:1:0712/004257.717054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004257.726592:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x4903e8029c8, 0x71ec9cc150
[1:1:0712/004257.727093:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 4500
[1:1:0712/004257.727871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.cn/, 1548
[1:1:0712/004257.728076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1548 0x7f5985393070 0x71ee695f60 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1335 0x7f5985393070 0x71edef9de0 
[1:1:0712/004258.258043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.cn/, 1337, 7f5987cd88db
[1:1:0712/004258.285192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"394b25482860","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004258.285397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.cn/","ptid":"1237 0x7f5985393070 0x71ee1120e0 ","rf":"5:3_https://www.amazon.cn/"}
[1:1:0712/004258.285633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.cn/, 1556
[1:1:0712/004258.285753:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1556 0x7f5985393070 0x71ed423360 , 5:3_https://www.amazon.cn/, 0, , 1337 0x7f5985393070 0x71edfe12e0 
[1:1:0712/004258.286003:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004258.286436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , f, (){if(s.length){y=G.now();for(var a=0;a<s.length;a++){var b=s[a],c=a;p=s[E];D=b;var d=void 0;if(!(d=
[1:1:0712/004258.286548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[43310:43310:0712/004258.313131:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/004258.884539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1497 0x7f59872bb2e0 0x71eedf1360 , "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla"
[1:1:0712/004259.036382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.cn/, 394b25482860, , , (function(f){var e=window.AmazonUIPageJS||window.P,l=e._namespace||e.attributeErrors,c=l?l("CommonDe
[1:1:0712/004259.036630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", "www.amazon.cn", 3, 1, , , 0
[1:1:0712/004259.232377:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.cn/dp/B071SDP8PC/ref=zg_bs_books_3/459-8251960-6993825?_encoding=UTF8&psc=1&refRID=CVZR6JMAEV77SRG0X9PN&tag=Mozilla", 250
[1:1:0712/004259.233088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.cn/, 1563
[1:1:0712/004259.233300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1563 0x7f5985393070 0x71ecbef060 , 5:3_https://www.amazon.cn/, 1, -5:3_https://www.amazon.cn/, 1497 0x7f59872bb2e0 0x71eedf1360 
