[0712/095546.039106:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095546.039485:INFO:switcher_clone.cc(787)] backtrace rip is 7f8252db1891
[0712/095546.872919:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095546.873351:INFO:switcher_clone.cc(787)] backtrace rip is 7f4f01b4b891
[1:1:0712/095546.886759:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/095546.887014:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/095546.896392:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[120176:120176:0712/095548.001863:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/89c62883-bf1b-4536-ab77-b2ba91c86d18
[0712/095548.176118:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/095548.176423:INFO:switcher_clone.cc(787)] backtrace rip is 7fa805d66891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[120207:120207:0712/095548.433032:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=120207
[120219:120219:0712/095548.433421:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=120219
[120176:120176:0712/095548.548341:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[120176:120204:0712/095548.549123:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/095548.549334:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095548.549594:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095548.550335:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095548.550543:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/095548.553440:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2c2bbd04, 1
[1:1:0712/095548.553772:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f67fbfd, 0
[1:1:0712/095548.553927:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x285a3cc8, 3
[1:1:0712/095548.554082:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x22678259, 2
[1:1:0712/095548.554267:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffdfffffffb671f 04ffffffbd2b2c 59ffffff826722 ffffffc83c5a28 , 10104, 4
[1:1:0712/095548.555157:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[120176:120204:0712/095548.555386:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��g�+,Y�g"�<Z(��T
[120176:120204:0712/095548.555453:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��g�+,Y�g"�<Z(8���T
[1:1:0712/095548.555372:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4effd860a0, 3
[1:1:0712/095548.555570:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4efff11080, 2
[120176:120204:0712/095548.555774:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/095548.555749:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ee9bd4d20, -2
[120176:120204:0712/095548.555848:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 120227, 4, fdfb671f 04bd2b2c 59826722 c83c5a28 
[1:1:0712/095548.573857:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095548.574651:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22678259
[1:1:0712/095548.575677:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22678259
[1:1:0712/095548.577279:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22678259
[1:1:0712/095548.578739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.578919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.579099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.579285:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.579922:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22678259
[1:1:0712/095548.580237:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4f01b4b7ba
[1:1:0712/095548.580365:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4f01b42def, 7f4f01b4b77a, 7f4f01b4d0cf
[1:1:0712/095548.587181:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 22678259
[1:1:0712/095548.587613:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 22678259
[1:1:0712/095548.588546:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 22678259
[1:1:0712/095548.591076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.591311:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.591535:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.591831:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 22678259
[1:1:0712/095548.593374:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 22678259
[1:1:0712/095548.593833:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4f01b4b7ba
[1:1:0712/095548.594007:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4f01b42def, 7f4f01b4b77a, 7f4f01b4d0cf
[1:1:0712/095548.603379:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095548.603901:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095548.604084:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd41ffc88, 0x7ffcd41ffc08)
[1:1:0712/095548.620553:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095548.626415:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[120176:120176:0712/095549.193590:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120176:120176:0712/095549.195009:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120176:120186:0712/095549.208294:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[120176:120176:0712/095549.208400:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[120176:120186:0712/095549.208391:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[120176:120176:0712/095549.208463:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[120176:120176:0712/095549.208561:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,120227, 4
[1:7:0712/095549.212048:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[120176:120197:0712/095549.289624:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/095549.302720:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xe23aa531220
[1:1:0712/095549.302984:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/095549.622983:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[120176:120176:0712/095551.396966:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[120176:120176:0712/095551.397086:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095551.422591:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095551.424602:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/095552.517843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095552.518369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095552.548128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/095552.548577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095552.603772:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095552.730134:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095552.730463:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095553.128210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095553.141277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095553.141732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095553.168606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095553.182175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/095553.182468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095553.194326:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[120176:120176:0712/095553.197386:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/095553.198476:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe23aa52fe20
[1:1:0712/095553.198754:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[120176:120176:0712/095553.204600:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[120176:120176:0712/095553.239261:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[120176:120176:0712/095553.239431:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/095553.305672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095554.409224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f4eeb7af2e0 0xe23aa73cb60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095554.410675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/095554.410875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095554.412381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[120176:120176:0712/095554.486092:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/095554.488156:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xe23aa530820
[1:1:0712/095554.488410:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[120176:120176:0712/095554.502170:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/095554.506712:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/095554.506909:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[120176:120176:0712/095554.530740:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[120176:120176:0712/095554.542369:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120176:120176:0712/095554.543414:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120176:120186:0712/095554.549691:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[120176:120186:0712/095554.549778:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[120176:120176:0712/095554.549937:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[120176:120176:0712/095554.550015:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[120176:120176:0712/095554.550155:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,120227, 4
[1:7:0712/095554.561469:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095554.975703:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/095555.145746:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f4eeb7af2e0 0xe23aa8e69e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095555.146837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0d048bde1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/095555.147262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/095555.148831:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/095555.272616:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[120176:120176:0712/095555.274734:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[120176:120176:0712/095555.274859:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/095555.646124:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095556.052054:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095556.052222:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[120176:120176:0712/095556.086042:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[120176:120204:0712/095556.086610:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/095556.086884:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/095556.087175:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/095556.087778:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/095556.087992:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/095556.091558:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d53bf1b, 1
[1:1:0712/095556.092120:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x38c91cc9, 0
[1:1:0712/095556.092366:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xbc2f59b, 3
[1:1:0712/095556.092663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2548044d, 2
[1:1:0712/095556.092900:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffc91cffffffc938 1bffffffbf532d 4d044825 ffffff9bfffffff5ffffffc20b , 10104, 5
[1:1:0712/095556.094285:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[120176:120204:0712/095556.094625:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��8�S-MH%����T
[120176:120204:0712/095556.094728:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��8�S-MH%������T
[120176:120204:0712/095556.095056:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 120272, 5, c91cc938 1bbf532d 4d044825 9bf5c20b 
[1:1:0712/095556.094886:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4effd860a0, 3
[1:1:0712/095556.095660:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4efff11080, 2
[1:1:0712/095556.095949:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4ee9bd4d20, -2
[1:1:0712/095556.110468:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/095556.110910:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2548044d
[1:1:0712/095556.111276:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2548044d
[1:1:0712/095556.111990:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2548044d
[1:1:0712/095556.113444:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.113733:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.113988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.114210:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.114922:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2548044d
[1:1:0712/095556.115248:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4f01b4b7ba
[1:1:0712/095556.115425:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4f01b42def, 7f4f01b4b77a, 7f4f01b4d0cf
[1:1:0712/095556.121677:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2548044d
[1:1:0712/095556.122101:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2548044d
[1:1:0712/095556.122881:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2548044d
[1:1:0712/095556.124968:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.125235:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.125466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.125726:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2548044d
[1:1:0712/095556.126995:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2548044d
[1:1:0712/095556.127402:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4f01b4b7ba
[1:1:0712/095556.127618:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4f01b42def, 7f4f01b4b77a, 7f4f01b4d0cf
[1:1:0712/095556.135762:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/095556.136302:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/095556.136500:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcd41ffc88, 0x7ffcd41ffc08)
[1:1:0712/095556.152250:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/095556.154467:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/095556.319251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095556.323862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0d048bf0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/095556.324165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/095556.326898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/095556.341983:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xe23aa4e2220
[1:1:0712/095556.342220:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[120176:120176:0712/095556.954667:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[120176:120176:0712/095556.962765:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[120176:120186:0712/095556.982747:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[120176:120186:0712/095556.982881:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[120176:120176:0712/095556.983473:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.odaily.com/
[120176:120176:0712/095556.983616:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.odaily.com/, https://www.odaily.com/, 1
[120176:120176:0712/095556.983754:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.odaily.com/, HTTP/1.1 200 status:200 server:Tengine date:Fri, 12 Jul 2019 16:55:56 GMT content-type:text/html; charset=utf-8 x-dns-prefetch-control:off x-frame-options:SAMEORIGIN strict-transport-security:max-age=15552000; includeSubDomains x-download-options:noopen x-content-type-options:nosniff x-xss-protection:1; mode=block etag:W/"e4fb-2h5Tnb8fEA46v0lOGqL4g7wz3a4" vary:Accept-Encoding content-encoding:gzip expires:Fri, 12 Jul 2019 16:55:55 GMT cache-control:no-cache  ,120272, 5
[1:7:0712/095556.988775:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/095557.033871:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.odaily.com/
[1:1:0712/095557.112442:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[120176:120176:0712/095557.131500:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.odaily.com/, https://www.odaily.com/, 1
[120176:120176:0712/095557.131624:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.odaily.com/, https://www.odaily.com
[1:1:0712/095557.215055:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095557.330056:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095557.330322:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.odaily.com/"
[1:1:0712/095558.373674:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7f4ee9887070 0xe23aa6a9c60 , "https://www.odaily.com/"
[1:1:0712/095558.376469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , 
          // Baidu Tongji
          var _hmt = _hmt || [];
          (function() {
              va
[1:1:0712/095558.376709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095558.378456:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/095558.987948:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.078491:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7f4ee9befbd0 0xe23aa6aacd8 , "https://www.odaily.com/"
[1:1:0712/095559.082742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , /*! Raven.js 3.26.4 (409f3b4) | github.com/getsentry/raven-js */
!function(a){if("object"==typeof ex
[1:1:0712/095559.082981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095559.118669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7f4ee9befbd0 0xe23aa6aacd8 , "https://www.odaily.com/"
[1:1:0712/095559.127338:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.127964:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.131826:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.132306:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.132723:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095559.212077:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.095506, 447, 1
[1:1:0712/095559.212403:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095559.695809:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095559.696191:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.odaily.com/"
[1:1:0712/095559.697264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7f4ee9887070 0xe23aa8575e0 , "https://www.odaily.com/"
[1:1:0712/095559.700159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , 
          window.process = {"env":{"NODE_ENV":"production","PUBLIC_URL":"","PROXY_API":"https://api
[1:1:0712/095559.700381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095559.769421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7f4ee9887070 0xe23aa8575e0 , "https://www.odaily.com/"
[1:1:0712/095600.109258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7f4ee9887070 0xe23aa8575e0 , "https://www.odaily.com/"
[1:1:0712/095604.636773:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.94054, 0, 0
[1:1:0712/095604.637087:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095604.916349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329 0x7f4eeb7af2e0 0xe23aa6ae2e0 , "https://www.odaily.com/"
[1:1:0712/095604.926552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , (function(){var h={},mt={},c={id:"6fa6c9b16da1547d0ddf83f54344694b",dm:["odaily.com"],js:"tongji.bai
[1:1:0712/095604.926849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095604.967924:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3a438f1229c8, 0xe23aa2bc148
[1:1:0712/095604.968102:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 100
[1:1:0712/095604.968282:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.odaily.com/, 360
[1:1:0712/095604.968391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 360 0x7f4ee9887070 0xe23aa5b42e0 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 329 0x7f4eeb7af2e0 0xe23aa6ae2e0 
[120176:120176:0712/095621.943260:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/095621.952940:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/095623.414988:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 330 0x7f4eeb7af2e0 0xe23aa619160 , "https://www.odaily.com/"
[1:1:0712/095623.416313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,t=docum
[1:1:0712/095623.416541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095623.502484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 333 0x7f4eeb7af2e0 0xe23aa103ce0 , "https://www.odaily.com/"
[1:1:0712/095623.503509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , document.write('<script charset="utf-8" src="https://s.ssl.qhres.com/ssl/ab77b6ea7f3fbf79.js"></scri
[1:1:0712/095623.503805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[120176:120176:0712/095623.510247:INFO:CONSOLE(1)] "Failed to execute 'write' on 'Document': It isn't possible to write into a document from an asynchronously-loaded external script unless it is explicitly opened.", source: https://jspassport.ssl.qhimg.com/11.0.1.js?46e51362476785a1177de8da55c05695 (1)
[1:1:0712/095623.527028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 334 0x7f4eeb7af2e0 0xe23aa6aa460 , "https://www.odaily.com/"
[1:1:0712/095623.531918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , (function(b){b.MtaH5=b.MtaH5||{};MtaH5.hack=function(){var b=document.getElementsByName("MTAH5"),f={
[1:1:0712/095623.532220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095623.694272:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095623.694533:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.odaily.com/"
[1:1:0712/095623.695642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f4ee9887070 0xe23ab60ace0 , "https://www.odaily.com/"
[1:1:0712/095623.696592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , window.render();
[1:1:0712/095623.696839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095625.412180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 300
[1:1:0712/095625.412748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 433
[1:1:0712/095625.413002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 433 0x7f4ee9887070 0xe23ac747ee0 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 343 0x7f4ee9887070 0xe23ab60ace0 
[1:1:0712/095625.462877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 5000
[1:1:0712/095625.463323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 436
[1:1:0712/095625.463588:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f4ee9887070 0xe23ab66a360 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 343 0x7f4ee9887070 0xe23ab60ace0 
[1:1:0712/095625.526109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 5000
[1:1:0712/095625.526569:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 437
[1:1:0712/095625.526812:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 437 0x7f4ee9887070 0xe23ac8d1ae0 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 343 0x7f4ee9887070 0xe23ab60ace0 
[1:1:0712/095625.995924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 1000
[1:1:0712/095625.996412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 444
[1:1:0712/095625.996687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 444 0x7f4ee9887070 0xe23ac8d1d60 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 343 0x7f4ee9887070 0xe23ab60ace0 
[1:1:0712/095626.806075:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa0d0
[1:1:0712/095626.808887:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa138
[1:1:0712/095626.850413:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa428
[1:1:0712/095626.852460:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa490
[1:1:0712/095626.880695:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa780
[1:1:0712/095626.882586:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfa7e8
[1:1:0712/095626.901167:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfaad8
[1:1:0712/095626.902954:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfab40
[1:1:0712/095626.938123:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfae30
[1:1:0712/095626.940018:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfae98
[1:1:0712/095626.977141:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb188
[1:1:0712/095626.978987:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb1f0
[1:1:0712/095627.026595:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb4e0
[1:1:0712/095627.028505:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb548
[1:1:0712/095627.066209:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb838
[1:1:0712/095627.068142:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfb8a0
[1:1:0712/095627.100741:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfbb90
[1:1:0712/095627.102501:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b439adfbbf8
[1:1:0712/095627.109655:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.41505, 0, 0
[1:1:0712/095627.109946:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/095627.207782:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.odaily.com/"
[1:1:0712/095627.208685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095627.208953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095627.450975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/095627.451282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095628.681591:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.odaily.com/, 360, 7f4eec1cc881
[1:1:0712/095628.704057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"10828b0c2860","ptid":"329 0x7f4eeb7af2e0 0xe23aa6ae2e0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095628.704468:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.odaily.com/","ptid":"329 0x7f4eeb7af2e0 0xe23aa6ae2e0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095628.704921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.odaily.com/"
[1:1:0712/095628.705589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095628.705815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095628.707901:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3a438f1229c8, 0xe23aa2bc150
[1:1:0712/095628.708132:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 100
[1:1:0712/095628.708509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.odaily.com/, 495
[1:1:0712/095628.708738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 495 0x7f4ee9887070 0xe23aa7c1660 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 360 0x7f4ee9887070 0xe23aa5b42e0 
[1:1:0712/095629.460696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095629.461445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095629.461701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095629.466132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095629.471026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095630.669356:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095641.392969:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095641.393473:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[120176:120176:0712/095644.117409:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/095646.233414:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.233855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095646.233975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095646.234748:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.237003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.633715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.634406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095646.634587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095646.639250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.698051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.698737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095646.698946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095646.700621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095646.704237:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095648.733566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x3a438f1229c8, 0xe23aa2bc210
[1:1:0712/095648.733748:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.odaily.com/", 1500
[1:1:0712/095648.733931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.odaily.com/, 525
[1:1:0712/095648.734043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f4ee9887070 0xe23ae32fee0 , 5:3_https://www.odaily.com/, 1, -5:3_https://www.odaily.com/, 462
[1:1:0712/095648.963841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095648.964234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095648.964379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095648.965239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095648.967142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
		remove user.11_45780eca -> 0
		remove user.12_6adea63c -> 0
		remove user.13_54245615 -> 0
[1:1:0712/095652.149846:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/095652.150082:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.odaily.com/"
[1:1:0712/095652.152195:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095652.152855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095652.153039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095652.636541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095653.234535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.odaily.com/"
[1:1:0712/095653.245145:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.odaily.com/"
[1:1:0712/095653.320924:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095653.321615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095653.321801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095653.324214:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095653.328519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095655.490436:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095655.490872:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095655.491207:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/095656.321299:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 433, 7f4eec1cc8db
[1:1:0712/095656.347442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"10828b0c2860","ptid":"343 0x7f4ee9887070 0xe23ab60ace0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095656.347828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.odaily.com/","ptid":"343 0x7f4ee9887070 0xe23ab60ace0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095656.348425:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 563
[1:1:0712/095656.348676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7f4ee9887070 0xe23b6330ce0 , 5:3_https://www.odaily.com/, 0, , 433 0x7f4ee9887070 0xe23ac747ee0 
[1:1:0712/095656.349036:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.odaily.com/"
[1:1:0712/095656.349683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095656.349917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095656.354255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 444, 7f4eec1cc8db
[1:1:0712/095656.378099:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"10828b0c2860","ptid":"343 0x7f4ee9887070 0xe23ab60ace0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095656.378429:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.odaily.com/","ptid":"343 0x7f4ee9887070 0xe23ab60ace0 ","rf":"5:3_https://www.odaily.com/"}
[1:1:0712/095656.378824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.odaily.com/, 564
[1:1:0712/095656.379037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 564 0x7f4ee9887070 0xe23b4f1d560 , 5:3_https://www.odaily.com/, 0, , 444 0x7f4ee9887070 0xe23ac8d1d60 
[1:1:0712/095656.379307:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.odaily.com/"
[1:1:0712/095656.379820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095656.379991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095656.404546:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095656.404942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , o, (){var o=[],i=arguments.length,a=!t||t&&!1!==t.deep;for(n&&v(n)&&n.apply(this,arguments);i--;)o[i]=a
[1:1:0712/095656.405061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095656.405830:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
[1:1:0712/095656.407889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.odaily.com/"
		remove user.14_d2ababab -> 0
		remove user.15_78ae976b -> 0
		remove user.16_c93ca4d7 -> 0
[1:1:0712/095659.273595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , document.readyState
[1:1:0712/095659.273798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
[1:1:0712/095659.299784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.odaily.com/, 10828b0c2860, , , (){w(t,function(){b=null})}
[1:1:0712/095659.300004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.odaily.com/", "www.odaily.com", 3, 1, , , 0
