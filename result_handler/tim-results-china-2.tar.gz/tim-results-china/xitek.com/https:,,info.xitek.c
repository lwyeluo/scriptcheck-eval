[0712/071305.959367:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071305.959790:INFO:switcher_clone.cc(787)] backtrace rip is 7ff573c85891
[0712/071306.976469:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071306.978215:INFO:switcher_clone.cc(787)] backtrace rip is 7fce30ff5891
[1:1:0712/071306.990195:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/071306.990483:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/071306.996252:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[98588:98588:0712/071308.156769:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/9db26d05-5e4b-41d4-9f69-b398930cd3b7
[0712/071308.325079:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071308.325384:INFO:switcher_clone.cc(787)] backtrace rip is 7ff84295c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[98619:98619:0712/071308.560722:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=98619
[98631:98631:0712/071308.561236:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=98631
[98588:98588:0712/071308.587167:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[98588:98616:0712/071308.588118:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/071308.588385:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/071308.588641:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/071308.589260:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/071308.589425:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/071308.592450:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2f941e8e, 1
[1:1:0712/071308.592884:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2c8750e9, 0
[1:1:0712/071308.593136:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x4779522, 3
[1:1:0712/071308.593402:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xecc6d4c, 2
[1:1:0712/071308.593694:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe950ffffff872c ffffff8e1effffff942f 4c6dffffffcc0e 22ffffff957704 , 10104, 4
[1:1:0712/071308.594796:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[98588:98616:0712/071308.595120:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�P�,��/Lm�"�wl�;
[98588:98616:0712/071308.595223:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �P�,��/Lm�"�w��l�;
[1:1:0712/071308.595113:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce2f2300a0, 3
[98588:98616:0712/071308.595608:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/071308.595434:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce2f3bb080, 2
[98588:98616:0712/071308.595705:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 98639, 4, e950872c 8e1e942f 4c6dcc0e 22957704 
[1:1:0712/071308.595785:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce1907ed20, -2
[1:1:0712/071308.616835:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/071308.617789:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ecc6d4c
[1:1:0712/071308.619076:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ecc6d4c
[1:1:0712/071308.620783:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ecc6d4c
[1:1:0712/071308.622309:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.622566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.622821:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.623055:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.623755:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ecc6d4c
[1:1:0712/071308.624171:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce30ff57ba
[1:1:0712/071308.624380:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce30fecdef, 7fce30ff577a, 7fce30ff70cf
[1:1:0712/071308.630211:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ecc6d4c
[1:1:0712/071308.630661:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ecc6d4c
[1:1:0712/071308.631470:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ecc6d4c
[1:1:0712/071308.633561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.633813:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.634056:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.634319:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ecc6d4c
[1:1:0712/071308.635626:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ecc6d4c
[1:1:0712/071308.636089:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce30ff57ba
[1:1:0712/071308.636316:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce30fecdef, 7fce30ff577a, 7fce30ff70cf
[1:1:0712/071308.644440:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/071308.644935:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/071308.645117:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffffb8e43b8, 0x7ffffb8e4338)
[1:1:0712/071308.660494:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/071308.666490:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[98588:98609:0712/071309.137862:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[98588:98588:0712/071309.182232:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[98588:98588:0712/071309.182775:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[98588:98598:0712/071309.201836:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[98588:98598:0712/071309.201971:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[98588:98588:0712/071309.202143:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[98588:98588:0712/071309.202241:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[98588:98588:0712/071309.202427:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,98639, 4
[1:7:0712/071309.205058:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071309.229543:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2058883e8220
[1:1:0712/071309.229874:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/071309.584425:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[98588:98588:0712/071311.221994:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[98588:98588:0712/071311.222147:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/071311.227952:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071311.231404:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071312.394478:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071312.494384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/071312.494715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071312.511767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/071312.512120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071312.663962:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071312.664266:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071313.011000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071313.020336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/071313.020642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071313.070371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071313.081386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/071313.081705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071313.092811:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[98588:98588:0712/071313.096516:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071313.097578:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2058883e6e20
[1:1:0712/071313.097862:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[98588:98588:0712/071313.100556:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[98588:98588:0712/071313.135844:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[98588:98588:0712/071313.136006:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/071313.177569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071313.977437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fce1ac592e0 0x2058885002e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071313.978913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/071313.979195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071313.980113:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[98588:98588:0712/071314.053981:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071314.055902:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2058883e7820
[1:1:0712/071314.056161:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[98588:98588:0712/071314.064348:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/071314.070924:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/071314.071277:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[98588:98588:0712/071314.082025:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[98588:98588:0712/071314.093812:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[98588:98588:0712/071314.095115:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[98588:98598:0712/071314.102927:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[98588:98598:0712/071314.103037:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[98588:98588:0712/071314.103265:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[98588:98588:0712/071314.103366:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[98588:98588:0712/071314.103548:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,98639, 4
[1:7:0712/071314.106701:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071314.610584:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/071314.935348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7fce1ac592e0 0x2058886c46e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071314.936412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 318cef6c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/071314.936649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071314.937433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[98588:98588:0712/071315.236449:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[98588:98588:0712/071315.236568:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/071315.266416:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071315.634813:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071316.195885:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071316.196189:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[98588:98588:0712/071316.269067:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[98588:98616:0712/071316.269570:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/071316.269799:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/071316.270016:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/071316.270433:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/071316.270578:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/071316.273905:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1fabd518, 1
[1:1:0712/071316.274370:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25a6f26e, 0
[1:1:0712/071316.274575:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x384451f3, 3
[1:1:0712/071316.275195:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2907feb, 2
[1:1:0712/071316.275417:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6efffffff2ffffffa625 18ffffffd5ffffffab1f ffffffeb7fffffff9002 fffffff3514438 , 10104, 5
[1:1:0712/071316.276844:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[98588:98616:0712/071316.277137:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGn�%ի���QD8|l�;
[98588:98616:0712/071316.277213:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is n�%ի���QD8h�|l�;
[98588:98616:0712/071316.277492:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 98684, 5, 6ef2a625 18d5ab1f eb7f9002 f3514438 
[1:1:0712/071316.277332:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce2f2300a0, 3
[1:1:0712/071316.277654:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce2f3bb080, 2
[1:1:0712/071316.277870:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fce1907ed20, -2
[1:1:0712/071316.299832:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/071316.300319:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2907feb
[1:1:0712/071316.300720:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2907feb
[1:1:0712/071316.301440:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2907feb
[1:1:0712/071316.302867:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.303075:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.303320:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.303510:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.304188:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2907feb
[1:1:0712/071316.304480:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce30ff57ba
[1:1:0712/071316.304614:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce30fecdef, 7fce30ff577a, 7fce30ff70cf
[1:1:0712/071316.309180:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2907feb
[1:1:0712/071316.309672:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2907feb
[1:1:0712/071316.310385:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2907feb
[1:1:0712/071316.312428:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.312654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.312839:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.313024:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2907feb
[1:1:0712/071316.314479:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2907feb
[1:1:0712/071316.314923:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fce30ff57ba
[1:1:0712/071316.315080:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fce30fecdef, 7fce30ff577a, 7fce30ff70cf
[1:1:0712/071316.324307:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/071316.324939:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/071316.325142:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffffb8e43b8, 0x7ffffb8e4338)
[1:1:0712/071316.339430:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/071316.343825:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/071316.556282:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/071316.560989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 318cef7ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/071316.561319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/071316.569524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/071316.604666:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2058883aa220
[1:1:0712/071316.604935:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[98588:98588:0712/071317.308816:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[98588:98588:0712/071317.315731:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[98588:98588:0712/071317.338533:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://info.xitek.com/
[98588:98588:0712/071317.338624:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://info.xitek.com/, https://info.xitek.com/reviews/201906/26-336678.html, 1
[98588:98588:0712/071317.338705:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://info.xitek.com/, HTTP/1.1 200 OK Server: openresty/1.9.7.3 Date: Fri, 12 Jul 2019 14:13:17 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Vary: Accept-Encoding X-Powered-By: PHP/5.6.30 Content-Encoding: gzip  ,98684, 5
[98588:98598:0712/071317.340462:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[98588:98598:0712/071317.340553:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/071317.342343:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071317.395079:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://info.xitek.com/
[1:1:0712/071317.616536:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[98588:98588:0712/071317.652214:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://info.xitek.com/, https://info.xitek.com/, 1
[98588:98588:0712/071317.652347:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://info.xitek.com/, https://info.xitek.com
[1:1:0712/071317.707990:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071317.826549:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071317.826815:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071318.518192:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/071318.815008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071318.824120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , /*! jQuery v2.1.4 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/071318.824410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071318.847286:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071319.107910:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.139092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.150619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.162689:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.168263:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.175747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fce19099bd0 0x2058884d1fd8 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.237010:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.133243, 315, 1
[1:1:0712/071319.237320:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071319.649874:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071319.650199:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.651289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fce18d31070 0x2058886bb160 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.652238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , getDigg(336678);
[1:1:0712/071319.652449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071319.660713:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.668592:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:7:0712/071319.677993:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 6
[1:7:0712/071319.868789:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 7
[1:7:0712/071319.870855:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 8
[1:7:0712/071319.872488:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 9
[1:7:0712/071319.875155:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 10
[1:1:0712/071319.882256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 265 0x7fce18d31070 0x2058886bb160 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071319.884458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:7:0712/071319.897181:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 14
[1:7:0712/071319.949688:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 15
[1:7:0712/071319.951536:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 16
[1:7:0712/071319.953053:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 17
[1:7:0712/071319.955557:INFO:scheduler_single_thread_task_runner_manager.cc(299)] >>> [Task] IO thread post a task: 18
[1:1:0712/071320.042528:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.392167, 440, 1
[1:1:0712/071320.042814:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071320.420361:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071320.420539:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071320.420996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293 0x7fce18d31070 0x2058886a4260 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071320.421570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , 
    var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
   
[1:1:0712/071320.421703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071320.750724:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328, "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071320.758182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/071320.758506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071320.833981:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328, "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071324.708077:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.87496, 0, 0
[1:1:0712/071324.708367:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071325.816092:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071325.816599:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071325.817046:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071325.817475:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071325.817855:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071328.328981:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071328.329341:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071328.330679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7fce18d31070 0x2058890dc260 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071328.332237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , 
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https
[1:1:0712/071328.332506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071328.343673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7fce18d31070 0x2058890dc260 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071328.349211:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7fce18d31070 0x2058890dc260 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071328.393917:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071328.399799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.400158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.400795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 561
[1:1:0712/071328.401076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7fce18d31070 0x205888856960 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.404859:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.405103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.405662:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 562
[1:1:0712/071328.405981:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 562 0x7fce18d31070 0x2058889c6060 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.411193:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.411476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.412069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 563
[1:1:0712/071328.412398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 563 0x7fce18d31070 0x20588892f2e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.417654:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.417918:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.418498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 564
[1:1:0712/071328.418788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 564 0x7fce18d31070 0x2058888060e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.424448:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.424752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.425317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 565
[1:1:0712/071328.425571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 565 0x7fce18d31070 0x2058887320e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.429873:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.430099:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.430573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 566
[1:1:0712/071328.430827:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7fce18d31070 0x2058884ccee0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.434829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.435067:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.435557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 567
[1:1:0712/071328.436735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7fce18d31070 0x2058887b4d60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.441568:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.441832:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.442396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 568
[1:1:0712/071328.442663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7fce18d31070 0x205888683f60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.447077:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.447312:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.447763:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 569
[1:1:0712/071328.448035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 569 0x7fce18d31070 0x205888637660 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.451779:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.452025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.452571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 570
[1:1:0712/071328.452834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 570 0x7fce18d31070 0x205888858b60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071328.457397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071328.457666:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600
[1:1:0712/071328.458239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 571
[1:1:0712/071328.458522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7fce18d31070 0x2058889a0ae0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
		remove user.10_67dd64c5 -> 0
		remove user.11_f210e33c -> 0
		remove user.12_ee227d89 -> 0
		remove user.13_a84ebaa3 -> 0
		remove user.14_ab30ce8c -> 0
[1:1:0712/071329.510559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071329.511135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 577
[1:1:0712/071329.511375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 577 0x7fce18d31070 0x205889293be0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.077303:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.077652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.078140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 580
[1:1:0712/071330.078408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7fce18d31070 0x205889497fe0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.146032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.146378:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.147053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 582
[1:1:0712/071330.147307:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7fce18d31070 0x2058894ec260 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.206444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.206760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.207220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 584
[1:1:0712/071330.207455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7fce18d31070 0x205889549e60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.282482:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.282803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.283270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 586
[1:1:0712/071330.283500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 586 0x7fce18d31070 0x205889512ce0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.366230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.366536:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.367016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 588
[1:1:0712/071330.367246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7fce18d31070 0x205889595ae0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.440313:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x2f151e4c29c8, 0x205888239a28
[1:1:0712/071330.440610:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 3000
[1:1:0712/071330.441086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 590
[1:1:0712/071330.441315:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 590 0x7fce18d31070 0x205889630060 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.490492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239a10
[1:1:0712/071330.490778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071330.491233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 592
[1:1:0712/071330.491531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 592 0x7fce18d31070 0x205889680be0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071330.533758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071330.534255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 593
[1:1:0712/071330.534486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 593 0x7fce18d31070 0x205889680a60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 495 0x7fce18d31070 0x2058890dc260 
[1:1:0712/071333.114870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 561, 7fce1b676881
[1:1:0712/071333.123734:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.124077:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.124535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.125267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.125532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.150151:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 562, 7fce1b676881
[1:1:0712/071333.159977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.160300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.160700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.161401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.161628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.166952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 563, 7fce1b676881
[1:1:0712/071333.183533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.183841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.184236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.184936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.185145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.187937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 564, 7fce1b676881
[1:1:0712/071333.219296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.219653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.220087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.220781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.221014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.249986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 565, 7fce1b676881
[1:1:0712/071333.277885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.278236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.278641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.279334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.279570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.284517:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 566, 7fce1b676881
[1:1:0712/071333.317406:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.317802:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.318225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.318968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.319205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.325158:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 567, 7fce1b676881
[1:1:0712/071333.353920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.354281:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.354714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.355421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.355710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.431131:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 568, 7fce1b676881
[1:1:0712/071333.449120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.449502:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.449904:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.450689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.450921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.455630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 569, 7fce1b676881
[1:1:0712/071333.485387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.485761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.486151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.486854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.487075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.490426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 570, 7fce1b676881
[1:1:0712/071333.508448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.508745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.509114:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.509872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.510082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.578964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 571, 7fce1b676881
[1:1:0712/071333.606043:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.606382:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.606783:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.607477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){
            $ad.each(function(){
                if ($(this).find('object').length != 0){
   
[1:1:0712/071333.607763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.610152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 592, 7fce1b676881
[1:1:0712/071333.639971:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.640388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.640903:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.641561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071333.641780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.674717:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 593, 7fce1b6768db
[1:1:0712/071333.685892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.686261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071333.686737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 691
[1:1:0712/071333.686972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7fce18d31070 0x20588885f5e0 , 5:3_https://info.xitek.com/, 0, , 593 0x7fce18d31070 0x205889680a60 
[1:1:0712/071333.687303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.687938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071333.688202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.799164:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.799934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/071333.800224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071333.856880:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071333.857642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/071333.857866:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071334.000394:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 639 0x7fce1ac592e0 0x205889660b60 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071334.005069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (function(){var h={},mt={},c={id:"ce70a1f49c2ca89b4b7f15662df921f2",dm:["ww.xitek.com"],js:"tongji.b
[1:1:0712/071334.005323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071334.029737:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239990
[1:1:0712/071334.029976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071334.030417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 697
[1:1:0712/071334.030687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7fce18d31070 0x2058895e86e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 639 0x7fce1ac592e0 0x205889660b60 
[98588:98588:0712/071339.236673:INFO:CONSOLE(5)] "The key "target-densitydpi" is not supported.", source: https://info.xitek.com/reviews/201906/26-336678.html (5)
[98588:98588:0712/071339.239819:INFO:CONSOLE(5)] "The value "1360px" for key "width" was truncated to its numeric prefix.", source: https://info.xitek.com/reviews/201906/26-336678.html (5)
[98588:98588:0712/071339.343369:INFO:CONSOLE(204)] "Synchronous XMLHttpRequest on the main thread is deprecated because of its detrimental effects to the end user's experience. For more help, check https://xhr.spec.whatwg.org/.", source: https://cms.xitek.com/include/dedeajax2.js (204)
[98588:98588:0712/071339.352518:INFO:CONSOLE(206)] "Failed to load https://cms.xitek.com/plus/digg_ajax.php?id=336678&formurl=beauty: No 'Access-Control-Allow-Origin' header is present on the requested resource. Origin 'https://info.xitek.com' is therefore not allowed access.", source: https://cms.xitek.com/include/dedeajax2.js (206)
[98588:98588:0712/071339.356670:INFO:CONSOLE(206)] "Uncaught NetworkError: Failed to execute 'send' on 'XMLHttpRequest': Failed to load 'https://cms.xitek.com/plus/digg_ajax.php?id=336678&formurl=beauty'.", source: https://cms.xitek.com/include/dedeajax2.js (206)
[98588:98588:0712/071339.362544:INFO:CONSOLE(206)] "Failed to load https://cms.xitek.com/plus/digg_ajax.php?id=336678&formurl=beautybad: No 'Access-Control-Allow-Origin' header is present on the requested resource. Origin 'https://info.xitek.com' is therefore not allowed access.", source: https://cms.xitek.com/include/dedeajax2.js (206)
[98588:98588:0712/071339.366288:INFO:CONSOLE(206)] "Uncaught NetworkError: Failed to execute 'send' on 'XMLHttpRequest': Failed to load 'https://cms.xitek.com/plus/digg_ajax.php?id=336678&formurl=beautybad'.", source: https://cms.xitek.com/include/dedeajax2.js (206)
[98588:98588:0712/071339.375540:INFO:CONSOLE(722)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ssl.google-analytics.com/ga.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://info.xitek.com/reviews/201906/26-336678.html (722)
[98588:98588:0712/071339.376651:INFO:CONSOLE(722)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://ssl.google-analytics.com/ga.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://info.xitek.com/reviews/201906/26-336678.html (722)
[98588:98588:0712/071339.577690:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/071339.701084:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/071340.653455:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 600000
[1:1:0712/071340.654039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 743
[1:1:0712/071340.654328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7fce18d31070 0x20588983b960 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 639 0x7fce1ac592e0 0x205889660b60 
[1:1:0712/071340.743970:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7fce1ac592e0 0x20588961e5e0 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071340.745094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":962,"zstr":["<a class='ada' href='http:\/\/www8.xitek.com\/oa\/adclick2.php?bannerid
[1:1:0712/071340.745327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071340.761511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[98588:98588:0712/071340.797827:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://info.xitek.com/reviews/201906/26-336678.html' was loaded over HTTPS, but requested an insecure image 'http://www8.xitek.com/oa/upload/y-0627-1920x180_2.jpg'. This content should also be served over HTTPS.", source: https://info.xitek.com/reviews/201906/26-336678.html (0)
[1:1:0712/071340.841677:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 577, 7fce1b6768db
[1:1:0712/071340.872827:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071340.873224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"495 0x7fce18d31070 0x2058890dc260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071340.873731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 754
[1:1:0712/071340.873988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7fce18d31070 0x2058891eda60 , 5:3_https://info.xitek.com/, 0, , 577 0x7fce18d31070 0x205889293be0 
[1:1:0712/071340.874355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071340.875030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071340.875273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071340.975441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071340.975730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071340.976202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 756
[1:1:0712/071340.976485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7fce18d31070 0x205888c3fee0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 577 0x7fce18d31070 0x205889293be0 
[1:1:0712/071341.014491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071341.015017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 757
[1:1:0712/071341.015253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7fce18d31070 0x205889918ee0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 577 0x7fce18d31070 0x205889293be0 
[1:1:0712/071341.096162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645 0x7fce1ac592e0 0x2058891fe4e0 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.097154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":963})
[1:1:0712/071341.097397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071341.120776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.172839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 646 0x7fce1ac592e0 0x205889219560 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.173955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":964,"zstr":["<a class='ada' href='http:\/\/www8.xitek.com\/oa\/adclick2.php?bannerid
[1:1:0712/071341.174184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071341.183346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[98588:98588:0712/071341.193709:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://info.xitek.com/reviews/201906/26-336678.html' was loaded over HTTPS, but requested an insecure image 'http://www8.xitek.com/oa/upload/320-320-0618.png'. This content should also be served over HTTPS.", source: https://info.xitek.com/reviews/201906/26-336678.html (0)
[1:1:0712/071341.264934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649 0x7fce1ac592e0 0x205889217060 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.265770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":965})
[1:1:0712/071341.265995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071341.288306:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.323660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 650 0x7fce1ac592e0 0x2058894aa2e0 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.324768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":967})
[1:1:0712/071341.325016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071341.347787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.405513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7fce1ac592e0 0x2058891edce0 , "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071341.406562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , callback({"zid":966})
[1:1:0712/071341.406780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071341.425899:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071342.184614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/071342.184909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071342.607579:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CERT_COMMON_NAME_INVALID","https://bdimg.share.baidu.com/static/api/js/share.js?cdnversion=434149&_=1562940799048"
[1:1:0712/071343.240311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 697, 7fce1b676881
[1:1:0712/071343.273842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"639 0x7fce1ac592e0 0x205889660b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.274168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"639 0x7fce1ac592e0 0x205889660b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.274544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071343.275160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071343.275341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071343.276183:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071343.276347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071343.276740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 796
[1:1:0712/071343.276952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7fce18d31070 0x205889967c60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 697 0x7fce18d31070 0x2058895e86e0 
[1:1:0712/071343.540865:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 756, 7fce1b676881
[1:1:0712/071343.573843:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.574192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.574568:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071343.575161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071343.575347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071343.576813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 757, 7fce1b6768db
[1:1:0712/071343.626537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.626854:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.627289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 799
[1:1:0712/071343.627488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7fce18d31070 0x205889aae9e0 , 5:3_https://info.xitek.com/, 0, , 757 0x7fce18d31070 0x205889918ee0 
[1:1:0712/071343.627785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071343.628414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071343.628595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071343.730957:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 754, 7fce1b6768db
[1:1:0712/071343.741042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.741192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"577 0x7fce18d31070 0x205889293be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071343.741405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 802
[1:1:0712/071343.741518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7fce18d31070 0x2058898e4c60 , 5:3_https://info.xitek.com/, 0, , 754 0x7fce18d31070 0x2058891eda60 
[1:1:0712/071343.741664:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071343.741999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071343.742111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071344.485093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071344.485345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071344.485752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 809
[1:1:0712/071344.485940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7fce18d31070 0x2058880513e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 754 0x7fce18d31070 0x2058891eda60 
[1:1:0712/071344.501421:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071344.501860:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 810
[1:1:0712/071344.502052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 810 0x7fce18d31070 0x20588885d360 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 754 0x7fce18d31070 0x2058891eda60 
[1:1:0712/071344.587633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071344.588413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , newImgs.(anonymous function).onload, (){
                imageloadpost();
            }
[1:1:0712/071344.588611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071344.658777:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071344.659268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , newImgs.(anonymous function).onload, (){
                imageloadpost();
            }
[1:1:0712/071344.659385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071344.736607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , document.readyState
[1:1:0712/071344.736785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.133634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.134512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , r.handle, (b){return typeof n!==U&&n.event.triggered!==b.type?n.event.dispatch.apply(a,arguments):void 0}
[1:1:0712/071345.134738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.541950:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.542752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/071345.543061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.587072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 796, 7fce1b676881
[1:1:0712/071345.600261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"697 0x7fce18d31070 0x2058895e86e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.600672:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"697 0x7fce18d31070 0x2058895e86e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.601125:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.601922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071345.602261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.603120:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071345.603323:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071345.603782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 847
[1:1:0712/071345.604052:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 847 0x7fce18d31070 0x20588a079be0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 796 0x7fce18d31070 0x205889967c60 
[1:1:0712/071345.877581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 809, 7fce1b676881
[1:1:0712/071345.906644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.907011:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.907446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.908160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071345.908553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.910086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 802, 7fce1b6768db
[1:1:0712/071345.933583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.933895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.934328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 860
[1:1:0712/071345.934571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7fce18d31070 0x205889fd5b60 , 5:3_https://info.xitek.com/, 0, , 802 0x7fce18d31070 0x2058898e4c60 
[1:1:0712/071345.934863:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.935505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071345.935759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071345.937316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 810, 7fce1b6768db
[1:1:0712/071345.982939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.983326:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"754 0x7fce18d31070 0x2058891eda60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071345.983834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 862
[1:1:0712/071345.984063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7fce18d31070 0x205887cf92e0 , 5:3_https://info.xitek.com/, 0, , 810 0x7fce18d31070 0x20588885d360 
[1:1:0712/071345.984371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071345.985024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071345.985251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071346.139714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , document.readyState
[1:1:0712/071346.140016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071348.096629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 847, 7fce1b676881
[1:1:0712/071348.128420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"796 0x7fce18d31070 0x205889967c60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071348.128785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"796 0x7fce18d31070 0x205889967c60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071348.129209:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071348.129854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071348.130085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071348.130795:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071348.130985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071348.131470:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 882
[1:1:0712/071348.131723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7fce18d31070 0x20588a1736e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 847 0x7fce18d31070 0x20588a079be0 
[1:1:0712/071348.206921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , document.readyState
[1:1:0712/071348.207264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071348.493849:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 860, 7fce1b6768db
[1:1:0712/071348.531043:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"802 0x7fce18d31070 0x2058898e4c60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071348.531503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"802 0x7fce18d31070 0x2058898e4c60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071348.532180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 898
[1:1:0712/071348.532413:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7fce18d31070 0x20588848fe60 , 5:3_https://info.xitek.com/, 0, , 860 0x7fce18d31070 0x205889fd5b60 
[1:1:0712/071348.532763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071348.533430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071348.533642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071348.596949:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071348.597241:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071348.597679:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 900
[1:1:0712/071348.597903:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7fce18d31070 0x20588a01d5e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 860 0x7fce18d31070 0x205889fd5b60 
[1:1:0712/071348.607840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071348.608363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 901
[1:1:0712/071348.608617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7fce18d31070 0x2058899e7ce0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 860 0x7fce18d31070 0x205889fd5b60 
[1:1:0712/071349.022994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , document.readyState
[1:1:0712/071349.023308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071349.059333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 882, 7fce1b676881
[1:1:0712/071349.074746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"847 0x7fce18d31070 0x20588a079be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.075071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"847 0x7fce18d31070 0x20588a079be0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.075498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071349.076133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071349.076371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071349.077087:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071349.077278:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071349.077711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 912
[1:1:0712/071349.077941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7fce18d31070 0x205889556260 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 882 0x7fce18d31070 0x20588a1736e0 
[1:1:0712/071349.454774:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 900, 7fce1b676881
[1:1:0712/071349.492312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.492693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.493085:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071349.493693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071349.493921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071349.495810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 901, 7fce1b6768db
[1:1:0712/071349.533331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.533692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071349.534106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 922
[1:1:0712/071349.534340:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7fce18d31070 0x20588a08d5e0 , 5:3_https://info.xitek.com/, 0, , 901 0x7fce18d31070 0x2058899e7ce0 
[1:1:0712/071349.534672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071349.535256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071349.535480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071349.636508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071349.637282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/071349.637563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071349.640727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071349.642454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239af0
[1:1:0712/071349.642653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071349.643075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 926
[1:1:0712/071349.643296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7fce18d31070 0x205889a20a60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 909 0x7fce18d31070 0x205889b55260 
[1:1:0712/071349.717258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , document.readyState
[1:1:0712/071349.717605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071350.083670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 926, 7fce1b676881
[1:1:0712/071350.121942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"909 0x7fce18d31070 0x205889b55260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.122224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"909 0x7fce18d31070 0x205889b55260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.122556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071350.123208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071350.123447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071350.124202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071350.124367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071350.124778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 941
[1:1:0712/071350.124974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 941 0x7fce18d31070 0x20588843e860 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 926 0x7fce18d31070 0x205889a20a60 
[1:1:0712/071350.365635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 941, 7fce1b676881
[1:1:0712/071350.381380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"926 0x7fce18d31070 0x205889a20a60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.381553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"926 0x7fce18d31070 0x205889a20a60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.381757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071350.382085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071350.382199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071350.382508:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071350.382609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071350.382814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 948
[1:1:0712/071350.382922:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 948 0x7fce18d31070 0x205887cfa860 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 941 0x7fce18d31070 0x20588843e860 
[1:1:0712/071350.656097:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 948, 7fce1b676881
[1:1:0712/071350.694670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"941 0x7fce18d31070 0x20588843e860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.694997:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"941 0x7fce18d31070 0x20588843e860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.695341:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071350.695979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071350.696175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071350.696905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071350.697068:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071350.697474:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 966
[1:1:0712/071350.697664:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7fce18d31070 0x20588985b4e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 948 0x7fce18d31070 0x205887cfa860 
[1:1:0712/071350.953208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 898, 7fce1b6768db
[1:1:0712/071350.979559:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.980035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"860 0x7fce18d31070 0x205889fd5b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071350.980663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 976
[1:1:0712/071350.981065:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 976 0x7fce18d31070 0x20588a08d5e0 , 5:3_https://info.xitek.com/, 0, , 898 0x7fce18d31070 0x20588848fe60 
[1:1:0712/071350.981520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071350.982483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071350.982846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.030769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071351.031127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071351.031721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 979
[1:1:0712/071351.032070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7fce18d31070 0x20588a1965e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 898 0x7fce18d31070 0x20588848fe60 
[1:1:0712/071351.050481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071351.051093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 980
[1:1:0712/071351.051414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 980 0x7fce18d31070 0x20588845e8e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 898 0x7fce18d31070 0x20588848fe60 
[1:1:0712/071351.199386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 966, 7fce1b676881
[1:1:0712/071351.251459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"948 0x7fce18d31070 0x205887cfa860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.251909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"948 0x7fce18d31070 0x205887cfa860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.252808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.254268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071351.254768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.256643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071351.257186:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071351.258252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 989
[1:1:0712/071351.258788:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 989 0x7fce18d31070 0x205889fd54e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 966 0x7fce18d31070 0x20588985b4e0 
[1:1:0712/071351.310006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 979, 7fce1b676881
[1:1:0712/071351.349692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.350518:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.351163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.351933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071351.352238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.353828:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 980, 7fce1b6768db
[1:1:0712/071351.392740:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.393522:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.394517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 994
[1:1:0712/071351.395119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7fce18d31070 0x205889b939e0 , 5:3_https://info.xitek.com/, 0, , 980 0x7fce18d31070 0x20588845e8e0 
[1:1:0712/071351.395760:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.397248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071351.397751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.540693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 989, 7fce1b676881
[1:1:0712/071351.584472:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"966 0x7fce18d31070 0x20588985b4e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.585285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"966 0x7fce18d31070 0x20588985b4e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.586323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.587493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071351.588117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.589503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071351.590019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071351.591217:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1002
[1:1:0712/071351.591785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1002 0x7fce18d31070 0x2058889a3860 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 989 0x7fce18d31070 0x205889fd54e0 
[1:1:0712/071351.757953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1002, 7fce1b676881
[1:1:0712/071351.788426:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"989 0x7fce18d31070 0x205889fd54e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.788768:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"989 0x7fce18d31070 0x205889fd54e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.789195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.789842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071351.790107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.790888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071351.791079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071351.791532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1009
[1:1:0712/071351.791796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7fce18d31070 0x20588a0867e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1002 0x7fce18d31070 0x2058889a3860 
[1:1:0712/071351.901797:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1009, 7fce1b676881
[1:1:0712/071351.957339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1002 0x7fce18d31070 0x2058889a3860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.957865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1002 0x7fce18d31070 0x2058889a3860 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071351.958516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071351.959617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071351.959974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071351.961362:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071351.961667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071351.962458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1014
[1:1:0712/071351.962828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7fce18d31070 0x205889b16660 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1009 0x7fce18d31070 0x20588a0867e0 
[1:1:0712/071352.149341:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1014, 7fce1b676881
[1:1:0712/071352.163243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1009 0x7fce18d31070 0x20588a0867e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.163863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1009 0x7fce18d31070 0x20588a0867e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.164670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071352.166135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071352.166621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071352.167862:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071352.168456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071352.169866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1021
[1:1:0712/071352.170372:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7fce18d31070 0x205889992b60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1014 0x7fce18d31070 0x205889b16660 
[1:1:0712/071352.299628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1021, 7fce1b676881
[1:1:0712/071352.366516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1014 0x7fce18d31070 0x205889b16660 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.367241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1014 0x7fce18d31070 0x205889b16660 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.368171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071352.369537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071352.370024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071352.371533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071352.372026:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071352.373043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1023
[1:1:0712/071352.373474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7fce18d31070 0x205888a4f060 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1021 0x7fce18d31070 0x205889992b60 
[1:1:0712/071352.520492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1023, 7fce1b676881
[1:1:0712/071352.542132:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1021 0x7fce18d31070 0x205889992b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.542545:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1021 0x7fce18d31070 0x205889992b60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.543016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071352.543811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071352.544224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071352.545093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071352.545418:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071352.545957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1026
[1:1:0712/071352.546305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7fce18d31070 0x20588a1adc60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1023 0x7fce18d31070 0x205888a4f060 
[1:1:0712/071352.729979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1026, 7fce1b676881
[1:1:0712/071352.757039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1023 0x7fce18d31070 0x205888a4f060 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.757757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1023 0x7fce18d31070 0x205888a4f060 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.758655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071352.760188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071352.760727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071352.762791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071352.763192:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071352.764391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1029
[1:1:0712/071352.764889:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7fce18d31070 0x20588891f460 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1026 0x7fce18d31070 0x20588a1adc60 
[1:1:0712/071352.927401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1029, 7fce1b676881
[1:1:0712/071352.970334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1026 0x7fce18d31070 0x20588a1adc60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.970775:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1026 0x7fce18d31070 0x20588a1adc60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071352.971254:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071352.972054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071352.972397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071352.973306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071352.973637:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071352.974856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1031
[1:1:0712/071352.975534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1031 0x7fce18d31070 0x205889afd160 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1029 0x7fce18d31070 0x20588891f460 
[1:1:0712/071353.140565:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1031, 7fce1b676881
[1:1:0712/071353.183382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1029 0x7fce18d31070 0x20588891f460 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.184162:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1029 0x7fce18d31070 0x20588891f460 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.185057:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.186717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071353.187175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.189230:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071353.189680:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071353.190831:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1034
[1:1:0712/071353.191383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7fce18d31070 0x20588985eee0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1031 0x7fce18d31070 0x205889afd160 
[1:1:0712/071353.347147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1034, 7fce1b676881
[1:1:0712/071353.390087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1031 0x7fce18d31070 0x205889afd160 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.390540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1031 0x7fce18d31070 0x205889afd160 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.391019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.391820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071353.392222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.393120:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071353.393432:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071353.393981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1037
[1:1:0712/071353.394346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7fce18d31070 0x205889e6e260 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1034 0x7fce18d31070 0x20588985eee0 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/071353.530438:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1037, 7fce1b676881
[1:1:0712/071353.564090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1034 0x7fce18d31070 0x20588985eee0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.564580:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1034 0x7fce18d31070 0x20588985eee0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.565112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.565949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071353.566290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.567306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071353.567698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071353.568298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1040
[1:1:0712/071353.568694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7fce18d31070 0x2058896d7460 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1037 0x7fce18d31070 0x205889e6e260 
[1:1:0712/071353.570548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 976, 7fce1b6768db
[1:1:0712/071353.584185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.584636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"898 0x7fce18d31070 0x20588848fe60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.585178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 1041
[1:1:0712/071353.585547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7fce18d31070 0x20588883efe0 , 5:3_https://info.xitek.com/, 0, , 976 0x7fce18d31070 0x20588a08d5e0 
[1:1:0712/071353.586129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.586967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , autoplay, (){
            if(!isMoved){
                isMoved = true;
                
                c
[1:1:0712/071353.587300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.643063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071353.643579:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 0
[1:1:0712/071353.644699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1044
[1:1:0712/071353.645193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1044 0x7fce18d31070 0x205889e696e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 976 0x7fce18d31070 0x20588a08d5e0 
[1:1:0712/071353.662770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 13
[1:1:0712/071353.663330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 1045
[1:1:0712/071353.663559:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7fce18d31070 0x205889ed5560 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 976 0x7fce18d31070 0x20588a08d5e0 
[1:1:0712/071353.825928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1044, 7fce1b676881
[1:1:0712/071353.885458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"976 0x7fce18d31070 0x20588a08d5e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.885806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"976 0x7fce18d31070 0x20588a08d5e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.886195:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.886842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , , (){La=void 0}
[1:1:0712/071353.887080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.888833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1040, 7fce1b676881
[1:1:0712/071353.935184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1037 0x7fce18d31070 0x205889e6e260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.935965:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1037 0x7fce18d31070 0x205889e6e260 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.936856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.938368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071353.938839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071353.940914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071353.941337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071353.942431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1052
[1:1:0712/071353.942851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1052 0x7fce18d31070 0x205889e691e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1040 0x7fce18d31070 0x2058896d7460 
[1:1:0712/071353.944292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 1045, 7fce1b6768db
[1:1:0712/071353.977746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"976 0x7fce18d31070 0x20588a08d5e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.978159:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"976 0x7fce18d31070 0x20588a08d5e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071353.978690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://info.xitek.com/, 1054
[1:1:0712/071353.979029:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7fce18d31070 0x205889af93e0 , 5:3_https://info.xitek.com/, 0, , 1045 0x7fce18d31070 0x205889ed5560 
[1:1:0712/071353.979491:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071353.980259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , n.fx.tick, (){var a,b=0,c=n.timers;for(La=n.now();b<c.length;b++)a=c[b],a()||c[b]!==a||c.splice(b--,1);c.length
[1:1:0712/071353.980585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071354.087687:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1052, 7fce1b676881
[1:1:0712/071354.144542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1040 0x7fce18d31070 0x2058896d7460 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.145226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1040 0x7fce18d31070 0x2058896d7460 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.146025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071354.147431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071354.147976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071354.149660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071354.150053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071354.150825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1058
[1:1:0712/071354.151288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7fce18d31070 0x20588a1a8f60 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1052 0x7fce18d31070 0x205889e691e0 
[1:1:0712/071354.285157:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1058, 7fce1b676881
[1:1:0712/071354.329002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1052 0x7fce18d31070 0x205889e691e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.329447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1052 0x7fce18d31070 0x205889e691e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.329976:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071354.330720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071354.331038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071354.331995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071354.332296:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071354.332865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1061
[1:1:0712/071354.333194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7fce18d31070 0x20588885d9e0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1058 0x7fce18d31070 0x20588a1a8f60 
[1:1:0712/071354.495050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1061, 7fce1b676881
[1:1:0712/071354.539025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1058 0x7fce18d31070 0x20588a1a8f60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.539443:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1058 0x7fce18d31070 0x20588a1a8f60 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0712/071354.539962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0712/071354.540747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071354.541273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0712/071354.543157:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0712/071354.543623:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0712/071354.544814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1063
[1:1:0712/071354.545354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1063 0x7fce18d31070 0x2058899ccde0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1061 0x7fce18d31070 0x20588885d9e0 
[1:1:0712/071354.705435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1063, 7fce1b676881
[1:1:0100/000000.744781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ad90be42860","ptid":"1061 0x7fce18d31070 0x20588885d9e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0100/000000.785255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://info.xitek.com/","ptid":"1061 0x7fce18d31070 0x20588885d9e0 ","rf":"5:3_https://info.xitek.com/"}
[1:1:0100/000000.786330:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://info.xitek.com/reviews/201906/26-336678.html"
[1:1:0100/000000.788380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://info.xitek.com/, 1ad90be42860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0100/000000.788597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://info.xitek.com/reviews/201906/26-336678.html", "info.xitek.com", 3, 1, , , 0
[1:1:0100/000000.789597:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2f151e4c29c8, 0x205888239950
[1:1:0100/000000.789820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://info.xitek.com/reviews/201906/26-336678.html", 100
[1:1:0100/000000.790004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://info.xitek.com/, 1077
[1:1:0100/000000.790087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7fce18d31070 0x205889ee5ae0 , 5:3_https://info.xitek.com/, 1, -5:3_https://info.xitek.com/, 1063 0x7fce18d31070 0x2058899ccde0 
